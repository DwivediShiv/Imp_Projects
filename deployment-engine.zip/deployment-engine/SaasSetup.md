## Create SES Identify and a smtp user and SMTP credentials.
##
## Create a role for SaaS Portal EC2 instance with admin access permissions on Shared account
##
  - IAM --> Create Role
   - Trusted entity type --> AWS Service
   - Use case --> EC2
     - Allows EC2 to call AWS services on your behalf.
       - Add permissions --> AmazonEC2ContainerRegistryReadOnly
       - Add permissions --> AmazonSSMManagedInstanceCore
       - Add permissions --> AdministratorAccess
     - Role Name --> acentrik-saas (DO NOT CHANGE THIS NAME)
     - Tags 
      - Name --> Accentrik-SaaS
##
## Create EC2 Instance for SaaS Portal in Singapore region on Shared account
##
  - EC2
    - Instances
      - Launch instances
        - Name and tags --> acentrik-saas
        - ami --> ubuntu
        - Instance type --> t2.large (upgrade if needed)
        - keypair
          - create a new one --> acentrik-saas
        - Network Settings
          - VPC - Default
          - Subnet - Any public subnet 
          - Auto-assign public IP - Enable
          - Create security group
            - Security group name --> acentrik-saas-sg
            - Description --> acentrik-saas-sg
            - Allow 3000 (saas-portal), 80, 8881, 8882, 8883 from anywhere (later update it to allow only from ALB after ALB creation)
            - Allow 8080 (keycloak) temporarily for initial keycloak setup - Later remove it, if not needed.
          - Configure storage
            - Change from 8GB to 100 GB
          - Advanced details
            - Termination protection --> Enable
##
## - Once the instance is up, assign role "acentrik-saas" to the EC2 instance
##
   - Instance
     - Actions 
       - Security
         - Modify IAM role
           - IAM role --> acentrik-saas (DO NOT CHANGE THIS NAME)

##
## Create RDS posrgres DB for SaaS Portal in Singapore region on Shared account
## These steps are for sime Dev/Test instance. For production, please create a Multi AZ Database
##
 - RDS
    - Create Database
      - Choose a database creation method 
        - Easy create 
      - Configuration
        - Engine type --> postgres
        - DB instance size --> Dev/Test (db.r6g.large ,2 vCPUs ,16 GiB RAM ,100 GiB )
        - DB instance identifier --> acentrik-saas
        - Master username --> postgres
        - Master password --> <password_of_your_choice> --> SaaSDBAdmin123!!!
        - Confirm master password --> <password_of_your_choice> --> SaaSDBAdmin123!!!
      - Set up EC2 connection
        - Compute resource --> Connect to an EC2 compute resource
        - EC2 instance --> Select acentrik-saas instance created above.
    - Click "Create Database"
    
    - Save following details after DB creation
      - Example
        - Endpoint --> acentrik-saas.cz9qqbsqetwe.ap-southeast-1.rds.amazonaws.com
        - Master username --> postgres
        - Master password --> SaaSDBAdmin123!!! (Sample)
##
## - ssh to EC2 from your local shell 
##
  - copy .pem file to --> ~/keys/acentrik-saas.pem
  ### It might take a little while for the instance to reflect in session manager after role is attached.
  ### (instance ID will be different in your case. Check/correct key path and permissions)
  - ssh -i ~/keys/acentrik-saas.pem ubuntu@i-0fbfa7e4926cb0593
  - Update and install packages 
     sudo apt-get update -y
     sudo apt-get install -y postgresql-client redis unzip jq apt-transport-https ca-certificates
  - Install aws cli
     curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
     unzip awscliv2.zip
     sudo ./aws/install
     aws --version
     rm -rf awscliv2.zip aws
     aws configure (set region as "ap-southeast-1" and leave everything blank)

##
## connect to RDS instance (update instance_id and RDS Endpoint)
##
  - ssh -i ~/keys/acentrik-saas.pem ubuntu@i-0a4e5a25b62d85892 -L 0.0.0.0:5435:acentrik-saas.cz9qqbsqetwe.ap-southeast-1.rds.amazonaws.com:5432
##
## Create databases 
##
  - Connect to DB using desktop client localhost:5435 and create databases -> keycloak , saasdb , assetdb
##
GRANT CONNECT ON DATABASE keycloak to postgres;
GRANT ALL PRIVILEGES ON DATABASE keycloak to postgres;
GRANT CONNECT ON DATABASE saasdb to postgres;
GRANT ALL PRIVILEGES ON DATABASE saasdb to postgres;
GRANT CONNECT ON DATABASE assetdb to postgres;
GRANT ALL PRIVILEGES ON DATABASE assetdb to postgres;

##
## Create a SSL certificate for saas-portal.acentrik.io
##
 - AWS Certificate Manager (ACM)
   - Request certificate
     - Request a public certificate
       - Fully qualified domain name --> *.saas-portal.acentrik.io and saas-portal.acentrik.io
       - Validation method --> DNS validation - recommended
   - Refresh List of Certs
     - Select the newly created cert
       - Certificate status will be "Pending validation"
       - Under "Domains" section 
         - Click "Create Records in Route53"
           - Create Records
   - Certificate status should change to "Issued"
##
## Create a target group for Load Balancer
##
 - EC2
   - Target groups
     - Create target group (for saas-portal)
       - Choose a target type --> Instances
       - Target group name --> acentrik-saas
       - Protocol --> HTTP
       - Port --> 3000
       - IP address type - IPv4
       - VPC --> Select appropriate VPC
       - Leave other options as default
       - NEXT
       - Register targets
         - select "acentrik-saas" EC2 Instance
         - Click "Include as pending below"
         - Create Target Group
    
    - Similarly Create target group for saas-management 
       - Target group name --> acentrik-saas-management
       - port - 80
    - Similarly Create target group for asset-management 
       - Target group name --> acentrik-asset-management
       - port - 80
    - Similarly Create target group for saas-notification 
       - Target group name --> acentrik-saas-notification
       - port - 80

    - Similarly Create target group for keycloak - can be removed later.
       - Target group name --> acentrik-saas-keycloak
       - port - 8080
       

##
## Create a Load balancer
##
 - EC2
   - Load balancers
     - Load balancer types
       - Application Load Balancer --> create
         - Basic configuration
           - Load balancer name --> acentrik-saas
           - Scheme --> Internet-facing
           - IP address type --> IPv4
         - Network mapping
           - Select Appropriate VPC, AZ's (including EC2 instance AZ)
         - Security groups
           - Create new SG
             - Name --> acentrik-saas-alb-sg
             - Allow 443 port from everywhere (Later can limit from Acentrik IP's only)
         - Listeners and routing
           - Listener --> Port 443 , HTTPS
           - Select Target group --> acentrik-saas
         - Secure listener settings
           - Security policy --> Keep Default selected
           - Default SSL/TLS certificate
             - From ACM --> Select ACM which was created earlier for "saas-portal.acentrik.io"
      - Click "Create Load Balancer"
      
      - Add rule for saas-management
        - HTTPS:443 listener
        - condition
          - Path --> /saas-management/*
          - Forward to target groups --> target group for saas-management
      - Add rule for asset-management
        - HTTPS:443 listener
        - condition
          - Path --> /asset-management/*
          - Forward to target groups --> target group for asset-management
      - Add rule for saas-notification
        - HTTPS:443 listener
        - condition
          - Path --> /saas-notification/*
          - Forward to target groups --> target group for saas-notification
      - Add rule for keycloak (will need for initial keycloak setup, can be removed once keycloak is setup)
        - HTTPS:443 listener
        - condition
          - Host Header --> keycloak.saas-portal.acentrik.io
          - Forward to target groups --> target group for keycloak

## 
## Update EC2 security group to allow all (or 80, 3000, 8080, 8881, 8882, 8883) ports TCP from ALB-SG (as source) and remove all other rules
##

## Create CNAME route53 record(s)
 - saas-portal.acentrik.io --> <DNS_Name_of_Above_Created_ALB>
 - *.saas-portal.acentrik.io --> <DNS_Name_of_Above_Created_ALB>
##
## Install docker and docker-conpose on Ubuntu
##
 - curl -fsSL https://get.docker.com -o get-docker.sh
 - sudo sh get-docker.sh
 - sudo usermod -aG docker $USER
 - newgrp docker
 - docker ps
 - sudo curl -SL https://github.com/docker/compose/releases/download/v2.20.3/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
 - sudo chmod 755 /usr/local/bin/docker-compose
 - docker-compose version
 
##
## Configure auto login to ECR
##
 - sudo apt install amazon-ecr-credential-helper
 - mkdir ~/.docker
 - vi ~/.docker/config.json  - add below content

{
  "credsStore": "ecr-login"
}

##
## Setup docker-compose 
##
  - scp saas-compose folder to home directory on EC2 instance
  - validate/correct/add configurations (db host, password, role arn's ) in asset-management/config.yaml, saas-management/config.yaml saas-notification/config.yaml
  - validate/correct DB_ADDR, DB_PASSWORD and image name in docker-compose.yml
  - create and add private key in saas-management directory
     - openssl genrsa -out ./private-key.pem 2048
##
##
## Bring up docker-compose
##
  - cd to saas-comnpose directory
  - docker-compose up -d
## 
## Redeploy new image 
## run ~/saas-deploy.sh

## Restrat docker-compose stack
## run ~/saas-restart.sh
##
## Access Saas Portal / saas-management api's and/or keycloak (if exposed)
##
  - Saas Portal --> https://saas-portal.acentrik.io
  - Saas Management --> https://saas-portal.acentrik.io/saas-management/
  - Keycloak --> https://keycloak.saas-portal.acentrik.io/
  - Saas notigication -->  https://dev.saas-portal.acentrik.io/saas-notification/
  - Asset Management -->  https://dev.saas-portal.acentrik.io/asset-management/
##
## 
## create a role to allow saas-portal EC2 role to codebuild and SSM paratemers (DNS) - Folow on both prod and non-prod account
## 
- create role 
      - Select trusted entity --> Trusted entity type --> AWS account
        - An AWS account
          - Another AWS account
            - Account ID --> 540306422608 # shared account ID
          - Next
          - Add permissions
             - Permissions policies (allow access to trigger codebuild and fetch SSM parameters (DNS)
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "codebuild:StartBuild",
			        	"codebuild:RetryBuild",
				        "codebuild:ListProjects"
            ],
            "Resource": "*"
        },
        {
            "Sid": "VisualEditor1",
            "Action": [
                "codebuild:BatchGet*",
                "codebuild:GetResourcePolicy",
                "codebuild:List*",
                "codebuild:DescribeTestCases",
                "codebuild:DescribeCodeCoverages",
                "codecommit:GetBranch",
                "codecommit:GetCommit",
                "codecommit:GetRepository",
                "cloudwatch:GetMetricStatistics",
                "events:DescribeRule",
                "events:ListTargetsByRule",
                "events:ListRuleNamesByTarget",
                "logs:GetLogEvents"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Sid": "VisualEditor2",
            "Effect": "Allow",
            "Action": [
                "ssm:DescribeParameters",
                "ssm:GetParametersByPath",
                "ssm:GetParameters",
                "ssm:GetParameter",
               	"SES:GetIdentityVerificationAttributes",
                "acm:ListCertificates"
            ],
            "Resource": "*"
        }
    ]
}


          - Next
          - Name, review, and create
            - Role name --> codebuild_ssm_role_shared   # DO NOT change this role name
    - update "Trusted Entities" under ""Trust Relaitionships" to allow just EC2 role of shared account saas-portal EC2 machine and should look like below

{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:sts::540306422608:role/acentrik-saas"
            },
            "Action": "sts:AssumeRole",
            "Condition": {}
        }
    ]
}

##
## update the EC2 instance role (acentrik-saas) with following permissions on Shared account


{
	"Version": "2012-10-17",
	"Statement": [
        {
            "Sid": "AssumeCrossAccountRoleProd",
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Resource": "arn:aws:iam::<Prod_account_id>:role/codebuild_ssm_role_shared"
        },
        {
            "Sid": "AssumeCrossAccountRoleNonProd",
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Resource": "arn:aws:iam::<Non_Prod_account_id>:role/codebuild_ssm_role_shared"
        },
	]
}







