#!/bin/bash
cd ~/saas-compose
docker-compose pull
docker-compose down
docker-compose up -d
