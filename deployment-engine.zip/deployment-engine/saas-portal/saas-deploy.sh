#!/bin/bash
cd ~/saas-compose
docker-compose pull
docker-compose up -d
