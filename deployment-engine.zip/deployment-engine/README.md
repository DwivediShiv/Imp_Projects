# One Time Setup 
# This repo contains code to create and destroy cluster(s) and instance(s) in preferred region  
##
## - Create a IAM  group "saas-administrators" with administrator permissions - Follow this on both prod and non-prod accounts
##
## - Create a IAM user saas-admin and assign to "saas-administrators" group - Follow this on both prod and non-prod accounts
##
## - Create other IAM users for team members as needed with appropriate permissions - Follow this on both prod and non-prod accounts
##
## - Make sure you have domain (default domain - accentrik.io in our case) added/created to Route53 hosted zone. This is the default domain that will be used, when custom domain is not passed - Only on Shared Account
##
## - ECR in base region should have all images on shared account
## - Following Images should have {branch_name}-latest tag.
## 
## - account-management
## - asset-management
## - provider-management
## - user-management
## - instance-management
## - instance-portal
## - market
## - notification
## 
## - Both prod and non-prod accounts should have access to these ECR images
##
## - Setup code-commit and push code to the repo (infra-automation) in base region (ap-southeast-1) # we can use other repos as well - This is not needed as we are already having code repo on Acentrik Git
 - code commit 
  - create repository
   - Repository name --> infra-automation
   - Description  --> infra-automation
   - Tags 
      - Name --> Accentrik-SaaS
   
 - Generated Repo URL --> https://git-codecommit.ap-southeast-1.amazonaws.com/v1/repos/infra-automation
##
## - Create credentials for user - This is not needed as we are already having code repo on Acentrik Git
  - IAM
    - Users
      - User (example - mshivam)
        - Security Credentials
          - HTTPS Git credentials for AWS CodeCommit
            - Generate Credentials
##
## - Clone the repo, create v1 branch, add code to v1 branch, commit and push the code
##
## - Create a private s3 bucket in base region (ap-southeast-1 is default) for terraform backend - Only on Shared Account
 - Bucket Name (private) --> terraform-state-acentrik-saas
   - Tags 
      - Name --> Accentrik-SaaS
   - create a folder --> config-management (This will be used for config version management)
   - create a sub folders in config-management --> v1 v2 and prod_versions
   - upload a json file (versions.json) in config-management/prod_versions folder with list of versions ( intilially v1 and v2)
   - upload default-config.yaml and default-secrets.json and form-builder.json for v1 to v1 folder
   - upload default-config.yaml and default-secrets.json and form-builder.json for v2 to v2 folder (add couple of new parameters/variables)
##
## Allow access to prod and non/prod accounts by applying following bucket policy on the above bucket
## Please update prod and non-prod account ID and change bucket name, if needed.
## This will be a read only access used by instance admins to fetch default configs from shared s3 account

{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Permissions to list on prod",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<AccountID_of_prod>:root"
            },
            "Action": [
            "s3:ListBucket",
            "s3:GetObject"
            ],
            "Resource": [
            "arn:aws:s3:::terraform-state-acentrik-saas",
            "arn:aws:s3:::terraform-state-acentrik-saas/*"
            ]
        },
        {
            "Sid": "Permissions to list on non-prod",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<AccountID_of_non_prod>:root"
            },
            "Action": [
            "s3:ListBucket",
            "s3:GetObject"
            ],
            "Resource": [
            "arn:aws:s3:::terraform-state-acentrik-saas",
            "arn:aws:s3:::terraform-state-acentrik-saas/*"
            ]
        }
    ]
}


## - Create a dynamodb table manually for terraform state lock in base region (ap-southeast-1 is default) - - Only on Shared Account
 - Table name --> terraform-state-acentrik-saas
 - Partition key --> LockID
 - Table settings --> Customize Settings 
   - Table class --> DynamoDB Standard
   - Read/write capacity settings --> On-demand
   - Encryption at rest --> Owned by Amazon DynamoDB
   - Deletion protection --> Turn on deletion protection
   - Tags 
      - Name --> Accentrik-SaaS
##
## Create a IAM role on Shared account to allow prod and non-prod accounts access/update s3 bucket(for terraform), dynamodb table (for terraform) and route53 hosted zone(default domain)
   - create role 
      - Select trusted entity --> Trusted entity type --> AWS account
        - An AWS account
          - Another AWS account
            - Account ID --> <AccountID_of_prod>
          - Next
          - Add permissions
             - Permissions policies (allow access to s3, route53 hosted zone and dynamodb table)
               - S3Access (Below policy)

{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "s3:ListBucket"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:s3:::terraform-state-acentrik-saas"
        },
        {
            "Action": [
                "s3:DeleteObject",
                "s3:GetObject",
                "s3:PutObject",
                "s3:PutObjectAcl"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:s3:::terraform-state-acentrik-saas/*"
        }
    ]
}

               - AmazonRoute53 Access (limited to default domain hosted zone)

{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "route53:GetHealthCheckStatus",
                "route53:GetChange",
                "route53:GetHostedZone",
                "route53:ChangeResourceRecordSets",
                "route53:ListResourceRecordSets",
                "route53:GetHealthCheck",
                "route53:ListTagsForResource"
            ],
            "Resource": "arn:aws:route53:::hostedzone/Z083299129HKDZ0YBV3M1" # use ID of acentrik.io hosted zone
        },
        {
            "Sid": "VisualEditor1",
            "Effect": "Allow",
            "Action": [
                "route53:ListHealthChecks",
                "route53:ListHostedZones",
                "route53:ListHostedZonesByName",
                "route53:GetHostedZoneCount"
            ],
            "Resource": "*"
        },
		    {
		    	"Sid": "VisualEditor2",
		    	"Effect": "Allow",
		    	"Action": [
		    		"route53:GetChange"
		    	],
		    	"Resource": "arn:aws:route53:::change/*"
		    }
    ]
}


               - AmazonDynamoDBAccess (limited this to specific dynamoDB for terraform)

{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
				        "dynamodb:GetItem",
				        "dynamodb:PutItem",
				        "dynamodb:Query",
				        "dynamodb:UpdateItem",
				        "dynamodb:UpdateTable",
				        "dynamodb:GetRecords",
				        "dynamodb:DeleteItem",
				        "dynamodb:DescribeTable",
				        "dynamodb:ListTables"
            ],
            "Resource": "arn:aws:dynamodb:ap-southeast-1:540306422608:table/terraform-state-acentrik-saas"
        },
        {
            "Sid": "VisualEditor1",
            "Effect": "Allow",
            "Action": "dynamodb:ListTables",
            "Resource": "*"
        }
    ]
}


          - Next
          - Name, review, and create
            - Role name --> route53_s3_dynamodb_role  # DO NOT change this role name
    - update role to allow <AccountID_of_non-prod> as well. Final "Trusted Entities" under ""Trust Relaitionships" should look like below.

    {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<AccountID_of_prod>:root"
            },
            "Action": "sts:AssumeRole",
            "Condition": {}
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<AccountID_of_non-prod>:root"
            },
            "Action": "sts:AssumeRole",
            "Condition": {}
        }
    ]
   }


## - Create a IAM role for codebuild to allow all permissions - Follow this on both prod and non-prod accounts
  - IAM --> Create Role
   - Trusted entity type --> AWS Service
   - Use case --> CodeBuild
     - Allows CodeBuild to call AWS services on your behalf.
       - Add permissions ---> Administrator Access
     - Role Name --> role_for_codebuild
     - Tags 
      - Name --> Accentrik-SaaS
##
## - Create a role for Base EC2 instance with admin access permissions - Follow this on both prod and non-prod accounts
  - IAM --> Create Role
   - Trusted entity type --> AWS Service
   - Use case --> EC2
     - Allows EC2 to call AWS services on your behalf.
       - Add permissions --> Administrator Access
       - Add permissions --> AmazonSSMManagedInstanceCore
     - Role Name --> base-jump-host
     - Tags 
      - Name --> Accentrik-SaaS
##
## - Using default VPC with CIDR "172.31.0.0/16" in base region. - Follow this on both prod and non-prod accounts
##
## - Tag the default vpc with following tag (Do NOT change key and value values). This will be used to identify default base VPC
##
  Key  --> purpose
  Value --> saas_base_vpc

## - Create NAT Gateway for codebuild private subnet - Follow this on both prod and non-prod 
  - Name --> codebuild-nat-gw
  - Subnet --> select any public subnet
  - Connectivity type --> Public
  - Elastic IP allocation ID --> Allocate EIP, if not existing.
  - tags
    - Name --> codebuild-nat-gw
##
##  - Create a private subnet for codebuild in base region base VPC - Follow this on both prod and non-prod accounts
  - Subnet name --> codebuild
  - Availability Zone --> ap-southeast-1a
  - IPv4 CIDR block --> 172.31.99.0/24
  - tags
    - Name --> codebuild
##
## - Create a route table for codebuild in base region base VPC - Follow this on both prod and non-prod accounts
  - Name --> codebuild-rt
  - VPC --> base VPC
  - tags
    - Name --> codebuild-rt
##
## - Add a route in route table - Follow this on both prod and non-prod accounts
  - edit routes
    - Add route
        - destination --> "0.0.0.0/0" 
        - target --> NAT GW created above (codebuild-nat-gw).
##
## - Associate subnet "codebuild" with route table "codebuild-rt" - Follow this on both prod and non-prod accounts
##
## - Create a EC2 instance (base-jump-host) in any public subnet of base VPC. - Follow this on both prod and non-prod accounts
  - Name --> base-jump-host
  - AMI --> Ubuntu (ami-0df7a207adb9748c7 or any other latest ubuntu )
  - Instance type --> t2.small
  - KeyPair 
    - create new
      - Key pair name --> base-jump-host (can choose any other suitable name)
      - Key pair type --> RSA
      - Private key file format --> .pem
  - Network Settings
    - Edit
      - VPC --> Select base VPC
      - Subnet --> Select any public subnet
      - Auto-assign public IP --> Enable
      - Firewall (security groups) --> Create security group
        - Security group name --> base-jump-host-sg
        - Description  --> base-jump-host-sg
        - Inbound Security Group Rules --> Remove any existing default rules. Keep it empty (Do not add any rule)
  - Advanced details
    - Termination protection --> Enable
##
## - Once the instance is up, assign role "base-jump-host" to the EC2 instance - Follow this on both prod and non-prod accounts
   - Instance
     - Actions 
       - Security
         - Modify IAM role
           - IAM role --> base-jump-host
##
## - ssh to EC2 from your local shell 
  - copy .pem file to --> ~/keys/base-jump-host.pem
  ### It might take a little while for the instance to reflect in session manager after role is attached.
  ### (instance ID will be different in your case. Check/correct key path and permissions)
  ### keys will also be different for prod and non-prod base jump host
  - ssh -i ~/keys/base-jump-host.pem ubuntu@i-02780cd5abad4eaf0 
##
## - Setup some tools on EC2 - Follow this on both prod and non-prod accounts
  - Copy scripts folder from repo
    scp -i ~/s/base-jump-host.pem ./misc/jump-host-scripts/* ubuntu@i-02780cd5abad4eaf0:~/
  - Update and install packages 
     sudo apt-get update -y
     sudo apt-get install -y postgresql-client redis unzip jq apt-transport-https ca-certificates curl net-tools
  - Install aws cli
     curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
     unzip awscliv2.zip
     sudo ./aws/install
     aws --version
     rm -rf awscliv2.zip aws
  - Install kubectl 
     curl -LO https://dl.k8s.io/release/v1.27.1/bin/linux/amd64/kubectl
     sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
     kubectl version --client
     rm -f kubectl
  - Setup HNC
     HNC_VERSION=v1.1.0
     HNC_PLATFORM=linux_amd64
     curl -L https://github.com/kubernetes-sigs/hierarchical-namespaces/releases/download/${HNC_VERSION}/kubectl-hns_${HNC_PLATFORM} -o ./kubectl-hns
     chmod +x ./kubectl-hns
     sudo mv kubectl-hns /usr/local/bin/
     kubectl hns -v
   - Install helm
     curl -fsSL -o get_helm.sh https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3
     chmod 700 get_helm.sh
     ./get_helm.sh
     helm version
     rm get_helm.sh
##
## - Update/validate base_region, base_region_vpc_id (created above), base_region_vpc_cidr (created above) and IAM users which are kms_key_administrators (create above) in following files in the terraform code. This is ONE time setup.
##
  ### PLEASE VALIDATE THESE ATLEAST TWICE AND UPDATE WHEREVER NECESSARY and PUSH THE CODE.
##
  
  - base_cluster/codebuild/cluster_create.yml (validate bucket name, shared_account_id and default_domain)
  - base_cluster/codebuild/cluster_destroy.yml (validate bucket name, shared_account_id and default_domain)
  - base_cluster/saas-infra/variables.tf (validate base_region_vpc_cidr , kms_key_administrators , eks_cluster_trusted_role_arns, explicit_eks_cluster_admins, region_cidrs and other cluster specific variables that needs to be tuned as per need)
  
  - instance/codebuild/instance_create.yml (validate bucket name, shared_account_id and default_domain)
  - instance/codebuild/instance_destroy.yml (validate bucket name, shared_account_id and default_domain)
  - instance/codebuild/instance_deactivate.yml (validate bucket name, shared_account_id and default_domain)

##
## - Create code builds for cluster_create - Follow this on both prod and non-prod accounts
   - Project --> cluster_create
     - Restrict number of concurrent builds this project can start --> 5
     - Tags 
      - Name --> Accentrik-SaaS
     - Source 1 - Primary --> AWS CodeCommit # This can be set to Github or other repos
      - Repository --> infra-automation
      - Branch --> v1 (Default version - update this whenever you want to change default version)
     - Environment
      - Managed Image
        - Operating system --> Ubuntu
        - Runtime(s) --> Standard
        - Image --> aws/codebuild/standard:7.0
        - Image Version --> aws/codebuild/standard:7.0-23.06.12
      - Service role
        - Existing service role
          - role_for_codebuild
          - uncheck "Allow AWS CodeBuild to modify this service role so it can be used with this build project" (uncheck if service quota limit to add policies per role is breached)
     - Additional configuration
       - Timeout --> 2 hours
       - select Base VPC, subnet (codebuild subnet) and SG (default, Do NOT select base-jumphost SG)
        - Validate VPC settings (This should be successful)
     - Buildspec 
       - Use a buildspec file
         - base_cluster/codebuild/cluster_create.yml (see path in code repo)
     - Batch configuration - SKIP
     - Artifacts - SKIP
     - Logs
       - CloudWatch --> Select "CloudWatch logs"
         - Group name --> codebuild
         - Stream name --> cluster_create (Separate stream name per codebuild. use same name as codebuild project)
         - Modify retention of log group to 3 months (from cloudwatch console), after one codebuild execution
##
## - Create code builds for cluster_destroy - Follow this on both prod and non-prod accounts
   - Project --> cluster_destroy
     - Restrict number of concurrent builds this project can start --> 5
     - Tags 
      - Name --> Accentrik-SaaS
     - Source 1 - Primary --> AWS CodeCommit # This can be set to Github or other repos
      - Repository --> infra-automation
      - Branch --> v1 (Default version - update this whenever you want to change default version)
     - Environment
      - Managed Image
        - Operating system --> Ubuntu
        - Runtime(s) --> Standard
        - Image --> aws/codebuild/standard:7.0
        - Image Version --> aws/codebuild/standard:7.0-23.06.12
      - Service role
        - Existing service role
          - role_for_codebuild
          - uncheck "Allow AWS CodeBuild to modify this service role so it can be used with this build project" (uncheck if service quota limit to add policies per role is breached)
     - Additional configuration
       - Timeout --> 2 hours
       - select Base VPC, subnet (codebuild subnet) and SG (default, Do NOT select base-jumphost SG)
        - Validate VPC settings (This should be successful)
     - Buildspec 
       - Use a buildspec file
         - base_cluster/codebuild/cluster_destroy.yml (see path in code repo)
     - Batch configuration - SKIP
     - Artifacts - SKIP
     - Logs
       - CloudWatch --> Select "CloudWatch logs"
         - Group name --> codebuild
         - Stream name --> cluster_destroy (Separate stream name per codebuild. use same name as codebuild project)
         - Modify retention of log group to 3 months (from cloudwatch console), after one codebuild execution
##
## - Create code builds for instance_create - Follow this on both prod and non-prod accounts
   - Project --> instance_create
     - Restrict number of concurrent builds this project can start --> 20
     - Tags 
      - Name --> Accentrik-SaaS
     - Source 1 - Primary --> AWS CodeCommit # This can be set to Github or other repos
      - Repository --> infra-automation
      - Branch --> v1 (Default version - update this whenever you want to change default version)
     - Environment
      - Managed Image
        - Operating system --> Ubuntu
        - Runtime(s) --> Standard
        - Image --> aws/codebuild/standard:7.0
        - Image Version --> aws/codebuild/standard:7.0-23.06.12
      - Service role
        - Existing service role
          - role_for_codebuild
          - uncheck "Allow AWS CodeBuild to modify this service role so it can be used with this build project" (uncheck if service quota limit to add policies per role is breached)
     - Additional configuration
       - Timeout --> 2 hours
       - select Base VPC, subnet (codebuild subnet) and SG (default, Do NOT select base-jumphost SG)
        - Validate VPC settings (This should be successful)
     - Buildspec 
       - Use a buildspec file
         - instance/codebuild/instance_create.yml (see path in code repo)
     - Batch configuration - SKIP
     - Artifacts - SKIP
     - Logs
       - CloudWatch --> Select "CloudWatch logs"
         - Group name --> codebuild
         - Stream name --> instance_create (Separate stream name per codebuild. use same name as codebuild project)
         - Modify retention of log group to 3 months (from cloudwatch console), after one codebuild execution
##
## - Create code builds for instance_destroy - Follow this on both prod and non-prod accounts
   - Project --> instance_destroy
     - Restrict number of concurrent builds this project can start --> 5
     - Tags 
      - Name --> Accentrik-SaaS
     - Source 1 - Primary --> AWS CodeCommit # This can be set to Github or other repos
      - Repository --> infra-automation
      - Branch --> v1 (Default version - update this whenever you want to change default version)
     - Environment
      - Managed Image
        - Operating system --> Ubuntu
        - Runtime(s) --> Standard
        - Image --> aws/codebuild/standard:7.0
        - Image Version --> aws/codebuild/standard:7.0-23.06.12
      - Service role
        - Existing service role
          - role_for_codebuild
          - uncheck "Allow AWS CodeBuild to modify this service role so it can be used with this build project" (uncheck if service quota limit to add policies per role is breached)
     - Additional configuration
       - Timeout --> 2 hours
       - select Base VPC, subnet (codebuild subnet) and SG (default, Do NOT select base-jumphost SG)
        - Validate VPC settings (This should be successful)
     - Buildspec 
       - Use a buildspec file
         - instance/codebuild/instance_destroy.yml (see path in code repo)
     - Batch configuration - SKIP
     - Artifacts - SKIP
     - Logs
       - CloudWatch --> Select "CloudWatch logs"
         - Group name --> codebuild
         - Stream name --> instance_destroy (Separate stream name per codebuild. use same name as codebuild project)
         - Modify retention of log group to 3 months (from cloudwatch console), after one codebuild execution
##
## - Create code builds for instance_deactivate - Follow this on both prod and non-prod accounts
   - Project --> instance_deactivate
     - Restrict number of concurrent builds this project can start --> 5
     - Tags 
      - Name --> Accentrik-SaaS
     - Source 1 - Primary --> AWS CodeCommit # This can be set to Github or other repos
      - Repository --> infra-automation
      - Branch --> v1 (Default version - update this whenever you want to change default version)
     - Environment
      - Managed Image
        - Operating system --> Ubuntu
        - Runtime(s) --> Standard
        - Image --> aws/codebuild/standard:7.0
        - Image Version --> aws/codebuild/standard:7.0-23.06.12
      - Service role
        - Existing service role
          - role_for_codebuild
          - uncheck "Allow AWS CodeBuild to modify this service role so it can be used with this build project" (uncheck if service quota limit to add policies per role is breached)
     - Additional configuration
       - Timeout --> 2 hours
       - select Base VPC, subnet (codebuild subnet) and SG (default, Do NOT select base-jumphost SG)
        - Validate VPC settings (This should be successful)
     - Buildspec 
       - Use a buildspec file
         - instance/codebuild/instance_deactivate.yml (see path in code repo)
     - Batch configuration - SKIP
     - Artifacts - SKIP
     - Logs
       - CloudWatch --> Select "CloudWatch logs"
         - Group name --> codebuild
         - Stream name --> instance_deactivate (Separate stream name per codebuild. use same name as codebuild project)
         - Modify retention of log group to 3 months (from cloudwatch console), after one codebuild execution
##
## - Setup AWS credentials (if you want to create cluste/instance from local machine). Your account should have access to trigger codebuilds. set region to base region (ap-southeast-1) - You will need different profiles for prod and non-prod accounts
 - aws configure
 
##
## There are 4 different codebuilds available - Make sure you have selected right profile (prod / non-prod)
 ### 1) To create Cluster in a region
 ### 2) To create Instance in a region
 ### 3) To destroy Instance fron a region
 ### 4) To destroy Cluster from a region
 ### 5) To deactivate Instance in a region
##
## Details about cluster create codebuild. 
##  
  ### Parameters
  #### 1) region (Mandatory) - It is the region where you want to create an EKS cluster
  #### 2) network (Mandatory) - It is the subgraph which you want to deploy at cluster level
  #### 3) version (Mandatory) - This is the branch from which code will be deployed. This is not a parameter to terraform, but a parameter to codebuild
##
  ### It creates following components.
  #### 1) A VPC and aother networking componenets like various subnets (for EKS cluster, databases, Opensearch, Elasticache etc..), nat gateways, enable flow_logs etc.. in the region
  #### 2) Peering between base VPC and this newly created VPC, required routes etc.. This is done so that resouces in all regions can be connected/managed from base region.
  #### 3) Setup GuardDuty in the region for threat detection
  #### 4) Create EKS cluster with follwing add-ons --> kube-proxy, vpc-cni, coredns, aws-ebs-csi-driver and aws-guardduty-agent
  #### 5) Setup Auto-scaling for EKS Cluster
  #### 6) Parameters for common ipfs-cluster
  #### 7) Create EFS  
  #### 8) Required KMS keys, policies and roles
  #### 9) Setting up Calico Networking
  #### 10) Setup Cloudwatch Monitoring and logging for EKS cluster and applications.
  #### 11) Install Secret Store CSI Driver
  #### 12) Install EFS CSI Driver
  #### 13) Install Cert-Issuer
  #### 14) Setup IPFS-CLUSTER in ipfs namespace, which will be common for all instances in the region.
  #### 15) subgraph at cluster level in the network (passed as parameter) namespace
  #### 16) Ingress controller which create and ingress LB. URL saved to SSM parameters, which will be used while instance creation in the region.
##
## Details about cluster destroy codebuild. It destroys all the components/resources created by cluster create.
  ### Parameters
  #### 1) region (Mandatory) - It is the region where you want to destroy the EKS cluster
  #### 2) version (Mandatory) - This is the branch from which code will be deployed. This is not a parameter to terraform, but a parameter to codebuild
##
## Details about instance create codebuild. 
##
## prod / non-prod account to be selected from UI and accordingly backend will use role from that account. Not passed as parameter.
  ### Parameters
  #### 1) region (Mandatory) - It is the region where you want to create an instance.
  #### 2) instance_name (Mandatory and unique) - It is the name of the instance. It has to be unique per region.
  #### 3) instance_admin_email (Mandatory) - It is the email id of initial instance admin.
  #### 4) network (Mandatory) - If becomes the default network for the instance.
  #### 5) token_address (Mandatory)
  #### 6) token_symbol (Mandatory)
  #### 7) decimals (Mandatory)
  #### 8) version (Mandatory, v1 is default) - This is the branch from which code will be deployed. This is not a parameter to terraform, but a parameter to codebuild
  #### 9) custom_domain (Optional and unique, default is defined in instance/codebuild/instance-infra/variables.
      - Ex-1 - For market service and instance_name as nagarro-dev, custom domain as acentrik.io, the generated domain name will be https://acentrik.io
      - Ex-2 - For market service and instance_name as nagarro-dev, custom domain as prod.acentrik.io, the generated domain name will be https://prod.acentrik.io
      - Ex-3 - For market service and instance_name as nagarro-dev, default domain as acentrik.io ( means no custom domain provided), the generated domain name will be https://nagarro-dev.acentrik.io
  #### 10) ses_domain (Optional, But mandatory when custom_domain is passed)
  #### 11) ses_domain_exists (Optional, but mandatory with custom domain - Either "True" or "False" and it's a string) - Check in saas instance db and check if it is already created for some instance.
  ## If you want to use custom domain, please follow below steps else skip directly to installation.
    - Ask client/domain owner to add wild card entry pointing to Regional LB URL (SSM Parameter --> /${region}/acentrik/lb_url). This LB is created when cluster in created
        - Ex1-  *.acentrik.io <LB_DOMAIN> 
        - Ex2-  *.prod.acentrik.io <LB_DOMAIN>
  ### start the installation   
    - cd misc/jump-host-scripts # Not needed on base jump host
    - ./instance_create.sh
  ### Post Installation - DNS records update (only for custom domain)
    - Ask client to add record for ACM DNS validation which is a CNAME record ( SSM Parameter --> /${instance_name}/acentrik/ssm_custom_acm_validation_route53_record_fqdns)
        - Make sure to check us-east-1 region
        - This ACM will be created during installation and adding record will validate the cert
        - The validation can take some time.
    - Wait for ACM certs validation. Make sure "Status" is "Issued".
    - Manually update cloudfront to add domain alias and approved ACM certs or rerun instance_create (make sure to pass custom_domain).
    - Add client to add CNAME record for marketplace to serve from cloudfront
      - <custom_domain> <cloudfront_dustribution_url>  --> (SSM Parameter --> /${instance_name}/acentrik/cdn_route53_record_fqdns)
        - Ex:- prod.acentrik.io --> d6rmy47lql98q.cloudfront.net
    - Ask client to add CNAME records for SES - This step will be needed only if ses_domain_exists was sent as 'False' ( SSM Parameter --> /${instance_name}/acentrik/ssm_custom_ses_validation_route53_record_fqdns)
##
##
  ### It creates following components and deploys applications
  #### 1) s3 bucket for the instance
  #### 2) ACM certs for the domain
  #### 3) applicable route 53 entries for default domain
  #### 4) WAF ACL's for instance
  #### 5) Cloudfront for instance
  #### 6) create opensearch instance
  #### 7) create elasticache instance
  #### 8) create SES Identity for the instance
  #### 9) RDS postgres database instance
  #### 10) creates following databases on RDS instance for applications - accountdb, assetdb, keycloakdb, operatordb, providerdb, userdb, logdb and network provider db like polygondb (based on network parameter), set the credentails and save to SSM parameters
  #### 11) create some dummy SSM parameters whose values are not known whilt instance creation. These parameters if changed later during instance customization or furthur setup will not change back to dummy values on re-running the create instance codebuild to upgrade/downgrade versions. On re-running, it will only create parameters with dummy values which are not existing.
  #### 12) create approproate policies and roles for serviceaccounts
  #### 13) create following instance specific namespaces -> ${instance_name}-ocean, ${instance_name}-ipfs, ${instance_name}-keyckoak, ${instance_name}-ocean-compute, ${instance_name}-ocean-operator, ${instance_name}-${network}
  #### 14) Deploy below helm charts for all applications/services, along with certs for public facing domains.
  #### a) ipfs-cluster in ${instance_name}-ipfs namespace
  #### b) keycloak in {instance_name}-keyckoak namespace
  #### c) ocean-compute-operator in ${instance_name}-ocean-computer namespace
  #### d) operator-api in ${instance_name}-ocean-operator namespace
  #### e) account-management in ${instance_name}-ocean namespace
  #### f) asset-management in ${instance_name}-ocean namespace
  #### g) market in ${instance_name}-ocean namespace
  #### h) notification in ${instance_name}-ocean namespace
  #### i) provider-management in ${instance_name}-ocean namespace
  #### j) rbac-server in ${instance_name}-ocean namespace
  #### k) user-management in ${instance_name}-ocean namespace
  #### l) aquarius in ${instance_name}-${network} namespace
  #### m) provider in ${instance_name}-${network} namespace
  #### n) subgraph in ${instance_name}-${network} namespace. This deploys its own ipfs as well
##
## Details about instance destroy codebuild. It destroys all the components/resources created by instance create.
  ### Parameters
  #### 1) region (Mandatory) - It is the region where you want to destroy the instance
  #### 2) instance_name (Mandatory) - It is the instance name which you want to destroy
  #### 3) version (Mandatory) - This is the branch from which code will be deployed. This is not a parameter to terraform, but a parameter to codebuild
  #### 4) ses_domain (Optional - Mandatory, if custom domain was used to create the instance - Pull value from DB)
  #### 5) ses_domain_in_use (Optional - Mandatory, if ses_domain is passed. Whether SES domain is in use by some instance ? - (it should be either "True" or "False" and it's a string)
##
## Details about instance deactivate codebuild. It will scale down repicas to 0 for all deployments for the instance
  ### Parameters
  #### 1) region (Mandatory) - It is the region where you want to deactivate the instance
  #### 2) instance_name (Mandatory) - It is the instance name which you want to deactivate
  #### 3) version (Mandatory) - This is the branch from which code will be deployed. This is not a parameter to terraform, but a parameter to codebuild
##
## upgrade/downgrade instance --> Keep different versions code in different branches like v1 branch for version v1 code, v2 branch for version v2 code and so on..
  ### to upgrade an instance pass the appropriate version, which you want to deploy
  ### same version logic applies to cluster infrastructure.

## - Jump Host - Setup EKS cluster context to run kubectl commands
./setup_cluster_context.sh        # input region
##
## - Jump Host - Connect to RDS from Jump Host in base region
./connect_rds.sh        # input region and instance_name
##
## - Jump Host - Fetch RDS hostname and password to connect using ssh tunneling from local DB client.
./get_db_details.sh     # input region and instance_name
##
## - Jump Host - Check opensearch status from Jump Host
./check_opensearch_status.sh     # input region and instance_name
##
## - Jump Host - Check/Connect Redis / Elasticache from Jump Host
./connect_elasticache.sh     # input region and instance_name





