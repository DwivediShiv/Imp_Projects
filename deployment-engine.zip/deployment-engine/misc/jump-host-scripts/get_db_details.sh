#!/bin/bash
echo ""
read -p 'Enter Cluster Region where RDS exists (Ex- us-east-1): ' region
read -p 'Enter Instance name (Ex- instance-a): ' instance_name
echo ""
region=$region
echo ""
echo "You have selected $region region and instance name is $instance_name"
echo ""
db_host=`aws ssm get-parameter --region $region --name /${instance_name}/acentrik/core/db/postgres/host --with-decryption | jq -r ".Parameter.Value"`
echo "DB connect URL is --> $db_host"
export PGPASSWORD=`aws ssm get-parameter --region $region --name /${instance_name}/acentrik/core/db/postgres/password --with-decryption | jq -r ".Parameter.Value"`
echo "DB username is --> postgres"
echo "DB password is --> $PGPASSWORD"

