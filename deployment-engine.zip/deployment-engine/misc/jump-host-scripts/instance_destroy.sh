#!/bin/bash
echo ""
region=; until [[ $region ]]; do read -p 'Enter Cluster region to destroy instance from (Ex- ap-southeast-1): ' region ; done
region=$region
instance_name=; until [[ $instance_name ]]; do read -p 'Enter Instance name (Ex- nagarro-dev): ' instance_name ; done
# There will a branch by version number, which will be checked out basis below input
version=; until [[ $version ]]; do read -p 'Enter version number - OPTIONAL (Default - v1): ' version; done
read -p 'Enter Ses Domain name - ( Optional - TO be passed if custom domain was used to create the instance - Pull value from DB): ' ses_domain
if [[ $ses_domain != "" ]]
  then
    ses_domain_in_use=;  until [[ $ses_domain_in_use ]]; do read -p 'Whether SES domain is in use by some instance ? - (it should be either "True" or "False"): ' ses_domain_in_use ; done
    sleep 5
    aws codebuild start-build --project-name instance_destroy --source-version $version --environment-variables-override "[{\"name\":\"region\",\"value\":\"$region\"} , {\"name\":\"instance_name\",\"value\":\"$instance_name\"} , {\"name\":\"ses_domain\",\"value\":\"$ses_domain\"} , {\"name\":\"ses_domain_in_use\",\"value\":\"$ses_domain_in_use\"}]"
  else
    aws codebuild start-build --project-name instance_destroy --source-version $version --environment-variables-override "[{\"name\":\"region\",\"value\":\"$region\"} , {\"name\":\"instance_name\",\"value\":\"$instance_name\"}]"
fi
echo ""
echo "RUN below command to see the logs"
echo ""
echo "aws logs tail codebuild --follow --log-stream-name-prefix  instance_destroy --format detailed "
