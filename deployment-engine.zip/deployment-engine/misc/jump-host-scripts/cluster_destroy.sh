#!/bin/bash
echo ""
region=; until [[ $region ]]; do read -p 'Enter Cluster region to DELETE create cluster from (Ex- ap-southeast-1): ' region ; done
# There will a branch by version number, which will be checked out basis below input
version=; until [[ $version ]]; do read -p 'Enter version number ' version ; done
sleep 5
echo ""
aws codebuild start-build --project-name cluster_destroy --source-version $version --environment-variables-override "[{\"name\":\"region\",\"value\":\"$region\"}]"
echo ""
echo "RUN below command to see the logs"
echo ""
echo "aws logs tail codebuild --follow --log-stream-name-prefix  cluster_destroy --format detailed "
