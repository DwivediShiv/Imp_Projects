#!/bin/bash
echo ""
region=; until [[ $region ]]; do read -p 'Enter Cluster region to create instance in (Ex- ap-southeast-1): ' region ; done
region=$region
instance_name=; until [[ $instance_name ]]; do read -p 'Enter Instance name (Ex- nagarro-dev): ' instance_name ;done
instance_admin_email=; until [[ $instance_admin_email ]]; do read -p "Enter Instance Admin's Email  : " instance_admin_email ; done
network_name=; until [[ $network_name ]]; do read -p 'Enter Network name : ' network_name ; done
token_address=; until [[ $token_address ]]; do read -p 'Enter token_address : ' token_address ; done
token_symbol=; until [[ $token_symbol ]]; do read -p 'Enter token_symbol : ' token_symbol ; done
decimals=; until [[ $decimals ]]; do read -p 'Enter decimals : ' decimals ; done
# There will a branch by version number, which will be checked out basis below input
version=; until [[ $version ]]; do read -p 'Enter version number - OPTIONAL (Default - v1): ' version; done
read -p 'Do you want a custom domain for the instance ? - OPTIONAL - "yes" for custom domain and anything else for default domain : ' answer
if [[ $answer == "yes" ]]
        then
            custom_domain=; until [[ $custom_domain ]]; do read -p 'Enter Custom Domain name -(Ex- example.com, abc.example.com): ' custom_domain ; done
            ses_domain=;  until [[ $ses_domain ]]; do read -p 'Enter Ses Domain name - (it should be either same as custom_domain or substring of custom_domain): ' ses_domain ; done
            ses_domain_exists=;  until [[ $ses_domain_exists ]]; do read -p 'Whether SES domain is already created by some instance ? - (it should be either "True" or "False"): ' ses_domain_exists ; done
            sleep 5
            aws codebuild start-build --project-name instance_create --source-version $version --environment-variables-override "[{\"name\":\"region\",\"value\":\"$region\"} , {\"name\":\"instance_name\",\"value\":\"$instance_name\"} , {\"name\":\"instance_admin_email\",\"value\":\"$instance_admin_email\"} , {\"name\":\"network\",\"value\":\"$network_name\"} , {\"name\":\"token_address\",\"value\":\"$token_address\"} , {\"name\":\"token_symbol\",\"value\":\"$token_symbol\"} , {\"name\":\"decimals\",\"value\":\"$decimals\"} , {\"name\":\"custom_domain\",\"value\":\"$custom_domain\"} , {\"name\":\"ses_domain\",\"value\":\"$ses_domain\"} , {\"name\":\"ses_domain_exists\",\"value\":\"$ses_domain_exists\"}]"
        else
            sleep 5
            aws codebuild start-build --project-name instance_create --source-version $version --environment-variables-override "[{\"name\":\"region\",\"value\":\"$region\"} , {\"name\":\"instance_name\",\"value\":\"$instance_name\"} , {\"name\":\"instance_admin_email\",\"value\":\"$instance_admin_email\"} , {\"name\":\"network\",\"value\":\"$network_name\"} , {\"name\":\"token_address\",\"value\":\"$token_address\"} , {\"name\":\"token_symbol\",\"value\":\"$token_symbol\"} , {\"name\":\"decimals\",\"value\":\"$decimals\"}]"
               
fi
echo ""
echo "RUN below command to see the logs"
echo ""
echo "aws logs tail codebuild --follow --log-stream-name-prefix  instance_create --format detailed "

