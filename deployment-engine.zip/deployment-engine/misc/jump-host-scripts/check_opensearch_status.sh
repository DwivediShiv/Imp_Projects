#!/bin/bash
echo ""
read -p 'Enter Cluster Region where OPensearch exists (Ex- us-east-1): ' region
read -p 'Enter Instance name (Ex- instance-a): ' instance_name
echo ""
region=$region
echo ""
echo "You have selected $region region and instance name is $instance_name"
echo ""
es_host=`aws ssm get-parameter --region $region --name /${instance_name}/acentrik/core/es/host --with-decryption | jq -r ".Parameter.Value"`
es_user=`aws ssm get-parameter --region $region --name /${instance_name}/acentrik/core/es/username --with-decryption | jq -r ".Parameter.Value"`
es_pass=`aws ssm get-parameter --region $region --name /${instance_name}/acentrik/core/es/password --with-decryption | jq -r ".Parameter.Value"`
curl -X GET -u $es_user:$es_pass https://$es_host/_cluster/health?pretty