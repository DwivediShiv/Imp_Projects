#!/bin/bash
echo ""
read -p 'Enter Cluster Region where Elasticache exists (Ex- us-east-1): ' region
read -p 'Enter Instance name (Ex- instance-a): ' instance_name
echo ""
REGION=$region
echo ""
echo "You have selected $region region and instance name is $instance_name"
echo ""
elasticache_host=`aws ssm get-parameter --region $region --name /${instance_name}/acentrik/core/redis/1/host --with-decryption | jq -r ".Parameter.Value"`
elasticache_auth_token=`aws ssm get-parameter --region $region --name /${instance_name}/acentrik/core/redis/1/auth-token --with-decryption | jq -r ".Parameter.Value"`
redis-cli -h $elasticache_host -p 6379 --tls -a $elasticache_auth_token