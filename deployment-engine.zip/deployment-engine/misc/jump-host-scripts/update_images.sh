aws ecr get-login-password --region ap-southeast-1 | docker login --username AWS --password-stdin 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com
docker pull 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/notification:nagarro-qa-latest
docker pull 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/user-management:nagarro-qa-latest
docker pull 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/asset-management:nagarro-qa-latest
docker pull 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/provider-management:nagarro-qa-latest
docker pull 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-management:nagarro-qa-latest
docker pull 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-portal:nagarro-qa-latest
docker pull 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/market:nagarro-qa-latest
echo "Images Pulled. Tagging them"


docker tag 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/asset-management:nagarro-qa-latest  540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/asset-management:v1-latest
docker tag 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-management:nagarro-qa-latest  540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-management:v1-latest
docker tag 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-portal:nagarro-qa-latest  540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-portal:v1-latest
docker tag 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/notification:nagarro-qa-latest  540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/notification:v1-latest
docker tag 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/provider-management:nagarro-qa-latest  540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/provider-management:v1-latest
docker tag 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/user-management:nagarro-qa-latest  540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/user-management:v1-latest
docker tag 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/market:nagarro-qa-latest 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/market:v1-latest

echo " Images Tagged. Pushing them"

docker push 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/asset-management:v1-latest
docker push 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-management:v1-latest
docker push 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/instance-portal:v1-latest
docker push 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/notification:v1-latest
docker push 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/provider-management:v1-latest
docker push 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/user-management:v1-latest
docker push 540306422608.dkr.ecr.ap-southeast-1.amazonaws.com/market:v1-latest