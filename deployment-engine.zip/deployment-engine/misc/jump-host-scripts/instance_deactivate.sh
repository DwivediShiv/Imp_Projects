#!/bin/bash
echo ""
region=; until [[ $region ]]; do read -p 'Enter Cluster region to deactivate instance in (Ex- ap-southeast-1): ' region ; done
region=$region
instance_name=; until [[ $instance_name ]]; do read -p 'Enter Instance name (Ex- nagarro-dev): ' instance_name ;done
# There will a branch by version number, which will be checked out basis below input
version=; until [[ $version ]]; do read -p 'Enter version number - OPTIONAL (Default - v1): ' version; done
sleep 5
aws codebuild start-build --project-name instance_deactivate --source-version $version --environment-variables-override "[{\"name\":\"region\",\"value\":\"$region\"} , {\"name\":\"instance_name\",\"value\":\"$instance_name\"}]"
echo ""
echo "RUN below command to see the logs"
echo ""
echo "aws logs tail codebuild --follow --log-stream-name-prefix  instance_deactivate --format detailed "
