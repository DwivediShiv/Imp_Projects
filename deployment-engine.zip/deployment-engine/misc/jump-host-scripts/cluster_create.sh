#!/bin/bash
echo ""
region=; until [[ $region ]]; do read -p 'Enter Cluster region to create cluster in (Ex- ap-southeast-1): ' region ; done
network=; until [[ $network ]]; do read -p 'Enter Subgraph network : ' network ; done
# There will a branch by version number, which will be checked out basis below input
version=; until [[ $version ]]; do read -p 'Enter version number ' version ; done
echo ""
sleep 5
echo ""
aws codebuild start-build --project-name cluster_create --source-version $version --environment-variables-override "[{\"name\":\"region\",\"value\":\"$region\"},{\"name\":\"network\",\"value\":\"$network\"}]"
echo ""
echo "RUN below command to see the logs"
echo ""
echo "aws logs tail codebuild --follow --log-stream-name-prefix  cluster_create --format detailed "
