#!/bin/bash
echo ""
read -p 'Enter Cluster Region (Ex- us-east-1): ' region
echo ""
region=$region
echo ""
echo "You have selected $region region"
echo ""
ROLE_ARN="arn:aws:iam::115138502786:role/${region}-eks-admin"
aws eks --region ${region} update-kubeconfig --name ${region}-eks --role-arn $ROLE_ARN
echo ""
echo "Please see below cluster information"
echo ""
kubectl cluster-info
echo ""
echo "Please see below cluster context"
echo ""
kubectl config current-context
echo ""
echo "PROCEED WITH CAUTION !"
echo ""
echo "VALIDATE above cluster info and the context to see which cluster you are connected to"
echo ""
