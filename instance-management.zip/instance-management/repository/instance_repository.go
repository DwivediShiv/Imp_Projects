package repository

import (
	"instance-management/models"

	"gorm.io/gorm"
)

type InstanceRepository interface {
	GetLatestInstanceBuild() (*models.InstanceBuilds, error)
	AddInstanceBuild(buildID, createdBy string) error
	UpdateInstanceBuildStatus(buildID uint, status, remarks string) error
}

const (
	IStatusStarted   = "Started"
	IStatusFailed    = "Failed"
	IStatusCompleted = "Completed"
)

func NewInstanceRepository(db *gorm.DB) InstanceRepository {
	return &instanceRepository{
		db: db,
	}
}

type instanceRepository struct {
	db *gorm.DB
}

func (ir *instanceRepository) AddInstanceBuild(buildID, createdBy string) error {
	ib := models.InstanceBuilds{BuildID: buildID, CreatedBy: createdBy, BuildStatus: IStatusStarted}
	return ir.db.Create(&ib).Error
}

func (ir *instanceRepository) GetLatestInstanceBuild() (*models.InstanceBuilds, error) {
	var latestRecord models.InstanceBuilds
	if err := ir.db.Order("created_at desc").Limit(1).First(&latestRecord).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, nil
		}
		return nil, err
	}
	return &latestRecord, nil
}

func (ir *instanceRepository) UpdateInstanceBuildStatus(id uint, status, remarks string) error {
	tx := ir.db.Table("instance_builds").Where("id = ?", id).UpdateColumn("build_status", status)
	if remarks != "" {
		tx.UpdateColumn("remarks", remarks)
	}
	return tx.Error
}
