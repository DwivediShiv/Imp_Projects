package repository

import (
	"instance-management/models"

	"gorm.io/gorm"
)

type InstanceUserRepository interface {
	IsEmailPresentInDB(email string) (bool, error)
	SaveInstanceUser(newUserData models.InstanceUserProfile) error
	GetUserDetailsFromDB(email string, model interface{}) error
	UpdateInstanceUserState(userReqEmail string, instanceUserProfile models.InstanceUserProfile) error
}

func NewInstanceUserRepository(db *gorm.DB) InstanceUserRepository {
	return instanceUserRepository{
		userDb: db,
	}
}

type instanceUserRepository struct {
	userDb *gorm.DB
}

func (i instanceUserRepository) IsEmailPresentInDB(email string) (bool, error) {
	var count int64
	err := i.userDb.Table("instance_user_invitation as iui").Where("iui.email = ?", email).Count(&count).Error

	return count > 0, err
}

func (i instanceUserRepository) SaveInstanceUser(newUserData models.InstanceUserProfile) error {
	err := i.userDb.Transaction(func(tx *gorm.DB) error {
		err := i.userDb.Table("instance_user_invitation").Create(&newUserData).Error
		return err
	})
	return err
}

func (i instanceUserRepository) GetUserDetailsFromDB(email string, model interface{}) error {
	userProfileTxn := i.userDb.Table("instance_user_invitation as iui").Select("*").Where("iui.email = ?", email)
	rows, err := userProfileTxn.Rows()

	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		userProfileTxn.ScanRows(rows, model)
	}

	return nil
}

func (i instanceUserRepository) UpdateInstanceUserState(userReqEmail string, instanceUserProfile models.InstanceUserProfile) error {
	err := i.userDb.Table("instance_user_invitation").
		Where("email = ?", userReqEmail).
		UpdateColumns(&instanceUserProfile).Error

	if err != nil {
		return err
	}
	return nil
}
