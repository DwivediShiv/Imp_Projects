package repository

import (
	"instance-management/models/keycloak"
	"strings"

	"gorm.io/gorm"
)

type KeycloakRepository interface {
	IfUserExists(email string) (*keycloak.KeyCloakUserEntity, error)
	GetRealmNameByUsername(username string) (string, error)
}

func NewKeycloakRepository(db *gorm.DB) KeycloakRepository {
	return keycloakRepository{
		keycloakDb: db,
	}
}

type keycloakRepository struct {
	keycloakDb *gorm.DB
}

func (k keycloakRepository) IfUserExists(email string) (*keycloak.KeyCloakUserEntity, error) {
	var userEntity *keycloak.KeyCloakUserEntity
	result := k.keycloakDb.Where("email = ?", email).First(&userEntity)
	if result.Error != nil && strings.Contains(result.Error.Error(), "record not found") {
		return userEntity, nil
	}

	return userEntity, result.Error
}

func (k keycloakRepository) GetRealmNameByUsername(username string) (string, error) {
	var realmName string
	tx := k.keycloakDb.Table("realm r").Joins("INNER JOIN user_entity as ue on ue.realm_id = r.id")
	tx.Where("ue.username = ?", username)
	tx.Select("r.name")
	rows, err := tx.Rows()

	if err != nil {
		return "", err
	}
	defer rows.Close()
	for rows.Next() {
		tx.ScanRows(rows, &realmName)
	}

	return realmName, nil
}
