package router

import (
	"context"
	"instance-management/config"
	_ "instance-management/docs"
	"instance-management/pkg/database"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	swaggerfiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"gorm.io/gorm"
)

//	@title			TODO APIs
//	@version		1.0
//	@description	Testing Swagger APIs.
//	@termsOfService	http://swagger.io/terms/

//	@contact.name	API Support
//	@contact.url	http://www.swagger.io/support
//	@contact.email	support@swagger.io

//	@securityDefinitions.apiKey	JWT
//	@in							header
//	@name						token

//	@license.name	Apache 2.0
//	@license.url	http://www.apache.org/licenses/LICENSE-2.0.html

//	@host		127.0.0.1:8880
//	@BasePath	/api/v1
//	@schemes	http

// API Config Structure
type ApiConfig struct {
	config     *config.Configuration
	router     *gin.Engine
	db         *gorm.DB
	keycloakdb *gorm.DB
}

func Initialize(ctx context.Context, config *config.Configuration) *ApiConfig {
	r := gin.Default()
	// use ginSwagger middleware to serve the API docs
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerfiles.Handler))

	r.ForwardedByClientIP = true

	api := newApiConfig(config, r)

	// initialize routes for the APIs
	PrepareRoutes(api.config, api.router, api.db, api.keycloakdb)

	return api
}

// new return API config instance after setting up the DB
func newApiConfig(config *config.Configuration, router *gin.Engine) *ApiConfig {
	appDB, keyCloakDB := database.SetupPostgresDBs(config)

	return &ApiConfig{
		config:     config,
		router:     router,
		db:         appDB,
		keycloakdb: keyCloakDB,
	}
}

func (api *ApiConfig) ListenAndServe(listenAddr string) error {
	log.Printf("Listen Address : %q\n", listenAddr)
	server := &http.Server{
		Addr:    listenAddr,
		Handler: api.router,
	}

	server.ListenAndServe()

	return nil
}
