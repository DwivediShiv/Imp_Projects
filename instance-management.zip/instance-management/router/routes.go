package router

import (
	"fmt"
	"instance-management/common"
	"instance-management/config"
	"instance-management/controller"
	"instance-management/middleware"
	"instance-management/repository"
	"instance-management/service"

	"github.com/gin-gonic/gin"
	"github.com/robfig/cron/v3"
	"gorm.io/gorm"
)

func PrepareRoutes(config *config.Configuration, router *gin.Engine, userDb, keycloakDb *gorm.DB) error {

	router.Use(middleware.CORS(config.API))

	instanceUserRepository := repository.NewInstanceUserRepository(userDb)
	instanceRepository := repository.NewInstanceRepository(userDb)
	keycloakRepository := repository.NewKeycloakRepository(keycloakDb)
	inviteUserService := service.NewInstanceUserService(instanceUserRepository, keycloakRepository, *config)
	inviteUserController := controller.NewInviteUserController(inviteUserService)
	instanceService := service.NewInstanceService(*config, instanceRepository)
	instanceController := controller.NewInstanceController(instanceService)

	apiGroup := router.Group("/api")
	v1Group := apiGroup.Group("/v1")

	instanceGroup := v1Group.Group("/instance")
	{
		instanceGroup.PUT("/login", inviteUserController.LoginUser)
		instanceGroup.GET("/invited/user-state", inviteUserController.GetUserState)
		instanceGroup.POST("/accept-invitation", inviteUserController.AcceptInvite)
		instanceGroup.GET("/users/:profileId/roles", inviteUserController.GetUserProfileRoles)
		instanceGroup.POST("/access-token", inviteUserController.GenerateAccessToken)

	}

	validateAdminGroup := instanceGroup.Group("")
	{
		// Validate for Admin role
		validateAdminGroup.Use(func(c *gin.Context) {
			middleware.ValidateByRealmRole(c, keycloakDb, config, common.AdminRole)
		})

		//api to invite user via email and save details in instance db
		validateAdminGroup.POST("/invite-user", inviteUserController.InviteUser)

		// version apis
		validateAdminGroup.GET("/version/list", instanceController.VersionList)
		validateAdminGroup.GET("/version/:version/release-note", instanceController.GetReleaseNote)
		validateAdminGroup.GET("/version/:version/config", instanceController.GetVersionConfig)
		validateAdminGroup.PUT("/version/:version/config", instanceController.PutVersionConfig)
		validateAdminGroup.PUT("/theming", instanceController.PutInstanceTheming)
		validateAdminGroup.GET("/version/:version/form-builder", instanceController.GetFormBuilder)
		validateAdminGroup.GET("/version/:version/secrets", instanceController.GetSecrets)
		validateAdminGroup.PUT("/version/:version/secrets", instanceController.PutSecrets)
		validateAdminGroup.POST("/redeploy/:version", instanceController.RedeployInstance)

	}

	createCronJobs(config, instanceService)

	return nil
}

func createCronJobs(config *config.Configuration, instanceService service.InstanceService) {
	c := cron.New()
	c.AddFunc("@every "+config.Instance.SICronJobDuration, instanceService.CheckStartedInstancesStatus)
	c.Start()
	printCronJobEntries(c.Entries())
}

func printCronJobEntries(entries []cron.Entry) {
	fmt.Printf("\nCron Info: %+v\n", entries)
}
