package common

import (
	"errors"
	"net/mail"
	"regexp"
	"strings"
)

// Normalize email (lower_case, trim, parse address)
func NormalizeEmail(email string) (string, error) {
	emailRes := strings.ToLower(email)
	emailRes = strings.TrimSpace(emailRes)
	_, err := mail.ParseAddress(emailRes)
	if err != nil {
		return "", err
	}
	return emailRes, nil
}

func IsEmailValid(emailAddress string) bool {
	emailRegex := regexp.MustCompile(`^(([^/<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$`)
	return emailRegex.MatchString(emailAddress)
}

func ValidatePassword(password string) error {
	match, _ := regexp.MatchString("([a-z])", password)
	if !match {
		return errors.New("NO_LOWERCASE")
	}

	match, _ = regexp.MatchString("([A-Z])", password)
	if !match {
		return errors.New("NO_UPPERCASE")
	}

	match, _ = regexp.MatchString("([0-9])", password)
	if !match {
		return errors.New("NO_NUMBER")
	}

	match, _ = regexp.MatchString("([!@#$%^&*\\]\\[()\\-_+={}'|])", password)
	if !match {
		return errors.New("NO_SPECIAL")
	}

	return nil
}
