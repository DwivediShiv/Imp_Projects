package database

import (
	"fmt"
	"log"
	"strings"

	"instance-management/config"

	"github.com/golang-migrate/migrate/v4"
	_ "github.com/golang-migrate/migrate/v4/database/postgres"
	_ "github.com/golang-migrate/migrate/v4/source/file"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// SetupPostgresDBs - sets up postgres databases
func SetupPostgresDBs(config *config.Configuration) (*gorm.DB, *gorm.DB) {
	appDB := setupAppDB(config.Database.Postgres)
	keyCloakDB := setupKeyCloakDB(config.Database.KeycloakDb)

	return appDB, keyCloakDB
}

// setupAppDB - connect to application's postgres database
func setupAppDB(dbConfig config.PostgresDBConfig) *gorm.DB {
	db, err := newPostgresDBConnection(dbConfig)
	if err != nil {
		panic("Failed to connect to application database!")
	}

	m, err := migrate.New(getPostgresDBMigrationConfig(dbConfig))
	if err != nil {
		log.Fatalf("Database Migrate Error - %s\n", err)
	}

	if err := m.Up(); err != nil {
		log.Printf("Database Migrate Error - %s\n", err)
	}
	return db
}

// setupKeycloakDB - connects to Keycloak postgres database
func setupKeyCloakDB(dbConfig config.PostgresDBConfig) *gorm.DB {
	db, err := newPostgresDBConnection(dbConfig)
	if err != nil {
		panic("Failed to connect to keycloak database!")
	}
	return db
}

// newPostgresDBConnection - sets up new postgres DB instance
func newPostgresDBConnection(dbConfig config.PostgresDBConfig) (*gorm.DB, error) {
	connectionString := fmt.Sprintf("host=%v port=%v user=%v dbname=%v password=%v sslmode=disable", dbConfig.Host, dbConfig.Port, dbConfig.User, dbConfig.DB, dbConfig.Password)
	return gorm.Open(postgres.Open(connectionString), &gorm.Config{})
}

// getPostgresDBMigrationConfig - returns postgres DB migration file path and connection string
func getPostgresDBMigrationConfig(dbConfig config.PostgresDBConfig) (string, string) {
	filePath := "file://database/migrations/"
	connectionString := []string{
		"postgres://",
		dbConfig.User,
		":",
		dbConfig.Password,
		"@",
		dbConfig.Host,
		":",
		dbConfig.Port,
		"/",
		dbConfig.DB,
		"?sslmode=disable",
	}
	return filePath, strings.Join(connectionString, "")
}
