package main

import (
	"context"
	"flag"
	"fmt"
	"instance-management/pkg/config"
	"instance-management/router"
	"log"
	"os"
)

//define Options for command line flags
type Options struct {
	configPath string
	configName string
}

func buildCommandLineFlags() (options Options) {
	flag.StringVar(&options.configPath, "configpath", ".", "config path")
	flag.StringVar(&options.configName, "configname", "config", "config name")
	flag.Set("logtostderr", "true")
	flag.Parse()
	return options
}

func main() {
	options := buildCommandLineFlags()
	log.Printf("[option] config path: %q", options.configPath)
	log.Printf("[option] config name: %q", options.configName)

	// filling the variable with the settings file and env vars
	config, err := config.LoadConfig(options.configPath, options.configName)
	if err != nil {
		panic(err)
	}

	log.Printf("[config] API ListenAddress: %q", config.API.ListenAddress)
	log.Printf("[config] API Port: %q", config.API.Port)

	var ctx context.Context
	apiService := router.Initialize(ctx, &config)
	if err != nil {
		panic(err)
	}

	var listenAddress = fmt.Sprintf("%s:%s", config.API.ListenAddress, config.API.Port)

	err = apiService.ListenAndServe(listenAddress)
	if err != nil {
		fmt.Printf("error starting server: %s\n", err)
		os.Exit(1)
	}
}
