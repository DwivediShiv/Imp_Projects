package middleware

import (
	"fmt"
	"instance-management/config"
	"instance-management/models"
	"instance-management/utils"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
	"gorm.io/gorm"
)

// Middleware for auth token keycloak realm role validation
func ValidateByRealmRole(ctx *gin.Context, keycloakDb *gorm.DB, config *config.Configuration, role string) {
	// Get auth token payload
	tokenPayload := getTokenFromJwtHeader(ctx)
	if tokenPayload.Subject == "" {
		fmt.Println("Unable to fetch user id")
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "User Unauthorized",
			"code": "Error_UnAuthorizedUserAction"})
		return
	}

	userRoles, userRoleErr := utils.FetchUserRoles(ctx, config, tokenPayload.Subject)
	if userRoleErr != nil {
		fmt.Println("Unable to fecth user roles")
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "User Unauthorized",
			"code": "Error_UnAuthorizedUserAction"})
		return
	}

	// Validate if provided role is assigned to user
	if !utils.Contains(userRoles.Roles, role) {
		fmt.Println("Error occured : " + role + " is not assigned to " + tokenPayload.Email)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "User Unauthorized",
			"code": "Error_UnAuthorizedUserAction"})
	}

	if role == config.Role.Admin && !utils.Contains(userRoles.Roles, config.Role.Validated) {
		fmt.Println("Error occured : validated role is not assigned to admin user " + tokenPayload.Email)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "User Unauthorized",
			"code": "Error_UnAuthorizedUserAction"})
	}
}

// get token payload from auth token header
func getTokenFromJwtHeader(c *gin.Context) *models.Claims {
	authHeader := c.GetHeader("Authorization")
	if len(authHeader) == 0 {
		return &models.Claims{}
	}
	tokenString := authHeader[len("Bearer"):]
	tokenString = strings.TrimLeft(tokenString, " ")
	claims := &models.Claims{}
	token, _ := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(""), nil
	})
	return token.Claims.(*models.Claims)
}
