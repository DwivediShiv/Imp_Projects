package middleware

import (
	"instance-management/config"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func CORS(apiConfig config.API) gin.HandlerFunc {
	config := cors.DefaultConfig()

	config.AllowCredentials = true
	config.AllowAllOrigins = false
	config.AllowWildcard = true

	if apiConfig.CORS.AllowOrigins != nil && len(apiConfig.CORS.AllowOrigins) > 0 {
		config.AllowOrigins = apiConfig.CORS.AllowOrigins
	} else {
		config.AllowAllOrigins = true
	}

	config.AllowMethods = []string{"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"}
	config.AllowHeaders = []string{
		"cache-control",
		"Origin",
		"Accept",
		"Content-Type",
		"user-agent",
		"Content-Length",
		"Accept-Encoding",
		"X-CSRF-Token",
		"Authorization",
		"X-Requested-With",
	}

	return cors.New(config)
}
