package config

// Application Configuration
type Configuration struct {
	API
	Info
	Database
	Auth
	Instance
	Role
	AWS
	AWS_S3
}

// API configuration
type API struct {
	ListenAddress string
	Port          string
	CORS          struct {
		AllowOrigins []string
	}
}

// Auth configuration
type Info struct {
	ClientId          string
	Realm             string
	PortalURL         string
	PrivateKeyFile    string
	NotificationURL   string
	UserManagementUrl string
}

// Auth configuration
type Auth struct {
	Host                      string
	AdminUsername             string
	AdminPassword             string
	AdminRealm                string
	AdminClientId             string
	AdminClientSecret         string
	GrantType                 string
	VerificationTokenDuration string
}

// Instance Aws configuration
type Instance struct {
	BasePath             string
	ReleaseNotesFileName string
	VersionFileName      string
	ConfigFileName       string
	FormBuilderFileName  string
	SecretPath           string
	SICronJobDuration    string
	VersionDir           string
}

// Role configuration
type Role struct {
	User      string
	Admin     string
	Validated string
}

type PostgresDBConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	DB       string
}

type AWS_S3 struct {
	Bucket        string
	BucketPrivate string
	BucketShared  string
	URL_Timeout   string
}

type AWS struct {
	Region       string
	SharedRegion string
}

// Database configuration
type Database struct {
	Postgres   PostgresDBConfig
	KeycloakDb PostgresDBConfig
}
