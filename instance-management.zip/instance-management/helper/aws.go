package helper

import (
	"context"
	"encoding/json"
	"fmt"
	cfg "instance-management/config"
	models "instance-management/models"
	"io"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/codebuild"
	"github.com/aws/aws-sdk-go-v2/service/codebuild/types"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	s3Types "github.com/aws/aws-sdk-go-v2/service/s3/types"
	"github.com/aws/aws-sdk-go-v2/service/ssm"
	st "github.com/aws/aws-sdk-go-v2/service/ssm/types"
)

const (
	instanceName = "instance_name"

	instanceCurrentVersion = "instance_version"
)

func createS3Client(cfg1 aws.Config, region string) (*s3.Client, *s3.PresignClient) {
	// Create S3 service client
	svc := s3.NewFromConfig(cfg1)
	presignClient := s3.NewPresignClient(svc)
	return svc, presignClient
}

func GetInstanceBuildStatus(configuration *cfg.Configuration, buildID string) (*types.Build, error) {
	cfg1, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion(configuration.AWS.SharedRegion))
	if err != nil {
		log.Fatalf("Failed to load AWS configuration: %v", err)
	}

	svc := codebuild.NewFromConfig(cfg1)

	input := &codebuild.BatchGetBuildsInput{
		Ids: []string{buildID},
	}
	output, err := svc.BatchGetBuilds(context.TODO(), input)
	if err != nil {
		fmt.Printf("\nGot error getbuild status: %v\nReq: '%s'\n", err, buildID)
		return nil, err
	}

	bnf := output.BuildsNotFound
	if len(bnf) > 0 {
		fmt.Printf("\nBuildsNotFoundError for id '%s' '%d' '%+v'\n", buildID, len(bnf), bnf)
	}

	fmt.Printf("BatchGetBuilds returned for '%s' for with obj count %v\n", buildID, len(output.Builds))
	return &output.Builds[0], nil
}

func RunCreateInstanceCodeBuildPipeline(configuration *cfg.Configuration, req *models.CreateInstanceArgs) (*string, error) {
	cfg1, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion(configuration.AWS.SharedRegion))
	if err != nil {
		log.Fatalf("Failed to load AWS configuration: %v", err)
		return nil, err
	}

	svc := codebuild.NewFromConfig(cfg1)
	var evo []types.EnvironmentVariable

	fmt.Printf("\nrequest to aws method: %+v\n", req)

	if req.CustomDomain != "" {
		evo = []types.EnvironmentVariable{
			{Name: aws.String("region"), Value: aws.String(req.Region)},
			{Name: aws.String("instance_name"), Value: aws.String(req.InstanceName)},
			{Name: aws.String("instance_admin_email"), Value: aws.String(req.InstanceAdminEmail)},
			{Name: aws.String("network"), Value: aws.String(req.Network)},
			{Name: aws.String("token_address"), Value: aws.String(req.TokenAddress)},
			{Name: aws.String("token_symbol"), Value: aws.String(req.TokenSymbol)},
			{Name: aws.String("decimals"), Value: aws.String(req.Decimals)},
			{Name: aws.String("custom_domain"), Value: aws.String(req.CustomDomain)},
			{Name: aws.String("ses_domain"), Value: aws.String(req.SESDomain)},
			{Name: aws.String("ses_domain_exists"), Value: aws.String(req.SESDomainExist)},
		}
	} else {
		evo = []types.EnvironmentVariable{
			{Name: aws.String("region"), Value: aws.String(req.Region)},
			{Name: aws.String("instance_name"), Value: aws.String(req.InstanceName)},
			{Name: aws.String("instance_admin_email"), Value: aws.String(req.InstanceAdminEmail)},
			{Name: aws.String("network"), Value: aws.String(req.Network)},
			{Name: aws.String("token_address"), Value: aws.String(req.TokenAddress)},
			{Name: aws.String("token_symbol"), Value: aws.String(req.TokenSymbol)},
			{Name: aws.String("decimals"), Value: aws.String(req.Decimals)},
		}
	}

	input := &codebuild.StartBuildInput{
		ProjectName:                  aws.String("instance_create"),
		EnvironmentVariablesOverride: evo,
		SourceVersion:                &req.Version,
	}
	output, err := svc.StartBuild(context.TODO(), input)
	if err != nil {
		fmt.Printf("\nGot error building create instance pipeline: %v\nReq: '%s' '%s' '%s'\n", err, req.InstanceName, req.Region, req.CustomDomain)
		return nil, err
	}

	fmt.Printf("Started build for project 'create_instance' with build obj: %+v\n", output)
	return output.Build.Id, nil
}

func GetVersionInfoFromS3(configuration *cfg.Configuration) (models.VersionInfo, error) {
	fn := configuration.Instance.BasePath + configuration.Instance.VersionDir + "/" + configuration.Instance.VersionFileName
	str, err := GetfileFromS3(configuration, configuration.AWS_S3.BucketShared, fn, configuration.SharedRegion)
	if err != nil {
		log.Printf("error in reading object from s3: %v", err)
		return nil, err
	}

	var obj models.VersionInfo
	if err = json.Unmarshal([]byte(str), &obj); err != nil {
		log.Printf("error in unmarshalling s3 object: %v", err)
		return nil, err
	}

	return obj, err
}

func GetReleaseNotesFromS3(configuration *cfg.Configuration, releaseVersion string) (string, error) {
	fn := configuration.Instance.BasePath + releaseVersion + "/" + configuration.Instance.ReleaseNotesFileName
	return GetfileFromS3(configuration, configuration.AWS_S3.BucketShared, fn, configuration.SharedRegion)
}

func GetVersionConfigurationFromS3Private(configuration *cfg.Configuration, releaseVersion string) (string, error) {
	fn := configuration.Instance.BasePath + releaseVersion + "/" + configuration.Instance.ConfigFileName

	content, err := GetfileFromS3(configuration, configuration.AWS_S3.BucketPrivate, fn, configuration.Region)
	if content == "" || err != nil {
		fmt.Printf("\nGetVersionConfigurationFromS3Private err: '%v' content: '%s'  currentinstanceVersion: '%s' \n", err, content, os.Getenv(instanceCurrentVersion))

		// get active version config
		fname := os.Getenv(instanceCurrentVersion)
		fn := configuration.Instance.BasePath + fname + "/" + configuration.Instance.ConfigFileName
		content, err = GetfileFromS3(configuration, configuration.AWS_S3.BucketPrivate, fn, configuration.Region)
	}
	fmt.Printf("\nGetVersionConfigurationFromS3Private  end err: '%v' content: '%s'  currentinstanceVersion: '%s' \n", err, content, os.Getenv(instanceCurrentVersion))

	return content, err
}

func GetVersionSSMParam(Configuration *cfg.Configuration, releaseVersion string) (string, error) {
	val, err := GetSSMParam(Configuration, releaseVersion)
	if err != nil || val == "" {
		fmt.Printf("\nGetVersionSSMParam err: '%v' val: '%s' currentinstanceVersion: '%s'  \n", err, val, os.Getenv(instanceCurrentVersion))
		val, err = GetSSMParam(Configuration, os.Getenv(instanceCurrentVersion))
	}
	fmt.Printf("\nGetVersionSSMParam end err: '%v' val: '%s' currentinstanceVersion: '%s' \n", err, val, os.Getenv(instanceCurrentVersion))

	return val, err
}

func GetFormBuilderFromS3shared(configuration *cfg.Configuration, releaseVersion string) (string, error) {
	fn := configuration.Instance.BasePath + releaseVersion + "/" + configuration.Instance.FormBuilderFileName
	return GetfileFromS3(configuration, configuration.AWS_S3.BucketShared, fn, configuration.SharedRegion)
}

func SaveConfigToS3Private(configuration *cfg.Configuration, releaseVersion string, file io.Reader) error {
	fn := configuration.Instance.BasePath + releaseVersion + "/" + configuration.Instance.ConfigFileName
	return PutFileIntoS3(configuration, configuration.AWS_S3.BucketPrivate, fn, file, false)
}

func SaveImageToS3Private(configuration *cfg.Configuration, file io.Reader, fileName string) error {
	fn := "instance/custom/" + fileName
	return PutFileIntoS3(configuration, configuration.AWS_S3.Bucket, fn, file, true)
}

func GetfileFromS3(configuration *cfg.Configuration, bucketName, fileName, region string) (string, error) {
	cfg1, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion(region))
	if err != nil {
		log.Printf("error in creating cfg for aws for '%s' region: %v", err, region)
		return "", err
	}

	s3Client, _ := createS3Client(cfg1, configuration.AWS.Region)

	requestInput := &s3.GetObjectInput{
		Bucket: aws.String(bucketName),
		Key:    aws.String(fileName),
	}

	result, err := s3Client.GetObject(context.TODO(), requestInput)
	if err != nil {
		log.Printf("error in getting object from s3: %v", err)
		return "", err
	}
	defer result.Body.Close()

	// capture all bytes from upload
	content, err := ioutil.ReadAll(result.Body)
	if err != nil {
		log.Printf("error in reading object from s3: %v", err)
		return "", err
	}

	return string(content), err
}

// getContentType maps file extensions to content types
func getContentType(fileExtension string) string {
	switch fileExtension {
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".css":
		return "text/css"
	case ".yaml", ".yml":
		return "application/x-yaml"
	case ".png":
		return "image/png"
	case ".gif":
		return "image/gif"
	case ".pdf":
		return "application/pdf"
	case ".json":
		return "application/json"
	case ".svg":
		return "image/svg+xml"
	default:
		return "application/octet-stream" // Default content type
	}
}

func PutFileIntoS3(configuration *cfg.Configuration, bucketName, fileName string, file io.Reader, ispublic bool) error {
	cfg1, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion(configuration.AWS.Region))
	if err != nil {
		log.Printf("error in creating cfg for aws for '%s' region: %v", err, configuration.AWS.Region)
		return err
	}

	s3Client, _ := createS3Client(cfg1, configuration.AWS.Region)
	fileExtension := filepath.Ext(fileName)
	contentType := getContentType(fileExtension)
	var fileKey string

	// Check for image files and exclude extension from filename key
	if strings.Contains(contentType, "image") {
		fileKey = *aws.String(strings.Split(fileName, ".")[0])
	} else {
		fileKey = *aws.String(fileName)
	}

	requestInput := &s3.PutObjectInput{
		Bucket:      aws.String(bucketName),
		Key:         &fileKey,
		Body:        file,
		ContentType: &contentType,
	}

	if ispublic {
		requestInput.ACL = s3Types.ObjectCannedACLPublicRead
	}

	_, err = s3Client.PutObject(context.TODO(), requestInput)
	if err != nil {
		log.Printf("error in putting object into ssm: %v", err)
		return err
	}

	return err
}

func GetSSMParam(configuration *cfg.Configuration, version string) (string, error) {
	cfg1, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion(configuration.AWS.Region))
	if err != nil {
		log.Printf("error in creating cfg for aws for '%s' region: %v", err, configuration.AWS.Region)
		return "", err
	}

	ssmClient := ssm.NewFromConfig(cfg1)
	name := fmt.Sprintf("/%s%s:%s", os.Getenv(instanceName), configuration.SecretPath, version)

	requestInput := &ssm.GetParameterInput{
		Name:           aws.String(name),
		WithDecryption: aws.Bool(true),
	}

	output, err := ssmClient.GetParameter(context.TODO(), requestInput)
	if err != nil {
		log.Printf("error in putting object into ssm: %v", err)
		return "", err
	}

	return *output.Parameter.Value, err
}

func PutSSMParam(configuration *cfg.Configuration, version, paramValue string) error {
	cfg1, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion(configuration.AWS.Region))
	if err != nil {
		log.Printf("error in creating cfg for aws for '%s' region: %v", err, configuration.AWS.Region)
		return err
	}

	name := fmt.Sprintf("/%s%s", os.Getenv(instanceName), configuration.SecretPath)
	fmt.Println(name)
	ssmClient := ssm.NewFromConfig(cfg1)

	// get history for kms key
	requestInput := &ssm.GetParameterHistoryInput{
		Name:           aws.String(name),
		WithDecryption: aws.Bool(true),
	}

	output, err := ssmClient.GetParameterHistory(context.TODO(), requestInput)
	if err != nil {
		log.Printf("error in putting object into ssm: %v", err)
		return err
	}

	kmsKey := output.Parameters[0].KeyId

	input := &ssm.PutParameterInput{
		Name:      aws.String(name),
		Value:     aws.String(paramValue),
		Type:      st.ParameterTypeSecureString,
		KeyId:     kmsKey,
		Overwrite: aws.Bool(true),
	}

	_, err = ssmClient.PutParameter(context.TODO(), input)
	if err != nil {
		log.Printf("error in putting object into ssm: %v", err)
		return err
	}

	// Add a label to the parameter using AddTagsToResource
	addTagsInput := &ssm.LabelParameterVersionInput{
		Name:   &name,
		Labels: []string{version},
	}

	_, err = ssmClient.LabelParameterVersion(context.TODO(), addTagsInput)
	if err != nil {
		log.Printf("error in putting version into ssm: %v", err)
		return err
	}

	return err
}
