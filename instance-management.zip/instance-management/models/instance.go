package models

import (
	"time"
)

type InstanceBuilds struct {
	ID            uint `gorm:"primarykey;autoIncrementIncrement"`
	CreatedBy     string
	CreatedAt     time.Time
	UpdatedAt     time.Time
	BuildStatus   string
	BuildID       string
	RebuildStatus string
	RebuildID     string
	Remarks       string
}
