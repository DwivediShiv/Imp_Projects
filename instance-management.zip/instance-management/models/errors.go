package models

type ErrorDetail struct {
	Message        string      `json:"message"`
	AdditionalData interface{} `json:"additionalData,omitempty"`
}

type ErrorResponse struct {
	ResponseCode int         `json:"-"`
	Error        ErrorDetail `json:"error"`
	Code         string      `json:"code"`
	StackTrace   *string     `json:"stackTrace,omitempty"`
}
