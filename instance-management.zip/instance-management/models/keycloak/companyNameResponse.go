package keycloak

type UserAttribute struct {
	CompanyName []string `json:"COMPANY_NAME"`
	FirstName   []string `json:"firstName"`
	LastName    []string `json:"lastName"`
	LastLogin   []string `json:"LAST_LOGIN"`
	LoginCount  []string `json:"LOGIN_COUNT"`
	Email       []string `json:"email"`
	UserName    []string `json:"username"`
	Country     []string `json:"country"`
}

type User struct {
	Id             string        `json:"Id"`
	UserAttributes UserAttribute `json:"userAttributes"`
}

type CompanyNameResponse struct {
	WalletId string `json:"walletId"`
	Users    []User `json:"users"`
}
