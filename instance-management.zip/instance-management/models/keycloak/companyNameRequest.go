package keycloak

type CompanyNameRequest struct {
	WalletId []string `json:"walletList"`
}

type ActivateAccountRequest struct {
	ActivationCode string `json:"activationCode"`
	Password       string `json:"password"`
}
