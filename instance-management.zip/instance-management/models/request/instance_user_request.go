package request

type InviteUserRequest struct {
	Email  string    `json:"email" binding:"required"`
	Roles  *[]string `json:"roles" binding:"required,min=1"`
	Remark string    `json:"remark"`
}

type AcceptInviteRequest struct {
	Password string `json:"password" binding:"required,min=12"`
}

type UserLoginRequest struct {
	Email    string `json:"email" binding:"required"`
	Password string `json:"password" binding:"required"`
}

type SecretsPutRequest struct {
	Message string `json:"message" binding:"required"`
}
