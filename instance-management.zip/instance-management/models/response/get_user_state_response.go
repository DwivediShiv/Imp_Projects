package response

import "time"

type GetUserStateResponse struct {
	Data UserStateResponse `json:"data"`
}
type UserStateResponse struct {
	ID              int       `json:"id" gorm:"primary_key;autoIncrementIncrement"`
	UserAcceptDate  time.Time `json:"userAcceptDate"`
	UserInviteDate  time.Time `json:"userInviteDate"`
	Email           string    `json:"email"`
	AllowedRoles    string    `json:"allowedRoles"`
	ProfileId       string    `json:"profileId"`
	State           string    `json:"state"`
	Remark          string    `json:"remark"`
	CreatedDate     time.Time `json:"createdDate"`
	CreatedBy       string    `json:"createdBy"`
	LastUpdatedDate time.Time `json:"lastUpdateDate"`
	LastUpdatedBy   string    `json:"lastUpdatedBy"`
}
