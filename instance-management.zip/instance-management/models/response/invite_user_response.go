package response

type InviteUserResponse struct {
	Status string `json:"status"`
}

type AcceptInviteResponse struct {
	Status string `json:"status"`
}

type LoginUserResponse struct {
	Data LoginResp `json:"data"`
}

type LoginResp struct {
	AccessToken      string `json:"access_token"`
	TokenType        string `json:"token_type"`
	ExpiresIn        int    `json:"expires_in"`
	RefreshToken     string `json:"refresh_token"`
	RefreshExpiresIn int    `json:"refresh_expires_in"`
	Scope            string `json:"scope"`
}
