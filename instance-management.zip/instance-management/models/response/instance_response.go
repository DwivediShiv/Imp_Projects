package response

type VersionListResponse struct {
	Data []VersionDetail `json:"data"`
}

type VersionDetail struct {
	Version     string
	Description string
}

type ReleaseNoteResponse struct {
	Data string `json:"data"`
}
