package models

type VersionInfo []struct {
	Version     string `json:"version"`
	ReleaseNote string `json:"releaseNote"`
	Description string `json:"description"`
}

type CreateInstanceArgs struct {
	Version            string
	Region             string
	InstanceName       string
	InstanceAdminEmail string
	Network            string
	TokenAddress       string
	TokenSymbol        string
	Decimals           string
	// optional below
	CustomDomain   string
	SESDomainExist string
	SESDomain      string
}
