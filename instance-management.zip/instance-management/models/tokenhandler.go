package models

import "crypto/rsa"

type TokenHandler struct {
	PrivateKey *rsa.PrivateKey
}
