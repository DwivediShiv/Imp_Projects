# instance-management
Instance Management Service

---
- [instance-management](#instance-management)
  - [Prerequisites](#prerequisites)
  - [Starting the server locally](#starting-the-server-locally)
    - [Quick start](#quick-start)
  - [Generate Swagger File](#generate-swagger.yaml-file)
---

## Prerequisites

You need the following toolset ready:
- [Go](https://golang.org/doc/install)

## Starting the server locally

To start the server locally. Just run
```bash
  go run main.go -configpath ./ -configname config
```
Or, you can run 
```bash
go build
```
and then run 
```bash
 ./instance-management.exe
```

If you still see any errors, please check the path of migration scripts in db setup if you are working on windows.
You need to change it in local.
Before running the above commands, check for any value you need to modify for local setup in config.yaml

### Quick start
```bash
git clone git@git.i.mercedes-benz.com:acentrik/instance-management.git

cd instance-management

make run
```
This will run the current default versions of instance-service with port 8880. If you prefer to use other port do modify config.yaml accordingly.

Command Line Parameters
| Field    | Type | Description                    |
| ----------- | ------------- | ---------------------
| `configpath` | `string`        | The application config file path
| `configname` | `string`        | The application config file name

---

## Generate Swagger.yaml file
Swagger has been generated for all the APIs in docs folder
After creating any new API, do add the swagger comments above the controller method and run
```bash
swag init
```