package service

import (
	"fmt"
	"instance-management/common"
	"instance-management/config"
	"instance-management/helper"
	"instance-management/models"
	"instance-management/models/response"
	"instance-management/repository"
	"io"
	"log"
	"os"

	"github.com/aws/aws-sdk-go-v2/service/codebuild/types"
)

type instanceService struct {
	config config.Configuration
	ir     repository.InstanceRepository
}

type InstanceService interface {
	GetVersionList() (*response.VersionListResponse, *models.ErrorResponse)
	GetReleaseNote(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse)
	GetVersionConfig(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse)
	PutVersionConfig(version string, file io.Reader) *models.ErrorResponse
	PutInstanceTheming(file io.Reader, fileName string) *models.ErrorResponse
	GetFormBuilder(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse)
	GetVersionSecrets(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse)
	PutVersionSecrets(version, value string) *models.ErrorResponse
	RedeployInstance(createdBy string, version string) *models.ErrorResponse
	CheckStartedInstancesStatus()
}

func NewInstanceService(config config.Configuration, ir repository.InstanceRepository) InstanceService {
	return &instanceService{
		config: config,
		ir:     ir,
	}
}

func (is *instanceService) GetVersionList() (*response.VersionListResponse, *models.ErrorResponse) {
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	var list []response.VersionDetail
	for _, v := range versions {
		versionDetails := response.VersionDetail{
			Version:     v.Version,
			Description: v.Description,
		}
		list = append(list, versionDetails)
	}
	return &response.VersionListResponse{Data: list}, nil
}

func (is *instanceService) GetReleaseNote(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse) {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return nil, &err1
	}

	// get release note from s3
	releaseNote, err := helper.GetReleaseNotesFromS3(&is.config, version)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	return &response.ReleaseNoteResponse{Data: releaseNote}, nil
}

func (is *instanceService) GetVersionConfig(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse) {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return nil, &err1
	}

	// get from s3
	versionConfig, err := helper.GetVersionConfigurationFromS3Private(&is.config, version)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	return &response.ReleaseNoteResponse{Data: versionConfig}, nil
}

func (is *instanceService) PutVersionConfig(version string, file io.Reader) *models.ErrorResponse {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return &err1
	}

	// put into s3
	err = helper.SaveConfigToS3Private(&is.config, version, file)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	return nil
}

func (is *instanceService) PutInstanceTheming(file io.Reader, fileName string) *models.ErrorResponse {

	// put into s3
	err := helper.SaveImageToS3Private(&is.config, file, fileName)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	return nil
}

func (is *instanceService) GetVersionSecrets(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse) {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return nil, &err1
	}

	// get from ssm
	secrets, err := helper.GetVersionSSMParam(&is.config, version)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	return &response.ReleaseNoteResponse{Data: secrets}, nil
}

func (is *instanceService) PutVersionSecrets(version string, value string) *models.ErrorResponse {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return &err1
	}

	// put into s3
	err = helper.PutSSMParam(&is.config, version, value)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	return nil
}

func (is *instanceService) GetFormBuilder(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse) {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return nil, &err1
	}

	// get from s3
	releaseNote, err := helper.GetFormBuilderFromS3shared(&is.config, version)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	return &response.ReleaseNoteResponse{Data: releaseNote}, nil
}

func (is *instanceService) RedeployInstance(createdBy string, version string) *models.ErrorResponse {
	latest, err := is.ir.GetLatestInstanceBuild()
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	if latest != nil && latest.BuildStatus == repository.IStatusStarted {
		err1 := common.InfoDeploymentInProgress
		err1.Error.AdditionalData = "Previous deployment is in progress, please wait for sometime."
		return &err1
	}

	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return &err1
	}

	req := &models.CreateInstanceArgs{
		Version:            version,
		InstanceName:       os.Getenv("instance_name"),
		Region:             os.Getenv("instance_region"),
		InstanceAdminEmail: os.Getenv("instance_admin_email"),
		Network:            os.Getenv("instance_network"),
		TokenAddress:       os.Getenv("instance_token_address"),
		TokenSymbol:        os.Getenv("instance_token_symbol"),
		CustomDomain:       os.Getenv("instance_custom_domain"),
		Decimals:           os.Getenv("instance_decimals"),
		SESDomain:          os.Getenv("instance_ses_domain"),
		SESDomainExist:     "True",
	}
	bID, err := helper.RunCreateInstanceCodeBuildPipeline(&is.config, req)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	if err = is.ir.AddInstanceBuild(*bID, createdBy); err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	return nil
}

func (is *instanceService) CheckStartedInstancesStatus() {
	fmt.Println("Checking latest instance if it is Started!")
	latest, err := is.ir.GetLatestInstanceBuild()
	if err != nil || latest == nil {
		fmt.Printf("CheckStartedInstancesStatus got error in getting instances: %v", err)
		return
	}

	if latest.BuildStatus != repository.IStatusStarted {
		fmt.Printf("CheckStartedInstancesStatus no started latest instance: %+v", latest.BuildStatus)
		return
	}

	// check build status and update status accordingly
	build, err := helper.GetInstanceBuildStatus(&is.config, latest.BuildID)
	if err != nil {
		fmt.Printf("CheckStartedInstancesStatus error in getting codebuild status %s instance", latest.BuildID)
		return
	}

	switch bs := build.BuildStatus; bs {
	case types.StatusTypeInProgress:
		log.Printf("Started Build '%s' is still in progress hence waiting for some time!\n", latest.BuildID)
		return
	case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
		remarks := fmt.Sprintf("%s\nStarted build failed with status '%s'", latest.Remarks, bs)
		if err := is.ir.UpdateInstanceBuildStatus(latest.ID, repository.IStatusFailed, remarks); err != nil {
			log.Printf("Started Build '%d' is Failed but error in updating success status '%s' from aws '%v'\n", latest.ID, latest.BuildID, err)
		}
		return
	case types.StatusTypeSucceeded:
		fmt.Printf("Started Build '%v' '%s' is Succeeded", latest.ID, latest.BuildID)
		remarks := fmt.Sprintf("%s\nStarted build passed with status '%s'", latest.Remarks, bs)
		if err := is.ir.UpdateInstanceBuildStatus(latest.ID, repository.IStatusCompleted, remarks); err != nil {
			log.Printf("Started Build '%d' is Succeeded but error in updating success status '%v' from aws '%v'\n", latest.ID, latest.BuildID, err)
		}
		return
	default:
		fmt.Printf("Build status for '%d' with id '%s' is unknown '%s'. Please check!\n", latest.ID, latest.BuildID, bs)
	}
}

func versionInVersionArray(str string, arr models.VersionInfo) bool {
	for _, v := range arr {
		if v.Version == str {
			return true
		}
	}
	return false
}
