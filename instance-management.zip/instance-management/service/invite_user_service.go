package service

import (
	"fmt"
	"instance-management/common"
	"instance-management/config"
	"instance-management/models"
	"instance-management/models/request"
	"instance-management/models/response"
	"instance-management/repository"
	"instance-management/utils"
	"log"
	"net/url"
	"strings"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
)

type inviteUserService struct {
	instanceUserRepo repository.InstanceUserRepository
	keycloakRepo     repository.KeycloakRepository
	config           config.Configuration
}

type InviteUserService interface {
	InviteUser(ctx *gin.Context, apiReq request.InviteUserRequest, newUserEmail string, tokenPayload *models.Claims) (response.InviteUserResponse, *models.ErrorResponse)
	AcceptInvite(ctx *gin.Context, actionToken, password string) (response.AcceptInviteResponse, *models.ErrorResponse)
	LoginUser(ctx *gin.Context, userEmail string, requestInput request.UserLoginRequest) (response.LoginUserResponse, *models.ErrorResponse)
	GetUserState(ctx *gin.Context, actionToken string) (response.GetUserStateResponse, *models.ErrorResponse)
	GetProfileRoles(ctx *gin.Context, profileId string) (response.GetUserProfileRolesResp, *models.ErrorResponse)
	GenerateAccessToken(ctx *gin.Context, res models.JWT) (response.LoginUserResponse, *models.ErrorResponse)
}

func NewInstanceUserService(instanceUser repository.InstanceUserRepository,
	keycloakRepo repository.KeycloakRepository, config config.Configuration) InviteUserService {
	return inviteUserService{
		instanceUserRepo: instanceUser,
		keycloakRepo:     keycloakRepo,
		config:           config,
	}
}

func (i inviteUserService) InviteUser(ctx *gin.Context, apiReq request.InviteUserRequest, newUserEmail string, tokenPayload *models.Claims) (response.InviteUserResponse, *models.ErrorResponse) {
	// Check email is present in db
	isEmailPresent, emailErr := i.instanceUserRepo.IsEmailPresentInDB(newUserEmail)
	if emailErr != nil {
		log.Printf("Error while Getting data from DB. Err:: %s", emailErr.Error())
		return response.InviteUserResponse{}, &common.ErrorDBFailed
	}
	if isEmailPresent {
		errMsg := fmt.Sprintf("User already invited: %s", newUserEmail)
		err := common.ErrorEmailExists
		err.Error.AdditionalData = errMsg
		return response.InviteUserResponse{}, &err
	}

	// Comma seperated roles from req input roles
	alloweRoles := strings.Join(*apiReq.Roles, ",")

	// Capitalize or sentence casing for user roles
	roles := utils.CapitalizeWords(alloweRoles)

	// Add new user details in db
	newUserData := models.InstanceUserProfile{}
	newUserData.Email = newUserEmail
	newUserData.UserInviteDate = time.Now()
	newUserData.AllowedRoles = roles
	newUserData.State = common.InvitedState
	newUserData.Remark = apiReq.Remark
	newUserData.CreatedBy = tokenPayload.Email
	newUserData.LastUpdatedBy = tokenPayload.Email

	createErr := i.instanceUserRepo.SaveInstanceUser(newUserData)
	if createErr != nil {
		log.Printf("Error while Adding New Instance User to the DB. Err:: %s", createErr.Error())
		return response.InviteUserResponse{}, &common.ErrorDBFailed
	}

	// Send email with invitation link
	if err := sendInvitationEmail(ctx, i.config, newUserEmail, tokenPayload.Email, "REALM"); err != nil {
		// log.Printf("Send Inviation Email err: %s", err.Error())
		return response.InviteUserResponse{}, &common.ErrorSendNotificationFailed
	}

	return response.InviteUserResponse{Status: "Successfully sent the invitation"}, nil
}

func (i inviteUserService) AcceptInvite(ctx *gin.Context, actionToken, password string) (response.AcceptInviteResponse, *models.ErrorResponse) {
	var resp response.AcceptInviteResponse
	email, tokenErr := i.verifyToken(ctx, actionToken)
	if tokenErr != nil {
		return resp, tokenErr
	}

	realm := i.config.Info.Realm
	client, admintoken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("AcceptInvite loginAdmin error. Err:: %s", err.Error())
		return resp, &common.ErrorServiceFailed
	}

	// Add user to keycloak
	userId, addUserErr := i.addNewKeycloakUser(ctx, client, admintoken, email, realm, password)
	if addUserErr != nil {
		log.Printf("Error occured while creating a new user in keycloak: %s", email)
		return resp, addUserErr
	}

	log.Printf("New user %v created in %v organization.Keycloak UserID %v", email, realm, userId)

	resp.Status = "password updated successfully"
	return resp, nil
}

// Add a User to keycloak
func (i inviteUserService) addNewKeycloakUser(ctx *gin.Context, client *gocloak.GoCloak, adminToken *gocloak.JWT, email string, realm string, password string) (string, *models.ErrorResponse) {
	var keycloakUserId string
	attrWalletRolesToAdd := []string{}
	instanceUserProfile := models.InstanceUserProfile{}

	// Get user details from db (user_invitation)
	userDetailsErr := i.instanceUserRepo.GetUserDetailsFromDB(email, &instanceUserProfile)
	if userDetailsErr != nil {
		log.Printf("GetUserDetailsFromDB error. Err:: %s", userDetailsErr.Error())
		return keycloakUserId, &common.ErrorDBFailed
	}

	// Filter realm roles from allowed roles
	allRoles := strings.Split(instanceUserProfile.AllowedRoles, ",")
	for _, attrRole := range allRoles {
		if strings.ToLower(attrRole) != common.AdminRole && strings.ToLower(attrRole) != common.ViewerRole {
			attrWalletRolesToAdd = append(attrWalletRolesToAdd, strings.ToLower(attrRole))
		}
	}

	// Credentials to be set, passed by user
	var credentials = []gocloak.CredentialRepresentation{
		{
			Type:      gocloak.StringP("password"),
			Temporary: gocloak.BoolP(false),
			Value:     gocloak.StringP(password),
		},
	}

	// Add user db details to keycloak attributes
	attributes := map[string][]string{
		common.INVITATION_ACCEPTED_ON: {time.Now().Format(time.RFC3339)},
		common.CREATED_BY:             {instanceUserProfile.CreatedBy},
		common.CREATED_DATE:           {instanceUserProfile.CreatedDate.Format(time.RFC3339)},
		common.UPDATED_BY:             {instanceUserProfile.LastUpdatedBy},
		common.UPDATE_DATE:            {time.Now().Format(time.RFC3339)},
		common.STATE:                  {common.AcceptedState},
		common.WALLET_ROLES:           {strings.Join(attrWalletRolesToAdd, ",")},
	}

	// Configure keycloak related properties
	keycloakUser := gocloak.User{
		Email:           gocloak.StringP(email),
		Enabled:         gocloak.BoolP(true),
		Username:        gocloak.StringP(email),
		EmailVerified:   gocloak.BoolP(true),
		RequiredActions: &[]string{""},
		Credentials:     &credentials,
		Attributes:      &attributes,
	}

	// Add new user to keycloak
	keycloakUserId, createUserError := client.CreateUser(ctx, adminToken.AccessToken, realm, keycloakUser)
	if createUserError != nil {
		log.Printf("Create User err: %s", createUserError.Error())
		return keycloakUserId, &common.ErrorCreateUserFailed
	}

	// Validate user by adding validated realm role
	keycloakRealmRoleAddErr := utils.AddRealmRolesToInvitedUser(ctx, client, adminToken.AccessToken, realm, keycloakUserId, allRoles)
	if keycloakRealmRoleAddErr != nil {
		log.Printf("keycloak realm role add to user err: %s", keycloakRealmRoleAddErr.Error.Message)
		return keycloakUserId, keycloakRealmRoleAddErr
	}

	// Update user table state as Active, user_accepted time and profile Id as keycloak user ID
	instanceUserProfile.State = common.AcceptedState
	instanceUserProfile.UserAcceptDate = time.Now()
	instanceUserProfile.LastUpdatedDate = time.Now()
	instanceUserProfile.ProfileId = keycloakUserId

	updateErr := i.instanceUserRepo.UpdateInstanceUserState(email, instanceUserProfile)
	if updateErr != nil {
		log.Printf("Error while updating user in db user err: %s", updateErr.Error())
		return keycloakUserId, &common.ErrorDBFailed
	}

	// return newly created user ID from keycloak
	return keycloakUserId, nil
}

func (i inviteUserService) verifyToken(ctx *gin.Context, actionToken string) (string, *models.ErrorResponse) {
	// Get token claims from action token
	var email string
	tokenClaims, tokenVerifyErr := utils.VerifySignedActionToken(&i.config, ctx, actionToken)
	if tokenVerifyErr != nil {
		errMsg := fmt.Sprintf("Verify Token error. Err:: %s", tokenVerifyErr.Error())
		errResp := common.ErrorTokenVerificationFailed
		errResp.Error.AdditionalData = errMsg
		return email, &errResp
	}

	// Check token is generated for invite instance user
	if tokenClaims.Subject != common.InviteInstanceUser {
		errMsg := "invalid token"
		errResp := common.ErrorTokenVerificationFailed
		errResp.Error.AdditionalData = errMsg
		return email, &errResp
	}
	// Get email from token
	email = tokenClaims.Email
	return email, nil
}

func (i inviteUserService) LoginUser(ctx *gin.Context, userEmail string, requestInput request.UserLoginRequest) (response.LoginUserResponse, *models.ErrorResponse) {
	var resp response.LoginUserResponse
	realm := i.config.Info.Realm
	clientID := i.config.Info.ClientId

	userEntity, ifUserExistsErr := i.keycloakRepo.IfUserExists(userEmail)
	if ifUserExistsErr != nil {
		log.Printf("Error while checking if user exists in DB. Err::%v", ifUserExistsErr)
		return resp, &common.ErrorDBFailed
	}

	if userEntity == nil || len(userEntity.ID) <= 1 {
		log.Printf("User login with non-existent credential: %s\n", userEmail)
		return resp, &common.ErrorUserAuthenticationFailed
	}

	// Get admin token for updating keycloak attributes
	client, adminToken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("loginUser loginAdmin error. Err:: %s", err.Error())
		return resp, &common.ErrorServiceFailed
	}

	// Create keycloak user object
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(userEmail),
	}

	// Fetch user based on email
	fetchedUser, err := client.GetUsers(ctx, adminToken.AccessToken, realm, keycloakUser)
	if err != nil {
		log.Printf("loginUser clientGetUsers err: %s", err.Error())
		return resp, &common.ErrorGeneralFailure
	}

	// User doesn't exist in keycloak
	if len(fetchedUser) == 0 {
		return resp, &common.ErrorUserAuthenticationFailed
	}

	user := *fetchedUser[0]
	if user.Attributes == nil {
		emptyAttributes := make(map[string][]string)
		user.Attributes = &emptyAttributes
	}

	// Login keycloak user for selected realm and requested email
	token, err := utils.KeycloakLoginUser(ctx, clientID, realm, &i.config, userEmail, requestInput.Password)
	if err != nil {
		log.Printf("loginUser keycloakLoginUser err: %s", err.Error())
		return resp, &common.ErrorUserAuthenticationFailed
	}

	// Update keycloak user attribute
	loginAt := time.Now().UTC()
	(*user.Attributes)[common.LAST_LOGIN_ATTRIBUTE] = []string{loginAt.String()}
	err2 := client.UpdateUser(ctx, adminToken.AccessToken, realm, user)
	if err2 != nil {
		log.Printf("LoginUser err: %s", err2.Error())
		return resp, &common.ErrorUserAuthenticationFailed
	}

	resp = response.LoginUserResponse{
		Data: response.LoginResp{
			AccessToken:      token.AccessToken,
			TokenType:        token.TokenType,
			ExpiresIn:        token.ExpiresIn,
			RefreshToken:     token.RefreshToken,
			RefreshExpiresIn: token.RefreshExpiresIn,
		},
	}

	return resp, nil
}

func (i inviteUserService) GetUserState(ctx *gin.Context, actionToken string) (response.GetUserStateResponse, *models.ErrorResponse) {
	var getUserStateResponse response.GetUserStateResponse
	var errMsg string

	tokenClaims, tokenError := utils.VerifySignedActionToken(&i.config, ctx, actionToken)
	if tokenError != nil {
		jwtError, hasJwtError := tokenError.(*jwt.ValidationError)

		if hasJwtError && jwtError.Errors == jwt.ValidationErrorExpired {
			errMsg = fmt.Sprint(jwtError.Errors)
		} else {
			errMsg = fmt.Sprintf("Token verification error : %s", tokenError.Error())
		}
		common.ErrorTokenVerificationFailed.Error.AdditionalData = errMsg

		return getUserStateResponse, &common.ErrorTokenVerificationFailed
	}

	getUserDetailsErr := i.instanceUserRepo.GetUserDetailsFromDB(tokenClaims.Email, &getUserStateResponse.Data)
	if getUserDetailsErr != nil || getUserStateResponse.Data.State == "" {
		log.Printf("Org user details not found: %s", tokenClaims.Email)
		return getUserStateResponse, &common.ErrorUserNotFound
	}

	return getUserStateResponse, nil
}

func (i inviteUserService) GetProfileRoles(ctx *gin.Context, profileId string) (response.GetUserProfileRolesResp, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("GetProfileRoles loginAdmin error. Err:: %s", err.Error())
		return response.GetUserProfileRolesResp{}, &common.ErrorServiceFailed
	}

	// Get realm roles of keycloak user
	userRealmRoles, realmRoleErr := client.GetRealmRolesByUserID(ctx, token.AccessToken, realm, profileId)
	if realmRoleErr != nil {
		errMsg := realmRoleErr.Error()
		err := common.ErrorEmailExists
		err.Error.AdditionalData = errMsg
		return response.GetUserProfileRolesResp{}, &err
	}

	return response.GetUserProfileRolesResp{
		Data: response.UserProfileRolesResponse{
			Roles: userRealmRoles,
		},
	}, nil
}

func (i inviteUserService) GenerateAccessToken(ctx *gin.Context, res models.JWT) (response.LoginUserResponse, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	claims := &models.Claims{}
	parsedRefreshToken, _ := jwt.ParseWithClaims(res.RefreshToken, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(""), nil
	})
	clientID := parsedRefreshToken.Claims.(*models.Claims).Azp
	token, err := utils.KeycloakGetToken(ctx, clientID, realm, &i.config, res.RefreshToken)
	if err != nil {
		log.Printf("generateAccessToken keycloakGetToken err: %s", err.Error())
		return response.LoginUserResponse{}, &common.ErrorServiceFailed
	}

	resp := response.LoginResp{
		AccessToken:      token.AccessToken,
		ExpiresIn:        token.ExpiresIn,
		RefreshToken:     token.RefreshToken,
		RefreshExpiresIn: token.RefreshExpiresIn,
	}

	return response.LoginUserResponse{
		Data: resp,
	}, nil
}

func sendInvitationEmail(c *gin.Context, config config.Configuration, email string, adminUserEmail string, orgName string) error {
	// Generate signed action token
	actionToken, tokenError := utils.GenerateSignedAccessToken(config, common.InviteInstanceUser, email)
	if tokenError != nil {
		log.Printf("Generate Token err: %s", tokenError.Error())
		return tokenError
	}

	// Generate a invitation link to attach in email
	invitationLink := config.Info.PortalURL + "/accept-invite?actiontoken=" + actionToken

	// Generate parameter for sending a mail
	sendEmailURL, err := url.Parse(config.Info.NotificationURL + "/send/mail/accept_invitation/" + url.PathEscape(email) + "?adminUser=" + adminUserEmail + "&orgName=" + orgName + "&link=" + invitationLink)
	if err != nil {
		log.Printf("Encode link err: %s", err.Error())
		return err
	}

	// Call notification service to send email
	sendInvitationEmailErr := utils.SendEmailRequest(sendEmailURL)
	if sendInvitationEmailErr != nil {
		log.Printf("Send invitation email err: %s", sendInvitationEmailErr.Error())
		return sendInvitationEmailErr
	}
	return nil
}
