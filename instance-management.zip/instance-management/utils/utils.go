package utils

import (
	"bufio"
	"bytes"
	"crypto/rsa"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"instance-management/common"
	"instance-management/config"
	"instance-management/helper"
	"instance-management/models"
	"io/ioutil"
	"log"
	"net/http"
	"net/mail"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
	"gopkg.in/yaml.v2"
	"gorm.io/gorm"
)

type TokenHandler models.TokenHandler

// common function to remove duplicates from a slice of int or string
func RemoveDuplicate[T string | int](sliceList []T) []T {
	allKeys := make(map[T]bool)
	list := []T{}
	for _, item := range sliceList {
		if _, value := allKeys[item]; !value {
			allKeys[item] = true
			list = append(list, item)
		}
	}
	return list
}

// Method to check for valid instance roles
func IsValidInstanceUserRole(role string) bool {
	for _, validRole := range common.ValidRoles {
		if strings.EqualFold(role, validRole) {
			return true
		}
	}
	return false
}

func GetTokenFromJwtHeader(c *gin.Context) *models.Claims {
	authHeader := c.GetHeader("Authorization")
	if len(authHeader) == 0 {
		return &models.Claims{}
	}
	tokenString := authHeader[len("Bearer"):]
	tokenString = strings.TrimLeft(tokenString, " ")
	claims := &models.Claims{}
	token, _ := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(""), nil
	})
	return token.Claims.(*models.Claims)
}

// Normalize email (lower_case, trim, parse address)
func NormalizeEmail(email string) (string, error) {
	emailRes := strings.ToLower(email)
	emailRes = strings.TrimSpace(emailRes)
	_, err := mail.ParseAddress(emailRes)
	if err != nil {
		return "", err
	}
	return emailRes, nil
}

func IsEmailValid(emailAddress string) bool {
	emailRegex := regexp.MustCompile(`^(([^/<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$`)
	return emailRegex.MatchString(emailAddress)
}

// Captial the first letter of word
func CapitalizeWords(input string) string {
	words := strings.Split(input, ",")
	capitalizedWords := make([]string, len(words))

	for i, word := range words {
		word = strings.TrimSpace(word)
		if word != "" {
			capitalizedWords[i] = strings.ToUpper(string(word[0])) + strings.ToLower(word[1:])
		}
	}

	return strings.Join(capitalizedWords, ",")
}

func GenerateSignedAccessToken(config config.Configuration, subject string, email string) (string, error) {
	privateKeyImported, privateKeyImportError := GetPrivateKey(&config)
	if privateKeyImportError != nil {
		fmt.Printf("Import Key err: %s", privateKeyImportError.Error())
		return "", privateKeyImportError
	}

	// Create token handler with this key
	tokenHandler := &TokenHandler{privateKeyImported}

	// Generate new signed token using tokenhandler
	_, _, actionToken, tokenError := tokenHandler.NewToken(subject, email, config.Auth.VerificationTokenDuration)

	return actionToken, tokenError
}

// Generate new JWT Token
func (e *TokenHandler) NewToken(subject string, email string, tokenExpiresIn string) (int64, int64, string, error) {
	createdAt := time.Now().Unix()
	tokenExpiry, err := strconv.ParseInt(tokenExpiresIn, 10, 64)
	if err != nil {
		tokenExpiry = int64(common.DefaultTokenExpiresIn)
	}
	expiresAt := createdAt + tokenExpiry
	t := jwt.NewWithClaims(jwt.SigningMethodRS256, models.Claims{
		StandardClaims: jwt.StandardClaims{
			Subject:   subject,
			ExpiresAt: expiresAt,
			IssuedAt:  createdAt,
			NotBefore: createdAt,
		},
		Email: email,
	})
	signedString, err := t.SignedString(e.PrivateKey)
	return createdAt, expiresAt, signedString, err
}

// Get Private Key (Pem File)
func GetPrivateKey(config *config.Configuration) (*rsa.PrivateKey, error) {
	fmt.Println("private key file", config.Info.PrivateKeyFile)
	privateKeyFile, err := os.Open(config.Info.PrivateKeyFile)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	pemfileinfo, _ := privateKeyFile.Stat()
	var size int64 = pemfileinfo.Size()
	pembytes := make([]byte, size)
	buffer := bufio.NewReader(privateKeyFile)
	_, err = buffer.Read(pembytes)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	data, _ := pem.Decode([]byte(pembytes))
	privateKeyFile.Close()
	privateKeyImported, err := x509.ParsePKCS1PrivateKey(data.Bytes)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	return privateKeyImported, err
}

// loginAdmin Login to keycloak for Admin REST APIs
func LoginAdmin(c *gin.Context, config *config.Configuration) (*gocloak.GoCloak, *gocloak.JWT, error) {
	client := gocloak.NewClient(config.Auth.Host)

	if config.Auth.GrantType == common.GrantTypeClientCredentials {
		//Login to keycloak using grant_type:client_credentials with a service account
		token, err := client.LoginClient(c, config.Auth.AdminClientId, config.Auth.AdminClientSecret,
			config.Auth.AdminRealm)

		return client, token, err
	} else {
		//Login to keycloak using grant_type:password with an admin account
		token, err := client.LoginAdmin(c, config.Auth.AdminUsername, config.Auth.AdminPassword,
			config.Auth.AdminRealm)

		return client, token, err
	}
}

// Verify JWT Token
func (e TokenHandler) Verify(token string) (*models.Claims, error) {
	parsed, err := jwt.ParseWithClaims(token, &models.Claims{}, func(t *jwt.Token) (interface{}, error) {
		return &e.PrivateKey.PublicKey, nil
	})

	if err != nil {
		jwtError, hasError := err.(*jwt.ValidationError)

		if hasError && jwtError.Errors == jwt.ValidationErrorExpired {
			claims := parsed.Claims.(*models.Claims)
			return claims, jwtError
		}

		return &models.Claims{}, err
	}

	if claims, ok := parsed.Claims.(*models.Claims); ok && parsed.Valid {
		return claims, nil
	}
	return &models.Claims{}, errors.New("invalid token")
}

// Verify last token to action token
func VerifyLastToken(actionToken string, user gocloak.User, config *config.Configuration) (bool, string, error) {
	if (len((*user.Attributes)[common.LAST_VERIFICATION_TOKEN]) == 0) || *user.EmailVerified {
		return false, "", nil
	}

	lastVerificationToken := (*user.Attributes)[common.LAST_VERIFICATION_TOKEN][0]
	verificationToken := strings.Split(lastVerificationToken, "_")
	stringTokenExpireAt := verificationToken[0]
	stringTokenIssueAt := verificationToken[1]
	today := time.Now()

	tokenExpireAt, _ := stringToTime(stringTokenExpireAt)
	lastTokenHasExpired := today.After(tokenExpireAt)

	if actionToken != "" {
		privateKeyImported, err := GetPrivateKey(config)
		if err != nil {
			fmt.Printf("Import Key err: %s", err.Error())

			return false, "", err
		}
		tokenHandler := &TokenHandler{privateKeyImported}
		parsed, _ := jwt.ParseWithClaims(actionToken, &models.Claims{}, func(t *jwt.Token) (interface{}, error) {
			return &tokenHandler.PrivateKey.PublicKey, nil
		})

		claims, _ := parsed.Claims.(*models.Claims)
		intLastTokenExpiry, _ := strconv.ParseInt(stringTokenExpireAt, 10, 64)
		intLastTokenIssueAt, _ := strconv.ParseInt(stringTokenIssueAt, 10, 64)

		if claims.ExpiresAt != intLastTokenExpiry || claims.IssuedAt != intLastTokenIssueAt {
			return false, common.JWT_TOKEN_NOT_MATCH_ERROR_CODE, errors.New("invalid token")
		}

	}

	if !lastTokenHasExpired {
		return true, "", nil
	}

	return false, common.JWT_TOKEN_NOT_MATCH_ERROR_CODE, errors.New("token expired")

}

func stringToTime(s string) (time.Time, error) {
	sec, err := strconv.ParseInt(s, 10, 64)
	if err != nil {
		return time.Time{}, err
	}
	return time.Unix(sec, 0), nil
}

func GetUserInfoByEmail(client *gocloak.GoCloak, context *gin.Context, adminToken string, realm string, email string) (gocloak.User, error) {
	var fetchedUser []*gocloak.User
	var user gocloak.User
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(email),
	}

	fetchedUser, err := client.GetUsers(context, adminToken, realm, keycloakUser)

	if err != nil {
		return user, err
	}

	if len(fetchedUser) == 0 {
		return user, errors.New("no user found")
	}

	user = *fetchedUser[0]

	if user.Attributes == nil {
		emptyAttributes := make(map[string][]string)
		user.Attributes = &emptyAttributes
	}

	return user, nil
}

func SendEmailRequest(sendEmailURL *url.URL) error {
	sendEmailURL.RawQuery = sendEmailURL.Query().Encode()
	req, err := http.NewRequest("PUT", sendEmailURL.String(), nil)

	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return err
	}

	resp, err := http.DefaultClient.Do(req)

	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return err
	}

	if resp.StatusCode >= 200 && resp.StatusCode <= 299 {
		fmt.Println("HTTP Status is in the 2xx range")
	} else {
		fmt.Printf("Send Email err: %s", resp.Status)
		return errors.New(resp.Status)
	}

	return nil
}

// Get realm for a user from keycloakdb
func GetRealmNameByUsername(keycloakDb *gorm.DB, username string) (string, error) {
	var realmName string

	// Get realm_id from keycloak table for user
	tx := keycloakDb.Table("user_entity").Where("username = ?", username)
	tx.Select("realm_id")
	rows, err := tx.Rows()

	if err != nil {
		return "", err
	}
	defer rows.Close()
	for rows.Next() {
		tx.ScanRows(rows, &realmName)
	}

	return realmName, nil
}

func ContainRole(roles []*gocloak.Role, checkRole string) bool {
	for _, role := range roles {
		if gocloak.PString(role.Name) == checkRole {
			return true
		}
	}
	return false
}

func VerifySignedActionToken(config *config.Configuration, c *gin.Context, actionToken string) (*models.Claims, error) {
	privateKeyImported, privateKeyImportError := GetPrivateKey(config)
	if privateKeyImportError != nil {
		errMsg := fmt.Sprintf("Import Key err: %s", privateKeyImportError.Error())
		helper.ErrorResponse(c, http.StatusBadRequest, common.ErrorTokenVerificationFailed, &errMsg)
		return nil, privateKeyImportError
	}

	// Create token handler with this key
	tokenHandler := &TokenHandler{privateKeyImported}

	// Validate signed action token using private key token handler
	tokenClaims, tokenError := tokenHandler.Verify(actionToken)

	return tokenClaims, tokenError
}

// Get validated role and add it to the user
func AddRealmRolesToInvitedUser(c *gin.Context, client *gocloak.GoCloak, adminToken string, realm string, userId string, allRoles []string) *models.ErrorResponse {
	roleToAdd := []gocloak.Role{}
	roles, err := client.GetRealmRoles(c, adminToken, realm, gocloak.GetRoleParams{})
	if err != nil {
		log.Print(err.Error())
		return &common.ErrorGetRealmRolesFailed
	}

	//filter for validated role
	validatedRole := filterRealmRoles(roles, common.ValidatedRole)
	roleToAdd = append(roleToAdd, *validatedRole)

	// Add admin,publisher,consumer role if present
	for _, attrRole := range allRoles {
		if strings.ToLower(attrRole) == common.AdminRole {
			role := filterRealmRoles(roles, common.AdminRole)
			if role != nil {
				roleToAdd = append(roleToAdd, *role)
			}
		}
	}

	if len(roleToAdd) > 0 {
		if err := client.AddRealmRoleToUser(c, adminToken, realm, userId, roleToAdd); err != nil {
			return &common.ErrorAddRealmRolesFailed
		}
	}

	return nil
}

// filter role value based on roles input
func filterRealmRoles(roles []*gocloak.Role, roleName string) *gocloak.Role {

	// Initialized variabls
	var roleDetails *gocloak.Role
	// find role present in roles array
	for _, role := range roles {
		if role.Name != nil && *role.Name == roleName {
			roleDetails = role
			break
		}
	}

	return roleDetails
}

// keycloakLoginUser Login to keycloak using admin
func KeycloakLoginUser(c *gin.Context, clientID string, realm string, config *config.Configuration, userName string, password string) (*gocloak.JWT, error) {
	client := gocloak.NewClient(config.Auth.Host)
	token, err := client.Login(c, clientID, "", realm, userName, password)
	if err != nil {
		fmt.Printf("LoginUser Error %s", err)
		return nil, err
	}
	return token, err
}

// keycloak get Access Token with Refresh Token
func KeycloakGetToken(c *gin.Context, clientID string, realm string, config *config.Configuration, refreshToken string) (*gocloak.JWT, error) {
	client := gocloak.NewClient(config.Auth.Host)
	token, err := client.RefreshToken(c, refreshToken, clientID, "", realm)
	if err != nil {
		fmt.Printf("RefreshToken Error %s", err)
		return nil, err
	}
	return token, err
}

// check string contains element
func Contains(elems []string, v string) bool {
	for _, s := range elems {
		if strings.EqualFold(s, v) {
			return true
		}
	}
	return false
}

// Fetch roles from user-management
func FetchUserRoles(c *gin.Context, config *config.Configuration, userId string) (models.UserRoleResult, error) {
	var result models.UserRoleResult

	authHeader := c.GetHeader("Authorization")
	tokenString := authHeader[len("Bearer"):]
	request, _ := http.NewRequest(http.MethodGet, config.Info.UserManagementUrl+"/api/v1/users/profile/"+userId+"/roles", bytes.NewBuffer(nil))
	request.Header.Set("Content-Type", "application/json")
	request.Header.Set("Authorization", "Bearer "+tokenString)
	client := &http.Client{}
	response, err := client.Do(request)
	if err != nil {
		fmt.Printf("userManagement Get User role API error. Err:: %s", err.Error())
		return result, err
	}
	if response.StatusCode != http.StatusOK {
		errMsg := "userManagement Get User role API status not OK"
		return result, errors.New(errMsg)
	}
	responseBody, _ := ioutil.ReadAll(response.Body)
	json.Unmarshal(responseBody, &result)

	return result, nil
}

// Convert yaml to json
func YamlToJson(yamlString string) (string, error) {
	var yamlData map[string]interface{}

	err := yaml.Unmarshal([]byte(yamlString), &yamlData)
	if err != nil {
		log.Fatalf("Error parsing YAML: %v", err)
		return "", err
	}
	jsonData, err := json.MarshalIndent(yamlData, "", "  ")
	if err != nil {
		log.Fatalf("Error converting to JSON: %v", err)
		return "", err
	}

	return string(jsonData), nil
}
