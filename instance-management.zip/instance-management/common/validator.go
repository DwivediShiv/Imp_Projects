package common

import (
	"errors"

	"github.com/go-playground/validator/v10"
)

func getErrorMsg(fe validator.FieldError) string {
	switch fe.Tag() {
	case "required":
		return "This field is required"
	case "gt":
		return "Should be greater than " + fe.Param()
	case "min":
		return "Length should be minimum " + fe.Param()
	case "max":
		return "The max value can be " + fe.Param()
	}
	return fe.Error()
}

func GetAdditionalErrorData(err error) map[string]string {
	var ve validator.ValidationErrors
	out := make(map[string]string, len(ve))
	if errors.As(err, &ve) {
		for _, fe := range ve {
			out[fe.Field()] = getErrorMsg(fe)
		}
	}
	return out
}
