package common

import (
	"instance-management/models"
	"net/http"
)

var (
	ErrorInvalidRequestInput = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Request Inputs are not valid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_INVALID_REQUEST_INPUT",
	}

	InfoDeploymentInProgress = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Changes still in progress",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INFO_DEPLOYMENT_IN_PROGRESS",
	}

	ErrorInvalidEmail = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Email Id is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_EMAIL",
	}

	ErrorEmailExists = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Email already exists",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "EMAIL_ALREADY_EXISTS",
	}

	ErrorServiceFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Service failed",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "SERVICE_FAILED",
	}

	ErrorGeneralFailure = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "General failure",
		},
		Code: "GENERAL_FAILURE",
	}

	ErrorSendNotificationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Invitation notification failed",
		},
		Code: "INVITATION_NOTIFICATION_FAILED",
	}

	ErrorDbFetchFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Unable to fetch data",
		},
		Code: "ERROR_FETCH_FAILED",
	}

	ErrorGetKeycloakUserNotFound = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User profile not found",
		},
		Code: "ERROR_GET_USER_PROFILE_NOT_FOUND",
	}

	ErrorDBFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "DB Failure",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "ERROR_DB_FAILED",
	}

	ErrorUserAuthenticationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User authentication failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_USER_AUTHENTICATION_FAILED",
	}

	ErrorAdminAccountLocked = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Admin account locked",
		},
		Code: "ERROR_ADMIN_ACCOUNT_LOCKED",
	}

	ErrorPasswordValidationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "password validate failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "PASSWORD_VALIDATION_FAILED",
	}

	ErrorTokenVerificationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "token verification failed",
		},
		Code: "TOKEN_VERIFICATION_FAILED",
	}

	ErrorInvitationAlreadyAccepted = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "user has already accepted the invitation. Please login",
		},
		Code: "ERROR_INVITATION_ALREADY_ACCEPTED",
	}

	ErrorGetRealmRolesFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "get realm roles failed",
		},
		Code: "ERROR_GET_REALM_ROLES_FAILED",
	}

	ErrorAddRealmRolesFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "add realm roles failed",
		},
		Code: "ERROR_ADD_REALM_ROLES_FAILED",
	}

	ErrorCreateUserFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "create user profile failed",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "ERROR_CREATE_USER_FAILED",
	}

	ErrorUserNotFound = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "user not found",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_USER_NOT_FOUND",
	}
)
