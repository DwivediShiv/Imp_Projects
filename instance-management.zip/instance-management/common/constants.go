package common

var ValidRoles = []string{
	"Admin",
	"Viewer",
}

const (
	InvitedState                   = "Invited"
	AcceptedState                  = "Accepted"
	GrantTypeClientCredentials     = "client_credentials"
	DefaultTokenExpiresIn          = 86400 * 3 // 3600 = 1hour  //86400 = 1 day
	LAST_VERIFICATION_TOKEN        = "LAST_VERIFICATION_TOKEN"
	JWT_TOKEN_NOT_MATCH_ERROR_CODE = "544"
	EMAIL_VERIFIED_DATE            = "EMAIL_VERIFIED_DATE"
	InviteInstanceUser             = "InviteInstanceUser"
	AdminRole                      = "admin"
	ViewerRole                     = "viewer"
	ValidatedRole                  = "validated"
)

//constants related to keycloak
const (
	INVITATION_ACCEPTED_ON = "INVITATION_ACCEPTED_ON"
	CREATED_BY             = "CREATED_BY"
	CREATED_DATE           = "CREATED_DATE"
	UPDATED_BY             = "UPDATED_BY"
	UPDATE_DATE            = "UPDATE_DATE"
	STATE                  = "STATE"
	WALLET_ROLES           = "ROLES_WALLET"
	MAX_LOGIN_ATTEMPT      = 3
	LAST_LOGIN_ATTRIBUTE   = "LAST_LOGIN"
)
