package controller

import (
	"fmt"
	"instance-management/common"
	"instance-management/helper"
	"instance-management/models/request"
	"instance-management/service"
	"instance-management/utils"
	"net/http"

	"github.com/gin-gonic/gin"
)

type InstanceController struct {
	instanceService service.InstanceService
}

func NewInstanceController(instanceService service.InstanceService) InstanceController {
	return InstanceController{
		instanceService: instanceService,
	}
}

func (ic *InstanceController) VersionList(ctx *gin.Context) {
	list, serviceErr := ic.instanceService.GetVersionList()
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, list)
}

func (ic *InstanceController) GetReleaseNote(ctx *gin.Context) {
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	resp, serviceErr := ic.instanceService.GetReleaseNote(version)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, resp)
}

func (ic *InstanceController) GetVersionConfig(ctx *gin.Context) {
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	resp, serviceErr := ic.instanceService.GetVersionConfig(version)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, resp)
}

func (ic *InstanceController) PutVersionConfig(ctx *gin.Context) {
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	file, _, err := ctx.Request.FormFile("file")
	if err != nil {
		errMsg := "empty file"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := ic.instanceService.PutVersionConfig(version, file)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.Status(http.StatusNoContent)
}

func (ic *InstanceController) PutInstanceTheming(ctx *gin.Context) {
	err := ctx.Request.ParseMultipartForm(10 << 20) // 10 MB limit
	if err != nil {
		errMsg := "file limit exceeded"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	formFiles := ctx.Request.MultipartForm.File

	for _, fileHeaders := range formFiles {
		for _, fileHeader := range fileHeaders {
			// Open the file
			file, err := fileHeader.Open()
			if err != nil {
				errMsg := "file opening error"
				errResp := common.ErrorInvalidRequestInput
				errResp.Error.AdditionalData = errMsg
				helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
				return
			}
			defer file.Close()

			serviceErr := ic.instanceService.PutInstanceTheming(file, fileHeader.Filename)
			if serviceErr != nil {
				helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
				return
			}
		}
	}

	ctx.Status(http.StatusNoContent)

}

func (ic *InstanceController) GetFormBuilder(ctx *gin.Context) {
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	resp, serviceErr := ic.instanceService.GetFormBuilder(version)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, resp)
}

func (ic *InstanceController) GetSecrets(ctx *gin.Context) {
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	resp, serviceErr := ic.instanceService.GetVersionSecrets(version)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, resp)
}

func (ic *InstanceController) PutSecrets(ctx *gin.Context) {
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	req := request.SecretsPutRequest{}
	if err := ctx.ShouldBindJSON(&req); err != nil {
		errMsg := fmt.Sprintf("PutSecrets Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := ic.instanceService.PutVersionSecrets(version, req.Message)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.Status(http.StatusNoContent)
}

func (ic *InstanceController) RedeployInstance(ctx *gin.Context) {
	// Get admin token payload
	tokenPayload := utils.GetTokenFromJwtHeader(ctx)
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	if serviceErr := ic.instanceService.RedeployInstance(tokenPayload.Email, version); serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.Status(http.StatusNoContent)
}
