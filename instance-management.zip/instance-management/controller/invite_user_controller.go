package controller

import (
	"fmt"
	"instance-management/common"
	"instance-management/helper"
	"instance-management/models"
	"instance-management/models/request"
	pkg "instance-management/pkg/common"
	"instance-management/service"
	"instance-management/utils"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

type InviteUserController struct {
	inviteUserService service.InviteUserService
}

func NewInviteUserController(inviteUserService service.InviteUserService) InviteUserController {
	return InviteUserController{
		inviteUserService: inviteUserService,
	}
}

//  InviteUser		godoc
//	@Summary		Invite Instance User
//	@Description	Save details of invited user in Db.
//	@Param			tags	body	request.InviteUserRequest	true	"Create user"
//	@Produce		application/json
//	@Tags			user
//	@Success		200	{object}	response.InviteUserResponse{}
//	@Router			/api/v1/instance/invite-user [POST]
func (i InviteUserController) InviteUser(ctx *gin.Context) {
	inviteUserReq := request.InviteUserRequest{}
	if err := ctx.ShouldBindJSON(&inviteUserReq); err != nil {
		errMsg := fmt.Sprintf("InviteUser Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	newUserEmail, validationErr := validateRolesAndEmailInRequest(ctx, inviteUserReq)
	if validationErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, *validationErr, &validationErr.Error.Message)
		return
	}

	// Get admin token payload
	tokenPayload := utils.GetTokenFromJwtHeader(ctx)

	serviceResp, serviceErr := i.inviteUserService.InviteUser(ctx, inviteUserReq, newUserEmail, tokenPayload)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//  AcceptInvite	godoc
//	@Summary		Accept Invite
//	@Description	Save details of invited user in Keycloak.
//	@Param			tags	body	request.AcceptInviteRequest	true	"Create user in keycloak"
//	@Produce		application/json
//	@Tags			user
//	@Success		200	{object}	response.AcceptInviteResponse{}
//	@Router			/api/v1/instance/accept-invite [POST]
func (i InviteUserController) AcceptInvite(ctx *gin.Context) {
	// Get auth token present in header
	authHeader := ctx.GetHeader("Authorization")
	if authHeader == "" {
		errMsg := "authorization token not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	actionToken := authHeader[len("Bearer "):]

	var requestInput request.AcceptInviteRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("AcceptInvite shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	err := pkg.ValidatePassword(requestInput.Password)
	if err != nil {
		errMsg := err.Error()
		errResp := common.ErrorPasswordValidationFailed
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorPasswordValidationFailed, &errMsg)
		return
	}

	resp, serviceErr := i.inviteUserService.AcceptInvite(ctx, actionToken, requestInput.Password)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, resp)

}

//  LoginUser		godoc
//	@Summary		Login User
//	@Description	Login User and give token
//	@Param			tags	body	request.UserLoginRequest	true	"Login user"
//	@Produce		application/json
//	@Tags			user
//	@Success		200	{object}	response.LoginUserResponse{}
//	@Router			/api/v1/instance/login [PUT]
func (i InviteUserController) LoginUser(ctx *gin.Context) {
	var requestInput request.UserLoginRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("loginUser shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	userEmail, emailErr := utils.NormalizeEmail(requestInput.Email)
	if emailErr != nil {
		errMsg := fmt.Sprintf("LoginUser mailParseAddress error. Err:: %s", emailErr.Error())
		errResp := common.ErrorInvalidEmail
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Check the validation of user email
	if !utils.IsEmailValid(userEmail) {
		errMsg := fmt.Sprintf("invalid email address: %s", userEmail)
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorInvalidEmail, &errMsg)
		return
	}

	serviceResp, serviceErr := i.inviteUserService.LoginUser(ctx, userEmail, requestInput)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//  GetUserState	godoc
//	@Summary		Get Invited User State
//	@Description	Get Invited User State
//	@Produce		application/json
//	@Tags			user
//	@Success		200	{object}	models.InstanceUserProfile
//	@Router			/api/v1/instance/invited/user-state [GET]
func (i InviteUserController) GetUserState(ctx *gin.Context) {
	authHeader := ctx.GetHeader("Authorization")
	if authHeader == "" {
		errMsg := "authorization token not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	actionToken := authHeader[len("Bearer "):]

	serviceResp, serviceErr := i.inviteUserService.GetUserState(ctx, actionToken)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//  GetUserProfileRoles	godoc
//	@Summary		Get User Profile Roles
//	@Description	Get Invited User State
//	@Produce		application/json
//	@Tags			user
//	@Success		200	{object}	response.GetUserProfileRolesResp
//	@Router			/api/v1/instance/users/:profileId/roles [GET]
func (i InviteUserController) GetUserProfileRoles(ctx *gin.Context) {
	profileId := ctx.Param("profileId")
	if profileId == "" {
		errMsg := "profileId not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.inviteUserService.GetProfileRoles(ctx, profileId)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//  GenerateAccessToken		godoc
//	@Summary		Generate Access Token
//	@Description	Generate Access Token
//	@Param			tags	body	models.JWT	true "Generate Token"
//	@Produce		application/json
//	@Tags			user
//	@Success		200	{object}	response.LoginUserResponse{}
//	@Router			/api/v1/instance/access-token [POST]
func (i InviteUserController) GenerateAccessToken(ctx *gin.Context) {
	var res models.JWT
	if err := ctx.ShouldBindJSON(&res); err != nil {
		errMsg := fmt.Sprintf("generateAccessToken shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorGeneralFailure
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	serviceResp, serviceErr := i.inviteUserService.GenerateAccessToken(ctx, res)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

// Method to validate instance invite user' request input
func validateRolesAndEmailInRequest(ctx *gin.Context, inviteUserReq request.InviteUserRequest) (newUserEmail string, errResponse *models.ErrorResponse) {
	//remove duplicates roles from all roles
	*inviteUserReq.Roles = utils.RemoveDuplicate(*inviteUserReq.Roles)

	// Validate input roles
	if inviteUserReq.Roles != nil && len(*inviteUserReq.Roles) > 0 {
		for _, inputRole := range *inviteUserReq.Roles {
			if !utils.IsValidInstanceUserRole(inputRole) {
				errMsg := "role is not a valid role"
				errResponse = &common.ErrorInvalidRequestInput
				errResponse.Error.AdditionalData = map[string]string{"roles": errMsg}
				break
			}
		}
	}

	// normalize email input
	newUserEmail, newUserEmailErr := utils.NormalizeEmail(inviteUserReq.Email)
	if newUserEmailErr != nil {
		log.Printf("InviteUser mailParseAddress error. Err:: %s", newUserEmailErr.Error())
		errResponse = &common.ErrorInvalidEmail
		return
	}

	// Check the validation of user email
	if !utils.IsEmailValid(newUserEmail) {
		log.Printf("invalid email address: %s", newUserEmail)
		errResponse = &common.ErrorInvalidEmail
		return
	}

	return
}
