<h1 align="center">Instance Admin Portal</h1>

**Table of Contents**

- [🏄 Get Started](#-get-started)
- [👩‍🎤 Storybook](#-storybook)
- [🤖 Testing](#-testing)
- [✨ Code Style](#-code-style)
- [🛳 Production](#-production)
- [⬆️ Deployment](#️-deployment)
- [💖 Contributing](#-contributing)
- [🍴 Forking](#-forking)
- [✅ GDPR Compliance](#-gdpr-compliance)
  - [Multi-Language Privacy Policies](#multi-language-privacy-policies)
  - [Privacy Preference Center](#privacy-preference-center)
    - [Privacy Preference Center Styling](#privacy-preference-center-styling)
- [🏛 License](#-license)

## 🏄 Get Started

The app is a React app built with [Next.js](https://nextjs.org) + TypeScript + CSS modules and will connect to Ocean remote components by default.

To start local development:

```bash
git clone https://git.i.mercedes-benz.com/acentrik/instance-portal.git
cd instance-portal

# when using nvm to manage Node.js versions
nvm use

```

Login to AWS CodeArtifact

```bash
aws codeartifact login --tool npm --domain acentrik --domain-owner 540306422608 --repository package-js
```

Set AUTH Token to ENV VAR for npm install authentication with AWS CodeArtifact Registry

```bash
export CODEARTIFACT_AUTH_TOKEN=`aws codeartifact get-authorization-token --domain acentrik --domain-owner 540306422608 --query authorizationToken --output text`
```

npm package installation

```bash
npm install
# in case of dependency errors, rather use:
# npm install --legacy-peer-deps
npm start
```

This will start the development server under
`http://localhost:8003`.


## 🦑 Environment variables

The `app.config.js` file is setup to prioritize environment variables for setting each component endpoint. By setting environment variables, you can easily switch between config without directly modifying `app.config.js`.

For local development, you can use a `.env` file:

```bash
# modify env variables
cp .env.example .env
```

## 🤖 Testing

Test runs utilize [Jest](https://jestjs.io/) as test runner and [Testing Library](https://testing-library.com/docs/react-testing-library/intro) for writing tests.

All created Storybook stories will automatically run as individual tests by using the [StoryShots Addon](https://storybook.js.org/addons/@storybook/addon-storyshots).

Creating Storybook stories for a component will provide good coverage of a component in many cases. Additional tests for dedicated component functionality which can't be done with Storybook are created as usual [Testing Library](https://testing-library.com/docs/react-testing-library/intro) tests, but you can also [import exisiting Storybook stories](https://storybook.js.org/docs/react/writing-tests/importing-stories-in-tests#example-with-testing-library) into those tests.

Executing linting, type checking, and full test run:

```bash
npm test
```

Which is a combination of multiple scripts which can also be run individually:

```bash
npm run lint
npm run type-check
npm run jest
```

A coverage report is automatically shown in console whenever `npm run jest` is called. Generated reports are sent to CodeClimate during CI runs.

During local development you can continously get coverage report feedback in your console by running Jest in watch mode:

```bash
npm run jest:watch
```

## ✨ Code Style

Code style is automatically enforced through [ESLint](https://eslint.org) & [Prettier](https://prettier.io) rules:

- Git pre-commit hook runs `prettier` on staged files, setup with [Husky](https://typicode.github.io/husky)
- VS Code suggested extensions and settings for auto-formatting on file save
- CI runs a linting & TypeScript typings check as part of `npm test`, and fails if errors are found

For running linting and auto-formatting manually, you can use from the root of the project:

```bash
# linting check
npm run lint

# auto format all files in the project with prettier, taking all configs into account
npm run format
```

## 🛳 Production

To create a production build, run from the root of the project:

```bash
npm run build

# serve production build
npm run serve
```

## ⬆️ Deployment

Every branch or Pull Request is automatically deployed to multiple hosts for redundancy and emergency reasons:

- [Netlify](https://netlify.com)
- [Vercel](https://vercel.com)
- [S3](https://aws.amazon.com/s3/)

A link to a preview deployment will appear under each Pull Request.

## 🍴 Forking

We encourage you to fork this repository and create your own data marketplace. When you publish your forked version of this market there are a few elements that you are required to change for copyright reasons:

- The typeface is copyright protected and needs to be changed unless you purchase a license for it.

Everything else is made open according to the apache2 license.

## ✅ GDPR Compliance

It comes with prebuilt components for you to customize to cover GDPR requirements. Find additional information on how to use them below.

### Multi-Language Privacy Policies

Feel free to adopt our provided privacy policies to your needs. Per default we cover four different languages: English, German, Spanish and French. Please be advised, that you will need to adjust some paragraphs in the policies depending on your market setup (e.g. the use of cookies). You can easily add or remove policies by providing your own markdown files in the `content/pages/privacy` directory. For guidelines on how to format your markdown files refer to our provided policies. The pre-linked content tables for these files are automatically generated.

### Privacy Preference Center

```tsx
import { CookieConsentStatus, useConsent } from '@context/CookieConsent'
import { deleteCookie, setCookie } from '@utils/cookies'

// ...

const { cookies, cookieConsentStatus } = useConsent()

cookies.map((cookie) => {
  const consent = cookieConsentStatus[cookie.cookieName]

  switch (consent) {
    case CookieConsentStatus.APPROVED:
      // example logic
      setCookie(`YOUR_COOKIE_NAME`, 'VALUE')
      break

    case CookieConsentStatus.REJECTED:
    case CookieConsentStatus.NOT_AVAILABLE:
    default:
      // example logic
      deleteCookie(`YOUR_COOKIE_NAME`)
      break
  }
})
```

#### Privacy Preference Center Styling

The privacy preference centre has two styling options `default` and `small`. The default view shows all of the customization options on a full-height side banner. When the `small` setting is used, a much smaller banner is shown which only reveals all of the customization options when the user clicks "Customize".

The style can be changed by altering the `style` prop in the `PrivacyPreferenceCenter` component in `src/components/App.tsx`. For example:

```Typescript
<PrivacyPreferenceCenter style="small" />
```

## 🏛 License

```text

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```
