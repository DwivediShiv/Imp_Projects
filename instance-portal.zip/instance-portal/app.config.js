function isToken(str) {
  // Define a regular expression pattern to match the token format
  const pattern = /^#\(.+\)#$/
  // Test if the string matches the pattern
  return pattern.test(str)
}

function parseStringArray(str) {
  // Remove surrounding quotes and backslashes
  let cleaned = JSON.parse(str.replace(/'/g, '"'))
  return cleaned
}

function validateEnvVariable(currentVal, defaultVal, type, emptyUseDefault) {
  if (isToken(currentVal) || (emptyUseDefault && currentVal === '')) {
    return defaultVal
  }

  switch (type) {
    case 'number':
      return Number(currentVal)
    case 'numberRound':
      return ~~currentVal
    case 'json':
      return JSON.parse(currentVal)
    case 'arrayjson':
      currentVal = parseStringArray(currentVal)
      return currentVal
    default:
      return currentVal
  }
}

module.exports = {
  metadataCacheUri:
    process.env.NEXT_PUBLIC_NETWORK_METADATA_CACHE_URI ||
    '#(NEXT_PUBLIC_NETWORK_METADATA_CACHE_URI)#',
  networks:
    process.env.NEXT_PUBLIC_CONFIGURED_NETWORKS ||
    validateEnvVariable('#(NEXT_PUBLIC_CONFIGURED_NETWORKS)#', [
      'amoy',
      'sepolia',
      'polygon'
    ]),
  chainIds:
    (process.env.NEXT_PUBLIC_MARKET_DEFAULT_CHAINS &&
      JSON.parse(process.env.NEXT_PUBLIC_MARKET_DEFAULT_CHAINS)) ||
    validateEnvVariable(
      '#(NEXT_PUBLIC_MARKET_DEFAULT_CHAINS)#',
      [11155111, 80002, 137],
      'json'
    ),
  source: process.env.NEXT_PUBLIC_SOURCE || '#(NEXT_PUBLIC_SOURCE)#',
  chainIdsSupported:
    (process.env.NEXT_PUBLIC_MARKET_SUPPORTED_CHAINS &&
      JSON.parse(process.env.NEXT_PUBLIC_MARKET_SUPPORTED_CHAINS)) ||
    validateEnvVariable(
      '#(NEXT_PUBLIC_MARKET_SUPPORTED_CHAINS)#',
      [1, 137, 10, 5, 80002, 11155111, 137],
      'json'
    ),

  // Config for https://github.com/donavon/use-dark-mode
  darkModeConfig: {
    classNameDark: 'dark',
    classNameLight: 'light',
    storageKey: 'oceanDarkMode'
  },

  // IPFS related settings
  ipfs: {
    gatewayUri: process.env.NEXT_PUBLIC_IPFS_URI || 'https://ipfs.acentrik.io',
    uploadLimit: process.env.NEXT_PUBLIC_IPFS_UPLOAD_LIMIT || '20',
    eulaUploadLimit: process.env.NEXT_PUBLIC_IPFS_EULA_UPLOAD_LIMIT || '20',
    imageUploadLimit: process.env.NEXT_PUBLIC_IPFS_UPLOAD_IMAGE_LIMIT || '10'
  },

  // Default standard api domain
  api: process.env.NEXT_PUBLIC_API_URI || '#(NEXT_PUBLIC_API_URI)#',
  instanceVersion:
    process.env.NEXT_PUBLIC_ENVIRONMENT_VERSION ||
    '#(NEXT_PUBLIC_ENVIRONMENT_VERSION)#',
  otpDuration:
    process.env.NEXT_PUBLIC_AUTH_OTP_DURATION ||
    '#(NEXT_PUBLIC_AUTH_OTP_DURATION)#',

  site: {
    termsAndConditionsUrl:
      process.env.NEXT_PUBLIC_SITE_TERM_AND_CONDITION_URL ||
      'https://acentrik.io/terms-and-conditions',
    cookieSecure: process.env.NEXT_PUBLIC_COOKIE_SECURE || 'true',
    webPortalUrl:
      process.env.NEXT_PUBLIC_SITE_WEB_PORTAL_URL || 'https://acentrik.io'
  },

  // Set the default privacy policy to initially display
  // this should be the slug of your default policy markdown file
  defaultPrivacyPolicySlug: '/privacy/en',

  supportEmail:
    process.env.NEXT_PUBLIC_SUPPORT_EMAIL ||
    'support-acentrik@mercedes-benz.com',

  customization: {
    theme: process.env.NEXT_PUBLIC_CUSTOMIZATION_THEME || 'light',
    dateFormat: 'DD MMM yyyy',
    defaultTheme: {
      fonts: process.env.NEXT_PUBLIC_FONTS || [
        'Noto Sans',
        'Arial',
        'Helvetica',
        'sans-serif'
      ]
    },
    bucket:
      process.env.NEXT_PUBLIC_AWS_S3_BUCKET_PUBLIC ||
      '#(NEXT_PUBLIC_AWS_S3_BUCKET_PUBLIC)#'
  }
}
