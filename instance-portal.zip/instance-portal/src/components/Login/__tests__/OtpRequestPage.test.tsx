/* eslint-disable testing-library/no-debugging-utils */
import React from 'react'
import { fireEvent, render, screen } from '@testing-library/react'
import OtpRequestPage from '../OtpRequestPage'

const mockRouterPush = jest.fn()
const formValues = {
  email: 'abc@test.com',
  password: 'AdinUserTest@123'
}

jest.mock('@core/context/UserPreferences', () => ({
  useUserPreferences: () => ({
    setAcceptCookies: jest.fn()
  })
}))

const setAuthSuccess = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    push: mockRouterPush
  })
}))

describe('Should render OTP request Page Form', () => {
  it('render otp request page without otp', async () => {
    render(
      <OtpRequestPage formValues={formValues} setAuthSuccess={setAuthSuccess} />
    )
    screen.logTestingPlaygroundURL()
    expect(await screen.findByText(/login verification/i)).toBeInTheDocument()
    expect(
      await screen.findByText(/a one-time password has been sent to/i)
    ).toBeInTheDocument()
    const verifyBtn = await screen.findByRole('button', {
      name: /verify/i
    })
    expect(verifyBtn).toBeInTheDocument()
    expect(verifyBtn).toBeDisabled()
    expect(
      await screen.findByText(/didn't receive an otp\?/i)
    ).toBeInTheDocument()
    const returnToLoginBtn = await screen.findByRole('button', {
      name: /return to login/i
    })
    expect(returnToLoginBtn).toBeInTheDocument()
  })
  it('render otp request page with otp', async () => {
    render(
      <OtpRequestPage formValues={formValues} setAuthSuccess={setAuthSuccess} />
    )
    expect(await screen.findByText(/login verification/i)).toBeInTheDocument()
    expect(
      await screen.findByText(/a one-time password has been sent to/i)
    ).toBeInTheDocument()
    const verifyBtn = await screen.findByRole('button', {
      name: /verify/i
    })
    const otpFields = await screen.findAllByRole('textbox')
    otpFields.forEach((field) => {
      fireEvent.change(field, { target: { value: '1' } })
    })
    expect(verifyBtn).toBeInTheDocument()
    expect(verifyBtn).toBeEnabled()
    expect(
      await screen.findByText(/didn't receive an otp\?/i)
    ).toBeInTheDocument()
    const returnToLoginBtn = await screen.findByRole('button', {
      name: /return to login/i
    })
    expect(returnToLoginBtn).toBeInTheDocument()
    screen.logTestingPlaygroundURL()
  })
})
