import { useCallback, useState } from 'react'
import axios from 'axios'
import { userLoginRes, UserLogin, LoginForm } from '../types/UserLogin'
import appConfig from 'app.config'
import { LoginFailed } from '@constants/constants'
import { onKeycloakToken } from '@utils/auth'
import { useUserPreferences } from '@core/context/UserPreferences'
import { useRouter } from 'next/router'
import { useAuthorize } from '@core/context/Authorize'

export interface UserLoginResponse {
  data: userLoginRes
}

export const userLoginApiUrl = `${appConfig.api}/user-management/api/v1/as/login-instance`
const resendOtpUrl = `${appConfig.api}/user-management/api/v1/as/resendOtp-instance`

export default function useUserLoginApi() {
  const { setRedirect } = useAuthorize()
  const [userLoginData, setUserLoginData] = useState<userLoginRes | null>(null)
  const [userLoginError, setUserLoginError] = useState<string | null>('')
  const [loading, setLoading] = useState(false)
  const { setAcceptCookies } = useUserPreferences()
  const router = useRouter()

  const userLogin = useCallback(
    async ({ loginInputs, setFieldError, otp, errorCallback }: UserLogin) => {
      if (loading) {
        return
      }
      try {
        setLoading(true)
        setUserLoginError('')
        const payload = otp ? { ...loginInputs, otp } : loginInputs
        const { data: response } = await axios.put<userLoginRes>(
          userLoginApiUrl,
          payload
        )
        if (!response?.otpRequired) {
          if (response && onKeycloakToken(response)) {
            setAcceptCookies(true)
            setRedirect((prev) => !prev)
          }
          setUserLoginData(response)
        }
        return response
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (errorCallback) {
            errorCallback(error)
          } else {
            setFieldError('password', LoginFailed.message)
            setUserLoginError(LoginFailed.message)
          }
        } else {
          setUserLoginError('unexpected error')
        }
      } finally {
        setLoading(false)
      }
    },
    []
  )

  const resendOTP = async (loginInputs: LoginForm): Promise<any> => {
    try {
      const { data: response } = await axios.put(resendOtpUrl, loginInputs)

      return response
    } catch (error) {
      console.log(error)
    }
  }

  return {
    userLoginData,
    userLoginError,
    setUserLoginData,
    userLogin,
    resendOTP
  }
}
