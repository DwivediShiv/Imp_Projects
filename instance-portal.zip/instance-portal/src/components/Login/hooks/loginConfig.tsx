import * as Yup from 'yup'
import { LoginForm } from '../types/UserLogin'

export const loginFormContent = {
  title: 'Login to your account',
  name: 'Login',
  fields: [
    {
      name: 'email',
      label: 'Business Email Address',
      placeholder: 'e.g. joedoe@email.com',
      help: 'Enter a business email address.',
      type: 'email',
      required: true
    },
    {
      name: 'password',
      label: 'Password',
      placeholder: 'My password',
      help: 'Input your login password',
      type: 'password',
      required: true
    }
  ]
}

export const initialValues: LoginForm = {
  email: '',
  password: ''
}

export const validationSchema: Yup.SchemaOf<LoginForm> = Yup.object().shape({
  email: Yup.string()
    .email('Please enter a valid email address.')
    .required('Required Field.'),
  password: Yup.string().required('Required Field.')
})
