import { rest } from 'msw'
import { server } from '@utils/msw'
import {
  ApiResponse,
  InvalidUser,
  MswHandlerProps,
  userLoginRes
} from '../types/UserLogin'
import { firstLogin, invalidCredData, userLoginData } from './userLoginData'
import appConfig from 'app.config'

export function setupGetUserDataHandler(props?: MswHandlerProps<userLoginRes>) {
  const statusCode = props?.status ?? 200
  const handler = rest.put(
    `${appConfig.api}/user-management/api/v1/as/login-instance`,
    async (_, res, ctx) => {
      let json: ApiResponse<userLoginRes>
      const data = firstLogin

      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}

export function setupInvalidUserDataHandler(
  props?: MswHandlerProps<InvalidUser>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.put(
    `${appConfig.api}/user-management/api/v1/as/login-instance`,
    async (_, res, ctx) => {
      let json: ApiResponse<InvalidUser>
      const data = invalidCredData

      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
