import { userLoginRes } from '../types/UserLogin'

export const userLoginData: userLoginRes = {
  access_token: '1',
  expires_in: 1,
  refresh_expires_in: 2,
  refresh_token: 'Sample Address',
  scope: 'www.nagarro.com',
  token_type: 'test@nagarro.com'
}

export const invalidCredData = {
  code: 'USER_AUTHENTICATION_FAILED',
  error: {
    message: 'User authentication failed.'
  }
}

export const firstLogin = {
  otpRequired: true
}
