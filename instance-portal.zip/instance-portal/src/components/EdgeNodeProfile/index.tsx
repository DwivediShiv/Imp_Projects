import React, { ReactElement, useEffect, useMemo } from 'react'
import styles from './index.module.css'
import { Grid } from '@mui/material'
import useCardConfig from './hooks/useCardConfig'
import useEdgeNodeApi from './hooks/useEdgeNodeApi'
import BackIcon from '@images/back_icon.svg'
import CustomButton from '@sharedComponents/Button'
import GridCard from '@sharedComponents/GridCard'
import { EDGE_NODE_STATE } from './constants'
import { useAuthorize } from '@core/context/Authorize'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_ADMIN,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import Warning from '../WarningMessage'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import { addC2dOperator } from '@utils/auth'

const EdgeNodeProfile = ({
  profileId
}: {
  profileId: string
}): ReactElement => {
  const { isLogin } = useAuthorize()

  const {
    publicEdgeNodeCards,
    privateEdgeNodeCards,
    handleBackClick,
    handleApprove,
    handleReject,
    validationSchema
  } = useCardConfig()

  const {
    fetchNodeProfile,
    nodeProfileData,
    setNodeProfUpdated,
    isNodeProfUpdated,
    nodeProfileError,
    nodeProfileErrorCode
  } = useEdgeNodeApi()

  useEffect(() => {
    if (isLogin) {
      fetchNodeProfile(profileId)
    }
  }, [fetchNodeProfile, isNodeProfUpdated, profileId, isLogin])

  const nodeCards = nodeProfileData?.private
    ? privateEdgeNodeCards
    : publicEdgeNodeCards

  function disableApprove() {
    let disable = false

    if (nodeProfileData?.state === EDGE_NODE_STATE.ACTIVE) {
      disable = true
    }

    return disable
  }

  function renderNodeProfileData() {
    if (nodeProfileError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = nodeProfileError

      const isUnauthorize = nodeProfileErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }
    if (!nodeProfileData) {
      return null
    }
    return (
      <>
        <Grid
          className={styles.content}
          container
          rowSpacing={4}
          columnSpacing={3}
        >
          {nodeProfileData?.private &&
            nodeProfileData?.state === EDGE_NODE_STATE.PENDING && (
              <Grid item xs={12} md={12} lg={9}>
                <div className={styles.head}>
                  <div className={styles.headerContainer}>
                    <div className={styles.companyHeader}>
                      <h2 title={nodeProfileData?.name} className={styles.name}>
                        {nodeProfileData?.name}
                      </h2>
                      <h3>Created on {nodeProfileData?.created_date}</h3>
                    </div>
                  </div>
                  <div className={styles.buttonContainer}>
                    <CustomButton
                      key="reject"
                      variant="outlined"
                      color="error"
                      onClick={() =>
                        handleReject(nodeProfileData?.id, setNodeProfUpdated)
                      }
                    >
                      Reject
                    </CustomButton>
                    <CustomButton
                      key="approve"
                      variant="contained"
                      color="primary"
                      className={styles.rightButton}
                      onClick={function () {
                        handleApprove(nodeProfileData?.id, setNodeProfUpdated)
                        addC2dOperator(
                          nodeProfileData.url,
                          nodeProfileData.network
                        )
                      }}
                      disabled={disableApprove()}
                    >
                      Approve
                    </CustomButton>
                  </div>
                </div>
              </Grid>
            )}
          {nodeCards.map((cardConfig, index) => {
            return (
              <Grid key={index} item xs={12} md={12} lg={9}>
                <GridCard
                  cardConfig={cardConfig}
                  data={nodeProfileData}
                  setStateData={setNodeProfUpdated}
                  validationSchema={validationSchema}
                />
              </Grid>
            )
          })}
        </Grid>
      </>
    )
  }
  return (
    <PrivateRoute>
      <>
        {!nodeProfileError && (
          <CustomButton onClick={handleBackClick} aria-label="Go Back">
            <BackIcon />
          </CustomButton>
        )}
        {renderNodeProfileData()}
      </>
    </PrivateRoute>
  )
}

export default EdgeNodeProfile
