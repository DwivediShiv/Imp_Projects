export interface NodeProfile {
  id: number | string
  name: string
  type: string
  url: string
  network: string
  active: boolean
  private: boolean
  provider_address: string
  owner: string
  created_date: string
  created_by: string
  edited_date: string
  edited_by: string
  state: string
  version: string
  approved_date: string
  approved_by: string
}
export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}
export interface EdgeNodeDetailsForm {
  edge_node_name: string
  edge_node_url: string
  edge_node_address: string
  edge_node_network: string
  edge_node_version: string
}
export interface EdgeNodeUrlResponse {
  providerAddress?: string
  version?: string
  chainId: number
}
export interface EdgeNodeDetailsInput {
  edge_node_name: string
  edge_node_url: string
}

export interface NodeResponse<T> {
  edge_node: T
}
export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
  nodeStatus?: string
  private?: boolean
}
export interface NodeState {
  active: boolean
  state: string
}
