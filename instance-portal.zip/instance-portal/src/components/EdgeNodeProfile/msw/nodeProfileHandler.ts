import { rest } from 'msw'
import { server } from '@utils/msw'
import {
  nodeProfileActive,
  nodeProfileInActive,
  nodeProfilePending,
  nodeProfileRejected,
  publicNodeProfileActive,
  publicNodeProfileInActive
} from './nodeProfileData'
import { MswHandlerProps, NodeProfile } from '../types/EdgeNodeProfile'
import { EDGE_NODE_STATE } from '../constants'
import appConfig from 'app.config'

export function setupGetNodeDataHandler(props?: MswHandlerProps<NodeProfile>) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(
    `${appConfig.api}/provider-management/api/v1/edge-node/24`,
    async (_, res, ctx) => {
      let json
      let data
      if (props?.nodeStatus === EDGE_NODE_STATE.ACTIVE) {
        data = props?.private ? nodeProfileActive : publicNodeProfileActive
      } else if (props?.nodeStatus === EDGE_NODE_STATE.INACTIVE) {
        data = props?.private ? nodeProfileInActive : publicNodeProfileInActive
      } else if (props?.nodeStatus === EDGE_NODE_STATE.PENDING) {
        data = nodeProfilePending
      } else if (props?.nodeStatus === EDGE_NODE_STATE.REJECTED) {
        data = nodeProfileRejected
      }

      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )

  server.use(handler)
}
