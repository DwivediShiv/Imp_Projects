export const nodeProfilePending = {
  edge_node: {
    id: 24,
    name: 'aa',
    type: 'org',
    url: 'https://v1.provider.sepolia.nagarro.acentrik.io/',
    network: 'Sepolia Testnet',
    active: false,
    private: true,
    provider_address: '0x149903E8E14103CF4913C451664748892726544A',
    owner: '5fc10191-41a8-4f34-8a44-3a2c2c6f3124',
    created_date: '26 Sep 2023',
    created_by: 'mariya.baig@nagarro.com',
    edited_date: '01 Jan 0001',
    edited_by: '',
    state: 'Pending',
    version: '1.3.12',
    approved_date: '0001-01-01T00:00:00Z',
    approved_by: ''
  },
  user_list: ['f94d3aab-a369-4942-b73b-dd086de963e0']
}
export const nodeProfileInActive = {
  edge_node: {
    id: 24,
    name: 'aa',
    type: 'org',
    url: 'https://v1.provider.sepolia.nagarro.acentrik.io/',
    network: 'Sepolia Testnet',
    active: false,
    private: true,
    provider_address: '0x149903E8E14103CF4913C451664748892726544A',
    owner: '5fc10191-41a8-4f34-8a44-3a2c2c6f3124',
    created_date: '26 Sep 2023',
    created_by: 'mariya.baig@nagarro.com',
    edited_date: '01 Jan 0001',
    edited_by: '',
    state: 'Inactive',
    version: '1.3.12',
    approved_date: '0001-01-01T00:00:00Z',
    approved_by: ''
  },
  user_list: ['f94d3aab-a369-4942-b73b-dd086de963e0']
}
export const nodeProfileActive = {
  edge_node: {
    id: 24,
    name: 'aa',
    type: 'org',
    url: 'https://v1.provider.sepolia.nagarro.acentrik.io/',
    network: 'Sepolia Testnet',
    active: true,
    private: true,
    provider_address: '0x149903E8E14103CF4913C451664748892726544A',
    owner: '5fc10191-41a8-4f34-8a44-3a2c2c6f3124',
    created_date: '26 Sep 2023',
    created_by: 'mariya.baig@nagarro.com',
    edited_date: '01 Jan 0001',
    edited_by: '',
    state: 'Active',
    version: '1.3.12',
    approved_date: '0001-01-01T00:00:00Z',
    approved_by: ''
  },
  user_list: ['f94d3aab-a369-4942-b73b-dd086de963e0']
}
export const nodeProfileRejected = {
  edge_node: {
    id: 24,
    name: 'aa',
    type: 'org',
    url: 'https://v1.provider.sepolia.nagarro.acentrik.io/',
    network: 'Sepolia Testnet',
    active: false,
    private: true,
    provider_address: '0x149903E8E14103CF4913C451664748892726544A',
    owner: '5fc10191-41a8-4f34-8a44-3a2c2c6f3124',
    created_date: '26 Sep 2023',
    created_by: 'mariya.baig@nagarro.com',
    edited_date: '01 Jan 0001',
    edited_by: '',
    state: 'Rejected',
    version: '1.3.12',
    approved_date: '0001-01-01T00:00:00Z',
    approved_by: ''
  },
  user_list: ['f94d3aab-a369-4942-b73b-dd086de963e0']
}

export const publicNodeProfileActive = {
  edge_node: {
    id: 24,
    name: 'aa',
    type: 'org',
    url: 'https://v1.provider.sepolia.nagarro.acentrik.io/',
    network: 'Sepolia Testnet',
    active: true,
    private: false,
    provider_address: '0x149903E8E14103CF4913C451664748892726544A',
    owner: '5fc10191-41a8-4f34-8a44-3a2c2c6f3124',
    created_date: '26 Sep 2023',
    created_by: 'mariya.baig@nagarro.com',
    edited_date: '01 Jan 0001',
    edited_by: '',
    state: 'Active',
    version: '1.3.12',
    approved_date: '0001-01-01T00:00:00Z',
    approved_by: ''
  },
  user_list: ['f94d3aab-a369-4942-b73b-dd086de963e0']
}
export const publicNodeProfileInActive = {
  edge_node: {
    id: 24,
    name: 'aa',
    type: 'org',
    url: 'https://v1.provider.sepolia.nagarro.acentrik.io/',
    network: 'Sepolia Testnet',
    active: true,
    private: false,
    provider_address: '0x149903E8E14103CF4913C451664748892726544A',
    owner: '5fc10191-41a8-4f34-8a44-3a2c2c6f3124',
    created_date: '26 Sep 2023',
    created_by: 'mariya.baig@nagarro.com',
    edited_date: '01 Jan 0001',
    edited_by: '',
    state: 'Inactive',
    version: '1.3.12',
    approved_date: '0001-01-01T00:00:00Z',
    approved_by: ''
  },
  user_list: ['f94d3aab-a369-4942-b73b-dd086de963e0']
}
