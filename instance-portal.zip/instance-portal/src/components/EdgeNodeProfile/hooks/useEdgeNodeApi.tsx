import axios from 'axios'
import { useCallback, useState } from 'react'
import {
  ApiResponse,
  EdgeNodeUrlResponse,
  NodeProfile,
  NodeResponse,
  NodeState
} from '../types/EdgeNodeProfile'
import appConfig from 'app.config'
import { convertDate } from '@utils/conversion'
import Toast from '@sharedComponents/Toast'
import { ERROR_UNAUTH, FAILURE_MESSAGES } from '@constants/permissionConstants'
import { USER_MESSAGES } from '@constants/modalConstant'

export const edgeNodeProfileUrl = `${appConfig.api}/provider-management/api/v1/edge-node`

export function getEdgeNodeUrl(id: string): string {
  return [edgeNodeProfileUrl, id].join('/')
}

export const updateNodeStateUrl = `${appConfig.api}/provider-management/api/v1/edge-node/update-state`
export function getupdateNodeStateUrl(id: string): string {
  return [updateNodeStateUrl, id].join('/')
}
export default function useEdgeNodeApi() {
  const [nodeProfileData, setNodeProfileData] = useState<NodeProfile>(null)
  const [isNodeProfUpdated, setNodeProfUpdated] = useState<boolean>(false)
  const [nodeProfileError, setNodeProfileError] = useState<string | null>('')
  const [nodeProfileErrorCode, setNodeProfileErrorCode] = useState<
    string | null
  >('')
  const fetchNodeProfile = useCallback(async (id: string) => {
    try {
      setNodeProfileError('')
      const { data: response } = await axios.get<
        ApiResponse<NodeResponse<NodeProfile>>
      >(getEdgeNodeUrl(id))

      response.data.edge_node.created_date = convertDate(
        response.data?.edge_node?.created_date,
        'DD MMM yyyy'
      )
      response.data.edge_node.edited_date = convertDate(
        response.data?.edge_node?.edited_date,
        'DD MMM yyyy'
      )

      setNodeProfileData(response.data?.edge_node)
    } catch (error) {
      setNodeProfileErrorCode(error?.response?.data?.code || 'General')

      setNodeProfileError(
        error?.response?.data?.error.message || FAILURE_MESSAGES.GENERAL_FAILURE
      )
    }
  }, [])
  const updateNodeProfile = useCallback(
    async (id: string, nodeProfile, successCallback, errorCallback) => {
      try {
        await axios.put<ApiResponse<string>>(getEdgeNodeUrl(id), nodeProfile)
        successCallback()
      } catch (error) {
        if (error.response && error.response.data?.code === ERROR_UNAUTH) {
          Toast('error', USER_MESSAGES.ERROR_UNAUTH_UPDATE_NODE)
        } else if (axios.isAxiosError(error)) {
          errorCallback(error)
        } else {
          errorCallback('unexpected error')
        }
      }
    },
    []
  )
  const updateNodeState = useCallback(
    async (id: string, state, successCallback, errorCallback) => {
      try {
        await axios.put<ApiResponse<NodeState>>(
          getupdateNodeStateUrl(id),
          state
        )
        successCallback()
      } catch (error) {
        if (error.response && error.response.data?.code === ERROR_UNAUTH) {
          Toast('error', USER_MESSAGES.ERROR_UNAUTH_UPDATE_NODE)
        } else if (axios.isAxiosError(error)) {
          errorCallback(error)
        } else {
          errorCallback('unexpected error')
        }
      }
    },
    []
  )

  const validateUrlData = async (edgeNodeUrl: string) => {
    const { data: response } = await axios.get<EdgeNodeUrlResponse>(edgeNodeUrl)
    return response
  }

  const fetchUrlData = async (
    edgeNodeUrl: string,
    setFieldValue,
    setFieldError,
    successBlurHandler,
    errorBlurHandler
  ) => {
    try {
      const response = await validateUrlData(edgeNodeUrl)
      if (successBlurHandler) {
        successBlurHandler(response, setFieldValue, setFieldError)
      }
    } catch (error) {
      errorBlurHandler(error, setFieldError)
    }
  }

  return {
    nodeProfileData,
    fetchNodeProfile,
    updateNodeProfile,
    isNodeProfUpdated,
    setNodeProfUpdated,
    nodeProfileError,
    nodeProfileErrorCode,
    updateNodeState,
    fetchUrlData,
    validateUrlData
  }
}
