import React, { useMemo, useState } from 'react'
import { EdgeNodeDetailsInput } from '../types/EdgeNodeProfile'
import styles from '../index.module.css'
import { IconColor, STATUS_CONSTANTS } from '@constants/constants'
import { useRouter } from 'next/router'
import Indicator from '@sharedComponents/Indicator'
import Copy from '@sharedComponents/Copy/Copy'
import Switch from '@sharedComponents/Switch'
import Modal from '@sharedComponents/Modal'
import {
  getNetworkDisplayName,
  getNetworkDisplayNames
} from '../../EdgeNodeAdd/utils/getNetworkDisplayName'
import useEdgeNodeApi from './useEdgeNodeApi'
import FancyToast from '@sharedComponents/Toast'
import {
  APPROVED_SUCCESSFULLY,
  EDGE_NODE_NAME_EXISTS,
  EDGE_NODE_NAME_URL_EXISTS,
  EDGE_NODE_STATE,
  INVALID_PROVIDER_URL,
  INVALID_URL_REGEX,
  REJECTED_SUCCESSFULLY,
  REQUIRED_EDGE_NODE_FIELD,
  UPDATED_SUCCESSFULLY
} from '../constants'
import * as Yup from 'yup'
import InputField from '@sharedComponents/InputField'
import { accountTruncate } from '@utils/conversion'
import { useOrganizationName } from '@hooks/useOrganizationName'
import CustomButton from '@sharedComponents/Button'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import NewStatusBox from '@sharedComponents/StatusFancy'

export function successBlurHandler(response, setFieldValue, setFieldError) {
  if (!response || !(response.chainId || response.chainIds)) {
    setFieldError('edge_node_url', INVALID_PROVIDER_URL)
    return
  }
  let networkDisplayName
  if (response.chainIds) {
    networkDisplayName = getNetworkDisplayNames(response.chainIds)
    setFieldValue(
      'edge_node_address',
      JSON.stringify(response.providerAddresses) || ''
    )
  } else {
    networkDisplayName = getNetworkDisplayName(response.chainId)
    setFieldValue('edge_node_address', response.providerAddress || '')
  }
  setFieldValue('edge_node_version', response.version || '')
  setFieldValue('edge_node_network', networkDisplayName || '')
}

export function errorBlurHandler(error, setFieldError) {
  setFieldError('edge_node_url', INVALID_PROVIDER_URL)
  console.log(error)
}

export default function useCardConfig() {
  const router = useRouter()
  const { updateNodeProfile, updateNodeState, fetchUrlData } = useEdgeNodeApi()
  const [showEdit, setShowEdit] = useState<boolean>(false)
  const [isStatusModalOpen, setStatusModalOpen] = useState(false)
  const { organizationMap } = useOrganizationName()

  const edgeNodeSuccessCallback = () =>
    FancyToast('success', UPDATED_SUCCESSFULLY)
  const edgeNodeApproveSuccessCallback = () =>
    FancyToast('success', APPROVED_SUCCESSFULLY)
  const edgeNodeRejectSuccessCallback = () =>
    FancyToast('success', REJECTED_SUCCESSFULLY)
  const edgeNodeErrorCallback = (error) => {
    const additionalData = error.response?.data?.error?.additionalData
    const errorMessage =
      additionalData &&
      (additionalData.includes(EDGE_NODE_NAME_EXISTS) ||
        additionalData.includes(EDGE_NODE_NAME_URL_EXISTS))
        ? additionalData
        : error.message
    FancyToast('error', errorMessage)
  }
  const handleBackClick = () => router.back()

  const handleApprove = async (nodeId, setNodeProfUpdated) => {
    await updateNodeState(
      nodeId,
      { state: EDGE_NODE_STATE.ACTIVE },
      edgeNodeApproveSuccessCallback,
      edgeNodeErrorCallback
    )
    setNodeProfUpdated((prev) => !prev)
  }

  const handleReject = async (nodeId, setNodeProfUpdated) => {
    await updateNodeState(
      nodeId,
      { state: EDGE_NODE_STATE.REJECTED },
      edgeNodeRejectSuccessCallback,
      edgeNodeErrorCallback
    )
    setNodeProfUpdated((prev) => !prev)
  }

  const validationSchema: Yup.SchemaOf<EdgeNodeDetailsInput> =
    Yup.object().shape({
      edge_node_name: Yup.string()
        .trim()
        .required(REQUIRED_EDGE_NODE_FIELD)
        .max(
          100,
          'Edge Node Name is too long, maximum length is 100 characters'
        )
        .matches(
          /^[a-zA-Z0-9\s]*$/,
          'Edge Node Name can only contain alphanumeric characters and spaces'
        ),
      edge_node_url: Yup.string()
        .trim()
        .required(REQUIRED_EDGE_NODE_FIELD)
        .max(100, 'URL is too long, maximum length is 100 characters')
        .url(INVALID_URL_REGEX)
    })

  async function onBlurHandler(
    e,
    handleBlur,
    setFieldValue,
    errors,
    dirty,
    values,
    setFieldError
  ) {
    handleBlur(e)
    if (
      dirty &&
      !(
        errors?.edge_node_url === INVALID_URL_REGEX ||
        errors?.edge_node_url === REQUIRED_EDGE_NODE_FIELD
      )
    ) {
      setFieldValue('edge_node_address', '')
      setFieldValue('edge_node_version', '')
      setFieldValue('edge_node_network', '')
      await fetchUrlData(
        values.edge_node_url,
        setFieldValue,
        setFieldError,
        successBlurHandler,
        errorBlurHandler
      )
    }
  }

  const onSwitchChange = async (event, id, isActive, setNodeProfUpdated) => {
    const state = {
      state: isActive ? EDGE_NODE_STATE.INACTIVE : EDGE_NODE_STATE.ACTIVE
    }
    await updateNodeState(
      id,
      state,
      edgeNodeSuccessCallback,
      edgeNodeErrorCallback
    )
    setNodeProfUpdated((prev) => !prev)
  }

  const renderStatusModal = (nodeProfile, isActive, setNodeProfUpdated) => {
    const status = nodeProfile.active
    const title = status ? 'Inactivate edge node' : 'Activate edge node'
    const text = status
      ? 'Do you wish to inactivate the edge node?'
      : 'Do you wish to activate the edge node?'
    return (
      <Modal
        type={CUSTOM_TYPE}
        title={title}
        titleSize="h3"
        onToggleModal={() => setStatusModalOpen(false)}
        isOpen={isStatusModalOpen}
      >
        {text}
        <div className={styles.footer}>
          <CustomButton
            color="primary"
            variant="contained"
            className={`mt-1 ${styles.confirmButton}`}
            onClick={(event) => {
              onSwitchChange(
                event,
                nodeProfile.id,
                isActive,
                setNodeProfUpdated
              )
              setStatusModalOpen(false)
            }}
          >
            Confirm
          </CustomButton>
        </div>
      </Modal>
    )
  }

  const StatusElement = ({ status }) => (
    <Indicator
      type="tag"
      variant={STATUS_CONSTANTS[status]?.variant}
      className={
        status === EDGE_NODE_STATE.INACTIVE && styles.inactiveIndicator
      }
    >
      {STATUS_CONSTANTS[status]?.title}
    </Indicator>
  )

  function statusElement(status) {
    const emailVerificationStatus = {
      true: { title: 'active', variant: 'success' },
      false: { title: 'inactive', variant: 'warning' }
    }
    return <NewStatusBox status={emailVerificationStatus[status].title} />
  }

  const switchElement = (nodeProfile, isEditActive, setNodeProfUpdated) => {
    let isActive = false
    setShowEdit(false)
    if (nodeProfile?.state === EDGE_NODE_STATE.ACTIVE) {
      isActive = true
      setShowEdit(true)
    }
    return (
      <div className={styles.customSwitch}>
        <Switch
          size="small"
          defaultChecked={false}
          checked={isActive}
          onChange={() => setStatusModalOpen(true)}
          disabled={isEditActive}
          label={statusElement(isActive)}
          className={isEditActive && styles.inactiveToggle}
        />
        {renderStatusModal(nodeProfile, isActive, setNodeProfUpdated)}
      </div>
    )
  }

  const publicEdgeNodeCards = useMemo(
    () => [
      {
        title: 'Information',
        isEditable: showEdit,
        fields: [
          {
            type: 'text',
            name: 'edge_node_name',
            previewTitle: 'Name',
            editActiveType: 'input',
            getValue: (nodeProfile) => nodeProfile?.name || ''
          },
          {
            name: 'edge_node_status',
            previewTitle: 'Status',
            getValue: (nodeProfile, isEditActive, setNodeProfUpdated) =>
              switchElement(nodeProfile, isEditActive, setNodeProfUpdated)
          },
          {
            type: 'text',
            name: 'edge_node_url',
            previewTitle: 'URL',
            editActiveType: 'custom',
            getValue: (nodeProfile) => nodeProfile?.url || '',
            getComponent: (props) => {
              const {
                field,
                setFieldValue,
                handleBlur,
                setFieldError,
                dirty,
                values,
                errors
              } = props
              field.onBlur = (e) =>
                onBlurHandler(
                  e,
                  handleBlur,
                  setFieldValue,
                  errors,
                  dirty,
                  values,
                  setFieldError
                )
              return <InputField {...props} field={field} type="text" />
            }
          },
          {
            type: 'text',
            name: 'edge_node_version',
            previewTitle: 'Version',
            editActiveType: 'input',
            disabled: true,
            getValue: (nodeProfile) => nodeProfile?.version || ''
          },
          {
            name: 'edge_node_type',
            previewTitle: 'Edge node type',
            getValue: (nodeProfile) =>
              nodeProfile?.private ? 'Private' : 'Public'
          },
          {
            type: 'text',
            name: 'edge_node_network',
            previewTitle: 'Blockchain network',
            editActiveType: 'input',
            disabled: true,
            getValue: (nodeProfile) => nodeProfile?.network || ''
          },
          {
            name: 'edge_node_created_by',
            previewTitle: 'Added by',
            getValue: (nodeProfile) => nodeProfile?.created_by || ''
          },
          {
            type: 'text',
            name: 'edge_node_address',
            previewTitle: 'Address',
            editActiveType: 'input',
            disabled: true,
            getValue: (nodeProfile) => (
              <div className={styles.addressContainer}>
                {accountTruncate(nodeProfile?.provider_address) || ''}
                <Copy
                  copyText={nodeProfile?.provider_address || ''}
                  color={IconColor.Primary}
                />
              </div>
            )
          }
        ],
        getDefaultValues: (nodeProfile) => ({
          edge_node_name: nodeProfile?.name,
          edge_node_url: nodeProfile?.url,
          edge_node_version: nodeProfile?.version,
          edge_node_network: nodeProfile?.network,
          edge_node_address: nodeProfile?.provider_address
        }),
        onSave: async (values, nodeProfile, setOrgProfUpdated) => {
          const data = {
            name: values.edge_node_name.trim(),
            url: values.edge_node_url,
            version: values.edge_node_version,
            network: values.edge_node_network,
            address: values.edge_node_address
          }
          await updateNodeProfile(
            nodeProfile?.id,
            data,
            edgeNodeSuccessCallback,
            edgeNodeErrorCallback
          )
          setOrgProfUpdated((prev) => !prev)
        },
        saveDisable: (values, dirty, errors) =>
          !values.edge_node_network ||
          !dirty ||
          Object.getOwnPropertyNames(errors).length > 0
      }
    ],
    [showEdit, isStatusModalOpen]
  )

  const privateEdgeNodeCards = useMemo(
    () => [
      {
        title: 'Edge Node Information',
        fields: [
          {
            name: 'edge_node_name',
            previewTitle: 'Name',
            getValue: (nodeProfile) => nodeProfile?.name || ''
          },
          {
            name: 'org_name',
            previewTitle: 'Group',
            getValue: (nodeProfile) =>
              organizationMap ? organizationMap[nodeProfile?.owner] || '' : ''
          },
          {
            name: 'verification_status',
            previewTitle: 'Status',
            getValue: (nodeProfile) => (
              <StatusElement status={nodeProfile?.state || 'Undefined'} />
            )
          },
          {
            name: 'edge_node_url',
            previewTitle: 'URL',
            getValue: (nodeProfile) => nodeProfile?.url || ''
          },
          {
            name: 'edge_node_version',
            previewTitle: 'Version',
            getValue: (nodeProfile) => nodeProfile?.version || ''
          },
          {
            name: 'edge_node_type',
            previewTitle: 'Edge node type',
            getValue: (nodeProfile) =>
              nodeProfile?.private ? 'Private' : 'Public'
          },
          {
            name: 'edge_node_network',
            previewTitle: 'Blockchain network',
            getValue: (nodeProfile) => nodeProfile?.network || ''
          },
          {
            name: 'edge_node_created_by',
            previewTitle: 'Created By',
            getValue: (nodeProfile) => nodeProfile?.created_by || ''
          },
          {
            name: 'edge_node_address',
            previewTitle: 'Address',
            getValue: (nodeProfile) => (
              <div className={styles.addressContainer}>
                {accountTruncate(nodeProfile?.provider_address) || ''}
                <Copy
                  copyText={nodeProfile?.provider_address || ''}
                  color={IconColor.Primary}
                />
              </div>
            )
          }
        ]
      }
    ],
    [organizationMap]
  )

  return {
    publicEdgeNodeCards,
    privateEdgeNodeCards,
    handleBackClick,
    handleApprove,
    handleReject,
    validationSchema
  }
}
