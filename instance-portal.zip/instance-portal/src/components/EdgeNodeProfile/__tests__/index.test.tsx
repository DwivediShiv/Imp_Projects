import React from 'react'
import { render, screen, waitFor } from '@testing-library/react'
import { useAuthorize, AuthorizeProviderValue } from '@core/context/Authorize'
import EdgeNodeProfile from '..'
import { setupGetNodeDataHandler } from '../msw/nodeProfileHandler'
import { EDGE_NODE_STATE } from '../constants'
import user from '@testing-library/user-event'

const mockRouterBack = jest.fn()

jest.mock('@core/context/FancyState', () => ({
  useFancyState: () => ({
    getOrganizationOptions: jest.fn()
  })
}))

interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack
  })
}))

jest.mock('@core/context/Authorize')

function renderComponent(options: RenderOptions, profileId: string) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin
  })

  render(<EdgeNodeProfile profileId={profileId} />)
}
describe('Edge Node profile ', () => {
  it('login component should render if unauthorized', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.ACTIVE,
      private: true
    })
    renderComponent(
      {
        authorize: {
          isLogin: false
        }
      },
      '24'
    )
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })
  it('component should render if authorized', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.ACTIVE,
      private: true
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )

    expect(await screen.findByText(/Blockchain network/i)).toBeInTheDocument()
    expect(await screen.findByText(/Name/i)).toBeInTheDocument()
    expect(await screen.findByText(/Group/i)).toBeInTheDocument()
    expect(await screen.findByText(/Status/i)).toBeInTheDocument()
    expect(await screen.findByText(/Address/i)).toBeInTheDocument()
    expect(
      await screen.findByText(
        `https://v1.provider.sepolia.nagarro.acentrik.io/`
      )
    ).toBeInTheDocument()
  })
  it('Edge node data should be displayed when status is Active and private edge node', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.ACTIVE,
      private: true
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )

    await waitFor(async () => {
      expect(await screen.findByText(/blockchain network/i)).toBeInTheDocument()
    })
    expect(await screen.findByText(/Active/i)).toBeInTheDocument()
  })
  it('Edge node data should be displayed when status is InActive and private edge node', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.INACTIVE,
      private: true
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )
    await waitFor(async () => {
      expect(screen.getByText(/Inactive/i)).toBeInTheDocument()
    })
  })
  it('Edge node data should be displayed when status is Pending and private edge node', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.PENDING,
      private: true
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )

    expect(await screen.findByText(/pending/i)).toBeInTheDocument()
    expect(await screen.findByText(/Address/i)).toBeInTheDocument()
    expect(await screen.findByText(/Name/i)).toBeInTheDocument()

    const rejectButton = await screen.findByRole('button', {
      name: /reject/i
    })
    const approveButton = await screen.findByRole('button', {
      name: /reject/i
    })
    expect(rejectButton).toBeInTheDocument()
    expect(approveButton).toBeInTheDocument()
    expect(rejectButton).toBeEnabled()
    expect(approveButton).toBeEnabled()
  })
  it('Edge node data should be displayed when status is Rejected and private edge node', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.REJECTED,
      private: true
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )
    expect(await screen.findByText(/rejected/i)).toBeInTheDocument()
    expect(await screen.findByText('Address')).toBeInTheDocument()
    expect(await screen.findByText('Name')).toBeInTheDocument()
  })
  it('Edge node data should be displayed when status is Active and public edge node', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.ACTIVE,
      private: false
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )
    expect(await screen.findByText('Blockchain network')).toBeInTheDocument()
    expect(await screen.findByText('active')).toBeInTheDocument()
    const activeToggle = await screen.findByRole('checkbox', {
      name: /active/i
    })
    expect(activeToggle).toBeInTheDocument()
    expect(activeToggle).toBeEnabled()
    expect(
      await screen.findByRole('cell', {
        name: /public/i
      })
    ).toBeInTheDocument()
    const editButton = await screen.findByRole('button', {
      name: /edit/i
    })
    expect(editButton).toBeInTheDocument()
    expect(editButton).toBeEnabled()
    await user.click(editButton)
    expect(activeToggle).toBeDisabled()
    const cancelButton = await screen.findByRole('button', {
      name: /cancel/i
    })
    const saveChanges = await screen.findByRole('button', {
      name: /save changes/i
    })
    expect(cancelButton).toBeInTheDocument()
    expect(saveChanges).toBeInTheDocument()
    expect(cancelButton).toBeEnabled()
    expect(saveChanges).toBeDisabled()

    await user.click(cancelButton)
    expect(
      await screen.findByRole('button', {
        name: /edit/i
      })
    ).toBeInTheDocument()
  })
  it('Edge node data should be displayed when status is InActive and public edge node', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.INACTIVE,
      private: false
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )
    expect(await screen.findByText('Blockchain network')).toBeInTheDocument()
    expect(await screen.findByText('inactive')).toBeInTheDocument()
    const activeToggle = await screen.findByRole('checkbox', {
      name: /active/i
    })
    expect(activeToggle).toBeInTheDocument()
    expect(activeToggle).toBeEnabled()
  })
  it('api errors should be handled', async () => {
    setupGetNodeDataHandler({
      response: {
        error: {
          message: 'BAD REQUEST'
        }
      },
      status: 400
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )
    expect(await screen.findByText(/Bad Request/i)).toBeInTheDocument()
  })
  it('handles back button', async () => {
    setupGetNodeDataHandler({
      nodeStatus: EDGE_NODE_STATE.ACTIVE,
      private: false
    })
    renderComponent(
      {
        authorize: {
          isLogin: true
        }
      },
      '24'
    )
    expect(await screen.findByText('Name')).toBeInTheDocument()

    const backButton = await screen.findByLabelText(/go back/i)
    await user.click(backButton)
    expect(mockRouterBack).toHaveBeenCalledTimes(1)
  })
})
