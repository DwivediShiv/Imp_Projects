export const EDGE_NODE_STATE = {
  ACTIVE: 'Active',
  REJECTED: 'Rejected',
  PENDING: 'Pending',
  INACTIVE: 'Inactive'
}

export const UPDATED_SUCCESSFULLY =
  'Successful. Edge Node changes have been updated.'
export const RESUBMIT_SUCCESSFULLY =
  'Successful. Edge Node has been Re-submitted and sent for approval.'

export const REJECTED_SUCCESSFULLY = 'Successful. Edge Node have been rejected.'
export const APPROVED_SUCCESSFULLY = 'Successful. Edge Node have been approved.'

export const INVALID_URL_NO_NETWORK = 'Invalid url! No network'
export const INVALID_PROVIDER_URL = 'Not a valid provider url!'
export const INVALID_URL_REGEX = `Not a valid url!`
export const EDGE_NODE_NAME_EXISTS = 'Edge Node Name already exists'
export const EDGE_NODE_NAME_URL_EXISTS = 'Edge node name or url already exists'
export const REQUIRED_EDGE_NODE_FIELD = `Required Field.`
