import React from 'react'
import usePasswordConfig, {
  initialValues,
  validationSchema
} from './hooks/usePasswordConfig'
import useForgetResetPwd from './hooks/useResetForgetPwd'
import SetPasswordForm from '@sharedComponents/SetPasswordForm'
import { ICON_TYPE } from '@constants/modalConstant'
import CustomModal from '@sharedComponents/Modal'
import styles from './index.module.css'

const ResetForgetPwd = ({
  actionToken
}: {
  actionToken: string | undefined
}) => {
  const { fulfilledPolicies, passwordConfig } = usePasswordConfig()
  const {
    handleSubmit,
    onModalClose,
    userEmail,
    loading,
    modalTemplate,
    openStatusModal
  } = useForgetResetPwd(actionToken)

  return (
    <>
      {!openStatusModal && (
        <SetPasswordForm
          content={passwordConfig}
          initialValues={initialValues}
          validationSchema={validationSchema}
          handleSubmit={handleSubmit}
          loading={loading}
          userEmail={userEmail}
          fulfilledPolicies={fulfilledPolicies}
        />
      )}
      <CustomModal
        className={styles.modal}
        type={ICON_TYPE}
        modalTemplate={modalTemplate}
        onToggleModal={onModalClose}
        isOpen={openStatusModal}
        buttonActionMain={onModalClose}
      />
    </>
  )
}

export default ResetForgetPwd
