import { useState } from 'react'
// import jwt from 'jwt-decode'
import useResetPwdApi from './useResetPwdApi'
import { ResetPasswordForm } from '@type/Form'
import { useRouter } from 'next/router'

const useForgetResetPwd = (actionToken) => {
  const { resetPassword } = useResetPwdApi()
  const [openStatusModal, setOpenStatusModal] = useState(false)
  const [modalTemplate, setModalTemplate] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const [userEmail, setUserEmail] = useState<string | undefined>()

  const actionTokenErrorCallback = () => {
    setModalTemplate('resetPasswordFailed')
    setLoading(false)
    setOpenStatusModal(true)
  }

  const forgetPwdResetSuccessCallback = () => {
    setLoading(false)
    router.push('/login?state=success&msg=Password updated successfully.')
  }

  const handleSubmit = async (
    values: Partial<ResetPasswordForm>,
    setFieldError: (field: string, errorMsg: string) => void,
    resetForm: () => void
  ): Promise<void> => {
    setLoading(true)
    const data = {
      password: values.password
    }
    // API call to accept invitation
    await resetPassword(
      actionToken,
      data,
      forgetPwdResetSuccessCallback,
      actionTokenErrorCallback
    )
    resetForm()
  }

  const onModalClose = () => {
    setOpenStatusModal(false)
    router.push('/login')
  }

  return {
    handleSubmit,
    onModalClose,
    userEmail,
    openStatusModal,
    modalTemplate,
    loading
  }
}

export default useForgetResetPwd
