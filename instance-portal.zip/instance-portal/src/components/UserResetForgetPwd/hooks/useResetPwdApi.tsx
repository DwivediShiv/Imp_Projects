import appConfig from 'app.config'
import axios from 'axios'
import { useCallback } from 'react'
const useResetPwdApi = () => {
  const postResetUserPwdUrl = `${appConfig.api}/user-management/api/v1/as/reset-password-instance`

  const resetPassword = useCallback(
    async (
      actionToken: string,
      data: { password: string },
      successCallback: any,
      errorCallback: any
    ) => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${actionToken}`
          }
        }
        const { data: response } = await axios.post(
          postResetUserPwdUrl,
          data,
          config
        )
        successCallback()
        return response
      } catch (error) {
        errorCallback()
      }
    },
    []
  )

  return {
    resetPassword
  }
}

export default useResetPwdApi
