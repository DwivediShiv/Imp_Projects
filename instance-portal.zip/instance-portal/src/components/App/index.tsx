import React, { ReactElement } from 'react'
import AuthorizeProvider from '@core/context/Authorize'
// import AcentrikLanding from '@instanceportal/libs/shared/layout/landingLayout'
import dynamic from 'next/dynamic'
import {
  isStaticPages,
  isWithoutHeaderFooterPages
} from '@utils/platformSetting'
import FancyStateProvider from '@core/context/FancyState'
import { applyAxiosInterceptor } from '@core/interceptor'
const LandingLayout = dynamic(
  () => import('@sharedComponents/Layout/LandingLayout'),
  {
    ssr: false
  }
)

applyAxiosInterceptor()

export default function App({
  children,
  ...props
}: {
  children: ReactElement
}): ReactElement {
  const isWithoutHeaderFooter = isWithoutHeaderFooterPages()
  const isStaticPage = isStaticPages()
  return (
    <AuthorizeProvider>
      <FancyStateProvider>
        <LandingLayout
          isWithoutHeaderFooter={isWithoutHeaderFooter}
          isStaticPage={isStaticPage}
          {...props}
        >
          {children}
        </LandingLayout>
        {/* <ThemeProvider theme={AccentrikDarkTheme}>{children}</ThemeProvider> */}
      </FancyStateProvider>
    </AuthorizeProvider>
  )
}
