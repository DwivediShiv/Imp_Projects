export interface OrgProfileFormValues {
  name_org_profile: string
  brNumber_org_profile: string
  address_org_profile: string
  website_org_profile: string
  remark_org_profile: string
  country_org_profile: string
  industry_org_profile: string
  business_email_org_profile: string
}
