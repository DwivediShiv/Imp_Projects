export interface OrgProfile {
  orgId: string
  name: string
  remark: string
  brNumber: string
  address: string
  website: string
  email: string
  industry: string
  country: string
  createdDate: string
  createdBy: string
  activatedOn: string
  logo: string
  companyName: string
  description: string
  businessNumber: string
  instanceRepresentativeId: string
  businessEmailId: string
  state: string
  id?: number
  verified?: boolean
  accountType?: string
  ssoEnabled?: boolean
}

export interface OrgProfileLogo {
  path: string
  preview: string
  contentType: string
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
  totalUsers?: number
  totalRecord?: number
  filterCriterias?: Record<string, string[]>
  code?: string
}

export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}

export interface OrgListFilters {
  orgId?: string
  email?: string
  filterUserRole?: string
  status?: string
  sortBy?: string
  sortOrder?: string
  filterCountry?: string
  filterUserBlocked?: string
}
export interface UserDetail {
  id: number
  org_id?: string
  email: string
  allowedRoles: string
  state?: string
  userInviteDate?: string
  createdBy?: string
  sortBy?: string
  sortOrder?: string
  createdDate?: string
  activatedOn?: string
  roles?: string
}
