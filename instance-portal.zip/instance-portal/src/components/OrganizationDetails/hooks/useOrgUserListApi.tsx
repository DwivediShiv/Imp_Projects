import { buildUrlWithQueryParams } from '@utils/url'
import { ERROR_MSG } from '@constants/constants'
import { ApiResponse, OrgListFilters, UserDetail } from '../types/OrgProfile'
import appConfig from 'app.config'
import axios from 'axios'
import { useCallback, useState } from 'react'
import Toast from '@sharedComponents/Toast'
import { USER_MESSAGES } from '@constants/modalConstant'
import { printErrorStack } from '@utils/index'
import { ERROR_UNAUTH } from '@constants/permissionConstants'

const useOrgUserListApi = () => {
  const [userListData, setUserListData] = useState<UserDetail[] | null>(null)
  const [userListError, setUserListError] = useState<string | null>('')
  const [userListErrorCode, setUserListErrorCode] = useState<string | null>('')
  const [userListTotal, setUserTotal] = useState<number>(0)
  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>()

  const userListUrl = `${appConfig.api}/user-management/api/v1/as/user-list`
  const fetchUserList = useCallback(
    async ({
      orgId,
      page,
      sortBy,
      sortOrder,
      searchValue,
      setIsLoading,
      filterUserRole,
      filterCountry,
      filterUserBlocked
    }) => {
      try {
        const urlParams: Record<string, string | string[]> = {}
        setUserListError('')
        setUserTotal(0)
        setIsLoading(true)

        if (orgId) {
          urlParams.orgId = orgId
        }

        if (page) {
          urlParams.page = page
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.email = searchValue
        }

        const filterUserRoleParam = Object.keys(filterUserRole).filter(
          (key) => filterUserRole[key]
        )

        if (filterUserRoleParam?.length) {
          urlParams.roles = filterUserRoleParam
        }

        const filterCountryParam = Object.keys(filterCountry).filter(
          (key) => filterCountry[key]
        )

        if (filterCountryParam?.length) {
          urlParams.countries = filterCountryParam
        }

        const filterUserBlockedParam = Object.keys(filterUserBlocked).filter(
          (key) => filterUserBlocked[key]
        )

        if (filterUserBlockedParam?.length) {
          urlParams.blocked = filterUserBlockedParam
        }

        // const userListApiUrl = buildUrlWithQueryParams(userListUrl, urlParams)
        const { data: response } = await axios.post<ApiResponse<UserDetail[]>>(
          userListUrl,
          urlParams
        )

        if (response.filterCriterias) {
          const { filterCriterias } = response
          filterCriterias.Blocked = ['true', 'false']
          setFilterCriterias(response.filterCriterias)
        }

        setUserListData(response.data)
        setUserTotal(response.totalRecord)
      } catch (error) {
        setUserListErrorCode(error?.response?.data?.code || 'General')
        if (axios.isAxiosError(error)) {
          setUserListError(error?.response?.data?.error)
        } else {
          setUserListError('unexpected error')
        }
      } finally {
        setIsLoading(false)
      }
    },
    []
  )

  const getExportUserUrlParams = ({
    email,
    orgId,
    filterUserRole,
    sortBy,
    sortOrder,
    filterCountry,
    filterUserBlocked
  }: OrgListFilters): any => {
    const urlParams: Record<string, string | string[]> = {}

    if (orgId) {
      urlParams.orgId = orgId
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    if (email !== '') {
      urlParams.email = email
    }

    const filterUserRoleParam = Object.keys(filterUserRole).filter(
      (key) => filterUserRole[key]
    )

    if (filterUserRoleParam?.length) {
      urlParams.roles = filterUserRoleParam
    }

    const filterCountryParam = Object.keys(filterCountry).filter(
      (key) => filterCountry[key]
    )

    if (filterCountryParam?.length) {
      urlParams.countries = filterCountryParam
    }

    const filterUserBlockedParam = Object.keys(filterUserBlocked).filter(
      (key) => filterUserBlocked[key]
    )

    if (filterUserBlockedParam?.length) {
      urlParams.blocked = filterUserBlockedParam
    }

    return urlParams
  }

  const exportUserList = async ({
    orgId,
    searchValue,
    filterUserRole,
    sortBy,
    sortOrder,
    filterCountry,
    filterUserBlocked
  }): Promise<string> => {
    try {
      const params = getExportUserUrlParams({
        orgId,
        email: searchValue,
        filterUserRole,
        sortBy,
        sortOrder,
        filterCountry,
        filterUserBlocked
      })
      const url = `${appConfig.api}/user-management/api/v1/as/user-list/export`
      const { data: response } = await axios.post(url, params)
      return response
    } catch (error) {
      console.log(error)
    }
  }

  const blockUser = async (profileId: string) => {
    try {
      const updateActiveStateUrl = `${appConfig.api}/user-management/api/v1/org/block-user/${profileId}`
      const { data: response } = await axios.put(updateActiveStateUrl)
      Toast('success', USER_MESSAGES.USER_BLOCKED)
    } catch (error) {
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH_BLOCK_USER)
      } else if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }

  const unblockUser = async (profileId: string) => {
    try {
      const updateActiveStateUrl = `${appConfig.api}/user-management/api/v1/org/unblock-user/${profileId}`
      const { data: response } = await axios.put(updateActiveStateUrl)
      Toast('success', USER_MESSAGES.USER_UNBLOCKED)
    } catch (error) {
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH_UNBLOCK_USER)
      } else if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }

  return {
    exportUserList,
    fetchUserList,
    userListData,
    userListError,
    userListErrorCode,
    userListTotal,
    filterCriterias,
    blockUser,
    unblockUser
  }
}

export default useOrgUserListApi
