import React, { ReactElement, useEffect, useMemo, useState } from 'react'
import {
  IconColor,
  IconSize,
  ENTER_VALID_EMAIL,
  MAX_100_CHAR_ALLOWED,
  MAX_500_CHAR_ALLOWED,
  MAX_50_CHAR_ALLOWED,
  REQUIRED_FIELD,
  STATE_ACTIVE,
  STATE_CONSTANTS,
  DEFAULT_ORG_FIELD_VALUES,
  GROUP_STATUS_CONSTANTS
} from '@constants/constants'
import * as Yup from 'yup'
import styles from '../index.module.css'
import Glob from '@images/global.svg'
import { OrgProfile } from '../types/OrgProfile'
import useOrgProfileApi from './useOrgProfileApi'
import { OrgProfileFormValues } from '../types/OrgProfileFormValues'
import IconNewTab from '@images/new_tab.svg'
import useUpload from '@hooks/useUploadS3/useUpload'
import OrgLogo from '@sharedComponents/OrgLogo'
import Toast from '@sharedComponents/Toast'
import CustomInput from '@sharedComponents/Input'
import CustomDropDown from '@sharedComponents/Dropdown'
import LinkButton from '@sharedComponents/LinkButton'
import appConfig from 'app.config'
import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import { UPDATE_ORG_PROFILE_MSG } from '@constants/modalConstant'
import Switch from '@sharedComponents/Switch'
import NewStatusBox from '@sharedComponents/StatusFancy'
import { ModalFieldValue } from '@type/Modal'

export default function useOrgProfile(totalUsers) {
  const [tabIndex, setTabIndex] = useState<number>(0)
  const { updateOrgProfile, updateInactiveOrg, orgProfileError } =
    useOrgProfileApi()
  const { updateFile } = useUpload()
  const [init, setInit] = useState<number>()
  const TimeWithCustomFormat = WithCustomFormat(Time)
  const [isOrgModalOpen, setOrgIsModalOpen] = useState(false)
  const [isEditable, setIsEditable] = useState(false)
  const [modalOrgFieldValue, setModalOrgFieldValue] = useState<ModalFieldValue>(
    {
      heading: '',
      subheading: null
    }
  )
  useEffect(() => {
    if (orgProfileError) {
      Toast('error', orgProfileError)
    } else if (orgProfileError === null) {
      Toast('success', UPDATE_ORG_PROFILE_MSG.SUCCESS)
    }
  }, [orgProfileError])

  const onInActiveToggle = async (
    event: React.ChangeEvent<HTMLInputElement>,
    orgProfile: OrgProfile
  ) => {
    setOrgIsModalOpen(true)
    const active = orgProfile?.state === STATE_CONSTANTS.ACTIVE
    setModalOrgFieldValue({
      heading: active ? 'Disable Organization' : 'Enable Organization',
      subheading: `Are you sure you want to ${
        active ? 'disable' : 'enable'
      } the organization?`,
      value: orgProfile.orgId,
      handleSubmit: async () => {
        await updateInactiveOrg(orgProfile.orgId)
        setInit(Math.random())
        setOrgIsModalOpen(false)
      }
    })
  }

  function statusElement(status: string): ReactElement {
    return <NewStatusBox status={status} />
  }

  const validationSchema: Yup.SchemaOf<OrgProfileFormValues> =
    Yup.object().shape({
      name_org_profile: Yup.string()
        .trim()

        .required(REQUIRED_FIELD)
        .max(100, MAX_100_CHAR_ALLOWED)
        .matches(/^(?=.*[a-zA-Z0-9]).*$/, {
          message: 'Only special characters are not allowed.'
        }),

      remark_org_profile: Yup.string()
        .trim()
        .required(REQUIRED_FIELD)
        .max(500, MAX_500_CHAR_ALLOWED)
        .matches(/^(?=.*[a-zA-Z0-9]).*$/, {
          message: 'Only special characters are not allowed.'
        }),
      brNumber_org_profile: Yup.string()
        .trim()
        .required(REQUIRED_FIELD)
        .matches(/^[a-zA-Z0-9_\s]*$/, {
          message: 'Please enter correct Business Number.'
        })
        .max(50, MAX_50_CHAR_ALLOWED),
      business_email_org_profile: Yup.string()
        .email(ENTER_VALID_EMAIL)
        .required(REQUIRED_FIELD),
      address_org_profile: Yup.string()
        .trim()
        .required(REQUIRED_FIELD)
        .matches(/.*[a-zA-Z0-9-].*/, {
          message: 'Only special characters are not allowed.'
        })
        .max(500, MAX_500_CHAR_ALLOWED),
      country_org_profile: Yup.string().required(REQUIRED_FIELD),
      industry_org_profile: Yup.string().required(REQUIRED_FIELD),
      website_org_profile: Yup.string()
        .trim()
        .required(REQUIRED_FIELD)
        .matches(
          /^(https?:\/\/)?([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/)?$/,
          'Please enter correct Website.'
        )
        .max(500, MAX_500_CHAR_ALLOWED)
    })

  const orgCards = useMemo(
    () => [
      {
        title: 'Logo',
        isEditable,
        cardType: 'custom_component',
        componentName: 'company_logo',
        getComponent: (props) => {
          return <OrgLogo {...props} width={220} height={180} />
        },

        onSave: async (values, orgProfile, setOrgProfUpdated) => {
          const file = values.company_logo[0]
          const name = 'logo'
          const organization = orgProfile.orgId
          const url = await updateFile(file, name, organization)
          if (url) {
            const data: Partial<OrgProfile> = {
              logo: url
            }
            await updateOrgProfile(orgProfile?.orgId, data)
            setOrgProfUpdated((prev) => !prev)
          } else {
            Toast('error', 'Unable to upload logo. Please try again later.')
          }
          return 'success'
        }
      },
      {
        title: 'Information',
        isEditable,
        fields: [
          {
            type: 'text',
            name: 'name_org_profile',
            previewTitle: 'Name',
            editActiveType: 'custom',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.name || ''
            },
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return isEditActive ? (
                <CustomInput
                  inputName={inputName}
                  error={hasError}
                  disabled={disabled}
                  type="text"
                  isValid={!excludedValid && !!isValid}
                  {...field}
                />
              ) : (
                data?.name
              )
            }
          },
          {
            type: 'text',
            name: 'state',
            previewTitle: 'Status',
            getValue: (orgProfile: OrgProfile, isEditActive: boolean) => {
              if (![STATE_CONSTANTS.REJECTED].includes(orgProfile?.state)) {
                setIsEditable(true)
              }

              return (
                <>
                  {![
                    STATE_CONSTANTS.INVITED,
                    STATE_CONSTANTS.REJECTED
                  ].includes(orgProfile?.state) && (
                    <Switch
                      size="small"
                      defaultChecked={false}
                      checked={orgProfile?.state === STATE_CONSTANTS.ACTIVE}
                      onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
                        onInActiveToggle(event, orgProfile)
                      }
                      disabled={
                        isEditActive ||
                        orgProfile?.state === STATE_CONSTANTS.INVITED
                      }
                      label={''}
                    />
                  )}
                  {statusElement(orgProfile?.state?.toLowerCase())}
                </>
              )
            }
          },
          {
            type: 'text',
            name: 'remark_org_profile',
            previewTitle: 'Description',
            editActiveType: 'custom',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.remark || ''
            },
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return isEditActive ? (
                <CustomInput
                  inputName={inputName}
                  error={hasError}
                  disabled={disabled}
                  type="text"
                  isValid={!excludedValid && !!isValid}
                  {...field}
                />
              ) : (
                data?.remark
              )
            }
          },
          {
            type: 'text',
            name: 'brNumber_org_profile',
            previewTitle: 'Reference number',
            editActiveType: 'custom',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.brNumber || ''
            },
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return isEditActive ? (
                <CustomInput
                  inputName={name}
                  error={hasError}
                  disabled={disabled}
                  type="text"
                  isValid={!excludedValid && !!isValid}
                  {...field}
                />
              ) : (
                data?.brNumber
              )
            }
          },
          {
            type: 'text',
            name: 'business_email_org_profile',
            previewTitle: 'Support email',
            editActiveType: 'custom',
            getValue: (orgProfille: OrgProfile) => {
              return orgProfille?.email || ''
            },
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return isEditActive ? (
                <CustomInput
                  inputName={name}
                  error={hasError}
                  disabled={disabled}
                  type="text"
                  isValid={!excludedValid && !!isValid}
                  {...field}
                />
              ) : (
                data?.email
              )
            }
          },
          {
            type: 'text',
            name: 'address_org_profile',
            previewTitle: 'Address',
            editActiveType: 'custom',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.address || ''
            },
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return isEditActive ? (
                <CustomInput
                  inputName={inputName}
                  error={hasError}
                  disabled={disabled}
                  type="text"
                  isValid={!excludedValid && !!isValid}
                  {...field}
                />
              ) : (
                data?.address
              )
            }
          },
          {
            type: 'text',
            name: 'industry_org_profile',
            previewTitle: 'Industry',
            editActiveType: 'custom',
            getValue: (orgProfile: OrgProfile) => orgProfile?.industry,
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return isEditActive ? (
                <CustomDropDown
                  inputName={inputName}
                  optionCategory="Industry"
                  error={hasError}
                  isValid={!excludedValid && !!isValid}
                  disabled={disabled}
                  {...field}
                />
              ) : (
                data?.country
              )
            }
          },
          {
            type: 'text',
            name: 'country_org_profile',
            previewTitle: 'Country',
            editActiveType: 'custom',
            getValue: (orgProfile: OrgProfile) => (
              <div>
                <span>
                  <Glob className={styles.emojiFlag} />
                </span>
                {orgProfile?.country}
              </div>
            ),
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return isEditActive ? (
                <CustomDropDown
                  inputName={inputName}
                  optionCategory="FullCountry"
                  error={hasError}
                  isValid={!excludedValid && !!isValid}
                  disabled={disabled}
                  {...field}
                />
              ) : (
                data?.country
              )
            }
          },
          {
            type: 'text',
            name: 'company_reg_on',
            previewTitle: 'Registration date',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.createdDate ? (
                <TimeWithCustomFormat
                  date={orgProfile?.createdDate}
                  customFormat={appConfig.customization.dateFormat}
                />
              ) : (
                ''
              )
            }
          },
          {
            type: 'text',
            name: 'createdBy_org_profile',
            previewTitle: 'Registered by',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.createdBy || ''
            }
          },
          {
            type: 'text',
            name: 'company_active_on',
            previewTitle: 'Activation date',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.activatedOn ? (
                <TimeWithCustomFormat
                  date={orgProfile?.activatedOn}
                  customFormat={appConfig.customization.dateFormat}
                />
              ) : (
                ''
              )
            }
          },
          {
            type: 'text',
            name: 'contact_email_address',
            previewTitle: 'Primary admin email',
            getValue: (orgProfille: OrgProfile) => {
              return orgProfille?.instanceRepresentativeId || ''
            }
          }
        ],
        getDefaultValues: (orgProfile: OrgProfile) => {
          return {
            name_org_profile: orgProfile?.name,
            brNumber_org_profile: orgProfile?.brNumber,
            website_org_profile: orgProfile?.website,
            remark_org_profile: orgProfile?.remark,
            address_org_profile: orgProfile?.address,
            industry_org_profile: orgProfile?.industry,
            country_org_profile: orgProfile?.country,
            business_email_org_profile: orgProfile?.email
          }
        },
        onSave: async (
          values: OrgProfileFormValues,
          orgProfile: OrgProfile,
          setOrgProfUpdated
        ) => {
          const data: Partial<OrgProfile> = {
            companyName: values.name_org_profile.trim(),
            description: values.remark_org_profile,
            businessNumber: values.brNumber_org_profile,
            address:
              values.address_org_profile === DEFAULT_ORG_FIELD_VALUES.BLANK
                ? DEFAULT_ORG_FIELD_VALUES.ADDRESS
                : values.address_org_profile,
            website: values.website_org_profile,
            remark: values.remark_org_profile,
            country: values.country_org_profile,
            industry:
              values.industry_org_profile === DEFAULT_ORG_FIELD_VALUES.BLANK
                ? DEFAULT_ORG_FIELD_VALUES.INDUSTRY
                : values.industry_org_profile,
            businessEmailId: values.business_email_org_profile
          }
          await updateOrgProfile(orgProfile?.orgId, data)
          setOrgProfUpdated((prev) => !prev)
          return 'success'
        }
      },
      {
        title: 'SSO configuration',
        isEditable: false,
        fields: [
          {
            type: 'text',
            name: 'sso_status',
            previewTitle: 'SSO status',
            getValue: (orgProfile: OrgProfile) => {
              return orgProfile?.ssoEnabled
                ? GROUP_STATUS_CONSTANTS.ENABLE
                : GROUP_STATUS_CONSTANTS.DISABLE
            }
          }
        ]
      }
    ],
    [updateOrgProfile, updateFile, isEditable]
  )

  const tabs = useMemo(
    () => [
      {
        title: 'Details',
        value: 'details',
        index: 0
      },
      {
        title: `Users`,
        value: 'userList',
        index: 1
      }
    ],
    [totalUsers]
  )

  const handleTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setTabIndex(newValue)
  }

  return {
    orgCards,
    validationSchema,
    tabs,
    handleTabChange,
    tabIndex,
    init,
    isOrgModalOpen,
    setOrgIsModalOpen,
    modalOrgFieldValue
  }
}
