import { SELECTION_CONSTANTS, STATE_CONSTANTS } from '@constants/constants'
import appConfig from 'app.config'
import React, { useMemo, useState } from 'react'
import useOrgUserListApi from './useOrgUserListApi'
import { ModalFieldValue } from '@type/Modal'
import { hasSelection } from '@sharedComponents/CustomTableList/hook/useCustomTableList'

const boolOptions = { Blocked: false, Unblocked: false }
const useOrgUserList = (orgId, orgState) => {
  const [searchValue, setSearchValue] = useState<string>('')
  const [filterUserRole, setFilterUserRole] = useState<Record<string, boolean>>(
    {}
  )
  const [filterUserBlocked, setFilterUserBlocked] = useState<
    Record<string, boolean>
  >({})
  const [filterCountry, setFilterCountry] = useState<Record<string, boolean>>(
    {}
  )
  const [page, setPage] = useState(1)
  const [sortBy, setSortBy] = useState<string>('')
  const [sortOrder, setSortOrder] = useState<string>('')
  const [sortValue, setsortValue] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>()
  const [initUser, setInitUser] = useState<number>()
  const { exportUserList, blockUser, unblockUser } = useOrgUserListApi()
  const [refreshList, setRefreshList] = useState<number>(0)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalFieldValue, setModalFieldValue] = useState<ModalFieldValue>({
    heading: '',
    subheading: null
  })

  const handleClearFilter = () => {
    setPage(1)
    setSearchValue('')
    setFilterUserRole({})
    setFilterUserBlocked({})
    setFilterCountry({})
    // setSortBy('')
    // setSortOrder('')
  }

  const handleOnSearch = (e) => {
    setPage(1)
    setSearchValue(e.target.value)
  }

  const handleFilterSelect = (
    items: Record<string, boolean>,
    type: 'Role' | 'Blocked' | 'Country'
  ) => {
    setPage(1)
    switch (type) {
      case 'Role':
        setFilterUserRole(items)
        break
      case 'Blocked':
        setFilterUserBlocked(items)
        break
      case 'Country':
        setFilterCountry(items)
        break
    }
  }

  const handlePageChange = (page) => {
    setPage(page)
  }

  async function onAction(row, type) {
    switch (type) {
      case 'unblock':
        setModalFieldValue({
          heading: 'Unblock User',
          subheading: 'Are you sure you want to unblock the user?',
          value: row,
          handleSubmit: async () => {
            await unblockUser(row.profileId)
            setIsModalOpen(false)
            setInitUser(Math.random())
          }
        })
        break
      case 'block':
        setModalFieldValue({
          heading: 'Block User',
          subheading: 'Are you sure you want to block the user?',
          value: row,
          handleSubmit: async () => {
            await blockUser(row.profileId)
            setIsModalOpen(false)
            setInitUser(Math.random())
          }
        })
        break
      default:
        setModalFieldValue({
          heading: '',
          subheading: '',
          value: '',
          handleSubmit: ''
        })
        break
    }

    setIsModalOpen(true)
  }

  const userListConfig = useMemo(() => {
    return {
      title: '',
      sortConfig: {
        type: 'fancySort',
        sortOptions: [
          {
            name: 'User Email: A-Z',
            value: 'email-asc'
          },
          {
            name: 'User Email: Z-A',
            value: 'email-desc'
          },
          {
            name: 'Roles: A-Z',
            value: 'allowed_roles-asc'
          },
          {
            name: 'Roles: Z-A',
            value: 'allowed_roles-desc'
          },
          {
            name: 'Invited On: Newest first',
            value: 'created_date-desc'
          },
          {
            name: 'Invited On: Oldest first',
            value: 'created_date-asc'
          },
          {
            name: 'Invited By: A-Z',
            value: 'created_by-asc'
          },
          {
            name: 'Invited By: Z-A',
            value: 'created_by-desc'
          },
          {
            name: 'Status: A-Z',
            value: 'state-asc'
          },
          {
            name: 'Status: Z-A',
            value: 'state-desc'
          }
        ]
      },
      searchConfig: {
        type: 'search',
        name: 'search',
        placeholder: 'Search',
        searchValue
      },
      exportConfig: {
        exportFn: () =>
          exportUserList({
            orgId,
            searchValue,
            filterUserRole,
            sortBy,
            sortOrder,
            filterCountry,
            filterUserBlocked
          }),
        fileName: 'userList.csv'
      },
      refreshConfig: {
        name: 'Refresh list',
        handleRefreshList: () => setRefreshList(Math.random())
      },
      columns: [
        {
          id: 'email',
          title: 'Email address',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'email',
          class: 'email',
          rowConfig: {
            cellType: 'default',
            value: 'email'
          },
          width: '341px',
          sortField: 'email'
        },
        {
          id: 'allowedRoles',
          title: 'Roles',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'allowedRoles',
          class: 'allowed_roles',
          rowConfig: {
            cellType: 'roleField',
            value: 'allowedRoles',
            clickable: 'false',
            class: 'allowedRolesColumn'
          },
          width: '180px',
          sortField: 'allowed_roles'
        },
        {
          id: 'createdDate',
          title: 'Invitation date',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'createdDate',
          class: 'createdDate',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'createdDate',
            class: 'createdDateColumn'
          },
          width: '110px',
          sortField: 'created_date',
          allowOverflow: false
        },
        {
          id: 'createdBy',
          title: 'Invited by',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'createdBy',
          rowConfig: {
            cellType: 'default',
            value: 'createdBy',
            class: 'createdByColumn'
          },
          width: '224px',
          sortField: 'created_by',
          allowOverflow: false
        },
        {
          id: 'country',
          title: 'Country',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'country',
          rowConfig: {
            cellType: 'default',
            value: 'country',
            class: 'countryColumn'
          },
          width: '124px',
          sortField: 'state',
          allowOverflow: false
        },
        {
          id: 'state',
          title: 'Status',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'state',
          rowConfig: {
            cellType: 'fancyStatusField',
            value: 'state',
            class: 'statusColumn'
          },
          width: '110px',
          sortField: 'state',
          allowOverflow: false
        },
        {
          id: 'actions',
          title: 'Actions',
          type: 'tableHeader',
          sortable: false,
          rowConfig: {
            cellType: 'actions',
            actions: [
              {
                type: 'text',
                label: 'UnBlock',
                hidden: (row: any) => {
                  return (
                    !row.blocked ||
                    row.state === STATE_CONSTANTS.INVITED ||
                    row.state === STATE_CONSTANTS.INACTIVE ||
                    orgState !== STATE_CONSTANTS.ACTIVE
                  )
                },
                clickable: () => {
                  return orgState === STATE_CONSTANTS.ACTIVE
                },
                onClick: (row: any) => {
                  onAction(row, 'unblock')
                }
              },
              {
                type: 'text',
                label: 'Block',
                hidden: (row: any) => {
                  return (
                    row.blocked ||
                    row.state === STATE_CONSTANTS.INVITED ||
                    row.state === STATE_CONSTANTS.INACTIVE ||
                    orgState !== STATE_CONSTANTS.ACTIVE
                  )
                },
                clickable: (row: any) => {
                  return orgState === STATE_CONSTANTS.ACTIVE
                },
                onClick: (row: any) => {
                  onAction(row, 'block')
                }
              }
            ]
          },
          width: '90px',
          allowOverflow: false
        }
      ],
      filterConfig: {
        clearFilters: handleClearFilter,
        filters: [
          {
            id: 'Roles',
            inputName: 'Roles',
            label: 'Roles',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterUserRole,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterUserRole,
            onChange: (items) => handleFilterSelect(items, 'Role')
          },
          {
            id: 'Country',
            inputName: 'Country',
            label: 'Country',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterCountry,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterCountry,
            onChange: (items) => handleFilterSelect(items, 'Country')
          },
          {
            id: 'Blocked',
            inputName: 'Blocked',
            label: 'Blocked users',
            dynamic: true,
            value: filterUserBlocked,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterUserBlocked,
            onChange: (items) => handleFilterSelect(items, 'Blocked')
          }
        ]
      }
    }
  }, [
    searchValue,
    filterUserRole,
    filterCountry,
    filterUserBlocked,
    sortBy,
    sortOrder,
    orgState
  ])

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    setSortBy(column.sortField)
    setSortOrder(sortDirection)
  }

  const handleSortOption = async (sortOption: string) => {
    setsortValue(sortOption)
    const sortSelection = sortOption.split('-')
    setSortBy(sortSelection[0])
    setSortOrder(sortSelection[1])
  }

  const hasFilterApplied = () => {
    return (
      searchValue !== '' ||
      hasSelection(filterCountry) ||
      hasSelection(filterUserRole) ||
      hasSelection(filterUserBlocked)
    )
  }

  return {
    userListConfig,
    sortBy,
    sortOrder,
    sortValue,
    handlePageChange,
    page,
    handleSortChange,
    handleSortOption,
    handleOnSearch,
    searchValue,
    hasFilterApplied,
    setIsLoading,
    isLoading,
    isModalOpen,
    setIsModalOpen,
    modalFieldValue,
    filterCountry,
    filterUserRole,
    filterUserBlocked,
    initUser,
    refreshList
  }
}

export default useOrgUserList
