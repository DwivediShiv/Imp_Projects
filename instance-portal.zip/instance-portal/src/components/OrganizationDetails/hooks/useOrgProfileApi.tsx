import { useCallback, useState } from 'react'
import axios from 'axios'
import { ApiResponse, OrgProfile } from '../types/OrgProfile'
import appConfig from 'app.config'
import { UPDATE_ORG_PROFILE_MSG } from '@constants/modalConstant'
import { FAILURE_MESSAGES } from '@constants/permissionConstants'
import { DEFAULT_ORG_FIELD_VALUES } from '@constants/constants'

export interface OrgProfileResponse {
  data: OrgProfile
}

export const orgProfileApiUrl = `${appConfig.api}/user-management/api/v1/org`

export function orgProfileUpdateUrl(orgId: string, joinBy: string): string {
  return [orgProfileApiUrl, orgId].join(`/${joinBy}`)
}

export function orgProfileInactiveUrl(orgId: string): string {
  return orgProfileApiUrl + `/update-state/${orgId}`
}

export default function useOrgProfileApi() {
  const [orgProfileData, setOrgProfileData] = useState<OrgProfile | null>(null)
  const [orgProfileError, setOrgProfileError] = useState<string | null>('')
  const [orgProfileErrorCode, setOrgProfileErrorCode] = useState<string | null>(
    ''
  )
  const [isOrgProfUpdated, setOrgProfUpdated] = useState<boolean>(false)
  const [totalUsers, setTotalUsers] = useState<number>(0)

  const fetchOrgProfile = useCallback(async (orgId: string) => {
    try {
      setOrgProfileError('')
      const { data: response } = await axios.get<ApiResponse<OrgProfile>>(
        `${orgProfileApiUrl}\\${orgId}`
      )
      const transformedResp = {
        ...response.data,
        industry:
          response.data?.industry === DEFAULT_ORG_FIELD_VALUES.INDUSTRY
            ? DEFAULT_ORG_FIELD_VALUES.BLANK
            : response.data?.industry,
        address:
          response.data?.address === DEFAULT_ORG_FIELD_VALUES.ADDRESS
            ? DEFAULT_ORG_FIELD_VALUES.BLANK
            : response.data?.address
      }

      setOrgProfileData(transformedResp)
      setTotalUsers(response.totalUsers)
    } catch (error) {
      setOrgProfileErrorCode(error?.response?.data?.code || 'General')
      setOrgProfileError(
        error?.response?.data?.error.message || FAILURE_MESSAGES.GENERAL_FAILURE
      )
    }
  }, [])

  const updateOrgProfile = useCallback(
    async (orgID: string, orgProfile: Partial<OrgProfile>) => {
      try {
        let joinBy = ''
        setOrgProfileError('')
        if (orgProfile.logo) {
          joinBy = 'logo/'
        }
        const { data: response } = await axios.put<ApiResponse<OrgProfile>>(
          orgProfileUpdateUrl(orgID, joinBy),
          orgProfile
        )
        setOrgProfileError(null)
        return response.data
      } catch (error) {
        if (axios.isAxiosError(error)) {
          const {
            message = UPDATE_ORG_PROFILE_MSG.ERROR,
            additionalData = {}
          } = error?.response?.data?.error ?? {}
          const additionalErrors = Object.values(additionalData)
          setOrgProfileError(
            additionalErrors?.length ? additionalErrors[0] : message
          )
        } else {
          setOrgProfileError('Unexpected error ocurred')
        }
      }
    },
    []
  )

  const updateInactiveOrg = useCallback(async (orgID: string) => {
    try {
      setOrgProfileError('')
      const { data: response } = await axios.put<ApiResponse<any>>(
        orgProfileInactiveUrl(orgID)
      )
      setOrgProfileError(null)
      return response.data
    } catch (error) {
      let message = UPDATE_ORG_PROFILE_MSG.ERROR
      if (error.response?.data?.error?.additionalData) {
        message = error.response?.data?.error?.additionalData
        setOrgProfileError(message)
      } else if (axios.isAxiosError(error)) {
        const { additionalData = {} } = error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        message = additionalErrors?.length
          ? (additionalErrors[0] as string)
          : message
        setOrgProfileError(message)
      } else {
        setOrgProfileError('Unexpected error ocurred')
      }
    }
  }, [])

  return {
    orgProfileData,
    orgProfileError,
    orgProfileErrorCode,
    setOrgProfileData,
    fetchOrgProfile,
    updateOrgProfile,
    updateInactiveOrg,
    setOrgProfUpdated,
    isOrgProfUpdated,
    totalUsers
  }
}
