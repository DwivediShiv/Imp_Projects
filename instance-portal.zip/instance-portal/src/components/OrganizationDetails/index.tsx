import React, { ReactElement, useCallback, useEffect, useState } from 'react'
import { Grid } from '@mui/material'

import styles from './index.module.css'
import { useRouter } from 'next/router'
import BackIcon from '@images/back_icon.svg'
import useOrgProfileApi from './hooks/useOrgProfileApi'
import { useAuthorize } from '@core/context/Authorize'
import useOrgProfile from './hooks/useOrgProfile'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_ADMIN,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import Button from '@sharedComponents/Button'
import Permission from '@sharedComponents/Permission'
import GridCard from '@sharedComponents/GridCard'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Tabs from '@sharedComponents/Tabs'
import CustomTableList from '@sharedComponents/CustomTableList'
import useOrgUserList from './hooks/useOrgUserList'
import Modal from '@sharedComponents/Modal'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import useOrgUserListApi from './hooks/useOrgUserListApi'
import { debounce } from 'lodash'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Warning from '../WarningMessage'
import { STATE_CONSTANTS } from '@constants/constants'
import { TransformedFilterCriterias } from '@sharedComponents/CustomTableList/types/CustomTableListTypes'
import ExportTable from '@sharedComponents/ExportTable'
export default function OrganizationProfile({
  orgId
}: {
  orgId: string
}): ReactElement {
  const { isLogin } = useAuthorize()
  const router = useRouter()
  const {
    orgProfileData,
    orgProfileError,
    orgProfileErrorCode,
    fetchOrgProfile,
    isOrgProfUpdated,
    setOrgProfUpdated,
    totalUsers
  } = useOrgProfileApi()
  const {
    orgCards,
    validationSchema,
    tabs,
    handleTabChange,
    tabIndex,
    init,
    isOrgModalOpen,
    setOrgIsModalOpen,
    modalOrgFieldValue
  } = useOrgProfile(totalUsers)
  const [transformedFilterCriteria, setTransformedFilterCriteria] =
    useState<TransformedFilterCriterias>({})
  const {
    userListConfig,
    sortValue,
    sortBy,
    sortOrder,
    handlePageChange,
    page,
    handleSortChange,
    handleSortOption,
    handleOnSearch,
    searchValue,
    hasFilterApplied,
    isLoading,
    setIsLoading,
    isModalOpen,
    setIsModalOpen,
    modalFieldValue,
    filterCountry,
    filterUserRole,
    filterUserBlocked,
    initUser,
    refreshList
  } = useOrgUserList(orgId, orgProfileData?.state)

  const {
    userListData,
    userListError,
    userListErrorCode,
    fetchUserList,
    userListTotal,
    filterCriterias
  } = useOrgUserListApi()

  const debouncefetch = useCallback(
    debounce((params) => {
      fetchUserList(params)
    }, 500),
    []
  )

  useEffect(() => {
    const data = filterCriterias
    const updatedData = {}
    for (const key in data) {
      if (data[key]?.length) {
        const updatedKey = Object.fromEntries(
          [...data[key]].map((item) => [
            item,
            filterUserRole[item] ||
              filterCountry[item] ||
              filterUserBlocked[item] ||
              false
          ])
        )
        updatedData[`${key}`] = updatedKey
      }
    }
    setTransformedFilterCriteria(updatedData)
  }, [filterCriterias])

  useEffect(() => {
    if (isLogin && tabIndex === 1) {
      const params = {
        orgId,
        page,
        sortBy,
        sortOrder,
        searchValue,
        setIsLoading,
        filterUserRole,
        filterCountry,
        filterUserBlocked
      }
      debouncefetch(params)
    }
  }, [
    fetchUserList,
    tabIndex,
    isLogin,
    orgId,
    page,
    sortBy,
    sortOrder,
    searchValue,
    setIsLoading,
    filterUserRole,
    filterCountry,
    initUser,
    filterUserBlocked,
    refreshList
  ])

  useEffect(() => {
    if (isLogin) {
      fetchOrgProfile(orgId)
    }
  }, [fetchOrgProfile, isOrgProfUpdated, orgId, isLogin, init])

  useEffect(() => {
    if (isLogin && orgProfileData) {
      if (orgProfileData.state === STATE_CONSTANTS.PENDING) {
        router.push(`/create-org/${orgId}`)
      }
    }
  }, [isLogin, orgId, orgProfileData])

  const handleClick = () => {
    router.back()
  }

  const renderModal = () => {
    const modalValue = isOrgModalOpen ? modalOrgFieldValue : modalFieldValue
    return (
      <Modal
        type={CUSTOM_TYPE}
        title={modalValue.heading}
        titleSize="h3"
        onToggleModal={() => {
          setIsModalOpen(false)
          setOrgIsModalOpen(false)
        }}
        isOpen={isModalOpen || isOrgModalOpen}
      >
        {modalValue.subheading}
        <div className={styles.footer}>
          <Button
            variant="contained"
            color="primary"
            className={`mt-1 ${styles.modalButton}`}
            onClick={modalValue.handleSubmit}
          >
            Confirm
          </Button>
        </div>
      </Modal>
    )
  }

  const renderOrgUserList = () => {
    return (
      <CustomTableList
        configuration={userListConfig}
        data={userListData}
        totalRecord={userListTotal}
        isLoading={isLoading}
        paginationSize={10}
        tabIndex={tabIndex}
        sortValue={sortValue}
        sortBy={sortBy}
        sortOrder={sortOrder}
        handlePageChange={handlePageChange}
        handleSortOption={handleSortOption}
        page={page}
        handleSortChange={handleSortChange}
        handleOnSearch={handleOnSearch}
        filterCriterias={transformedFilterCriteria}
        searchValue={searchValue}
        hasFilterApplied={hasFilterApplied}
      />
    )
  }

  const renderOrgProfile = () => {
    return (
      <Grid
        className={styles.content}
        container
        rowSpacing={4}
        columnSpacing={3}
      >
        {orgCards.map((cardConfig, index) => {
          return (
            <Grid key={index} item xs={12} md={12} lg={9}>
              <GridCard
                cardConfig={cardConfig}
                data={orgProfileData}
                setStateData={setOrgProfUpdated}
                validationSchema={validationSchema}
              />
            </Grid>
          )
        })}
      </Grid>
    )
  }

  function renderOrgDetails() {
    if (
      (tabIndex === 0 && orgProfileError) ||
      (tabIndex === 1 && userListError)
    ) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = tabIndex === 0 ? orgProfileError : userListError

      const isUnauthorize =
        orgProfileErrorCode === ERROR_UNAUTH ||
        userListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    return (
      <>
        <div className={styles.header}>
          <div>
            {<h3 className={styles.bold}>{orgProfileData?.name}</h3>}
            {<div className={styles.description}>&nbsp;</div>}
          </div>
          <div>
            {tabIndex === 1 && (
              <ExportTable
                exportConfig={userListConfig.exportConfig}
                totalRecord={userListTotal}
              ></ExportTable>
            )}
          </div>
        </div>

        <Tabs
          items={tabs}
          handleTabChange={handleTabChange}
          defaultIndex={tabIndex}
        />
        {tabIndex === 0
          ? (orgProfileData && renderOrgProfile()) || null
          : renderOrgUserList()}
      </>
    )
  }

  return (
    <PrivateRoute>
      <>
        {!orgProfileError && (
          <Button onClick={handleClick} aria-label="Go Back">
            <BackIcon />
          </Button>
        )}
        {(isModalOpen || isOrgModalOpen) && renderModal()}
        {renderOrgDetails()}
      </>
    </PrivateRoute>
  )
}
