export const userList = {
  data: [
    {
      id: 302,
      org_id: 'd7091bbd-4161-4d99-babb-2c6fdef5eea9',
      userAcceptDate: '0001-01-01T00:00:00Z',
      userInviteDate: '2023-12-28T08:18:35.8663Z',
      email: 'mugytim@mailinator.com',
      source: 'portal',
      allowedRoles: 'Super-admin,Admin,Publisher,Consumer',
      spendLimit: 0,
      country: 'Afghanistan',
      profileId: '',
      state: 'Invited',
      remark: 'Super-Admin user added while creation of organization',
      blocked: false,
      createdDate: '2023-12-28T08:18:35.8663Z',
      createdBy: 'madhav.kalra@nagarro.com',
      lastUpdateDate: '2023-12-28T08:18:35.8663Z',
      lastUpdatedBy: 'madhav.kalra@nagarro.com',
      purge_status: false,
      purge_reason: ''
    }
  ],
  filterCriterias: {
    Country: null,
    Roles: ['Admin', 'Consumer', 'Publisher', 'Super-admin'],
    OrgId: null
  },
  totalRecord: 1
}
