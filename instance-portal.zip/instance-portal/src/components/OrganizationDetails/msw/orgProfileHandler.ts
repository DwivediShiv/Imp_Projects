import { rest } from 'msw'
import { server } from '@utils/msw'
import { MswHandlerProps, OrgProfile } from '../types/OrgProfile'
import { orgProfile } from './orgProfileData'
import appConfig from 'app.config'
import { userList } from './userListData'

export function setupGetOrgDataHandler(props?: MswHandlerProps<OrgProfile>) {
  const statusCode = props?.status ?? 200
  const handler1 = rest.get(
    `${appConfig.api}/user-management/api/v1/org/123`,
    async (_, res, ctx) => {
      let json
      const data = orgProfile

      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  const handler2 = rest.post(
    `${appConfig.api}/user-management/api/v1/as/user-list`,
    async (_, res, ctx) => {
      let json
      const data = userList
      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )

  const handler3 = rest.post(
    `${appConfig.api}/user-management/api/v1/as/user-list/export`,
    async (_, res, ctx) => {
      let json
      const data = userList
      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )

  server.use(handler1, handler2, handler3)
}
