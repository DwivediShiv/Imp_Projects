import React from 'react'
import {
  render,
  screen,
  fireEvent,
  within,
  waitFor
} from '@testing-library/react'
import { setupGetOrgDataHandler } from '../msw/orgProfileHandler'
import OrganizationProfile from '..'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'

const mockRouterBack = jest.fn()
const mockRouterPush = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack,
    push: mockRouterPush
  })
}))

jest.mock('@core/context/FancyState', () => ({
  useFancyState: () => ({
    getSelectionOptionsByCategory: (optionCategory) => {
      if (optionCategory === 'Country') {
        return [
          {
            id: 31,
            name: 'Austria',
            key: 'AT',
            category: 'Country',
            sortOrder: 1,
            updatedAt: '2023-07-16T16:37:20.891966Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 32,
            name: 'Belgium',
            key: 'BE',
            category: 'Country',
            sortOrder: 2,
            updatedAt: '2023-07-16T16:37:20.891966Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 33,
            name: 'Bulgaria',
            key: 'BG',
            category: 'Country',
            sortOrder: 3,
            updatedAt: '2023-07-16T16:37:20.891966Z',
            updatedBy: 'ACENTRIK'
          }
        ]
      } else if (optionCategory === 'Industry') {
        return [
          {
            id: 1,
            name: 'Aerospace',
            key: 'aerospace',
            category: 'Industry',
            sortOrder: 1,
            updatedAt: '2023-07-16T16:37:20.83741Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 2,
            name: 'Agriculture',
            key: 'agriculture',
            category: 'Industry',
            sortOrder: 2,
            updatedAt: '2023-07-16T16:37:20.83741Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 62,
            name: 'Automotive',
            key: 'automotive',
            category: 'Industry',
            sortOrder: 3,
            updatedAt: '2023-07-16T16:37:21.048874Z',
            updatedBy: 'ACENTRIK'
          }
        ]
      }
    }
  })
}))

interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

jest.mock('@core/context/Authorize')

const renderComponent = (options: RenderOptions) => {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin
  })

  render(<OrganizationProfile orgId={'123'} />)
}

describe('Org Admin profile ', () => {
  beforeEach(() => {
    setupGetOrgDataHandler()
  })
  it('login component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isLogin: false
      }
    })
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('component should render if authorized', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(
      await screen.findByRole('heading', { level: 3, name: /Test 28/i })
    ).toHaveTextContent('Test 28')
    const detailsTab = await screen.findByRole('tab', {
      name: /details/i
    })
    const userListTab = await screen.findByRole('tab', {
      name: /users/i
    })
    const editButton = await screen.findAllByRole('button', {
      name: /Edit/i
    })
    expect(detailsTab).toBeInTheDocument()
    expect(userListTab).toBeInTheDocument()
    expect(editButton[1]).toBeInTheDocument()
  })

  it('component should render and has 2 tabs if authorized', async () => {
    window.URL.createObjectURL = jest.fn()
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(
      await screen.findByRole('heading', { level: 3, name: /Test 28/i })
    ).toHaveTextContent('Test 28')

    const editButton = await screen.findAllByRole('button', {
      name: /Edit/i
    })
    expect(editButton[1]).toBeInTheDocument()
    fireEvent.click(editButton[1])
    const companyName = await screen.findByRole('cell', {
      name: /test 28/i
    })
    const textBox = await within(companyName).findByRole('textbox')
    fireEvent.change(textBox, { target: { value: 'Test 29' } })
    const saveButton = await screen.findByRole('button', {
      name: /save changes/i
    })
    fireEvent.click(saveButton)
    expect(textBox).toHaveValue('Test 29')
  })

  it('handles back button', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    screen.getByRole('button', {
      name: /go back/i
    })
    const backButton = await screen.findByRole('button', {
      name: /go back/i
    })
    expect(backButton).toBeInTheDocument()
    fireEvent.click(backButton)
    expect(mockRouterBack).toHaveBeenCalledTimes(1)
  })

  it('component should render if authorized', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    const companyLogo = await screen.findByRole('heading', {
      name: /logo/i
    })
    const companyInformation = await screen.findByRole('heading', {
      name: /information/i
    })

    expect(companyLogo).toBeInTheDocument()

    expect(companyInformation).toBeInTheDocument()
  })
  it('api errors should be handled', async () => {
    setupGetOrgDataHandler({
      response: {
        code: 'Error_UnAuthorizedUserAction',
        error: 'User Unauthorized'
      },
      status: 400
    })
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(await screen.findByText(/Restricted Access/i)).toBeInTheDocument()
  })
})
