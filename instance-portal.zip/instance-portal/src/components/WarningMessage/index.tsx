import React, { ReactElement } from 'react'
import { IconSize } from '@utils/constants'
import styles from './index.module.css'
import IconicCard, {
  CustomIconicCardSize,
  CustomIconicCardState
} from '@sharedComponents/IconicCard'
import Markdown from '@sharedComponents/Markdown'
export default function Warning({
  header,
  message,
  icon = 'not-found',
  actionLabel,
  state,
  isMarkDown,
  action
}: {
  header: string
  message?: string
  icon?: string
  actionLabel?: string
  state?: CustomIconicCardState
  isMarkDown?: boolean
  action?: () => void
}): ReactElement {
  return (
    <div className={styles.fancyBigBlock}>
      <IconicCard
        header={header}
        icon={icon}
        state={state}
        size={CustomIconicCardSize.Big}
        actionLabel={actionLabel}
        action={action}
      >
        <div>
          {isMarkDown ? (
            <Markdown text={message} iconSize={IconSize.Large} />
          ) : (
            message
          )}
        </div>
      </IconicCard>
    </div>
  )
}
