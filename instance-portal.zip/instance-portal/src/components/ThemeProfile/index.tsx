import React, { ReactElement, useEffect, useMemo, useState } from 'react'
import { PERMISSION_ADMIN } from '@constants/permissionConstants'
import Permission from '@sharedComponents/Permission'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import useSectionConfig from './hooks/useSectionConfig'
import ThemeSectionForm from './component/ThemeSectionForm'
import Loader from '@sharedComponents/CustomLoader'
import styles from './index.module.css'

export default function OrganizationProfile(): ReactElement {
  const [isEditHeaderLogo, setIsEditHeaderLogo] = useState(false)
  const [isEditFooterLogo, setIsEditFooterLogo] = useState(false)
  const [isEditLoadingImage, setIsEditLoadingImage] = useState(false)
  const [isEditTokenImage, setIsEditTokenImage] = useState(false)
  const [isEditFavicon, setIsEditFavicon] = useState(false)
  const editStatusArray = [
    { isEditActive: isEditHeaderLogo, setIsEditActive: setIsEditHeaderLogo },
    { isEditActive: isEditFooterLogo, setIsEditActive: setIsEditFooterLogo },
    {
      isEditActive: isEditLoadingImage,
      setIsEditActive: setIsEditLoadingImage
    },
    {
      isEditActive: isEditTokenImage,
      setIsEditActive: setIsEditTokenImage
    },
    { isEditActive: isEditFavicon, setIsEditActive: setIsEditFavicon }
  ]
  const {
    initialValues,
    validationSchema,
    handleSubmit,
    setInit,
    staticUrls,
    initialLoader
  } = useSectionConfig(editStatusArray)

  return (
    <PrivateRoute>
      {initialLoader ? (
        <div className={styles.loader}>
          <Loader />
        </div>
      ) : (
        <>
          <h3 className="bold">Instance Theming</h3>
          {staticUrls && (
            <ThemeSectionForm
              initialValues={initialValues}
              validationSchema={validationSchema}
              handleSubmit={handleSubmit}
              values={undefined}
              setInit={setInit}
              editStatusArray={editStatusArray}
              isEditHeaderLogo={isEditHeaderLogo}
              isEditFooterLogo={isEditFooterLogo}
              isEditLoadingImage={isEditLoadingImage}
              isEditTokenImage={isEditTokenImage}
              isEditFavicon={isEditFavicon}
            />
          )}
        </>
      )}
    </PrivateRoute>
  )
}
