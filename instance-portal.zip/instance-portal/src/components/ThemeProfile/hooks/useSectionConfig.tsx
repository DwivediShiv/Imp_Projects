import * as Yup from 'yup'
import { useRouter } from 'next/router'
import Toast from '@sharedComponents/Toast'
import { ADD_EDGE_NODE_CONSTANTS } from '../../../libs/constants/modalConstant'
import { useEffect, useState } from 'react'
import useThemeApi from './useThemeApi'

import { DEFAULT_ERROR_MESSAGE } from '@features/OrganizationAdd/constants'
import { DEFAULT_FONT, MAX_500_CHAR_ALLOWED } from '@constants/constants'

import theme from '../msw/theme.json'
import useInstanceConfigApi from '@features/InstanceConfig/hooks/useInstanceConfigApi'
import { HEX_CODE_MSG } from '../constants'
import { imageUrl } from '../msw/imageUrl'

const useSectionConfig = (editStatusArray) => {
  const router = useRouter()
  const {
    themeError,
    updateTheme,
    fetchCustomizeJson,
    cutomizeJson,
    isLoading,
    initialLoader
  } = useThemeApi()

  const {
    headerLogoUrl,
    faviconUrl,
    loadingImageUrl,
    footerLogoUrl,
    tokenImageUrl
  } = imageUrl

  const [fontInitialValue, setFontInitialValue] = useState(null)
  const [staticUrls, setStaticUrls] = useState({
    termsAndConditions: '',
    privacyPolicy: '',
    cookiePolicy: '',
    licenses: '',
    copyrightText: '',
    knowledgeBase: '',
    faqs: '',
    contactUs: '',
    websiteHeading: ''
  })
  const [init, setInit] = useState<boolean>(true)
  const regMatch =
    /^((http|https):\/\/)?(www.)?(?!.*(http|https|www.))[a-zA-Z0-9_-]+(\.[a-zA-Z]+)+(\/)?.([\w?[a-zA-Z-_%/@?]+)*([^/\w?[a-zA-Z0-9_-]+=\w+(&[a-zA-Z0-9_]+=\w+)*)?$/

  useEffect(() => {
    fetchCustomizeJson()
  }, [fetchCustomizeJson, init])

  function replaceInitialValues(obj, cssPayload) {
    if (Array.isArray(obj)) {
      for (let i = 0; i < obj.length; i++) {
        replaceInitialValues(obj[i], cssPayload)
      }
    } else if (typeof obj === 'object') {
      for (const key in obj) {
        if (key === 'name' && 'initial_value' in obj) {
          const { name } = obj
          if (name in cssPayload) {
            obj.initial_value = cssPayload[name]
          }
        } else {
          replaceInitialValues(obj[key], cssPayload)
        }
      }
    }
  }
  useEffect(() => {
    if (cutomizeJson) {
      const { staticUrls, cssPayload } = cutomizeJson || {}

      replaceInitialValues(theme, cssPayload || {})

      setFontInitialValue({
        '--font-family-base':
          (cssPayload && cssPayload['--font-family-base']) || DEFAULT_FONT
      })

      setStaticUrls(staticUrls)
    } else {
      setFontInitialValue({
        '--font-family-base': DEFAULT_FONT
      })
    }
  }, [cutomizeJson])

  useEffect(() => {
    if (themeError) {
      Toast('error', 'Unexpected Error Occured')
    } else if (themeError === null) {
      Toast('success', 'Updated Successfully')
    }
  }, [themeError])

  const createThemeSuccessCallback = () => {
    Toast('success', 'Updated Successfully.')
  }
  const createThemeInfoCallback = (infoMessage) => {
    Toast('info', infoMessage)
  }
  const createThemeErrorCallback = (error) => {
    Toast('error', error || DEFAULT_ERROR_MESSAGE)
  }

  const deleteNonCSSVal = (payload) => {
    delete payload.headerLogo
    delete payload.footerLogo
    delete payload.loadingImage
    delete payload.tokenImage
    delete payload.favicon

    delete payload.termsAndConditions
    delete payload.privacyPolicy
    delete payload.cookiePolicy
    delete payload.licenses
    delete payload.copyrightText
    delete payload.knowledgeBase
    delete payload.faqs
    delete payload.contactUs
    delete payload.websiteHeading
  }

  const checkOnlyThemeUpdated = (values, editStatusArray) => {
    const initialValues = { ...staticUrls, ...fontInitialValue }

    const isAnyImageInEditMode = editStatusArray.some(
      (editStatus) => editStatus.isEditActive
    )

    if (isAnyImageInEditMode) {
      return false
    }

    for (const property in values) {
      const value = values[property]
      if (property in initialValues && value !== initialValues[property]) {
        return false
      }
    }
    return true
  }

  function populateYupValidation(externalLink: string) {
    return Yup.string()
      .trim()
      .matches(
        regMatch,
        `Invalid link. Please enter a correct URL to your ${externalLink} page.`
      )
      .max(500, MAX_500_CHAR_ALLOWED)
  }

  const handleSubmit = async (values, isDraft: boolean) => {
    try {
      const files = {}
      let onlyThemeUpdated = false

      if (!isDraft) {
        onlyThemeUpdated = checkOnlyThemeUpdated(values, editStatusArray)
      }

      const propertiesToUpdate = [
        'headerLogo',
        'footerLogo',
        'loadingImage',
        'tokenImage',
        'favicon'
      ]

      propertiesToUpdate.forEach((property) => {
        if (values[property] && values[property][0]) {
          files[property] = values[property][0]
        }
      })

      const staticUrls = {
        termsAndConditions: values.termsAndConditions
          ? values.termsAndConditions
          : '',
        privacyPolicy: values.privacyPolicy ? values.privacyPolicy : '',
        cookiePolicy: values.cookiePolicy ? values.cookiePolicy : '',
        licenses: values.licenses ? values.licenses : '',
        copyrightText: values.copyrightText ? values.copyrightText : '',
        knowledgeBase: values.knowledgeBase ? values.knowledgeBase : '',
        faqs: values.faqs ? values.faqs : '',
        contactUs: values.contactUs ? values.contactUs : '',
        websiteHeading: values.websiteHeading ? values.websiteHeading : ''
      }

      const cssPayload = { ...values }

      deleteNonCSSVal(cssPayload)

      await updateTheme(
        cssPayload,
        createThemeSuccessCallback,
        createThemeErrorCallback,
        createThemeInfoCallback,
        files,
        staticUrls,
        isDraft,
        cutomizeJson,
        onlyThemeUpdated
      )
    } catch (e) {
      console.error(e)
    }
  }

  const imageUrls = {
    headerLogo: headerLogoUrl,
    footerLogo: footerLogoUrl,
    loadingImage: loadingImageUrl,
    tokenImage: tokenImageUrl,
    favicon: faviconUrl
  }
  const primaryColorProperties = {}
  const hexValidationProperties = {}
  const hexCodeValidation = Yup.string()
    .required(HEX_CODE_MSG.REQUIRED_TEXT)
    .matches(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/, {
      message: HEX_CODE_MSG.FORMAT
    })
    .max(7, 'MAX_7_CHARACTERS_ALLOWED')

  function extractPrimaryColorProperties(theme) {
    theme.forEach((category) => {
      category.sections.forEach((section) => {
        section.items.forEach((item) => {
          primaryColorProperties[item.name] = item.initial_value
          hexValidationProperties[item.name] = hexCodeValidation
        })
      })
    })
  }
  extractPrimaryColorProperties(theme)
  const initialValues = {
    ...imageUrls,
    ...primaryColorProperties,
    ...staticUrls,
    ...fontInitialValue
  }

  const commonFieldValidation = Yup.string()
    .matches(/.*[a-zA-Z0-9].*/, {
      message: 'Please enter a correct value.'
    })
    .max(500, MAX_500_CHAR_ALLOWED)

  const validationSchema: Yup.SchemaOf<any> = Yup.object().shape({
    termsAndConditions: populateYupValidation('Terms & Conditions'),
    privacyPolicy: populateYupValidation('Privacy Policy'),
    cookiePolicy: populateYupValidation('Cookie Policy'),
    licenses: populateYupValidation('Licenses'),
    copyrightText: commonFieldValidation,
    websiteHeading: commonFieldValidation,
    knowledgeBase: populateYupValidation('Knowledge Base'),
    faqs: populateYupValidation('FAQs'),
    contactUs: populateYupValidation('Contact Us'),
    ...hexValidationProperties
  })

  return {
    handleSubmit,
    initialValues,
    staticUrls,
    validationSchema,
    isLoading,
    setInit,
    initialLoader
  }
}

export default useSectionConfig
