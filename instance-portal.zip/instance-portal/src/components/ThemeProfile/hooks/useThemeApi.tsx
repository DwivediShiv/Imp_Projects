import { useCallback, useEffect, useState } from 'react'
import axios from 'axios'
import { ApiResponse, Theme } from '../types/Theme'
import appConfig from 'app.config'
import { imageUrl } from '../msw/imageUrl'
import useInstanceConfigApi from '@features/InstanceConfig/hooks/useInstanceConfigApi'
import defaultBase from '../msw/defaultBase.json'
import { DEPLOYMENT_IN_PROGRESS } from '@constants/permissionConstants'
export interface ThemeResponse {
  data: Theme
}
export const uploadThemeURL = `${appConfig.api}/instance-management/api/v1/instance/theming`
export const redeployURL = `${appConfig.api}/instance-management/api/v1/instance/redeploy`

export default function useThemeApi() {
  const [cutomizeJson, setCutomizeJson] = useState(null)
  const [themeError, setThemeError] = useState<string | null>('')
  const [isThemeUpdated, setThemeUpdated] = useState<boolean>(false)

  const {
    customizeJsonUrl,
    headerLogoUrl,
    footerLogoUrl,
    tokenImageUrl,
    faviconUrl,
    loadingImageUrl
  } = imageUrl

  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [initialLoader, setInitialLoader] = useState<boolean>(true)

  const fetchcustomizeJsonUrl = `${customizeJsonUrl}?v=${new Date().getTime()}`
  const { reDeploy } = useInstanceConfigApi()

  const toBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = () => resolve(reader.result)
      reader.onerror = reject
    })

  const fetchCustomizeJson = useCallback(async () => {
    try {
      setIsLoading(true)
      setThemeError('')

      const { data: response } = await axios.get<ApiResponse<any>>(
        fetchcustomizeJsonUrl
      )

      setCutomizeJson(response)
    } catch (error) {
      console.log('initial call :', error)
    } finally {
      setIsLoading(false)
      setInitialLoader(false)
    }
  }, [])

  const updateTheme = useCallback(
    async (
      cssPayload,
      createThemeSuccessCallback,
      createThemeErrorCallback,
      createThemeInfoCallback,
      files,
      staticUrls,
      isDraft,
      cutomizeJsonGet,
      onlyThemeUpdated
    ) => {
      try {
        setIsLoading(true)
        const formData = new FormData()
        const customizeJson: any = {
          staticUrls: {},
          cssPayload: {},
          imageUrls: {
            headerLogoUrl,
            footerLogoUrl,
            tokenImageUrl,
            faviconUrl,
            loadingImageUrl
          },
          customiseImagesBase64: {
            headerLogo: defaultBase.headerLogo,
            footerLogo: defaultBase.footerLogo,
            tokenImage: defaultBase.tokenImage,
            favicon: defaultBase.favicon,
            loadingImage: defaultBase.loadingImage
          }
        }
        const imagesBase64 = {}

        if (defaultBase) {
          for (const key in defaultBase) {
            if (files[key] && typeof files[key] === 'object') {
              const fileType = files[key].type.split('/')[1]
              formData.append('files', files[key], `${key}.${fileType}`)
              const file = files[key]
              imagesBase64[`${key}Base64`] = await toBase64(file)
              customizeJson.customiseImagesBase64[key] =
                imagesBase64[`${key}Base64`]
            } else {
              if (
                cutomizeJsonGet &&
                cutomizeJsonGet.customiseImagesBase64 &&
                cutomizeJsonGet.customiseImagesBase64[key]
              ) {
                imagesBase64[`${key}Base64`] =
                  cutomizeJsonGet.customiseImagesBase64[key]
                customizeJson.customiseImagesBase64[key] =
                  imagesBase64[`${key}Base64`]
              } else {
                imagesBase64[`${key}Base64`] = defaultBase[key]
                customizeJson.customiseImagesBase64[key] =
                  imagesBase64[`${key}Base64`]
              }
            }
          }
        }
        if (staticUrls) {
          customizeJson.staticUrls = staticUrls
        }
        if (cssPayload) {
          customizeJson.cssPayload = cssPayload
          if (!isDraft) {
            let cssString = 'body {\n'

            for (const variable in cssPayload) {
              cssString += `    ${variable}: ${cssPayload[variable]};\n`
            }

            cssString += '}\n'

            const blob = new Blob([cssString], { type: 'text/css' })

            const customCssfile = new File([blob], 'customize.css', {
              type: 'text/css'
            })

            formData.append('files', customCssfile)
          }
        }
        const blob = new Blob([JSON.stringify(customizeJson)], {
          type: 'application/json'
        })

        const customConfigFile = new File([blob], 'customize.json', {
          type: 'application/json'
        })

        formData.append('files', customConfigFile)

        const imagesblob = new Blob([JSON.stringify(imagesBase64)], {
          type: 'application/json'
        })

        const imagesConfigFile = new File([imagesblob], 'themeImages.json', {
          type: 'application/json'
        })

        formData.append('files', imagesConfigFile)

        const { data: response } = await axios.put<ApiResponse<any>>(
          uploadThemeURL,
          formData
        )
        const resetImageURLs = () => {
          setCutomizeJson({
            ...cutomizeJson,
            imageUrls: {
              headerLogoUrl: defaultBase.headerLogo,
              footerLogoUrl: defaultBase.footerLogo,
              tokenImageUrl: defaultBase.tokenImage,
              faviconUrl: defaultBase.favicon,
              loadingImageUrl: defaultBase.loadingImage
            }
          })
        }
        if (!isDraft && !onlyThemeUpdated) {
          try {
            const url = redeployURL + `/${appConfig?.instanceVersion}`
            const { data: response } = await axios.post(url)
            createThemeSuccessCallback()
          } catch (error) {
            if (
              error.response &&
              error.response.data?.code === DEPLOYMENT_IN_PROGRESS
            ) {
              createThemeInfoCallback(
                'Changes still in progress, please try again in sometime.'
              )
              resetImageURLs()
            } else {
              createThemeErrorCallback(
                'Cannot apply changes. Please try again in sometime.'
              )
              resetImageURLs()
            }
          }
        } else {
          createThemeSuccessCallback()
        }
      } catch (error) {
        if (axios.isAxiosError(error)) {
          createThemeErrorCallback(error.message)
        } else {
          createThemeErrorCallback('Unexpected Error Occured')
        }
      } finally {
        setIsLoading(false)
      }
    },
    []
  )

  return {
    cutomizeJson,
    themeError,
    setCutomizeJson,
    fetchCustomizeJson,
    updateTheme,
    setThemeUpdated,
    isThemeUpdated,
    isLoading,
    initialLoader
  }
}
