export const HEX_CODE_MSG = {
  REQUIRED_TEXT: `Required field`,
  FORMAT: `Invalid color code`
}
