import { Paper, Grid } from '@mui/material'
import React, { useEffect, useMemo, useRef, useState } from 'react'
import styles from './ThemeSectionForm.module.css'
import { Field, Form, Formik } from 'formik'
import ButtonSection from '@sharedComponents/SectionForm/ButtonSection'
import FieldsSection from '@sharedComponents/SectionForm/FieldsSection'
import { SectionFormProps } from '@sharedComponents/SectionForm/types/SectionFormTypes'
import ThemeColors from './ThemeColors'
import theme from '../msw/theme.json'
import appConfig from 'app.config'
import { useRouter } from 'next/router'
import { imageUrl } from '../msw/imageUrl'
import CustomButton from '@sharedComponents/Button'
import Modal from '@sharedComponents/Modal'
import { CUSTOM_TYPE, ICON_TYPE } from '@constants/modalConstant'
const ThemeSectionForm: React.FC<SectionFormProps> = ({
  initialValues,
  validationSchema,
  editStatusArray,
  isEditHeaderLogo,
  isEditFooterLogo,
  isEditFavicon,
  isEditTokenImage,
  isEditLoadingImage,
  handleSubmit = () => {
    // default value
  },
  setInit
}) => {
  const {
    headerLogoUrl,
    faviconUrl,
    loadingImageUrl,
    footerLogoUrl,
    tokenImageUrl
  } = imageUrl

  const [isModalOpen, setIsModalOpen] = useState(false)
  const resetImages = () => {
    editStatusArray.forEach(({ setIsEditActive }) => {
      setIsEditActive(false)
    })
  }
  const [openModal, setOpenModal] = useState(false)
  const formValuesRef = useRef(null)

  const imageUploadConfig = useMemo(() => {
    return [
      {
        title: 'Header Logo',
        fields: [
          {
            name: 'headerLogo',
            label: 'Header Logo',
            type: 'themeImage',
            logoUrl: headerLogoUrl,
            isEditActive: isEditHeaderLogo,
            width: 125,
            height: 24,
            itemSpacing: 12
          }
        ]
      },
      {
        title: 'Footer Logo',
        fields: [
          {
            name: 'footerLogo',
            label: 'Footer Logo',
            type: 'themeImage',
            logoUrl: footerLogoUrl,
            isEditActive: isEditFooterLogo,
            width: 125,
            height: 50,
            itemSpacing: 12
          }
        ]
      },
      {
        title: 'Loading Image',
        fields: [
          {
            name: 'loadingImage',
            label: 'Loading Image',
            type: 'themeImage',
            logoUrl: loadingImageUrl,
            isEditActive: isEditLoadingImage,
            width: 250,
            height: 180,
            itemSpacing: 12
          }
        ]
      },
      {
        title: 'Token Image',
        fields: [
          {
            name: 'tokenImage',
            label: 'Token Image',
            type: 'themeImage',
            logoUrl: tokenImageUrl,
            isEditActive: isEditTokenImage,
            width: 80,
            height: 80,
            itemSpacing: 12
          }
        ]
      },
      {
        title: 'Favicon',
        fields: [
          {
            name: 'favicon',
            label: 'Favicon',
            type: 'themeImage',
            logoUrl: faviconUrl,
            isEditActive: isEditFavicon,
            width: 100,
            height: 100,
            itemSpacing: 12
          }
        ]
      }
    ]
  }, [
    faviconUrl,
    footerLogoUrl,
    headerLogoUrl,
    isEditFavicon,
    isEditFooterLogo,
    isEditHeaderLogo,
    isEditLoadingImage,
    isEditTokenImage,
    loadingImageUrl,
    tokenImageUrl
  ])

  const fieldsConfig = [
    {
      title: 'Customise Fonts',
      fields: [
        {
          name: '--font-family-base',
          label: 'Body Text',
          type: 'select',
          options: appConfig.customization.defaultTheme.fonts
        }
      ]
    },
    {
      title: 'External Links',
      fields: [
        {
          name: 'knowledgeBase',
          label: 'Knowledge Base',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        },
        {
          name: 'faqs',
          label: 'FAQs',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        },
        {
          name: 'termsAndConditions',
          label: 'Terms & Conditions',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        },
        {
          name: 'privacyPolicy',
          label: 'Privacy Policy',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        },
        {
          name: 'cookiePolicy',
          label: 'Cookie Policy',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        },
        {
          name: 'licenses',
          label: 'Licenses',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        },
        {
          name: 'contactUs',
          label: 'Contact Us',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        }
      ]
    },
    {
      title: 'Website Info',
      fields: [
        {
          name: 'copyrightText',
          label: 'Copyright Text',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 100 }
        },
        {
          name: 'websiteHeading',
          label: 'Website Heading',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 100 }
        }
      ]
    }
  ]

  const leftButtons = [
    {
      name: 'Cancel',
      color: 'secondary',
      variant: 'link',
      disableRipple: true,
      onClick: () => {
        location.reload()
      }
    }
  ]
  const rightButtons = [
    {
      name: 'Save Draft',
      color: 'secondary',
      variant: 'link',
      disableRipple: true,
      onClick: async (props, values, resetForm) => {
        await handleSubmit(values, true)
        setInit((prevInit) => !prevInit)
        resetImages()
        resetForm()
      },
      disable: ({ dirty, isValid }) => !dirty || !isValid
    },
    {
      name: 'Apply Changes',
      variant: 'contained',
      color: 'primary',
      onClick: (props, values) => {
        setOpenModal(true)
        formValuesRef.current = values
      },
      disable: ({ dirty, isValid }) => !dirty || !isValid
    }
  ]

  const submitModal = async (resetForm) => {
    setOpenModal(false)
    await handleSubmit(formValuesRef.current, false)
    setInit((prevInit) => !prevInit)
    resetImages()
    resetForm()
  }

  return (
    <>
      <Formik
        initialValues={initialValues}
        onSubmit={async (
          values,
          { setSubmitting, resetForm, setFieldError }
        ) => {
          await submitModal(resetForm)
          setSubmitting(false)
        }}
        validationSchema={validationSchema}
        enableReinitialize
      >
        {({
          handleSubmit,
          errors,
          dirty,
          resetForm,
          handleBlur,
          setFieldValue,
          setFieldTouched,
          isValid,
          values,
          touched,
          setFieldError
        }) => (
          <Form className={styles.form}>
            <div className={styles.boxPaperContainer}>
              <Grid xs={12} md={12} lg={9} container spacing={2}>
                {imageUploadConfig.map((field, index) => (
                  <Grid item xs={6} key={'grid' + field.title + index}>
                    <Paper
                      classes={{
                        root: `${styles.squareBoxPaper}`
                      }}
                    >
                      <div className={styles.header}>
                        <div className={styles.title}>
                          <h4 className="bold">{field.title}</h4>
                        </div>
                        <div className={styles.actions}>
                          {editStatusArray[index].isEditActive ? (
                            <div className={styles.editActions}>
                              <CustomButton
                                buttonType="link"
                                color="primary"
                                className={styles.actionButton}
                                onClick={() => {
                                  const fieldName = field.fields[0].name
                                  setFieldValue(
                                    fieldName,
                                    initialValues[fieldName]
                                  )
                                  setFieldTouched(fieldName, false)
                                  setFieldError(fieldName, '')
                                  editStatusArray[index].setIsEditActive(false)
                                }}
                              >
                                Cancel
                              </CustomButton>
                            </div>
                          ) : (
                            <CustomButton
                              buttonType="link"
                              color="primary"
                              className={styles.actionButton}
                              onClick={() => {
                                editStatusArray[index].setIsEditActive(true)
                              }}
                            >
                              Edit
                            </CustomButton>
                          )}
                        </div>
                      </div>
                      <FieldsSection
                        errors={errors}
                        fields={field.fields}
                        handleBlur={handleBlur}
                        dirty={dirty}
                        values={values}
                        setFieldValue={setFieldValue}
                        setFieldError={setFieldError}
                      />
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            </div>

            <ThemeColors theme={theme} />

            {fieldsConfig &&
              fieldsConfig.map((fieldConfig, index) => (
                <Grid
                  xs={12}
                  md={12}
                  lg={9}
                  container
                  key={`${fieldConfig.title}${index}`}
                >
                  <Paper
                    classes={{
                      root: `${styles.boxPaper} ${styles.boxPaperContainer}`
                    }}
                    className={'w-100'}
                  >
                    <div className={styles.header}>
                      <div className={styles.title}>
                        <h4 className="bold">{fieldConfig.title}</h4>
                      </div>
                    </div>
                    <FieldsSection
                      errors={errors}
                      fields={fieldConfig.fields}
                      handleBlur={handleBlur}
                      dirty={dirty}
                      values={values}
                      setFieldValue={setFieldValue}
                      setFieldError={setFieldError}
                    />
                  </Paper>
                </Grid>
              ))}

            <Grid xs={12} md={12} lg={9} container>
              <Paper
                classes={{
                  root: `${styles.boxPaper} ${styles.boxPaperContainer}`
                }}
                className={'w-100'}
              >
                <ButtonSection
                  leftButtons={leftButtons}
                  rightButtons={rightButtons}
                  isValid={isValid}
                  dirty={dirty}
                  values={values}
                  resetForm={resetForm}
                  touched={touched}
                  setIsModalOpen={setIsModalOpen}
                />
              </Paper>
            </Grid>
            {openModal && (
              <Modal
                type={CUSTOM_TYPE}
                title="Confirm Changes"
                titleSize="h3"
                onToggleModal={() => {
                  setOpenModal(false)
                }}
                isOpen={openModal}
              >
                {`Are you sure you want to apply the theming? This will take approximately 30 minutes to reflect.`}
                <div className={styles.footer}>
                  <CustomButton
                    color="primary"
                    variant="contained"
                    className={`mt-1 ${styles.confirmButton}`}
                    onClick={handleSubmit}
                  >
                    Confirm
                  </CustomButton>
                </div>
              </Modal>
            )}
          </Form>
        )}
      </Formik>
    </>
  )
}

export default ThemeSectionForm
