import React, { useState, useRef } from 'react'
import styles from '../index.module.css'
import { Grid, Paper } from '@mui/material'
import stylesTheme from './ThemeSectionForm.module.css'
import Idea from '@images/idea_help.svg'
import CustomModal from '@sharedComponents/Modal'
import { ICON_TYPE } from '@constants/modalConstant'
import ColorPicker from '@sharedComponents/ColorPicker'
import { ChromePicker } from 'react-color'
import CustomButton from '@sharedComponents/Button'
import CrossIcon from '@images/cross_dark.svg'

const ThemeColors = ({ theme }) => {
  const [openModal, setOpenModal] = useState(false)
  const [colorPickerValue, setColorPickerValue] = useState(null)
  const [pickerPosition, setPickerPosition] = useState({ x: 0, y: 0 })
  const [isPickerVisible, setPickerVisible] = useState(false)
  const setFieldValRef = useRef(null)

  const renderColorList = (colorList) => {
    return (
      <div className={stylesTheme.sectionWrapper}>
        <Grid container spacing={4}>
          {colorList?.map(({ label, name }, index) => {
            return (
              <Grid item xs={3} key={'colorgrid' + label + index}>
                <ColorPicker
                  label={label}
                  name={name}
                  setColorPickerValue={setColorPickerValue}
                  setPickerVisible={setPickerVisible}
                  setPickerPosition={setPickerPosition}
                  setFieldValRef={setFieldValRef}
                />
              </Grid>
            )
          })}
        </Grid>
      </div>
    )
  }

  return (
    <>
      {isPickerVisible && (
        <div
          className={styles.colorPickerContainer}
          style={{
            left: pickerPosition.x,
            top: pickerPosition.y
          }}
        >
          <button
            className={stylesTheme.close}
            onClick={() => {
              setPickerVisible(false)
            }}
            data-testid="closeModal"
          >
            <CrossIcon />
          </button>
          <ChromePicker
            className={styles.chromePicker}
            color={colorPickerValue}
            onChange={(val) => {
              setColorPickerValue(val)
            }}
          />
          <div className={styles.button}>
            <CustomButton
              key="confirm"
              size="small"
              variant="contained"
              color="primary"
              onClick={() => {
                setPickerVisible(false)
                if (setFieldValRef.current && colorPickerValue) {
                  setFieldValRef.current(
                    colorPickerValue.hex ? colorPickerValue.hex : ''
                  )
                }
              }}
            >
              Confirm
            </CustomButton>
          </div>
        </div>
      )}
      {theme &&
        theme.length > 0 &&
        theme.map((item, index) => {
          return (
            <Grid
              xs={12}
              md={12}
              lg={9}
              container
              key={'paper' + item.heading + index}
            >
              <Paper
                classes={{
                  root: `${stylesTheme.boxPaper} ${stylesTheme.boxPaperContainer}`
                }}
                className={'w-100'}
              >
                <div className={stylesTheme.header}>
                  <div className={stylesTheme.title}>
                    <h4 className="bold">{item.heading}</h4>
                  </div>
                  <span onClick={() => setOpenModal(true)}>
                    <Idea />
                  </span>
                </div>
                {openModal && (
                  <CustomModal
                    type={ICON_TYPE}
                    isOpen={openModal}
                    modalTemplate="theme"
                    onToggleModal={() => setOpenModal(false)}
                    buttonActionMain={() => setOpenModal(false)}
                  />
                )}

                {item.sections &&
                  item.sections.length > 0 &&
                  item.sections.map((colorItem, index) => {
                    return (
                      <div key={'sections' + colorItem.heading + index}>
                        <>
                          {colorItem.heading && (
                            <div className={stylesTheme.header}>
                              <div className={stylesTheme.subtitle}>
                                <h6 className="bold">{colorItem.heading}</h6>
                              </div>
                            </div>
                          )}

                          {colorItem.items &&
                            colorItem.items.length > 0 &&
                            renderColorList(colorItem.items)}
                        </>
                        {index < item.sections.length - 1 && (
                          <hr className={styles.break} />
                        )}
                      </div>
                    )
                  })}
              </Paper>
            </Grid>
          )
        })}
    </>
  )
}

export default ThemeColors
