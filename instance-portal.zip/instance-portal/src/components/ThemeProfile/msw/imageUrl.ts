import appConfig from 'app.config'

export const imageUrl = {
  headerLogoUrl:
    'https://' +
    appConfig.customization.bucket +
    '.s3.amazonaws.com/instance/custom/headerLogo',
  footerLogoUrl:
    'https://' +
    appConfig.customization.bucket +
    '.s3.amazonaws.com/instance/custom/footerLogo',
  loadingImageUrl:
    'https://' +
    appConfig.customization.bucket +
    '.s3.amazonaws.com/instance/custom/loadingImage',
  tokenImageUrl:
    'https://' +
    appConfig.customization.bucket +
    '.s3.amazonaws.com/instance/custom/tokenImage',
  faviconUrl:
    'https://' +
    appConfig.customization.bucket +
    '.s3.amazonaws.com/instance/custom/favicon',
  customizeJsonUrl:
    'https://' +
    appConfig.customization.bucket +
    '.s3.amazonaws.com/instance/custom/customize.json'
}
