// TODO: validate fields matches with API response
export interface Theme {
  orgId: string
  name: string
  remark: string
  brNumber: string
  address: string
  website: string
  email: string
  industry: string
  country: string
  createdDate: string
  createdBy: string
  activatedOn: string
  logo: string
  companyName: string
  description: string
  businessNumber: string
  instanceRepresentativeId: string
  businessEmailId: string
}

export interface ThemeLogo {
  path: string
  preview: string
  contentType: string
}

// TODO: Move to `common-js`
export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

// TODO: Move to `common-js`
export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}
