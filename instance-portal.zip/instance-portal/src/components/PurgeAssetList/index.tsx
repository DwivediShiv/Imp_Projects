import React, { useCallback, useEffect, useState } from 'react'
import styles from './index.module.css'
import { parentTabs, useManagePurge } from './hooks/usePurgeManagement'
import CustomTableList from '@sharedComponents/CustomTableList'
import Tabs from '@sharedComponents/Tabs'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_ADMIN,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import { useManagePurgeApi } from './hooks/usePurgeApi'
import { useAuthorize } from '@core/context/Authorize'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import Modal from '@sharedComponents/Modal'
import { debounce } from 'lodash'
import CustomButton from '@sharedComponents/Button'
import Loader from '@sharedComponents/Loader'
import appConfig from 'app.config'
import usePurgeUtils from './hooks/usePurgeUtils'
import Warning from '../WarningMessage'
import { useCancelToken } from '@hooks/useCancelToken'
import { useFancyState } from '@core/context/FancyState'
import { queryMetadata } from '@utils/aquarius'
import { useOrganizationName } from '@hooks/useOrganizationName'
import { getFilterIds } from '@hooks/useOrgTransformers'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import { TransformedFilterCriterias } from '@sharedComponents/CustomTableList/types/CustomTableListTypes'

const PurgeAssetList = () => {
  const { organizationMap } = useOrganizationName()
  const [activeAssetList, setActiveAssetList] = useState(null)
  const [activeAssetFilters, setActiveAssetFilters] = useState(null)
  const [activeAssetTotalRecords, setActiveAssetTotalRecords] = useState(0)
  const {
    parentTabIndex,
    handleParentTabChange,
    handleChildTabChange,
    handlePageChange,
    childTabIndex,
    assetsPage,
    userPage,
    handleOnSearch,
    purgeConfig,
    hasFilterApplied,
    assetSearch,
    userSearch,
    filterAssetsOrgName,
    filterAssetsNetwork,
    filterAssetType,
    filterUsersOrgName,
    filterUsersCountry,
    filterUserRole,
    isLoading,
    setIsLoading,
    modal,
    setModal,
    submitPurgeModal,
    submitUnpurgeModal,
    init,
    isInitialLoader,
    setInitialLoader,
    handleRowSelect,
    toggledClearRows,
    refreshList
  } = useManagePurge({ organizationMap })
  const { assetFilters } = useFancyState()
  const { isLogin, isAdmin } = useAuthorize()
  const {
    getResults,
    transformActiveAssetData,
    networkMap,
    getSupportedNetworkSelection
  } = usePurgeUtils({
    organizationMap
  })
  const {
    filterCriterias,
    fetchPurgedUsers,
    fetchActiveUsers,
    purgeUserList,
    fetchPurgedAssets,
    activeUserList,
    totalRecords,
    purgeAssetList,
    fetchAllPurgedAssets,
    errorCode,
    errorMsg
  } = useManagePurgeApi()
  const [transformedFilterCriteria, setTransformedFilterCriteria] =
    useState<TransformedFilterCriterias>({})
  const newCancelToken = useCancelToken()

  const {
    assetsPurge: { config: assetsConfig },
    usersPurge: { config: usersAssetsConfig }
  } = purgeConfig

  const debouncefetch = useCallback(
    debounce((params, type) => {
      if (parentTabIndex === 0 && type === 'purgeAssets') {
        fetchPurgedAssets(params)
      } else if (parentTabIndex === 1) {
        if (type === 'purgeUsers') {
          fetchActiveUsers(params)
        } else if (type === 'unpurgeUsers') {
          fetchPurgedUsers(params)
        }
      }
    }, 500),
    [parentTabIndex]
  )

  const debouncefetchAssets = useCallback(
    debounce((fetchAssets) => {
      fetchAssets()
    }, 500),
    []
  )

  const transformer = (filterCriterias) => {
    const data = filterCriterias
    const updatedData = {}
    for (const key in data) {
      if (data[key]?.length) {
        const updatedKey = Object.fromEntries(
          [...data[key]].map((item) => [
            item,
            filterUserRole[item] ||
              filterUsersCountry[item] ||
              filterUsersOrgName[item] ||
              filterAssetType[item] ||
              filterAssetsNetwork[item] ||
              filterAssetsOrgName[item] ||
              false
          ])
        )
        updatedData[`${key}`] = updatedKey
      }
    }
    return updatedData
  }
  useEffect(() => {
    setTransformedFilterCriteria(transformer(filterCriterias))
  }, [filterCriterias])

  const fetchActiveAssets = async () => {
    const serviceTypes = Object.keys(filterAssetType).filter(
      (key) => filterAssetType[key]
    )
    let networkIds = ''
    const filterAssetsNetworkParam = Object.keys(filterAssetsNetwork).filter(
      (key) => filterAssetsNetwork[key]
    )
    if (filterAssetsNetworkParam?.length) {
      const networkFilterIds = getFilterIds(
        networkMap,
        filterAssetsNetworkParam
      )
      networkIds = networkFilterIds.join(',')
    }
    let orgIds = ''
    const filterAssetsOrgNameParam = Object.keys(filterAssetsOrgName).filter(
      (key) => filterAssetsOrgName[key]
    )
    if (filterAssetsOrgNameParam?.length) {
      const orgFilterIds = getFilterIds(
        organizationMap,
        filterAssetsOrgNameParam
      )
      orgIds = orgFilterIds.join(',')
      if (orgFilterIds?.length === Object.values(organizationMap)?.length) {
        orgIds = ''
      }
    }
    const parsed = {
      offset: '10',
      serviceType: serviceTypes,
      network: networkIds,
      orgID: orgIds,
      page: assetsPage.toString(),
      text: assetSearch
    }
    const searchQuery = getResults(parsed, appConfig.chainIds, assetFilters)
    const queryResult = await queryMetadata(
      searchQuery,
      newCancelToken(),
      setIsLoading,
      setInitialLoader
    )
    const assetType = ['dataset', 'algorithm']
    const organization = Object.values(organizationMap)
    const network = getSupportedNetworkSelection()
    setActiveAssetFilters(transformer({ network, organization, assetType }))
    if (queryResult?.results?.length) {
      const allPurgedAssetList = await fetchAllPurgedAssets()
      const transformedAssetData = await transformActiveAssetData(
        queryResult.results,
        queryResult.totalResults,
        allPurgedAssetList
      )
      setInitialLoader(false)
      setActiveAssetList(transformedAssetData)

      setActiveAssetTotalRecords(transformedAssetData?.totalRecord)
    } else {
      setActiveAssetList(null)
      setActiveAssetTotalRecords(0)
    }
  }

  useEffect(() => {
    if (organizationMap && parentTabIndex === 0) {
      if (childTabIndex === 0) {
        debouncefetchAssets(fetchActiveAssets)
      } else {
        const params = {
          page: assetsPage,
          searchValue: assetSearch,
          setIsLoading,
          organizationMap,
          setInitialLoader,
          filterAssetsOrgName,
          filterAssetsNetwork,
          filterAssetType
        }
        debouncefetch(params, 'purgeAssets')
      }
    } else {
      const params = {
        page: userPage,
        searchValue: userSearch,
        setIsLoading,
        filterUsersOrgName,
        organizationMap,
        setInitialLoader,
        filterUsersCountry,
        filterUserRole
      }
      if (childTabIndex === 0) {
        debouncefetch(params, 'purgeUsers')
      } else {
        debouncefetch(params, 'unpurgeUsers')
      }
    }
  }, [
    organizationMap,
    parentTabIndex,
    childTabIndex,
    filterAssetsOrgName,
    filterAssetsNetwork,
    filterAssetType,
    assetsPage,
    assetSearch,
    userPage,
    userSearch,
    filterUsersOrgName,
    filterUsersCountry,
    filterUserRole,
    isLogin,
    init,
    setInitialLoader,
    setIsLoading,
    refreshList
  ])

  function renderEdgeNodeListData() {
    if (errorMsg || !isAdmin) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = FAILURE_MESSAGES.GENERAL_FAILURE

      const isUnauthorize = errorCode === ERROR_UNAUTH || !isAdmin
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }
    let dataToRender = []
    let filters = transformedFilterCriteria
    let totalRecord = totalRecords
    if (parentTabIndex === 0) {
      if (childTabIndex === 0) {
        dataToRender = activeAssetList?.data
        totalRecord = activeAssetTotalRecords
        filters = activeAssetFilters
      } else {
        dataToRender = purgeAssetList
      }
    } else if (parentTabIndex === 1) {
      if (childTabIndex === 0) {
        dataToRender = activeUserList
      } else {
        dataToRender = purgeUserList
      }
    }
    return (
      <CustomTableList
        configuration={parentTabIndex === 0 ? assetsConfig : usersAssetsConfig}
        data={dataToRender}
        totalRecord={totalRecord}
        isLoading={isLoading}
        paginationSize={10}
        tabIndex={childTabIndex}
        handlePageChange={handlePageChange}
        handleOnTabChange={handleChildTabChange}
        page={parentTabIndex === 0 ? assetsPage : userPage}
        state={''}
        handleOnSearch={handleOnSearch}
        hasFilterApplied={hasFilterApplied}
        filterCriterias={filters}
        isSelectable={true}
        onSelectedRowsChange={handleRowSelect}
        noDataText={
          <>
            <span>
              {parentTabIndex === 0 ? 'No assets yet.' : 'No users yet.'}
            </span>
          </>
        }
        noDataAction={<></>}
        sortBy={''}
        sortOrder={''}
        clearSelectedRows={toggledClearRows}
      />
    )
  }

  return (
    <PrivateRoute>
      {isInitialLoader ? (
        <Loader />
      ) : (
        <>
          {isAdmin && (
            <>
              <section className={styles.grid}>
                <div className={styles.header}>
                  <div>
                    <h3 className="bold">Manage data asset</h3>
                  </div>
                </div>
              </section>
              <Tabs
                items={parentTabs}
                handleTabChange={handleParentTabChange}
                defaultIndex={parentTabIndex}
                className="tabRootFullBorder"
              />
            </>
          )}
          {renderEdgeNodeListData()}
          <Modal
            type={CUSTOM_TYPE}
            title={modal?.title}
            titleSize="h3"
            onToggleModal={() => {
              setModal({ isOpen: false })
            }}
            isOpen={modal?.isOpen}
          >
            {modal?.content}
            <div className={styles.footer}>
              <CustomButton
                color="primary"
                variant="contained"
                className={`mt-1 ${styles.confirmButton}`}
                onClick={
                  modal?.type === 'purge'
                    ? submitPurgeModal
                    : submitUnpurgeModal
                }
              >
                Confirm
              </CustomButton>
            </div>
          </Modal>
        </>
      )}
    </PrivateRoute>
  )
}

export default PurgeAssetList
