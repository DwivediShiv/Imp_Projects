import { customization } from 'app.config'

export const assetsConfig = [
  {
    id: 'assetName',
    title: 'Asset name',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'assetName',
    class: 'assetName',
    rowConfig: {
      cellType: 'assetField',
      clickable: 'false',
      value: 'assetName'
    },
    width: '252px',
    sortField: 'assetName'
  },
  {
    id: 'did',
    title: 'DID',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'did',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'did'
    },
    width: '170px',
    sortField: 'did'
  },
  {
    id: 'publisher',
    title: 'Wallet',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'publisher',
    rowConfig: {
      cellType: 'address',
      clickable: 'false',
      value: 'publisher'
    },
    width: '115px',
    sortField: 'publisher'
  },
  {
    id: 'networkId',
    title: 'Blockchain network',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'networkId',
    rowConfig: {
      cellType: 'network',
      clickable: 'false',
      value: 'networkId'
    },
    width: '123px',
    style: '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
    sortField: 'networkId'
  },
  {
    id: 'orgName',
    title: 'Group',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'orgName',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'orgName'
    },
    width: '122px',
    sortField: 'orgName'
  },
  {
    id: 'datePublished',
    title: 'Publication date',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'datePublished',
    rowConfig: {
      cellType: 'dateField',
      format: customization.dateFormat,
      value: 'datePublished'
    },
    width: '127px',
    sortField: 'datePublished',
    allowOverflow: false
  },
  {
    id: 'assetType',
    title: 'Asset type',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'assetType',
    rowConfig: {
      cellType: 'assetType',
      clickable: 'false',
      value: 'assetType'
    },
    width: '108px',
    sortField: 'assetType',
    allowOverflow: false
  },
  {
    id: 'accessType',
    title: 'Access type',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'accessType',
    rowConfig: {
      cellType: 'accessType',
      clickable: 'false',
      value: 'accessType'
    },
    width: '108px',
    sortField: 'accessType',
    allowOverflow: false
  }
]
