import { customization } from 'app.config'

export const userListConfig = [
  {
    id: 'email',
    title: 'User Name',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'email',
    class: 'email',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'email'
    },
    grow: 1.5,
    style: '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
    sortField: 'email'
  },
  {
    id: 'orgName',
    title: 'Group',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'orgName',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'orgName'
    },
    grow: 1.25,
    style: '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
    sortField: 'orgName'
  },
  {
    id: 'allowedRoles',
    title: 'Roles',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'allowedRoles',
    class: 'allowed_roles',
    rowConfig: {
      cellType: 'default',
      value: 'allowedRoles',
      clickable: 'false',
      class: 'allowedRolesColumn'
    },
    style: '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
    sortField: 'allowed_roles'
  },
  {
    id: 'country',
    title: 'Country',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'country',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'country'
    },
    grow: 1,
    style: '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
    sortField: 'country'
  },
  {
    id: 'created_date',
    title: 'Created Date',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'created_date',
    rowConfig: {
      cellType: 'dateField',
      format: customization.dateFormat,
      value: 'createdDate'
    },
    grow: 1,
    style: '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
    sortField: 'created_date',
    allowOverflow: false
  }
]
