import { AuthorizeProviderValue } from '@core/context/Authorize'
import {
  Column,
  ExportConfig,
  FilterConfig,
  SearchConfig,
  TabConfig
} from '@sharedComponents/CustomTableList/types/CustomTableListTypes'

export interface Config {
  config: {
    title: string
    columns: Column[]
    tabConfig: TabConfig
    exportConfig?: ExportConfig
    searchConfig: SearchConfig
    filterConfig: FilterConfig
    buttonConfig?: any
    refreshConfig?: any
  }
}

export interface Configuration {
  assetsPurge: Config
  usersPurge: Config
}

export interface Modal {
  isOpen: boolean
  content?: string
  title?: string
  type?: string
}

export interface PurgeDetail {
  allowedRoles: string
  blocked: boolean
  country: string
  createdBy: string
  createdDate: string
  email: string
  id: number
  lastUpdateDate: string
  lastUpdatedBy: string
  org_id: string
  profileId: string
  purge_reason: string
  purge_status: boolean
  remark: string
  source: string
  spendLimit: number
  state: string
  userAcceptDate: string
  userInviteDate: string
  length?: number
}

export interface PurgeAsset {
  accessType: string
  assetName: string
  assetType: string
  datePublished: string
  did: string
  networkId: string
  networkName: string
  orgId: string
  orgName: string
  publisher: string
}

export interface ApiResponse<T> {
  data?: T
  Data?: T
  error?: string | { message: string }
  totalRecord?: number
  filterCriterias?: Record<string, string[]>
}

export interface EdgeNodeFilters {
  type: string
  searchValue: string
  filterNetwork: string | string[]
  filterOrgName?: string | string[]
  organizationMap?: string
  status: string
  sortBy: string
  sortOrder: string
}

export interface OrganizationFilter {
  orgId: string
  orgName?: string
}

export interface PurgeList {
  data: PurgeDetail[]
  totalRecord: number
}

export interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
  typeOfData?: string
}

export interface OrgList {
  id: string
  name: string
}

export interface AssetList {
  did: string
  reason: string
}
