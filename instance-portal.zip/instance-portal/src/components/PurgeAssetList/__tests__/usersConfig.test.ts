import { userListConfig } from '../configuration/usersConfig'

describe('assetsConfig', () => {
  it('should have the correct number of columns', () => {
    expect(userListConfig).toHaveLength(5)
  })

  it('should have specific properties in each column', () => {
    userListConfig.forEach((column) => {
      expect(column).toHaveProperty('id')
      expect(column).toHaveProperty('title')
      expect(column).toHaveProperty('type')
      expect(column).toHaveProperty('sortable')
      expect(column).toHaveProperty('rowConfig')
    })
  })

  it('should have valid rowConfig for each column', () => {
    userListConfig.forEach((column) => {
      const { rowConfig } = column
      expect(rowConfig).toHaveProperty('cellType')
      expect(rowConfig).toHaveProperty('value')
    })
  })
})
