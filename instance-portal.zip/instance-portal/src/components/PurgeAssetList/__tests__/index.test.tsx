import React from 'react'
import { render, screen, waitFor } from '@testing-library/react'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'
import PurgeAssetList from '..'
import { purgeListDataHandler } from '../msw/purgeAssetHandler'

const mockRouterBack = jest.fn()
const mockRouterPush = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack,
    push: mockRouterPush
  })
}))

jest.mock('@core/context/FancyState', () => ({
  useFancyState: () => ({
    getOrganizationOptions: jest.fn()
  })
}))

jest.mock('@core/context/Authorize')

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // Deprecated
    removeListener: jest.fn(), // Deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn()
  }))
})

function renderComponent(options) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isAdmin, isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isAdmin,
    isLogin
  })

  return render(<PurgeAssetList />)
}

describe('Purge List list ', () => {
  it('Purge List should render with data', async () => {
    window.URL.createObjectURL = jest.fn()
    purgeListDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(await screen.findByText('Manage data asset')).toBeInTheDocument()
    })
    expect(
      await screen.findByRole('tab', {
        name: /assets/i
      })
    ).toBeInTheDocument()
    // expect(
    //   screen.getByRole('tab', {
    //     name: /users/i
    //   })
    // ).toBeInTheDocument()
    expect(
      await screen.findByRole('tab', {
        name: /active/i
      })
    ).toBeInTheDocument()
    expect(
      await screen.findByRole('tab', {
        name: /suspended/i
      })
    ).toBeInTheDocument()
  })

  //   it('api errors should be handled', async () => {
  //     setupGetOrgDataHandler({
  //       response: {
  //         code: 'Error_UnAuthorizedUserAction',
  //         error: 'User Unauthorized'
  //       },
  //       status: 400
  //     })
  //     renderComponent({
  //       authorize: {
  //         isLogin: true
  //       }
  //     })
  //     expect(await screen.findByText(/Restricted Access/i)).toBeInTheDocument()
  //   })

  //   it('Should not display a table when no data is available', async () => {
  //     setupGetOrgDataHandler({ typeOfData: 'No Record' })
  //     renderComponent({
  //       authorize: {
  //         isLogin: true,
  //         isAdmin: true
  //       }
  //     })
  //     const table = screen.queryByRole('table')

  //     await waitFor(async () => {
  //       expect(table).not.toBeInTheDocument()
  //     })

  //     // expect(
  //     //   await screen.findByRole('heading', { name: /no records found\./i })
  //     // ).toBeInTheDocument()
  //   })
})

// describe('Click of tabs', () => {
//   it('Active tab click', async () => {
//     setupGetOrgDataHandler({ typeOfData: STATUS_CONSTANTS.Active.title })
//     renderComponent({
//       authorize: {
//         isLogin: true,
//         isAdmin: true
//       }
//     })

//     await waitFor(async () => {
//       expect(screen.getByRole('tab', { name: 'All' })).toBeInTheDocument()
//     })

//     const invitedTabEl = screen.getByRole('tab', { name: /\bactive\b/i })
//     user.click(invitedTabEl)

//     await waitFor(async () => {
//       expect(screen.getByText('Nagarro')).toBeInTheDocument()
//     })
//     await waitFor(async () => {
//       expect(screen.getByText('Active')).toBeInTheDocument()
//     })
//   })

//   it('Inactive tab click', async () => {
//     setupGetOrgDataHandler()
//     renderComponent({
//       authorize: {
//         isLogin: true,
//         isAdmin: true
//       }
//     })

//     await waitFor(async () => {
//       expect(screen.getByRole('tab', { name: 'All' })).toBeInTheDocument()
//     })

//     const invitedTabEl = screen.getByRole('tab', { name: /\binactive\b/i })
//     user.click(invitedTabEl)

//     setupGetOrgDataHandler({ typeOfData: STATUS_CONSTANTS.Inactive.title })
//     renderComponent({
//       authorize: {
//         isLogin: true,
//         isAdmin: true
//       }
//     })

//     await waitFor(async () => {
//       expect(screen.getByText('Nagarro Abstract')).toBeInTheDocument()
//     })
//     await waitFor(async () => {
//       expect(screen.getByText('Inactive')).toBeInTheDocument()
//     })
//   })
// })

// describe('search state', () => {
//   it('updates org name state on search input change', async () => {
//     setupGetOrgDataHandler({ typeOfData: 'Nagarro' })
//     renderComponent({
//       authorize: {
//         isLogin: true,
//         isAdmin: true
//       }
//     })
//     await waitFor(async () => {
//       expect(screen.getByPlaceholderText('Search...')).toBeInTheDocument()
//     })

//     const searchInput = screen.getByPlaceholderText('Search...')
//     await user.type(searchInput, 'Nagarro')

//     await waitFor(async () => {
//       expect(searchInput).toHaveValue('Nagarro')
//     })
//   })
// })

// describe('filter states', () => {
//   it('handles country filter', async () => {
//     setupGetOrgDataHandler({ typeOfData: 'Austria, Belgium' })
//     const { container } = renderComponent({
//       authorize: {
//         isLogin: true,
//         isAdmin: true
//       }
//     })
//     await waitFor(async () => {
//       expect(screen.getByPlaceholderText('Search...')).toBeInTheDocument()
//     })

//     const searchInput1 = screen.getByPlaceholderText('Search...')
//     await user.type(searchInput1, 'Nagarro')

//     await waitFor(async () => {
//       expect(searchInput1).toHaveValue('Nagarro')
//     })

//     const searchInput2 = screen.getByTestId('Country')
//     searchInput2.textContent = 'Austria, Belgium'

//     await waitFor(async () => {
//       expect(searchInput2).toHaveTextContent('Austria, Belgium')
//     })

//     await waitFor(async () => {
//       expect(screen.getByText('Nagarro ZXR')).toBeInTheDocument()
//     })
//     await waitFor(async () => {
//       expect(screen.queryByText('Nagarro')).not.toBeInTheDocument()
//     })
//   })

//   it('handles industry filter', async () => {
//     setupGetOrgDataHandler({ typeOfData: 'Aerospace' })
//     const { container } = renderComponent({
//       authorize: {
//         isLogin: true,
//         isAdmin: true
//       }
//     })
//     await waitFor(async () => {
//       expect(screen.getByPlaceholderText('Search...')).toBeInTheDocument()
//     })

//     const searchInput1 = screen.getByPlaceholderText('Search...')
//     user.type(searchInput1, 'Nagarro')

//     await waitFor(async () => {
//       expect(searchInput1).toHaveValue('Nagarro')
//     })

//     const searchInput2 = screen.getByTestId('Industry')
//     searchInput2.textContent = 'Aerospace'

//     await waitFor(async () => {
//       expect(searchInput2).toHaveTextContent('Aerospace')
//     })

//     await waitFor(async () => {
//       expect(screen.getByText('Nagarro ZXR')).toBeInTheDocument()
//     })
//     await waitFor(async () => {
//       expect(screen.queryByText('Nagarro Abstract')).not.toBeInTheDocument()
//     })
//   })
// })

// describe('reset filters', () => {
//   it('handles country filter', async () => {
//     setupGetOrgDataHandler()
//     const { container } = renderComponent({
//       authorize: {
//         isLogin: true,
//         isAdmin: true
//       }
//     })
//     await waitFor(async () => {
//       expect(screen.getByPlaceholderText('Search...')).toBeInTheDocument()
//     })

//     const searchInput1 = screen.getByPlaceholderText('Search...')
//     await user.type(searchInput1, 'Nagarro')

//     await waitFor(async () => {
//       expect(searchInput1).toHaveValue('Nagarro')
//     })

//     const searchInput2 = screen.getByTestId('Country')
//     searchInput2.textContent = 'Austria, Belgium'

//     await waitFor(async () => {
//       expect(searchInput2).toHaveTextContent('Austria, Belgium')
//     })

//     const searchInput3 = screen.getByTestId('Industry')
//     searchInput3.textContent = 'Aerospace'

//     await waitFor(async () => {
//       expect(searchInput3).toHaveTextContent('Aerospace')
//     })

//     const resetButton = screen.getByText('Reset') as HTMLInputElement
//     user.click(resetButton)

//     await waitFor(async () => {
//       expect(searchInput1).toHaveValue('')
//     })
//     await waitFor(async () => {
//       expect(searchInput1).toHaveValue('')
//     })
//     await waitFor(async () => {
//       expect(searchInput1).toHaveValue('')
//     })
//   })
// })
