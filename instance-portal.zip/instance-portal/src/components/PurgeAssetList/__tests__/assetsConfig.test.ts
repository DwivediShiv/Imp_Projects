import { assetsConfig } from '../configuration/assetsConfig'

describe('assetsConfig', () => {
  it('should have the correct number of columns', () => {
    expect(assetsConfig).toHaveLength(8)
  })

  it('should have specific properties in each column', () => {
    assetsConfig.forEach((column) => {
      expect(column).toHaveProperty('id')
      expect(column).toHaveProperty('title')
      expect(column).toHaveProperty('type')
      expect(column).toHaveProperty('sortable')
      expect(column).toHaveProperty('rowConfig')
    })
  })

  it('should have valid rowConfig for each column', () => {
    assetsConfig.forEach((column) => {
      const { rowConfig } = column
      expect(rowConfig).toHaveProperty('cellType')
      expect(rowConfig).toHaveProperty('value')
    })
  })
})
