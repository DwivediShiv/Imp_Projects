import { rest } from 'msw'
import { server } from '@utils/msw'
import appConfig from 'app.config'
import { AssetList, MswHandlerProps, OrgList } from '../types/List'
import { assetListData, orgList } from './purgeAssetData'

export function purgeListDataHandler(props?: MswHandlerProps<OrgList[]>) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(
    `${appConfig.api}//user-management/api/v1/org/list`,
    async (_, res, ctx) => {
      let json
      const data = orgList
      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  const handler1 = rest.get(
    `${appConfig.api}/asset-management/api/v1/purgatory/list-assets`,
    async (_, res, ctx) => {
      let json
      const data = assetListData
      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler, handler1)
}

export function assetListDataHandler(props?: MswHandlerProps<AssetList[]>) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(
    `${appConfig.api}/asset-management/api/v1/purgatory/list-assets`,
    async (_, res, ctx) => {
      let json
      const data = assetListData
      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
