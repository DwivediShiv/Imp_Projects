export const orgList = {
  data: [
    {
      id: '58fd454e-b051-4c54-87ae-c6d3120a521b',
      name: 'ANi AA'
    },
    {
      id: '92532027-fbcb-45a1-b34f-362aaf745ebb',
      name: 'Elaine Instance ORG'
    },
    {
      id: '8e16309c-0ba6-4568-a6a1-9295c18ac283',
      name: 'Nagarro Ish Pvt LTD'
    },
    {
      id: '13ee4205-a385-4063-a0cb-e5435e6895b5',
      name: 'Nagarro Test1'
    },
    {
      id: '6cd2da1b-4713-4d75-9886-fd628b6e1011',
      name: 'Nagarro Test2'
    },
    {
      id: 'bd66c8be-86c6-44c9-8ec2-20cc911d73b4',
      name: 'Potts Buck LLC'
    }
  ]
}

export const assetListData = [
  {
    did: 'did:op:3e90ff42064ccb599ea50f1a6cea554dab0ca4f1c7f2d5e59896accd5e23db42',
    reason: 'Purging asset'
  },
  {
    did: 'did:op:743c8e9e58dcff87153fea2a6a4e42528c4b71879a0ec5171a7b1a966f2a5b17',
    reason: 'Purging asset'
  }
]
