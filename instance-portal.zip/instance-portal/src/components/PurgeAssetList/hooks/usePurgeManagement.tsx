import { SELECTION_CONSTANTS } from '@constants/constants'
import React, { useCallback, useMemo, useState } from 'react'
import { useManagePurgeApi } from './usePurgeApi'
import { userListConfig } from '../configuration/usersConfig'
import { assetsConfig } from '../configuration/assetsConfig'
import { Modal } from '../types/List'
import { hasSelection } from '@sharedComponents/CustomTableList/hook/useCustomTableList'

export const parentTabs = [
  {
    title: 'Assets',
    value: 'assets',
    index: 0
  }
]

export const useManagePurge = ({ organizationMap }) => {
  const [parentTabIndex, setParentTabIndex] = useState<number>(0)
  const [childTabIndex, setChildTabIndex] = useState<number>(0)
  const [isLoading, setIsLoading] = useState<boolean>()
  const [isInitialLoader, setInitialLoader] = useState<boolean>(true)
  const [assetsPage, setAssetsPage] = useState<number>(1)
  const [userPage, setUserPage] = useState<number>(1)
  const [assetSearch, setAssetSearch] = useState<string>('')
  const [userSearch, setUserSearch] = useState<string>('')
  const [modal, setModal] = useState<Modal>({ isOpen: false })
  const [refreshList, setRefreshList] = useState<number>(0)
  const [userProfileId, setUserProfileId] = useState<string[]>([])
  const [init, setInit] = useState<boolean>()
  const [assetSelectedRows, setAssetSelectedRows] = useState([])
  const [toggledClearRows, setToggleClearRows] = useState(false)

  const [filterAssetsOrgName, setFilterAssetsOrgName] = useState<
    Record<string, boolean>
  >({})
  const [filterAssetsNetwork, setFilterAssetsNetwork] = useState<
    Record<string, boolean>
  >({})
  const [filterAssetType, setFilterAssetType] = useState<
    Record<string, boolean>
  >({})

  const [filterUsersOrgName, setFilterUsersOrgName] = useState<
    Record<string, boolean>
  >({})
  const [filterUserRole, setFilterUserRole] = useState<Record<string, boolean>>(
    {}
  )
  const [filterUsersCountry, setFilterUsersCountry] = useState<
    Record<string, boolean>
  >({})

  const { purgeUsers, unpurgeUsers, purgeAssets, unpurgeAssets } =
    useManagePurgeApi()

  const handleRowSelect = ({ selectedRows }) => {
    if (parentTabIndex === 0) {
      const assetRows = selectedRows?.map((row) => {
        const {
          did,
          assetName,
          assetType,
          networkId,
          orgId,
          publisher,
          accessType,
          datePublished,
          markedForPurge
        } = row
        return {
          did,
          assetName,
          assetPublishedDate: datePublished,
          assetType,
          acceessType: accessType,
          network: networkId?.toString(),
          organization: orgId,
          walletAddress: publisher,
          markedForPurge
        }
      })
      setAssetSelectedRows(assetRows)
    } else {
      const profileIds = selectedRows?.map((row) => row.profileId)
      setUserProfileId(profileIds)
    }
  }

  async function submitPurgeModal() {
    if (parentTabIndex === 0) {
      await purgeAssets({ assets: assetSelectedRows, reason: 'Purging asset' })
      setAssetSelectedRows([])
    } else {
      await purgeUsers({ profileIds: userProfileId, reason: 'Purging User' })
      setUserProfileId([])
    }
    setModal({ isOpen: false })
    setInit(!init)
    setToggleClearRows(!toggledClearRows)
  }

  async function submitUnpurgeModal() {
    if (parentTabIndex === 0) {
      await unpurgeAssets({ dids: assetSelectedRows.map((row) => row?.did) })
      setAssetSelectedRows([])
    } else {
      await unpurgeUsers({ profileIds: userProfileId })
      setUserProfileId([])
    }
    setModal({ isOpen: false })
    setInit(!init)
    setToggleClearRows(!toggledClearRows)
  }

  const handleClearFilter = () => {
    if (parentTabIndex === 0) {
      setAssetsPage(1)
      setFilterAssetsNetwork({})
      setFilterAssetsOrgName({})
      setFilterAssetType({})
      setAssetSearch('')
      setAssetSelectedRows([])
      setToggleClearRows(!toggledClearRows)
    } else {
      setUserPage(1)
      setFilterUsersOrgName({})
      setFilterUserRole({})
      setFilterUsersCountry({})
      setUserSearch('')
      setUserProfileId([])
      setToggleClearRows(!toggledClearRows)
    }
  }

  const assetFilterTypes = ['AssetsNetwork', 'AssetsOrgName', 'AssetsType']
  const userFilterTypes = ['UserRole', 'UserOrgName', 'UserCountryName']

  const handleFilterSelect = (
    items: Record<string, boolean>,
    type:
      | 'AssetsNetwork'
      | 'AssetsOrgName'
      | 'AssetsType'
      | 'UserRole'
      | 'UserOrgName'
      | 'UserCountryName'
  ) => {
    assetFilterTypes.includes(type) && setAssetsPage(1)
    userFilterTypes.includes(type) && setUserPage(1)
    switch (type) {
      case 'AssetsNetwork':
        setFilterAssetsNetwork(items)
        break
      case 'AssetsOrgName':
        setFilterAssetsOrgName(items)
        break
      case 'AssetsType':
        setFilterAssetType(items)
        break
      case 'UserRole':
        setFilterUserRole(items)
        break
      case 'UserOrgName':
        setFilterUsersOrgName(items)
        break
      case 'UserCountryName':
        setFilterUsersCountry(items)
        break
    }
  }

  const hasFilterApplied = () => {
    if (parentTabIndex === 0) {
      return (
        assetSearch !== '' ||
        hasSelection(filterAssetsOrgName) ||
        hasSelection(filterAssetsNetwork) ||
        hasSelection(filterAssetType) ||
        assetSelectedRows?.length > 0
      )
    } else {
      return (
        userSearch !== '' ||
        hasSelection(filterUsersOrgName) ||
        hasSelection(filterUserRole) ||
        hasSelection(filterUsersCountry) ||
        userProfileId?.length > 0
      )
    }
  }

  const purgeConfig = useMemo(() => {
    const modalContent = (action: string) =>
      (
        <>
          Are you sure to {action} the selected{' '}
          <b>{assetSelectedRows.length}</b> asset(s)
        </>
      ) as unknown as string
    return {
      assetsPurge: {
        config: {
          title: '',
          searchConfig: {
            type: 'search',
            name: 'search',
            placeholder: 'Search',
            searchValue: assetSearch
          },
          refreshConfig: {
            name: 'Refresh list',
            handleRefreshList: () => setRefreshList(Math.random())
          },
          buttonConfig:
            childTabIndex === 0
              ? {
                  title: 'Suspend asset(s)',
                  disable:
                    assetSelectedRows?.length < 1 ||
                    assetSelectedRows?.filter((asset) => asset.markedForPurge)
                      .length > 0,
                  handleClick: () => {
                    setModal({
                      isOpen: true,
                      title: 'Suspend asset',
                      content: modalContent('suspend'),
                      type: 'purge'
                    })
                  }
                }
              : {
                  title: 'Unsuspend asset(s)',
                  disable: assetSelectedRows?.length < 1,
                  handleClick: () =>
                    setModal({
                      isOpen: true,
                      title: 'Unsuspend asset',
                      content: modalContent('unsuspend'),
                      type: 'unpurge'
                    })
                },
          columns: [...assetsConfig],
          tabConfig: {
            name: 'Purge management',
            defaultTab: 0,
            tabList: [
              {
                title: 'Active',
                key: 'active',
                value: 'active',
                icon: 'success',
                index: 0
              },
              {
                title: 'Suspended',
                key: 'assetsPurged',
                value: 'assetsPurged',
                index: 1,
                icon: 'warning'
              }
            ]
          },
          filterConfig: {
            clearFilters: handleClearFilter,
            filters: [
              {
                id: 'network',
                inputName: 'network',
                label: 'Blockchain network',
                dynamic: true,
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                value: filterAssetsNetwork,
                selectType: 'network',
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterAssetsNetwork,
                onChange: (items) => {
                  handleFilterSelect(items, 'AssetsNetwork')
                }
              },
              {
                id: 'organization',
                inputName: 'organization',
                label: 'Group',
                dynamic: true,
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                value: filterAssetsOrgName,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterAssetsOrgName,
                onChange: (items) => {
                  handleFilterSelect(items, 'AssetsOrgName')
                }
              },
              {
                id: 'assetType',
                inputName: 'assetType',
                label: 'Asset type',
                dynamic: true,
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                value: filterAssetType,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterAssetType,
                onChange: (items) => {
                  handleFilterSelect(items, 'AssetsType')
                }
              }
            ]
          }
        }
      },
      usersPurge: {
        config: {
          title: '',
          searchConfig: {
            type: 'search',
            name: 'search',
            placeholder: 'Search',
            searchValue: userSearch
          },
          refreshConfig: {
            name: 'Refresh list',
            handleRefreshList: () => setRefreshList(Math.random())
          },
          buttonConfig:
            childTabIndex === 0
              ? {
                  title: 'Purge User(s)',
                  disable: userProfileId?.length < 1,
                  handleClick: () =>
                    setModal({
                      isOpen: true,
                      title: 'Confirm Purge User',
                      content:
                        'Are you sure you want to purge selected user(s)?',
                      type: 'purge'
                    })
                }
              : {
                  title: 'Unpurge User(s)',
                  disable: userProfileId?.length < 1,
                  handleClick: () =>
                    setModal({
                      isOpen: true,
                      title: 'Confirm Unpurge User',
                      content:
                        'Are you sure you want to unpurge selected user(s)?',
                      type: 'unpurge'
                    })
                },
          columns: [...userListConfig],
          tabConfig: {
            name: 'Purge management',
            defaultTab: 0,
            tabList: [
              {
                title: 'Active',
                key: 'active',
                value: 'active',
                index: 0,
                icon: 'success'
              },
              {
                title: 'Purged',
                key: 'userPurged',
                value: 'userPurged',
                index: 1,
                icon: 'warning'
              }
            ]
          },
          filterConfig: {
            clearFilters: handleClearFilter,
            filters: [
              {
                id: 'OrgId',
                inputName: 'OrgId',
                label: 'Organization',
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                dynamic: true,
                value: filterUsersOrgName,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterUsersOrgName,
                onChange: (items) => {
                  handleFilterSelect(items, 'UserOrgName')
                }
              },
              {
                id: 'Roles',
                inputName: 'Roles',
                label: 'User Roles',
                dynamic: true,
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                value: filterUserRole,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterUserRole,
                onChange: (items) => {
                  handleFilterSelect(items, 'UserRole')
                }
              },
              {
                id: 'Country',
                inputName: 'Country',
                label: 'Country',
                dynamic: true,
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                value: filterUsersCountry,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterUsersCountry,
                onChange: (items) => {
                  handleFilterSelect(items, 'UserCountryName')
                }
              }
            ]
          }
        }
      }
    }
  }, [
    assetSearch,
    userSearch,
    filterAssetsOrgName,
    filterAssetsNetwork,
    filterAssetType,
    filterUsersOrgName,
    filterUsersCountry,
    filterUserRole,
    childTabIndex,
    organizationMap,
    assetSelectedRows,
    userProfileId
  ])

  const clearAssetFilterProps = () => {
    setAssetsPage(1)
    setAssetSearch('')
    setFilterAssetsNetwork({})
    setFilterAssetsOrgName({})
    setFilterAssetType({})
    setAssetSelectedRows([])
    setToggleClearRows(!toggledClearRows)
  }

  const clearUsersFilterProps = () => {
    setUserPage(1)
    setUserSearch('')
    setFilterUsersCountry({})
    setFilterUserRole({})
    setFilterUsersOrgName({})
    setUserProfileId([])
    setToggleClearRows(!toggledClearRows)
  }

  const handleParentTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setParentTabIndex(newValue)
    setChildTabIndex(0)
    if (newValue === 0) {
      clearUsersFilterProps()
    } else {
      clearAssetFilterProps()
    }
  }

  const handleChildTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setChildTabIndex(newValue)
    if (parentTabIndex === 0) {
      clearAssetFilterProps()
    } else {
      clearUsersFilterProps()
    }
  }

  const handlePageChange = (page) => {
    parentTabIndex === 0 ? setAssetsPage(page) : setUserPage(page)
  }

  const handleOnSearch = (e) => {
    if (parentTabIndex === 0) {
      setAssetsPage(1)
      setAssetSearch(e.target.value)
    } else {
      setUserPage(1)
      setUserSearch(e.target.value)
    }
  }

  return {
    handleParentTabChange,
    handleChildTabChange,
    parentTabIndex,
    childTabIndex,
    handlePageChange,
    assetsPage,
    userPage,
    handleOnSearch,
    assetSearch,
    userSearch,
    purgeConfig,
    hasFilterApplied,
    filterAssetsOrgName,
    filterAssetsNetwork,
    filterAssetType,
    filterUsersOrgName,
    filterUsersCountry,
    filterUserRole,
    isLoading,
    setIsLoading,
    modal,
    setModal,
    submitPurgeModal,
    submitUnpurgeModal,
    init,
    isInitialLoader,
    setInitialLoader,
    handleRowSelect,
    toggledClearRows,
    setRefreshList,
    refreshList
  }
}
