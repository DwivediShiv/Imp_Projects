import {
  STATE_ACTIVE,
  TYPE_ACCESS,
  TYPE_COMPUTE,
  TYPE_PRIVATE,
  TYPE_PUBLIC
} from '@constants/constants'
import { useCancelToken } from '@hooks/useCancelToken'
import { getFilterTerm, transformChainIdsListToQuery } from '@utils/aquarius'
import { getNetworkDisplayName, networkMap } from '@utils/getNetworkDisplayName'
import appConfig from 'app.config'
import { isBoolean } from 'lodash'

const usePurgeUtils = ({ organizationMap = {} }) => {
  const newCancelToken = useCancelToken()
  const escapeESReservedChars = (text) => {
    return text
      ? text.replace(/([!*+\-=<>&|()\\[\]{}^~?:\\/"])/g, '\\$1')
      : text
  }

  const sortTermDicionary = {
    price: 'price.value',
    provider: 'service.serviceEndpoint',
    size: 'service.attributes.main.files.contentLength'
  }

  const getSortTerm = (sort) => {
    return sortTermDicionary[sort] || sort || 'metadata.created'
  }

  const SortValueOptions = {
    Ascending: 'asc',
    Descending: 'desc'
  }

  const appendNoSpecialCharSearch = (
    specialCharText: string,
    text: string,
    orConditions: any[],
    searchFields: string[]
  ) => {
    if (!text || !specialCharText) {
      return
    }
    let searchTerm = specialCharText.replace(
      /([!*+\-=<>&|()\\[\]{}^~?:\\/"])/g,
      ''
    )
    searchTerm = searchTerm && searchTerm.trim()
    if (searchTerm === text || !searchTerm) {
      return
    }

    const modifiedSearchTerm = searchTerm?.split(' ').join(' OR ').trim()
    const noSpaceSearchTerm = searchTerm?.split(' ').join('').trim()
    const prefixedSearchTerm = `*${searchTerm}*`
    modifiedSearchTerm &&
      orConditions.push({
        query_string: {
          query: `${modifiedSearchTerm}`,
          fields: searchFields,
          minimum_should_match: '2<75%',
          phrase_slop: 2,
          boost: 5
        }
      })
    noSpaceSearchTerm &&
      orConditions.push({
        query_string: {
          query: `${noSpaceSearchTerm}*`,
          fields: searchFields,
          boost: 5,
          lenient: true
        }
      })
    searchTerm &&
      orConditions.push({
        match_phrase: {
          content: {
            query: `${searchTerm}`,
            boost: 10
          }
        }
      })
    prefixedSearchTerm &&
      orConditions.push({
        query_string: {
          query: `${prefixedSearchTerm}`,
          fields: searchFields,
          default_operator: 'AND'
        }
      })
  }

  const addOrgToQuery = (matches, orgID) => {
    if (!orgID) {
      return
    }
    matches.push({
      match: {
        'metadata.additionalInformation.organization': `${orgID}`
      }
    })
  }

  const splitString = (input) => {
    const output = input && typeof input === 'string' ? input.split(',') : input
    return output
  }

  const getDataTypeConditions = (assetType, accessType) => {
    let isAlgo = false
    let isDataset = false
    const accessTypes = splitString(accessType)
    const serviceTypes = splitString(assetType)
    const orConditions = []

    accessTypes?.forEach((type: string) => {
      if (type === TYPE_PRIVATE || type === TYPE_PUBLIC) {
        isAlgo = true
        orConditions.push({
          bool: {
            must: [
              {
                match: {
                  'metadata.type': 'algorithm'
                }
              },
              {
                match: {
                  'services.type': `${
                    type === TYPE_PRIVATE ? 'compute' : 'access'
                  }`
                }
              }
            ]
          }
        })
      }
      if (type === TYPE_COMPUTE || type === TYPE_ACCESS) {
        isDataset = true
        orConditions.push({
          bool: {
            must: [
              {
                match: {
                  'metadata.type': 'dataset'
                }
              },
              {
                match: {
                  'services.type': `${type}`
                }
              }
            ]
          }
        })
      }
    })
    serviceTypes &&
      serviceTypes?.indexOf('algorithm') !== -1 &&
      !isAlgo &&
      orConditions.push({
        match: {
          'metadata.type': 'algorithm'
        }
      })
    serviceTypes &&
      serviceTypes?.indexOf('dataset') !== -1 &&
      !isDataset &&
      orConditions.push({
        match: {
          'metadata.type': 'dataset'
        }
      })
    return orConditions
  }

  const addDataTypeFilterToQuery = (
    matches,
    assetTypeFilter,
    accessTypeFilter
  ) => {
    if (assetTypeFilter === 'dataset,algorithm') {
      assetTypeFilter = undefined
    }
    const orConditions = getDataTypeConditions(
      assetTypeFilter,
      accessTypeFilter
    )
    if (orConditions.length) {
      matches.push({
        bool: {
          should: orConditions
        }
      })
    }
  }

  const isTrue = (input) => {
    if (isBoolean(input)) {
      return input === true
    }
    return input === 'true'
  }

  const getSearchQuery = ({
    chainIds,
    text,
    orgID,
    page,
    offset,
    sort,
    sortOrder,
    serviceType,
    accessType
  }) => {
    const queryMatches = []
    const orConditions = []

    const specialCharText = text
    text = escapeESReservedChars(text)
    const emptySearchTerm = text === undefined || text === ''
    let searchTerm = text || ''

    searchTerm = searchTerm.trim()
    const modifiedSearchTerm = searchTerm?.split(' ').join(' OR ').trim()
    const noSpaceSearchTerm = searchTerm?.split(' ').join('').trim()

    const prefixedSearchTerm =
      emptySearchTerm && searchTerm
        ? searchTerm
        : !emptySearchTerm && searchTerm
        ? '*' + searchTerm + '*'
        : '**'

    const searchFields = [
      'id',
      'nft.owner',
      'datatokens.address',
      'datatokens.name',
      'datatokens.symbol',
      'metadata.name^10',
      'metadata.author',
      'metadata.description',
      'services.description',
      'metadata.tags'
    ]
    const sortTerm = getSortTerm(sort)
    const sortValue = sortOrder === SortValueOptions.Ascending ? 'asc' : 'desc'
    appendNoSpecialCharSearch(specialCharText, text, orConditions, searchFields)

    const fancyMatches = [
      {
        query_string: {
          query: `(${transformChainIdsListToQuery(chainIds)})`
        }
      }
    ]
    addOrgToQuery(fancyMatches, orgID)
    addDataTypeFilterToQuery(fancyMatches, serviceType, accessType)

    modifiedSearchTerm &&
      orConditions.push({
        query_string: {
          query: `${modifiedSearchTerm}`,
          fields: searchFields,
          minimum_should_match: '2<75%',
          phrase_slop: 2,
          boost: 5
        }
      })
    noSpaceSearchTerm &&
      orConditions.push({
        query_string: {
          query: `${noSpaceSearchTerm}*`,
          fields: searchFields,
          boost: 5,
          lenient: true
        }
      })
    searchTerm &&
      orConditions.push({
        match_phrase: {
          content: {
            query: `${searchTerm}`,
            boost: 10
          }
        }
      })
    prefixedSearchTerm &&
      orConditions.push({
        query_string: {
          query: `${prefixedSearchTerm}`,
          fields: searchFields,
          default_operator: 'AND'
        }
      })
    orConditions.length &&
      queryMatches.push({
        bool: {
          should: orConditions
        }
      })

    const from = (Number(page) - 1 || 0) * (Number(offset) || 12)

    const fancyFilters = [
      {
        query_string: {
          query: `${transformChainIdsListToQuery(chainIds)}`
        }
      },
      {
        term: {
          'purgatory.state': false
        }
      },
      getFilterTerm('nft.state', STATE_ACTIVE)
    ]

    return {
      from,
      size: Number(offset) || 12,
      query: {
        bool: {
          must: [
            ...queryMatches,
            {
              match: {
                'metadata.additionalInformation.source': `${appConfig.source}`
              }
            },
            ...fancyMatches
          ],
          must_not: [
            {
              wildcard: {
                _index: '*_histories'
              }
            }
          ],
          filter: fancyFilters
        }
      },
      sort: {
        [sortTerm]: sortValue
      }
    }
  }

  const convertNetwork = (networkList, chainIds) => {
    if (!networkList) return chainIds
    const list = networkList.split(',')
    for (let i = 0; i < list.length; i++) {
      list[i] = Number(list[i])
    }
    return list
  }

  const getResults = (params, chainIds, assetFilters) => {
    const {
      text,
      orgID,
      page,
      offset,
      sort,
      sortOrder,
      serviceType,
      accessType,
      network
    } = params

    const searchQuery = getSearchQuery({
      chainIds: convertNetwork(network, chainIds),
      text,
      orgID,
      page,
      offset,
      sort,
      sortOrder,
      serviceType,
      accessType
    })
    return searchQuery
  }

  const getAssetsBestPrices = (assets) => {
    const assetsWithPrice = []
    for (const ddo of assets) {
      assetsWithPrice.push({
        ddo
      })
    }
    return assetsWithPrice
  }

  const getSupportedNetworkSelection = (): any => {
    const selection = []
    for (let i = 0; i < appConfig.chainIdsSupported.length; i++) {
      selection.push(networkMap[appConfig.chainIdsSupported[i]])
    }
    return selection
  }

  const transformActiveAssetData = async (
    assets,
    totalRecords,
    allPurgedAssetList
  ) => {
    const combinedAsset = []
    for (const asset of assets) {
      const { id } = asset
      const markedForPurge = allPurgedAssetList.find((x) => x.did === id)
      combinedAsset.push({
        assetName: asset.metadata.name,
        id: id.replace('did:', ''),
        did: id,
        markedForPurge: !!markedForPurge,
        publisher:
          asset.metadata.additionalInformation.signer || asset.nft.owner,
        networkId: asset.chainId,
        orgId: asset.metadata.additionalInformation.organization,
        orgName: organizationMap
          ? organizationMap[asset.metadata.additionalInformation.organization]
          : '',
        networkName: getNetworkDisplayName(asset.chainId),
        datePublished: asset.metadata.created,
        assetType: asset.metadata.type,
        accessType: asset.services[0].type
      })
    }

    const response = {
      totalRecord: totalRecords,
      data: combinedAsset
    }
    return response
  }

  return {
    newCancelToken,
    getResults,
    getAssetsBestPrices,
    transformActiveAssetData,
    getSupportedNetworkSelection,
    networkMap
  }
}

export default usePurgeUtils
