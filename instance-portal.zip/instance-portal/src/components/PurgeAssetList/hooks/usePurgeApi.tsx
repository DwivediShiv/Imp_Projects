import React, { useCallback, useState } from 'react'
import axios from 'axios'
import appConfig from 'app.config'
import { ERROR_MSG, PURGE_USER, UNPURGE_USER } from '@constants/constants'
import { ApiResponse, PurgeAsset, PurgeDetail } from '../types/List'
import Toast from '@sharedComponents/Toast'
import {
  getFilterIds,
  tranformedOrgFilters,
  transformDataWithOrgName
} from '@hooks/useOrgTransformers'
import {
  getNetworkDisplayName,
  getNetworkFilterIds
} from '@utils/getNetworkDisplayName'

export const useManagePurgeApi = () => {
  const [activeUserList, setActiveUserList] = useState<PurgeDetail[] | null[]>(
    null
  )
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [errorMsg, setErrorMsg] = useState<string | null>('')
  const [errorCode, setErrorCode] = useState<string | null>('')
  const [purgeUserList, setPurgeUserList] = useState<PurgeDetail[] | null[]>(
    null
  )
  const [purgeAssetList, setPurgeAssetList] = useState<PurgeAsset[] | null[]>(
    null
  )

  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>()

  const activeUserListUrl = `${appConfig.api}/user-management/api/v1/org/all-users-list/false`
  const purgedUserListUrl = `${appConfig.api}/user-management/api/v1/org/all-users-list/true`
  const purgedAssetListUrl = `${appConfig.api}/asset-management/api/v1/purgatory/asset/list/`

  const purgeUnpurgeToastMsg = (assetCount: number | null, action: string) => ({
    success: (
      <>
        The selected <b>{assetCount}</b> asset(s) has been {action}{' '}
        successfully.
      </>
    ) as unknown as string,
    error: (
      <>
        The selected asset(s) could not {action} at the moment. Please try again
        later.
      </>
    ) as unknown as string
  })

  const fetchActiveUsers = useCallback(
    async ({
      page,
      searchValue,
      setIsLoading,
      filterUsersOrgName,
      organizationMap,
      setInitialLoader,
      filterUsersCountry,
      filterUserRole
    }) => {
      try {
        const payload: Record<string, string | string[]> = {}
        setErrorMsg('')
        setTotalRecords(0)
        setIsLoading(true)

        if (page) {
          payload.page = page
        }

        if (searchValue !== '') {
          payload.email = searchValue
        }

        if (filterUsersOrgName?.length) {
          const orgfilterIds = getFilterIds(organizationMap, filterUsersOrgName)
          payload.orgs = orgfilterIds
        }

        if (filterUsersCountry?.length) {
          payload.countries = filterUsersCountry
        }

        if (filterUserRole?.length) {
          payload.roles = filterUserRole
        }

        const { data: response } = await axios.post(activeUserListUrl, payload)

        organizationMap
          ? setActiveUserList(
              transformDataWithOrgName(response.data, organizationMap, 'org_id')
            )
          : setActiveUserList(response.data)

        if (response?.filterCriterias) {
          const orgFilterList = tranformedOrgFilters(
            response.filterCriterias?.OrgId,
            organizationMap
          )

          const filters = {
            OrgId: orgFilterList?.map((orgFilter) => orgFilter.orgName),
            Roles: response.filterCriterias?.Roles,
            Country: response.filterCriterias?.Country
          }
          setFilterCriterias(filters)
        }

        setTotalRecords(response.totalRecord)
      } catch (error) {
        console.error(error)
        setErrorCode(error?.response?.data?.code || 'General')

        if (axios.isAxiosError(error)) {
          setErrorMsg(error?.response?.data?.error)
        } else {
          setErrorMsg('unexpected error')
        }
      } finally {
        setIsLoading(false)
        setInitialLoader(false)
      }
    },
    []
  )

  const fetchPurgedUsers = useCallback(
    async ({
      page,
      searchValue,
      setIsLoading,
      filterUsersCountry,
      filterUsersOrgName,
      setInitialLoader,
      filterUserRole,
      organizationMap
    }) => {
      try {
        const payload: Record<string, string | string[]> = {}
        setErrorMsg('')
        setTotalRecords(0)
        setIsLoading(true)

        if (page) {
          payload.page = page
        }
        if (filterUserRole?.length) {
          payload.roles = filterUserRole
        }
        if (searchValue !== '') {
          payload.email = searchValue
        }

        if (filterUsersOrgName?.length) {
          const orgfilterIds = getFilterIds(organizationMap, filterUsersOrgName)
          payload.orgs = orgfilterIds
        }
        if (filterUsersCountry?.length) {
          payload.countries = filterUsersCountry
        }

        const { data: response } = await axios.post(purgedUserListUrl, payload)

        organizationMap
          ? setPurgeUserList(
              transformDataWithOrgName(response.data, organizationMap, 'org_id')
            )
          : setPurgeUserList(response.data)

        if (response?.filterCriterias) {
          const orgFilterList = tranformedOrgFilters(
            response.filterCriterias?.OrgId,
            organizationMap
          )

          const filters = {
            OrgId: orgFilterList?.map((orgFilter) => orgFilter.orgName),
            Roles: response.filterCriterias?.Roles,
            Country: response.filterCriterias?.Country
          }
          setFilterCriterias(filters)
        }

        setTotalRecords(response.totalRecord)
      } catch (error) {
        console.error(error)
        setErrorCode(error?.response?.data?.code || 'General')
        if (axios.isAxiosError(error)) {
          setErrorMsg(error?.response?.data?.error)
        } else {
          setErrorMsg('unexpected error')
        }
      } finally {
        setIsLoading(false)
        setInitialLoader(false)
      }
    },
    []
  )

  const purgeUsers = useCallback(async ({ profileIds, reason }) => {
    try {
      const purgeUserUrl = `${appConfig.api}/user-management/api/v1/org/purge-user`

      const response = await axios.put(purgeUserUrl, {
        profileIds,
        reason
      })
      Toast('success', PURGE_USER)
      return response
    } catch (error) {
      console.error(error)
      Toast('error', ERROR_MSG)
    }
  }, [])

  const unpurgeUsers = useCallback(async ({ profileIds }) => {
    try {
      const unpurgeUserUrl = `${appConfig.api}/user-management/api/v1/org/unpurge-user`

      const response = await axios.put(unpurgeUserUrl, { profileIds })
      Toast('success', UNPURGE_USER)
      return response
    } catch (error) {
      console.error(error)
      Toast('error', ERROR_MSG)
    }
  }, [])

  const transformPurgeAssetList = (list) => {
    const transformedList = list.map((data) => {
      const {
        accessType,
        assetName,
        assetPublishedDate,
        assetType,
        did,
        network,
        organization,
        walletAddress
      } = data
      return {
        accessType,
        assetName,
        did,
        networkId: network,
        publisher: walletAddress,
        orgId: organization,
        assetType,
        datePublished: assetPublishedDate,
        networkName: getNetworkDisplayName(network)
      }
    })
    return transformedList
  }

  const fetchPurgedAssets = useCallback(
    async ({
      page,
      searchValue,
      setIsLoading,
      setInitialLoader,
      organizationMap,
      filterAssetsOrgName,
      filterAssetsNetwork,
      filterAssetType
    }) => {
      try {
        const payload: Record<string, string | string[]> = {}
        setErrorMsg('')
        setTotalRecords(0)
        setIsLoading(true)

        if (page) {
          payload.page = page
        }

        const filterAssetsNetworkParam = Object.keys(
          filterAssetsNetwork
        ).filter((key) => filterAssetsNetwork[key])

        if (filterAssetsNetworkParam?.length) {
          const networkFilterIds = getNetworkFilterIds(filterAssetsNetworkParam)
          payload.networks = networkFilterIds
        }
        if (searchValue !== '') {
          payload.assetName = searchValue
        }

        const filterAssetsOrgNameParam = Object.keys(
          filterAssetsOrgName
        ).filter((key) => filterAssetsOrgName[key])

        if (filterAssetsOrgNameParam?.length) {
          const orgfilterIds = getFilterIds(
            organizationMap,
            filterAssetsOrgNameParam
          )
          payload.organizations = orgfilterIds
        }

        const filterAssetTypeParam = Object.keys(filterAssetType).filter(
          (key) => filterAssetType[key]
        )

        if (filterAssetTypeParam?.length) {
          payload.assetTypes = filterAssetTypeParam
        }

        const { data: response } = await axios.post<ApiResponse<PurgeDetail>>(
          purgedAssetListUrl,
          payload
        )
        if (response.Data?.length) {
          const transformedList = transformPurgeAssetList(response.Data)
          organizationMap
            ? setPurgeAssetList(
                transformDataWithOrgName(transformedList, organizationMap)
              )
            : setPurgeAssetList(transformedList)
        } else {
          setPurgeAssetList(null)
        }

        if (response?.filterCriterias) {
          const orgFilterList = tranformedOrgFilters(
            response.filterCriterias?.Organizations,
            organizationMap
          )

          const filters = {
            organization: orgFilterList?.map((orgFilter) => orgFilter.orgName),
            network: response.filterCriterias?.Networks?.map((id) =>
              getNetworkDisplayName(id)
            ),
            assetType: response.filterCriterias?.AssetTypes
          }
          setFilterCriterias(filters)
        }

        setTotalRecords(response.totalRecord)
      } catch (error) {
        setErrorCode(error?.response?.data?.code || 'General')
        setPurgeAssetList(null)
        if (axios.isAxiosError(error)) {
          setErrorMsg(error?.response?.data?.error)
        } else {
          setErrorMsg('unexpected error')
        }
        console.error(error)
      } finally {
        setIsLoading(false)
        setInitialLoader(false)
      }
    },
    []
  )

  const purgeAssets = useCallback(async ({ assets, reason }) => {
    try {
      const purgeAssetUrl = `${appConfig.api}/asset-management/api/v1/purgatory/asset/purge/`

      const response = await axios.put(purgeAssetUrl, {
        assets,
        reason
      })
      Toast('success', purgeUnpurgeToastMsg(assets.length, 'suspended').success)
    } catch (error) {
      console.error(error)
      Toast('error', purgeUnpurgeToastMsg(null, 'suspended').error)
    }
  }, [])

  const fetchAllPurgedAssets = useCallback(async () => {
    try {
      const purgeAssetUrl = `${appConfig.api}/asset-management/api/v1/purgatory/list-assets`
      const response = await axios.get(purgeAssetUrl)
      return response.data
    } catch (error) {
      console.error(error)
    }
  }, [])

  const unpurgeAssets = useCallback(async ({ dids }) => {
    try {
      const unpurgeAssetUrl = `${appConfig.api}/asset-management/api/v1/purgatory/asset/active/`

      const response = await axios.put(unpurgeAssetUrl, { dids })
      Toast('success', purgeUnpurgeToastMsg(dids.length, 'unsuspended').success)
      return response
    } catch (error) {
      console.error(error)
      Toast('error', purgeUnpurgeToastMsg(null, 'unsuspended').error)
    }
  }, [])

  return {
    filterCriterias,
    fetchPurgedUsers,
    fetchActiveUsers,
    purgeUsers,
    purgeUserList,
    errorMsg,
    activeUserList,
    unpurgeUsers,
    totalRecords,
    setTotalRecords,
    fetchPurgedAssets,
    purgeAssetList,
    purgeAssets,
    fetchAllPurgedAssets,
    unpurgeAssets,
    errorCode
  }
}
