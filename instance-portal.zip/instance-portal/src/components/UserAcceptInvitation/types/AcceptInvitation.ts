export interface UserState {
  state: string
}

export interface ResetPasswordForm {
  password: string
  passwordConfirmation: string
}

export interface ActionToken {
  email: string
  sub: string
  exp: number
  iat: number
  nbf: number
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

export interface InviteUserState {
  allowedRoles: string
  createdBy: string
  createdDate: string
  email: string
  id: number
  lastUpdateDate: string
  lastUpdatedBy: string
  profileId: string
  remark: string
  state: string
  userAcceptDate: string
  userInviteDate: string
}
