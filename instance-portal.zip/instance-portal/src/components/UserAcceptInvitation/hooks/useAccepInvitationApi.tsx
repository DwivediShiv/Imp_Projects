import appConfig from 'app.config'
import axios from 'axios'
import { useCallback } from 'react'
import { ApiResponse, InviteUserState } from '../types/AcceptInvitation'
import { INVITED_USER_STATES } from '@constants/constants'

const useAcceptInvitationApi = () => {
  const getInvitedUserStateUrl = `${appConfig.api}/user-management/api/v1/as/invited/user-state`
  const postAcceptUserInvitationUrl = `${appConfig.api}/user-management/api/v1/as/accept-invitation`
  // Fetch invited user state (invited/active)
  const fetchInvitedUserState = useCallback(
    async (
      actionToken: string,
      errorCallback: any,
      inviteAcceptedCallback: any
    ) => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${actionToken}`
          }
        }
        const { data: response } = await axios.get<InviteUserState>(
          getInvitedUserStateUrl,
          config
        )
        const currentUserState = response?.state
        if (currentUserState === INVITED_USER_STATES.verified) {
          inviteAcceptedCallback()
        }
        return response
      } catch (error) {
        errorCallback()
      }
    },
    []
  )

  const acceptUserInvitation = useCallback(
    async (
      actionToken: string,
      data: { password: string },
      successCallback: any,
      errorCallback: any
    ) => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${actionToken}`
          }
        }
        const { data: response } = await axios.post(
          postAcceptUserInvitationUrl,
          data,
          config
        )
        successCallback()
        return response
      } catch (error) {
        errorCallback()
      }
    },
    []
  )

  return {
    fetchInvitedUserState,
    acceptUserInvitation
  }
}

export default useAcceptInvitationApi
