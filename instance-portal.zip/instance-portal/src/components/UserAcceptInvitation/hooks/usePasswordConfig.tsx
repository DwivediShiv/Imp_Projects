import {
  MESSAGE_PASSWORD_NOT_MEET_REQUIREMENT,
  PASSWORD_POLICY_INDEX
} from '@constants/constants'
import { ResetPasswordForm } from '@type/Form'
import { onPasswordChange } from '@utils/passwordUtils'
import { useMemo, useState } from 'react'
import * as Yup from 'yup'

export const validationSchema: Yup.SchemaOf<ResetPasswordForm> =
  Yup.object().shape({
    password: Yup.string().required('Required Field.'),
    passwordConfirmation: Yup.string()
      .required('Required Field.')
      .oneOf([Yup.ref('password'), null], 'The passwords do not match.')
  })

export const initialValues: Partial<ResetPasswordForm> = {
  password: '',
  passwordConfirmation: ''
}

const usePasswordConfig = () => {
  const [fulfilledPolicies, setFulfilledPolicies] = useState([])
  const passwordConfig = useMemo(() => {
    return {
      title: 'Set Your Password',
      name: 'Confirm & Login',
      fields: [
        {
          name: 'password',
          label: 'New Password',
          placeholder: 'My password',
          help: 'Input your new password',
          type: 'password',
          required: true,
          passwordPolicies: [
            {
              name: 'PasswordLowerCase',
              title: 'One lowercase character'
            },
            {
              name: 'PasswordSpecial',
              title: 'One special character'
            },
            {
              name: 'PasswordUpperCase',
              title: 'One uppercase character'
            },
            {
              name: 'PasswordNumber',
              title: 'One numeric character'
            },
            {
              name: 'PasswordLength',
              title: 'Fifteen characters minimum'
            }
          ]
        },
        {
          name: 'passwordConfirmation',
          label: 'Confirm Password',
          placeholder: 'My password',
          help: 'Input the same new password',
          type: 'password',
          required: true
        }
      ],
      validate: async (value) => {
        let errorMessage
        const fullFilledPolicy = await onPasswordChange(
          value,
          setFulfilledPolicies
        )
        if (value && fullFilledPolicy?.length < PASSWORD_POLICY_INDEX) {
          errorMessage = MESSAGE_PASSWORD_NOT_MEET_REQUIREMENT
        }
        return errorMessage
      }
    }
  }, [])
  return { passwordConfig, fulfilledPolicies }
}

export default usePasswordConfig
