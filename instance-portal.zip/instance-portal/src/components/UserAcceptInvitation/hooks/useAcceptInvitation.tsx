import { useState } from 'react'
import jwt from 'jwt-decode'
import { ActionToken } from '../types/AcceptInvitation'
import useAcceptInvitationApi from './useAccepInvitationApi'
import { ResetPasswordForm } from '@type/Form'
import { useRouter } from 'next/router'
import { TOKEN_SUBJECT_STRING } from '@constants/constants'

const useAcceptInvitation = (actionToken) => {
  const { fetchInvitedUserState, acceptUserInvitation } =
    useAcceptInvitationApi()
  const [openStatusModal, setOpenStatusModal] = useState(false)
  const [modalTemplate, setModalTemplate] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const [userEmail, setUserEmail] = useState<string | undefined>()

  const actionTokenErrorCallback = () => {
    setModalTemplate('tokenInvalidFailure')
    setLoading(false)
    setOpenStatusModal(true)
  }

  const inviteAcceptedCallback = () => {
    setModalTemplate('invitationAccepted')
    setOpenStatusModal(true)
  }

  const acceptInvitationSuccessCallback = () => {
    setLoading(false)
    router.push('/login?state=success&msg=Password updated successfully.')
  }

  const loadAcceptInvitationFunc = async () => {
    try {
      if (actionToken) {
        const jwtActionToken: ActionToken = jwt(actionToken) // Decode action token
        setUserEmail(jwtActionToken.email)

        if (jwtActionToken.sub === TOKEN_SUBJECT_STRING.invite) {
          // If action token contains invite parameter then call fetch invited state function
          await fetchInvitedUserState(
            actionToken,
            actionTokenErrorCallback,
            inviteAcceptedCallback
          )
        } else {
          throw new Error('Action token is not valid')
        }
      } else {
        throw new Error('Action token is required')
      }
    } catch (error) {
      setModalTemplate('tokenInvalidFailure')
      setOpenStatusModal(true)
    }
  }

  const handleSubmit = async (
    values: Partial<ResetPasswordForm>,
    setFieldError: (field: string, errorMsg: string) => void,
    resetForm: () => void
  ): Promise<void> => {
    setLoading(true)
    const data = {
      password: values.password
    }
    // API call to accept invitation
    await acceptUserInvitation(
      actionToken,
      data,
      acceptInvitationSuccessCallback,
      actionTokenErrorCallback
    )
    resetForm()
  }

  const onModalClose = () => {
    setOpenStatusModal(false)
    router.push('/login')
  }

  return {
    handleSubmit,
    loadAcceptInvitationFunc,
    onModalClose,
    userEmail,
    openStatusModal,
    modalTemplate,
    loading
  }
}

export default useAcceptInvitation
