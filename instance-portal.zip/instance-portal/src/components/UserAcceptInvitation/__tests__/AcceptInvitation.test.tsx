import React from 'react'
import { fireEvent, render, screen } from '@testing-library/react'
import user from '@testing-library/user-event'
import AcceptInvitationPage from '..'
import { validationSchema } from '../hooks/usePasswordConfig'

const mockRouterPush = jest.fn()

jest.mock('@utils/passwordUtils', () => {
  const actualTracker = jest.requireActual('@utils/passwordUtils')
  return {
    ...actualTracker,
    onPasswordChange: jest.fn()
  }
})

jest.mock('next/router', () => ({
  useRouter: () => ({
    push: mockRouterPush
  })
}))

const mockValidToken = '1234'
const mockInvalidToken = '5678'
const testEmail = 'test.user@email.com'

jest.mock('jwt-decode', () => (token: string) => {
  if (token.localeCompare(mockValidToken) === 0) {
    return {
      email: testEmail,
      sub: 'InviteInstanceUser',
      exp: Date.now() + 3600 * 1000,
      iat: Date.now(),
      nbf: Date.now()
    }
  }
  return {}
})

describe('Should not render Set Password Form', () => {
  it('Not render with invalid token', async () => {
    render(<AcceptInvitationPage actionToken={mockInvalidToken} />)
    expect(
      await screen.findByText(/invalid invitation link/i)
    ).toBeInTheDocument()
    expect(
      await screen.findByText(
        /invitation link is invalid\/expired\. please contact administrator\./i
      )
    ).toBeInTheDocument()
    const returnToLoginBtn = await screen.findByRole('button', {
      name: /return to login/i
    })
    expect(returnToLoginBtn).toBeInTheDocument()
  })
})

describe('Render Set Password Form', () => {
  it('Form rendering', async () => {
    render(<AcceptInvitationPage actionToken={mockValidToken} />)
    expect(
      await screen.findByRole('heading', {
        name: /set your password/i
      })
    ).toHaveTextContent('Set Your Password')
    expect(
      await screen.findByRole('heading', {
        name: /test\.user@email\.com/i
      })
    ).toHaveTextContent(testEmail)

    expect(await screen.findByText(/new password/i)).toBeInTheDocument()
    expect(await screen.findByText(/confirm password/i)).toBeInTheDocument()
    const confirmLoginBtn = await screen.findByRole('button', {
      name: /confirm & login/i
    })
    expect(confirmLoginBtn).toBeInTheDocument()
    expect(confirmLoginBtn).toBeDisabled()
  })

  it('Confirm button rendering and should be enabled', async () => {
    render(<AcceptInvitationPage actionToken={mockValidToken} />)
    const newPasswordEl = await screen.findByLabelText(/new password/i)
    fireEvent.change(newPasswordEl, { target: { value: 'AdminUserTest@123' } })

    const confirmPasswordEl = await screen.findByLabelText(/confirm password/i)
    fireEvent.change(confirmPasswordEl, {
      target: { value: 'AdminUserTest@123' }
    })
    const confirmLoginBtn = await screen.findByRole('button', {
      name: /confirm & login/i
    })
    expect(confirmLoginBtn).toBeInTheDocument()
    expect(confirmLoginBtn).toBeEnabled()
  })
})

describe('Yup Form Validation', () => {
  it('check yup validations on the form , incorrect values will give error', async () => {
    const values = {
      password: 'AdminUserTest@123',
      passwordConfirmation: 'AdminUserTest'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toBe(false)
  })

  it('check yup validations on the form correct values no error', async () => {
    const values = {
      password: 'AdminUserTest@123',
      passwordConfirmation: 'AdminUserTest@123'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toEqual(true)
  })

  it('error messages on form when incorrect value is provided', async () => {
    const values = {
      password: 'AdminUserTest@123',
      passwordConfirmation: 'AdminUserTest'
    }
    try {
      await validationSchema.validate(values, { abortEarly: false })
    } catch (error) {
      // If an error is thrown, the test is successful
      expect(error).toBeDefined()
      expect(error.errors).toEqual(['The passwords do not match.'])
      expect(error.errors).toHaveLength(1)
      return
    }
    // If no error is thrown, the test fails
    throw new Error('Validation did not fail as expected')
  })
})
