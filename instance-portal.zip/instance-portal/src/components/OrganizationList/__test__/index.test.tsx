import React from 'react'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import user from '@testing-library/user-event'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'
import { setupGetOrgDataHandler } from '../msw/orgListHandler'
import OrganizationList from '..'
import { RenderOptions } from '../types/OrgList'
import { STATUS_CONSTANTS } from '@constants/constants'
import { instanceOrgDetails } from '../msw/orgListData'

const mockRouterBack = jest.fn()
const mockRouterPush = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack,
    push: mockRouterPush
  })
}))

jest.mock('../../OrganizationAdd/hooks/useCreateOrgApi', () => {
  return () => {
    return {
      fetchInstanceOrgDetails: jest.fn(),
      instanceOrgDetails
    }
  }
})

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // Deprecated
    removeListener: jest.fn(), // Deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn()
  }))
})

jest.mock('@core/context/Authorize')

function renderComponent(options: RenderOptions) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isAdmin, isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isAdmin,
    isLogin
  })

  return render(<OrganizationList />)
}

describe('Org Admin list ', () => {
  it('components rendered and button is enabled ', async () => {
    setupGetOrgDataHandler()
    window.URL.createObjectURL = jest.fn()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })

    await waitFor(async () => {
      expect(screen.getByRole('tab', { name: 'All' })).toBeInTheDocument()
    })

    expect(screen.getByRole('tab', { name: /\bactive\b/i })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: /inactive/i })).toBeInTheDocument()

    expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    const exportBtn = await screen.findByText('Export')
    expect(exportBtn).toBeInTheDocument()
    fireEvent.click(exportBtn)

    expect(screen.getByText('Name')).toBeInTheDocument()

    expect(screen.getByText('Nagarro ZXR')).toBeInTheDocument()

    expect(
      await screen.findByRole('button', {
        name: /create new group/i
      })
    )
  })
  it('should count the correct number of user rows', async () => {
    setupGetOrgDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(
        screen.getByText(/displaying 4 out of 4 result\(s\)/i)
      ).toBeInTheDocument()
    })
  })

  it('api errors should be handled', async () => {
    setupGetOrgDataHandler({
      response: {
        code: 'Error_UnAuthorizedUserAction',
        error: 'User Unauthorized'
      },
      status: 400
    })
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(await screen.findByText(/Restricted Access/i)).toBeInTheDocument()
  })

  it('Should not display a table when no data is available', async () => {
    setupGetOrgDataHandler({ typeOfData: 'No Record' })
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    const table = screen.queryByRole('table')

    await waitFor(async () => {
      expect(table).not.toBeInTheDocument()
    })

    // expect(
    //   await screen.findByRole('heading', { name: /no records found\./i })
    // ).toBeInTheDocument()
  })
})

describe('Click of tabs', () => {
  it('Active tab click', async () => {
    setupGetOrgDataHandler({ typeOfData: STATUS_CONSTANTS.Active.title })
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })

    await waitFor(async () => {
      expect(screen.getByRole('tab', { name: 'All' })).toBeInTheDocument()
    })

    const invitedTabEl = screen.getByRole('tab', { name: /\bactive\b/i })
    user.click(invitedTabEl)

    await waitFor(async () => {
      expect(screen.getByText('Nagarro')).toBeInTheDocument()
    })
    await waitFor(async () => {
      expect(screen.getByText('Active')).toBeInTheDocument()
    })
  })

  it('Inactive tab click', async () => {
    setupGetOrgDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })

    await waitFor(async () => {
      expect(screen.getByRole('tab', { name: 'All' })).toBeInTheDocument()
    })

    const invitedTabEl = screen.getByRole('tab', { name: /\binactive\b/i })
    user.click(invitedTabEl)

    setupGetOrgDataHandler({ typeOfData: STATUS_CONSTANTS.Inactive.title })
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })

    await waitFor(async () => {
      expect(screen.getByText('Nagarro Abstract')).toBeInTheDocument()
    })
    await waitFor(async () => {
      expect(screen.getByText('Inactive')).toBeInTheDocument()
    })
  })
})

describe('search state', () => {
  it('updates org name state on search input change', async () => {
    setupGetOrgDataHandler({ typeOfData: 'Nagarro' })
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    })

    const searchInput = screen.getByPlaceholderText('Search')
    await user.type(searchInput, 'Nagarro')

    await waitFor(async () => {
      expect(searchInput).toHaveValue('Nagarro')
    })
  })
})

describe('filter states', () => {
  it('handles country filter', async () => {
    setupGetOrgDataHandler({ typeOfData: 'Austria, Belgium' })
    const { container } = renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    })

    const searchInput1 = screen.getByPlaceholderText('Search')
    await user.type(searchInput1, 'Nagarro')

    await waitFor(async () => {
      expect(searchInput1).toHaveValue('Nagarro')
    })

    // const searchInput2 = screen.getByTestId('Country')
    // searchInput2.textContent = 'Austria, Belgium'

    // await waitFor(async () => {
    //   expect(searchInput2).toHaveTextContent('Austria, Belgium')
    // })

    await waitFor(async () => {
      expect(screen.getByText('Nagarro ZXR')).toBeInTheDocument()
    })
    await waitFor(async () => {
      expect(screen.queryByText('Nagarro')).not.toBeInTheDocument()
    })
  })

  it('handles industry filter', async () => {
    setupGetOrgDataHandler({ typeOfData: 'Aerospace' })
    const { container } = renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    })

    const searchInput1 = screen.getByPlaceholderText('Search')
    await user.type(searchInput1, 'Nagarro')

    await waitFor(async () => {
      expect(searchInput1).toHaveValue('Nagarro')
    })

    // const searchInput2 = screen.getByTestId('Industry')
    // searchInput2.textContent = 'Aerospace'

    // await waitFor(async () => {
    //   expect(searchInput2).toHaveTextContent('Aerospace')
    // })

    await waitFor(async () => {
      expect(screen.getByText('Nagarro ZXR')).toBeInTheDocument()
    })
    await waitFor(async () => {
      expect(screen.queryByText('Nagarro Abstract')).not.toBeInTheDocument()
    })
  })
})

describe('reset filters', () => {
  it('handles country filter', async () => {
    setupGetOrgDataHandler()
    const { container } = renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    })

    const searchInput1 = screen.getByPlaceholderText('Search')
    await user.type(searchInput1, 'Nagarro')

    await waitFor(async () => {
      expect(searchInput1).toHaveValue('Nagarro')
    })

    // const searchInput2 = screen.getByTestId('Country')
    // searchInput2.textContent = 'Austria, Belgium'

    // await waitFor(async () => {
    //   expect(searchInput2).toHaveTextContent('Austria, Belgium')
    // })

    // const searchInput3 = screen.getByTestId('Industry')
    // searchInput3.textContent = 'Aerospace'

    // await waitFor(async () => {
    //   expect(searchInput3).toHaveTextContent('Aerospace')
    // })

    const resetButton = screen.getByText('Reset') as HTMLInputElement
    user.click(resetButton)

    await waitFor(async () => {
      expect(searchInput1).toHaveValue('')
    })
    await waitFor(async () => {
      expect(searchInput1).toHaveValue('')
    })
    await waitFor(async () => {
      expect(searchInput1).toHaveValue('')
    })
  })
})
