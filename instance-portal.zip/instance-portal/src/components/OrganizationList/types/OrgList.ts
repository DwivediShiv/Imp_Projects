import {
  Column,
  ExportConfig,
  FilterConfig,
  SearchConfig,
  TabConfig
} from '@sharedComponents/CustomTableList/types/CustomTableListTypes'
import { AuthorizeProviderValue } from '@core/context/Authorize'

export interface OrgDetail {
  id: number
  orgId: string
  name: string
  accountType?: string
  accountAddress?: string
  brNumber: string
  address: string
  website: string
  email: string
  domain?: string
  industry: string
  revenueWallet?: string
  orgGroup?: string
  state?: string
  instanceRepresentativeId?: string
  registrationDocument?: string
  country: string
  createdDate: string
  createdBy: string
  lastUpdatedDate?: string
  lastUpdatedBy?: string
  activatedOn: string
  remark: string
  logo: OrgProfileLogo
}

export interface OrgList {
  data: OrgDetail[]
  totalRecord: number
}

export interface OrgProfileLogo {
  path: string
  preview: string
  contentType: string
}

// TODO: Move to `common-js`
export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
  totalRecord?: number
  filterCriterias?: Record<string, string[]>
  code?: string
}

// TODO: Move to `common-js`
export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
  typeOfData?: string
}

export interface Configuration {
  title: string
  columns: Column[]
  tabConfig: TabConfig
  exportConfig: ExportConfig
  searchConfig: SearchConfig
  filterConfig: FilterConfig
}

export interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}
