import React, { useCallback, useState } from 'react'
import axios, { AxiosResponse } from 'axios'
import { ApiResponse, OrgDetail, OrgList } from '../types/OrgList'
import appConfig from 'app.config'
import { buildUrlWithQueryParams } from '@utils/url'
import {
  SELECTION_CONSTANTS,
  DEFAULT_ORG_FIELD_VALUES
} from '@constants/constants'
import { USER_MESSAGES } from '@constants/modalConstant'
import { printErrorStack } from '@utils/index'
import Toast from '@sharedComponents/Toast'
import { ERROR_UNAUTH } from '@constants/permissionConstants'
function getResendInviteURL(orgId: string): string {
  return `${appConfig.api}/user-management/api/v1/org/resend-invite/${orgId}`
}
function getDeleteOrgURL(orgId: string): string {
  return `${appConfig.api}/user-management/api/v1/org/${orgId}`
}
export interface OrgListResponse {
  data: OrgList
}

export let orgListApiUrl = `${appConfig.api}/user-management/api/v1/org/details-list`

export default function useOrgListApi() {
  const [orgListData, setOrgListData] = useState<OrgDetail[] | null>(null)
  const [orgListError, setOrgListError] = useState<string | null>('')
  const [orgListErrorCode, setOrgListErrorCode] = useState<string | null>('')
  const [orgListTotal, setOrgTotal] = useState<number>(0)

  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>()

  const fetchOrgList = useCallback(
    async ({
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterCountry,
      filterIndustry,
      setIsInitialLoader
    }) => {
      try {
        const urlParams: Record<string, string | string[]> = {}
        setOrgListError('')
        setOrgTotal(0)
        setIsLoading(true)

        orgListApiUrl = `${appConfig.api}/user-management/api/v1/org/details-list`

        if (page) {
          urlParams.page = page
        }

        if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
          urlParams.state = status
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.name = searchValue
        }

        const filterCountryParam = Object.keys(filterCountry).filter(
          (key) => filterCountry[key]
        )

        if (filterCountryParam?.length) {
          urlParams.countries = filterCountryParam
        }

        const filterIndustryParam = Object.keys(filterIndustry).filter(
          (key) => filterIndustry[key]
        )

        if (filterIndustryParam?.length) {
          urlParams.industries = filterIndustryParam
        }

        // orgListApiUrl = buildUrlWithQueryParams(orgListApiUrl, urlParams)
        const { data: response } = await axios.post<ApiResponse<OrgDetail[]>>(
          orgListApiUrl,
          urlParams
        )

        if (response?.filterCriterias) {
          setFilterCriterias(response.filterCriterias)
        }

        const transformedResp = response?.data?.map((org) => ({
          ...org,
          address:
            org.address === DEFAULT_ORG_FIELD_VALUES.ADDRESS
              ? DEFAULT_ORG_FIELD_VALUES.BLANK
              : org.address,
          industry:
            org.industry === DEFAULT_ORG_FIELD_VALUES.INDUSTRY
              ? DEFAULT_ORG_FIELD_VALUES.BLANK
              : org.industry
        }))
        setOrgListData(transformedResp)
        setOrgTotal(response?.totalRecord)
        setIsInitialLoader(false)
      } catch (error) {
        setOrgListErrorCode(error?.response?.data?.code || 'General')
        if (axios.isAxiosError(error)) {
          setOrgListError(error?.response?.data?.error)
        } else {
          setOrgListError('unexpected error')
        }
      } finally {
        setIsLoading(false)
        setIsInitialLoader(false)
      }
    },
    []
  )

  function getExportOrgUrlParams(
    name?: string,
    filterCountry?: string,
    filterIndustry?: string,
    status?: string,
    sortBy?: string,
    sortOrder?: string
  ): any {
    const urlParams: Record<string, string | string[]> = {}
    urlParams.get = 'All'
    if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
      urlParams.state = status
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    if (name !== '') {
      urlParams.name = name
    }

    const filterCountryParam = Object.keys(filterCountry).filter(
      (key) => filterCountry[key]
    )

    if (filterCountryParam?.length) {
      urlParams.countries = filterCountryParam
    }

    const filterIndustryParam = Object.keys(filterIndustry).filter(
      (key) => filterIndustry[key]
    )

    if (filterIndustryParam?.length) {
      urlParams.industries = filterIndustryParam
    }

    return urlParams
  }

  async function exportOrgList(
    searchValue,
    country,
    industry,
    status,
    sortBy,
    sortOrder
  ): Promise<string> {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: `${appConfig.api}/user-management/api/v1/org/details-list/export`,
        data: getExportOrgUrlParams(
          searchValue,
          country,
          industry,
          status,
          sortBy,
          sortOrder
        )
      })
      return response.data
    } catch (error) {
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH)
        return
      }
      console.log(error)
    }
  }
  async function resendOrgInvite(orgId: string): Promise<any> {
    try {
      const resp = await axios.post(getResendInviteURL(orgId))
      Toast('success', USER_MESSAGES.USER_INVITED)
    } catch (error) {
      let message = USER_MESSAGES.ERROR_COMMON
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH_USER_INVITE)
        return
      } else if (error.response?.data?.error?.additionalData) {
        message = error.response?.data?.error?.additionalData
      } else if (axios.isAxiosError(error)) {
        const { additionalData = {} } = error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        message = additionalErrors?.length
          ? (additionalErrors[0] as string)
          : message
      } else {
        printErrorStack(error)
      }
      Toast('error', message)
    }
  }

  async function deleteOrg(orgId: string, orgName: string): Promise<any> {
    try {
      const resp = await axios.delete(getDeleteOrgURL(orgId))
      Toast(
        'success',
        (
          <>
            The group <b>{orgName}</b> has been removed successfully.
          </>
        ) as unknown as string
      )
    } catch (error) {
      setOrgListErrorCode(error?.response?.data?.code || 'General')
      let message = USER_MESSAGES.ORG_DELETED_FAIL
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH_DELETE_ORG)
        return
      } else if (error.response?.data?.error?.additionalData) {
        message = error.response?.data?.error?.additionalData
      } else if (axios.isAxiosError(error)) {
        const { additionalData = {} } = error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        message = additionalErrors?.length
          ? (additionalErrors[0] as string)
          : message
      } else {
        printErrorStack(error)
      }
      Toast('error', message)
    }
  }

  return {
    orgListData,
    setOrgListData,
    orgListError,
    orgListErrorCode,
    fetchOrgList,
    orgListTotal,
    filterCriterias,
    exportOrgList,
    resendOrgInvite,
    deleteOrg
  }
}
