import React, { useMemo, useState } from 'react'
import useOrgListApi from './useOrgListApi'
import appConfig from 'app.config'
import { Configuration, OrgDetail } from '../types/OrgList'
import { SELECTION_CONSTANTS, STATE_CONSTANTS } from '@constants/constants'
import Mail from '@images/mailreset.svg'
import Delete from '@images/deleteicon.svg'
import { ModalFieldValue } from '@type/Modal'
import { hasSelection } from '@sharedComponents/CustomTableList/hook/useCustomTableList'
export const useOrgListing = () => {
  const [page, setPage] = useState(1)
  const [sortValue, setsortValue] = useState<string>('')
  const [sortBy, setSortBy] = useState<string>('')
  const [sortOrder, setSortOrder] = useState<string>('')
  const [status, setStatus] = useState<string>('')
  const [searchValue, setSearchValue] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>()
  const [isInitialLoader, setIsInitialLoader] = useState<boolean>(true)
  const [tabIndex, setTabIndex] = useState<number>(0)
  const [filterCountry, setFilterCountry] = useState<Record<string, boolean>>(
    {}
  )
  const [filterIndustry, setFilterIndustry] = useState<Record<string, boolean>>(
    {}
  )
  const [init, setInit] = useState<number>()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [refreshList, setRefreshList] = useState<number>(0)
  const [modalFieldValue, setModalFieldValue] = useState<ModalFieldValue>({
    heading: '',
    subheading: null
  })
  const { exportOrgList, resendOrgInvite, deleteOrg } = useOrgListApi()

  const handleFilterSelect = (
    items: Record<string, boolean>,
    type: 'Country' | 'Industry'
  ) => {
    setPage(1)
    switch (type) {
      case 'Country':
        setFilterCountry(items)
        break
      case 'Industry':
        setFilterIndustry(items)
        break
    }
  }

  const handleClearFilter = () => {
    setPage(1)
    setSearchValue('')
    setFilterCountry({})
    setFilterIndustry({})
    // setSortBy('')
    // setSortOrder('')
    // setStatus('')
    // setTabIndex(0)
  }

  async function onAction(row, type) {
    switch (type) {
      case 'delete':
        setModalFieldValue({
          heading: 'Remove group',
          subheading: (
            <>
              Are you sure you want to remove the group with the name{' '}
              <b>{row.name}</b>?
            </>
          ) as unknown as string,
          value: row,
          handleSubmit: async () => {
            await deleteOrg(row.orgId, row.name)
            setIsModalOpen(false)
            setInit(Math.random())
          }
        })
        break
      default:
        setModalFieldValue({
          heading: '',
          subheading: '',
          value: '',
          handleSubmit: ''
        })
        break
    }

    setIsModalOpen(true)
  }

  function hasFilterApplied() {
    return (
      searchValue !== '' ||
      hasSelection(filterCountry) ||
      hasSelection(filterIndustry)
    )
  }

  const OrgListConfig: Configuration = useMemo(() => {
    return {
      title: '',
      sortConfig: {
        type: 'fancySort',
        sortOptions: [
          {
            name: 'Company Name: A-Z',
            value: 'name-asc'
          },
          {
            name: 'Company Name: Z-A',
            value: 'name-desc'
          },
          {
            name: 'Business Number: A-Z',
            value: 'br_number-asc'
          },
          {
            name: 'Business Number: Z-A',
            value: 'br_number-desc'
          },
          {
            name: 'Industry: A-Z',
            value: 'industry-asc'
          },
          {
            name: 'Industry: Z-A',
            value: 'industry-desc'
          },
          {
            name: 'Country: A-Z',
            value: 'country-asc'
          },
          {
            name: 'Country: Z-A',
            value: 'country-desc'
          },
          {
            name: 'Registered On: Newest first',
            value: 'created_date-desc'
          },
          {
            name: 'Registered On: Oldest first',
            value: 'created_date-asc'
          },
          {
            name: 'Registered By: A-Z',
            value: 'created_by-asc'
          },
          {
            name: 'Registered By: Z-A',
            value: 'created_by-desc'
          },
          {
            name: 'Status: A-Z',
            value: 'state-asc'
          },
          {
            name: 'Status: Z-A',
            value: 'state-desc'
          }
        ]
      },
      searchConfig: {
        type: 'search',
        name: 'search',
        placeholder: 'Search',
        searchValue
      },
      refreshConfig: {
        name: 'Refresh list',
        handleRefreshList: () => setRefreshList(Math.random())
      },
      exportConfig: {
        exportFn: () =>
          exportOrgList(
            searchValue,
            filterCountry,
            filterIndustry,
            status,
            sortBy,
            sortOrder
          ),
        fileName: 'orgList.csv'
      },
      columns: [
        {
          id: 'name',
          title: 'Name',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'name',
          class: 'name',
          rowConfig: {
            cellType: 'nameField',
            clickable: 'true',
            value: 'name',
            class: 'nameColumn',
            href: '/org-profile/',
            conditionalHref: {
              href: '/create-org/',
              param: 'state',
              value: STATE_CONSTANTS.PENDING
            },
            param: 'orgId'
          },
          width: '278px',
          sortField: 'name'
        },
        {
          id: 'brNumber',
          title: 'Reference number',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'brNumber',
          class: 'brNumber',
          rowConfig: {
            cellType: 'default',
            clickable: 'false',
            value: 'brNumber',
            class: 'brNumberColumn'
          },
          width: '124px',
          sortField: 'br_number'
        },
        {
          id: 'industry',
          title: 'Industry',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'industry',
          class: 'industry',
          rowConfig: {
            cellType: 'default',
            clickable: 'false',
            value: 'industry',
            class: 'industryColumn'
          },
          width: '132px',
          sortField: 'industry'
        },
        {
          id: 'country',
          title: 'Country',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'country',
          class: 'country',
          rowConfig: {
            cellType: 'default',
            clickable: 'false',
            value: 'country',
            class: 'countryColumn'
          },
          width: '124px',
          sortField: 'country'
        },
        {
          id: 'createdOn',
          title: 'Registration date',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'createdOn',
          class: 'createdOn',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'createdDate'
          },
          width: '130px',
          sortField: 'created_date',
          allowOverflow: false
        },
        {
          id: 'createdBy',
          title: 'Registered by',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'createdBy',
          class: 'createdBy',
          rowConfig: {
            cellType: 'default',
            value: 'createdBy'
          },
          width: '200px',
          sortField: 'created_by',
          allowOverflow: false
        },
        {
          id: 'state',
          title: 'Status',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'state',
          class: 'state',
          rowConfig: {
            cellType: 'fancyStatusField',
            value: 'state',
            class: 'statusColumn'
          },
          width: '100px',
          sortField: 'state',
          allowOverflow: false
        },
        {
          id: 'actions',
          title: 'Actions',
          type: 'tableHeader',
          sortable: false,
          rowConfig: {
            cellType: 'actions',
            actions: [
              {
                type: 'icon',
                image: Mail,
                clickable: (row: OrgDetail) => {
                  return row.state === STATE_CONSTANTS.INVITED
                },
                onClick: (row: OrgDetail) => {
                  resendOrgInvite(row.orgId)
                }
              },
              {
                type: 'icon',
                image: Delete,
                clickable: (row: OrgDetail) => {
                  return (
                    row.state === STATE_CONSTANTS.INVITED ||
                    row.state === STATE_CONSTANTS.INACTIVE ||
                    row.state === STATE_CONSTANTS.REJECTED
                  )
                },
                onClick: (row: OrgDetail) => {
                  onAction(row, 'delete')
                }
              }
            ]
          },

          allowOverflow: false
        }
      ],
      tabConfig: {
        defaultTab: 0,
        tabList: [
          {
            title: 'All',
            key: 'all',
            value: '',
            index: 0
          },
          {
            title: 'Active',
            key: 'active',
            value: 'active',
            index: 1,
            icon: 'success'
          },
          {
            title: 'Invited',
            key: 'invited',
            value: 'invited',
            index: 2,
            icon: 'warning'
          },
          {
            title: 'Inactive',
            key: 'inactive',
            value: 'inactive',
            index: 3,
            icon: 'disabled'
          },
          {
            title: 'Pending',
            key: 'pending',
            value: 'pending',
            index: 4,
            icon: 'warning'
          },
          {
            title: 'Rejected',
            key: 'rejected',
            value: 'rejected',
            index: 5,
            icon: 'danger'
          }
        ]
      },
      filterConfig: {
        clearFilters: handleClearFilter,
        filters: [
          {
            id: 'Country',
            inputName: 'Country',
            label: 'Country',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterCountry,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterCountry,
            onChange: (items) => handleFilterSelect(items, 'Country')
          },
          {
            id: 'Industry',
            inputName: 'Industry',
            label: 'Industry',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterIndustry,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterIndustry,
            onChange: (items) => handleFilterSelect(items, 'Industry')
          }
        ]
      }
    }
  }, [searchValue, filterCountry, filterIndustry, status, sortBy, sortOrder])

  const {
    tabConfig: { tabList = [] }
  } = OrgListConfig

  const handleTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setPage(1)
    setStatus(tabList[newValue].value)
    setTabIndex(newValue)
  }

  const handlePageChange = (page) => {
    setPage(page)
  }

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    setSortBy(column.sortField)
    setSortOrder(sortDirection)
  }

  const handleSortOption = async (sortOption: string) => {
    setsortValue(sortOption)
    const sortSelection = sortOption.split('-')
    setSortBy(sortSelection[0])
    setSortOrder(sortSelection[1])
  }

  function handleOnSearch(e) {
    setPage(1)
    setSearchValue(e.target.value)
  }

  return {
    handleTabChange,
    handlePageChange,
    handleSortChange,
    handleSortOption,
    handleOnSearch,
    page,
    sortValue,
    sortBy,
    sortOrder,
    status,
    tabIndex,
    searchValue,
    OrgListConfig,
    setIsLoading,
    isLoading,
    filterCountry,
    filterIndustry,
    hasFilterApplied,
    isInitialLoader,
    setIsInitialLoader,
    isModalOpen,
    setIsModalOpen,
    modalFieldValue,
    init,
    refreshList
  }
}
