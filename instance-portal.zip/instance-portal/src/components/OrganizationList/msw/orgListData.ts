import { OrgDetail, OrgList } from '../types/OrgList'

export const orgList: OrgDetail[] = [
  {
    id: 217,
    logo: {
      path: 'https://acentrik-organization-img-nagarro-dev.s3.amazonaws.com/1/chinar.png',
      preview: '',
      contentType: ''
    },
    orgId: 'd7091bbd-4161-4d99-babb-2c6fdef5eea9',
    name: 'Test 28',
    accountType: 'EOA',
    accountAddress: '',
    brNumber: '424',
    country: 'Afghanistan',
    address:
      'Laborum voluptates esse veniam obcaecati aliquip tenetur in eaque quod quas dolor excepturi officia porro nisi et',
    industry: 'Aerospace',
    website: 'https://www.faju.org',
    email: 'soqifi@mailinator.com',
    domain: 'mailinator.com',
    revenueWallet: '',
    orgGroup: 'ORG--Test28d7091bbd-4161-4d99-babb-2c6fdef5eea9',
    remark:
      'Et autem sed sit adipisicing veniam aut deleniti illo nihil enim deleniti cupidatat aperiam architecto quae',
    state: 'Invited',
    activatedOn: '2023-12-28T08:18:35.852455Z',
    instanceRepresentativeId: 'mugytim@mailinator.com',
    createdDate: '2023-12-28T08:18:35.852455Z',
    createdBy: 'madhav.kalra@nagarro.com',
    lastUpdatedDate: '2023-12-28T08:18:35.852455Z',
    lastUpdatedBy: 'madhav.kalra@nagarro.com'
  },
  {
    id: 1,
    orgId: '123',
    name: 'Nagarro',
    accountType: 'EOA',
    accountAddress: '',
    brNumber: 'SIN6345693645',
    country: 'Bulgaria',
    address: 'SIN6345693645',
    industry: 'Automotive',
    website: 'www.nagarro.com',
    email: 'marketing@nagarro.com',
    domain: 'nagarro.com',
    logo: {
      path: 'https://acentrik-organization-img-nagarro-dev.s3.amazonaws.com/1/chinar.png',
      preview: '',
      contentType: ''
    },
    revenueWallet: '',
    orgGroup: 'marketplace',
    remark:
      'Mercedes-Benz Group AG, one of the biggest producers of premium cars',
    state: 'Active',
    activatedOn: '2023-08-22T06:02:58.036Z',
    instanceRepresentativeId: '',
    registrationDocument: '',
    createdDate: '2023-08-03T11:46:50.393666Z',
    createdBy: 'NAGARRO_TEST_SYSTEM',
    lastUpdatedDate: '2023-09-15T16:18:38.11388Z',
    lastUpdatedBy: 'ishmeet.kalsi@nagarro.com'
  },
  {
    id: 34,
    orgId: '123',
    name: 'Nagarro Abstract',
    accountType: 'AA',
    accountAddress: '',
    brNumber: '',
    country: 'Austria',
    address: 'Gurugram',
    industry: 'Agriculture',
    website: 'www.nagarro.com',
    email: 'marketing@nagarro.com',
    domain: 'nagarro.com',
    logo: {
      path: 'https://acentrik-organization-img-nagarro-dev.s3.amazonaws.com/1/chinar.png',
      preview: '',
      contentType: ''
    },
    revenueWallet: '',
    orgGroup: 'Devtest',
    remark: '',
    state: 'Active',
    activatedOn: '',
    instanceRepresentativeId: '',
    registrationDocument: '',
    createdDate: '2023-08-16T11:37:25.573833Z',
    createdBy: 'NAGARRO_TEST_SYSTEM',
    lastUpdatedDate: '0001-01-01T00:00:00Z',
    lastUpdatedBy: ''
  },
  {
    id: 2,
    orgId: '123',
    name: 'Nagarro ZXR',
    accountType: 'AA',
    accountAddress: '',
    brNumber: '',
    country: 'Belgium',
    address: 'Gurugram',
    industry: 'Aerospace',
    website: 'www.nagarro.com',
    email: 'marketing@nagarro.com',
    domain: 'nagarro.com',
    logo: {
      path: 'https://acentrik-organization-img-nagarro-dev.s3.amazonaws.com/1/chinar.png',
      preview: '',
      contentType: ''
    },
    revenueWallet: '',
    orgGroup: 'marketplace',
    remark: '',
    state: 'Inactive',
    activatedOn: '',
    instanceRepresentativeId: '',
    registrationDocument: '',
    createdDate: '2023-08-03T11:46:50.393Z',
    createdBy: 'NAGARRO_TEST_SYSTEM',
    lastUpdatedDate: '0001-01-01T00:00:00Z',
    lastUpdatedBy: ''
  }
]

export const emptyOrgList = {
  emptyData: [],
  zeroTotalRecord: 0
}

export const activeOrgList: OrgDetail[] = [
  {
    id: 1,
    orgId: '123',
    name: 'Nagarro',
    accountType: 'EOA',
    accountAddress: '',
    brNumber: 'SIN6345693645',
    country: 'Belgium',
    address: 'SIN6345693645',
    industry: 'Automotive',
    website: 'www.nagarro.com',
    email: 'marketing@nagarro.com',
    domain: 'nagarro.com',
    logo: {
      path: 'https://acentrik-organization-img-nagarro-dev.s3.amazonaws.com/1/chinar.png',
      preview: '',
      contentType: ''
    },
    revenueWallet: '',
    orgGroup: 'marketplace',
    remark:
      'Mercedes-Benz Group AG, one of the biggest producers of premium cars',
    state: 'Active',
    activatedOn: '2023-08-22T06:02:58.036Z',
    instanceRepresentativeId: '',
    registrationDocument: '',
    createdDate: '2023-08-03T11:46:50.393666Z',
    createdBy: 'NAGARRO_TEST_SYSTEM',
    lastUpdatedDate: '2023-09-15T16:18:38.11388Z',
    lastUpdatedBy: 'ishmeet.kalsi@nagarro.com'
  },
  {
    id: 34,
    orgId: '123',
    name: 'Nagarro Abstract',
    accountType: 'AA',
    accountAddress: '',
    brNumber: '',
    country: 'IND',
    address: 'Gurugram',
    industry: '',
    website: 'www.nagarro.com',
    email: 'marketing@nagarro.com',
    domain: 'nagarro.com',
    logo: {
      path: 'https://acentrik-organization-img-nagarro-dev.s3.amazonaws.com/1/chinar.png',
      preview: '',
      contentType: ''
    },
    revenueWallet: '',
    orgGroup: 'Devtest',
    remark: '',
    state: 'Active',
    activatedOn: '',
    instanceRepresentativeId: '',
    registrationDocument: '',
    createdDate: '2023-08-16T11:37:25.573833Z',
    createdBy: 'NAGARRO_TEST_SYSTEM',
    lastUpdatedDate: '0001-01-01T00:00:00Z',
    lastUpdatedBy: ''
  }
]

export const inactiveOrgList: OrgDetail[] = [
  {
    id: 34,
    orgId: '123',
    name: 'Nagarro Abstract',
    accountType: 'AA',
    accountAddress: '',
    brNumber: '',
    country: 'Bulgaria',
    address: 'Gurugram',
    industry: '',
    website: 'www.nagarro.com',
    email: 'marketing@nagarro.com',
    domain: 'nagarro.com',
    logo: {
      path: 'https://acentrik-organization-img-nagarro-dev.s3.amazonaws.com/1/chinar.png',
      preview: '',
      contentType: ''
    },
    revenueWallet: '',
    orgGroup: 'Devtest',
    remark: '',
    state: 'Inactive',
    activatedOn: '',
    instanceRepresentativeId: '',
    registrationDocument: '',
    createdDate: '2023-08-16T11:37:25.573833Z',
    createdBy: 'NAGARRO_TEST_SYSTEM',
    lastUpdatedDate: '0001-01-01T00:00:00Z',
    lastUpdatedBy: ''
  }
]

export const filterCriterias = {
  Country: ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Czech Republic'],
  Industry: ['Aerospace', 'Agriculture', 'Automotive', 'Blockchain', 'Energy']
}
export const instanceOrgDetails = {
  name: 'TestShivam',
  accountType: 'EOA',
  ssoEnabled: false,
  ssoConfigured: false,
  socialDetails: {},
  enablePaymaster: false,
  orgId: 'cd23b513-99ca-490a-be4f-0669dbb02cf9',
  orgGroup: ''
}
