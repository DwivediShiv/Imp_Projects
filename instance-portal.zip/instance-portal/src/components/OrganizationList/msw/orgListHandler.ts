import { rest } from 'msw'
import { server } from '@utils/msw'
import {
  ApiResponse,
  MswHandlerProps,
  OrgList,
  OrgDetail
} from '../types/OrgList'
import {
  orgList,
  inactiveOrgList,
  activeOrgList,
  emptyOrgList,
  filterCriterias
} from './orgListData'
import { STATUS_CONSTANTS } from '@constants/constants'
import appConfig from 'app.config'

export function setupGetOrgDataHandler(props?: MswHandlerProps<OrgDetail[]>) {
  const statusCode = props?.status ?? 200
  const handler = rest.post(
    `${appConfig.api}/user-management/api/v1/org/details-list`,
    async (_, res, ctx) => {
      let json
      let data = orgList

      json = {
        filterCriterias
      }

      if (props?.typeOfData === STATUS_CONSTANTS.Active.title) {
        data = activeOrgList
      } else if (props?.typeOfData === STATUS_CONSTANTS.Inactive.title) {
        data = inactiveOrgList
      } else if (props?.typeOfData === 'No Record') {
        data = emptyOrgList.emptyData
      } else if (props?.typeOfData === 'Nagarro') {
        data = data.filter((item) => item.name === 'Nagarro')
      } else if (props?.typeOfData === 'Austria, Belgium') {
        data = data.filter(
          (item) => item.country === 'Austria' || item.country === 'Belgium'
        )
      } else if (props?.typeOfData === 'Aerospace') {
        data = data.filter((item) => item.industry === 'Aerospace')
      }

      if (props?.response) {
        json = { ...json, ...props.response }
      } else {
        json = {
          ...json,
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  const handler1 = rest.post(
    `${appConfig.api}/user-management/api/v1/org/details-list/export`,
    async (_, res, ctx) => {
      let json
      const data = orgList

      json = {
        filterCriterias
      }

      if (props?.response) {
        json = { ...json, ...props.response }
      } else {
        json = {
          ...json,
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler, handler1)
}
