import React, { useCallback, useEffect, useState } from 'react'
import classNames from 'classnames'
import styles from './index.module.css'
import Container from '@sharedComponents/Container'
import Link from 'next/link'
import { useOrgListing } from './hooks/useOrgListing'
import useOrgListApi from './hooks/useOrgListApi'
import { useAuthorize } from '@core/context/Authorize'
import CustomButton from '@sharedComponents/Button'
import CustomTableList from '@sharedComponents/CustomTableList'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import { debounce } from 'lodash'
import { useRouter } from 'next/router'

import CustomIconicCard, {
  CustomIconicCardState,
  CustomIconicCardSize
} from '@sharedComponents/IconicCard'
import Loader from '@sharedComponents/CustomLoader'
import CustomModal from '@sharedComponents/Modal'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import Warning from '../WarningMessage'
import useCreateOrgApi from '../OrganizationAdd/hooks/useCreateOrgApi'
import { TransformedFilterCriterias } from '@sharedComponents/CustomTableList/types/CustomTableListTypes'
import ExportTable from '@sharedComponents/ExportTable'
const OrganizationList = () => {
  const router = useRouter()
  const { isAdmin, isLogin } = useAuthorize()
  const {
    handleTabChange,
    handlePageChange,
    handleSortChange,
    handleSortOption,
    handleOnSearch,
    page,
    sortValue,
    sortBy,
    sortOrder,
    searchValue,
    status,
    tabIndex,
    OrgListConfig: orgListConfig,
    setIsLoading,
    isLoading,
    filterCountry,
    filterIndustry,
    hasFilterApplied,
    isInitialLoader,
    setIsInitialLoader,
    isModalOpen,
    setIsModalOpen,
    modalFieldValue,
    init,
    refreshList
  } = useOrgListing()
  const [transformedFilterCriteria, setTransformedFilterCriteria] =
    useState<TransformedFilterCriterias>({})
  const {
    orgListData,
    orgListError,
    orgListErrorCode,
    fetchOrgList,
    orgListTotal,
    filterCriterias
  } = useOrgListApi()

  const debouncefetch = useCallback(
    debounce((params) => {
      fetchOrgList(params)
    }, 500),
    []
  )
  useEffect(() => {
    const data = filterCriterias
    const updatedData = {}
    for (const key in data) {
      if (data[key]?.length) {
        const updatedKey = Object.fromEntries(
          [...data[key]].map((item) => [
            item,
            filterCountry[item] || filterIndustry[item] || false
          ])
        )
        updatedData[`${key}`] = updatedKey
      }
    }
    setTransformedFilterCriteria(updatedData)
  }, [filterCriterias])
  const { fetchInstanceOrgDetails, instanceOrgDetails } = useCreateOrgApi()
  useEffect(() => {
    if (isLogin) {
      fetchInstanceOrgDetails()
    }
  }, [isLogin])

  useEffect(() => {
    const params = {
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterCountry,
      filterIndustry,
      setIsInitialLoader
    }
    debouncefetch(params)
  }, [
    fetchOrgList,
    page,
    searchValue,
    setIsLoading,
    sortBy,
    sortOrder,
    status,
    filterCountry,
    filterIndustry,
    isLogin,
    setIsInitialLoader,
    init,
    refreshList
  ])

  function renderOrgListData() {
    if (orgListError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = FAILURE_MESSAGES.GENERAL_FAILURE

      const isUnauthorize = orgListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    return (
      <>
        <CustomTableList
          configuration={orgListConfig}
          data={orgListData}
          totalRecord={orgListTotal}
          isLoading={isLoading}
          paginationSize={10}
          tabIndex={tabIndex}
          sortValue={sortValue}
          sortBy={sortBy}
          sortOrder={sortOrder}
          handlePageChange={handlePageChange}
          handleOnTabChange={handleTabChange}
          page={page}
          handleSortChange={handleSortChange}
          handleSortOption={handleSortOption}
          state={status}
          handleOnSearch={handleOnSearch}
          filterCriterias={transformedFilterCriteria}
          searchValue={searchValue}
          hasFilterApplied={hasFilterApplied}
        />
        <CustomModal
          type={CUSTOM_TYPE}
          title={modalFieldValue.heading}
          titleSize="h3"
          onToggleModal={() => {
            setIsModalOpen(false)
          }}
          isOpen={isModalOpen}
        >
          {modalFieldValue.subheading}
          <div className={styles.footer}>
            <CustomButton
              color="primary"
              variant="contained"
              className={`mt-1 ${styles.confirmButton}`}
              onClick={modalFieldValue.handleSubmit}
            >
              Confirm
            </CustomButton>
          </div>
        </CustomModal>
      </>
    )
  }

  return (
    <PrivateRoute>
      {isInitialLoader ? (
        <div className={styles.loader}>
          <Loader />
        </div>
      ) : (
        <>
          {(orgListData && orgListData.length) ||
          (!isLoading &&
            orgListTotal === 0 &&
            (hasFilterApplied() || tabIndex !== 0)) ||
          orgListError ? (
            <>
              <section className={styles.grid}>
                <div className={styles.header}>
                  <div>
                    {!orgListError && (
                      <h3 className={styles.bold}>Manage groups</h3>
                    )}
                    {<div className={styles.description}>&nbsp;</div>}
                  </div>
                  <div>
                    {!orgListError && isAdmin && (
                      <Link href="create-org" legacyBehavior>
                        <CustomButton
                          color="primary"
                          variant="contained"
                          className={styles.inviteButton}
                        >
                          {instanceOrgDetails &&
                          Object.keys(instanceOrgDetails).length
                            ? `Create new group`
                            : `Create Instance Org`}
                        </CustomButton>
                      </Link>
                    )}
                    {!orgListError && (
                      <ExportTable
                        exportConfig={orgListConfig.exportConfig}
                        totalRecord={orgListTotal}
                      ></ExportTable>
                    )}
                  </div>
                </div>
              </section>
              {renderOrgListData()}
            </>
          ) : (
            !isLoading &&
            !orgListError && (
              <div className={`${styles.noData} h-100`}>
                <CustomIconicCard
                  header="You do not have any organizations yet."
                  icon="not-found"
                  state={CustomIconicCardState.Warning}
                  size={CustomIconicCardSize.Big}
                >
                  <>
                    <div>Get started by create new organization</div>
                    <CustomButton
                      color="primary"
                      variant="contained"
                      className={styles.instanceButton}
                      onClick={() => router.push(`/create-org`)}
                    >
                      Create Instance Organization
                    </CustomButton>
                  </>
                </CustomIconicCard>
              </div>
            )
          )}
        </>
      )}
    </PrivateRoute>
  )
}

export default OrganizationList
