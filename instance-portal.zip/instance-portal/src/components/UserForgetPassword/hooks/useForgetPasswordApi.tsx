import appConfig from 'app.config'
import axios from 'axios'

const useForgotPwdApi = () => {
  const postResendEmailUrl = `${appConfig.api}/user-management/api/v1/as/send-reset-email-instance`

  const postResendEmail = async (data: { email: string }) => {
    const { data: response } = await axios.post(postResendEmailUrl, data)
    return response.data
  }

  return {
    postResendEmail
  }
}

export default useForgotPwdApi
