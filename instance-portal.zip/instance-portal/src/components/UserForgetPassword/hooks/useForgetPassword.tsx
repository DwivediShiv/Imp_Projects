import { useMemo, useState } from 'react'
import { ForgetPasswordForm } from '@type/Form'
import {
  ENTER_VALID_EMAIL,
  ERROR_USER_NOT_FOUND,
  REQUIRED_FIELD
} from '@constants/constants'
import * as Yup from 'yup'
import useForgetPasswordApi from './useForgetPasswordApi'
import FancyToast from '@sharedComponents/Toast'

export const initialValues: Partial<ForgetPasswordForm> = {
  email: ''
}

export const validationSchema: Yup.SchemaOf<ForgetPasswordForm> =
  Yup.object().shape({
    email: Yup.string().email(ENTER_VALID_EMAIL).required(REQUIRED_FIELD)
  })

const useForgetPassword = () => {
  const { postResendEmail } = useForgetPasswordApi()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [userEmail, setEmail] = useState('')

  const handleSubmit = async (
    values: Partial<ForgetPasswordForm>,
    resetForm: () => void
  ): Promise<void> => {
    const data = {
      email: values.email
    }
    try {
      setLoading(true)
      // API call to continue
      await postResendEmail(data)
      resetForm()
      setEmail(values.email)
      setIsModalOpen(true)
    } catch (error) {
      console.error(error.message)
      FancyToast('error', ERROR_USER_NOT_FOUND.MESSAGE)
    } finally {
      setLoading(false)
    }
  }
  const forgetPassword = useMemo(() => {
    return {
      title: 'Reset Your Password',
      name: 'Continue',
      fields: [
        {
          name: 'email',
          label: 'Business Email Address',
          placeholder: 'Business Email Address',
          help: 'Input your email address',
          type: 'email',
          required: true
        }
      ]
    }
  }, [])
  return {
    forgetPassword,
    loading,
    isModalOpen,
    setIsModalOpen,
    userEmail,
    handleSubmit
  }
}

export default useForgetPassword
