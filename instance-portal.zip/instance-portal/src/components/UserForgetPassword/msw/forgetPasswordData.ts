export const forgetPasswordData = {
  message: 'Successfully sent the reset password email'
}
