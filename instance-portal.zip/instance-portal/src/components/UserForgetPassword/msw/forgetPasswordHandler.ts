import { rest } from 'msw'
import { server } from '@utils/msw'
import appConfig from 'app.config'
import { MswHandlerProps } from '@features/UserAdd/types/inviteUser'
import { forgetPasswordData } from './forgetPasswordData'

export function forgetPwdDataHandler(
  props?: MswHandlerProps<{ status?: string }>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.post(
    `${appConfig.api}/user-management/api/v1/as/send-reset-email-instance`,
    async (_, res, ctx) => {
      let json
      const data = forgetPasswordData

      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
