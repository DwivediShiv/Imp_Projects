import React from 'react'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import ForgotPassword from '..'
import { validationSchema } from '../hooks/useForgetPassword'
import { forgetPwdDataHandler } from '../msw/forgetPasswordHandler'

const mockRouterPush = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    push: mockRouterPush
  })
}))

jest.mock('../hooks/useForgetPasswordApi', () => ({
  __esModule: true,
  default: () => ({
    postResendEmail: jest.fn()
  })
}))

describe('Should render Reset Password resend LINK Form', () => {
  beforeEach(() => {
    forgetPwdDataHandler()
  })
  it(' rendering Resend link form  ', async () => {
    render(<ForgotPassword />)
    expect(
      await screen.findByRole('heading', {
        name: /reset your password/i
      })
    ).toHaveTextContent('Reset Your Password')

    const returnToLoginBtn = await screen.findByRole('button', {
      name: /continue/i
    })
    expect(returnToLoginBtn).toBeInTheDocument()
  })

  it('test forget pwd', async () => {
    render(<ForgotPassword />)
    expect(
      await screen.findByRole('heading', {
        name: /reset your password/i
      })
    ).toHaveTextContent('Reset Your Password')

    const continueBtn = await screen.findByRole('button', {
      name: /continue/i
    })
    const email = await screen.findByRole('textbox', {
      name: /business email address/i
    })
    fireEvent.change(email, {
      target: { value: 'test123@gmail.com' }
    })
    expect(continueBtn).toBeEnabled()
    fireEvent.click(continueBtn)
    await waitFor(() => {
      const successModal = screen.getByText('Password Recovery')
      expect(successModal).toBeInTheDocument()
    })
  })
})

describe('Yup validation for Resend Invite Link Page', () => {
  it('check yup validations , incorrect values will give error', async () => {
    const values = {
      email: ''
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toBe(false)
  })

  it('check yup validations on the form correct values no error', async () => {
    const values = {
      email: 'testbusiness@nagarro.com'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toEqual(true)
  })
})
