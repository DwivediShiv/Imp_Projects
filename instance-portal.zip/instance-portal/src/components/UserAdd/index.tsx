import * as Yup from 'yup'

import React, { ReactElement, useEffect, useState } from 'react'
import useInviteUserApi from './hooks/useInviteUserApi'
import {
  FormValues,
  FormattedValues,
  InviteUserFormSchema
} from './types/inviteUser'
import { formConfig } from './hooks/inviteUserConfig'
import { ALLOWED_ROLES } from '@constants/roleConstants'
import CommonForm from '@sharedComponents/Forms/CommonForm'
import Toast from '@sharedComponents/Toast'
import { ERROR_UNAUTH } from '@constants/permissionConstants'
import { USER_MESSAGES } from '@constants/modalConstant'

export function formatValues(values: FormValues): FormattedValues {
  const roles = []
  roles.push(ALLOWED_ROLES.ADMIN)
  return {
    email: values.email,
    roles,
    remark: values.remarks
  }
}

export const validationSchema: Yup.SchemaOf<InviteUserFormSchema> =
  Yup.object().shape({
    email: Yup.string()
      .email('Please enter a valid email address.')
      .required('Required Field.'),
    remarks: Yup.string()
  })
function InviteUser({
  onToggleModal
}: {
  onToggleModal: () => void
  isOpen: boolean
}): ReactElement {
  const [checkedBoxes, setCheckedBoxes] = useState<string[]>([])
  const { inviteUser, inviteUserError } = useInviteUserApi()

  useEffect(() => {
    if (inviteUserError === ERROR_UNAUTH) {
      Toast('error', USER_MESSAGES.ERROR_UNAUTH_USER_INVITE)
      onToggleModal()
    } else if (inviteUserError) {
      Toast(
        'error',
        'The invitation email could not be sent at the moment. Please try again later.'
      )
      onToggleModal()
    } else if (inviteUserError === null) {
      Toast('success', 'The invitation email has been sent successfully')
      onToggleModal()
    }
  }, [inviteUserError, onToggleModal])

  async function handleSubmit(
    values: FormValues,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ): Promise<void> {
    const formattedValues = formatValues(values)
    await inviteUser(formattedValues, setFieldError)
  }

  function checkDisabled(dirty, errors) {
    return !dirty || !!errors.email
  }

  function onChangeCheckbox(option) {
    setCheckedBoxes((prev) => {
      const index = prev.indexOf(option)
      if (index === -1) {
        return [...prev, option]
      } else {
        return prev.slice(0, index).concat(prev.slice(index + 1))
      }
    })
  }
  return (
    <CommonForm
      content={formConfig}
      validationSchema={validationSchema}
      handleSubmit={handleSubmit}
      checkDisabled={checkDisabled}
      onChangeCheckbox={onChangeCheckbox}
    />
  )
}

export default InviteUser
