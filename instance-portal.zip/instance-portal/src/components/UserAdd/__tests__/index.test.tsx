import React from 'react'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import InviteUser from '..'
import { inviteUserDataHandler } from '../msw/invitationHandler'

function renderComponent() {
  render(
    <InviteUser
      onToggleModal={() => {
        console.log('toggle')
      }}
      isOpen={false}
    />
  )
}

describe('Invite User ', () => {
  beforeEach(() => {
    inviteUserDataHandler()
  })
  it('components rendered and button is disabled ', async () => {
    renderComponent()

    expect(await screen.findByText('Email address')).toBeInTheDocument()
    const inviteButton = await screen.findByRole('button', {
      name: /Confirm/i
    })
    expect(inviteButton).toBeInTheDocument()
    expect(inviteButton).toBeDisabled()
  })

  it('email required for button to be enabled ', async () => {
    renderComponent()

    const emailText = await screen.findByRole('textbox', {
      name: /Email address/i
    })

    fireEvent.change(emailText, { target: { value: 'test@nagarro.com' } })
    const inviteButton = await screen.findByRole('button', {
      name: /Confirm/i
    })
    expect(inviteButton).toBeInTheDocument()
    expect(inviteButton).toBeEnabled()
  })

  it('submitting form', async () => {
    renderComponent()

    const emailText = await screen.findByRole('textbox', {
      name: /Email address/i
    })
    fireEvent.change(emailText, { target: { value: 'test@nagarro.com' } })
    const inviteButton = await screen.findByRole('button', {
      name: /Confirm/i
    })
  })
})
