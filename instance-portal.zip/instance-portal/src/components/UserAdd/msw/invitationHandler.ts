import { rest } from 'msw'
import { server } from '@utils/msw'
import appConfig from 'app.config'
import { invitationData } from './invitationData'
import { MswHandlerProps } from '../types/inviteUser'

export function inviteUserDataHandler(
  props?: MswHandlerProps<{ status?: string }>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.post(
    `${appConfig.api}/user-management/api/v1/as/invite-user`,
    async (_, res, ctx) => {
      let json
      const data = invitationData

      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
