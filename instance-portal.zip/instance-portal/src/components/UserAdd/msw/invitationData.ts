export const invitationData = {
  status: 'Successfully sent the invitation.'
}
