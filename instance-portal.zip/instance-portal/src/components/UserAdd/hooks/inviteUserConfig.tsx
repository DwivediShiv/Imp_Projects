export const formConfig = {
  title: 'Confirm',
  initialValues: {
    email: ''
  },
  form: {
    data: [
      {
        name: 'email',
        label: 'Email address',
        placeholder: 'e.g. joedoe@email.com',
        help: 'Enter user email address.',
        type: 'email',
        required: true
      },
      {
        name: 'remarks',
        placeholder: 'Remarks (optional)',
        help: 'Remarks',
        type: 'textarea'
      }
    ]
  }
}
