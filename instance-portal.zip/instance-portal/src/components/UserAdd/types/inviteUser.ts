export interface ApiResponse<T> {
  data?: T
  status?: number
  statusText?: string
  error?: string | { message: string }
  code?: string
}
export interface InviteUserFormSchema {
  email: string
  remarks?: string
}

export interface FormattedValues {
  email: string
  roles: string[]
  remark: string
}
export interface FormValues {
  email: string
  admin?: boolean
  remarks?: string
}

export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}
