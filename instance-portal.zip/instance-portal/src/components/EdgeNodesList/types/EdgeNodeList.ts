import {
  Column,
  ExportConfig,
  FilterConfig,
  SearchConfig,
  TabConfig
} from '@sharedComponents/CustomTableList/types/CustomTableListTypes'

export interface Config {
  config: {
    title: string
    columns: Column[]
    tabConfig: TabConfig
    exportConfig: ExportConfig
    searchConfig: SearchConfig
    filterConfig: FilterConfig
  }
}

export interface Configuration {
  instanceEdgeNode: Config
  orgEdgeNode: Config
}

export interface NodeDetail {
  id: string
  name: string
  orgId: string
  url: string
  network: string
  active: string
  provider_address: string
  owner: string
  created_date: string
  created_by: string
  state: string
  version: string
}

export interface EdgeNodeList {
  data: NodeDetail[]
  totalRecord: number
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
  totalRecord?: number
  filterCriterias?: Record<string, string[]>
  code?: string
}

export interface EdgeNodeFilters {
  type: string
  searchValue: string
  filterNetwork: Record<string, boolean>
  filterOrgName?: Record<string, boolean>
  organizationMap?: string
  status: string
  sortBy: string
  sortOrder: string
}

export interface OrganizationFilter {
  orgId: string
  orgName?: string
}

export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
  typeOfData?: string
}
