import { customization } from 'app.config'
import { NodeDetail } from '../types/EdgeNodeList'

export const orgEdgeNodeConfig = [
  {
    id: 'name',
    title: 'Name',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'name',
    class: 'name',
    rowConfig: {
      cellType: 'clickableField',
      clickable: () => {
        return true
      },
      value: 'name',
      onClick: (row: NodeDetail) => {
        return `/edgenode/${row.id}`
      }
    },
    width: '198px',
    sortField: 'name'
  },
  {
    id: 'orgName',
    title: 'Group',
    type: 'tableHeader',
    sortable: false,
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'orgName'
    },
    width: '198px'
  },
  {
    id: 'url',
    title: 'URL',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'url',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'url'
    },
    width: '158px',
    sortField: 'url'
  },
  {
    id: 'network',
    title: 'Blockchain network',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'network',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'network'
    },
    width: '180px',
    sortField: 'network'
  },
  {
    id: 'provider_address',
    title: 'Address',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'provider_address',
    rowConfig: {
      cellType: 'default',
      clickable: 'false',
      value: 'provider_address'
    },
    width: '124px',
    sortField: 'provider_address'
  },
  {
    id: 'created_date',
    title: 'Added On',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'created_date',
    rowConfig: {
      cellType: 'dateField',
      format: customization.dateFormat,
      value: 'created_date'
    },
    width: '130px',
    sortField: 'created_date',
    allowOverflow: false
  },
  {
    id: 'version',
    title: 'Version',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'version',
    rowConfig: {
      cellType: 'default',
      value: 'version'
    },
    width: '100px',
    sortField: 'version',
    allowOverflow: false
  },
  {
    id: 'state',
    title: 'Status',
    type: 'tableHeader',
    sortable: false,
    sortBy: 'state',
    rowConfig: {
      cellType: 'fancyStatusField',
      value: 'state'
    },
    sortField: 'state',
    allowOverflow: false
  }
]
