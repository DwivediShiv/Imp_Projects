import React from 'react'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import user from '@testing-library/user-event'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'
import ManageEdgeNodes from '..'
import { setupEdgeNodeListDataHandler } from '../msw/edgeNodeListHandler'
import { STATUS_CONSTANTS } from '@constants/constants'

const mockRouterBack = jest.fn()
const mockRouterPush = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack,
    push: mockRouterPush
  })
}))

jest.mock('@core/context/FancyState', () => ({
  useFancyState: () => ({
    getOrganizationOptions: jest.fn()
  })
}))

jest.mock('@core/context/Authorize')

function renderComponent(options) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isAdmin, isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isAdmin,
    isLogin
  })

  return render(<ManageEdgeNodes />)
}

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // Deprecated
    removeListener: jest.fn(), // Deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn()
  }))
})

describe('Edge Node List ', () => {
  it('Edge Node List should render with no data ', async () => {
    setupEdgeNodeListDataHandler({
      status: 200,
      response: { data: [] as any, totalRecord: 0 }
    })
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(await screen.findByText('Manage edge nodes')).toBeInTheDocument()
    })
    expect(
      await screen.findByText('Instance has no Edge Node yet.')
    ).toBeInTheDocument()
  })

  it('should render edge node list with tabs', async () => {
    setupEdgeNodeListDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    expect(
      await screen.findByRole('tab', {
        name: /instance edge nodes/i
      })
    ).toBeInTheDocument()
    expect(
      await screen.findByRole('tab', {
        name: /group edge nodes/i
      })
    ).toBeInTheDocument()
    expect(
      await screen.findByRole('tab', {
        name: /all/i
      })
    ).toBeInTheDocument()
    expect(
      await screen.findByRole('tab', {
        name: /inactive/i
      })
    ).toBeInTheDocument()
  })

  it('should render search box and refresh button and perform refresh action', async () => {
    setupEdgeNodeListDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })

    const searchBox = await screen.findByPlaceholderText('Search')
    expect(searchBox).toBeInTheDocument()
    const refreshBtn = await screen.findByText(/refresh list/i)
    fireEvent.click(refreshBtn)
    await waitFor(async () => {
      expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    })

    const searchInput1 = screen.getByPlaceholderText('Search')
    await user.type(searchInput1, 'Test Edge')

    expect(searchBox).toHaveValue('Test Edge')
  })

  it('should search edge node list and export', async () => {
    window.URL.createObjectURL = jest.fn()
    setupEdgeNodeListDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    expect(await screen.findByPlaceholderText('Search')).toBeInTheDocument()
    const refreshBtn = await screen.findByText(/refresh list/i)
    fireEvent.click(refreshBtn)
    await waitFor(async () => {
      expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    })

    const searchInput = screen.getByPlaceholderText('Search')
    await user.type(searchInput, 'Test Edge')

    await waitFor(async () => {
      expect(searchInput).toHaveValue('Test Edge')
    })

    expect(await screen.findByText(/export/i)).toBeInTheDocument()
    const exportBtn = await screen.findByText(/export/i)
    expect(exportBtn).toBeInTheDocument()
    fireEvent.click(exportBtn)
  })

  it('should able to reset the searchbox', async () => {
    setupEdgeNodeListDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
    })
    const searchInput = screen.getByPlaceholderText('Search')
    await user.type(searchInput, 'Test Edge')

    await waitFor(async () => {
      expect(searchInput).toHaveValue('Test Edge')
    })
    const resetBtn = await screen.findByText('Reset')
    expect(resetBtn).toBeInTheDocument()
    fireEvent.click(resetBtn)
    await waitFor(async () => {
      expect(searchInput).toHaveValue('')
    })
  })

  it('Edge Node List should render with data', async () => {
    window.URL.createObjectURL = jest.fn()
    setupEdgeNodeListDataHandler()
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    await waitFor(async () => {
      expect(await screen.findByText('Manage edge nodes')).toBeInTheDocument()
    })
    const orgEdgeNode = await screen.findByRole('tab', {
      name: /group edge nodes/i
    })
    expect(orgEdgeNode).toBeInTheDocument()
    fireEvent.click(orgEdgeNode)
  })
  it('api errors should be handled', async () => {
    setupEdgeNodeListDataHandler({
      response: {
        code: 'Error_UnAuthorizedUserAction',
        error: 'User Unauthorized'
      },
      status: 400
    })
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(await screen.findByText(/Restricted Access/i)).toBeInTheDocument()
  })
})

describe('Click of tabs', () => {
  it('Active tab click', async () => {
    setupEdgeNodeListDataHandler({ typeOfData: STATUS_CONSTANTS.Active.title })
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })

    await waitFor(async () => {
      expect(
        await screen.findByRole('tab', { name: 'All' })
      ).toBeInTheDocument()
    })

    const activeTab = screen.getByRole('tab', { name: /\bactive\b/i })
    user.click(activeTab)
  })
})
