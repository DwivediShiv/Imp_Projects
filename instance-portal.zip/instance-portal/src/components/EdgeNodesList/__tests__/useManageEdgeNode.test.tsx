import React from 'react'
import { renderHook, act } from '@testing-library/react'
import { useManageEdgeNode } from '../hooks/useManageEdgeNode'

jest.mock('next/router', () => ({
  useRouter: () => ({
    push: jest.fn()
  })
}))

jest.mock('../hooks/useManageEdgeNodeApi', () => ({
  useManageEdgeNodeApi: jest.fn(() => ({
    exportEdgeNodeList: jest.fn(),
    deleteEdgeNode: jest.fn()
  }))
}))

describe('useManageEdgeNode', () => {
  const organizationMap = {
    'bb0b9a56-93b1-4a9f-afac-7a0dc06bd1e8': 'Abhishek AA',
    'ea79cd64-0321-4c86-836b-b258b3dc9176': 'Abhishek Meta',
    'e9092482-68d4-4bbe-a689-3c54bf641cb7': 'Abstract org',
    '0da8cd0d-f0e7-44ac-8bca-df8447f4a626': 'Calhoun and Glover Plc',
    '06c4abe6-bbf4-4dec-b62f-f4ac7f09086e': 'English and Woodard Traders',
    '48865a23-b2ea-41cc-ae1b-5a9aef16182b': 'Hudson and Barnett LLC',
    'd6295156-e87e-4996-b152-d6f74739c12a': 'P Org 1',
    'd7091bbd-4161-4d99-babb-2c6fdef5eea9': 'Test 28',
    'b97d690c-4d58-4201-9abf-eaf8edbce950': 'Test MK 222',
    'cd23b513-99ca-490a-be4f-0669dbb02cf9': 'TestShivam',
    'c7cc329e-ad47-4edd-bfb6-d55a599bd43f': 'Welch and Hickman Plc'
  }

  it('handles tab changes', async () => {
    const { result } = renderHook(() => useManageEdgeNode({ organizationMap }))
    act(() => {
      result.current.handleParentTabChange(null, 1)
    })
    expect(result.current.parentTabIndex).toBe(1)
  })
})
