import React from 'react'
import { render, screen } from '@testing-library/react'
import ManageEdgeNodes from '..'
import { useAuthorize, AuthorizeProviderValue } from '@core/context/Authorize'

const mockRouterPush = jest.fn()

interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterPush
  })
}))

jest.mock('@core/context/FancyState', () => ({
  useFancyState: () => ({
    getOrganizationOptions: jest.fn()
  })
}))

jest.mock('@core/context/Authorize')

const renderComponent = (options: RenderOptions) => {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin
  })

  render(<ManageEdgeNodes />)
}

describe('Should render Manage Edge Nodes Form', () => {
  it('login component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isLogin: false
      }
    })
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('render Manage Edge Node Form', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
  })

  it('render Manage Edge Node Form Org Edge node Tab', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
  })
})
