import React, { useCallback, useEffect, useState } from 'react'
import styles from './index.module.css'
import { parentTabs, useManageEdgeNode } from './hooks/useManageEdgeNode'
import CustomTableList from '@sharedComponents/CustomTableList'
import Tabs from '@sharedComponents/Tabs'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import { useManageEdgeNodeApi } from './hooks/useManageEdgeNodeApi'
import { useOrganizationName } from '@hooks/useOrganizationName'
import { useAuthorize } from '@core/context/Authorize'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import Modal from '@sharedComponents/Modal'
import { debounce } from 'lodash'
import Link from 'next/link'
import CustomButton from '@sharedComponents/Button'
import Loader from '@sharedComponents/CustomLoader'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Warning from '../WarningMessage'
import { TransformedFilterCriterias } from '@sharedComponents/CustomTableList/types/CustomTableListTypes'

const ManageEdgeNodes = () => {
  const { organizationMap } = useOrganizationName()
  const {
    parentTabIndex,
    handleParentTabChange,
    handlePageChange,
    handleTabChange,
    instTabIndex,
    orgTabIndex,
    instSortValue,
    instSortBy,
    instSortOrder,
    orgSortValue,
    orgSortBy,
    orgSortOrder,
    instListPage,
    orgListPage,
    instNodeStatus,
    orgNodeStatus,
    handleSortChange,
    handleSortOption,
    handleOnSearch,
    edgeNodeConfig,
    hasFilterApplied,
    instSearchValue,
    orgSearchValue,
    filterInstNetwork,
    filterOrgName,
    filterOrgNetwork,
    isLoading,
    setIsLoading,
    setIsModalOpen,
    isModalOpen,
    submitModal,
    init,
    isInitialLoader,
    setInitialLoader,
    refreshList,
    setRefreshList
  } = useManageEdgeNode({ organizationMap })
  const { isLogin } = useAuthorize()
  const {
    fetchEdgeNodeList,
    edgeNodeListData,
    edgeNodeListTotal,
    filterCriterias,
    edgeNodeListError,
    edgeNodeListErrorCode
  } = useManageEdgeNodeApi()
  const {
    instanceEdgeNode: { config: instanceConfig },
    orgEdgeNode: { config: orgConfig }
  } = edgeNodeConfig
  const [transformedFilterCriteria, setTransformedFilterCriteria] =
    useState<TransformedFilterCriterias>({})
  const debouncefetch = useCallback(
    debounce((params) => {
      fetchEdgeNodeList(params)
    }, 500),
    []
  )

  useEffect(() => {
    const data = filterCriterias
    const updatedData = {}
    for (const key in data) {
      if (data[key]?.length) {
        const updatedKey = Object.fromEntries(
          [...data[key]].map((item) => [
            item,
            filterInstNetwork[item] ||
              filterOrgName[item] ||
              filterOrgNetwork[item] ||
              false
          ])
        )
        updatedData[`${key}`] = updatedKey
      }
    }
    setTransformedFilterCriteria(updatedData)
  }, [filterCriterias])

  useEffect(() => {
    if (organizationMap) {
      if (parentTabIndex === 0) {
        const params = {
          type: 'instance',
          page: instListPage,
          sortBy: instSortBy,
          sortOrder: instSortOrder,
          status: instNodeStatus,
          searchValue: instSearchValue,
          setIsLoading,
          filterNetwork: filterInstNetwork,
          setInitialLoader
        }
        debouncefetch(params)
      } else {
        const params = {
          type: 'portal',
          page: orgListPage,
          sortBy: orgSortBy,
          sortOrder: orgSortOrder,
          status: orgNodeStatus,
          searchValue: orgSearchValue,
          setIsLoading,
          filterNetwork: filterOrgNetwork,
          filterOrgName,
          organizationMap,
          setInitialLoader
        }
        debouncefetch(params)
      }
    }
  }, [
    fetchEdgeNodeList,
    parentTabIndex,
    instListPage,
    orgListPage,
    instSortBy,
    orgSortBy,
    instSortOrder,
    orgSortOrder,
    instNodeStatus,
    orgNodeStatus,
    instSearchValue,
    orgSearchValue,
    filterInstNetwork,
    filterOrgName,
    filterOrgNetwork,
    setIsLoading,
    organizationMap,
    isLogin,
    init,
    setInitialLoader,
    refreshList
  ])

  function renderEdgeNodeListData() {
    if (edgeNodeListError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = FAILURE_MESSAGES.GENERAL_FAILURE

      const isUnauthorize = edgeNodeListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }
    return (
      <CustomTableList
        configuration={parentTabIndex === 0 ? instanceConfig : orgConfig}
        data={edgeNodeListData}
        totalRecord={edgeNodeListTotal}
        isLoading={isLoading}
        paginationSize={10}
        tabIndex={parentTabIndex === 0 ? instTabIndex : orgTabIndex}
        sortValue={parentTabIndex === 0 ? instSortValue : orgSortValue}
        sortBy={parentTabIndex === 0 ? instSortBy : orgSortBy}
        sortOrder={parentTabIndex === 0 ? instSortOrder : orgSortOrder}
        handlePageChange={handlePageChange}
        handleOnTabChange={handleTabChange}
        page={parentTabIndex === 0 ? instListPage : orgListPage}
        handleSortChange={handleSortChange}
        handleSortOption={handleSortOption}
        state={parentTabIndex === 0 ? instNodeStatus : orgNodeStatus}
        handleOnSearch={handleOnSearch}
        hasFilterApplied={hasFilterApplied}
        filterCriterias={transformedFilterCriteria}
        noDataText={
          <>
            <span>
              {parentTabIndex === 0
                ? 'Instance has no Edge Node yet.'
                : 'Organizations has no Edge Node yet.'}
            </span>
            <h4>
              {parentTabIndex === 0 && 'Get started by adding new edge nodes.'}
            </h4>
          </>
        }
        noDataAction={
          (parentTabIndex === 0 && (
            <Link href={instanceConfig.tabConfig.button.href} legacyBehavior>
              <CustomButton
                color={instanceConfig.tabConfig.button.color}
                variant={instanceConfig.tabConfig.button.variant}
                className={styles.tabSectionButton}
                onClick={instanceConfig.tabConfig.button.handleClick}
              >
                {instanceConfig.tabConfig.button.name}
              </CustomButton>
            </Link>
          )) || <></>
        }
      />
    )
  }

  return (
    <PrivateRoute>
      {isInitialLoader ? (
        <div className={styles.loader}>
          <Loader />
        </div>
      ) : (
        <>
          <section className={styles.grid}>
            <div className={styles.header}>
              <div>
                <h3 className={styles.bold}>Manage edge nodes</h3>
              </div>
            </div>
          </section>
          <Tabs
            items={parentTabs}
            handleTabChange={handleParentTabChange}
            defaultIndex={parentTabIndex}
            className="tabRootFullBorder"
          />

          {renderEdgeNodeListData()}

          <Modal
            type={CUSTOM_TYPE}
            title="Delete Edge Node"
            titleSize="h3"
            onToggleModal={() => {
              setIsModalOpen(false)
            }}
            isOpen={isModalOpen}
          >
            Are you sure you want to delete the Edge Node?
            <div className={styles.footer}>
              <CustomButton
                color="primary"
                variant="contained"
                className={`mt-1 ${styles.confirmButton}`}
                onClick={submitModal}
              >
                Confirm
              </CustomButton>
            </div>
          </Modal>
        </>
      )}
    </PrivateRoute>
  )
}

export default ManageEdgeNodes
