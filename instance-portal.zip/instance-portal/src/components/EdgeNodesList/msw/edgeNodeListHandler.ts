import { rest } from 'msw'
import { server } from '@utils/msw'
import { edgeNodeList } from './edgeNodeListData'
import appConfig from 'app.config'
import { EdgeNodeList, MswHandlerProps } from '../types/EdgeNodeList'

export function setupEdgeNodeListDataHandler(
  props?: MswHandlerProps<EdgeNodeList>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.post(
    `${appConfig.api}/provider-management/api/v1/edge-node-list`,
    async (_, res, ctx) => {
      let json
      const data = edgeNodeList
      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  const handler1 = rest.post(
    `${appConfig.api}/provider-management/api/v1/edge-node-list/export`,
    async (_, res, ctx) => {
      let json
      const data = edgeNodeList

      if (props?.response) {
        json = props.response
      } else {
        json = data
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler, handler1)
}
