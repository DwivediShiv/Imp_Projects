export const edgeNodeList = {
  totalRecord: 2,
  data: [
    {
      id: '9',
      name: 'Test Edge Node',
      url: 'https://v1.provider.amoy.nagarro.acentrik.io/',
      network: 'amoy',
      active: false,
      provider_address: '0x149903E8E14103CF4913C451664748892726544A',
      created_date: '2024-01-04T06:58:13.755749Z',
      created_by: 'madhavkalra01@gmail.com',
      state: 'Inactive',
      version: '1.3.12'
    },
    {
      id: '7',
      name: 'Elaine Instance 2 Edge Node',
      url: 'https://provider-amoy.elaine-instance-2.acentrik.io',
      network: 'amoy',
      active: true,
      provider_address: '0x67E64C3B0b740C7FBF40B0b8B3FDd9e9aC399B57',
      created_date: '2024-01-04T02:02:18.073811Z',
      created_by: 'kjhen0929@gmail.com',
      state: 'Active',
      version: '1.3.12'
    }
  ],
  filterCriterias: {
    network: ['amoy']
  }
}

export const filterCriterias = {
  network: ['amoy']
}

export const activeEdgeNodeList = {
  data: [
    {
      id: '7',
      name: 'Elaine Instance 2 Edge Node',
      url: 'https://provider-amoy.elaine-instance-2.acentrik.io',
      network: 'amoy',
      active: true,
      provider_address: '0x67E64C3B0b740C7FBF40B0b8B3FDd9e9aC399B57',
      created_date: '2024-01-04T02:02:18.073811Z',
      created_by: 'kjhen0929@gmail.com',
      state: 'Active',
      version: '1.3.12'
    }
  ],
  filterCriterias: {
    network: ['amoy']
  }
}

export const inActiveEdgeNodeList = {
  totalRecord: 1,
  data: [
    {
      id: '9',
      name: 'Test Edge Node',
      url: 'https://v1.provider.amoy.nagarro.acentrik.io/',
      network: 'amoy',
      active: false,
      provider_address: '0x149903E8E14103CF4913C451664748892726544A',
      created_date: '2024-01-04T06:58:13.755749Z',
      created_by: 'madhavkalra01@gmail.com',
      state: 'Inactive',
      version: '1.3.12'
    }
  ],
  filterCriterias: {
    network: ['amoy']
  }
}
