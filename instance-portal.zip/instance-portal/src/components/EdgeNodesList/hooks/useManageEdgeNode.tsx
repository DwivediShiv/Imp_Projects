import { SELECTION_CONSTANTS, STATE_CONSTANTS } from '@constants/constants'
import { useMemo, useState } from 'react'
import { useRouter } from 'next/router'
import { Configuration } from '../types/EdgeNodeList'
import { useManageEdgeNodeApi } from './useManageEdgeNodeApi'
import Delete from '@images/deleteicon.svg'
import { ModalFieldValue } from '@type/Modal'
import { orgEdgeNodeConfig } from '../configurations/orgEdgeNodeConfig'
import { instanceEdgeNodeConfig } from '../configurations/instanceEdgeNodeConfig'
import { hasSelection } from '@sharedComponents/CustomTableList/hook/useCustomTableList'
export const parentTabs = [
  {
    title: 'Instance edge nodes',
    value: 'instanceEdgeNode',
    index: 0
  },
  {
    title: `Group edge nodes`,
    value: 'orgEdgeNode',
    index: 1
  }
]

export const useManageEdgeNode = ({ organizationMap }) => {
  const router = useRouter()
  const [parentTabIndex, setParentTabIndex] = useState<number>(0)
  const [instTabIndex, setInstTabIndex] = useState<number>(0)
  const [orgTabIndex, setOrgTabIndex] = useState<number>(0)
  const [isLoading, setIsLoading] = useState<boolean>()
  const [isInitialLoader, setInitialLoader] = useState<boolean>(true)
  const [instNodeStatus, setInstNodeStatus] = useState<string>('')
  const [orgNodeStatus, setOrgNodeStatus] = useState<string>('')
  const [instListPage, setInstListPage] = useState<number>(1)
  const [orgListPage, setOrgListPage] = useState<number>(1)
  const [instSortValue, setInstSortValue] = useState<string>('')
  const [instSortBy, setInstSortBy] = useState<string>('')
  const [instSortOrder, setInstSortOrder] = useState<string>('')
  const [orgSortBy, setOrgSortBy] = useState<string>('')
  const [orgSortOrder, setOrgSortOrder] = useState<string>('')
  const [orgSortValue, setOrgSortValue] = useState<string>('')
  const [instSearchValue, setInstSearchValue] = useState<string>('')
  const [orgSearchValue, setOrgSearchValue] = useState<string>('')
  const [filterInstNetwork, setFilterInstNetwork] = useState<
    Record<string, boolean>
  >({})
  const [filterOrgNetwork, setFilterOrgNetwork] = useState<
    Record<string, boolean>
  >({})
  const [filterOrgName, setFilterOrgName] = useState<Record<string, boolean>>(
    {}
  )
  const { exportEdgeNodeList, deleteEdgeNode } = useManageEdgeNodeApi()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [init, setInit] = useState<boolean>()
  const [refreshList, setRefreshList] = useState<number>(0)
  const [modalFieldValue, setModalFieldValue] = useState<ModalFieldValue>({
    template: '',
    value: null
  })
  async function onDelete(row) {
    setModalFieldValue({ template: 'deleteUser', value: row })
    setIsModalOpen(true)
  }

  async function submitModal() {
    const { id } = modalFieldValue.value
    await deleteEdgeNode(id)
    setIsModalOpen(false)
    setInit(!init)
  }

  const orgEdgeNodeColumns = orgEdgeNodeConfig

  const handleAddEdgeNodeClick = () => {
    router.push('/add-edge-node')
  }

  const handleClearFilter = () => {
    if (parentTabIndex === 0) {
      setInstListPage(1)
      setFilterInstNetwork({})
      setInstSearchValue('')
      // setInstSortBy('')
      // setInstSortOrder('')
      // setOrgSortBy('')
      // setOrgSortOrder('')
      // setInstNodeStatus('')
      // setInstTabIndex(0)
    } else {
      setOrgListPage(1)
      setOrgSearchValue('')
      setFilterOrgNetwork({})
      setFilterOrgName({})
      // setInstSortBy('')
      // setInstSortOrder('')
      // setOrgSortBy('')
      // setOrgSortOrder('')
      // setOrgTabIndex(0)
      // setOrgNodeStatus('')
    }
  }

  const handleFilterSelect = (
    items: Record<string, boolean>,
    type: 'Network' | 'OrgNetwork' | 'ORG'
  ) => {
    setOrgListPage(1)
    switch (type) {
      case 'Network':
        setFilterInstNetwork(items)
        break
      case 'OrgNetwork':
        setFilterOrgNetwork(items)
        break
      case 'ORG':
        setFilterOrgName(items)
        break
    }
  }

  const hasFilterApplied = () => {
    if (parentTabIndex === 0) {
      return instSearchValue !== '' || hasSelection(filterInstNetwork)
    } else {
      return (
        orgSearchValue !== '' ||
        hasSelection(filterOrgName) ||
        hasSelection(filterOrgNetwork)
      )
    }
  }

  const edgeNodeConfig: Configuration = useMemo(() => {
    return {
      instanceEdgeNode: {
        config: {
          title: '',
          sortConfig: {
            type: 'fancySort',
            sortOptions: [
              {
                name: 'Edge Node Name: A-Z',
                value: 'name-asc'
              },
              {
                name: 'Edge Node Name: Z-A',
                value: 'name-desc'
              },
              {
                name: 'URL: A-Z',
                value: 'url-asc'
              },
              {
                name: 'URL: Z-A',
                value: 'url-desc'
              },
              {
                name: 'Network: A-Z',
                value: 'network-asc'
              },
              {
                name: 'Network: Z-A',
                value: 'network-desc'
              },
              {
                name: 'Added On: Newest first',
                value: 'created_date-desc'
              },
              {
                name: 'Added On: Oldest first',
                value: 'created_date-asc'
              },
              {
                name: 'Version: Newest first',
                value: 'version-desc'
              },
              {
                name: 'Version: Oldest first',
                value: 'version-asc'
              },
              {
                name: 'Status: A-Z',
                value: 'state-asc'
              },
              {
                name: 'Status: Z-A',
                value: 'state-desc'
              }
            ]
          },
          searchConfig: {
            type: 'search',
            name: 'search',
            placeholder: 'Search',
            searchValue: instSearchValue
          },
          refreshConfig: {
            name: 'Refresh list',
            handleRefreshList: () => setRefreshList(Math.random())
          },
          exportConfig: {
            exportFn: () =>
              exportEdgeNodeList({
                type: 'instance',
                sortBy: instSortBy,
                sortOrder: instSortOrder,
                status: instNodeStatus,
                searchValue: instSearchValue,
                filterNetwork: filterInstNetwork
              }),
            fileName: 'instanceEdgeNodeList.csv'
          },
          columns: [
            ...instanceEdgeNodeConfig,
            {
              id: 'actions',
              title: 'Actions',
              type: 'tableHeader',
              sortable: false,
              rowConfig: {
                cellType: 'actions',
                actions: [
                  {
                    type: 'icon',
                    image: Delete,
                    clickable: (row: any) => {
                      return row.state === STATE_CONSTANTS.INACTIVE
                    },
                    onClick: (row: any) => {
                      onDelete(row)
                    }
                  }
                ]
              },
              width: '80px',
              allowOverflow: false
            }
          ],
          tabConfig: {
            defaultTab: 0,
            button: {
              name: 'Create edge node',
              color: 'primary',
              variant: 'contained',
              handleClick: handleAddEdgeNodeClick,
              href: `add-edge-node`
            },
            showExport: true,
            tabList: [
              {
                title: 'All',
                key: 'all',
                value: '',
                index: 0
              },
              {
                title: 'Active',
                key: 'active',
                value: 'active',
                index: 1,
                icon: 'success'
              },
              {
                title: 'Inactive',
                key: 'inactive',
                value: 'inactive',
                index: 2,
                icon: 'disabled'
              }
            ]
          },
          filterConfig: {
            clearFilters: handleClearFilter,
            filters: [
              {
                id: 'network',
                inputName: 'network',
                label: 'Blockchain network',
                dynamic: true,
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                value: filterInstNetwork,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterInstNetwork,
                onChange: (items) => handleFilterSelect(items, 'Network')
              }
            ]
          }
        }
      },
      orgEdgeNode: {
        config: {
          title: '',
          sortConfig: {
            type: 'fancySort',
            sortOptions: [
              {
                name: 'Edge Node Name: A-Z',
                value: 'name-asc'
              },
              {
                name: 'Edge Node Name: Z-A',
                value: 'name-desc'
              },
              {
                name: 'URL: A-Z',
                value: 'url-asc'
              },
              {
                name: 'URL: Z-A',
                value: 'url-desc'
              },
              {
                name: 'Network: A-Z',
                value: 'network-asc'
              },
              {
                name: 'Network: Z-A',
                value: 'network-desc'
              },
              {
                name: 'Added On: Newest first',
                value: 'created_date-desc'
              },
              {
                name: 'Added On: Oldest first',
                value: 'created_date-asc'
              },
              {
                name: 'Version: Newest first',
                value: 'version-desc'
              },
              {
                name: 'Version: Oldest first',
                value: 'version-asc'
              },
              {
                name: 'Status: A-Z',
                value: 'state-asc'
              },
              {
                name: 'Status: Z-A',
                value: 'state-desc'
              }
            ]
          },
          searchConfig: {
            type: 'search',
            name: 'search',
            placeholder: 'Search',
            searchValue: orgSearchValue
          },
          exportConfig: {
            exportFn: () =>
              exportEdgeNodeList({
                type: 'portal',
                sortBy: orgSortBy,
                sortOrder: orgSortOrder,
                status: orgNodeStatus,
                searchValue: orgSearchValue,
                filterNetwork: filterOrgNetwork,
                filterOrgName,
                organizationMap
              }),
            fileName: 'orgEdgeNodeList.csv'
          },
          columns: orgEdgeNodeColumns,
          tabConfig: {
            defaultTab: 0,
            showExport: true,
            tabList: [
              {
                title: 'All',
                key: 'all',
                value: '',
                index: 0
              },
              {
                title: 'Active',
                key: 'active',
                value: 'active',
                index: 1,
                icon: 'success'
              },
              {
                title: 'Inactive',
                key: 'inactive',
                value: 'inactive',
                index: 2,
                icon: 'disabled'
              },
              {
                title: 'Pending',
                key: 'pending',
                value: 'pending',
                index: 3,
                icon: 'warning'
              },
              {
                title: 'Rejected',
                key: 'rejected',
                value: 'rejected',
                index: 4,
                icon: 'danger'
              }
            ]
          },
          filterConfig: {
            clearFilters: handleClearFilter,
            filters: [
              {
                id: 'organization',
                inputName: 'orgName',
                label: 'Group',
                containerClass: 'exploreFilter',
                customBackground: '--surface-1-color',
                dynamic: true,
                value: filterOrgName,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterOrgName,
                onChange: (items) => handleFilterSelect(items, 'ORG')
              },
              {
                id: 'network',
                inputName: 'network',
                label: 'Blockchain network',
                containerClass: 'exploreFilter',
                dynamic: true,
                customBackground: '--surface-1-color',
                value: filterOrgNetwork,
                deselectText: SELECTION_CONSTANTS.ALL,
                onValueChange: setFilterOrgNetwork,
                onChange: (items) => handleFilterSelect(items, 'OrgNetwork')
              }
            ]
          }
        }
      }
    }
  }, [
    instSearchValue,
    orgSearchValue,
    instNodeStatus,
    orgNodeStatus,
    filterInstNetwork,
    filterOrgNetwork,
    filterOrgName,
    instSortBy,
    instSortOrder,
    orgSortBy,
    orgSortOrder,
    organizationMap
  ])

  const {
    instanceEdgeNode: {
      config: {
        tabConfig: { tabList: instanceTabs }
      }
    },
    orgEdgeNode: {
      config: {
        tabConfig: { tabList: orgTabs }
      }
    }
  } = edgeNodeConfig

  const clearInstFilterProps = () => {
    setInstListPage(1)
    setFilterInstNetwork({})
    setInstSearchValue('')
    setInstTabIndex(0)
    setInstNodeStatus('')
    // setInstSortBy('')
    // setInstSortOrder('')
  }

  const clearOrgFilterProps = () => {
    setOrgListPage(1)
    setOrgSearchValue('')
    setFilterOrgNetwork({})
    setFilterOrgName({})
    setOrgTabIndex(0)
    setOrgNodeStatus('')
    // setOrgSortBy('')
    // setOrgSortOrder('')
  }

  const handleParentTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setIsLoading(true)
    setParentTabIndex(newValue)
    if (newValue === 0) {
      clearOrgFilterProps()
    } else {
      clearInstFilterProps()
    }
  }

  const handleTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    if (parentTabIndex === 0) {
      setInstListPage(1)
      setInstNodeStatus(instanceTabs[newValue].value)
      setInstTabIndex(newValue)
    } else {
      setOrgListPage(1)
      setOrgNodeStatus(orgTabs[newValue].value)
      setOrgTabIndex(newValue)
    }
  }

  const handleSortOption = async (sortOption: string) => {
    const sortSelection = sortOption.split('-')
    if (parentTabIndex === 0) {
      setInstSortValue(sortOption)
      setInstSortBy(sortSelection[0])
      setInstSortOrder(sortSelection[1])
    } else {
      setOrgSortValue(sortOption)
      setOrgSortBy(sortSelection[0])
      setOrgSortOrder(sortSelection[1])
    }
  }

  const handlePageChange = (page) => {
    parentTabIndex === 0 ? setInstListPage(page) : setOrgListPage(page)
  }

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    if (parentTabIndex === 0) {
      setInstSortBy(column.sortField)
      setInstSortOrder(sortDirection)
    } else {
      setOrgSortBy(column.sortField)
      setOrgSortOrder(sortDirection)
    }
  }

  const handleOnSearch = (e) => {
    if (parentTabIndex === 0) {
      setInstListPage(1)
      setInstSearchValue(e.target.value)
    } else {
      setOrgListPage(1)
      setOrgSearchValue(e.target.value)
    }
  }

  return {
    handleParentTabChange,
    parentTabIndex,
    handleTabChange,
    handlePageChange,
    handleSortChange,
    handleSortOption,
    instTabIndex,
    orgTabIndex,
    instNodeStatus,
    orgNodeStatus,
    instListPage,
    orgListPage,
    instSortValue,
    instSortBy,
    instSortOrder,
    orgSortValue,
    orgSortBy,
    orgSortOrder,
    handleOnSearch,
    instSearchValue,
    orgSearchValue,
    edgeNodeConfig,
    hasFilterApplied,
    handleAddEdgeNodeClick,
    filterInstNetwork,
    filterOrgName,
    filterOrgNetwork,
    isLoading,
    setIsLoading,
    isModalOpen,
    setIsModalOpen,
    submitModal,
    init,
    isInitialLoader,
    setInitialLoader,
    refreshList,
    setRefreshList
  }
}
