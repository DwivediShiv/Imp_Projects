import { useCallback, useState } from 'react'
import axios, { AxiosResponse } from 'axios'
import appConfig from 'app.config'
import { buildUrlWithQueryParams } from '@utils/url'
import { SELECTION_CONSTANTS } from '@constants/constants'
import { ApiResponse, EdgeNodeFilters, NodeDetail } from '../types/EdgeNodeList'
import { ERROR_MSG, USER_MESSAGES } from '@constants/modalConstant'
import Toast from '@sharedComponents/Toast'
import { printErrorStack } from '@utils/index'
import { ERROR_UNAUTH } from '@constants/permissionConstants'

export function getEdgeNodeUrl(id: string) {
  return `${appConfig.api}/provider-management/api/v1/edge-node/${id}`
}

export const useManageEdgeNodeApi = () => {
  const [edgeNodeListData, setEdgeNodeListData] = useState<NodeDetail | null[]>(
    null
  )
  const [edgeNodeListError, setEdgeNodeListError] = useState<string | null>('')
  const [edgeNodeListErrorCode, setEdgeNodeListErrorCode] = useState<
    string | null
  >('')
  const [edgeNodeListTotal, setEdgeNodeListTotal] = useState<number>(0)

  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>()

  const transformedData = (response, organizationMap) => {
    const dataList = response?.map((item) => {
      return { ...item, orgName: organizationMap[item?.orgId] }
    })
    return dataList
  }

  const tranformedOrgFilters = (orgIdFilter, organizationMap) => {
    const orgFilterList = orgIdFilter?.reduce((acc, curr) => {
      organizationMap[curr] &&
        acc.push({ orgId: curr, orgName: organizationMap[curr] })
      return acc
    }, [])
    return orgFilterList
  }

  const getOrgIdByOrgName = (orgMap, orgName) => {
    return Object.keys(orgMap).find((key) => orgMap[key] === String(orgName))
  }

  const getOrgFilterIds = (organizationMap, filterOrgName): string[] => {
    const orgIds = filterOrgName?.map((orgname) =>
      getOrgIdByOrgName(organizationMap, orgname)
    )
    return orgIds
  }

  const edgeNodeListUrl = `${appConfig.api}/provider-management/api/v1/edge-node-list`

  const fetchEdgeNodeList = useCallback(
    async ({
      type,
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterNetwork,
      filterOrgName,
      organizationMap,
      setInitialLoader
    }) => {
      try {
        const urlParams: Record<string, string | string[]> = {}
        setEdgeNodeListError('')
        setEdgeNodeListTotal(0)
        setIsLoading(true)

        if (type) {
          urlParams.type = type
        }

        if (page) {
          urlParams.page = page
        }

        if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
          urlParams.state = status
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.name = searchValue
        }

        const filterNetworkParam = Object.keys(filterNetwork).filter(
          (key) => filterNetwork[key]
        )

        if (filterNetworkParam?.length) {
          urlParams.networks = filterNetworkParam
        }

        if (filterOrgName) {
          const filterOrgNameParam = Object.keys(filterOrgName).filter(
            (key) => filterNetwork[key]
          )

          if (filterOrgNameParam?.length) {
            const orgfilterIds = getOrgFilterIds(
              organizationMap,
              filterOrgNameParam
            )
            urlParams.orgs = orgfilterIds
          }
        }
        const { data: response } = await axios.post<ApiResponse<NodeDetail>>(
          edgeNodeListUrl,
          urlParams
        )

        organizationMap
          ? setEdgeNodeListData(transformedData(response.data, organizationMap))
          : setEdgeNodeListData(response.data)

        if (response.filterCriterias) {
          if (type === 'portal') {
            const orgFilterList = tranformedOrgFilters(
              response.filterCriterias?.organization,
              organizationMap
            )
            const filters = {
              network: response.filterCriterias?.network,
              organization: orgFilterList?.map((orgFilter) => orgFilter.orgName)
            }
            setFilterCriterias(filters)
          } else {
            setFilterCriterias(response.filterCriterias)
          }
        }
        setEdgeNodeListTotal(response.totalRecord)
      } catch (error) {
        setEdgeNodeListErrorCode(error?.response?.data?.code || 'General')
        if (axios.isAxiosError(error)) {
          setEdgeNodeListError(error?.response?.data?.error)
        } else {
          setEdgeNodeListError('unexpected error')
        }
      } finally {
        setIsLoading(false)
        setInitialLoader(false)
      }
    },
    []
  )

  const getExportEdgeNodeUrlParam = ({
    type,
    searchValue,
    filterNetwork,
    filterOrgName,
    status,
    sortBy,
    sortOrder,
    organizationMap
  }: EdgeNodeFilters): any => {
    const urlParams: Record<string, string | string[]> = {}

    if (type) {
      urlParams.type = type
    }

    if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
      urlParams.state = status
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    if (searchValue !== '') {
      urlParams.name = searchValue
    }

    const filterNetworkParam = Object.keys(filterNetwork).filter(
      (key) => filterNetwork[key]
    )

    if (filterNetworkParam?.length) {
      urlParams.networks = filterNetworkParam
    }

    if (filterOrgName) {
      const filterOrgNameParam = Object.keys(filterOrgName).filter(
        (key) => filterNetwork[key]
      )

      if (filterOrgNameParam?.length) {
        const orgfilterIds = getOrgFilterIds(
          organizationMap,
          filterOrgNameParam
        )
        urlParams.orgs = orgfilterIds
      }
    }

    return urlParams
  }

  async function exportEdgeNodeList({
    type,
    sortBy,
    sortOrder,
    status,
    searchValue,
    filterNetwork,
    filterOrgName,
    organizationMap
  }: EdgeNodeFilters): Promise<string> {
    try {
      const { data: response } = await axios.post(
        `${appConfig.api}/provider-management/api/v1/edge-node-list/export`,
        getExportEdgeNodeUrlParam({
          type,
          searchValue,
          filterNetwork,
          filterOrgName,
          status,
          sortBy,
          sortOrder,
          organizationMap
        })
      )
      return response
    } catch (error) {
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH)
      } else if (axios.isAxiosError(error)) {
        setEdgeNodeListError(error?.response?.data?.error?.message)
      } else {
        setEdgeNodeListError(ERROR_MSG)
      }
    }
  }

  async function deleteEdgeNode(id: string): Promise<any> {
    try {
      const response: AxiosResponse = await axios({
        method: 'DELETE',
        url: getEdgeNodeUrl(id)
      })
      Toast('success', USER_MESSAGES.EDGE_NODE_DELETED)
    } catch (error) {
      if (error.response && error.response.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH_DELETE_NODE)
      } else if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }

  return {
    edgeNodeListData,
    edgeNodeListError,
    edgeNodeListErrorCode,
    edgeNodeListTotal,
    filterCriterias,
    fetchEdgeNodeList,
    exportEdgeNodeList,
    deleteEdgeNode
  }
}
