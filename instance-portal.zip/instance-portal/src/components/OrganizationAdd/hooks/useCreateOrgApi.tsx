import appConfig from 'app.config'
import axios from 'axios'
import { useCallback, useState } from 'react'
import {
  InstanceOrgDetails,
  Organization,
  OrganizationLogo
} from '../types/Organization'
import useUpload from '@hooks/useUploadS3/useUpload'
import { ERROR_EMAIL_ALREADY_EXISTS } from '@constants/constants'
import { ERROR_UNAUTH } from '@constants/permissionConstants'
import { USER_MESSAGES } from '@constants/modalConstant'
import Toast from '@sharedComponents/Toast'
import { DEFAULT_ERROR_MESSAGE, ERROR_FIELDS } from '../constants'

const useCreateOrgApi = () => {
  const { updateFile } = useUpload()
  const [instanceOrgDetails, setInstanceOrgDetails] =
    useState<InstanceOrgDetails>({})
  const [instanceOrgError, setInstanceOrgError] = useState<string | null>('')

  const postCreateOrgUrl = `${appConfig.api}/user-management/api/v1/org/invite-org`
  const approveOrgUrl = `${appConfig.api}/user-management/api/v1/org/approve-signup`
  const orgProfileApiUrl = `${appConfig.api}/user-management/api/v1/org/logo`
  const instanceDetailsApi = `${appConfig.api}/user-management/api/v1/as/instance-details`
  const rejectOrgApi = `${appConfig.api}/user-management/api/v1/org/reject`
  const [orgDetailsError, setOrgDetailsError] = useState<string | null>('')
  const [orgDetailsErrorCode, setOrgDetailsErrorCode] = useState<string | null>(
    ''
  )
  const orgProfileUpdateUrl = (id: string): string => {
    return [orgProfileApiUrl, id].join('/')
  }
  const getRejectOrgApi = (id: string): string => {
    return [rejectOrgApi, id, ''].join('/')
  }
  const getApproveOrgUrl = (id: string): string => {
    return [approveOrgUrl, id].join('/')
  }

  const createOrganization = useCallback(
    async (
      data: Organization,
      successCallback: any,
      errorCallback: any,
      setFieldError: (field: string, errorMsg: string) => void,
      file?: File,
      setLoading?,
      orgId?
    ) => {
      try {
        setOrgDetailsError('')
        let response
        if (orgId) {
          const res = await axios.post(getApproveOrgUrl(orgId), data)
          response = res.data
        } else {
          const res = await axios.post(postCreateOrgUrl, data)
          response = res.data
        }
        if (file) {
          const logoUrl = await updateFile(file, 'logo', response?.orgId)
          const payload: OrganizationLogo = {
            logo: logoUrl
          }
          if (logoUrl) {
            await axios.put(orgProfileUpdateUrl(response?.orgId), payload)
          } else {
            errorCallback(
              'Company Logo could not be successfully uploaded',
              true
            )
            return response
          }
        }
        successCallback()
        return response
      } catch (error) {
        if (error.response && error.response.data?.code === ERROR_UNAUTH) {
          Toast('error', USER_MESSAGES.ERROR_UNAUTH_CREATE_ORG)
          return
        } else if (
          error.response &&
          error.response.data?.code === ERROR_EMAIL_ALREADY_EXISTS.CODE
        ) {
          setFieldError('contactEmail', ERROR_EMAIL_ALREADY_EXISTS.MESSAGE)
          return
        }
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        const additionalErrorsKeys = Object.keys(additionalData)

        if (
          additionalErrorsKeys.length &&
          ERROR_FIELDS.includes(additionalErrorsKeys[0])
        ) {
          setFieldError(additionalErrorsKeys[0], additionalErrors[0] as string)
        } else {
          errorCallback(
            additionalErrors?.length
              ? additionalErrors[0]
              : message || DEFAULT_ERROR_MESSAGE
          )
        }
      } finally {
        setLoading(false)
      }
    },
    []
  )

  const fetchInstanceOrgDetails = useCallback(async () => {
    try {
      const { data: response } = await axios.get(instanceDetailsApi)
      setInstanceOrgDetails(response.data)
    } catch (error) {
      setOrgDetailsErrorCode(error?.response?.data?.code || 'General')
      if (axios.isAxiosError(error)) {
        setOrgDetailsError(error?.response?.data?.error)
      } else {
        setOrgDetailsError('unexpected error')
      }
    }
  }, [])

  const rejectOrgProfile = useCallback(
    async (orgId, setLoading, successCallback, errorCallback) => {
      try {
        const { data: response } = await axios.put(getRejectOrgApi(orgId))
        successCallback()
      } catch (error) {
        if (axios.isAxiosError(error)) {
          errorCallback(error)
        } else {
          errorCallback({ message: 'unexpected error' })
        }
      } finally {
        setLoading(false)
      }
    },
    []
  )

  return {
    createOrganization,
    fetchInstanceOrgDetails,
    instanceOrgDetails,
    instanceOrgError,
    orgDetailsError,
    orgDetailsErrorCode,
    rejectOrgProfile
  }
}

export default useCreateOrgApi
