import { useRouter } from 'next/router'
import React, { useEffect, useMemo, useState } from 'react'
import { Organization, OrganizationPayload } from '../types/Organization'
import * as Yup from 'yup'
import {
  ACCOUNT_ABSTRACTION_PROVIDERS,
  ACCOUNT_TYPES,
  ENTER_VALID_EMAIL,
  MAX_100_CHAR_ALLOWED,
  MAX_500_CHAR_ALLOWED,
  MAX_50_CHAR_ALLOWED,
  RADIO_BUTTON_OPTIONS,
  REQUIRED_FIELD,
  DEFAULT_ORG_FIELD_VALUES,
  STATE_CONSTANTS
} from '@constants/constants'
import OrgLogo from '@sharedComponents/OrgLogo'
import CustomDropDown from '@sharedComponents/Dropdown'
import useCreateOrgApi from './useCreateOrgApi'
import Toast from '@sharedComponents/Toast'
import HelperMessage from '../../../libs/sharedComponents/HelperMessage'

import styles from '../index.module.css'
import CommonRadioButton from '@sharedComponents/RadioButton'
import Modal from '@sharedComponents/Modal'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import Button from '@sharedComponents/Button'
import {
  DEFAULT_ERROR_MESSAGE,
  DEFAULT_TYPE,
  DISABLE,
  ENABLE,
  INSTANCE_ORG_TYPE,
  MODAL_TYPE,
  SIGNUP_ORG_REJECTED
} from '../constants'
import Message from '@sharedComponents/Message'
import { IconSize } from '@utils/constants'

const useSectionConfig = (instanceOrgDetails, state, orgId) => {
  const { createOrganization, rejectOrgProfile } = useCreateOrgApi()
  const router = useRouter()
  const [loading, setLoading] = useState<boolean>(false)
  const [rejectLoading, setRejectLoading] = useState<boolean>(false)
  const [isSSOModalOpen, setSSOModalOpen] = useState(false)
  const [isAbstractModalOpen, setAbstractModalOpen] = useState(false)
  const [isPaymasterModalOpen, setPaymasterModalOpen] = useState(false)
  const [hideSSO, setHideSSO] = useState(true)
  const [hideAbstract, setHideAbstract] = useState(true)
  const [orgType, setOrgType] = useState(DEFAULT_TYPE)
  useEffect(() => {
    if (instanceOrgDetails === null) {
      setOrgType(INSTANCE_ORG_TYPE)
      setHideSSO(false)
      setHideAbstract(false)
    }

    if (instanceOrgDetails && Object.keys(instanceOrgDetails).length > 0) {
      setHideSSO(instanceOrgDetails?.ssoEnabled === true)
      setHideAbstract(instanceOrgDetails?.enablePaymaster === true)
    }
  }, [instanceOrgDetails])

  const createOrgSuccessCallback = () => {
    Toast('success', 'New organization has been created.')
    router.back()
  }
  function closeModal(modalType) {
    if (modalType === MODAL_TYPE.ENABLE_SSO) {
      setSSOModalOpen(false)
    } else if (modalType === MODAL_TYPE.ENABLE_ABSTRACT) {
      setAbstractModalOpen(false)
    } else if (modalType === MODAL_TYPE.ENABLE_PAYMASTER) {
      setPaymasterModalOpen(false)
    }
  }
  function getModal(setFieldValue, modalType, value) {
    let title = ''
    let upperText = ''
    let lowertext = ''
    let isOpen = false
    const isInstanceOrg = orgType === INSTANCE_ORG_TYPE
    switch (modalType) {
      case MODAL_TYPE.ENABLE_SSO:
        if (value === ENABLE) {
          title = `Enable SSO configuration`
          upperText = isInstanceOrg
            ? `This will Enable SSO login for all organizations in this Instance.`
            : `Are you sure you want to enable the SSO configuration for the group?`
          lowertext = isInstanceOrg
            ? `Are you sure you want to allow all organizations to use SSO 
          Login?`
            : "The SSO configuration cannot be changed once group's profile is created."
        } else {
          title = `Disable SSO Login`
          upperText = isInstanceOrg
            ? `This will Disable SSO login for all organizations in this Instance.`
            : `Once SSO login is disabled it cannot be changed.`
          lowertext = isInstanceOrg
            ? `Are you sure you don’t want to allow all organizations to use 
          SSO Login?`
            : `Are you sure you don’t want to allow this organization to use 
          SSO Login?`
        }
        isOpen = isSSOModalOpen
        break

      case MODAL_TYPE.ENABLE_ABSTRACT:
        if (value === ENABLE) {
          title = `Enable group wallet`
          upperText = isInstanceOrg
            ? `This will Enable Abstract for all users in this organization`
            : `Are you sure you want to enable the group wallet for the group?`
          lowertext = isInstanceOrg
            ? `Are you sure you want to Enable Abstract?`
            : `The enable group wallet cannot be changed once group's profile is created.`
        } else {
          title = `Disable Abstract for Instance`
          upperText = isInstanceOrg
            ? `This will Disable Abstract for all organizations in this Instance`
            : 'Once Abstract is disabled it cannot be changed.'
          lowertext = isInstanceOrg
            ? `Are you sure you want to Disable Abstract?`
            : `Are you sure you don’t want to allow users in this 
              organization to have Abstract?`
        }
        isOpen = isAbstractModalOpen
        break
      case MODAL_TYPE.ENABLE_PAYMASTER:
        if (value === ENABLE) {
          title = `Enable Paymaster for Instance`
          upperText = `This will Enable Paymaster setup for all organizations in this 
          Instance`
          lowertext = `Are you sure you want to Enable Paymaster setup?`
        } else {
          title = `Disable Paymaster for Instance`
          upperText = `This will Disable Paymaster setup for all organizations in this 
          Instance`
          lowertext = `Are you sure you want to Disable Paymaster setup?`
        }
        isOpen = isPaymasterModalOpen
    }

    return (
      <Modal
        type={CUSTOM_TYPE}
        title={title}
        titleSize="h3"
        onToggleModal={() => {
          closeModal(modalType)
          setFieldValue(modalType, value === DISABLE ? ENABLE : DISABLE)
        }}
        isOpen={isOpen}
      >
        <div className={styles.modalContent}>
          {upperText}
          <div>{lowertext}</div>
        </div>
        <div className={styles.footer}>
          <Button
            className={`mt-1 ${styles.modalButton}`}
            onClick={() => closeModal(modalType)}
            color="primary"
            variant="contained"
            processingLoader={true}
          >
            Confirm
          </Button>
        </div>
      </Modal>
    )
  }

  const createOrgErrorCallback = (error, redirectOnError) => {
    Toast('error', error || DEFAULT_ERROR_MESSAGE)
    if (redirectOnError) {
      router.back()
    }
  }

  const initialValues: Partial<OrganizationPayload> = {
    companyName: '',
    description: '',
    businessNumber: '',
    businessEmailId: '',
    address: '',
    country: '',
    industry: '',
    website: '',
    contactEmail: '',
    logo: '',
    company_logo: '',
    enableSSO: RADIO_BUTTON_OPTIONS[0],
    enableAbstract: RADIO_BUTTON_OPTIONS[0],
    enablePaymaster: RADIO_BUTTON_OPTIONS[0]
  }

  const regMatch =
    /^(https?:\/\/)?([a-zA-Z0-9_-]+\.)*[a-zA-Z0-9_-]+\.[a-zA-Z]+(\/[a-zA-Z0-9]*)?$/

  const validationSchema: Yup.SchemaOf<Organization> = Yup.object().shape({
    logo: Yup.string(),
    company_logo: Yup.mixed(),
    companyName: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/.*[a-zA-Z0-9].*/, {
        message: 'Please enter correct Company Name.'
      })
      .max(100, MAX_100_CHAR_ALLOWED),
    description: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/.*[a-zA-Z0-9].*/, {
        message: 'Please enter correct Description.'
      })
      .max(500, MAX_500_CHAR_ALLOWED),
    businessNumber: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/^[a-zA-Z0-9_\s]*$/, {
        message: 'Please enter correct Business Number.'
      })
      .max(50, MAX_50_CHAR_ALLOWED),
    businessEmailId: Yup.string()
      .email(ENTER_VALID_EMAIL)
      .required(REQUIRED_FIELD),
    address: Yup.string()
      .trim()
      .matches(/.*[a-zA-Z0-9].*/, {
        message: 'Please enter correct Address.'
      })
      .max(500, MAX_500_CHAR_ALLOWED),
    country: Yup.string().required(REQUIRED_FIELD),
    industry: Yup.string(),
    website: Yup.string()
      .trim()
      .matches(regMatch, 'Please enter correct Website.')
      .max(500, MAX_500_CHAR_ALLOWED),
    contactEmail: Yup.string().email(ENTER_VALID_EMAIL).required(REQUIRED_FIELD)
  })

  const onCancel = () => {
    router.push('/org-list')
  }
  const formatPayload = (payload: OrganizationPayload): OrganizationPayload => {
    if (
      payload.enableAbstract === RADIO_BUTTON_OPTIONS[1] ||
      instanceOrgDetails?.enablePaymaster === true
    ) {
      payload.accountType = ACCOUNT_TYPES.AA
      // temporary hardcode the value for this, until we have the enhancement story to cover choose AA provider
      payload.accountAbstractionProvider = ACCOUNT_ABSTRACTION_PROVIDERS.ALCHEMY
    } else {
      payload.accountType = ACCOUNT_TYPES.EOA
    }

    if (payload.enableSSO === RADIO_BUTTON_OPTIONS[1]) {
      payload.enableSsoLogin = true
    } else {
      payload.enableSsoLogin = false
    }

    if (orgType === INSTANCE_ORG_TYPE) {
      if (payload.enablePaymaster === RADIO_BUTTON_OPTIONS[1]) {
        payload.enablePaymaster = true
      } else {
        payload.enablePaymaster = false
      }
    } else {
      if (hideSSO) {
        payload.enableSsoLogin = true
      }
      if (hideAbstract) {
        payload.accountType = ACCOUNT_TYPES.AA
      }
      delete payload.enablePaymaster
    }

    delete payload.enableSSO
    delete payload.enableAbstract

    return payload
  }

  const handleSubmit = async (
    values: Organization,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ): Promise<void> => {
    setLoading(true)
    let file
    if (values.company_logo && values.company_logo[0]) {
      file = values.company_logo[0]
    }
    const payload = { ...values }
    payload.address = payload.address || DEFAULT_ORG_FIELD_VALUES.ADDRESS
    payload.industry = payload.industry || DEFAULT_ORG_FIELD_VALUES.INDUSTRY
    payload.website = payload.website || 'https://www.example.com'
    payload.companyName = payload.companyName.trim()
    payload.businessNumber = payload.businessNumber.trim()
    delete payload.logo
    delete payload.company_logo
    const data = formatPayload(payload)
    if (orgId) {
      await createOrganization(
        data,
        createOrgSuccessCallback,
        createOrgErrorCallback,
        setFieldError,
        file,
        setLoading,
        orgId
      )
    } else {
      await createOrganization(
        data,
        createOrgSuccessCallback,
        createOrgErrorCallback,
        setFieldError,
        file,
        setLoading
      )
    }
  }
  const instanceOrgPending =
    state === STATE_CONSTANTS.PENDING && orgType === INSTANCE_ORG_TYPE // instance org is not setup and orgid is of pending org from org signup

  const rejectSuccessCallback = () => {
    Toast('success', SIGNUP_ORG_REJECTED)
    router.push('/org-list')
  }
  const rejectErrorCallback = (error) => {
    let errorMessage

    const additionalData = error.response?.data?.error?.additionalData
    if (additionalData && typeof additionalData === 'string') {
      errorMessage = additionalData
    } else {
      errorMessage = error.message
    }
    Toast('error', errorMessage || DEFAULT_ERROR_MESSAGE)
  }
  const sectionConfig = useMemo(() => {
    const generalSectionConfig = [
      {
        title: 'Logo',
        name: 'company_logo',
        type: 'custom',
        getComponent: (props) => {
          return <OrgLogo {...props} width={220} height={180} />
        }
      },
      {
        name: 'company_information',
        title: 'Information',
        type: 'form',
        fields: [
          {
            name: 'companyName',
            label: 'Name *',
            type: 'text',
            elementType: 'input',
            inputProps: { maxLength: 100 }
          },
          {
            name: 'description',
            label: 'Description *',
            type: 'text',
            elementType: 'input',
            isResizable: false,
            multiline: true,
            maxRows: 1,
            inputProps: { maxLength: 500 }
          },
          {
            name: 'businessNumber',
            label: 'Reference number *',
            type: 'text',
            elementType: 'input',
            inputProps: { maxLength: 50 }
          },
          {
            name: 'businessEmailId',
            label: 'Support email *',
            type: 'text',
            elementType: 'input'
          },
          {
            name: 'address',
            label: 'Address (optional)',
            type: 'text',
            elementType: 'input',
            inputProps: { maxLength: 500 }
          },
          {
            name: 'country',
            label: 'Country *',
            elementType: 'custom',
            getComponent: ({
              form,
              field,
              name,
              excludedValid,
              disabled,
              ...restProps
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return (
                <CustomDropDown
                  inputName={inputName}
                  optionCategory="FullCountry"
                  error={hasError}
                  isValid={!excludedValid && !!isValid}
                  disabled={disabled}
                  {...field}
                  {...restProps}
                />
              )
            }
          },
          {
            name: 'industry',
            label: 'Industry (optional)',
            elementType: 'custom',
            getComponent: ({
              field,
              form,
              name,
              excludedValid,
              disabled,
              ...restProps
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError

              return (
                <CustomDropDown
                  inputName={inputName}
                  optionCategory="Industry"
                  error={hasError}
                  isValid={!excludedValid && !!isValid}
                  disabled={disabled}
                  {...field}
                  {...restProps}
                />
              )
            }
          },
          {
            name: 'contactEmail',
            label: 'Group owner email *',
            type: 'text',
            elementType: 'input'
          }
        ]
      },
      {
        name: 'info',
        type: 'custom',
        independentComponent: true,
        getIndependentComponent: () => {
          let text = ''
          const showInfo = hideAbstract || hideSSO

          if (hideAbstract && !hideSSO) {
            text = `All users inside the organization have been Paymaster enabled.By default, all organization users will 
            use abstract in this instance.`
          } else if (!hideAbstract && hideSSO) {
            text = `All users inside the organization have been SSO login enabled by the Admin.`
          } else if (hideAbstract && hideSSO) {
            text = `All users inside the organization have been SSO login and Paymaster enabled. By default, all organization users will 
            use abstract in this instance.`
          }

          return (
            <Message
              type="info"
              texts={[text]}
              showIcon
              color="outline"
              className={`${styles.info} ${!showInfo && styles.infoHidden}`}
              iconSize={IconSize.Small}
            />
          )
        }
      },
      {
        hidden: hideSSO || instanceOrgPending,
        title:
          orgType === INSTANCE_ORG_TYPE
            ? 'SSO Login for Instance'
            : 'Enable SSO configuration',
        name: 'enableSSO',
        type: 'custom',
        getComponent: ({ field, name, setFieldValue, ...restProps }) => {
          const fieldName = name || field?.name
          return (
            <>
              <div className={styles.radioSection}>
                <CommonRadioButton
                  label={
                    orgType === INSTANCE_ORG_TYPE
                      ? `Enable SSO for all organizations in this instance.`
                      : 'All group users will use SSO configuration to login.'
                  }
                  name={fieldName}
                  options={RADIO_BUTTON_OPTIONS}
                  optionType={'enableDisableOptions'}
                  multipleLineDesc={false}
                  defaultValue={RADIO_BUTTON_OPTIONS[0]}
                  {...restProps}
                  className={styles.radioGroup}
                  {...field}
                  onChange={(event) => {
                    field.onChange(event)
                    setSSOModalOpen(true)
                  }}
                />
              </div>
              {getModal(setFieldValue, fieldName, field.value)}
            </>
          )
        }
      },
      {
        hidden: !(orgType === INSTANCE_ORG_TYPE) || instanceOrgPending,
        title: `Paymaster for Instance`,
        name: 'enablePaymaster',
        type: 'custom',
        getComponent: ({ field, name, setFieldValue, ...restProps }) => {
          const fieldName = name || field?.name
          return (
            <>
              <div className={styles.radioSection}>
                <CommonRadioButton
                  label={'All users will use the paymaster of this instance.'}
                  name={fieldName}
                  options={RADIO_BUTTON_OPTIONS}
                  optionType={'enableDisableOptions'}
                  multipleLineDesc={false}
                  defaultValue={RADIO_BUTTON_OPTIONS[0]}
                  {...restProps}
                  className={styles.radioGroup}
                  {...field}
                  onChange={(event) => {
                    field.onChange(event)
                    setPaymasterModalOpen(true)
                  }}
                />
              </div>
              {getModal(setFieldValue, fieldName, field.value)}
            </>
          )
        }
      },
      {
        hidden: hideAbstract || instanceOrgPending,
        title: 'Enable Group wallet',
        name: 'enableAbstract',
        type: 'custom',
        getComponent: ({ field, name, setFieldValue, ...restProps }) => {
          const fieldName = name || field?.name

          return (
            <>
              <div className={styles.radioSection}>
                <CommonRadioButton
                  label={
                    'All group users will be using a group wallet for transactions.'
                  }
                  name={fieldName}
                  options={RADIO_BUTTON_OPTIONS}
                  optionType={'enableDisableOptions'}
                  multipleLineDesc={false}
                  defaultValue={RADIO_BUTTON_OPTIONS[0]}
                  {...restProps}
                  className={styles.radioGroup}
                  {...field}
                  onChange={(event) => {
                    field.onChange(event)
                    setAbstractModalOpen(true)
                  }}
                />
              </div>
              {getModal(setFieldValue, fieldName, field.value)}
            </>
          )
        }
      },
      {
        name: 'info',
        type: 'custom',
        independentComponent: true,
        getIndependentComponent: () => {
          let text = ''
          const showInfo = instanceOrgPending
          text = `Instance organization is not set up, cannot create new organization.`

          return (
            <Message
              type="info"
              texts={[text]}
              showIcon
              color="outline"
              className={`${styles.info} ${!showInfo && styles.infoHidden}`}
              iconSize={IconSize.Small}
            />
          )
        }
      },
      {
        name: 'submit_button',
        type: 'button',
        label: 'Add & Submit',
        leftButtons: [
          {
            name: 'Cancel',
            color: 'secondary',
            variant: 'outlined',
            disableRipple: true,
            onClick: onCancel
          },
          {
            name: 'Reset',
            'data-action': 'back',
            color: 'secondary',
            variant: 'text',
            disable: (formik) => {
              const { values, dirty } = formik
              const hasLogo = !!values.company_logo
              const otherFieldsNotEmpty = Object.keys(values)
                .filter((field) => field !== 'company_logo')
                .some((field) => values[field] !== initialValues[field])

              return (hasLogo && !otherFieldsNotEmpty) || !formik.dirty
            }
          }
        ],
        rightButtons: [
          {
            name:
              orgType === INSTANCE_ORG_TYPE && !instanceOrgPending
                ? 'Create Instance Organization'
                : 'Create & Invite',
            variant: 'contained',
            color: 'primary',
            type: 'submit',
            processingLoader: true,
            disable: ({ touched, isValid }) =>
              !(touched?.companyName && isValid) || instanceOrgPending,
            loading
          }
        ]
      }
    ]

    if (state === STATE_CONSTANTS.PENDING && orgId) {
      const rejectButton = {
        name: 'Reject',
        variant: 'outlined',
        color: 'error',
        processingLoader: true,
        onClick: async () => {
          setRejectLoading(true)
          await rejectOrgProfile(
            orgId,
            setRejectLoading,
            rejectSuccessCallback,
            rejectErrorCallback
          )
        },
        disable: () => false,
        loading: rejectLoading,
        type: ''
      }
      generalSectionConfig[
        generalSectionConfig.length - 1
      ].rightButtons.unshift(rejectButton)
    }

    return generalSectionConfig
  }, [
    isSSOModalOpen,
    isAbstractModalOpen,
    isPaymasterModalOpen,
    hideSSO,
    hideAbstract,
    orgType,
    loading,
    rejectLoading,
    state
  ])

  return {
    sectionConfig,
    handleSubmit,
    initialValues,
    validationSchema,
    getModal,
    loading
  }
}

export default useSectionConfig
