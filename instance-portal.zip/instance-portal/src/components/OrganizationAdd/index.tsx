import React, { useEffect } from 'react'
import styles from './index.module.css'
import useSectionConfig from './hooks/useSectionConfig'
import { PERMISSION_ADMIN } from '@constants/permissionConstants'
import SectionForm from '@sharedComponents/SectionForm'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import useCreateOrgApi from './hooks/useCreateOrgApi'
import { useAuthorize } from '@core/context/Authorize'
import Loader from '@sharedComponents/Loader'
import useOrgProfileApi from '../OrganizationDetails/hooks/useOrgProfileApi'
import Info from '@images/info.svg'
import HelperMessage from '@sharedComponents/HelperMessage'

import { STATE_CONSTANTS } from '@constants/constants'
import Warning from '../WarningMessage'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'

const CreateOrganization = ({ orgId }: { orgId?: string }) => {
  const { fetchInstanceOrgDetails, instanceOrgDetails, instanceOrgError } =
    useCreateOrgApi()

  const { isLogin } = useAuthorize()

  const { orgProfileData, fetchOrgProfile } = useOrgProfileApi()

  useEffect(() => {
    if (isLogin && orgId) {
      fetchOrgProfile(orgId)
    }
  }, [fetchOrgProfile, orgId, isLogin])

  useEffect(() => {
    if (isLogin) {
      fetchInstanceOrgDetails()
    }
  }, [isLogin])

  const {
    sectionConfig,
    initialValues,
    validationSchema,
    handleSubmit,
    loading
  } = useSectionConfig(instanceOrgDetails, orgProfileData?.state, orgId)

  if (orgId && !orgProfileData) {
    return null
  }
  if (orgId && orgProfileData.state !== STATE_CONSTANTS.PENDING) {
    return (
      <Warning
        message={'Only Pending State is allowed'}
        header={'No record found'}
        icon={'not-found'}
        state={CustomIconicCardState.Warning}
      />
    )
  }
  let initialComapnyInfo

  if (
    orgId &&
    orgProfileData &&
    orgProfileData.state === STATE_CONSTANTS.PENDING
  ) {
    const {
      name,
      brNumber,
      email,
      address,
      country,
      industry,
      website,
      instanceRepresentativeId,
      remark
    } = orgProfileData

    initialComapnyInfo = {
      companyName: name,
      description: remark,
      businessNumber: brNumber,
      businessEmailId: email,
      address,
      country,
      industry,
      website,
      contactEmail: instanceRepresentativeId
    }
  }

  function renderOrgData() {
    if (instanceOrgError) {
      return <div>Unable to fetch instance org details</div>
    }
    return (
      <>
        <section className={styles.grid}>
          <div className={styles.topBar}>
            <h3 className="bold">Create new group</h3>
          </div>
        </section>
        <HelperMessage
          message={`An invitation email will be sent to the primary admin once the group
            is created.`}
          isInfo
        />
        <SectionForm
          sectionConfig={sectionConfig}
          initialValues={initialComapnyInfo || initialValues}
          validationSchema={validationSchema}
          handleSubmit={handleSubmit}
          {...(initialComapnyInfo && { initialTouch: true })}
        />
      </>
    )
  }

  return <PrivateRoute>{renderOrgData()}</PrivateRoute>
}

export default CreateOrganization
