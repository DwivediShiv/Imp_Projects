export const MODAL_TYPE = {
  ENABLE_SSO: 'enableSSO',
  ENABLE_ABSTRACT: 'enableAbstract',
  ENABLE_PAYMASTER: 'enablePaymaster'
}

export const DEFAULT_ERROR_MESSAGE = `Unable to save changes. Please try again later.`
export const SIGNUP_ORG_REJECTED = `Signup organization has been rejected.`
export const INSTANCE_ORG_TYPE = `instanceOrg`
export const DEFAULT_TYPE = `default`
export const DISABLE = `disable`
export const ENABLE = `enable`
export const ERROR_FIELDS = ['companyName', 'businessNumber']
