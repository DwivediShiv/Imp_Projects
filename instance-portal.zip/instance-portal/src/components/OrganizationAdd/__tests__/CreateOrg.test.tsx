import React from 'react'
import { fireEvent, render, screen, within } from '@testing-library/react'
import CreateOrganization from '..'
import { useAuthorize, AuthorizeProviderValue } from '@core/context/Authorize'

const mockRouterBack = jest.fn()

interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack
  })
}))

jest.mock('@core/context/FancyState', () => ({
  useFancyState: () => ({
    getSelectionOptionsByCategory: (optionCategory) => {
      if (optionCategory === 'Country') {
        return [
          {
            id: 31,
            name: 'Austria',
            key: 'AT',
            category: 'Country',
            sortOrder: 1,
            updatedAt: '2023-07-16T16:37:20.891966Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 32,
            name: 'Belgium',
            key: 'BE',
            category: 'Country',
            sortOrder: 2,
            updatedAt: '2023-07-16T16:37:20.891966Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 33,
            name: 'Bulgaria',
            key: 'BG',
            category: 'Country',
            sortOrder: 3,
            updatedAt: '2023-07-16T16:37:20.891966Z',
            updatedBy: 'ACENTRIK'
          }
        ]
      } else if (optionCategory === 'Industry') {
        return [
          {
            id: 1,
            name: 'Aerospace',
            key: 'aerospace',
            category: 'Industry',
            sortOrder: 1,
            updatedAt: '2023-07-16T16:37:20.83741Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 2,
            name: 'Agriculture',
            key: 'agriculture',
            category: 'Industry',
            sortOrder: 2,
            updatedAt: '2023-07-16T16:37:20.83741Z',
            updatedBy: 'ACENTRIK'
          },
          {
            id: 62,
            name: 'Automotive',
            key: 'automotive',
            category: 'Industry',
            sortOrder: 3,
            updatedAt: '2023-07-16T16:37:21.048874Z',
            updatedBy: 'ACENTRIK'
          }
        ]
      }
    }
  })
}))

jest.mock('@core/context/Authorize')

const renderComponent = (options: RenderOptions) => {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin
  })

  render(<CreateOrganization />)
}

describe('Should render Create Organization Form', () => {
  it('login component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isLogin: false
      }
    })
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('render create org', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(
      await screen.findByRole('heading', {
        name: /create new group/i
      })
    ).toBeInTheDocument()
  })

  it('render create org field section', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    const companyName = await screen.findByRole('textbox', {
      name: /name \*/i
    })
    const description = await screen.findByRole('textbox', {
      name: /description \*/i
    })
    const businessNumber = await screen.findByRole('textbox', {
      name: /reference number \*/i
    })
    const businessEmailId = await screen.findByRole('textbox', {
      name: /support email \*/i
    })
    const address = await screen.findByRole('textbox', {
      name: /address \(optional\)/i
    })
    const contactEmail = await screen.findByRole('textbox', {
      name: /group owner email \*/i
    })
    expect(companyName).toBeInTheDocument()
    expect(companyName).toHaveValue('')
    expect(description).toBeInTheDocument()
    expect(description).toHaveValue('')
    expect(businessNumber).toBeInTheDocument()
    expect(businessNumber).toHaveValue('')
    expect(businessEmailId).toBeInTheDocument()
    expect(businessEmailId).toHaveValue('')
    expect(address).toBeInTheDocument()
    expect(address).toHaveValue('')
    expect(contactEmail).toBeInTheDocument()
    expect(contactEmail).toHaveValue('')
  })
  it('renders SSO section', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })

    expect(
      await screen.findByText(
        /all group users will use SSO configuration to login\./i
      )
    ).toBeInTheDocument()

    const radiogroup = await screen.findByRole('radiogroup', {
      name: /enableSSO/i
    })
    expect(radiogroup).toBeInTheDocument()
    await within(radiogroup).findByRole('radio', {
      name: /enable/i
    })
    await within(radiogroup).findByRole('radio', {
      name: /disable/i
    })
  })
  it('renders Abstract section', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })

    expect(
      await screen.findByText(
        /all group users will be using a group wallet for transactions\./i
      )
    ).toBeInTheDocument()

    const radiogroup = await screen.findByRole('radiogroup', {
      name: /enableAbstract/i
    })

    expect(radiogroup).toBeInTheDocument()
    await within(radiogroup).findByRole('radio', {
      name: /enable/i
    })
    await within(radiogroup).findByRole('radio', {
      name: /disable/i
    })
  })
  it('test create org', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    const companyName = await screen.findByRole('textbox', {
      name: /name \*/i
    })
    const description = await screen.findByRole('textbox', {
      name: /description \*/i
    })
    const businessNumber = await screen.findByRole('textbox', {
      name: /reference number \*/i
    })
    const businessEmailId = await screen.findByRole('textbox', {
      name: /support email \*/i
    })
    const address = await screen.findByRole('textbox', {
      name: /address \(optional\)/i
    })
    const contactEmail = await screen.findByRole('textbox', {
      name: /group owner email \*/i
    })
    fireEvent.change(companyName, { target: { value: 'Test 29' } })
    fireEvent.change(description, { target: { value: 'Test description' } })
    fireEvent.change(businessNumber, { target: { value: '1234' } })
    fireEvent.change(businessEmailId, { target: { value: 'test@gmail.com' } })
    fireEvent.change(address, { target: { value: 'test address' } })
    fireEvent.change(contactEmail, { target: { value: 'test1@gmail.com' } })
    const createBtn = await screen.findByRole('button', {
      name: /create & invite/i
    })
    expect(createBtn).toBeDisabled()
    const country = screen.getByText('Country *')
    country.textContent = 'Austria'
    const industry = screen.getByText('Industry (optional)')
    industry.textContent = 'Aerospace'
    const radiogroupSSO = await screen.findByRole('radiogroup', {
      name: /enableSSO/i
    })
    expect(radiogroupSSO).toBeInTheDocument()
    const disableSSO = await within(radiogroupSSO).findByRole('radio', {
      name: /disable/i
    })
    fireEvent.click(disableSSO)
    const radiogroupPayMaster = screen.getByRole('radiogroup', {
      name: /enablepaymaster/i
    })
    const disablePayMaster = await within(radiogroupPayMaster).findByRole(
      'radio',
      {
        name: /disable/i
      }
    )
    fireEvent.click(disablePayMaster)
    expect(createBtn).toBeDisabled()
  })
})
