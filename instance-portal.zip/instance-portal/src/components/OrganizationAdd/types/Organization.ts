export interface Organization {
  companyName: string
  description: string
  businessNumber: string
  businessEmailId: string
  address?: string
  country: string
  industry?: string
  website: string
  contactEmail: string
  company_logo?: any
  logo?: string
}
export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

export interface OrganizationLogo {
  logo: string
}

export interface OrganizationPayload extends Organization {
  enableAbstract?: string
  accountType?: string
  enableSSO?: string
  enableSsoLogin?: boolean
  enablePaymaster?: string | boolean
  accountAbstractionProvider?: string
}
export interface InstanceOrgDetails {
  name?: string
  accountType?: string
  ssoEnabled?: boolean
  ssoConfigured?: boolean
  enablePaymaster?: boolean
  socialDetails?: object
}
