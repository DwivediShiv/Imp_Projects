import { getNetworkDisplayName } from '../utils/getNetworkDisplayName'

describe('getNetworkDisplayName', () => {
  it('should return "mainnet" for networkId 137', () => {
    expect(getNetworkDisplayName(137)).toBe('mainnet')
  })

  it('should return "Moonbase Alpha" for networkId 1287', () => {
    expect(getNetworkDisplayName(1287)).toBe('Moonbase Alpha')
  })

  it('should return "Moonriver" for networkId 1285', () => {
    expect(getNetworkDisplayName(1285)).toBe('Moonriver')
  })

  it('should return "rinkeby" for networkId 4', () => {
    expect(getNetworkDisplayName(4)).toBe('rinkeby')
  })

  it('should return "sepolia" for networkId 11155111', () => {
    expect(getNetworkDisplayName(11155111)).toBe('sepolia')
  })

  it('should return "goerli" for networkId 5', () => {
    expect(getNetworkDisplayName(5)).toBe('goerli')
  })

  it('should return "amoy" for networkId 80002', () => {
    expect(getNetworkDisplayName(80002)).toBe('amoy')
  })

  it('should return "supernet" for networkId 81001', () => {
    expect(getNetworkDisplayName(81001)).toBe('supernet')
  })

  it('should return "ETH Ropsten" for networkId 3', () => {
    expect(getNetworkDisplayName(3)).toBe('ETH Ropsten')
  })

  it('should return "development" for networkId 8996', () => {
    expect(getNetworkDisplayName(8996)).toBe('development')
  })

  it('should return "GAIA-X Testnet" for networkId 2021000', () => {
    expect(getNetworkDisplayName(2021000)).toBe('GAIA-X Testnet')
  })

  it('should return "Gen-X Testnet" for networkId 100', () => {
    expect(getNetworkDisplayName(100)).toBe('Gen-X Testnet')
  })

  it('should return "Unknown" for no networkId passed', () => {
    expect(getNetworkDisplayName()).toBe('Unknown')
  })

  it('should return "Unknown" for unknown networkId', () => {
    expect(getNetworkDisplayName()).toBe('Unknown')
    expect(getNetworkDisplayName(123)).toBe('Unknown')
  })
})
