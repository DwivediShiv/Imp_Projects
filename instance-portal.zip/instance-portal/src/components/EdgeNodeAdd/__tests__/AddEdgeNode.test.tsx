import React from 'react'
import { render, screen } from '@testing-library/react'
import * as Yup from 'yup'
import AddEdgeNode from '..'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'

jest.mock('next/router', () => ({
  useRouter: jest.fn()
}))
jest.mock('@core/context/Authorize')

const renderComponent = (options: RenderOptions) => {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin
  })

  render(<AddEdgeNode />)
}
const validationSchema = Yup.object().shape({
  edge_node_name: Yup.string()
    .trim()
    .required('Required Field.')
    .max(100, 'Edge Node Name is too long, maximum length is 100 characters')
    .matches(
      /^[a-zA-Z0-9\s]*$/,
      'Edge Node Name can only contain alphanumeric characters and spaces'
    ),

  edge_node_url: Yup.string()
    .trim()
    .required('Required Field.')
    .max(100, 'URL is too long, maximum length is 100 characters')
    .url('URL entered is not valid!')
})

interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

describe('AddEdgeNode ', () => {
  it('Login component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isLogin: false
      }
    })
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })
  it('Render add edge node form if authorized', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(
      await screen.findByRole('heading', {
        name: /information/i
      })
    ).toBeInTheDocument()
  })
  it('Only Instance Admin Can Create Public Edge Nodes', async () => {
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: false
      }
    })

    const submitButton = await screen.findByRole('button', {
      name: /create & submit/i
    })
    expect(submitButton).toBeDisabled()
  })
  it('Render add edge node field section if authorized', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    const url = await screen.findByRole('textbox', {
      name: /url \*/i
    })
    const name = await screen.findByRole('textbox', {
      name: /name \*/i
    })
    const network = await screen.findByRole('textbox', {
      name: /blockchain network/i
    })

    const address = await screen.findByRole('textbox', {
      name: /address/i
    })
    const version = await screen.findByRole('textbox', {
      name: /version/i
    })

    expect(name).toBeInTheDocument()
    expect(name).toHaveValue('')
    expect(url).toBeInTheDocument()
    expect(url).toHaveValue('')
    expect(network).toBeInTheDocument()
    expect(network).toHaveValue('')
    expect(version).toBeInTheDocument()
    expect(version).toHaveValue('')
    expect(address).toBeInTheDocument()
    expect(address).toHaveValue('')
  })
})

describe('Yup validation for Add Edge Node', () => {
  it('check yup validations , incorrect values will give error', async () => {
    const values = {
      edge_node_name: '',
      edge_node_url: 'http'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toBe(false)
  })

  it('check yup validations on the form correct values no error', async () => {
    const values = {
      edge_node_name: 'edge node name',
      edge_node_url: 'https://v1.provider.amoy.nagarro.acentrik.io/'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toEqual(true)
  })
})
