import React from 'react'
import SectionForm from '@sharedComponents/SectionForm'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import BackIcon from '@images/back_icon.svg'
import { useRouter } from 'next/router'
import styles from './index.module.css'
import InfoIcon from '@images/icon_information.svg'
import Button from '@sharedComponents/Button'
import useSectionConfig from './hooks/useSectionConfig'
import { PERMISSION_ADMIN } from '@constants/permissionConstants'

const AddEdgeNode = () => {
  const router = useRouter()
  const { sectionConfig, initialValues, validationSchema, handleSubmit } =
    useSectionConfig()

  function handleGoBack() {
    router.back()
  }
  return (
    <PrivateRoute>
      <>
        <Button onClick={handleGoBack} aria-label="Go Back">
          <BackIcon />
        </Button>
        <h3 className="bold">Create edge node</h3>
        <span className={styles.iconMessageContainer}>
          <InfoIcon className={`${styles.infoIcon}`} />
          &nbsp;By default, the Instance edge node created will be public.
        </span>

        <SectionForm
          sectionConfig={sectionConfig}
          initialValues={initialValues}
          validationSchema={validationSchema}
          handleSubmit={handleSubmit}
          values={undefined}
        />
      </>
    </PrivateRoute>
  )
}

export default AddEdgeNode
