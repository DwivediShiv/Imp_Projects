export function getNetworkDisplayName(networkId?: number): string {
  let displayName

  switch (networkId) {
    case 137:
      displayName = 'mainnet'
      break
    case 1287:
      displayName = 'Moonbase Alpha'
      break
    case 1285:
      displayName = 'Moonriver'
      break
    case 4:
      displayName = 'rinkeby'
      break
    case 5:
      displayName = 'goerli'
      break
    case 11155111:
      displayName = 'sepolia'
      break
    case 81001:
      displayName = 'supernet'
      break
    case 8996:
      displayName = 'development'
      break
    case 3:
      displayName = 'ETH Ropsten'
      break
    case 2021000:
      displayName = 'GAIA-X Testnet'
      break
    case 100:
      displayName = 'Gen-X Testnet'
      break
    case 80002:
      displayName = 'amoy'
      break
    default:
      displayName = 'Unknown'
      break
  }

  return displayName
}

export function getNetworkDisplayNames(networkIds: number[]): string {
  return networkIds.reduce((acc: string, networkId) => {
    const networkName = getNetworkDisplayName(networkId)
      ? getNetworkDisplayName(networkId)
      : ''
    return acc.length === 0 ? networkName : `${acc},${networkName}`
  }, '')
}
