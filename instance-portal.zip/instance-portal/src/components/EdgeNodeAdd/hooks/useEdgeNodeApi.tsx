import { USER_MESSAGES } from '@constants/modalConstant'
import { ERROR_UNAUTH } from '@constants/permissionConstants'
import Toast from '@sharedComponents/Toast'
import appConfig from 'app.config'
import axios from 'axios'
import { useCallback } from 'react'

const useEdgeNodeApi = () => {
  const addEdgeNodeUrl = `${appConfig.api}/provider-management/api/v1/edge-node `
  const addEdgeNode = useCallback(
    async (
      edgeNodeData: {
        name: string
        network: string
        url: string
        version: string
        address: string
      },
      successCallback: () => void,
      errorCallback: (error: string) => void
    ) => {
      try {
        const { data: response } = await axios.post(
          addEdgeNodeUrl,
          edgeNodeData
        )
        successCallback()
        return response
      } catch (error) {
        if (error.response && error.response.data?.code === ERROR_UNAUTH) {
          Toast('error', USER_MESSAGES.ERROR_UNAUTH_CREATE_NODE)
          return
        } else if (axios.isAxiosError(error)) {
          errorCallback(
            error?.response?.data?.error?.additionalData ||
              error?.response?.data?.error?.message
          )
        }
        errorCallback('Unexpected error ocurred')
      }
    },
    []
  )

  return {
    addEdgeNode
  }
}

export default useEdgeNodeApi
