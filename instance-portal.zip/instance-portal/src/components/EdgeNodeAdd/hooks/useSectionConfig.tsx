import * as Yup from 'yup'
import {
  EdgeNodeDetailsForm,
  EdgeNodeDetailsInput
} from '../types/EdgeNodeDetails'
import { FormikErrors } from 'formik'
import useEdgeNodeApi from './useEdgeNodeApi'
import useEdgeNodeProfileApi from '../../EdgeNodeProfile/hooks/useEdgeNodeApi'
import { useRouter } from 'next/router'
import Toast from '@sharedComponents/Toast'
import { ADD_EDGE_NODE_CONSTANTS } from '../../../libs/constants/modalConstant'
import {
  INVALID_PROVIDER_URL,
  INVALID_URL_REGEX,
  REQUIRED_EDGE_NODE_FIELD
} from '../../../components/EdgeNodeProfile/constants'
import {
  errorBlurHandler,
  successBlurHandler
} from '../../../components/EdgeNodeProfile/hooks/useCardConfig'
import { addC2dOperator } from '@utils/auth'
import { debounce } from 'lodash'

const useSectionConfig = () => {
  const router = useRouter()
  const { fetchUrlData, validateUrlData } = useEdgeNodeProfileApi()

  function onCancel() {
    router.back()
  }

  const { addEdgeNode } = useEdgeNodeApi()
  const addEdgeNodeSuccessCallback = () => {
    Toast('success', ADD_EDGE_NODE_CONSTANTS.SUCCESS)
    router.push('/manage-edge-nodes')
  }

  const addEdgeNodeErrorCallback = (error) => {
    Toast('error', error)
  }

  const handleSubmit = async (values, resetForm, setFieldError) => {
    try {
      const response = await addEdgeNode(
        {
          name: values.edge_node_name.trim(),
          network: values.edge_node_network,
          url: values.edge_node_url,
          address: values.edge_node_address,
          version: values.edge_node_version
        },
        async () => {
          await addC2dOperator(values.edge_node_url, values.edge_node_network)
          resetForm()
          addEdgeNodeSuccessCallback()
        },
        (error) => {
          throw error
        }
      )
      resetForm()
    } catch (error) {
      addEdgeNodeErrorCallback(error)
    }
  }

  const initialValues = {
    edge_node_name: '',
    edge_node_url: '',
    edge_node_address: '',
    edge_node_network: '',
    edge_node_version: ''
  }

  const validationSchema: Yup.SchemaOf<EdgeNodeDetailsInput> =
    Yup.object().shape({
      edge_node_name: Yup.string()
        .trim()
        .required(REQUIRED_EDGE_NODE_FIELD)
        .max(
          100,
          'Edge Node Name is too long, maximum length is 100 characters'
        )
        .matches(
          /^[a-zA-Z0-9\s]*$/,
          'Edge Node Name can only contain alphanumeric characters and spaces'
        ),

      edge_node_url: Yup.string()
        .trim()
        .required(REQUIRED_EDGE_NODE_FIELD)
        .max(100, 'URL is too long, maximum length is 100 characters')
        .url(INVALID_URL_REGEX)
        .test(
          'Edge node url validity',
          INVALID_PROVIDER_URL,
          debounce(async (edgeNodeUrl) => {
            try {
              await validateUrlData(edgeNodeUrl)
              return true
            } catch (error) {
              return false
            }
          }, 1000)
        )
    })

  const sectionConfig = [
    {
      name: 'edge_node',
      title: 'Information',
      type: 'form',
      fields: [
        {
          name: 'edge_node_name',
          label: 'Name *',
          type: 'text'
        },
        {
          name: 'edge_node_url',
          label: 'URL *',
          type: 'text',
          elementType: 'custom_input_field',
          onBlurHandler: async (
            e: React.FocusEvent<any>,
            handleBlur: (e: React.FocusEvent<any>) => void,
            setFieldValue: (field: string, errorMsg: string) => void,
            errors: FormikErrors<EdgeNodeDetailsForm>,
            dirty: boolean,
            values: EdgeNodeDetailsForm,
            setFieldError: (field: string, errorMsg: string) => void
          ) => {
            handleBlur(e)

            if (
              dirty &&
              !(
                errors?.edge_node_url === INVALID_URL_REGEX ||
                errors?.edge_node_url === REQUIRED_EDGE_NODE_FIELD
              )
            ) {
              setFieldValue('edge_node_url', values.edge_node_url.trim())
              setFieldValue('edge_node_address', '')
              setFieldValue('edge_node_version', '')
              setFieldValue('edge_node_network', '')
              await fetchUrlData(
                values.edge_node_url,
                setFieldValue,
                setFieldError,
                successBlurHandler,
                errorBlurHandler
              )
            }
          }
        },

        {
          name: 'edge_node_network',
          label: 'Blockchain network',
          type: 'text',
          disabled: true
        },
        {
          name: 'edge_node_address',
          label: 'Address',
          type: 'text',
          disabled: true
        },
        {
          name: 'edge_node_version',
          label: 'Version',
          type: 'text',
          disabled: true,
          value: 'ok'
        }
      ]
    },
    {
      name: 'submit_button',
      type: 'button',
      label: 'Add & Submit',
      leftButtons: [
        {
          name: 'Cancel',
          color: 'secondary',
          variant: 'outlined',
          disableRipple: true,
          onClick: onCancel
        },
        {
          name: 'Reset',
          'data-action': 'back',
          color: 'secondary',
          variant: 'text',
          disable: ({ dirty }) => !dirty
        }
      ],
      rightButtons: [
        {
          name: 'Create & Submit',
          variant: 'contained',
          color: 'primary',
          type: 'submit',
          processingLoader: true,
          disable: ({ isValid, dirty, values }) =>
            !isValid || !dirty || !values.edge_node_network
          // ||
          // !values.edge_node_version
          // TODO: DISABLE BUTTON IF ADDRESS IS EMPTY
          // || !values.edge_node_address
        }
      ]
    }
  ]

  return { sectionConfig, handleSubmit, initialValues, validationSchema }
}

export default useSectionConfig
