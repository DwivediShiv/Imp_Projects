export interface EdgeNodeUrlResponse {
  providerAddress: string
  version: string
  chainId: number
}

export interface EdgeNodeDetailsForm {
  edge_node_name: string
  edge_node_url: string
  edge_node_address: string
  edge_node_network: string
  edge_node_version: string
}

export interface EdgeNodeDetailsInput {
  edge_node_name: string
  edge_node_url: string
}
