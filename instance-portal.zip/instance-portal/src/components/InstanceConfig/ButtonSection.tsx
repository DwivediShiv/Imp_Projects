import React, { useEffect } from 'react'
import styles from './StepperForm.module.css'
import { Grid } from '@mui/material'
import Button from '@sharedComponents/Button'
import useTransformer from './hooks/useTransformer'

const ButtonSection = ({
  values,
  errors,
  handleCancel,
  handleSaveDraft,
  handleNext,
  activeStep,
  steps,
  configKeys,
  secretKeys,
  setConfigErrors,
  setSecretErrors,
  dirty,
  setIsEdited
}) => {
  const { transformFieldName } = useTransformer()
  useEffect(() => {
    const configFields = configKeys.map((field) => transformFieldName(field))
    const secretFields = secretKeys.map((field) => transformFieldName(field))
    let configErrObj = {}
    let secretErrObj = {}
    Object.keys(errors)?.forEach((error) => {
      if (configFields?.includes(error)) {
        configErrObj = { ...configErrObj, [error]: errors[error] }
      } else if (secretFields?.includes(error)) {
        secretErrObj = { ...secretErrObj, [error]: errors[error] }
      }
    })
    setConfigErrors(configErrObj)
    setSecretErrors(secretErrObj)
  }, [errors])

  useEffect(() => {
    setIsEdited(dirty)
  }, [dirty])

  return (
    <div className={styles.buttonWrapper}>
      <Grid
        container
        className={styles.container}
        justifyContent="space-between"
      >
        <Grid item>
          <Button color="secondary" variant="text" onClick={handleCancel}>
            Cancel
          </Button>
        </Grid>
        <Grid item>
          <Button
            color="secondary"
            variant="text"
            onClick={() => handleSaveDraft(values)}
          >
            Save Draft
          </Button>

          {
            <Button
              variant="contained"
              color="primary"
              disabled={activeStep === 3 && Object.keys(errors).length}
              processingLoader={true}
              {...(activeStep === 3
                ? { type: 'submit' }
                : { onClick: () => handleNext(values, errors) })}
            >
              {activeStep < 3
                ? `Next Step: ${steps[activeStep + 1].label}`
                : 'Deploy Instance'}
            </Button>
          }
        </Grid>
      </Grid>
    </div>
  )
}

export default ButtonSection
