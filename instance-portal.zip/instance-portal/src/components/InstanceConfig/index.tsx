import React, { useEffect, useState } from 'react'
import StepperForm from './StepperForm'
import useInstanceConfig from './hooks/useInstanceConfig'
import styles from './index.module.css'
import CustomDropDown from '@sharedComponents/Dropdown'
import CustomTooltip from '@sharedComponents/Tooltip'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import { PERMISSION_ADMIN } from '@constants/permissionConstants'
import useInstanceConfigApi from './hooks/useInstanceConfigApi'
import appConfig from 'app.config'
import Modal from '@sharedComponents/Modal'
import { CUSTOM_TYPE, ICON_TYPE } from '@constants/modalConstant'
import Button from '@sharedComponents/Button'
import {
  REDEPLOY_TITLE,
  SAVE_TITLE,
  VERSION_CHANGE_CONFIRMATION
} from '@constants/constants'
import { useAuthorize } from '@core/context/Authorize'
import Loader from '@sharedComponents/Loader'

const InstanceConfig = () => {
  const { isLogin } = useAuthorize()
  const [activeStep, setActiveStep] = useState(0)
  const [previewData, setPreviewData] = useState([])
  const [isEdited, setIsEdited] = useState(false)
  const {
    fetchVersionList,
    versionList,
    fetchReleaseNotes,
    releaseNotes,
    fetchFormBuilder,
    formBuilder,
    fetchConfigJson,
    configJson,
    fetchSecretJson,
    secretJson,
    fetchJsonLoader
  } = useInstanceConfigApi()

  const [version, setVersion] = useState('')
  const [confirmVersion, setConfirmVersion] = useState('')

  const handleCancel = () => {
    setVersion('')
    setIsEdited(false)
    setConfirmVersion('')
    setActiveStep(0)
  }

  const {
    handleSubmit,
    handleSaveDraft,
    steps,
    validationSchema,
    initialValues,
    configPreview,
    secretPreview,
    setterConfig,
    modalOpen,
    setModalOpen,
    handleConfirm,
    configKeys,
    secretKeys,
    confirmLoader
  } = useInstanceConfig({
    activeStep,
    formBuilder,
    secretJson,
    configJson,
    releaseNotes,
    version,
    handleCancel,
    setIsEdited
  })

  const handleVersionChange = (e) => {
    setConfirmVersion(e.target.value)
    if (version && isEdited) {
      setModalOpen({
        title: SAVE_TITLE,
        content: VERSION_CHANGE_CONFIRMATION,
        state: true
      })
    } else {
      setVersion(e.target.value)
      setActiveStep(0)
      fetchReleaseNotes(e.target.value)
      fetchFormBuilder(e.target.value)
      fetchConfigJson(e.target.value)
      fetchSecretJson(e.target.value)
    }
  }

  const handleVersionConfirm = () => {
    setModalOpen({ title: '', content: '', state: false })
    setIsEdited(false)
    setVersion(confirmVersion)
    setActiveStep(0)
    fetchReleaseNotes(confirmVersion)
    fetchFormBuilder(confirmVersion)
    fetchConfigJson(confirmVersion)
    fetchSecretJson(confirmVersion)
  }

  useEffect(() => {
    if (isLogin) {
      fetchVersionList()
    }
  }, [isLogin])

  useEffect(() => {
    const preview = [
      { label: 'Configuration', data: configPreview },
      { label: 'Secret', data: secretPreview }
    ]
    setPreviewData(preview)
  }, [configPreview, secretPreview])
  return (
    <PrivateRoute>
      <>
        <section className={styles.grid}>
          <div className={styles.topBar}>
            <h3 className="bold">Instance Configuration</h3>
          </div>
        </section>
        <div className={styles.actionWrapper}>
          <div className={styles.header}>
            <div className={styles.title}>
              <h4 className="bold">Select Version</h4>
              <CustomTooltip title="Select a Version" type="bulb" />
            </div>
            <div className={styles.dropdownContainer}>
              <div className={styles.dropdown}>
                <CustomDropDown
                  inputName={'version'}
                  label="Select Version"
                  value={version}
                  onChange={handleVersionChange}
                  options={versionList}
                />
              </div>
              {version && (
                <div className={styles.version}>
                  Current Deployed Version: {appConfig?.instanceVersion}
                </div>
              )}
            </div>
          </div>
        </div>
        {version && initialValues && !fetchJsonLoader ? (
          <StepperForm
            steps={steps}
            validationSchema={validationSchema}
            initialValues={initialValues}
            handleSubmit={handleSubmit}
            handleSaveDraft={handleSaveDraft}
            handleCancel={handleCancel}
            stepsConfig={formBuilder}
            activeStep={activeStep}
            setActiveStep={setActiveStep}
            setterConfig={setterConfig}
            previewData={previewData}
            configKeys={configKeys}
            secretKeys={secretKeys}
            setIsEdited={setIsEdited}
          />
        ) : (
          version && <Loader />
        )}
        {modalOpen.title === REDEPLOY_TITLE ? (
          <Modal
            type={CUSTOM_TYPE}
            title={modalOpen.title}
            titleSize="h3"
            onToggleModal={() => {
              setModalOpen({ title: '', content: '', state: false })
            }}
            isOpen={modalOpen.state}
          >
            {modalOpen.content}
            <div className={styles.footer}>
              {confirmLoader ? (
                <div className={styles.loader}>
                  <Loader />
                </div>
              ) : (
                <Button
                  color="primary"
                  variant="contained"
                  className={`mt-1 ${styles.confirmButton}`}
                  onClick={
                    modalOpen.title === REDEPLOY_TITLE
                      ? handleConfirm
                      : handleVersionConfirm
                  }
                >
                  Confirm
                </Button>
              )}
            </div>
          </Modal>
        ) : (
          <Modal
            type={ICON_TYPE}
            modalTemplate={'unsavedChanges'}
            isOpen={modalOpen.state}
            onToggleModal={() => {
              setModalOpen({ title: '', content: '', state: false })
            }}
            buttonActionMain={handleVersionConfirm}
          />
        )}
      </>
    </PrivateRoute>
  )
}

export default InstanceConfig
