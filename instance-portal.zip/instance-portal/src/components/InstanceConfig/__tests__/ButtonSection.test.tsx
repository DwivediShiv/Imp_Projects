import React from 'react'
import { render, fireEvent, screen } from '@testing-library/react'
import ButtonSection from '../ButtonSection'

jest.mock('../hooks/useTransformer', () => ({
  __esModule: true,
  default: () => ({ transformFieldName: jest.fn() })
}))

describe('ButtonSection Component', () => {
  const mockHandleCancel = jest.fn()
  const mockHandleSaveDraft = jest.fn()
  const mockHandleNext = jest.fn()
  it('renders ButtonSection correctly', () => {
    render(
      <ButtonSection
        values={{}}
        errors={{}}
        handleCancel={mockHandleCancel}
        handleSaveDraft={mockHandleSaveDraft}
        handleNext={mockHandleNext}
        activeStep={0}
        steps={[{ label: 'Step 1' }, { label: 'Step 2' }, { label: 'Step 3' }]}
        configKeys={[]}
        secretKeys={[]}
        setConfigErrors={jest.fn()}
        setSecretErrors={jest.fn()}
        dirty={false}
        setIsEdited={jest.fn()}
      />
    )
    expect(screen.getByText('Cancel')).toBeInTheDocument()
  })

  it('calls the correct function when "Cancel" button is clicked', async () => {
    render(
      <ButtonSection
        values={{}}
        errors={{}}
        handleCancel={mockHandleCancel}
        handleSaveDraft={jest.fn()}
        handleNext={jest.fn()}
        activeStep={0}
        steps={[
          {
            step: 0,
            label: 'Select Version',
            state: ''
          },
          {
            step: 1,
            label: 'Configuration',
            state: ''
          },
          {
            step: 2,
            label: 'Secret',
            state: ''
          },
          {
            step: 3,
            label: 'Review & Deploy',
            state: ''
          }
        ]}
        configKeys={[]}
        secretKeys={[]}
        setConfigErrors={jest.fn()}
        setSecretErrors={jest.fn()}
        dirty={false}
        setIsEdited={jest.fn()}
      />
    )
    fireEvent.click(screen.getByText('Cancel'))
    expect(mockHandleCancel).toHaveBeenCalledTimes(1)
  })

  it('calls the correct function when "Save Draft" button is clicked', async () => {
    render(
      <ButtonSection
        values={{}}
        errors={{}}
        handleCancel={mockHandleCancel}
        handleSaveDraft={mockHandleSaveDraft}
        handleNext={mockHandleNext}
        activeStep={0}
        steps={[
          {
            step: 0,
            label: 'Select Version',
            state: ''
          },
          {
            step: 1,
            label: 'Configuration',
            state: ''
          },
          {
            step: 2,
            label: 'Secret',
            state: ''
          },
          {
            step: 3,
            label: 'Review & Deploy',
            state: ''
          }
        ]}
        configKeys={[]}
        secretKeys={[]}
        setConfigErrors={jest.fn()}
        setSecretErrors={jest.fn()}
        dirty={false}
        setIsEdited={jest.fn()}
      />
    )
    const saveDraft = await screen.findByRole('button', {
      name: /save draft/i
    })
    fireEvent.click(saveDraft)
    expect(mockHandleSaveDraft).toHaveBeenCalledTimes(1)
  })

  it('calls the correct function when "Next" button is clicked', async () => {
    render(
      <ButtonSection
        values={{}}
        errors={{}}
        handleCancel={mockHandleCancel}
        handleSaveDraft={mockHandleSaveDraft}
        handleNext={mockHandleNext}
        activeStep={0}
        steps={[
          {
            step: 0,
            label: 'Select Version',
            state: ''
          },
          {
            step: 1,
            label: 'Configuration',
            state: ''
          },
          {
            step: 2,
            label: 'Secret',
            state: ''
          },
          {
            step: 3,
            label: 'Review & Deploy',
            state: ''
          }
        ]}
        configKeys={[]}
        secretKeys={[]}
        setConfigErrors={jest.fn()}
        setSecretErrors={jest.fn()}
        dirty={false}
        setIsEdited={jest.fn()}
      />
    )
    const nextBtn = screen.getByRole('button', {
      name: /next step: configuration/i
    })
    fireEvent.click(nextBtn)
    expect(mockHandleNext).toHaveBeenCalledTimes(1)
  })

  it('renders the correct error stepper on error', async () => {
    render(
      <ButtonSection
        values={{}}
        errors={{
          maxJobDuration: 'Required Field.'
        }}
        handleCancel={mockHandleCancel}
        handleSaveDraft={mockHandleSaveDraft}
        handleNext={mockHandleNext}
        activeStep={1}
        steps={[
          {
            step: 0,
            label: 'Select Version',
            state: ''
          },
          {
            step: 1,
            label: 'Configuration',
            state: ''
          },
          {
            step: 2,
            label: 'Secret',
            state: ''
          },
          {
            step: 3,
            label: 'Review & Deploy',
            state: ''
          }
        ]}
        configKeys={['marketFeeAddress', 'infuraProjectId', 'maxJobDuration']}
        secretKeys={[
          'market-infura-project-id',
          'provider-amoy-infura-project-id',
          'provider-polygon-infura-project-id',
          'provider-sepolia-infura-project-id'
        ]}
        setConfigErrors={jest.fn()}
        setSecretErrors={jest.fn()}
        dirty={false}
        setIsEdited={jest.fn()}
      />
    )
    const nextBtn = screen.getByRole('button', {
      name: /next step: secret/i
    })
    fireEvent.click(nextBtn)
    expect(mockHandleNext).toHaveBeenCalledTimes(2)
  })
})
