import React from 'react'
import { render, screen } from '@testing-library/react'
import StepperForm from '../StepperForm'

describe('StepperForm component', () => {
  const mockSteps = [
    {
      step: 0,
      label: 'Select Version',
      state: ''
    },
    {
      step: 1,
      label: 'Configuration',
      state: ''
    },
    {
      step: 2,
      label: 'Secret',
      state: ''
    },
    {
      step: 3,
      label: 'Review & Deploy',
      state: ''
    }
  ]

  const mockInitialValues = {
    releaseNotes: 'Dev_v1 version\r\nReleaseNotes.MD',
    marketFeeAddress: '0x2025b1e4Cd5D638d5899E37F0068f2924a698A2c',
    infuraProjectId: '',
    assetManagementToken_name: 'Acentrik Asset Management Token',
    ipfs_expiryTime: '1440h',
    computeOption_nodeJs_registry: 'https://gallery.ecr.aws/',
    computeOption_python_registry: 'https://gallery.ecr.aws/',
    customization_disableCustomDocker: 'false',
    site_baseUrl: 'https://elaine-instance-2.acentrik.io/',
    auth_otpDuration: 120,
    blockChunkSize: 1000,
    authorizedDecrypters: '0xa00c7731165626779dD33ab9914418C886650B1f',
    resource_inputVolumeSize: '1Gi',
    pod_configurationContainer:
      'public.ecr.aws/acentrik/oceanprotocol/pod-configuration:new_timesout-1000',
    aws_bucket_output: 'compute-output',
    ipfs_enabled: true,
    env_nCpu: '1',
    'market-infura-project-id': '69d0218fe76f4eca9525aed82a219cfb',
    'aquarius-amoy-events-ecies-private-key':
      '325e96601c2d003ad95f183cb862adf59e74c7d1eafe8ecbacfa4704e3416efd',
    'provider-amoy-private-key':
      'b70a72408122b7a7faea0157d75fbf6b50bb1798836478c17946c049db40bdd1'
  }

  const mockStepsConfig = [
    {
      step: 0,
      config: [
        {
          name: 'releaseNotes',
          title: 'Release Notes',
          type: 'form',
          fields: [
            {
              name: 'releaseNotes',
              type: 'textarea',
              elementType: 'textArea',
              isResizable: true,
              disabled: true,
              multiline: true,
              maxRows: 8,
              itemSpacing: 12
            }
          ]
        }
      ]
    },
    {
      step: 1,
      config: [
        {
          name: 'marketPlace',
          title: 'Marketplace',
          tooltip: 'Fill the market place required fields.',
          type: 'form',
          subSections: [
            {
              name: 'marketPlace',
              title: 'Marketplace',
              tooltip: 'Fill the market place required fields.',
              type: 'form',
              fields: [
                {
                  name: 'marketFeeAddress',
                  label: 'Market Fee Address',
                  type: 'text',
                  elementType: 'input',
                  mapping: 'marketFeeAddress',
                  dataType: 'string',
                  require: true
                },
                {
                  name: 'infuraProjectId',
                  label: 'Infura Project `Id',
                  type: 'text',
                  elementType: 'input',
                  mapping: 'infuraProjectId',
                  dataType: 'string',
                  require: false,
                  invisible: true
                }
              ],
              border: true
            },
            {
              name: 'nftAssetManagement',
              title: 'NFT/Asset Management Token',
              type: 'form',
              fields: [
                {
                  name: 'assetManagementToken_name',
                  label: 'Token Name',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: true,
                  mapping: 'assetManagementToken.name'
                }
              ],
              border: true
            },
            {
              name: 'computeToData',
              title: 'Compute-to-Data',
              type: 'form',
              fields: [
                {
                  name: 'ipfs_expiryTime',
                  label: 'Compute Output Expiry (Optional)',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  required: false,
                  mapping: 'ipfs.expiryTime'
                }
              ]
            },
            {
              name: 'defaultNodeJS',
              subTitle: 'Default NodeJS',
              type: 'form',
              fields: [
                {
                  name: 'computeOption_nodeJs_registry',
                  label: 'Default NodeJS Registry',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: true,
                  mapping: 'computeOption.nodeJs.registry'
                }
              ]
            },
            {
              name: 'defaultPython',
              subTitle: 'Default Python',
              type: 'form',
              fields: [
                {
                  name: 'computeOption_python_registry',
                  label: 'Default Python Registry',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: true,
                  mapping: 'computeOption.python.registry'
                }
              ],
              border: true
            },
            {
              name: 'featureToggle',
              title: 'Feature Toggle',
              type: 'form',
              fields: [
                {
                  name: 'customization_disableCustomDocker',
                  label: 'Disable Custom Docker',
                  elementType: 'dropdown',
                  dataType: 'boolean',
                  require: true,
                  mapping: 'customization.disableCustomDocker'
                }
              ],
              border: true
            },
            {
              name: 'matomo',
              title: 'Matomo',
              type: 'form',
              fields: [
                {
                  name: 'site_baseUrl',
                  label: 'Base URL (Optional)',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: false,
                  mapping: 'site.baseUrl'
                }
              ],
              border: false
            }
          ]
        },
        {
          name: 'api',
          title: 'API',
          tooltip: 'Fill the API required fields.',
          type: 'form',
          fields: [
            {
              name: 'auth_otpDuration',
              label: 'Email OTP Duration',
              type: 'text',
              elementType: 'input',
              dataType: 'string',
              require: true,
              mapping: 'auth.otpDuration'
            }
          ]
        },
        {
          name: 'indexer',
          title: 'Indexer',
          tooltip: 'Fill the Indexer required fields.',
          type: 'form',
          fields: [
            {
              name: 'blockChunkSize',
              label: 'Event Block Chunk Size',
              type: 'text',
              elementType: 'input',
              dataType: 'number',
              require: true,
              mapping: 'blockChunkSize'
            }
          ]
        },
        {
          name: 'edgeComputingCluster',
          type: 'form',
          title: 'Edge Computing Cluster',
          tooltip: 'Fill the Edge Computing Cluster required fields.',
          subSections: [
            {
              name: 'edgeComputingCluster',
              title: 'Edge Computing Cluster',
              tooltip: 'Fill the Edge Computing Cluster required fields.',
              type: 'form',
              fields: [
                {
                  name: 'authorizedDecrypters',
                  label: 'Authorized Decrypter',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'stringArray',
                  require: true,
                  mapping: 'authorizedDecrypters'
                }
              ],
              border: true
            },
            {
              name: 'resources',
              title: 'Resources',
              type: 'form',
              fields: [
                {
                  name: 'resource_inputVolumeSize',
                  label: 'Input Volume Size',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: true,
                  mapping: 'resource.inputVolumeSize'
                }
              ],
              border: true
            },
            {
              name: 'jobContainer',
              title: 'Job Container',
              type: 'form',
              fields: [
                {
                  name: 'pod_configurationContainer',
                  label: 'Configuration Container',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: true,
                  mapping: 'pod.configurationContainer'
                }
              ],
              border: true
            },
            {
              name: 'awsBucket',
              title: 'AWS Bucket',
              type: 'form',
              fields: [
                {
                  name: 'aws_bucket_output',
                  label: 'Output (Optional)',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: false,
                  mapping: 'aws.bucket.output'
                }
              ],
              border: true
            },
            {
              name: 'ipfs',
              title: 'IPFS',
              type: 'form',
              fields: [
                {
                  name: 'ipfs_enabled',
                  label: 'Enabled (Optional)',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'string',
                  require: false,
                  mapping: 'ipfs.enabled'
                }
              ],
              border: true
            },
            {
              name: 'resouces',
              title: 'Resources',
              type: 'form',
              fields: [
                {
                  name: 'env_nCpu',
                  label: 'nCPU',
                  type: 'text',
                  elementType: 'input',
                  dataType: 'number',
                  require: true,
                  mapping: 'env.nCpu'
                }
              ],
              border: false
            }
          ]
        }
      ]
    },
    {
      step: 2,
      config: [
        {
          name: 'marketPlace',
          title: 'Marketplace',
          tooltip: 'Fill the Marketplace required fields.',
          type: 'form',
          fields: [
            {
              name: 'market-infura-project-id',
              label: 'Infura Project Id (optional)',
              type: 'text',
              elementType: 'input',
              dataType: 'string',
              require: false,
              mapping: 'market-infura-project-id'
            }
          ]
        },
        {
          name: 'indexer',
          title: 'Indexer',
          tooltip: 'Fill the Indexer required fields.',
          type: 'form',
          fields: [
            {
              name: 'aquarius-amoy-events-ecies-private-key',
              label: 'Aquarius Amoy Private Key',
              type: 'text',
              elementType: 'input',
              dataType: 'string',
              require: true,
              network: 'amoy',
              mapping: 'aquarius-amoy-events-ecies-private-key',
              invisible: false
            }
          ]
        },
        {
          name: 'edgeComputingCluster',
          type: 'form',
          title: 'Edge Computing Cluster',
          fields: [
            {
              name: 'provider-amoy-private-key',
              label: 'Provider Amoy Private Key',
              type: 'text',
              elementType: 'input',
              dataType: 'string',
              require: true,
              network: 'amoy',
              publicKey: 'allowedProviders',
              mapping: 'provider-amoy-private-key',
              invisible: false
            }
          ]
        }
      ]
    },
    {
      step: 3,
      config: [
        {
          name: 'reviewAndDeploy',
          title: 'Review & Deploy',
          fields: []
        }
      ]
    }
  ]

  test('renders StepperForm with initial values', async () => {
    render(
      <StepperForm
        steps={mockSteps}
        validationSchema={{}}
        initialValues={mockInitialValues}
        handleSubmit={jest.fn()}
        handleSaveDraft={jest.fn()}
        handleCancel={jest.fn()}
        stepsConfig={mockStepsConfig}
        activeStep={0}
        setActiveStep={jest.fn()}
        previewData={[]}
        setterConfig={jest.fn()}
        configKeys={[]}
        secretKeys={[]}
        setIsEdited={jest.fn()}
      />
    )
    expect(screen.getByText(/select version/i)).toBeInTheDocument()
    expect(
      screen.getByRole('heading', {
        name: /release notes/i
      })
    ).toBeInTheDocument()
  })
})
