import React from 'react'
import { render, screen, fireEvent, within } from '@testing-library/react'
import ReviewAndDeploy from '../ReviewAndDeploy'

const mockPreviewData = [
  {
    label: 'Configuration',
    data: [
      {
        heading: 'Marketplace',
        title: 'Marketplace',
        border: false,
        fields: [
          {
            name: 'marketFeeAddress',
            label: 'Market Fee Address',
            value: '0x2025b1e4Cd5D638d5899E37F0068f2924a698A2c',
            require: true,
            visible: true
          }
        ]
      },
      {
        heading: '',
        title: 'Resources',
        border: false,
        fields: [
          {
            name: 'maxJobDuration',
            label: 'Max. Job Duration',
            value: '',
            require: true,
            visible: true
          }
        ]
      }
    ]
  },
  {
    label: 'Secret',
    data: [
      {
        heading: 'Marketplace',
        title: 'Marketplace',
        border: false,
        fields: [
          {
            name: 'market-infura-project-id',
            label: 'Infura Project Id (optional)',
            value: 'e8f48173be3047d0b7d57f09742af74f',
            require: false,
            visible: true
          },
          {
            name: 'provider-amoy-infura-project-id',
            label: 'Provider Amoy Infura Project Id',
            value: 'e8f48173be3047d0b7d57f09742af74f',
            require: false,
            visible: true
          },
          {
            name: 'provider-polygon-infura-project-id',
            label: 'Provider Polygon Infura Project Id',
            value: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
            require: false,
            visible: true
          },
          {
            name: 'provider-sepolia-infura-project-id',
            label: 'Provider Sepolia Infura Project Id',
            value: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
            require: false,
            visible: true
          }
        ]
      }
    ]
  }
]

const mockHandleEdit = jest.fn()

const mockErrors = {
  maxJobDuration: 'Required Field.'
}

test('renders ReviewAndDeploy component', () => {
  render(
    <ReviewAndDeploy
      previewData={mockPreviewData}
      handleEdit={mockHandleEdit}
      errors={mockErrors}
    />
  )
  expect(
    screen.getByRole('heading', {
      name: /configuration/i
    })
  ).toBeInTheDocument()
  const row = screen.getByRole('row', {
    name: /marketplace market fee address 0x2025b1e4cd5d638d5899e37f0068f2924a698a2c/i
  })

  const title1 = within(row).getByText(/marketplace/i)
  expect(title1).toBeInTheDocument()
  const maxJobDuration = screen.getByText(/max\. job duration/i)
  expect(maxJobDuration).toBeInTheDocument()
  const configEdit = screen.getAllByRole('button', { name: /edit/i })[0]
  fireEvent.click(configEdit)
  expect(mockHandleEdit).toHaveBeenCalledTimes(1)
})
