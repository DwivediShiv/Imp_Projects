import React from 'react'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'
import { render, screen, waitFor } from '@testing-library/react'
import InstanceConfig from '..'
import { versionListDataHandler } from '../msw/instanceConfigHandler'

jest.mock('next/router', () => ({
  useRouter: jest.fn()
}))

jest.mock('@core/context/Authorize')
interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

function renderComponent(options: RenderOptions) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin, isAdmin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin,
    isAdmin
  })

  render(<InstanceConfig />)
}

describe('instance config', () => {
  beforeEach(() => {
    versionListDataHandler()
  })

  it('admin component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isAdmin: false
      }
    })
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('component should render if authorized', async () => {
    renderComponent({
      authorize: {
        isAdmin: true,
        isLogin: true
      }
    })
    expect(await screen.findByText('Instance Configuration'))
  })
})
