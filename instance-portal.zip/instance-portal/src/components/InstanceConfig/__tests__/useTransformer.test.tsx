import '@testing-library/jest-dom'
import useTransformer from '../hooks/useTransformer'

describe('useTransformer', () => {
  test('transformFieldName transforms dots to underscores', () => {
    const { transformFieldName } = useTransformer()
    const fieldName = 'some.field.name'
    const transformedName = transformFieldName(fieldName)
    expect(transformedName).toBe('some_field_name')
  })

  test('transformSubmitValues transforms underscores to dots', () => {
    const { transformSubmitValues } = useTransformer()
    const inputObject = { some_field_name: 'value' }
    const transformedObject = transformSubmitValues(inputObject)
    expect(transformedObject).toEqual({ 'some.field.name': 'value' })
  })

  test('transformStringToArray transforms string to JSON array', () => {
    const { transformStringToArray } = useTransformer()
    const inputObject = { stringArrayField: 'value1,value2,value3' }
    const transformedObject = transformStringToArray(inputObject, [
      'stringArrayField'
    ])
    expect(transformedObject).toEqual({
      stringArrayField: '["value1","value2","value3"]'
    })
  })

  test('transformStringToNumber transforms string to number', () => {
    const { transformStringToNumber } = useTransformer()
    const inputObject = { numberField: '42' }
    const transformedObject = transformStringToNumber(inputObject, [
      'numberField'
    ])
    expect(transformedObject).toEqual({ numberField: 42 })
  })
})
