import React, { ReactElement, useEffect, useRef, useState } from 'react'
import styles from './StepperForm.module.css'
import { Formik, Field, Form } from 'formik'
import classNames from 'classnames'
import Stepper from '@sharedComponents/Stepper'
import Container from '@sharedComponents/Container'
import FieldsSection from '@sharedComponents/SectionForm/FieldsSection'
import CustomTooltip from '@sharedComponents/Tooltip'
import ReviewAndDeploy from './ReviewAndDeploy'
import { mapValues } from 'lodash'
import ButtonSection from './ButtonSection'

const StepperForm = ({
  steps,
  validationSchema,
  initialValues,
  handleSubmit,
  handleSaveDraft,
  handleCancel,
  stepsConfig,
  activeStep,
  setActiveStep,
  previewData,
  setterConfig,
  configKeys,
  secretKeys,
  setIsEdited
}): ReactElement => {
  const [stepsList, setStepsList] = useState(steps)
  const [configErrors, setConfigErrors] = useState({})
  const [secretErrors, setSecretErrors] = useState({})
  const formikRef = useRef(null)
  useEffect(() => {
    const newSteps = steps
    if (Object.keys(configErrors)?.length) {
      newSteps[1].state = 'error'
    }
    if (Object.keys(secretErrors)?.length) {
      newSteps[2].state = 'error'
    }
    setStepsList(newSteps)
  }, [configErrors, secretErrors])

  const handleNext = (values) => {
    setterConfig(values)
    setActiveStep((prevActiveStep) => prevActiveStep + 1)
  }

  const handleEdit = (label) => {
    label === 'Configuration' ? setActiveStep(1) : setActiveStep(2)
  }

  const renderFormFields = ({
    section,
    errors,
    dirty,
    values,
    setFieldValue,
    setFieldError
  }) => (
    <>
      {(section.title || section.subTitle) && (
        <div className={styles.header}>
          <div className={styles.title}>
            {section.title && <h4 className="bold">{section.title}</h4>}
            {section.tooltip && (
              <CustomTooltip title={section.tooltip} type="bulb" />
            )}
            {section.subTitle && <h6 className="bold">{section.subTitle}</h6>}
          </div>
        </div>
      )}
      {(() => {
        switch (section.type) {
          case 'form':
            return (
              <FieldsSection
                errors={errors}
                fields={section?.fields}
                dirty={dirty}
                values={values}
                setFieldValue={setFieldValue}
                setFieldError={setFieldError}
                containerSpacing={activeStep === 0 ? 12 : 4}
              />
            )
          default:
            return (
              <Field
                name={section.name}
                component={section.getComponent}
                className={styles.inputbox}
                isEditActive
                setFieldValue={setFieldValue}
              />
            )
        }
      })()}
    </>
  )

  useEffect(() => {
    if (Object.keys(initialValues).length) {
      formikRef.current.validateForm()
    }
  }, [initialValues])

  return (
    <div className={styles.content}>
      <Formik
        innerRef={formikRef}
        enableReinitialize={true}
        initialTouched={mapValues(initialValues, (value, key) => {
          return key !== 'releaseNotes'
        })}
        initialValues={initialValues}
        validationSchema={activeStep !== 0 && validationSchema}
        validateOnMount={true}
        onSubmit={async (
          values,
          { setSubmitting, resetForm, setFieldError }
        ) => {
          setterConfig(values)
          if (activeStep === 3) {
            await handleSubmit(values, resetForm, setFieldError)
            setSubmitting(false)
          }
        }}
      >
        {({ errors, dirty, values, setFieldValue, setFieldError }) => {
          return (
            <Form>
              <Container className={styles.stepperContainer}>
                <Stepper
                  activeStep={activeStep}
                  list={stepsList}
                  onClick={(index) => {
                    setActiveStep(index)
                    setterConfig(values)
                  }}
                />
              </Container>
              {stepsConfig?.map((form) => {
                const { config } = form
                return (
                  <div
                    className={classNames(
                      styles.stepContentContainer,
                      activeStep === form.step ? styles.active : ''
                    )}
                    key={form.name}
                  >
                    {activeStep === 3 && (
                      <ReviewAndDeploy
                        previewData={previewData}
                        handleEdit={handleEdit}
                        errors={errors}
                      />
                    )}
                    {activeStep !== 3 &&
                      config?.map((section) => {
                        if (section.subSections) {
                          const { subSections } = section
                          return (
                            <div className={styles.boxPaper} key={section.name}>
                              {subSections?.map((subSection) => (
                                <>
                                  <div
                                    key={subSection.name}
                                    className={styles.actionWrapper}
                                  >
                                    {renderFormFields({
                                      section: subSection,
                                      errors,
                                      dirty,
                                      values,
                                      setFieldValue,
                                      setFieldError
                                    })}
                                  </div>
                                  {subSection?.border && (
                                    <hr className={styles.divider} />
                                  )}
                                </>
                              ))}
                            </div>
                          )
                        } else {
                          return (
                            <div className={styles.boxPaper} key={section.name}>
                              <div className={styles.actionWrapper}>
                                {renderFormFields({
                                  section,
                                  errors,
                                  dirty,
                                  values,
                                  setFieldValue,
                                  setFieldError
                                })}
                              </div>
                            </div>
                          )
                        }
                      })}
                    <ButtonSection
                      values={values}
                      errors={errors}
                      handleCancel={handleCancel}
                      handleSaveDraft={handleSaveDraft}
                      handleNext={handleNext}
                      activeStep={activeStep}
                      steps={steps}
                      configKeys={configKeys}
                      secretKeys={secretKeys}
                      setConfigErrors={setConfigErrors}
                      setSecretErrors={setSecretErrors}
                      dirty={dirty}
                      setIsEdited={setIsEdited}
                    />
                  </div>
                )
              })}
            </Form>
          )
        }}
      </Formik>
    </div>
  )
}

export default StepperForm
