import { rest } from 'msw'
import { server } from '@utils/msw'
import { versionList } from './instanceConfigData'
import appConfig from 'app.config'
import { MswHandlerProps, VersionList } from '../types/instanceConfig'

export function versionListDataHandler(props?: MswHandlerProps<VersionList[]>) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(
    `${appConfig.api}/instance-management/api/v1/instance/version/list`,
    async (_, res, ctx) => {
      let json
      const data = versionList
      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
