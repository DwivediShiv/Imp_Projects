export const versionList = {
  data: [
    {
      Version: 'v1.0.0',
      Description: 'description'
    },
    {
      Version: 'v1.0.1',
      Description: 'description'
    }
  ]
}
