import { Paper, Table, TableBody, TableCell, TableRow } from '@mui/material'
import { makeStyles } from 'tss-react/mui'
import React from 'react'
import styles from './ReviewAndDeploy.module.css'
import Button from '@sharedComponents/Button'

const useStyles = makeStyles()(() => {
  return {
    root: {
      width: 213,
      maxWidth: 213,
      verticalAlign: 'top'
    },
    tableCell: {
      borderBottom: 'none !important'
    }
  }
})

const ReviewAndDeploy = ({ previewData, handleEdit, errors }) => {
  const { classes } = useStyles()
  const checkError = (fieldName) => {
    return errors[fieldName]
  }
  const renderFieldValue = (fields) => {
    return (
      <>
        <div className={styles.boxContainer}>
          <Table>
            {fields.map((field) => (
              <>
                {field.visible && (
                  <TableRow key={field.label}>
                    <TableCell className={classes.root} align="left">
                      <p className={`caption ${styles.subtitle}`}>
                        {field.label}
                      </p>
                      <p className={`pre-title ${styles.error}`}>
                        {field.require && !field.value
                          ? 'Required Field'
                          : checkError(field?.name)}
                      </p>
                    </TableCell>
                    <TableCell align="left">
                      <span className={styles.previewValue}>
                        {field.value === '' ? '-' : field.value}
                      </span>
                    </TableCell>
                  </TableRow>
                )}
              </>
            ))}
          </Table>
        </div>
      </>
    )
  }

  const defaultField = (section) => {
    return (
      <TableRow className={`${styles.tableRow}`}>
        <TableCell className={`${classes.root}`} align="left">
          {section.heading ? (
            <p className={`caption ${styles.heading}`}>{section.heading}</p>
          ) : (
            <p className={`caption ${styles.title}`}>{section.title}</p>
          )}
        </TableCell>
        <TableCell align="left" className={styles.fieldsCell}>
          {renderFieldValue(section.fields)}
        </TableCell>
      </TableRow>
    )
  }

  const box = (
    <>
      {previewData.map(({ label, data, index }) => (
        <Paper key={index} classes={{ root: styles.boxPaper }}>
          <div className={styles.header}>
            <div className={`${styles.title}`}>
              <h6 className="bold">{label}</h6>
            </div>
            <Button color="primary" onClick={() => handleEdit(label)}>
              Edit
            </Button>
          </div>
          <Table className={styles.table}>
            <TableBody>
              {data?.map((section) => defaultField(section))}
            </TableBody>
          </Table>
        </Paper>
      ))}
    </>
  )
  return <div className={styles.container}>{box} </div>
}

export default ReviewAndDeploy
