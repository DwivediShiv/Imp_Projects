export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}

export interface VersionList {
  Version: string
  Description: string
}
