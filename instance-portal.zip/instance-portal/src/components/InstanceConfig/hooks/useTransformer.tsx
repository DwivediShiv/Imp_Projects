const useTransformer = () => {
  const transformFieldName = (fieldName) => {
    return fieldName.replaceAll('.', '_')
  }

  const transformSubmitValues = (obj) => {
    return Object.keys(obj)?.reduce((acc, currKey) => {
      const value = obj[currKey]
      const newKey = currKey.replaceAll('_', '.')
      acc[newKey] = value
      return acc
    }, {})
  }

  const transformStringToArray = (finalObj, stringArrayFields) => {
    let final = { ...finalObj }
    stringArrayFields.forEach((field) => {
      if (typeof final[field] === 'string' && final[field]) {
        final = { ...final, [field]: JSON.stringify(final[field]?.split(',')) }
      }
    })
    return final
  }

  const transformStringToNumber = (finalObj, numberFields) => {
    let final = { ...finalObj }
    numberFields.forEach((field) => {
      if (typeof final[field] === 'string' && final[field]) {
        final = { ...final, [field]: parseInt(final[field]) }
      }
    })
    return final
  }

  return {
    transformFieldName,
    transformSubmitValues,
    transformStringToArray,
    transformStringToNumber
  }
}

export default useTransformer
