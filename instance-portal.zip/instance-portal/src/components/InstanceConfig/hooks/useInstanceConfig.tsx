import React, { useCallback, useEffect, useState } from 'react'
import * as Yup from 'yup'
import { get, setWith } from 'lodash'
import { convertDate } from '@utils/conversion'
import useTransformer from './useTransformer'
import { ethers } from 'ethers'
import useInstanceConfigApi from './useInstanceConfigApi'
import Toast from '@sharedComponents/Toast'
import { REDEPLOY_CONFIRMATION, REDEPLOY_TITLE } from '@constants/constants'
import appConfig from 'app.config'

const useInstanceConfig = ({
  activeStep,
  formBuilder,
  secretJson,
  configJson,
  releaseNotes,
  version,
  handleCancel,
  setIsEdited
}) => {
  const [configPreview, setConfigPreview] = useState([])
  const [secretPreview, setSecretPreview] = useState([])
  const [finalConfig, setFinalConfig] = useState({})
  const [finalSecret, setFinalSecret] = useState({})
  const [configKeys, setConfigKeys] = useState([])
  const [secretKeys, setSecretKeys] = useState([])
  const [stringArrayFields, setStringArrayFields] = useState([])
  const [addressFields, setAddressFields] = useState([])
  const [numberFields, setNumberFields] = useState([])
  const [modalOpen, setModalOpen] = useState({
    title: '',
    content: '',
    state: false
  })
  const [submittedValues, setSubmittedValues] = useState({})
  const [confirmLoader, setConfirmLoader] = useState(false)
  const {
    transformFieldName,
    transformSubmitValues,
    transformStringToArray,
    transformStringToNumber
  } = useTransformer()
  const { saveConfigJson, saveSecretJson, reDeploy, deployLoader } =
    useInstanceConfigApi()

  useEffect(() => {
    setConfirmLoader(deployLoader)
  }, [deployLoader])

  const steps = [
    {
      step: 0,
      label: 'Select Version',
      state: ''
    },
    {
      step: 1,
      label: 'Configuration',
      state: ''
    },
    {
      step: 2,
      label: 'Secret',
      state: ''
    },
    {
      step: 3,
      label: 'Review & Deploy',
      state: ''
    }
  ]

  const getInitialValues = useCallback(
    (field, initialValues) => {
      const combinedData = { ...configJson, ...secretJson }
      if (field.type === 'date') {
        let dateValue = get(combinedData, field.mapping)
        dateValue = convertDate(dateValue, 'YYYY-MM-DD')
        initialValues[transformFieldName(field?.name)] = dateValue ?? ''
        return initialValues
      }
      if (field.dataType === 'stringArray') {
        let fieldValue = get(combinedData, field.mapping)
        if (fieldValue) fieldValue = JSON.parse(fieldValue)
        fieldValue = fieldValue?.length ? fieldValue.join(', ') : ''
        initialValues[transformFieldName(field?.name)] = fieldValue
      } else {
        if (field?.name === 'releaseNotes') {
          initialValues.releaseNotes = releaseNotes
        } else {
          initialValues[transformFieldName(field?.name)] =
            get(combinedData, field.mapping) ?? ''
        }
      }
      return initialValues
    },
    [releaseNotes, configJson, secretJson, version]
  )

  const getValidationSchema = (field, validationSchema) => {
    switch (field.dataType) {
      case 'string':
      case 'stringArray':
      case 'arrayString':
        validationSchema[transformFieldName(field?.name)] = Yup.string().trim()
        if (field.require) {
          validationSchema[transformFieldName(field?.name)] = Yup.string()
            .trim()
            .required('Required Field.')
        }
        break
      case 'number':
        validationSchema[transformFieldName(field?.name)] = Yup.number()
        if (field.require) {
          validationSchema[transformFieldName(field?.name)] = Yup.number()
            .required('Required Field.')
            .typeError('Must be a number')
        } else {
          validationSchema[transformFieldName(field?.name)] =
            Yup.number().typeError('Must be a number')
        }
        break
      case 'boolean':
        validationSchema[transformFieldName(field?.name)] = Yup.boolean()
        if (field.require) {
          validationSchema[transformFieldName(field?.name)] =
            Yup.boolean().required('Required Field.')
        }
        break
    }
    return validationSchema
  }

  const getSchemaValues = useCallback(
    (data = formBuilder) => {
      let initialValues = {}
      let validationSchema = {}
      if (data) {
        data.map((form) => {
          const { config } = form
          config?.map((section) => {
            if (section?.subSections) {
              const { subSections } = section
              subSections?.map((subSection) => {
                subSection?.fields?.map((field) => {
                  if (field?.name) {
                    initialValues = getInitialValues(field, initialValues)
                    validationSchema = getValidationSchema(
                      field,
                      validationSchema
                    )
                  }
                })
              })
            } else {
              section?.fields?.map((field) => {
                if (field?.name) {
                  initialValues = getInitialValues(field, initialValues)
                  validationSchema = getValidationSchema(
                    field,
                    validationSchema
                  )
                }
              })
            }
          })
        })
      }
      validationSchema = Yup.object().shape({ ...validationSchema })
      return { initialValues, validationSchema }
    },
    [formBuilder, secretJson, configJson, version, releaseNotes]
  )

  const setPreviewList = ({
    previewArr,
    section,
    index = 0,
    transformedObj,
    numberFieldsArr,
    stringArrayFieldsArr,
    addressFieldsArr
  }) => {
    previewArr.push({
      heading: index === 0 ? section.title : '',
      title: section.title ?? '',
      border: section.length - 1 === index,
      fields: section.fields.map((field) => {
        if (field?.publicKey) {
          addressFieldsArr.push({
            publicKey: field.publicKey,
            privateKey: field?.mapping
          })
          setAddressFields(addressFieldsArr)
        }
        if (
          field.dataType === 'stringArray' &&
          !stringArrayFields?.includes(field.mapping)
        ) {
          stringArrayFieldsArr.push(field.mapping)
          setStringArrayFields(stringArrayFieldsArr)
        }
        if (
          field.dataType === 'number' &&
          !numberFields?.includes(field.mapping)
        ) {
          numberFieldsArr.push(field.mapping)
          setNumberFields(numberFieldsArr)
        }
        return {
          name: field.name,
          label: field.label,
          value: transformedObj[field.mapping] ?? '-',
          require: field.require,
          visible: field.invisible
            ? !field.invisible
            : field.network
            ? appConfig.networks?.includes(field.network)
            : true
        }
      })
    })
  }

  const generatePreviewData = (transformedObj, step) => {
    const previewArr = []
    const numberFieldsArr = []
    const stringArrayFieldsArr = []
    const addressFieldsArr = []
    const filteredConfig = formBuilder?.filter(
      (stepConfig) => stepConfig.step === step
    )
    filteredConfig?.forEach((form) => {
      const { config } = form
      config.forEach((section) => {
        if (section.subSections) {
          const { subSections } = section
          subSections?.forEach((subSection, index) => {
            setPreviewList({
              previewArr,
              section: subSection,
              index,
              transformedObj,
              numberFieldsArr,
              stringArrayFieldsArr,
              addressFieldsArr
            })
          })
        } else {
          setPreviewList({
            previewArr,
            section,
            transformedObj,
            numberFieldsArr,
            stringArrayFieldsArr,
            addressFieldsArr
          })
        }
      })
      if (step === 1) {
        setConfigPreview(previewArr)
      }
      if (step === 2) {
        setSecretPreview(previewArr)
      }
    })
  }

  const getFinalObject = (transformedObj, keys) => {
    const transformedArray = keys?.map((item) => ({
      [item]: transformedObj[item]
    }))
    const finalObject = {}
    transformedArray?.map((obj) =>
      setWith(finalObject, Object.keys(obj)[0], Object.values(obj)[0])
    )
    return finalObject
  }

  useEffect(() => {
    if (formBuilder && configJson && secretJson && releaseNotes) {
      steps.forEach(({ step }) => {
        if (step === 1 || step === 2) {
          const stepConfig = formBuilder?.filter(
            (stepConfig) => stepConfig.step === step
          )
          const { initialValues: initValues } = getSchemaValues(stepConfig)
          const transformedObj = transformSubmitValues(initValues)
          generatePreviewData(transformedObj, step)
          if (step === 1) {
            setConfigKeys(Object.keys(transformedObj))
            const finalConfigObject = getFinalObject(
              transformedObj,
              Object.keys(transformedObj)
            )
            setFinalConfig(finalConfigObject)
          }
          if (step === 2) {
            setSecretKeys(Object.keys(transformedObj))
            const finalSecretObject = getFinalObject(
              transformedObj,
              Object.keys(transformedObj)
            )
            setFinalSecret(finalSecretObject)
          }
        }
      })
    }
  }, [formBuilder, configJson, secretJson, releaseNotes])

  const setterConfig = (values) => {
    const transformedObj = transformSubmitValues(values)
    generatePreviewData(transformedObj, activeStep)
    let finalConfigObject = finalConfig
    let finalSecretObject = finalSecret
    if (activeStep === 1) {
      finalConfigObject = getFinalObject(transformedObj, configKeys)
      setFinalConfig(finalConfigObject)
    }
    if (activeStep === 2) {
      finalSecretObject = getFinalObject(transformedObj, secretKeys)
      setFinalSecret(finalSecretObject)
    }
    return { finalConfigObject, finalSecretObject }
  }

  const isValidHex = (value) => {
    const hexRegex = /^[0-9a-fA-F]{64}$/
    return hexRegex.test(value)
  }

  const getAddressFromKey = (key) => {
    let address
    if (isValidHex(key)) {
      address = new ethers.Wallet(key)?.address
    }
    return address
  }

  const handleSaveDraft = useCallback(
    async (values, isSaveDraft = true) => {
      const { finalConfigObject, finalSecretObject } = setterConfig(values)
      let transformedFinalConfig = transformStringToArray(
        finalConfigObject,
        stringArrayFields
      )
      transformedFinalConfig = transformStringToNumber(
        transformedFinalConfig,
        numberFields
      )
      const allowedProviders = []
      addressFields.forEach((field) => {
        if (field?.publicKey === 'allowedProviders') {
          const address = getAddressFromKey(
            finalSecretObject[field?.privateKey]
          )
          if (address) allowedProviders.push(address)
        } else {
          const address = getAddressFromKey(
            finalSecretObject[field?.privateKey]
          )
          if (address) transformedFinalConfig[field?.publicKey] = address
        }
      })
      if (allowedProviders?.length) {
        transformedFinalConfig.allowedProviders =
          JSON.stringify(allowedProviders)
      }
      await saveConfigJson(transformedFinalConfig, version)
      await saveSecretJson(finalSecretObject, version)
      if (isSaveDraft) {
        Toast('success', 'Draft saved successfully.')
      }
      setIsEdited(false)
    },
    [finalConfig, finalSecret, setterConfig]
  )

  const handleConfirm = useCallback(async () => {
    await handleSaveDraft(submittedValues, false)
    await reDeploy(version)
    handleCancel()
    setModalOpen({ title: '', content: '', state: false })
  }, [submittedValues, modalOpen])

  const handleSubmit = (
    values,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ) => {
    setSubmittedValues(values)
    setModalOpen({
      title: REDEPLOY_TITLE,
      content: REDEPLOY_CONFIRMATION,
      state: true
    })
  }

  return {
    handleSubmit,
    handleSaveDraft,
    steps,
    validationSchema: getSchemaValues()?.validationSchema,
    initialValues: getSchemaValues()?.initialValues,
    setterConfig,
    configPreview,
    secretPreview,
    stringArrayFields,
    modalOpen,
    setModalOpen,
    handleConfirm,
    configKeys,
    secretKeys,
    confirmLoader
  }
}

export default useInstanceConfig
