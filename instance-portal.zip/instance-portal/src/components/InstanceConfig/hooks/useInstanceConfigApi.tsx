import Toast from '@sharedComponents/Toast'
import appConfig from 'app.config'
import axios from 'axios'
import yaml from 'js-yaml'
import React, { useCallback, useState } from 'react'

const versionListUrl = `${appConfig.api}/instance-management/api/v1/instance/version/list`
const reDeployUrl = `${appConfig.api}/instance-management/api/v1/instance/redeploy`

const fetchReleaseNotesUrl = (versionId) => {
  const releaseNotesUrl = `${appConfig.api}/instance-management/api/v1/instance/version/${versionId}/release-note`
  return releaseNotesUrl
}

const fetchFormBuilderUrl = (versionId) => {
  const formBuilderUrl = `${appConfig.api}/instance-management/api/v1/instance/version/${versionId}/form-builder`
  return formBuilderUrl
}

const fetchConfigUrl = (versionId) => {
  const configUrl = `${appConfig.api}/instance-management/api/v1/instance/version/${versionId}/config`
  return configUrl
}

const fetchSecretUrl = (versionId) => {
  const secretUrl = `${appConfig.api}/instance-management/api/v1/instance/version/${versionId}/secrets`
  return secretUrl
}

const useInstanceConfigApi = () => {
  const [versionList, setVersionList] = useState(null)
  const [releaseNotes, setReleaseNotes] = useState('')
  const [formBuilder, setFormBuilder] = useState(null)
  const [configJson, setConfigJson] = useState(null)
  const [secretJson, setSecretJson] = useState(null)
  const [deployLoader, setDeployLoader] = useState({
    reDeploy: false,
    saveConfig: false,
    saveSecret: false
  })
  const [fetchConfigLoader, setFetchConfigLoader] = useState(false)
  const [fetchSecretLoader, setFetchSecretLoader] = useState(false)
  const [fetchFormLoader, setFetchFormLoader] = useState(false)
  const [fetchNotesLoader, setFetchNotesLoader] = useState(false)

  const fetchVersionList = useCallback(async () => {
    try {
      const { data: response } = await axios.get(versionListUrl)
      setVersionList(response.data.map((version) => version.Version))
    } catch (error) {
      setVersionList(null)
      console.log(error)
    }
  }, [])

  const fetchReleaseNotes = useCallback(async (currVersion) => {
    try {
      setFetchNotesLoader(true)
      setReleaseNotes('')
      const getReleaseNotesUrl = fetchReleaseNotesUrl(currVersion)
      const { data: response } = await axios.get(getReleaseNotesUrl)
      setReleaseNotes(response.data)
      setFetchNotesLoader(false)
    } catch (error) {
      setFetchNotesLoader(false)
      setReleaseNotes('')
      console.log(error)
    }
  }, [])

  const fetchFormBuilder = useCallback(async (currVersion) => {
    try {
      setFetchFormLoader(true)
      const getFormBuilderUrl = fetchFormBuilderUrl(currVersion)
      const { data: response } = await axios.get(getFormBuilderUrl)
      const formBuilderJson = JSON.parse(response.data)
      formBuilderJson?.forEach((form) => {
        const { config } = form
        config?.forEach((section) => {
          const { subSections } = section
          if (subSections) {
            subSections.forEach((subSection) => {
              const { fields } = subSection
              fields.forEach((field) => {
                if (field?.network) {
                  field.invisible = field.invisible
                    ? field.invisible
                    : !appConfig.networks?.includes(field.network)
                }
              })
            })
          } else {
            const { fields } = section
            fields.forEach((field) => {
              if (field?.network) {
                field.invisible = field.invisible
                  ? field.invisible
                  : !appConfig.networks?.includes(field.network)
              }
            })
          }
        })
      })
      setFormBuilder(formBuilderJson)
      setFetchFormLoader(false)
    } catch (error) {
      setFetchFormLoader(false)
      console.log(error)
      setFormBuilder(null)
    }
  }, [])

  const fetchConfigJson = useCallback(async (currVersion) => {
    try {
      setFetchConfigLoader(true)
      const getConfigUrl = fetchConfigUrl(currVersion)
      const { data: response } = await axios.get(getConfigUrl)
      const configObject = yaml.load(response.data)
      setConfigJson(configObject?.config)
      setFetchConfigLoader(false)
    } catch (error) {
      setFetchConfigLoader(false)
      console.log(error)
      setConfigJson(null)
    }
  }, [])

  const saveConfigJson = useCallback(async (configObject, currVersion) => {
    try {
      setDeployLoader({ ...deployLoader, saveConfig: true })
      const putConfigUrl = fetchConfigUrl(currVersion)
      const configYaml = yaml.dump({ config: configObject })
      if (configYaml) {
        const configJsonBlob = new Blob([configYaml], {
          type: 'application/x-yaml'
        })
        const formData = new FormData()
        formData.append('file', configJsonBlob, 'deafult.yaml')
        const { data: response } = await axios.put(putConfigUrl, formData, {
          headers: {
            'Content-Type': 'text-plain'
          }
        })
      }
      setDeployLoader({ ...deployLoader, saveConfig: false })
    } catch (error) {
      setDeployLoader({ ...deployLoader, saveConfig: false })
      console.log(error)
    }
  }, [])

  const fetchSecretJson = useCallback(async (currVersion) => {
    try {
      setFetchSecretLoader(true)
      const getSecretUrl = fetchSecretUrl(currVersion)
      const { data: response } = await axios.get(getSecretUrl)
      const secretObject = yaml.load(response.data)
      setSecretJson(secretObject)
      setFetchSecretLoader(false)
    } catch (error) {
      setFetchSecretLoader(false)
      console.log(error)
      setSecretJson(null)
    }
  }, [])

  const saveSecretJson = useCallback(async (secretObject, currVersion) => {
    try {
      setDeployLoader({ ...deployLoader, saveSecret: true })
      const putSecretUrl = fetchSecretUrl(currVersion)
      const { data: response } = await axios.put(putSecretUrl, {
        message: JSON.stringify(secretObject)
      })
      setDeployLoader({ ...deployLoader, saveSecret: false })
    } catch (error) {
      setDeployLoader({ ...deployLoader, saveSecret: false })
      console.log(error)
    }
  }, [])

  const reDeploy = useCallback(async (version) => {
    try {
      setDeployLoader({ ...deployLoader, reDeploy: true })
      const { data: response } = await axios.post(reDeployUrl + `/${version}`)
      setDeployLoader({ ...deployLoader, reDeploy: false })
      Toast('success', 'Instance deployed with updated configuration.')
    } catch (error) {
      setDeployLoader({ ...deployLoader, reDeploy: false })
      Toast(
        'error',
        'Cannot deploy configuration. Please try again after sometime.'
      )
      console.log(error)
    }
  }, [])

  return {
    fetchVersionList,
    versionList,
    fetchReleaseNotes,
    releaseNotes,
    fetchFormBuilder,
    formBuilder,
    fetchConfigJson,
    configJson,
    fetchSecretJson,
    secretJson,
    saveConfigJson,
    saveSecretJson,
    reDeploy,
    deployLoader:
      deployLoader.reDeploy ||
      deployLoader.saveConfig ||
      deployLoader.saveSecret,
    fetchJsonLoader:
      fetchConfigLoader ||
      fetchSecretLoader ||
      fetchFormLoader ||
      fetchNotesLoader
  }
}

export default useInstanceConfigApi
