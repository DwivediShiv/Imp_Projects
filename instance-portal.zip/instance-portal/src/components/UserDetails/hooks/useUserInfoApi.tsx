import { useCallback, useState } from 'react'
import axios from 'axios'
import { ApiResponse, UserInfo, userRoles } from '../types/UserInfo'
import appConfig from 'app.config'
import Toast from '@sharedComponents/Toast'
import { printErrorStack } from '@utils/index'
import { USER_MESSAGES } from '@constants/modalConstant'
import { FAILURE_MESSAGES } from '@constants/permissionConstants'

export interface UserInfoResponse {
  data: UserInfo
}

export const userInfoApiUrl = `${appConfig.api}/user-management/api/v1/as/users`
export const adminRoleUrl = `${appConfig.api}/user-management/api/v1/as/users/admin`
export const getAllRolesUrl = `${appConfig.api}/user-management/api/v1/as/roles`

export function updateActiveStateUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/as/users/update-state/${id}`
}

export function getUserRoleUrl(profileId: string): string {
  return [userInfoApiUrl, profileId, 'roles'].join('/')
}

export default function useUserInfoApi() {
  const [userInfoData, setUserInfoData] = useState<UserInfo | null>(null)
  const [userInfoErrorCode, setUserInfoErrorCode] = useState<string | null>('')
  const [userInfoError, setUserInfoError] = useState<string | null>('')
  const [defaultRoles, setDefaultRoles] = useState<userRoles | null>(null)
  const [loading, setLoading] = useState<boolean>(true)

  const getUserInfoWithId = useCallback(async (profileId: string) => {
    try {
      setLoading(true)
      setUserInfoError('')
      const { data: response } = await axios.get<ApiResponse<UserInfo>>(
        `${userInfoApiUrl}\\${profileId}`
      )
      setUserInfoData(response.data)
      setLoading(false)
      return response?.data
    } catch (error) {
      setLoading(false)
      setUserInfoErrorCode(error?.response?.data?.code || 'General')
      setUserInfoError(
        error?.response?.data?.error.message || FAILURE_MESSAGES.GENERAL_FAILURE
      )
    } finally {
      setLoading(false)
    }
  }, [])

  const getOrgUserRoles = useCallback(async (profileId: string) => {
    try {
      setUserInfoError('')
      const url = `${getUserRoleUrl(profileId)}`
      const { data: response } = await axios.get<userRoles>(url)
      setDefaultRoles(response)
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setUserInfoError(error.message)
      } else {
        setUserInfoError('unexpected error')
      }
    }
  }, [])

  const updateAdminRole = useCallback(
    async (profileId: string, adminRole: boolean) => {
      try {
        setUserInfoError('')
        const { data: response } = await axios.put<ApiResponse<userRoles>>(
          `${adminRoleUrl}\\${profileId}`,
          adminRole
        )
        setUserInfoError(null)
        return response?.data
      } catch (error) {
        if (axios.isAxiosError(error)) {
          setUserInfoError(error.message)
        } else {
          setUserInfoError('unexpected error')
        }
      }
    },
    []
  )

  const getAllOrgRoles = useCallback(async () => {
    try {
      setUserInfoError('')
      const { data: response } = await axios.get(getAllRolesUrl)
      return response?.data
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setUserInfoError(error.message)
      } else {
        setUserInfoError('unexpected error')
      }
    }
  }, [])

  const updateInactiveRole = async (profileId: string) => {
    try {
      const { data: response } = await axios.put<ApiResponse<any>>( // any to be updated as per the response
        updateActiveStateUrl(profileId)
      )
      Toast('success', USER_MESSAGES.USER_INFO_UPDATED)
    } catch (error) {
      if (error.response?.data?.error.additionalData) {
        Toast('error', error.response?.data?.error.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }

  return {
    userInfoData,
    userInfoError,
    userInfoErrorCode,
    setUserInfoData,
    getUserInfoWithId,
    getOrgUserRoles,
    defaultRoles,
    updateAdminRole,
    getAllOrgRoles,
    updateInactiveRole,
    loading
  }
}
