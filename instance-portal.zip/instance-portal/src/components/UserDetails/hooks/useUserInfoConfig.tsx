import React, { ReactElement, useEffect, useMemo, useState } from 'react'
import { IUserDetailsResult, UserInfo } from '../types/UserInfo'
import Switch from '@sharedComponents/Switch'
import useUserInfoApi from './useUserInfoApi'
import FancyToast from '@sharedComponents/Toast'
import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import appConfig from 'app.config'
import {
  CUSTOM_TYPE,
  MANAGE_USER_DETAILS_CONSTANTS
} from '@constants/modalConstant'
import NewStatusBox from '@sharedComponents/StatusFancy'
import { getUserEmail } from '@utils/auth'
import Modal from '@sharedComponents/Modal'
import CustomButton from '@sharedComponents/Button'
import styles from '../index.module.css'
export default function useUserCards(defaultRoles) {
  const [isStatusModalOpen, setStatusModalOpen] = useState(false)
  const [isRoleModalOpen, setRoleModalOpen] = useState(false)

  const { updateAdminRole, userInfoError, updateInactiveRole } =
    useUserInfoApi()
  const TimeWithCustomFormat = WithCustomFormat(Time)
  const [init, setInit] = useState<boolean>()

  useEffect(() => {
    if (userInfoError) {
      FancyToast('error', MANAGE_USER_DETAILS_CONSTANTS.ERROR)
    } else if (userInfoError === null) {
      FancyToast('success', MANAGE_USER_DETAILS_CONSTANTS.SUCCESS)
    }
  }, [userInfoError])

  function statusElement(status: boolean): ReactElement {
    const enabled = status ? 'true' : 'false'
    const emailVerificationStatus: any = {
      true: { title: 'active', variant: 'success' },
      false: { title: 'inactive', variant: 'warning' }
    }
    return <NewStatusBox status={emailVerificationStatus[enabled].title} />
  }

  const onSwitchChange = async (
    event: React.ChangeEvent<HTMLInputElement>,
    profileId: string
  ) => {
    try {
      const newAdminRole = event.target.checked
      await updateAdminRole(profileId, newAdminRole)
      setInit(!init)
    } catch (userInfoError) {
      console.log('userInfoError')
    }
  }

  const onInActiveToggle = async (
    event: React.ChangeEvent<HTMLInputElement>,
    profileId: string
  ) => {
    try {
      await updateInactiveRole(profileId)
      setInit(!init)
    } catch (userInfoError) {
      console.log('userInfoError')
    }
  }

  function SwitchElement(isAdmin, profileId, email): ReactElement {
    return (
      <Switch
        size="small"
        checked={isAdmin}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setRoleModalOpen(true)
        }
        disabled={getUserEmail() === email}
        label={undefined}
      />
    )
  }
  const renderStatusModal = (userInfo) => {
    const status = userInfo.enabled
    const title = status ? 'Inactivate User' : 'Activate User'
    const text = status
      ? 'Do you wish to Inactivate User?'
      : 'Do you wish to Activate User?'
    return (
      <Modal
        type={CUSTOM_TYPE}
        title={title}
        titleSize="h3"
        onToggleModal={() => {
          setStatusModalOpen(false)
        }}
        isOpen={isStatusModalOpen}
      >
        {text}
        <div className={styles.footer}>
          <CustomButton
            color="primary"
            variant="contained"
            className={`mt-1 ${styles.confirmButton}`}
            onClick={(event) => {
              onInActiveToggle(event, userInfo.id)
              setStatusModalOpen(false)
            }}
          >
            Confirm
          </CustomButton>
        </div>
      </Modal>
    )
  }
  const renderRoleModal = (isAdmin, userInfo) => {
    const title = isAdmin ? 'Unassign Admin role' : 'Assign Admin role'
    const text = isAdmin
      ? 'Do you wish to Unassign user as Admin?'
      : 'Do you wish to Assign user as Admin?'
    return (
      <Modal
        type={CUSTOM_TYPE}
        title={title}
        titleSize="h3"
        onToggleModal={() => {
          setRoleModalOpen(false)
        }}
        isOpen={isRoleModalOpen}
      >
        {text}
        <div className={styles.footer}>
          <CustomButton
            color="primary"
            variant="contained"
            className={`mt-1 ${styles.confirmButton}`}
            onClick={(event) => {
              onSwitchChange(event, userInfo.id)
              setRoleModalOpen(false)
            }}
          >
            Confirm
          </CustomButton>
        </div>
      </Modal>
    )
  }

  const userCards = useMemo(
    () => [
      {
        title: 'Information',
        isEditable: false,
        fields: [
          {
            type: 'text',
            name: 'email',
            previewTitle: 'Email address',
            getValue: (userInfo: UserInfo) => {
              return userInfo?.email || ''
            }
          },
          {
            type: 'text',
            name: 'allowedRoles',
            previewTitle: 'Role',
            getValue: () => {
              if (
                defaultRoles?.roles.filter((role) => role.name === 'admin')
                  .length > 0
              ) {
                return 'Admin'
              } else {
                return '-'
              }
            }
          },
          {
            type: 'text',
            name: 'state',
            previewTitle: 'Status',
            getValue: (userInfo: IUserDetailsResult) => {
              return (
                <>
                  <Switch
                    size="small"
                    defaultChecked={false}
                    checked={userInfo?.enabled || false}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
                      setStatusModalOpen(true)
                    }
                    label={''}
                    disabled={getUserEmail() === userInfo?.email}
                  />
                  {statusElement(userInfo.enabled)}
                  {renderStatusModal(userInfo)}
                </>
              )
            }
          },
          {
            type: 'text',
            name: 'userAcceptDate',
            previewTitle: 'Verification date',
            getValue: (userInfo: UserInfo) => {
              return userInfo?.attributes.INVITATION_ACCEPTED_ON || [] ? (
                <TimeWithCustomFormat
                  date={userInfo?.attributes.INVITATION_ACCEPTED_ON}
                  customFormat={appConfig.customization.dateFormat}
                />
              ) : (
                ''
              )
            }
          },
          {
            type: 'text',
            name: 'createdDate',
            previewTitle: 'Invitation date',
            getValue: (userInfo: UserInfo) => {
              return userInfo?.attributes.CREATED_DATE || [] ? (
                <TimeWithCustomFormat
                  date={userInfo?.attributes.CREATED_DATE || []}
                  customFormat={appConfig.customization.dateFormat}
                />
              ) : (
                ''
              )
            }
          }
        ]
      }
    ],
    [defaultRoles, isStatusModalOpen, isRoleModalOpen]
  )
  return { userCards, init }
}
