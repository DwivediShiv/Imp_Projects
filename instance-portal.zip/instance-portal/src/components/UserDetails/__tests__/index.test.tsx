/* eslint-disable testing-library/no-debugging-utils */
import React from 'react'
import { render, screen } from '@testing-library/react'
import user from '@testing-library/user-event'
import UserDetails from '..'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'
import { userInfo } from '../msw/userInfoData'

const mockRouterBack = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack
  })
}))

const userInfoData = {
  id: 'eebdea82-e578-4436-9149-cb5b42225ef4',
  createdTimestamp: 1695982130279,
  username: 'aakash.s.jadhav@gmail.com',
  enabled: true,
  totp: false,
  emailVerified: true,
  email: 'aakash.s.jadhav@gmail.com',
  attributes: {
    COUNTRY: [''],
    CREATED_BY: ['aakash.jadhav@nagarro.com'],
    CREATED_DATE: ['2023-09-29T10:08:35Z'],
    INVITATION_ACCEPTED_ON: ['2023-09-29T10:08:50Z'],
    LAST_LOGIN: ['2023-09-29 10:09:03.275392913 +0000 UTC'],
    LIMIT_CONSUMED: ['0'],
    ORG_ID: ['00000000-0000-0000-0000-000000000000'],
    ROLES_WALLET: [''],
    SPEND_LIMIT: ['0'],
    STATE: ['Verified'],
    UPDATED_BY: ['aakash.jadhav@nagarro.com'],
    UPDATE_DATE: ['2023-09-29T10:08:50Z']
  },
  disableableCredentialTypes: [],
  requiredActions: [],
  access: {
    impersonate: true,
    manage: true,
    manageGroupMembership: true,
    mapRoles: true,
    view: true
  }
}

jest.mock('@core/context/Authorize')

jest.mock('../hooks/useUserInfoApi', () => ({
  __esModule: true,
  default: () => ({
    userInfoData,
    getUserInfoWithId: jest.fn(),
    getOrgUserRoles: jest.fn()
  })
}))

interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

function renderComponent(options: RenderOptions) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin
  })
  render(<UserDetails userId={'eebdea82-e578-4436-9149-cb5b42225ef4'} />)
}

describe('User profile ', () => {
  it('login component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isLogin: false,
        isAdmin: false
      }
    })

    expect(await screen.findByText('Account Required')).toBeInTheDocument()

    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('component should render if authorized', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })

    screen.logTestingPlaygroundURL()
    expect(await screen.findByText('Information')).toBeInTheDocument()

    expect(await screen.findByRole('heading', { level: 3 })).toHaveTextContent(
      'aakash.s.jadhav@gmail.com'
    )
  })

  it('Render User Info data fields', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })

    // Check all the elements are rendered

    const userEmail = await screen.findByText(/Email address/i)
    const status = await screen.findByText(/Status/i)
    const verificationDate = await screen.findByText(/Verification date/i)
    const invitationDate = await screen.findByText(/Invitation date/i)
    const userRole = await screen.findByTestId('allowedRoles')

    expect(userEmail).toBeInTheDocument()
    expect(userRole).toBeInTheDocument()
    expect(status).toBeInTheDocument()
    expect(verificationDate).toBeInTheDocument()
    expect(invitationDate).toBeInTheDocument()
  })

  it('handles back button', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })

    expect(await screen.findByRole('heading', { level: 3 })).toBeInTheDocument()

    const backButton = await screen.findByLabelText(/go back/i)

    await user.click(backButton)
    expect(mockRouterBack).toHaveBeenCalledTimes(1)
  })
})

describe('check fields User Rows', () => {
  it('should check the role ', async () => {
    const u = await userInfo
    const roles = u.allowedRoles
    expect(roles).toBe('Admin')
  })

  it('should check the user Email ', async () => {
    const u = await userInfo
    const userEmail = u.email
    expect(userEmail).toBe('aakash.s.jadhav@gmail.com')
  })
})
