import { UserInfo } from '../types/UserInfo'

export const userInfo: UserInfo = {
  id: 37,
  org_id: '00000000-0000-0000-0000-000000000000',
  userAcceptDate: '2023-09-29T10:08:50.365269Z',
  userInviteDate: '2023-09-29T10:08:35.594447Z',
  email: 'aakash.s.jadhav@gmail.com',
  allowedRoles: 'Admin',
  profileId: 'eebdea82-e578-4436-9149-cb5b42225ef4',
  state: 'Verified',
  createdDate: '2023-09-29T10:08:35.594447Z',
  createdBy: 'aakash.jadhav@nagarro.com'
}
