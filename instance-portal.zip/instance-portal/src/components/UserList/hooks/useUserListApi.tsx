import React, { useCallback, useState } from 'react'
import axios, { AxiosResponse } from 'axios'
import { ApiResponse, UserDetail, UserList } from '../types/UserList'
import appConfig from 'app.config'
import { SELECTION_CONSTANTS } from '@constants/constants'
import { buildUrlWithQueryParams } from '@utils/url'
import Toast from '@sharedComponents/Toast'
import { USER_MESSAGES } from '@constants/modalConstant'
import { printErrorStack } from '@utils/index'
import { ERROR_UNAUTH } from '@constants/permissionConstants'
export interface UserListResponse {
  data: UserList
}

export let userListApiUrl = `${appConfig.api}/user-management/api/v1/as/user-list`

export function getDeleteUserUrl(email: string) {
  return `${appConfig.api}/user-management/api/v1/as/user-list/delete-user/${email}`
}

export function getResendInviteURL(email: string): string {
  return `${appConfig.api}/user-management/api/v1/as/resend-invite/${email}`
}

export default function useUserListApi() {
  const [userListData, setUserListData] = useState<UserDetail | null>(null)
  const [userListError, setUserListError] = useState<string | null>('')
  const [userListErrorCode, setUserListErrorCode] = useState<string | null>('')
  const [userListTotal, setUserTotal] = useState<number>(0)

  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>()

  const fetchUserList = useCallback(
    async ({
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterUserRole,
      setIsInitialLoader
    }) => {
      try {
        const urlParams: Record<string, string | string[]> = {}
        setUserListError('')
        setUserTotal(0)
        setIsLoading(true)

        userListApiUrl = `${appConfig.api}/user-management/api/v1/as/user-list`

        if (page) {
          urlParams.page = page
        }

        if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
          urlParams.state = status
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.email = searchValue
        }

        const filterUserRoleParam = Object.keys(filterUserRole).filter(
          (key) => filterUserRole[key]
        )

        if (filterUserRoleParam?.length) {
          urlParams.roles = filterUserRoleParam
        }

        // userListApiUrl = buildUrlWithQueryParams(userListApiUrl, urlParams)
        const { data: response } = await axios.post<ApiResponse<UserDetail>>(
          userListApiUrl,
          urlParams
        )

        if (response.filterCriterias) {
          setFilterCriterias(response.filterCriterias)
        }
        setUserListData(response.data)
        setUserTotal(response.totalRecord)
      } catch (error) {
        setUserListErrorCode(error?.response?.data?.code || 'General')
        if (axios.isAxiosError(error)) {
          setUserListError(error?.response?.data?.error)
        } else {
          setUserListError('unexpected error')
        }
      } finally {
        setIsLoading(false)
        setIsInitialLoader(false)
      }
    },
    []
  )

  function getExportUserUrlParams(
    sortBy,
    sortOrder,
    status,
    searchValue,
    filterUserRole
  ): any {
    const urlParams: Record<string, string | string[]> = {}

    if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
      urlParams.state = status
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    if (searchValue !== '') {
      urlParams.email = searchValue
    }

    const filterUserRoleParam = Object.keys(filterUserRole).filter(
      (key) => filterUserRole[key]
    )

    if (filterUserRoleParam?.length) {
      urlParams.roles = filterUserRoleParam
    }
    return urlParams
  }

  async function exportUserList(
    sortBy,
    sortOrder,
    status,
    searchValue,
    filterUserRole
  ): Promise<string> {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: `${appConfig.api}/user-management/api/v1/as/user-list/export`,
        data: getExportUserUrlParams(
          sortBy,
          sortOrder,
          status,
          searchValue,
          filterUserRole
        )
      })
      return response.data
    } catch (error) {
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH)
        return
      }
      console.log(error)
    }
  }

  async function deleteUser(emailId: string): Promise<any> {
    try {
      const response: AxiosResponse = await axios({
        method: 'DELETE',
        url: getDeleteUserUrl(emailId)
      })
      Toast(
        'success',
        (
          <>
            The admin <b>{emailId}</b> has been removed successfully.
          </>
        ) as unknown as string
      )
    } catch (error) {
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH_DELETE_USER)
      } else if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_REMOVE_ADMIN)
        printErrorStack(error)
      }
    }
  }

  async function resendInvite(emailId: string): Promise<any> {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: getResendInviteURL(emailId)
      })
      Toast('success', USER_MESSAGES.USER_INVITED)
    } catch (error) {
      if (error?.response?.data?.code === ERROR_UNAUTH) {
        Toast('error', USER_MESSAGES.ERROR_UNAUTH_USER_INVITE)
      } else if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_RESEND_ADMIN_INVITE)
        printErrorStack(error)
      }
    }
  }

  return {
    userListData,
    userListError,
    userListErrorCode,
    setUserListData,
    exportUserList,
    fetchUserList,
    userListTotal,
    filterCriterias,
    deleteUser,
    resendInvite
  }
}
