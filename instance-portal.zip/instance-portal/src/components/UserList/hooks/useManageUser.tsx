import React, { useMemo, useState } from 'react'
import { Configuration, UserDetail } from '../types/UserList'
import { SELECTION_CONSTANTS, STATE_CONSTANTS } from '@constants/constants'
import useUserListApi from './useUserListApi'
import appConfig from 'app.config'
import Delete from '@images/deleteicon.svg'
import Mail from '@images/mailreset.svg'
import { ModalFieldValue } from '@type/Modal'
import { hasSelection } from '@sharedComponents/CustomTableList/hook/useCustomTableList'
export const useManageUser = () => {
  const [page, setPage] = useState(1)
  const [sortBy, setSortBy] = useState<string>('')
  const [sortValue, setsortValue] = useState<string>('')
  const [sortOrder, setSortOrder] = useState<string>('')
  const [status, setStatus] = useState<string>('')
  const [searchValue, setSearchValue] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>()
  const [isInitialLoader, setIsInitialLoader] = useState<boolean>(true)
  const [refreshList, setRefreshList] = useState<number>(0)
  const [tabIndex, setTabIndex] = useState<number>(0)
  const [filterUserRole, setFilterUserRole] = useState<Record<string, boolean>>(
    {}
  )
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalFieldValue, setModalFieldValue] = useState<ModalFieldValue>({
    template: '',
    value: null
  })
  const [init, setInit] = useState<boolean>()
  const { exportUserList, deleteUser, resendInvite } = useUserListApi()
  const handleFilterSelect = (items: Record<string, boolean>, type: 'Role') => {
    setPage(1)
    switch (type) {
      case 'Role':
        setFilterUserRole(items)
        break
    }
  }

  const handleClearFilter = () => {
    setPage(1)
    setSearchValue('')
    setFilterUserRole({})
    // setSortBy('')
    // setSortOrder('')
    // setStatus('')
    // setTabIndex(0)
  }

  function hasFilterApplied() {
    return searchValue !== '' || hasSelection(filterUserRole)
  }

  async function onDelete(row) {
    setModalFieldValue({ template: 'deleteUser', value: row })
    setIsModalOpen(true)
  }

  const UserListConfig: Configuration = useMemo(() => {
    return {
      title: '',
      sortConfig: {
        type: 'fancySort',
        sortOptions: [
          {
            name: 'User Email: A-Z',
            value: 'email-asc'
          },
          {
            name: 'User Email: Z-A',
            value: 'email-desc'
          },
          {
            name: 'Roles: A-Z',
            value: 'allowed_roles-asc'
          },
          {
            name: 'Roles: Z-A',
            value: 'allowed_roles-desc'
          },
          {
            name: 'Invited on: Newest first',
            value: 'created_date-desc'
          },
          {
            name: 'Invited on: Oldest first',
            value: 'created_date-asc'
          },
          {
            name: 'Invited By: A-Z',
            value: 'created_by-asc'
          },
          {
            name: 'Invited By: Z-A',
            value: 'created_by-desc'
          },
          {
            name: 'Status: A-Z',
            value: 'state-asc'
          },
          {
            name: 'Status: Z-A',
            value: 'state-desc'
          }
        ]
      },
      searchConfig: {
        type: 'search',
        name: 'search',
        placeholder: 'Search',
        searchValue
      },
      exportConfig: {
        exportFn: () =>
          exportUserList(
            sortBy,
            sortOrder,
            status,
            searchValue,
            filterUserRole
          ),
        fileName: 'userList.csv'
      },
      refreshConfig: {
        name: 'Refresh list',
        handleRefreshList: () => setRefreshList(Math.random())
      },
      columns: [
        {
          id: 'email',
          title: 'Email address',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'email',
          class: 'email',
          rowConfig: {
            cellType: 'clickableField',
            clickable: (row) => {
              return (
                row.state === STATE_CONSTANTS.VERIFIED ||
                row.state === STATE_CONSTANTS.INACTIVE
              )
            },
            value: 'email',
            onClick: (row) => {
              return `/userdetails/${row.profileId}`
            }
          },
          width: '424px',
          sortField: 'email'
        },
        {
          id: 'allowedRoles',
          title: 'Roles',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'allowed_roles',
          class: 'allowed_roles',
          rowConfig: {
            cellType: 'default',
            value: 'allowedRoles',
            clickable: 'false',
            class: 'allowedRolesColumn'
          },
          width: '180px',
          sortField: 'allowed_roles'
        },
        {
          id: 'createdDate',
          title: 'Invitation date',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'created_date',
          class: 'createdDate',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'createdDate',
            class: 'createdDateColumn'
          },
          width: '150px',
          sortField: 'created_date',
          allowOverflow: false
        },
        {
          id: 'createdBy',
          title: 'Invited by',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'createdBy',
          rowConfig: {
            cellType: 'default',
            value: 'createdBy',
            class: 'createdByColumn'
          },
          width: '224px',
          sortField: 'created_by',
          allowOverflow: false
        },
        {
          id: 'state',
          title: 'Status',
          type: 'tableHeader',
          sortable: false,
          sortBy: 'state',
          rowConfig: {
            cellType: 'fancyStatusField',
            value: 'state',
            class: 'statusColumn'
          },
          width: '110px',
          sortField: 'state',
          allowOverflow: false
        },
        {
          id: 'actions',
          title: 'Actions',
          type: 'tableHeader',
          sortable: false,
          rowConfig: {
            cellType: 'actions',
            actions: [
              {
                type: 'icon',
                image: Mail,
                clickable: (row: UserDetail) => {
                  return row.state === STATE_CONSTANTS.INVITED
                },
                onClick: (row: UserDetail) => {
                  resendInvite(row.email)
                }
              },
              {
                type: 'icon',
                image: Delete,
                clickable: (row: any) => {
                  return (
                    row.state === STATE_CONSTANTS.INVITED ||
                    row.state === STATE_CONSTANTS.INACTIVE
                  )
                },
                onClick: (row: any) => {
                  onDelete(row)
                }
              }
            ]
          },
          allowOverflow: false
        }
      ],
      tabConfig: {
        defaultTab: 0,
        tabList: [
          {
            title: 'All',
            key: 'all',
            value: '',
            index: 0
          },
          {
            title: 'Invited',
            key: 'invited',
            value: 'invited',
            index: 2,
            icon: 'warning'
          },
          {
            title: 'Verified',
            key: 'verified',
            value: 'verified',
            index: 1,
            icon: 'success'
          },
          {
            title: 'Inactive',
            key: 'inactive',
            value: 'inactive',
            index: 2,
            icon: 'disabled'
          }
        ]
      },
      filterConfig: {
        clearFilters: handleClearFilter,
        filters: [
          {
            id: 'Roles',
            inputName: 'Roles',
            label: 'Roles',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterUserRole,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterUserRole,
            onChange: (items) => handleFilterSelect(items, 'Role')
          }
        ]
      }
    }
  }, [searchValue, filterUserRole, status, sortBy, sortOrder])

  const {
    tabConfig: { tabList = [] }
  } = UserListConfig

  const handleTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setPage(1)
    setStatus(tabList[newValue].value)
    setTabIndex(newValue)
  }

  const handlePageChange = (page) => {
    setPage(page)
  }

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    setSortBy(column.sortField)
    setSortOrder(sortDirection)
  }

  const handleSortOption = async (sortOption: string) => {
    setsortValue(sortOption)
    const sortSelection = sortOption.split('-')
    setSortBy(sortSelection[0])
    setSortOrder(sortSelection[1])
  }

  const handleOnSearch = (e) => {
    setPage(1)
    setSearchValue(e.target.value)
  }

  async function submitModal() {
    const { email } = modalFieldValue.value
    await deleteUser(email)
    setIsModalOpen(false)
    setInit(!init)
  }

  async function handleUserCreation() {
    setPage(1)
  }

  return {
    searchValue,
    handleOnSearch,
    handleSortChange,
    handleSortOption,
    handleTabChange,
    handlePageChange,
    tabIndex,
    status,
    sortValue,
    sortBy,
    sortOrder,
    filterUserRole,
    UserListConfig,
    page,
    isLoading,
    setIsLoading,
    hasFilterApplied,
    isModalOpen,
    setIsModalOpen,
    submitModal,
    handleUserCreation,
    init,
    isInitialLoader,
    setIsInitialLoader,
    refreshList,
    modalFieldValue
  }
}
