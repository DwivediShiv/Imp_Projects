import React from 'react'
import { setupGetUserListDataHandler } from '../msw/userListHandler'
import user from '@testing-library/user-event'
import { userList } from '../msw/userListData'
import ManageUser from '..'
import { AuthorizeProviderValue, useAuthorize } from '@core/context/Authorize'
import { render, screen, waitFor } from '@testing-library/react'

jest.mock('next/router', () => ({
  useRouter: jest.fn()
}))

jest.mock('@core/context/Authorize')
interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

function renderComponent(options: RenderOptions) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin, isAdmin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin,
    isAdmin
  })

  render(<ManageUser />)
}

describe('user list', () => {
  beforeEach(() => {
    setupGetUserListDataHandler()
  })

  it('admin component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isAdmin: false
      }
    })
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('component should render if authorized', async () => {
    renderComponent({
      authorize: {
        isAdmin: true,
        isLogin: true
      }
    })

    // expect(await screen.findByText('Manage Users'))
  })
})

describe('Rendering Empty Data Table', () => {
  it('Should not display a table when no data is available', async () => {
    renderComponent({
      authorize: {
        isLogin: true,
        isAdmin: true
      }
    })
    const table = screen.queryByRole('table')
    expect(table).not.toBeInTheDocument()
  })
})

describe('count User Rows', () => {
  it('should count the correct number of user rows', async () => {
    const u = await userList
    const rowCount = u.data.length
    expect(rowCount).toBe(13)
  })
})

describe('pagination', () => {
  it('return paginated data for the first page', async () => {
    const mockData = await userList

    // Validate the total record count
    expect(mockData.totalRecord).toBe(13)

    // Get the data for the first page (first 10 items)
    const firstPageData = mockData.data.slice(0, 10)

    // Perform checks for each row in the first page
    firstPageData.forEach((row, index) => {
      expect(row.id).toBe(index + 1)
    })
  })

  it('return paginated data for the second page', async () => {
    const mockData = await userList
    // expect(userList.data).toHaveBeenCalled()
    expect(mockData.totalRecord).toBe(13)

    // Get the data for the second page (remaining 3 items)
    const secondPageData = mockData.data.slice(10)

    // Perform checks for each row in the second page
    secondPageData.forEach((row, index) => {
      expect(row.id).toBe(index + 11)
    })
  })
})
