import { rest } from 'msw'
import { server } from '@utils/msw'
import { ApiResponse, MswHandlerProps, UserList } from '../types/UserList'
import { userList } from './userListData'

export function setupGetUserListDataHandler(props?: MswHandlerProps<UserList>) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(
    'https://api.nagarro.acentrik.io/user-management/api/v1/as/user-list',
    async (_, res, ctx) => {
      let json: ApiResponse<UserList>
      const data = userList

      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
