import {
  Column,
  ExportConfig,
  FilterConfig,
  SearchConfig,
  TabConfig
} from '@sharedComponents/CustomTableList/types/CustomTableListTypes'

export interface UserDetail {
  id: number
  org_id?: string
  email: string
  allowedRoles: string
  state?: string
  userInviteDate?: string
  createdBy?: string
  sortBy?: string
  sortOrder?: string
  createdDate?: string
  activatedOn?: string
  roles?: string
}

export interface UserList {
  data: UserDetail[]
  totalRecord: number
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
  totalRecord?: number
  filterCriterias?: Record<string, string[]>
}

// TODO: Move to `common-js`
export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}

export interface Configuration {
  title: string
  columns: Column[]
  tabConfig: TabConfig
  exportConfig: ExportConfig
  searchConfig: SearchConfig
  filterConfig: FilterConfig
}
