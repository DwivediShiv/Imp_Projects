import React, { useCallback, useEffect, useState } from 'react'
import classNames from 'classnames'

import styles from './index.module.css'
import CustomTableList from '@sharedComponents/CustomTableList'
import { useManageUser } from './hooks/useManageUser'
import useUserListApi from './hooks/useUserListApi'
import Container from '@sharedComponents/Container'
import { useAuthorize } from '@core/context/Authorize'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_ADMIN,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import InviteUserModal from '../UserAdd/components/InviteUserModal'
import Modal from '@sharedComponents/Modal'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import Button from '@sharedComponents/Button'
import { debounce } from 'lodash'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Loader from '@sharedComponents/CustomLoader'
import Warning from '../WarningMessage'
import { TransformedFilterCriterias } from '@sharedComponents/CustomTableList/types/CustomTableListTypes'
import ExportTable from '@sharedComponents/ExportTable'
const ManageUser = () => {
  const { isAdmin, isLogin } = useAuthorize()
  const {
    page,
    handlePageChange,
    handleTabChange,
    sortValue,
    sortBy,
    sortOrder,
    searchValue,
    status,
    tabIndex,
    handleSortChange,
    handleSortOption,
    handleOnSearch,
    isLoading,
    setIsLoading,
    filterUserRole,
    hasFilterApplied,
    UserListConfig: userListConfig,
    setIsModalOpen,
    isModalOpen,
    submitModal,
    init,
    isInitialLoader,
    setIsInitialLoader,
    refreshList,
    modalFieldValue
  } = useManageUser()

  const {
    userListData,
    userListError,
    userListErrorCode,
    fetchUserList,
    userListTotal,
    filterCriterias
  } = useUserListApi()

  const debouncefetch = useCallback(
    debounce((params) => {
      fetchUserList(params)
    }, 500),
    []
  )

  const [transformedFilterCriteria, setTransformedFilterCriteria] =
    useState<TransformedFilterCriterias>({})

  useEffect(() => {
    const params = {
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterUserRole,
      setIsInitialLoader
    }
    debouncefetch(params)
  }, [
    fetchUserList,
    page,
    searchValue,
    setIsLoading,
    sortBy,
    sortOrder,
    status,
    filterUserRole,
    init,
    isLogin,
    setIsInitialLoader,
    refreshList
  ])

  useEffect(() => {
    const data = filterCriterias
    const updatedData = {}
    for (const key in data) {
      if (data[key]?.length) {
        const updatedKey = Object.fromEntries(
          [...data[key]].map((item) => [item, filterUserRole[item] || false])
        )
        updatedData[`${key}`] = updatedKey
      }
    }
    setTransformedFilterCriteria(updatedData)
  }, [filterCriterias])

  const refreshListHandler = () => {
    fetchUserList({
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterUserRole,
      setIsInitialLoader
    })
  }

  const renderUserListData = () => {
    if (userListError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = FAILURE_MESSAGES.GENERAL_FAILURE

      const isUnauthorize = userListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    return (
      <>
        <CustomTableList
          configuration={userListConfig}
          data={userListData}
          totalRecord={userListTotal}
          isLoading={isLoading}
          paginationSize={10}
          tabIndex={tabIndex}
          sortValue={sortValue}
          sortBy={sortBy}
          sortOrder={sortOrder}
          handlePageChange={handlePageChange}
          handleOnTabChange={handleTabChange}
          page={page}
          handleSortChange={handleSortChange}
          handleSortOption={handleSortOption}
          state={status}
          handleOnSearch={handleOnSearch}
          filterCriterias={transformedFilterCriteria}
          searchValue={searchValue}
          hasFilterApplied={hasFilterApplied}
          noDataText={
            <>
              <span>No admins invited yet.</span>
            </>
          }
          noDataAction={<InviteUserModal refreshHandler={refreshListHandler} />}
        />
        <Modal
          type={CUSTOM_TYPE}
          title="Remove admin"
          titleSize="h3"
          onToggleModal={() => {
            setIsModalOpen(false)
          }}
          isOpen={isModalOpen}
        >
          Are you sure you want to remove the admin with the email address{' '}
          <b>{modalFieldValue.value?.email}</b> ?
          <div className={styles.footer}>
            <Button
              color="primary"
              variant="contained"
              className={`mt-1 ${styles.confirmButton}`}
              onClick={submitModal}
            >
              Confirm
            </Button>
          </div>
        </Modal>
      </>
    )
  }
  return (
    <PrivateRoute>
      {isInitialLoader ? (
        <div className={styles.loader}>
          <Loader />
        </div>
      ) : (
        <Container className={classNames(styles.headerContent, 'container')}>
          <section className={styles.grid}>
            <div className={styles.header}>
              <div>
                {!userListError && (
                  <h3 className={styles.bold}>Manage admin</h3>
                )}
                {<div className={styles.description}>&nbsp;</div>}
              </div>
              <div>
                {isAdmin && (
                  <InviteUserModal refreshHandler={refreshListHandler} />
                )}
                {
                  <ExportTable
                    exportConfig={userListConfig.exportConfig}
                    totalRecord={userListTotal}
                  ></ExportTable>
                }
              </div>
            </div>
          </section>
          {renderUserListData()}
        </Container>
      )}
    </PrivateRoute>
  )
}

export default ManageUser
