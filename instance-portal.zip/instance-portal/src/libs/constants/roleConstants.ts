export const ROLE_USER = 'user'
export const ROLE_CONSUMER = 'consumer'
export const ROLE_PUBLISHER = 'publisher'
export const ROLE_ADMIN = 'admin'
export const ROLE_VALIDATED = 'validated'
export const ROLE_SUPERADMIN = 'super-admin'
export const ROLE_ADMIN_INITIAL = 'A'

export const ALLOWED_ROLES = {
  ADMIN: 'Admin',
  CONSUMER: 'Consumer',
  PUBLISHER: 'Publisher'
}
