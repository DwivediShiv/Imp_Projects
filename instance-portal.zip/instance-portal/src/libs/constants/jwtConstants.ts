export const JWT_LATEST_EXPIRY = 'jwt-latest-expiry'
