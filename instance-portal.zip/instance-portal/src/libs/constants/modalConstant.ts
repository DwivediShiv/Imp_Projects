export const ICON_TYPE = 'ICON_TYPE'
export const CUSTOM_TYPE = 'CUSTOM_TYPE'
export const MODAL_TYPE_ORDER = 'MODAL_TYPE_ORDER'
export const MODAL_TYPE_CONFIRM = 'MODAL_TYPE_CONFIRM'
export const ADD_EDGE_NODE_CONSTANTS = {
  SUCCESS: 'Success. Edge Node has been added.'
}

export const MANAGE_USER_DETAILS_CONSTANTS = {
  SUCCESS: 'Updated successfully!',
  ERROR: 'Unable to save changes. Please try again later.'
}

export const ERROR_MSG =
  'An unexpected error has occurred. Please try again later.'

export const UPDATE_ORG_PROFILE_MSG = {
  SUCCESS: 'Information Updated Successfully',
  ERROR: 'Unable to save changes. Please try again later.'
}

export const USER_MESSAGES = {
  EDGE_NODE_DELETED: 'Edge Node deleted sucessfully',
  USER_INVITED: 'The invitation email has been resent sucessfully.',
  USER_INFO_UPDATED: 'User information updated sucessfully',
  USER_BLOCKED: 'User has been disabled sucessfully',
  USER_UNBLOCKED: 'User has been enabled sucessfully',
  ERROR_COMMON: 'Unexpected error ocurred',
  ERROR_UNAUTH: 'User is unauthorized to perform action',
  ERROR_UNAUTH_CREATE_NODE: 'User is unauthorized to create edge node',
  ERROR_UNAUTH_UPDATE_NODE: 'User is unauthorized to update edge node',
  ERROR_UNAUTH_DELETE_NODE: 'User is unauthorized to delete edge node',
  ERROR_UNAUTH_CREATE_ORG: 'User is unauthorized to create organization',
  ERROR_UNAUTH_DELETE_USER: 'User is unauthorized to delete user',
  ERROR_UNAUTH_USER_INVITE: 'User is unauthorized to invite user',
  ERROR_UNAUTH_DELETE_ORG: 'User is unauthorized to delete organization',
  ERROR_UNAUTH_BLOCK_USER: 'User is unauthorized to block user',
  ERROR_UNAUTH_UNBLOCK_USER: 'User is unauthorized to unblock user',
  ORG_DELETED_FAIL: 'Organization deletion was not successfull',
  ERROR_REMOVE_ADMIN:
    'The admin could not be removed at the moment. Please try again later.',
  ERROR_RESEND_ADMIN_INVITE:
    'The invitation email could not be resent at the moment. Please try again later.'
}
