import appConfig from '../../../app.config'

export const MAX_DECIMALS = 6
export const USDC_DECIMAL = 6
export const WEI_DECIMAL = 18
export const SAMPLE_TYPE_UPLOAD = 'UPLOAD'
export const SAMPLE_TYPE_URL = 'URL'
export const SMALL_DESKTOP_BREAKPOINT = 1280
export const DEFAULT_DOWNLOAD_FILE_NAME = 'download'
export enum IconSize {
  ExtraLarge = 'iconSizeExtraLarge',
  Large = 'iconSizeLarge',
  Medium = 'iconSizeMedium',
  Small = 'iconSizeSmall'
}

export enum IconColor {
  Primary = 'iconColorPrimary',
  Secondary = 'iconColorSecondary',
  Info = 'iconColorInfo'
}
export enum ImageSize {
  Large = 'imageSizeLarge',
  Small = 'imageSizeSmall'
}
export const SUPPORT_EMAIL = appConfig.supportEmail
export const MAILETO_SUPPORT = `mailto:${SUPPORT_EMAIL}`
export const MAXIMUM_NUMBER_OF_PAGES_WITH_RESULTS = 476
export const STATE_DELIST = 1
export const STATE_ACTIVE = [0, 4]
export const START_TRUNCATE = 36
export const END_TRUNCATE = 14
export const DOT = '...'
export const MINIMUM_URL_LENGTH = 20
export const NOTCHED_OUTLINE = 'notchedOutline'
export const SET_AUTOCOMPLETE_EXPAND = 'setAutocompleteExpand'

// Error constants
export const ERROR_EMAIL_ALREADY_EXISTS = {
  CODE: 'EMAIL_ALREADY_EXISTS',
  MESSAGE: 'A user with this email already exists.'
}

export const MESSAGE_ACCOUNT_EXISTING =
  'There is an existing account registered with this email address. Please log in using the same or register a new one.'

export const COMPUTE_OPTION = {
  nodejs: 'NodeJS 16.0.0',
  'python3.7': 'Python 3.7',
  custom: 'Custom Public Docker Image'
}

export const INVITED_USER_STATES = {
  invited: 'Invited',
  accepted: 'Accepted',
  verified: 'Verified',
  dormant: 'Dormant',
  delete: 'Delete'
}

export const TOKEN_SUBJECT_STRING = {
  invite: 'InviteInstanceUser'
}

export const MESSAGE_PASSWORD_NOT_MEET_REQUIREMENT =
  'The password you entered does not meet all the requirements.'

export const PASSWORD_POLICY_INDEX = 5

export const REQUIRED_FIELD = 'Required Field'
export const MAX_100_CHAR_ALLOWED = 'Maximum 100 characters allowed.'
export const MAX_500_CHAR_ALLOWED = 'Maximum 500 characters allowed.'
export const MAX_50_CHAR_ALLOWED = 'Maximum 50 characters allowed.'
export const ENTER_VALID_EMAIL = 'Please enter a valid email address.'
export const MAX_FILE_SIZE_1_MB = 'File size should not exceed 1 MB'

export const STATE_CONSTANTS = {
  ACCEPTED: 'Accepted',
  INACTIVE: 'Inactive',
  ACTIVE: 'Active',
  UNVERIFIED: 'Unverified',
  VERIFIED: 'Verified',
  INVITED: 'Invited',
  PENDING: 'Pending',
  REJECTED: 'Rejected'
}

export const STATUS_CONSTANTS = {
  Pending: { title: 'Pending', variant: 'warning' },
  Rejected: { title: 'Rejected', variant: 'danger' },
  Active: { title: 'Active', variant: 'success' },
  Inactive: { title: 'Inactive', variant: 'disabled' },
  Undefined: { title: 'Undefined', variant: 'disabled' }
}

export const LoginFailed = {
  code: 'ERROR_USER_AUTHENTICATION_FAILED',
  message:
    'Login failed. Please check your business email address / password and try again.'
}

export const SELECTION_CONSTANTS = {
  ALL: 'All'
}

export const ERROR_USER_NOT_FOUND = {
  CODE: 'ERROR_USER_NOT_FOUND',
  MESSAGE: 'User not found'
}
export const STATUS_CODE_INCORRECT_OTP = 'INSTANCE_ADMIN_OTP_INCORRECT'
export const STATUS_CODE_EXPIRED_OTP = 'INSTANCE_ADMIN_OTP_EXPIRED'
export const INVALID_OTP_ERR_MSG = 'Invalid OTP. Please try again.'
export const EXPIRED_OTP_ERR_MSG =
  'OTP has expired. Please resend another OTP and try again.'

export const ACCOUNT_TYPES = {
  AA: 'AA',
  EOA: 'EOA'
}

export const ERROR_MSG =
  'An unexpected error has occurred. Please try again later.'

export const RADIO_BUTTON_OPTIONS = ['disable', 'enable']

export const DEFAULT_FONT = 'Noto Sans'
export const CONFIG_OPTIONS = {
  boolean: ['true', 'false']
}

export const REDEPLOY_CONFIRMATION =
  'Are you sure you want to apply the configuration? This will take approximately 30 minutes to reflect.'

export const REDEPLOY_TITLE = 'Re-Deploy Instance Configuration'

export const VERSION_CHANGE_CONFIRMATION =
  'Your unsaved changes will be lost, Are you sure u want to proceed?'

export const SAVE_TITLE = 'Change Version'

export enum HttpStatusCode {
  Ok = 200
}

export const PURGE_USER = 'Successful. User has been purged'
export const UNPURGE_USER = 'Successful. User has been unpurged'
export const TYPE_PRIVATE = 'private'
export const TYPE_PUBLIC = 'public'
export const TYPE_COMPUTE = 'compute'
export const TYPE_ACCESS = 'access'

export const ACCOUNT_ABSTRACTION_PROVIDERS = {
  BICONOMY: 'biconomy',
  ALCHEMY: 'alchemy'
}

export const DEFAULT_ORG_FIELD_VALUES = {
  ADDRESS: 'optional',
  INDUSTRY: 'Others',
  BLANK: '-'
}

export const GROUP_STATUS_CONSTANTS = {
  ENABLE: 'Enabled',
  DISABLE: 'Disabled'
}
