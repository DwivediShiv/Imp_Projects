export const PERMISSION_BROWSE = 'browse'
export const PERMISSION_CONSUME = 'consume'
export const PERMISSION_PUBLISH = 'publish'
export const PERMISSION_ADMIN = 'admin'
export const GENERAL_FAILURE = 'General Failure'
export const RESTRICTED_ACCESS = 'Restricted Access'
export const ERROR_UNAUTH = 'Error_UnAuthorizedUserAction'
export const DEPLOYMENT_IN_PROGRESS = 'INFO_DEPLOYMENT_IN_PROGRESS'
export const FAILURE_MESSAGES = {
  RESTRICTED_ACCESS: 'Unfortunately you do not have access to this page.',
  GENERAL_FAILURE: `An error occured please try again later ! `
}
