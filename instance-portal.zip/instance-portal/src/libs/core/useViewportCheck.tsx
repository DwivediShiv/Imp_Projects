import { useCallback, useEffect, useState } from 'react'

const useViewportCheck = (inViewDelta?: any) => {
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight
  })
  const [scrollY, setScrollY] = useState<any>()
  const [sections, setSections] = useState<any>([])
  const [lastInViewPort, setLastInViewPort] = useState<any>(-1)

  // register sections
  const addSection = useCallback(
    (section) => {
      setSections((items: any) => {
        const newSections = [...items]
        newSections[section.id] = section

        return newSections
      })
    },
    [setSections]
  )

  const onGotoSection = useCallback(
    (id) => {
      const targetSection = sections[id]

      if (targetSection) {
        window.scrollTo({
          top: targetSection.sectionEl.current.offsetTop,
          behavior: 'smooth'
        })
      }
    },
    [sections]
  )

  const onPrevClick = useCallback(
    (id) => {
      onGotoSection(id - 1)
    },
    [onGotoSection]
  )

  const onNextClick = useCallback(
    (id) => {
      onGotoSection(id + 1)
    },
    [onGotoSection]
  )

  // set window size on resize
  useEffect(() => {
    const onResize = () => {
      setWindowSize(() => ({
        width: window.innerWidth,
        height: window.innerHeight
      }))
    }
    window.addEventListener('resize', onResize)

    return () => {
      window.removeEventListener('resize', onResize)
    }
  }, [])

  useEffect(() => {
    const onScroll = () => {
      setScrollY(window.scrollY)
    }

    document.addEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    const delta = windowSize.height * inViewDelta
    const winTop = 0 + scrollY
    const winBottom = windowSize.height + scrollY

    const inViewBottom = winBottom - delta
    const newSections = [...sections]

    let lastInViewPort = -1

    for (let i = 0; i < sections.length; i++) {
      const section = sections[i]

      const curDomEl = section.sectionEl.current
      if (curDomEl) {
        const elOffsetTop = curDomEl.offsetTop
        if (elOffsetTop < inViewBottom) {
          newSections[i].inViewPort = true
          lastInViewPort = i
        } else {
          newSections[i].inViewPort = false
        }
      }
    }

    setLastInViewPort(lastInViewPort)
  }, [
    inViewDelta,
    scrollY,
    sections,
    setSections,
    windowSize.height,
    setLastInViewPort
  ])

  return {
    windowSize,
    addSection,
    scrollY,
    sections,
    onPrevClick,
    onNextClick,
    onGotoSection,
    lastInViewPort
  }
}

export default useViewportCheck
