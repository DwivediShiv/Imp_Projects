import { ROLE_ADMIN, ROLE_SUPERADMIN } from '@constants/roleConstants'
import { IDLE_TIMEOUT } from '@utils/constants'
import {
  fetchRoles,
  hasAccess,
  isLoggedIn,
  setActive,
  setTabSessionInactive,
  startTimer
} from '@utils/auth'
import appConfig from 'app.config'
import React, {
  useContext,
  useState,
  createContext,
  ReactElement,
  ReactNode,
  useEffect,
  useMemo
} from 'react'
import { getLandingPageUrl } from '@utils/url'

export interface AuthorizeProviderValue {
  isLogin: boolean
  isAdmin: boolean
  isSuperAdmin: boolean
  landingPage: string
  setRedirect: (arg: any) => void
}

const AuthorizeContext = createContext({} as AuthorizeProviderValue)

function AuthorizeProvider({
  children
}: {
  children: ReactNode
}): ReactElement {
  const [isLogin, setIsLogin] = useState<boolean>(false)
  const [isAdmin, setIsAdmin] = useState<boolean>(false)
  const [isSuperAdmin, setIsSuperAdmin] = useState<boolean>(false)
  const [redirect, setRedirect] = useState<boolean>(false)

  let logoutTimeout
  const signoutTime = IDLE_TIMEOUT * 60 * 1000

  useEffect(() => {
    async function setupUserProfile() {
      await fetchRoles()
      setIsLogin(isLoggedIn())
      setIsAdmin(hasAccess(ROLE_ADMIN))
      setIsSuperAdmin(hasAccess(ROLE_SUPERADMIN))
    }
    setupUserProfile()

    return () => null
  }, [isLoggedIn(), redirect])

  const landingPage = useMemo(() => {
    return getLandingPageUrl(isAdmin)
  }, [isAdmin])

  function logout() {
    if (isLogin) setTabSessionInactive()
  }

  function setTimeouts() {
    if (isLogin) logoutTimeout = setTimeout(logout, signoutTime)
  }

  function clearTimeouts() {
    if (isLogin && logoutTimeout) clearTimeout(logoutTimeout)
  }

  useEffect(() => {
    const events = ['mousemove', 'mousedown', 'click', 'scroll', 'keypress']

    const handleEvent = () => {
      clearTimeouts()
      setTimeouts()
      setActive()
    }

    const initEventHandlers = () => {
      events.forEach((event) => window.addEventListener(event, handleEvent))
      window.addEventListener('load', handleEvent)
    }

    const cleanUpEventHandlers = () => {
      events.forEach((event) => window.removeEventListener(event, handleEvent))
      window.removeEventListener('load', handleEvent)
      clearTimeouts()
    }

    initEventHandlers()

    return cleanUpEventHandlers
  }, [isLogin])

  useEffect(() => {
    if (!isLogin) return
    startTimer()
  }, [isLogin])

  return (
    <AuthorizeContext.Provider
      value={
        {
          isLogin,
          isAdmin,
          isSuperAdmin,
          setRedirect,
          landingPage
        } as AuthorizeProviderValue
      }
    >
      {children}
    </AuthorizeContext.Provider>
  )
}

const useAuthorize = (): AuthorizeProviderValue => useContext(AuthorizeContext)

export { AuthorizeProvider, useAuthorize, AuthorizeContext }
export default AuthorizeProvider
