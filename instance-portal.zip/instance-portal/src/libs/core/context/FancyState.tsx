import React, {
  useEffect,
  useState,
  ReactElement,
  createContext,
  useContext,
  ReactNode
} from 'react'
import {
  getOrganizationOption,
  getSelectionOptions
} from '@utils/fancySelectionOption/index'
import { OrganizationOption, SelectionOption } from '@type/SelectionOptions'
import AssetFilters from '@type/AssetFilters'
import { getAssetFilters as getAssetFiltersRequest } from '@utils/assetFiltersUtils'

interface FancyStateValue {
  selectionOptions: any
  getSelectionOptionsByCategory: (category?: string) => SelectionOption[]
  getOrganizationOptions: () => Promise<OrganizationOption[]>
  organizationOptions: OrganizationOption[]
  assetFilters: AssetFilters
  getAssetFilters: () => Promise<void>
}

const FancyStateContext = createContext({} as FancyStateValue)

function FancyStateProvider({
  children
}: {
  children: ReactNode
}): ReactElement {
  const [selectionOptions, setSelectionOptions] = useState([])
  const [organizationOptions, setOrganizationOptions] = useState<
    OrganizationOption[]
  >([])
  const [assetFilters, setAssetFilters] = useState<AssetFilters>(null)

  function getSelectionOptionsByCategory(category?: string): SelectionOption[] {
    if (!category) return selectionOptions
    return (
      selectionOptions?.filter((option: any) => option.category === category) ??
      []
    )
  }

  async function getOrganizationOptions(): Promise<OrganizationOption[]> {
    try {
      const organizationOptions = await getOrganizationOption()
      setOrganizationOptions(organizationOptions)
      return organizationOptions
    } catch (err: any) {
      console.error('Unable to retrieve organizations')
    }
  }

  async function getAssetFilters(): Promise<void> {
    try {
      const _assetFilters = await getAssetFiltersRequest()
      setAssetFilters(_assetFilters)
    } catch (err: any) {
      console.error('Unable to retrieve asset filter criteria')
    }
  }

  useEffect(() => {
    let attempt = 0
    const maxAttempt = 3

    async function getSelectOptions() {
      try {
        const response = await getSelectionOptions()
        setSelectionOptions(response)
      } catch (err: any) {
        if (attempt < maxAttempt) {
          attempt++
          getSelectOptions()
        }
      }
    }
    getAssetFilters()
    getSelectOptions()
    getOrganizationOptions()
  }, [])

  return (
    <FancyStateContext.Provider
      value={{
        selectionOptions,
        getSelectionOptionsByCategory,
        organizationOptions,
        getOrganizationOptions,
        assetFilters,
        getAssetFilters
      }}
    >
      {children}
    </FancyStateContext.Provider>
  )
}

function useFancyState(): FancyStateValue {
  return useContext(FancyStateContext)
}

export { useFancyState }
export default FancyStateProvider
