import { useFancyState } from '@core/context/FancyState'
import { useEffect, useState } from 'react'

export const useOrganizationName = () => {
  const { getOrganizationOptions } = useFancyState()
  const [organizationMap, setOrganizationMap] = useState(null)

  useEffect(() => {
    const getOrgName = async () => {
      const orgOptions = await getOrganizationOptions()
      if (orgOptions?.length) {
        const orgMap = orgOptions.reduce((acc, curr) => {
          return { ...acc, [curr.id]: curr.name }
        }, {})
        setOrganizationMap(orgMap)
      } else {
        setOrganizationMap([])
      }
    }
    getOrgName()
  }, [])

  return { organizationMap }
}
