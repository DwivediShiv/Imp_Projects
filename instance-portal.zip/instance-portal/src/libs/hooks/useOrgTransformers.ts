export const transformDataWithOrgName = (
  response,
  organizationMap,
  key = 'orgId'
) => {
  const dataList = response?.map((item) => {
    return { ...item, orgName: organizationMap[item[key]] }
  })
  return dataList
}

export const tranformedOrgFilters = (orgIdFilter, organizationMap) => {
  const orgFilterList = orgIdFilter?.reduce((acc, curr) => {
    organizationMap[curr] &&
      acc.push({ orgId: curr, orgName: organizationMap[curr] })
    return acc
  }, [])
  return orgFilterList
}

export const getIdByName = (dataMap, name) => {
  return Object.keys(dataMap).find((key) => dataMap[key] === String(name))
}

export const getFilterIds = (dataMap, filterArray): string[] => {
  const orgIds = filterArray?.map((name) => getIdByName(dataMap, name))
  return orgIds
}
