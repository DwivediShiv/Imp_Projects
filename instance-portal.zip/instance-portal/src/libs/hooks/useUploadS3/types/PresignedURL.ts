export interface PresignedURL {
  publicUrl: string
  key: string
  preSignedUrl: string
}
