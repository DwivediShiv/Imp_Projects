import { Menu, MenuItem, Collapse } from '@mui/material'
import React, { ReactElement, useState, useEffect } from 'react'
import styles from './index.module.css'
import ExpandLessIcon from '@images/expandLess.svg'
import ExpandMoreIcon from '@images/expandMore.svg'
import InputField from '@sharedComponents/InputField'
import { accountTruncate } from '@utils/conversion'

function ChipFilter({
  label,
  className,
  disabled,
  filterItems,
  setFilterItems,
  children,
  type
}: {
  label?: string
  className?: string
  disabled?: boolean
  filterItems?: any
  setFilterItems?: React.Dispatch<React.SetStateAction<any>>
  children?: ReactElement
  type?: string
}): ReactElement {
  const [anchorEl, setAnchorEl] = useState(null)
  const [isOpen, setIsOpen] = useState(false)
  const [title, setTitle] = useState('')
  const filterKeys = filterItems && Object.keys(filterItems)
  const [hasFilterItem, setHasFilterItem] = useState<boolean>(false)

  useEffect(() => {
    let count = 0
    if (filterKeys && filterKeys.length) {
      filterKeys.map((key) => {
        // TODO: do not count for tree title (algorithm, dataset)
        if (filterItems[key]) {
          count++
        }
      })
    }

    setHasFilterItem(count > 0)

    setTitle(`${label}${count ? ` • ${count}` : ''}`)
  }, [filterItems, label])

  const handleClick = (event) => {
    if (disabled) {
      return
    }
    setAnchorEl(event.currentTarget)
    setIsOpen(Boolean(event.currentTarget))
  }

  const handleClose = () => {
    setAnchorEl(false)
    setIsOpen(false)
  }

  const handleChange = (event, key) => {
    setFilterItems &&
      setFilterItems({
        ...filterItems,
        [key]: event.target.checked
      })
  }

  return (
    <>
      <div
        className={`${className} ${styles.chipContainer} ${
          hasFilterItem ? styles.active : ''
        } ${disabled ? styles.disabled : ''} ${
          anchorEl ? styles.openStyle : ''
        }`}
        onClick={handleClick}
      >
        <span>{title}</span>
        {isOpen ? (
          <ExpandLessIcon
            className={`iconColorFillText2 ${styles.dropDownIcon} iconSizeMedium ml-2`}
          />
        ) : (
          <ExpandMoreIcon
            className={`iconColorFillText2 ${styles.dropDownIcon} iconSizeMedium ml-2`}
          />
        )}
      </div>
      <Menu
        id="simple-menu"
        anchorEl={anchorEl}
        keepMounted
        open={isOpen}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left'
        }}
        TransitionComponent={Collapse}
        className={styles.menu}
        classes={{ paper: styles.menuPaper, list: styles.menuList }}
      >
        {children}
        {!children &&
          filterKeys?.map((key) => {
            return (
              <div key={key}>
                <MenuItem className={styles.menuItem} disableRipple>
                  <InputField
                    fancyInput="fancy-checkbox"
                    name={key}
                    label={
                      <span>
                        {label.includes('Wallet') ? accountTruncate(key) : key}
                      </span>
                    }
                    type="customCheckbox"
                    defaultChecked={filterItems[key]}
                    onChange={(e) => handleChange(e, key)}
                    onClick={(e) => e.stopPropagation()}
                  />
                </MenuItem>
              </div>
            )
          })}
      </Menu>
    </>
  )
}

export default ChipFilter
