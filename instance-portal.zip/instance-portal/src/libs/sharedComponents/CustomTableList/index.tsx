import React, { ReactElement } from 'react'
import styles from './index.module.css'
import Refresh from '@images/refresh.svg'
import CustomIconicCard, {
  CustomIconicCardState,
  CustomIconicCardSize
} from '../IconicCard'
import { useCustomTableList } from './hook/useCustomTableList'
import { CustomTableListProps } from './types/CustomTableListTypes'
import InputField from '../InputField'
import Link from 'next/link'
import CustomButton from '../Button'
import Tabs from '../Tabs'
import Table from '../Table'
import SortQuery from '@sharedComponents/SortQuery'
import ChipFilter from '@sharedComponents/Chipfilter'
import ExportTable from '@sharedComponents/ExportTable'
import DateRangePicker from '@sharedComponents/DatePicker/DateRangePicker'
import Loader from '@sharedComponents/Loader'
import CenterCard from '@sharedComponents/Layout/CenterCard'
import CustomLoader from '@sharedComponents/CustomLoader'
import { useUserPreferences } from '@core/context/UserPreferences'

function CustomTableList({
  data,
  configuration,
  sortValue,
  sortBy,
  sortOrder,
  totalRecord,
  paginationSize,
  handleOnTabChange,
  handleSortChange,
  handleSortOption,
  handlePageChange,
  page,
  tabIndex,
  isLoading,
  handleOnSearch,
  filterCriterias,
  filterDateCriterias,
  hasFilterApplied,
  noDataText,
  noDataAction,
  isSelectable,
  onSelectedRowsChange,
  clearSelectedRows
}: CustomTableListProps): ReactElement {
  const {
    columns,
    tabConfig,
    sortConfig,
    searchConfig,
    title,
    filterConfig,
    refreshConfig,
    buttonConfig,
    exportConfig
  } = configuration
  const { getColumns } = useCustomTableList({
    columns,
    sortBy,
    sortOrder
  })
  const isFilterAppliedWithTabs = hasFilterApplied() || tabIndex !== 0
  const userPreferences = useUserPreferences()
  const isSideMenuOpen = userPreferences
    ? userPreferences.isSideMenuOpen
    : false

  function isObjectEmpty(obj: object): boolean {
    return Object.keys(obj).length === 0
  }

  return (
    <section className={styles.grid}>
      <div className={styles.header}>
        <h3>{title}</h3>
      </div>
      {isLoading ? (
        <div
          className={`${isSideMenuOpen ? styles.sideMenuOpen : ''} ${
            styles.loader
          }`}
        >
          <CustomLoader />
        </div>
      ) : (
        <div className={styles.contentContainer}>
          {tabConfig?.tabList?.length > 0 && (
            <div className={styles.tabContainer}>
              {(data ||
                tabConfig?.name ||
                (!isLoading &&
                  totalRecord === 0 &&
                  isFilterAppliedWithTabs)) && (
                <Tabs
                  overideStyle={{
                    margin: 'var(--margin-8) 0 var(--margin-4) 0'
                  }}
                  items={tabConfig.tabList}
                  handleTabChange={handleOnTabChange}
                  defaultIndex={tabIndex}
                />
              )}
              {tabConfig?.button &&
                ((totalRecord === 0 && isFilterAppliedWithTabs) ||
                  totalRecord > 0) && (
                  <>
                    <Link href={tabConfig.button.href} legacyBehavior>
                      <CustomButton
                        color={tabConfig.button.color}
                        variant={tabConfig.button.variant}
                        className={styles.tabSectionButton}
                        onClick={tabConfig.button.handleClick}
                        disabled={isLoading}
                      >
                        {tabConfig.button.name}
                      </CustomButton>
                    </Link>
                  </>
                )}
              {tabConfig.showExport &&
                totalRecord > 0 &&
                tabConfig?.tabList?.length > 0 && (
                  <Link href={''} legacyBehavior>
                    <ExportTable
                      exportConfig={exportConfig}
                      totalRecord={totalRecord}
                    />
                  </Link>
                )}
            </div>
          )}
          {(data ||
            (!isLoading && totalRecord === 0 && isFilterAppliedWithTabs)) && (
            <div className={styles.container}>
              <div className={styles.search}>
                <div className={styles.searchContainer}>
                  {searchConfig && (
                    <InputField
                      className={styles.noMargin}
                      type={searchConfig?.type}
                      name={searchConfig?.name}
                      placeholder={searchConfig?.placeholder}
                      value={searchConfig?.searchValue}
                      fancyInput="fancyGreyBackground"
                      customBackground="--surface-1-color"
                      onChange={handleOnSearch}
                    />
                  )}
                  <div className={styles.buttonWrapper}>
                    {refreshConfig && (
                      <CustomButton
                        onClick={refreshConfig?.handleRefreshList}
                        disabled={isLoading}
                        className={styles.refreshBtn}
                        data-testid="refreshList"
                      >
                        <div className={styles.refresh}>
                          <Refresh width="16" height="16" />
                        </div>
                        &nbsp;&nbsp;
                        <div className={styles.refreshFont}>
                          {refreshConfig.name}
                        </div>
                      </CustomButton>
                    )}
                    {buttonConfig && (
                      <article className={styles.additionalButton}>
                        <CustomButton
                          key="approve"
                          variant="contained"
                          color="primary"
                          onClick={buttonConfig?.handleClick}
                          disabled={buttonConfig?.disable}
                        >
                          {buttonConfig?.title}
                        </CustomButton>
                      </article>
                    )}
                  </div>
                </div>
                {sortConfig?.type === 'fancySort' && (
                  <SortQuery
                    option={sortConfig.sortOptions}
                    value={sortValue}
                    onSortChange={handleSortOption}
                    disabled={isLoading}
                  />
                )}
              </div>
              <div className={styles.filterBoxes}>
                <div className={styles.filterLists}>
                  <div
                    className={`${styles.filterContainer} ${styles.chipItems}`}
                  >
                    {filterConfig &&
                      filterConfig?.filters?.map((filter) =>
                        filter.type === 'date' ? (
                          <DateRangePicker
                            key={filter?.inputName}
                            startDate={
                              filterDateCriterias[filter?.id]?.startDate
                            }
                            endDate={filterDateCriterias[filter?.id]?.endDate}
                            onChange={(value, dateType) =>
                              filter.onChange(value, filter?.id, dateType)
                            }
                          />
                        ) : (
                          filterCriterias &&
                          !isObjectEmpty(filterCriterias) && (
                            <ChipFilter
                              key={filter?.inputName}
                              label={filter?.label}
                              filterItems={
                                filter.dynamic
                                  ? filterCriterias[filter?.id]
                                  : filter.options
                              }
                              setFilterItems={filter?.onChange}
                              disabled={
                                isLoading ||
                                (filterCriterias &&
                                  !filterCriterias[filter?.id])
                              }
                            />
                          )
                        )
                      )}
                  </div>
                  <div className={styles.clearFilter}>
                    <div className={styles.stickRight}>
                      <CustomButton
                        color="primary"
                        variant="text"
                        onClick={filterConfig.clearFilters}
                        disabled={
                          (tabIndex === 0 && !hasFilterApplied()) ||
                          (tabIndex > 0 && !hasFilterApplied())
                        }
                        data-testid="resetButton"
                      >
                        Reset
                      </CustomButton>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className={styles.tableWrapper}>
            {!data ||
            data?.length < 1 ||
            (!isLoading && totalRecord === 0 && isFilterAppliedWithTabs) ? (
              <div className={`${styles.noData} h-100`}>
                <CustomIconicCard
                  header={
                    (totalRecord === 0 &&
                      !isFilterAppliedWithTabs &&
                      noDataText) ||
                    'No records found.'
                  }
                  icon="not-found"
                  state={CustomIconicCardState.Warning}
                  size={CustomIconicCardSize.Big}
                >
                  <div>
                    {!isLoading &&
                      totalRecord === 0 &&
                      ((isFilterAppliedWithTabs &&
                        'Please adjust your filters and try again.') ||
                        (!isFilterAppliedWithTabs && noDataAction))}
                  </div>
                </CustomIconicCard>
              </div>
            ) : (
              <>
                {data && (
                  <Table
                    columns={getColumns()}
                    paginationTotalRows={totalRecord}
                    data={data}
                    paginationServer
                    pagination
                    responsive
                    onSort={handleSortChange}
                    sortServer
                    currentPage={page}
                    paginationDefaultPage={page}
                    paginationPerPage={paginationSize || 10}
                    onChangePage={(page) => {
                      handlePageChange(page)
                    }}
                    isLoading={isLoading}
                    className={styles.table}
                    isSelectable={isSelectable}
                    onSelectedRowsChange={onSelectedRowsChange}
                    clearSelectedRows={clearSelectedRows}
                  />
                )}
              </>
            )}
          </div>
        </div>
      )}
    </section>
  )
}

export default CustomTableList
