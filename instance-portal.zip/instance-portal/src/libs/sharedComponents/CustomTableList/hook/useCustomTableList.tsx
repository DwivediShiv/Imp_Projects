import React from 'react'
import styles from '../index.module.css'
import Link from 'next/link'
// import { IDataTableColumn } from 'react-data-table-component'
import { TableColumn } from 'react-data-table-component'
import WithCustomFormat from '@sharedComponents/TimeHOC'
import TableHeader from '@sharedComponents/TableHeader'
import Time from '@sharedComponents/Time'
import NewStatusBox from '@sharedComponents/StatusFancy'
import LinkButton from '@sharedComponents/LinkButton'
import { IconColor } from '@constants/constants'
import { accountTruncate } from '@utils/conversion'
import NetworkName from '@sharedComponents/NetworkName'
import { IconSize } from '@utils/constants'
import AssetBadge from '@sharedComponents/Badge/AssetBadge'

export const roleMap = {
  Publisher: 'Publisher',
  Consumer: 'Consumer',
  Admin: 'Admin',
  'Super-admin': 'Owner'
}

export const getAttribute = (
  attributes: string | any[],
  key: string
): string => {
  for (let i = 0; i < attributes?.length; i++) {
    const attribute = attributes[i]
    if (attribute.name === key) {
      return attribute.value
    }
  }
  return ''
}

export const getRoles = (roles: any[]): React.ReactNode => {
  return <span>{roles.toString()}</span>
}

export function hasSelection(filterItems: any): boolean {
  if (!filterItems) return false

  return Object.values(filterItems).some(
    (value) => typeof value === 'boolean' && value
  )
}

function mapRoles(roles: string): string {
  return roles
    .split(',')
    .map((role) => {
      return roleMap[role.trim()] || role.trim()
    })
    .join(',')
}

const updateReplaceRolefromMap = (roles) => {
  const mappedRoles = mapRoles(roles)
  return (
    <div className={styles.wrapStyles} title={mappedRoles}>
      {mappedRoles || '-'}
    </div>
  )
}

export const useCustomTableList = ({ columns, sortBy, sortOrder }) => {
  const TimeWithCustomFormat = WithCustomFormat(Time)

  const generateName = (element: any): React.ReactNode => {
    switch (element.type) {
      case 'tableHeader':
        return (
          <TableHeader
            title={element.title}
            sortable={element.sortable}
            sortActive={sortBy === element.sortField}
            sortDirection={sortOrder}
          />
        )
      default:
        break
    }
  }

  const renderField = (text) => {
    return (
      <div className={styles.wrapStyles} title={text}>
        {text || '-'}
      </div>
    )
  }

  function getActionItems(row: any, rowConfig: any): React.ReactNode {
    return rowConfig?.actions.map((action) => {
      const type = action?.type
      const clickable = (action?.clickable && action?.clickable(row)) || false
      const hidden = (action?.hidden && action?.hidden(row)) || false
      const ActionImage = action?.image
      const actionStyle = (!clickable && {
        opacity: '0.4',
        color: 'var(--primary-color)',
        pointerEvents: 'none' as React.CSSProperties['pointerEvents'],
        display: 'visible'
      }) || {
        color: 'var(--primary-color)',
        fontWeight: 'var(--font-weight-semibold)',
        cursor: 'pointer'
      }
      actionStyle.display = hidden ? 'none' : 'visible'
      switch (type) {
        case 'icon':
          return (
            <ActionImage
              width="20"
              height="20"
              style={actionStyle}
              className={styles.icon}
              onClick={() => {
                action?.onClick(row)
              }}
            ></ActionImage>
          )
        case 'primaryIcon':
          return (
            <ActionImage
              width="20"
              height="20"
              style={actionStyle}
              className={styles.primaryIcon}
              onClick={() => {
                action?.onClick(row)
              }}
            ></ActionImage>
          )
        case 'text':
          return (
            <span
              style={actionStyle}
              onClick={() => {
                action?.onClick(row)
              }}
            >
              {action.label}
            </span>
          )
      }
    })
  }

  const getCell = (row: any, rowConfig: any): React.ReactNode => {
    let state = '-'
    switch (rowConfig.cellType) {
      case 'fancyStatusField':
        state = row[rowConfig?.value]
          ? row[rowConfig.value]?.toLowerCase()
          : null
        return (
          <div>
            <article className={styles.statusField}>
              {(state && <NewStatusBox status={state} />) || '-'}
            </article>
          </div>
        )
      case 'fancyStatusBoolField':
        state =
          row[rowConfig.value] === true ? rowConfig.value.toLowerCase() : null
        return (
          <div>
            <article className={styles.statusField}>
              {(state && <NewStatusBox status={state} />) || '-'}
            </article>
          </div>
        )
      case 'address':
        return (
          <div>
            <span className={styles.wrapStyles} title={row[rowConfig.value]}>
              {accountTruncate(row[rowConfig?.value])}
            </span>
          </div>
        )
      case 'nameField':
        if (rowConfig.clickable === 'true') {
          let baseUrl = rowConfig.href
          if (
            rowConfig?.conditionalHref?.param &&
            rowConfig.conditionalHref.value &&
            row[rowConfig.conditionalHref.param] ===
              rowConfig.conditionalHref.value
          ) {
            baseUrl = rowConfig.conditionalHref.href
          }
          return (
            <Link href={`${baseUrl}${row[rowConfig?.param]}`} legacyBehavior>
              <article
                className={`${styles.clickable} ${styles.attributeContent}`}
              >
                <div className={styles.wrapStyles} title={row[rowConfig.value]}>
                  {row[rowConfig.value] || '-'}
                </div>
              </article>
            </Link>
          )
        } else {
          return renderField(row.name)
        }
      case 'clickableField': // conditional clickable
        return (
          <div>
            {rowConfig?.clickable(row) ? (
              <Link
                href={rowConfig?.onClick(row)}
                aria-disabled={true}
                legacyBehavior
              >
                <article
                  className={`${styles.clickable} ${styles.attributeContent}`}
                >
                  <div
                    className={styles.wrapStyles}
                    title={row[rowConfig?.value] || '-'}
                  >
                    {row[rowConfig?.value] || '-'}
                  </div>
                </article>
              </Link>
            ) : (
              <div
                className={styles.wrapStyles}
                title={row[rowConfig?.value] || '-'}
              >
                {row[rowConfig?.value] || '-'}
              </div>
            )}
          </div>
        )
      case 'emailField':
        return (
          <div
            className={` ${(row.blocked && styles.blocked) || ''} ${
              styles.wrapStyles
            }`}
          >
            <div>
              <span className={styles.blocktext}>
                {row.blocked ? 'Blocked' : ''}
              </span>
            </div>
            <div className={` ${styles.assetTitle} ${styles.wrapStyles}`}>
              {rowConfig?.clickable(row) ? (
                <LinkButton
                  title={row[rowConfig?.value] || '-'}
                  href={rowConfig?.onClick(row)}
                  color={IconColor.Primary}
                  className="semibold"
                />
              ) : (
                <div
                  className={styles.wrapStyles}
                  title={row[rowConfig?.value] || '-'}
                >
                  {row[rowConfig?.value] || '-'}
                </div>
              )}
            </div>
          </div>
        )

      case 'attributeField':
        return <div>{getAttribute(row.attributes, rowConfig.value) || '-'}</div>
      case 'roleField':
        return (
          (row[rowConfig?.value] &&
            updateReplaceRolefromMap(row[rowConfig?.value])) ||
          ''
        )
      case 'dateField':
        return (
          <div>
            <article className={styles.attributeContent}>
              <TimeWithCustomFormat
                date={row[rowConfig.value]}
                customFormat={rowConfig.format}
              />
            </article>
          </div>
        )
      case 'network':
        return (
          <NetworkName
            networkName={row.networkName}
            type="table"
            iconSize={IconSize.Medium}
          />
        )
      case 'assetType':
        return (
          <AssetBadge title={row.assetType} className={styles.assetBadge} />
        )
      case 'accessType':
        return (
          <AssetBadge
            title={row.accessType}
            parentTitle={row.assetType}
            className={styles.assetBadge}
          />
        )
      case 'actions':
        return (
          <div className={styles.actionsP}>
            <article className={styles.actionContainer}>
              {getActionItems(row, rowConfig)}
            </article>
          </div>
        )
      case 'assetField':
        return (
          <div
            className={
              row.markedForPurge
                ? `${styles.markedForPurge} ${styles.attributeContent}`
                : `${styles.attributeContent}`
            }
          >
            <span className={styles.purgetext}>
              {row.markedForPurge ? 'Purge in progress' : ''}
            </span>
            <p className={styles.wrapText} title={row[rowConfig?.value] || '-'}>
              {row[rowConfig?.value] || '-'}
            </p>
          </div>
        )
      default:
        return renderField(row[rowConfig.value])
    }
  }

  const getColumns = (): TableColumn<any>[] => {
    return columns.map((config: any) => {
      const column: TableColumn<any> = {}
      column.id = config.id
      column.name = generateName(config)
      column.cell = (row: any) => {
        return (
          (config.cell && config.cell(row)) || getCell(row, config.rowConfig)
        )
      }
      column.grow = config.grow
      column.style = config.style
      column.width = config.width
      column.sortable = config.sortable
      column.allowOverflow = config.allowOverflow

      return column
    })
  }

  return {
    getColumns
  }
}
