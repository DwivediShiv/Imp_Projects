import React from 'react'
describe('Button test ', () => {
  it('test', () => {
    // will remove when uncommented
    expect('test').toBe('test')
  })
})
