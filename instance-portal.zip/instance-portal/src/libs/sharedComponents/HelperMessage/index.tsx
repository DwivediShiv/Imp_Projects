import React, { ReactElement, useEffect, useState } from 'react'
import styles from './index.module.css'
import WarningIcon from '@images/icon_warning.svg'
import InfoIcon from '@images/icon_information.svg'
import { WarningCircleIcon as ErrorIcon } from '../Icon/WarningCircleIcon'
import { SuccessCircleIcon as TickIcon } from '../Icon/SuccessCircleIcon'
import { ReactNode } from 'react-markdown'

export default function HelperMessage({
  message,
  isValid,
  isWarning,
  isAlert,
  isInfo,
  icon,
  hasIcon,
  className
}: {
  message: string | ReactNode
  isValid?: boolean
  isWarning?: boolean
  isAlert?: boolean
  isInfo?: boolean
  icon?: ReactNode
  hasIcon?: boolean
  className?: string
}): ReactElement {
  const [messageType, setMessageType] = useState('error')

  useEffect(() => {
    if (isValid) setMessageType('success')
    if (isWarning) setMessageType('warning')
    if (isAlert) setMessageType('error')
    if (isInfo) setMessageType('info')
  }, [isValid, isWarning, isAlert, isInfo])

  const displayHelperIcon = () => {
    switch (messageType) {
      case 'error':
        return (
          icon || <ErrorIcon className={`iconSizeSmall ${styles.errorIcon}`} />
        )
      case 'warning':
        return (
          icon || (
            <WarningIcon className={`iconSizeSmall ${styles.warningIcon}`} />
          )
        )
      case 'info':
        return (
          icon || <InfoIcon className={`iconSizeSmall ${styles.infoIcon}`} />
        )
      case 'success':
        return (
          icon || <TickIcon iconSize={`iconSizeSmall ${styles.successIcon}`} />
        )
      default:
        return <span className={styles.messageIcon}>{icon || ''}</span>
    }
  }

  const displayHelperText = (message) => {
    return (
      <div className={styles.helperMessageContainer}>
        {hasIcon ?? <div className={styles.icon}>{displayHelperIcon()}</div>}
        <span className={styles.message}>{message}</span>
      </div>
    )
  }

  return (
    <div
      className={`${className} ${styles.messageIconWrapper} ${styles[messageType]}`}
    >
      {displayHelperText(message)}
    </div>
  )
}
