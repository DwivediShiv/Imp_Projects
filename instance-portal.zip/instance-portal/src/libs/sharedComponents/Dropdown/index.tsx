import React, {
  ChangeEvent,
  ReactElement,
  ReactNode,
  useEffect,
  useState
} from 'react'
import styles from './index.module.css'
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  MenuProps
} from '@mui/material'
import { makeStyles } from 'tss-react/mui'
import ExpandLessIcon from '@images/expandLess.svg'
import ExpandMoreIcon from '@images/expandMore.svg'
import { SelectionOption } from '@type/SelectionOptions'
import { getStatusColor } from '@utils/fancyStyles'
import { COMPUTE_OPTION, NOTCHED_OUTLINE } from '@constants/constants'
import { useFancyState } from '@core/context/FancyState'
import useViewportCheck from '@core/useViewportCheck'
import appConfig from 'app.config'
import { useFormikContext } from 'formik'
import CountryElement from '../CountryElement'
import HelperMessage from '../HelperMessage'
import { setBorderRadius } from '../TextField'

type SelectBoxProps = {
  type?: string
  label?: string | ReactNode
  inputName: string
  options?: string[]
  value?: string
  error?: boolean | string
  isValid?: boolean | string
  isWarning?: boolean
  isAlert?: boolean
  isLoading?: boolean
  MenuListComponent?: JSX.Element[]
  onChange?: any
  onStateChange?(e: ChangeEvent<any>, state?: any): void
  disabled?: boolean
  isNativeSelect?: boolean
  placeholder?: string
  helperText?: string | ReactNode
  optionCategory?: string
  optionKey?: string
  isDisable?: boolean
  containerClass?: string
  deselectText?: string
  deselectValue?: string
  MenuProps?: Partial<MenuProps>
  customBackground?: string
  variant?: string
  title?: string | ReactNode
  mode?: string
  isFilterBox?: boolean
  showFlag?: boolean
}

const useStyles = makeStyles<{
  isValid
  isWarning
  error
  name
  customBackground
  variant
  popperWidth
}>()(
  (
    theme,
    { isValid, isWarning, error, name, customBackground, variant, popperWidth }
  ) => {
    return {
      label: {
        color: getStatusColor(
          { isValid, isWarning, error },
          'var(--light-text-3)'
        ),
        '&.Mui-focused': {
          color: getStatusColor(
            { isValid, isWarning, error },
            'var(--light-text-2)'
          )
        },
        '&.Mui-error': {
          color: 'var(--light-text-3)'
        }
      },
      helperText: {
        margin: '8px 0 0 14px',
        color: getStatusColor({
          isValid,
          isWarning,
          error
        }),
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        '& path': {
          stroke: getStatusColor({
            isValid,
            isWarning,
            error
          })
        },
        '& span': {
          lineHeight: 'var(--line-height-standard)',
          fontSize: 'var(--font-size-smaller)',
          padding: '0 0.1rem'
        }
      },
      customInput: {
        height: '56px',
        marginRight: name === 'fileSizeType' ? '20px' : '',
        backgroundColor: 'var(--surface-0-color)',
        color: 'var(--light-text-1)',
        display: 'grid',
        fontSize: 'var(--acentrik-font-size-body-2)',
        borderRadius: setBorderRadius(),
        border: 'solid 1px',
        borderColor: getStatusColor({
          isValid,
          isWarning,
          error
        }),
        '&:hover': {
          backgroundColor: 'var(--surface-0-color)'
        },
        '&.Mui-error': {
          border: '1px solid  var(--danger-color)',
          backgroundColor: ' var(--danger-color-background-input)'
        },
        '&.Mui-focused': {
          backgroundColor: error
            ? 'var(--danger-color-background-input)'
            : 'var(--surface-0-color)'
        },
        '&[aria-expanded="true"]': {
          borderBottomLeftRadius: '0px',
          borderBottomRightRadius: '0px'
        }
      },
      customInputUnderlineVariant: {
        marginRight: name === 'fileSizeType' ? '20px' : '',
        color: 'var(--light-text-1)',
        fontSize: 'var(--font-size-th)',
        borderBottom: '1px solid ',
        borderColor: getStatusColor({
          isValid,
          isWarning,
          error
        }),
        '&.Mui-error': {
          border: '1px solid  var(--danger-color)',
          '&:after': {
            borderColor: 'transparent'
          }
        }
      },
      paperBG: {
        backgroundColor: 'var(--surface-2-color)',
        color: 'var(--light-text-1)',
        maxHeight: '260px',
        margin: '-1px 0',
        border: 'solid 1px',
        width: popperWidth,
        padding: 'var(--padding-2) 0',
        backgroundImage: 'unset',
        minWidth: 'unset !important',
        boxShadow: 'var(--dropdown-box-shadow)',
        borderRadius: '0 0 var(--border-radius) var(--border-radius)',
        borderColor: getStatusColor({
          isValid,
          isWarning,
          error
        })
      },
      menuList: {
        padding: '0',
        backgroundColor: 'var(--surface-2-color)',
        '& .MuiMenuItem-root:hover': {
          backgroundColor: 'var(--secondary-color-hover)'
        },
        '& .MuiMenuItem-root.Mui-selected': {
          backgroundColor: 'var(--secondary-color-active)'
        }
      },
      listItem: {
        whiteSpace: 'unset',
        wordBreak: 'break-word',
        backgroundColor: 'var(--surface-2-color) !important',
        '&:hover': {
          backgroundColor: 'var(--secondary-color-hover) !important'
        }
      },
      selectedItem: {
        '&.Mui-selected, &.Mui-selected:hover, &.Mui-selected:focus': {
          backgroundColor: 'var(--secondary-color-active) !important'
        }
      }
    }
  }
)

function CustomDropDown({
  label,
  inputName,
  options,
  error,
  MenuListComponent,
  isValid,
  isWarning,
  disabled,
  isNativeSelect,
  placeholder,
  helperText,
  customBackground,
  variant,
  title,
  mode,
  isFilterBox = false,
  onChange,
  showFlag,
  optionCategory,
  ...field
}: SelectBoxProps): ReactElement {
  const [popperWidth, setPopperWidth] = useState<string>('')
  const { classes } = useStyles({
    isValid,
    isWarning,
    error,
    name: inputName,
    customBackground,
    variant,
    popperWidth
  })

  const isNotchedOutlineMode = mode === NOTCHED_OUTLINE
  const isFilledVariant = !isNotchedOutlineMode && label

  const formik = useFormikContext<any>()
  const formValues = formik?.values
  const fieldValue: any =
    field.value ?? formik?.getFieldMeta(inputName)?.value ?? ''
  const fieldHelper = formik?.getFieldHelpers(inputName)

  const {
    // optionCategory,
    optionKey,
    containerClass,
    deselectText,
    deselectValue,
    onStateChange,
    ...otherField
  } = field
  const [fancyOptions, setFancyOptions] = useState<SelectionOption[]>([])
  const [expanded, setExpanded] = useState<boolean>(false)

  const { getSelectionOptionsByCategory } = useFancyState()
  const { windowSize } = useViewportCheck()
  const isCustomized = appConfig?.customization?.theme === 'customized'

  useEffect(() => {
    async function loadSelectionOptions() {
      if (!optionCategory) return
      const options = await getSelectionOptionsByCategory(optionCategory)
      setFancyOptions(options)
    }

    loadSelectionOptions()
  }, [optionCategory])

  useEffect(() => {
    if (!open || !expanded) return
    const textFieldDropdown = document.getElementById(
      `${inputName}_formControl`
    )
    setPopperWidth(window.getComputedStyle(textFieldDropdown).width)
  }, [windowSize.width, open, expanded])

  const optionType = {
    computeOptions: COMPUTE_OPTION
  }

  function getLabel(type: string, value: string) {
    if (inputName === 'credentialCountry') {
      return (
        <CountryElement
          countryCode={value}
          showFlag={showFlag}
          optionCategory={optionCategory}
        />
      )
    }

    const dataOptionType = optionType[type]

    if (dataOptionType === undefined) return value
    return dataOptionType?.[value] || value
  }

  const deselectSelectMenu = () => {
    return deselectText ? (
      isNativeSelect ? (
        <option value={deselectValue || ''}>{deselectText}</option>
      ) : (
        <MenuItem
          classes={{
            root: classes.listItem,
            selected: classes.selectedItem
          }}
          key={deselectText}
          value={deselectValue || ''}
          disableRipple
        >
          {deselectText}
        </MenuItem>
      )
    ) : null
  }

  const defaultSelectMenu = () => {
    if (fancyOptions && fancyOptions.length) {
      return fancyOptions.map((option: SelectionOption, index: number) =>
        isNativeSelect ? (
          <option value={option[optionKey || 'name']} key={index}>
            {option.name}
          </option>
        ) : (
          <MenuItem
            classes={{
              root: classes.listItem,
              selected: classes.selectedItem
            }}
            key={index}
            value={option[optionKey || 'name']}
            disableRipple
          >
            {option.name}
          </MenuItem>
        )
      )
    }
    return (
      options &&
      options.map((option: string, index: number) =>
        isNativeSelect ? (
          <option value={option} key={index}>
            {option}
          </option>
        ) : (
          <MenuItem
            classes={{
              root: classes.listItem,
              selected: classes.selectedItem
            }}
            key={index}
            value={option}
            disableRipple
          >
            {getLabel(optionKey, option)}
          </MenuItem>
        )
      )
    )
  }
  const overideContainerStyle =
    (containerClass && styles[containerClass]) || containerClass

  function onSelectStateChange(event: ChangeEvent<any>, state: string) {
    onStateChange && onStateChange(event, state)
    state === 'expanded' ? setExpanded(true) : setExpanded(false)
  }

  function handleOnChange(event: ChangeEvent<any>) {
    const newValue = event.target.value

    if (inputName === 'timeout') {
      const accessType = formValues.services[0].access
      fieldHelper.setValue(
        accessType === 'compute' && newValue === 'Unlimited Period'
          ? ''
          : newValue,
        true
      )
    } else {
      fieldHelper?.setValue(newValue, true)
    }

    if (onChange) {
      onChange(event)
    }
  }

  return (
    <FormControl
      variant={isFilledVariant ? 'filled' : 'standard'}
      className={`${overideContainerStyle || ''} ${
        isNotchedOutlineMode ? styles.notchedOutlineContainer : ''
      } ${disabled ? styles.disabled : ''}`}
      classes={{ root: styles.root }}
      error={!!error}
      disabled={disabled}
      id={`${inputName}_formControl`}
    >
      {label && (
        <InputLabel
          id={`${inputName}-label`}
          htmlFor={inputName}
          className={styles.label}
          classes={{
            root: classes.label,
            filled: styles.labelFilled,
            shrink: styles.labelShrink,
            focused: styles.labelFocus
          }}
        >
          {label}
        </InputLabel>
      )}
      <Select
        {...otherField}
        native={isNativeSelect}
        displayEmpty={isNotchedOutlineMode || !label}
        value={fieldValue ?? ''}
        id={inputName}
        className={
          variant === 'underline'
            ? classes.customInputUnderlineVariant
            : classes.customInput
        }
        classes={
          field.containerClass === 'exploreFilter' && {
            select: styles.selectRoot
          }
        }
        onOpen={(event) => onSelectStateChange(event, 'expanded')}
        onClose={(event) => onSelectStateChange(event, 'collapsed')}
        onChange={handleOnChange}
        IconComponent={(props) => (
          <div
            className={`${styles.dropDownIcon} ${
              variant === 'underline' && styles.dropDownIconToRight
            } d-flex center`}
          >
            {props.className.includes('iconOpen') ? (
              <ExpandLessIcon className={`iconColorFillText2 iconSizeMedium`} />
            ) : (
              <ExpandMoreIcon className={`iconColorFillText2 iconSizeMedium`} />
            )}
          </div>
        )}
        aria-expanded={expanded}
        MenuProps={{
          classes: {
            paper: classes.paperBG,
            list: classes.menuList
          },
          variant: 'menu',
          ...field.MenuProps
        }}
        input={
          <Select
            classes={{
              select: `${styles.select} ${fieldValue && styles.inputValue} ${
                !label && variant !== 'underline' && styles.padding
              } ${isNotchedOutlineMode && styles.padding}`
            }}
            disableUnderline
          />
        }
        renderValue={
          (!label || isNotchedOutlineMode) && placeholder
            ? (selected: string) => {
                return selected ? (
                  getLabel(optionKey, selected)
                ) : (
                  <div className={styles.placeholder}>{placeholder}</div>
                )
              }
            : null
        }
      >
        {deselectSelectMenu()}
        {MenuListComponent || defaultSelectMenu()}
      </Select>
      {(helperText || error) && (
        <HelperMessage
          message={helperText || error}
          isWarning={isWarning}
          isAlert={!!error}
        />
      )}
    </FormControl>
  )
}

export default CustomDropDown
