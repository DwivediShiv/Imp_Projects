import React, { ReactElement } from 'react'
import classNames from 'classnames'
import styles from './AssetBadge.module.css'

const typeTitle = {
  dataset: 'Dataset',
  algorithm: 'Algorithm',
  compute: 'Compute',
  access: 'Download',
  download: 'Download'
}

export const strongTypeTitle = {
  dataset: {
    compute: 'Compute',
    access: 'Download',
    download: 'Download'
  },
  algorithm: {
    compute: 'Private',
    access: 'Public'
  }
}

export function getActualTitle(parentTitle, title) {
  const actualTitle = parentTitle ? strongTypeTitle[parentTitle]?.[title] : ''
  return actualTitle || typeTitle[title] || title
}

export default function AssetBadge({
  title,
  className,
  parentTitle,
  ...props
}: {
  title?: string
  className?: string
  parentTitle?: string
}): ReactElement {
  const actualTitle = getActualTitle(parentTitle, title)
  return (
    <div
      className={classNames(className, styles[actualTitle], styles.badge)}
      {...props}
    >
      {actualTitle}
    </div>
  )
}
