import { Field, Formik, Form } from 'formik'
import React, { ReactElement, useState } from 'react'
import styles from './CommonForm.module.css'
import classNames from 'classnames'
import InputField from '../InputField'
import { FormFieldProps } from '@type/Form'
import { CommonFormProps } from './types/formTypes'
import CustomButton from '../Button'

const CommonForm: React.FC<CommonFormProps> = ({
  handleSubmit,
  validationSchema,
  content,
  checkDisabled,
  onChangeCheckbox
}): ReactElement => {
  const formFields = content.form.data
  const [isSelectedOtherCountry, setIsSelectedOtherCountry] =
    useState<boolean>(false)

  return (
    <Formik
      initialValues={content.initialValues}
      validationSchema={validationSchema}
      onSubmit={async (values, { setSubmitting, resetForm, setFieldError }) => {
        await handleSubmit(values, resetForm, setFieldError)
        setSubmitting(false)
      }}
    >
      {({ errors, dirty }) => {
        return (
          <Form>
            <div className={styles.content} data-testid="formik-form">
              {formFields.map((field: Partial<FormFieldProps>) => {
                if (field.type === 'countryList') {
                  return (
                    <Field
                      className={styles.fieldContainer}
                      key={field.name}
                      validate={(val: string) => {
                        setIsSelectedOtherCountry(val === 'OTHERS')
                      }}
                      {...field}
                      addonInput={isSelectedOtherCountry && field.addonInput}
                      component={InputField}
                      sendCountryName
                    />
                  )
                } else if (
                  field.type === 'checkbox' &&
                  field.optionType === 'group'
                ) {
                  return (
                    <div className={styles.checkBoxContainer} key={field.name}>
                      <div className={styles.textareaLabel}>{field.label}</div>
                      <div className={styles.checkBoxArea}>
                        {field.options?.map((option: string) => (
                          <Field
                            key={option}
                            {...field}
                            label={option}
                            name={option}
                            component={InputField}
                            className={classNames(
                              !field.noBoundary && styles.checkBoxBoundary
                            )}
                            onChange={() => onChangeCheckbox(option)}
                          />
                        ))}
                      </div>
                    </div>
                  )
                } else {
                  return (
                    <Field
                      className={styles.fieldContainer}
                      key={field.name}
                      {...field}
                      component={InputField}
                    />
                  )
                }
              })}
              <div className={styles.containerBtn}>
                <CustomButton
                  color="primary"
                  variant="contained"
                  type="submit"
                  className={styles.actionButton}
                  disabled={checkDisabled(dirty, errors)}
                >
                  {content.title}
                </CustomButton>
              </div>
            </div>
          </Form>
        )
      }}
    </Formik>
  )
}

export default CommonForm
