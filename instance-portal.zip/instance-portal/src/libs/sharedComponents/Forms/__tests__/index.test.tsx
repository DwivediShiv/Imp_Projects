import React from 'react'
describe('Org Admin profile ', () => {
  it('test', () => {
    // will remove when uncommented
    expect('test').toBe('test')
  })
})
