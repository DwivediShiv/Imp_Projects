import React, { ReactElement } from 'react'
import styles from './DatePicker.module.css'
import { Divider } from '@mui/material'
import DatePicker from './DatePicker'

interface DatePickerProps {
  startDate?: Date | null
  setStartDate?: (value: Date) => void
  endDate?: Date | null
  setEndDate?: (value: Date) => void
  onChange?: (value: Date, dateType: 'startDate' | 'endDate') => void
}

export default function DateRangePicker({
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  onChange
}: DatePickerProps): ReactElement {
  return (
    <>
      <DatePicker
        label={'Start date'}
        date={startDate}
        setDate={
          onChange
            ? (startDate) => onChange(startDate, 'startDate')
            : setStartDate
        }
        maxDate={endDate}
      />
      <DatePicker
        label={'End date'}
        date={endDate}
        setDate={
          onChange ? (endDate) => onChange(endDate, 'endDate') : setEndDate
        }
        minDate={startDate}
      />
      <Divider className={styles.divider} />
    </>
  )
}
