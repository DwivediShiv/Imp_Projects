import React, { ReactElement, useEffect, useState } from 'react'
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import styles from './DatePicker.module.css'
import Calendar from '@images/calendar.svg'
import Cross from '@images/cross_default.svg'
import Arrow from '@images/arrow.svg'
import localeEnGB from 'dayjs/locale/en-gb'
import { isValidDate } from '@utils/index'
interface DatePickerProps {
  label: string
  date: Date | null
  setDate: (value: Date) => void
  minDate?: Date | null
  maxDate?: Date | null
}

function FancyDatePicker({
  label,
  date,
  setDate,
  minDate,
  maxDate
}: DatePickerProps): ReactElement {
  const [isOpen, setIsOpen] = useState<boolean>(false)
  const [onDayChange, setOnDayChange] = useState<boolean>(true)

  function DatePickerButton() {
    return date ? (
      <Cross
        data-testid="cross-icon"
        className={`iconSizeSmall ${styles.crossIcon}`}
        onClick={(event: { stopPropagation: () => void }) => {
          event.stopPropagation()
          setDate(null)
          setIsOpen(false)
        }}
      />
    ) : (
      <Calendar
        data-testid="calendar-icon"
        className={`iconSizeSmall ${styles.calenderIcon}`}
      />
    )
  }

  function ArrowDirectedToRightButton() {
    return <Arrow className={`iconSizeSmall ${styles.rightArrowIcon}`} />
  }

  function ArrowDirectedToLeftButton() {
    return <Arrow className={`iconSizeSmall ${styles.leftArrowIcon}`} />
  }

  function scrollToSelectedYear(target) {
    if (!target) return
    target.parentNode.parentElement.scrollTop =
      target.parentElement.offsetTop - 60 // Make the current year as the first row
  }

  function scrollToNearestYear() {
    const lengthOfYear =
      document.getElementsByClassName(`MuiPickersYear-root`).length
    if (!lengthOfYear) return
    const target = document.getElementsByClassName(`MuiPickersYear-yearButton`)[
      lengthOfYear - 1
    ]
    target.parentNode.parentElement.scrollTop = target.parentElement.offsetTop // Move to the nearest year as possible
  }

  useEffect(() => {
    if (onDayChange) return
    const hasSelectedYear = document.getElementsByClassName(
      `MuiPickersYear-yearButton Mui-selected`
    )[0]

    hasSelectedYear
      ? scrollToSelectedYear(hasSelectedYear)
      : scrollToNearestYear()
  }, [onDayChange])

  return (
    <LocalizationProvider
      dateAdapter={AdapterDayjs}
      adapterLocale={localeEnGB.name}
    >
      <DesktopDatePicker
        label={label}
        className={styles.root}
        open={isOpen}
        onClose={() => {
          setIsOpen(false)
        }}
        value={date || null}
        onAccept={(newValue) => {
          onDayChange && isValidDate(newValue) && setDate(newValue)
        }}
        localeText={{
          fieldMonthPlaceholder: (params) =>
            params.contentType === 'letter' ? 'MMM' : 'MM'
        }}
        slots={{
          openPickerIcon: DatePickerButton,
          rightArrowIcon: ArrowDirectedToRightButton,
          leftArrowIcon: ArrowDirectedToLeftButton
        }}
        slotProps={{
          popper: {
            className: styles.popper
          },
          textField: {
            onClick: () => {
              setIsOpen(true)
            },
            className: `${isOpen ? styles.open : ''}`,
            inputProps: {
              'data-testid': 'datepicker-textfield'
            },
            InputLabelProps: {
              classes: {
                shrink: styles.labelShrink
              }
            }
          }
        }}
        onViewChange={(view) => {
          setOnDayChange(view === 'day')
        }}
        minDate={minDate || null}
        maxDate={maxDate || null}
        yearsPerRow={3}
        format={'DD MMM YYYY'}
        disableFuture
        reduceAnimations
      />
    </LocalizationProvider>
  )
}

export default FancyDatePicker
