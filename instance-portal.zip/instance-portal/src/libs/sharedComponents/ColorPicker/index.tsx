import React, { useState } from 'react'
import { ErrorMessage, FastField } from 'formik'
import ColorPickerError from './ColorPickerError'
import styles from './index.module.css'

function ColorPicker(props) {
  const {
    label,
    name,
    setColorPickerValue,
    setPickerVisible,
    setPickerPosition,
    setFieldValRef,
    ...rest
  } = props

  return (
    <div className="form-control">
      <FastField name={name}>
        {({ form, field }) => {
          const { setFieldValue } = form
          const { value } = field
          const hasError = form?.touched[name] && form?.errors[name]
          const isValid = form?.touched[name] && form?.values[name] && !hasError
          return (
            <div key={name + 'renderFields'}>
              <div className={styles.colorLabel}>{label}</div>
              <div className={styles.colorContainer}>
                <div
                  style={{
                    backgroundColor: value
                  }}
                  className={styles.colorBox}
                  onClick={(event) => {
                    let x = event.pageX
                    let y = event.pageY
                    const { clientY } = event
                    const w = 240
                    const h = 306
                    if (x + w > window.innerWidth) {
                      x = window.innerWidth - 280
                    }

                    if (clientY + h > window.innerHeight) {
                      y = y - 310
                    }
                    setPickerPosition({ x, y })
                    setColorPickerValue({ hex: value })
                    setPickerVisible(true)
                    setFieldValRef.current = (val) => setFieldValue(name, val)
                  }}
                >
                  {''}
                </div>

                <div>
                  <input
                    id={name}
                    type="text"
                    {...field}
                    {...rest}
                    value={value}
                    className={`${styles.colorInput} ${
                      hasError ? ` ${styles.colorInputError} ` : ` `
                    } ${isValid ? ` ${styles.colorInputSuccess} ` : ` `} `}
                    onChange={(e) => {
                      setFieldValue(name, e.target.value)
                    }}
                  />
                </div>
              </div>
            </div>
          )
        }}
      </FastField>

      <ErrorMessage component={ColorPickerError} name={name} />
    </div>
  )
}

export default ColorPicker
