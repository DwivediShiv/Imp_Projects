import HelperText from '@sharedComponents/HelperText'
import React from 'react'
import styles from './index.module.css'

function ColorPickerError(props) {
  return (
    <HelperText className={styles.errorMessagge} message={props.children} />
  )
}

export default ColorPickerError
