import { useAuthorize } from '@core/context/Authorize'
import router from 'next/router'
import React, { ReactElement } from 'react'
import styles from './index.module.css'
import { fancyNavigation } from '@utils/fancyDelegateAction'
import { setAsLastVisitUrl } from '@utils/platformSetting'
import CustomButton from '../Button'

export default function AuthenticationButtonGroup(): ReactElement {
  const { isLogin, isAdmin } = useAuthorize()
  const handleNavigate = (navigateTo: string, siteTitle?: string) => {
    if (siteTitle) {
      fancyNavigation(() =>
        router.push(`${navigateTo}?title=${siteTitle}`, navigateTo)
      )
    } else {
      isLogin
        ? fancyNavigation(() =>
            isAdmin ? router.push('/manage-users') : router.push('/dashboard')
          )
        : fancyNavigation(() => router.push(navigateTo))
    }
  }
  return (
    <div className={styles.authButtonGroup}>
      <CustomButton
        className={styles.noOutlineBtn}
        onClick={() => {
          setAsLastVisitUrl()
          handleNavigate('/login')
        }}
      >
        Login
      </CustomButton>
    </div>
  )
}
