import React, { ReactElement } from 'react'
import styles from './index.module.css'
import {
  AppBar,
  CssBaseline,
  Toolbar,
  useScrollTrigger,
  useMediaQuery
} from '@mui/material'

import appConfig from 'app.config'
import StaticHeader from './StaticHeader'
import MarketHeader from './MarketHeader'

export default function CustomHeader({
  handleLeftDrawerToggle,
  isStaticPage
}: {
  handleLeftDrawerToggle: () => void
  isStaticPage?: boolean
}): ReactElement {
  const isLargeScreen = useMediaQuery('(min-width:1024px)')

  const scrollTrigger = useScrollTrigger({
    disableHysteresis: true,
    threshold: isLargeScreen ? 39 : 56
  })

  return (
    <>
      <CssBaseline />
      <AppBar
        position="sticky"
        className={`${
          isStaticPage
            ? styles.appBarWebPortal
            : `${styles.appBar} ${styles[appConfig.customization.theme]}`
        } ${scrollTrigger && styles.onScroll} main-header`}
      >
        <Toolbar
          className={`${styles.headerWrapper} ${
            isStaticPage && styles.webPortalHeader
          }`}
          disableGutters
        >
          {isStaticPage ? (
            <StaticHeader />
          ) : (
            <MarketHeader handleLeftDrawerToggle={handleLeftDrawerToggle} />
          )}
        </Toolbar>
      </AppBar>
    </>
  )
}
