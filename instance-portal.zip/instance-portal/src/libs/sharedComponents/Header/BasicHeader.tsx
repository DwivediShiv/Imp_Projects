import React, { ReactElement, useState } from 'react'
import styles from './BasicHeader.module.css'
import {
  AppBar,
  CssBaseline,
  Toolbar,
  useMediaQuery,
  useScrollTrigger
} from '@mui/material'
import { useRouter } from 'next/router'
import appConfig from 'app.config'
import Image from 'next/image'

export default function BasicHeader(): ReactElement {
  const router = useRouter()
  const isLargeScreen = useMediaQuery('(min-width:1024px)')
  const scrollTrigger = useScrollTrigger({
    disableHysteresis: true,
    threshold: isLargeScreen ? 39 : 56
  })
  const [imageError, setImageError] = useState(false)
  const handleImageError = () => {
    setImageError(true)
  }
  return (
    <>
      <CssBaseline />
      <AppBar
        position="sticky"
        className={`${styles.appBar} ${scrollTrigger && styles.onScroll} ${
          styles[appConfig.customization.theme]
        }`}
        classes={{ root: styles.rootAppBar }}
      >
        <Toolbar className={styles.headerWrapper}>
          <div className={`${styles.buttonsWrapper}`}>
            <div className={styles.fancyLogoWrapper}>
              {!imageError ? (
                <Image
                  src={`https://${appConfig.customization.bucket}.s3.amazonaws.com/instance/custom/headerLogo`}
                  width={125}
                  height={24}
                  priority
                  unoptimized
                  alt="Logo"
                  onErrorCapture={handleImageError}
                />
              ) : (
                <div className={styles.logo}></div>
              )}
              <div className={styles.logoSubtitle}>Instance</div>
            </div>
          </div>
        </Toolbar>
      </AppBar>
    </>
  )
}
