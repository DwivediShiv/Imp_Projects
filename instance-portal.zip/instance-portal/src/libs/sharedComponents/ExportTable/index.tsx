import React, { ReactElement } from 'react'
import styles from './index.module.css' // Make sure to adjust the path
import ExportIcon from '@images/export.svg'
import CustomButton from '@sharedComponents/Button'

export default function ExportTable({
  exportConfig,
  totalRecord
}): ReactElement {
  if (!exportConfig || totalRecord === 0) {
    return null
  }

  const handleExportData = async (exportFn, fileName) => {
    const response = await exportFn()
    const url = window.URL.createObjectURL(new Blob([response]))
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
  }

  const handleClick = () => {
    if (totalRecord !== 0) {
      handleExportData(exportConfig.exportFn, exportConfig.fileName)
    }
  }

  const isDisabled = totalRecord === 0

  return (
    <CustomButton
      variant="contained"
      color="primary"
      data-testid="export-csv-button"
      disabled={isDisabled}
      className={styles.additionalButton}
      onClick={handleClick}
    >
      <ExportIcon className={`iconSizeLarge mr-3 ${styles.exportIcon}`} />
      <span>Export</span>
    </CustomButton>
  )
}
