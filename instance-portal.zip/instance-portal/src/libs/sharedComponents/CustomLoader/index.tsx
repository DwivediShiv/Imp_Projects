import React, { ReactElement } from 'react'
import styles from './index.module.css'
import { CircularProgress } from '@mui/material'
import CircularProgressWithLabel from './CircularProgressWithLabel'
import { makeStyles } from 'tss-react/mui'

const useStyles = makeStyles()(() => {
  return {
    root: {
      display: 'flex'
    },
    circle: {
      stroke: 'var(--primary-color)'
    }
  }
})

export default function CustomLoader({
  message,
  progressValue,
  isCenter,
  circularSize,
  label,
  customStyle,
  buttonLoader = false
}: {
  message?: string | ReactElement
  progressValue?: number
  isCenter?: boolean
  circularSize?: number
  customStyle?: string
  label?: string
  buttonLoader?: boolean
}): ReactElement {
  const { classes } = useStyles()

  return (
    <div
      data-testid="fancy-loader"
      className={`${styles.loaderWrap} ${isCenter && styles.center}  ${
        customStyle || ''
      }`}
    >
      <div
        className={`${styles.loader} ${circularSize && styles.circularSize}`}
      >
        {progressValue > 0 ? (
          <CircularProgressWithLabel
            data-testid="fancy-loader-circular-progress-with-label"
            size={80}
            thickness={4}
            value={progressValue}
            classes={{ circle: classes.circle }}
            className={buttonLoader && styles.buttonLoader}
          />
        ) : (
          <>
            <CircularProgress
              data-testid="fancy-loader-circular-progress"
              size={circularSize || 80}
              thickness={3}
              classes={{ circle: classes.circle }}
              className={buttonLoader && styles.buttonLoader}
            />
            {label && <span className={styles.label}>{label}</span>}
          </>
        )}
      </div>
      {message && <div className={styles.message}>{message}</div>}
    </div>
  )
}
