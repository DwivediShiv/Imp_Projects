import React from 'react'
import styles from './index.module.css'
import {
  Box,
  Typography,
  CircularProgressProps,
  CircularProgress
} from '@mui/material'

function CircularProgressWithLabel(props: CircularProgressProps) {
  return (
    <Box position="relative" display="inline-flex">
      <CircularProgress {...props} />
      <Box
        top={0}
        left={0}
        bottom={0}
        right={0}
        position="absolute"
        display="flex"
        alignItems="center"
        justifyContent="center"
      >
        <Typography
          className={styles.process}
          variant="caption"
          component="div"
        >
          <Box
            fontWeight="var(--font-weight-bold)"
            fontSize="var(--font-size-h5)"
          >{`${Math.round(props.value)}%`}</Box>
        </Typography>
      </Box>
    </Box>
  )
}

export default function CircularStatic({ ...props }) {
  return <CircularProgressWithLabel {...props} />
}
