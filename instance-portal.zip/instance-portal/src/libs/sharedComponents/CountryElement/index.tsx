import React, { ReactElement, useEffect, useState } from 'react'
import ReactCountryFlag from 'react-country-flag'
import styles from './index.module.css'
import Glob from '@images/global.svg'
import { useFancyState } from '@core/context/FancyState'

function CountryElement({
  countryCode,
  countryName,
  showFlag = true,
  optionCategory = 'Country'
}: {
  countryCode: string
  countryName?: string
  showFlag?: boolean
  optionCategory?: string
}): ReactElement {
  const notOtherCountry = countryCode !== 'OTHERS'
  const [countryList, setCountryList] = useState<any[]>()

  const { getSelectionOptionsByCategory } = useFancyState()

  useEffect(() => {
    async function init() {
      try {
        const result = await getSelectionOptionsByCategory(optionCategory)
        result && setCountryList(result)
      } catch (error) {
        console.error(error)
      }
    }
    init()
  }, [countryCode, getSelectionOptionsByCategory])

  return (
    <div className={styles.countryField}>
      {showFlag && (
        <>
          {notOtherCountry ? (
            <ReactCountryFlag
              countryCode={countryCode}
              svg
              className={styles.emojiFlag}
              title={countryName}
            />
          ) : (
            <Glob className={styles.emojiFlag} />
          )}
        </>
      )}
      <span>
        {countryName && countryName.length > 0
          ? countryName
          : countryList &&
            countryList.find((value) => {
              return value.key.toLowerCase() === countryCode.toLowerCase()
            })?.name}
      </span>
    </div>
  )
}

export default CountryElement
