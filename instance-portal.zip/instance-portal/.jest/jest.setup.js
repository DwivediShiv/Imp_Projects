import '@testing-library/jest-dom/extend-expect'
import { jest } from '@jest/globals'
import './__mocks__/svgrMock'
import { server } from '../src/libs/utils/msw'

const { TextEncoder, TextDecoder } = require('util')
global.TextEncoder = TextEncoder
global.TextDecoder = TextDecoder

/**
 * Sets up mock service worker for our unit tests.
 * We use mock service worker to avoid manually mocking methods using `fetch` API.
 */
beforeAll(() => server.listen())

afterEach(() => server.resetHandlers())

afterAll(() => server.close())
