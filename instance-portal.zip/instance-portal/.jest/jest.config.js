const nextJest = require('next/jest')

const createJestConfig = nextJest({
  // Provide the path to your Next.js app to load next.config.js and .env files in your test environment
  dir: './'
})

// Add any custom config to be passed to Jest
const customJestConfig = {
  preset: 'ts-jest',
  verbose: true,
  runner: 'jest-runner',
  rootDir: '../',
  // Add more setup options before each test is run
  setupFilesAfterEnv: ['<rootDir>/.jest/jest.setup.js'],
  testEnvironment: 'jest-environment-jsdom',
  // if using TypeScript with a baseUrl set to the root directory then you need the below for alias' to work
  moduleDirectories: ['node_modules', '<rootDir>/src'],
  modulePaths: ['<rootdir>/src'],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'node'],
  moduleNameMapper: {
    '\\.svg': '<rootDir>/.jest/__mocks__/svgrMock.tsx',
    '@/components/(.*)$': '<rootDir>/components/$1',
    '@components/Publish/(.*)$': '<rootDir>/src/components/Publish/$1',
    '@instanceportal(.*)$': '<rootDir>/src/$1',
    '@components/Publish/_constants$':
      '<rootDir>/src/components/Publish/_constants',
    '@sharedComponents(.*)$': '<rootDir>/src/libs/sharedComponents/$1',
    '@hooks/(.*)$': '<rootDir>/src/libs/hooks/$1',
    '@core/(.*)$': '<rootDir>/src/libs/core/$1',
    '@constants/(.*)$': '<rootDir>/src/libs/constants/$1',
    '@context/(.*)$': '<rootDir>/src/@context/$1',
    '@images/(.*)$': '<rootDir>/src/@images/$1',
    '@utils/(.*)$': '<rootDir>/src/libs/utils/$1',
    '@content/(.*)$': '<rootDir>/@content/$1',
    'src/@types/(.*)$': '<rootDir>/src/@types/$1',
    'src/components/Constants': '<rootDir>/src/components/Constants',
    'app.config': '<rootDir>/app.config',
    'src/components/pages/Constants':
      '<rootDir>/src/components/pages/Constants',
    'src/components/pages/Profile/(.*)$':
      '<rootDir>/src/components/pages/Profile/$1',
    'src/components/Publish/': '<rootDir>/src/components/Publish',
    'src/components/pages/Admin/(.*)$':
      '<rootDir>/src/components/pages/Admin/$1',
    'src/components/Constants': '<rootDir>/src/components/Constants',
    'src/components/pages/Profile/Published/Constants':
      '<rootDir>/src/components/pages/Profile/Published/Constants',
    'src/pages/landingpage/hooks/(.*)$':
      '<rootDir>/src/pages/landingpage/hooks/$1',
    'src/@types/aquarius/(.*)$': '<rootDir>/src/@types/aquarius/$1',
    '@walletconnect/web3-provider':
      '<rootDir>/node_modules/@walletconnect/web3-provider/dist/cjs/index.d.ts',
    'is-url-superb': '<rootDir>/node_modules/is-url-superb/index.d.ts',
    wagmi: '<rootDir>/node_modules/wagmi/dist/index.d.ts'
  },
  collectCoverage: true,
  collectCoverageFrom: [
    'src/**/*.{ts,tsx}',
    '!src/**/*.{stories,test}.{ts,tsx}',
    '!src/@types/**/*.{ts,tsx}'
  ],
  testTimeout: 15000,
  coveragePathIgnorePatterns: ['/node_modules/', '.index.tsx'],
  testPathIgnorePatterns: [
    'node_modules',
    '\\.cache',
    '.next',
    'coverage',
    // ignore the breaking big changes test fix
    'src/@context/Prices',
    '.storybook/storyshots.test.tsx',
    '.index.tsx'
  ],
  transform: {
    '^.+\\.ts$': 'ts-jest',
    '\\.[jt]sx?$': 'babel-jest'
  },
  transformIgnorePatterns: [
    'node_modules/(?!(is-url-superb|wagmi)/)',
    'node_modules/wagmi/dist/chains.js'
  ]

  // testRegex: '(/__test__/.*|(\\.|/)(test|spec))\\.[jt]sx?$',
  // transform: { '^.+\\.(t|j)sx?$': '<rootDir>/jest/preprocess.ts' }
}

// createJestConfig is exported this way to ensure that next/jest can load the Next.js config which is async
module.exports = createJestConfig(customJestConfig)
