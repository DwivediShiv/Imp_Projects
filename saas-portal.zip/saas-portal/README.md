[![banner](https://raw.githubusercontent.com/oceanprotocol/art/master/github/repo-banner%402x.png)](https://oceanprotocol.com)

<h1 align="center">Saas Portal</h1>

## 🏄 Get Started

The app is a React app built with [Next.js](https://nextjs.org) + TypeScript + CSS modules and will connect to Ocean remote components by default.

To start local development:

```bash
git clone https://git.i.mercedes-benz.com/acentrik/saas-portal.git
cd saas-portal

# when using nvm to manage Node.js versions
nvm use

```

Login to AWS CodeArtifact

```bash
aws codeartifact login --tool npm --domain acentrik --domain-owner 540306422608 --repository package-js
```

Set AUTH Token to ENV VAR for npm install authentication with AWS CodeArtifact Registry

```bash
export CODEARTIFACT_AUTH_TOKEN=`aws codeartifact get-authorization-token --domain acentrik --domain-owner 540306422608 --query authorizationToken --output text`
```

npm package installation

```bash
npm install
# in case of dependency errors, rather use:
# npm install --legacy-peer-deps
npm start
```

This will start the development server under
`http://localhost:8000`.

Finally, set environment variables to use this local connection in `.env` in the app:

```bash
# modify env variables
cp .env.example .env

npm start
```
