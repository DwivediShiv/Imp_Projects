import appConfig from '../../../app.config'

export const MAX_DECIMALS = 6
export const USDC_DECIMAL = 6
export const WEI_DECIMAL = 18
export const SAMPLE_TYPE_UPLOAD = 'UPLOAD'
export const SAMPLE_TYPE_URL = 'URL'
export const SMALL_DESKTOP_BREAKPOINT = 1280
export const DEFAULT_DOWNLOAD_FILE_NAME = 'download'
export enum IconSize {
  ExtraLarge = 'iconSizeExtraLarge',
  Large = 'iconSizeLarge',
  Medium = 'iconSizeMedium',
  Small = 'iconSizeSmall'
}

export enum IconColor {
  Primary = 'iconColorPrimary',
  Secondary = 'iconColorSecondary',
  Info = 'iconColorInfo'
}
export enum ImageSize {
  Large = 'imageSizeLarge',
  Small = 'imageSizeSmall'
}
export const SUPPORT_EMAIL = appConfig.supportEmail
export const MAILETO_SUPPORT = `mailto:${SUPPORT_EMAIL}`
export const MAXIMUM_NUMBER_OF_PAGES_WITH_RESULTS = 476
export const STATE_DELIST = 1
export const STATE_ACTIVE = [0, 4]
export const START_TRUNCATE = 36
export const END_TRUNCATE = 14
export const DOT = '...'
export const MINIMUM_URL_LENGTH = 20
export const NOTCHED_OUTLINE = 'notchedOutline'
export const SET_AUTOCOMPLETE_EXPAND = 'setAutocompleteExpand'

// Error constants
export const ERROR_EMAIL_ALREADY_EXISTS = {
  CODE: 'EMAIL_ALREADY_EXISTS',
  MESSAGE: 'A user with this email already exists.'
}

export const MESSAGE_ACCOUNT_EXISTING =
  'There is an existing account registered with this email address. Please log in using the same or register a new one.'

export const COMPUTE_OPTION = {
  nodejs: 'NodeJS 16.0.0',
  'python3.7': 'Python 3.7',
  custom: 'Custom Public Docker Image'
}

export const INVITED_USER_STATES = {
  invited: 'Invited',
  accepted: 'Active',
  dormant: 'Dormant',
  delete: 'Delete'
}

export const TOKEN_SUBJECT_STRING = {
  invite: 'InviteSaasUser'
}

export const MESSAGE_PASSWORD_NOT_MEET_REQUIREMENT =
  'The password you entered does not meet all the requirements.'

export const PASSWORD_POLICY_INDEX = 5

export const REQUIRED_FIELD = 'Required Field'
export const MAX_100_CHAR_ALLOWED = 'Maximum 100 characters allowed.'
export const MAX_25_CHAR_ALLOWED = 'Maximum 25 characters allowed.'
export const MAX_200_CHAR_ALLOWED = 'Maximum 200 characters allowed.'
export const MAX_500_CHAR_ALLOWED = 'Maximum 500 characters allowed.'
export const MAX_50_CHAR_ALLOWED = 'Maximum 50 characters allowed.'
export const ENTER_VALID_EMAIL = 'Please enter a valid email address.'
export const MAX_FILE_SIZE_1_MB = 'File size should not exceed 1 MB'

export const STATE_CONSTANTS = {
  ACCEPTED: 'Active',
  UNVERIFIED: 'Unverified',
  INVITED: 'Invited',
  INACTIVE: 'Inactive'
}

export const LoginFailed = {
  code: 'ERROR_USER_AUTHENTICATION_FAILED',
  message:
    'Login failed. Please check your business email address / password and try again.'
}

export const SELECTION_CONSTANTS = {
  ALL: 'All'
}

export const STATUS_CODE_INCORRECT_OTP = 'ERROR_LOGIN_OTP_INCORRECT'
export const STATUS_CODE_EXPIRED_OTP = 'ERROR_LOGIN_OTP_EXPIRED'
export const INVALID_OTP_ERR_MSG = 'Invalid OTP. Please try again.'
export const EXPIRED_OTP_ERR_MSG =
  'OTP has expired. Please resend another OTP and try again.'

export const USER_MESSAGES = {
  USER_DELETED: 'User deleted sucessfully',
  USER_INVITED: 'User invitation sent sucessfully',
  USER_INFO_UPDATED: 'User information updated sucessfully',
  ERROR_COMMON: 'Unexpected error ocurred'
}
export const INSTANCE_MESSAGES = {
  INSATNCE_DELETED: 'Instance deletion sucessfully triggered.',
  ERROR_COMMON: 'Unexpected error ocurred'
}
export const MANAGE_USER_DETAILS_CONSTANTS = {
  SUCCESS: 'Updated successfully!',
  ERROR: 'Unable to save changes. Please try again later.'
}

export const ERROR_MSG = 'Unexpected Error Occurred.'

export const ADD_CUSTOMER_SUCCESS_MSG = 'New customer has been created.'
export const ADD_CLUSTER_SUCCESS_MSG = 'New cluster has been created.'

export const ERROR_USER_NOT_FOUND = {
  CODE: 'ERROR_USER_NOT_FOUND',
  MESSAGE: 'User not found'
}

export const ERROR_CUSTOMER_ALREADY_EXISTS = 'ERROR_ENTRY_ALREADY_EXIST'

export const STATUS_CONSTANTS = {
  Provisioned: { title: 'Provisioned', variant: 'default' },
  'Finalizing Instance': { title: 'Finalizing Instance', variant: 'disabled' },
  Active: { title: 'Active', variant: 'success' },
  Inactive: { title: 'Inactive', variant: 'disabled' },
  'Pending Verification': { title: 'Pending Verification', variant: 'warning' }
}

export const INSTANCE_STATUS = {
  ACTIVE: 'Active',
  INACTIVE: 'Inactive',
  'BUILD FAILED': 'Build Failed',
  'DELETION FAILED': 'Deletion Failed',
  'ACTIVATION FAILED': 'Activation Failed',
  'INACTIVATION FAILED': 'Inactivation Failed',
  'NETWORK DEPLOYMENT FAILED': 'Network Deployment Failed',
  'VERSION DEPLOYMENT FAILED': 'Version Deployment Failed'
}
