export const PERMISSION_BROWSE = 'browse'
export const PERMISSION_CONSUME = 'consume'
export const PERMISSION_PUBLISH = 'publish'
export const PERMISSION_ADMIN = 'admin'
export const PERMISSION_CUSTOMERMNGR = 'customer-manager'
export const PERMISSION_INFRAMANAGER = 'infra-manager'
export const GENERAL_FAILURE = 'General Failure'
export const RESTRICTED_ACCESS = 'Restricted Access'
export const ERROR_UNAUTH = 'Error_UnAuthorizedUserAction'
export const FAILURE_MESSAGES = {
  RESTRICTED_ACCESS: 'Unfortunately you do not have access to this page.',
  GENERAL_FAILURE: `An error occured please try again later.`
}
