export const REJECT_FILE_TYPE = [
  'text/javascript', // .js (will obselete)
  'application/x-javascript', // .js
  'application/xml', // .xml, .asa, .asax
  'application/java-archive', // .jar
  'text/html', // .html, htm
  'application/xhtml+xml', // .xhtml
  'application/vnd.ms-word.document.macroEnabled.12', // .docm
  'application/vnd.ms-xpsdocument', // .xps
  'application/oxps', // .xps
  'text/vbscript', // .vbs
  'application/octet-stream', // .exe, .scr, .bin
  'application/x-sh', // .sh
  'application/x-python-code', // .py
  'text/x-python', // .py,
  'text/x-python-script', // .py (for firefox)
  'application/x-httpd-php', // .php
  'application/pkix-cert', // .cer
  'application/x-x509-ca-cert', // .swf
  'application/x-shockwave-flash', // .swf
  'application/x-silverlight-app' // .xap
]
