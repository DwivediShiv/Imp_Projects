export const ROLE_USER = 'user'
export const ROLE_CONSUMER = 'consumer'
export const ROLE_PUBLISHER = 'publisher'
export const ROLE_ADMIN = 'admin'
export const ROLE_CUSTMNGR = 'customer-manager'
export const ROLE_INFRA_MANAGER = 'infra-manager'
export const ROLE_VALIDATED = 'validated'
export const ROLE_SUPERADMIN = 'super-admin'
export const ROLE_ADMIN_INITIAL = 'A'
export const VALID_INPUT_ROLES = ['Admin', 'Infra Manager', 'Customer Manager']

export const ALLOWED_ROLES = {
  ADMIN: 'Admin',
  INFRA_MANAGER: 'Infra Manager',
  CUSTOMER_MANAGER: 'Customer Manager'
}
