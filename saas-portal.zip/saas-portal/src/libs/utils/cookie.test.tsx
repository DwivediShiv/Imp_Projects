import moment from 'moment'
import { deleteCookie, writeCookie } from './cookie'

jest.mock('moment', () => {
  const defaultMoment = jest.requireActual('moment')
  return () => defaultMoment.utc('2024-06-20T00:00:00Z')
})

const mockedCookieName = 'testCookie'
const mockedCookieValue = 'cookieValue'
const mockedExpiryInSeconds = 1800
const mockedDateFormat = 'ddd, DD MMM YYYY HH:mm:ss'

describe('cookie', () => {
  let documentCookie

  const setupDocumentCookie = () => {
    Object.defineProperty(document, 'cookie', {
      get: () => documentCookie,
      set: (cookie) => {
        documentCookie = cookie
      },
      configurable: true
    })
  }

  const setupWindow = (https = true) => {
    Object.defineProperty(window, 'location', {
      value: {
        protocol: https ? 'https:' : 'http'
      },
      writable: true
    })
  }

  describe('writeCookie', () => {
    beforeEach(() => {
      jest.resetAllMocks()
      documentCookie = ''
      setupWindow()
      setupDocumentCookie()
    })

    it('should set a secure cookie with SameSite=strict and correct expiration time', async () => {
      writeCookie(mockedCookieName, mockedCookieValue, mockedExpiryInSeconds)
      const expectedExpiry = moment()
        .add(mockedExpiryInSeconds + 10, 'seconds')
        .utc()
        .format(mockedDateFormat)
      const expectedCookie = `${mockedCookieName}=${mockedCookieValue};path=/;SameSite=strict;secure;expires=${expectedExpiry} GMT;`
      expect(document.cookie).toBe(expectedCookie)
    })

    it('should set a secure cookie without secure if secure flag is not set from process.env and correct expiration time', async () => {
      setupWindow(false)
      writeCookie(mockedCookieName, mockedCookieValue, mockedExpiryInSeconds)
      const expectedExpiry = moment()
        .add(mockedExpiryInSeconds + 10, 'seconds')
        .utc()
        .format(mockedDateFormat)
      const expectedCookie = `${mockedCookieName}=${mockedCookieValue};path=/;SameSite=strict;expires=${expectedExpiry} GMT;`
      expect(document.cookie).toBe(expectedCookie)
    })

    it('should console error if required function params are undefined', async () => {
      expect(() =>
        writeCookie(undefined, mockedCookieValue, mockedExpiryInSeconds)
      ).toThrowError('writeCookie err: required information is missing')
      expect(() =>
        writeCookie(mockedCookieName, undefined, mockedExpiryInSeconds)
      ).toThrowError('writeCookie err: required information is missing')
      expect(() =>
        writeCookie(mockedCookieName, mockedCookieValue, undefined)
      ).toThrowError('writeCookie err: required information is missing')
    })
  })

  describe('deleteCookie', () => {
    beforeEach(() => {
      jest.resetAllMocks()
      documentCookie = ''
      setupDocumentCookie()
      setupWindow()
    })

    it('should provide a cookie string without a value', async () => {
      writeCookie(mockedCookieName, mockedCookieValue, mockedExpiryInSeconds)
      deleteCookie(mockedCookieName)
      const expectedExpiry = moment().utc().format(mockedDateFormat)
      expect(document.cookie).toBe(
        `${mockedCookieName}=; path=/; SameSite=strict; expires=${expectedExpiry} GMT;`
      )
    })
  })
})
