/* eslint-disable @typescript-eslint/no-explicit-any */

import appConfig from './../../../../app.config'

export function getSelectionOptionUrl(): string {
  return `${appConfig.api}/asset-management/api/v1/general/selection-option`
}

/** end IPFS api */
