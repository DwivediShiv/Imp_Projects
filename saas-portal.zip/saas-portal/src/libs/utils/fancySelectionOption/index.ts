import axios, { AxiosResponse } from 'axios'
import { getSelectionOptionUrl } from './api'
import { convertSnakeToCamel } from '../conversion'
import { SelectionOption } from '@libs/types/SelectionOptions'

let inMemorySelectionOptions: SelectionOption[] = []

async function populateSelectionOptions(
  isForce?: boolean
): Promise<SelectionOption[]> {
  if (!isForce && inMemorySelectionOptions?.length) {
    return
  }
  const response: AxiosResponse = await axios({
    method: 'GET',
    url: getSelectionOptionUrl()
  })
  inMemorySelectionOptions = response?.data?.map((d) => {
    return convertSnakeToCamel(d)
  })
}

export async function getSelectionOptions(
  category?: string
): Promise<SelectionOption[]> {
  await populateSelectionOptions()
  if (!category) {
    return inMemorySelectionOptions
  }
  const filteredOptions = inMemorySelectionOptions.filter((option) => {
    return option.category === category
  })
  return filteredOptions
}
