export const isBrowser = typeof window !== 'undefined'
interface ErrorDetails {
  message?: string
}
interface ErrorResponse {
  response: {
    data: {
      errorDetails?: ErrorDetails
      code?: string
    }
  }
}
export function printErrorStack(errorResponse: ErrorResponse): void {
  console.error(errorResponse, errorResponse?.response?.data)
}
