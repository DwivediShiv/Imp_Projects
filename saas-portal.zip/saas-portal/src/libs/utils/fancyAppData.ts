const inMemoryWalletAccess: {
  [walletId: string]: boolean
} = {}
const inMemoryValue: {
  [key: string]: any
} = {}
let inMemoryDockerImage: {
  [key: string]: any
} = {}

export function getInMemoryWalletAccess(
  walletId: string,
  eventType: string
): boolean {
  if (!walletId || !eventType) {
    return false
  }
  return inMemoryWalletAccess[`${walletId}_${eventType}`]
}

export function setInMemoryWalletAccess(
  walletId: string,
  eventType: string,
  access: boolean
): void {
  inMemoryWalletAccess[`${walletId}_${eventType}`] = access
}

export function getInMemoryValue(key: string): any {
  return inMemoryValue[key]
}

export function setInMemoryValue(key: string, value: any): void {
  inMemoryValue[key] = value
}

export function removeInMemory(key: string): void {
  delete inMemoryValue[key]
}

export function setInMemoryDockerImage(key: string, value: any): void {
  inMemoryDockerImage[key] = value
}

export function getInMemoryDockerImage(key: string): any {
  return inMemoryDockerImage[key]
}

export function deleteAllInMemoryDockerImage(): void {
  inMemoryDockerImage = {}
}
