import { isBrowser } from '.'
import {
  PERMISSION_BROWSE,
  PERMISSION_CONSUME
} from '@constants/permissionConstants'

import {
  getInMemoryValue,
  removeInMemory,
  setInMemoryValue
} from './fancyAppData'

const allowWithoutLogin = {
  asset: PERMISSION_CONSUME
}
const freeToAccessRole = {
  asset: PERMISSION_BROWSE,
  search: PERMISSION_BROWSE
}

const iconicBigBoardPath = ['search']

export function setAsLastVisitUrl(): void {
  setInMemoryValue('lastVisitPath', window.location.href)
}

const staticPages = []

const withoutHeaderFooterPages = [
  'login',
  'accept-invite',
  'forget-password',
  'reset'
]

export function isWithoutHeaderFooterPages(): boolean {
  if (!isBrowser) return
  const currentLocation = location?.pathname.split('/')[1]
  return withoutHeaderFooterPages.includes(currentLocation)
}

export function isStaticPages(): boolean {
  if (!isBrowser) return
  const currentLocation = location?.pathname.split('/')[1]
  return staticPages.includes(currentLocation)
}

export function isIconicBigBoard(): boolean {
  const currentLocation = location.pathname
  return iconicBigBoardPath.some((i) => currentLocation.indexOf(i) !== -1)
}

export function isFreeToAccessPage(event: string): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return freeToAccessRole[currentLocation] === event
}

export function isAllowWithoutLogin(event: string): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return allowWithoutLogin[currentLocation] === event
}

export function removeLastVisitUrl() {
  removeInMemory('lastVisitPath')
}

export function getLastVisitUrl(clearCache?: boolean): string {
  const url = getInMemoryValue('lastVisitPath')
  if (clearCache) {
    removeLastVisitUrl()
  }
  return url
}
