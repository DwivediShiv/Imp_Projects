import axios, { AxiosResponse } from 'axios'
import Router from 'next/router'
import jwt, { JwtPayload } from 'jwt-decode' // import dependency
// import { removeLastVisitUrl } from './platformSetting'
import {
  getLocalStorage,
  setLocalStorage,
  writeCookie,
  deleteCookie,
  readCookie
} from '../cookie'
import { postAuthenticationUrl, getUserRolesUrl } from './apis'
import { JWTActionToken, ResponseToken } from '@libs/types/Auth'
import { UserProfileRoles } from '@libs/types/User'
import { JWT_LATEST_EXPIRY } from '@constants/jwtConstants'
import { ROLE_ADMIN, ROLE_VALIDATED } from '@constants/roleConstants'
import Toast from '@sharedComponents/Toast'
import { ONE_MINUTE_IN_MS, ONE_SECOND_IN_MS } from '../constants'

let inMemoryToken: ResponseToken = null
let interval: NodeJS.Timeout
let inMemoryJwtActionToken: JWTActionToken = null
let isActive = false
let inMemoryRole: UserProfileRoles = null

export function setActive() {
  isActive = true
}

export function checkIsActive(jwtObj: JwtPayload, jwtLatestExpiry?: string) {
  jwtLatestExpiry = jwtLatestExpiry || getLocalStorage(JWT_LATEST_EXPIRY)
  isActive = jwtLatestExpiry && jwtLatestExpiry === jwtObj?.exp?.toString()
}

export function isLatestActiveSession(jwtLatestExpiry?: string) {
  jwtLatestExpiry = jwtLatestExpiry || getLocalStorage(JWT_LATEST_EXPIRY)
  if (!inMemoryToken?.token) {
    return false
  }
  const jwtObj = jwt<JwtPayload>(inMemoryToken.token)
  checkIsActive(jwtObj, jwtLatestExpiry)
  return jwtLatestExpiry && jwtLatestExpiry === jwtObj?.exp?.toString()
}

export const keycloakLogout = (pageProp?: any): void => {
  inMemoryRole = null
  inMemoryToken = null
  inMemoryJwtActionToken = null
  clearInterval(interval)
  // removeLastVisitUrl()
  interval = null
  setLocalStorage(JWT_LATEST_EXPIRY, '')
  deleteCookie('refresh_token_saas')
  !pageProp && Toast('success', 'You have successfully logged out.')
  Router.push(
    {
      pathname: '/login',
      query: pageProp
    },
    '/login'
  )
}

export function setTabSessionInactive(): void {
  isLatestActiveSession() && isActive && keycloakLogout({ reason: 'timeout' })
}

async function authentication(isGetTokenOnly?: boolean): Promise<any> {
  const refreshToken = readCookie('refresh_token_saas')
  const jwtLatestExpiry = getLocalStorage(JWT_LATEST_EXPIRY)

  if (!isGetTokenOnly && !isActive && !jwtLatestExpiry && !refreshToken) {
    keycloakLogout({ reason: 'timeout' })
    return
  }
  if (refreshToken && (isActive || jwtLatestExpiry)) {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: postAuthenticationUrl(),
        data: {
          refresh_token: refreshToken
        }
      })
      writeCookie(
        'refresh_token_saas',
        response.data.data.refresh_token,
        response.data.data.refresh_expires_in
      )

      !isGetTokenOnly && isLatestActiveSession()

      inMemoryJwtActionToken = jwt(response.data.data.access_token)

      isActive &&
        setLocalStorage(JWT_LATEST_EXPIRY, inMemoryJwtActionToken?.exp)

      return {
        token: response.data.data.access_token,
        expiry: response.data.data.expires_in
      }
    } catch (error) {
      keycloakLogout()
      console.log(error)
    }
  }
}

export const startTimer = () => {
  // Get from backend keycloack instead hardcode and subtract one minute grace period
  const calculatedInterval = (inMemoryToken?.expiry - 60) * ONE_SECOND_IN_MS

  // If calculated interval is less than a minute, default to 4 minutes
  const refreshInterval =
    calculatedInterval >= ONE_MINUTE_IN_MS
      ? calculatedInterval
      : 4 * ONE_MINUTE_IN_MS

  if (!interval) {
    interval = setInterval(async () => {
      const nowInGMT =
        Date.now() - new Date().getTimezoneOffset() * ONE_MINUTE_IN_MS

      if (
        !inMemoryToken ||
        nowInGMT >= inMemoryToken.expiry * ONE_SECOND_IN_MS
      ) {
        inMemoryToken = await authentication()
      }
    }, refreshInterval)
  }
}

export const setCookiesOnLogin = (response: any) => {
  if (response) {
    writeCookie(
      'refresh_token_saas',
      response.refresh_token,
      response.refresh_expires_in
    )
    return true
  } else {
    Toast('error', 'Unable to write to cookies.')
    return false
  }
}

export const onKeycloakToken = (response: any) => {
  if (response) {
    inMemoryToken = {
      token: response.access_token,
      expiry: response.expires_in
    }
    inMemoryJwtActionToken = jwt(response.access_token)
    setLocalStorage(JWT_LATEST_EXPIRY, inMemoryJwtActionToken?.exp)
    writeCookie(
      'refresh_token_saas',
      response.refresh_token,
      response.refresh_expires_in
    )
    return true
  } else {
    Toast('error', 'Unable to write to cookies.')
    return false
  }
}

export const isLoggedIn = (): boolean => {
  return !!readCookie('refresh_token_saas')
}

export const getCurrentAccessToken = (): string => {
  if (!isLoggedIn() || !inMemoryToken) {
    return null
  }
  return inMemoryToken.token
}

export const getAccessToken = async (): Promise<any> => {
  if (inMemoryToken?.token) {
    return inMemoryToken.token
  } else {
    const token = await authentication(true)
    if (!token) {
      return null
    }
    inMemoryToken = token
    return inMemoryToken.token
  }
}

export async function getRoles(): Promise<any> {
  if (!inMemoryJwtActionToken) {
    await getAccessToken()
  }

  const userId = inMemoryJwtActionToken?.sub

  const response: AxiosResponse = await axios({
    method: 'GET',
    url: getUserRolesUrl(userId)
  })

  return response.data.data
}

export async function fetchRoles() {
  if (!isLoggedIn()) return
  inMemoryRole = await getRoles()
}

export async function isSuperAdminRole(role: string) {
  await fetchRoles()
  const filteredRole = inMemoryRole?.roles.filter(
    (userRole) => userRole.name === role
  )
  return filteredRole?.length > 0
}

export function hasAccess(role: string): boolean {
  const filteredRole = inMemoryRole?.roles.filter(
    (userRole) => userRole.name === role
  )
  return filteredRole?.length > 0
}

export function isValidatedRole() {
  return hasAccess(ROLE_VALIDATED)
}

export function isAdminRole() {
  return hasAccess(ROLE_ADMIN)
}

export function isValidatedLogin() {
  return isLoggedIn() && isValidatedRole()
}

export const getUserEmail = (): string => {
  if (
    inMemoryToken &&
    inMemoryToken.token &&
    inMemoryJwtActionToken &&
    inMemoryJwtActionToken.email
  ) {
    return inMemoryJwtActionToken.email
  }

  return ''
}
