import appConfig from 'app.config'

export function postAuthenticationUrl(): string {
  return `${appConfig.api}/saas-management/api/v1/saas/access-token`
}

export function getUserRolesUrl(id: string): string {
  return `${appConfig.api}/saas-management/api/v1/saas/users/${id}/roles`
}
