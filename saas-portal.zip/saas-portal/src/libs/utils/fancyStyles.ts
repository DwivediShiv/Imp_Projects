import {
  DOT,
  END_TRUNCATE,
  MINIMUM_URL_LENGTH,
  START_TRUNCATE
} from '@constants/constants'

export const getStatusColor = (
  { isValid, isWarning, isAlert, error, isLoading }: any,
  defaultColor?: string
): string => {
  if (isLoading) {
    return defaultColor || 'var(--neutral-70-color)'
  }
  if (isWarning) {
    return 'var(--warning-color)'
  }
  if (isAlert) {
    return 'var(--danger-color)'
  }
  if (isValid) {
    return 'var(--success-color)'
  }
  if (error) {
    return 'var(--danger-color)'
  }
  return defaultColor || 'var(--neutral-70-color)'
}

export function urlTruncate(url: string): string {
  if (typeof url !== 'string') return
  if (!url && !url?.length) return
  const middle = url?.substring(START_TRUNCATE, url?.length - END_TRUNCATE)
  const truncated = url?.replace(middle, DOT)
  if (middle.length < MINIMUM_URL_LENGTH) return url
  return truncated
}

export function getElevatedColor(color: string, elevation = 0) {
  if (color === 'transparent') return color

  const baseColor = parseInt(color.replace(/\D/g, ''))
  if (isNaN(baseColor) || !Number.isInteger(elevation)) return `var(${color})`

  let elevatedColor = baseColor + elevation * 10
  if (elevatedColor > 100) elevatedColor = 100
  if (elevatedColor < 0) elevatedColor = 0

  return `var(${color.replace(/\d+/, elevatedColor.toString())})`
}

export function truncateLastString(value: string, length: number): string {
  if (!value && !length) return null
  if (value.length < length) return value
  const truncated = value?.substring(0, length) + DOT
  return truncated
}

export const getNumberTypeBorder = ({ type }: any): string => {
  if (type === 'price') {
    return '1px 1px 1px 0px'
  }
  return '1px'
}

export const getCustomTagInputHeight = ({ type }: any) => {
  switch (type) {
    case 'optionsTags': // Consumer Parameter's Options
      return '140px'
    case 'tags': // Further Details's Asset Tag
      return '140px'
  }
}
