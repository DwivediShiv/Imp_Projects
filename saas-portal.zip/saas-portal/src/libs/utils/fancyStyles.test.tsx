import {
  getCustomTagInputHeight,
  getNumberTypeBorder,
  getStatusColor,
  truncateLastString,
  urlTruncate
} from './fancyStyles'

describe('Test on status color', () => {
  test('should get status colour correctly', () => {
    expect(getStatusColor({ isLoading: true })).toBe('var(--neutral-70-color)')
    expect(getStatusColor({ isLoading: true }, 'blue')).toBe('blue')
    expect(getStatusColor({ isWarning: true })).toBe('var(--warning-color)')
    expect(getStatusColor({ isAlert: true })).toBe('var(--danger-color)')
    expect(getStatusColor({ isValid: true })).toBe('var(--success-color)')
    expect(getStatusColor({ error: true })).toBe('var(--danger-color)')
    expect(getStatusColor({})).toBe('var(--neutral-70-color)')
    expect(getStatusColor({}, 'blue')).toBe('blue')
  })
})

describe('Test on trucate url', () => {
  test('should url truncate correctly', () => {
    const url =
      'https://raw.githubusercontent.com/MoH-Malaysia/covid19-public/main/epidemic/cases_state.csv'
    const truncatedUrl = urlTruncate(url)
    expect(truncatedUrl).toBe(
      'https://raw.githubusercontent.com/Mo...ases_state.csv'
    )
  })

  test('should return empty if no value', () => {
    const truncatedUndefinedUrl = urlTruncate(undefined)
    const truncatedEmptyString = urlTruncate('')
    expect(truncatedUndefinedUrl).toBe(undefined)
    expect(truncatedEmptyString).toBe(undefined)
  })

  test('should not truncate if short url value', () => {
    const url = 'https://acentrik.io/'
    const truncatedUrl = urlTruncate(url)
    expect(truncatedUrl).toBe(url)
  })
})

describe('Test on trucate string', () => {
  test('should truncate string correctly', () => {
    expect(truncateLastString(undefined, 0)).toBeNull()
    expect(truncateLastString('ABCD', 100)).toBe('ABCD')
    expect(truncateLastString('Welcome to Acentrik', 7)).toBe('Welcome...')
  })
})

describe('Test on border number by type', () => {
  test('should get border correctly', () => {
    expect(getNumberTypeBorder({})).toBe('1px')
    expect(getNumberTypeBorder({ type: 'price' })).toBe('1px 1px 1px 0px')
  })
})

describe('Test on custom tag input hight', () => {
  test('should get input height correctly', () => {
    expect(getCustomTagInputHeight({ type: 'optionsTags' })).toBe('140px')
    expect(getCustomTagInputHeight({ type: 'tags' })).toBe('140px')
  })
})
