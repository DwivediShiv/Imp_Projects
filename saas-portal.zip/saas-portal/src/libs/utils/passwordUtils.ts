export async function onPasswordChange(val, setFulfilledPolicies) {
  const fulfilledPolicies = []

  const capsUpperRegex = /[A-Z]/
  if (capsUpperRegex.test(val)) {
    fulfilledPolicies.push('PasswordUpperCase')
  }
  const capsLowerRegex = /[a-z]/
  if (capsLowerRegex.test(val)) {
    fulfilledPolicies.push('PasswordLowerCase')
  }
  const lengthRegex = /(?=.{15,})/
  if (lengthRegex.test(val)) {
    fulfilledPolicies.push('PasswordLength')
  }
  const numberRegex = /[0-9]/
  if (numberRegex.test(val)) {
    fulfilledPolicies.push('PasswordNumber')
  }
  const specialRegex = /[!@#$%^&*\]\\[()\-_+={}'|]/
  if (specialRegex.test(val)) {
    fulfilledPolicies.push('PasswordSpecial')
  }

  setFulfilledPolicies(fulfilledPolicies)
  return fulfilledPolicies
}
