import { getInMemoryValue } from './fancyAppData'

let currentCallbackFunc: () => void = null
let currentDelegateKey = ''
const delegateFunction: { [key: string]: any } = {}
const delegateAppDataKey: { [key: string]: string } = {}

export function setDelegateFunction(
  key: string,
  func: any,
  appDataKey?: any
): void {
  currentDelegateKey = key
  delegateFunction[key] = func
  if (appDataKey) {
    delegateAppDataKey[key] = appDataKey
  }
}

export function removeDelegateFunction(key: string): void {
  delete delegateFunction[key]
  delete delegateAppDataKey[key]
  if (key === currentDelegateKey) currentDelegateKey = ''
}

export function getAppData(key?: string): any {
  const appDataKey = delegateAppDataKey?.[key]
  return getInMemoryValue(appDataKey)
}

export function executeDelegateFunction(key?: string) {
  const delegateFunc = delegateFunction?.[key]
  if (!delegateFunc) return
  const appData = getAppData(key)
  appData ? delegateFunc(appData) : delegateFunc()
}

export async function executeCallbackFunc(): Promise<void> {
  currentCallbackFunc && (await currentCallbackFunc())
  currentCallbackFunc = null
}

export function executeAllDelegateFunction() {
  for (const key in delegateFunction) {
    executeDelegateFunction(key)
  }
}

export async function fancyNavigation(callbackFunc: () => void): Promise<void> {
  if (currentDelegateKey) {
    currentCallbackFunc = callbackFunc
    await executeDelegateFunction(currentDelegateKey)
  } else {
    await callbackFunc()
  }
}
