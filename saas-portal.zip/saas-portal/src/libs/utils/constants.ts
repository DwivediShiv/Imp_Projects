export enum IconSize {
  ExtraLarge = 'iconSizeExtraLarge',
  Large = 'iconSizeLarge',
  Medium = 'iconSizeMedium',
  Small = 'iconSizeSmall'
}

export const ORG_LIST_FILE_NAME = 'user.csv'

export const IDLE_TIMEOUT = 30
export const ONE_MINUTE_IN_MS = 60000
export const ONE_SECOND_IN_MS = 1000
