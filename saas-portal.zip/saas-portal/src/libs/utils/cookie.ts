import appConfig from 'app.config'
import moment from 'moment'

export function isCookieAccepted(): boolean {
  return (
    typeof window !== 'undefined' &&
    window.localStorage.getItem('accepted-cookie') === 'true'
  )
}

export function setAcceptCookie(): void {
  typeof window !== 'undefined' &&
    window.localStorage.setItem('accepted-cookie', 'true')
}

export function getLocalStorage(key: string): any {
  return typeof window !== 'undefined' && window.localStorage.getItem(key)
}

export function setLocalStorage(key: string, value: any): void {
  isCookieAccepted() &&
    typeof window !== 'undefined' &&
    window.localStorage.setItem(key, value)
}

function clearLocalStorage(): void {
  if (typeof window !== 'undefined' && window.localStorage.length > 0)
    window.localStorage.clear()
}

function clearSessionStorage(): void {
  if (typeof window !== 'undefined' && window.sessionStorage.length > 0)
    window.sessionStorage.clear()
}

function clearAllCookie(): void {
  if (typeof window === 'undefined' || !window?.document) {
    // fix server side rendering fail build because document doesnt exist
    return
  }
  const cookies = document.cookie.split('; ')
  for (let index = 0; index < cookies?.length; index++) {
    const cookieBase =
      encodeURIComponent(cookies[index].split(';')[0].split('=')[0]) +
      '=; expires=Thu, 01-Jan-1970 00:00:01 GMT;path='
    const pathNameSplit = location.pathname.split('/')
    document.cookie = cookieBase + '/'
    while (pathNameSplit.length > 0) {
      document.cookie = cookieBase + pathNameSplit.join('/')
      pathNameSplit.pop()
    }
  }
}

export function clearClientCache(): void {
  clearLocalStorage()
  clearSessionStorage()
  clearAllCookie()
}

export function writeCookie(name: string, content: string, min: number): void {
  if (!min || !name || !content)
    throw new Error('writeCookie err: required information is missing')
  const secureFlag = window.location.protocol === 'https:' ? 'secure;' : ''
  // To handle firefox cookie behavior, slow network might take up to 8 seconds to load js scripts, hence round up 10 sec
  const delay = 10
  const expires = min
    ? `expires=${moment()
        .add(min + delay, 'seconds')
        .utc()
        .format('ddd, DD MMM YYYY HH:mm:ss')} GMT;`
    : ''
  const cookieStr = `${encodeURIComponent(name)}=${encodeURIComponent(
    content
  )};path=/;SameSite=strict;${secureFlag}${expires}`
  document.cookie = cookieStr
}

export function readCookie(name: string): string {
  if (typeof window === 'undefined' || !window?.document) {
    // fix server side rendering fail build because document doesnt exist
    return
  }
  const nameEQ = name + '='
  const ca = document.cookie.split(';')
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === ' ') c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

export function deleteCookie(name: string): void {
  document.cookie = `${encodeURIComponent(
    name
  )}=; path=/; SameSite=strict; expires=${moment()
    .utc()
    .format('ddd, DD MMM YYYY HH:mm:ss')} GMT;`
}
