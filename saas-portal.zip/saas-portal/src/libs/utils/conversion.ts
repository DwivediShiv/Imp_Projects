import { camelCase, mapKeys, toNumber } from 'lodash'
import moment from 'moment'
const TRUNC_ACC_START = 22
const TRUNC_ACC_END = 38

export function megaByteToByte(size: string): number {
  return parseInt(size) * 1024 * 1024
}

export function byteToMegaByte(size: string): string | number {
  if (!size) {
    return size
  }
  try {
    return parseInt(size) / 1024 / 1024
  } catch {
    return size
  }
}

export function megaByteIndication(size: string): string {
  const mbSize = byteToMegaByte(size)
  if (typeof mbSize !== 'number') {
    return size
  }
  return mbSize < 25 ? '<25' : mbSize.toFixed(2)
}

export function getMegaByte(size: string): string {
  const mbSize = byteToMegaByte(size)
  if (typeof mbSize !== 'number') {
    return size
  }
  return mbSize.toFixed(2)
}

export function durationToNowInTimestamp(date: string): number {
  const dataTimestamp = new Date(date).getTime()
  const timestamp = Math.round((new Date().getTime() - dataTimestamp) / 1000)
  return timestamp
}

export function convertDate(
  date: string,
  format?: string,
  inputFormat?: string,
  defaultText?: string
) {
  return date
    ? inputFormat
      ? moment(date, inputFormat).format(format || 'DD MMM YYYY, hh:mm A')
      : moment(new Date(date)).format(format || 'DD MMM YYYY, hh:mm A')
    : defaultText || '-'
}

// export function durationToNow(date: string): string {
//   return secondsToString(durationToNowInTimestamp(date))
// }

export function getFileTypeWithoutCharset(mime: string): string {
  if (!mime) return
  const semiColoIndex = mime.indexOf(';')
  return mime.substr(0, semiColoIndex)
}

export function convertSnakeToCamel(data) {
  const camel = mapKeys(data, (value, key) => camelCase(key))
  return camel
}

export function truncateEnding(text: string, length: number): string {
  if (!length) return
  if (text?.length > length) {
    const truncated = text.substring(0, length).concat('...')
    return truncated
  } else {
    return text
  }
}

export function addressTruncate(address: string): string {
  if (!address || address === '') return
  const middle = address.substring(6, 38)
  const truncated = address.replace(middle, '…')
  return truncated
}

export function capitalizeFirstLetter(str: string) {
  return str.charAt(0).toUpperCase() + str.slice(1)
}
