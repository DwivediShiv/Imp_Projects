export interface UserProfileRoles {
  roles: UserRoleData[]
  wallets: Wallet[]
}

export interface UserRoleData {
  id: string
  name: string
  clientRole: boolean
  composite: boolean
  containerId: string
  description: string
}
