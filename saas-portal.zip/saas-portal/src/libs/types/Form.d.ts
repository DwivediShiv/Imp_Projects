import { GridSize } from '@mui/material'
import { PasswordPolicy } from '../components/molecules/FormFields/PasswordStrength'

export interface FormFieldProps {
  label?: string
  extraLabel?: string
  name: string
  value?: string
  decimal?: boolean
  type?: string
  options?: string[] | AssetSelectionAsset[]
  optionType?: string
  sortOptions?: boolean
  required?: boolean
  multiple?: boolean
  disabled?: boolean
  help?: string
  placeholder?: string
  pattern?: string
  min?: string
  step?: string
  passwordPolicies?: PasswordPolicy[]
  addonInput?: FormFieldProps
  combineWith?: string[]
  isPartOfCombination?: boolean
  gridSize?: GridSize
  optionCategory?: string
  optionKey?: string
  previewTitle?: string
  tooltip?: string
  infotip?: string
  isEditDisabled?: boolean
  disclaimer?: string
  disclaimerValues?: string[]
  advanced?: boolean
  state?: any
  stateMsg?: any
  additionalInformation?: string
  description?: string
  noBoundary?: boolean
  groupFields?: FormFieldProps[]
  getComponent?(data: object): React.ReactNode
}

export interface FormStepContent {
  title: string
  description?: string
  success: string
  asset?: 'dataset' | 'algorithm'
  data: FormFieldProps[]
  tips?: FormTipsProps[]
}

export interface LoginForm {
  email: string
  password: string
}

export interface resetPassForm {
  password: string
  passwordConfirmation: string
}

export interface ChangePassForm {
  currentPassword: string
  password: string
  passwordConfirmation: string
}

export interface ForgetPasswordForm {
  email: string
}

export interface DomainForm {
  domain: string
  status?: boolean
}

export interface AddDemandBoardForm {
  title: string
  description: string
  purpose: string
  category: string
  accessType: string
  region: string
  source: string
  createdByWallet: string
}

export interface FormTipsProps {
  title: string
  name: string
  content: string
  type: string
  label: string
  step: string
}

export interface ContactUsForm {
  email: string
  inquiryType: string
  message: string
  captcha: string
}

export interface ContactPublisherForm {
  inquiryType: string
  message: string
}

// Kris: Ocean usage merge v4 usage below
export interface FormFieldContent {
  label: string
  name: string
  type?: string
  options?: string[]
  sortOptions?: boolean
  required?: boolean
  multiple?: boolean
  disabled?: boolean
  help?: string
  placeholder?: string
  pattern?: string
  min?: string
  disclaimer?: string
  disclaimerValues?: string[]
  advanced?: boolean
}

interface FormStepContent {
  title: string
  description?: string
  fields: FormFieldContent[]
}
