export interface ModalFieldValue {
  template: string
  value: any
}
