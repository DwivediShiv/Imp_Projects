import React, { ReactElement } from 'react'
import Link from 'next/link'
import { ReactNode } from 'react-markdown/src/ast-to-react'
import styles from './index.module.css'
import classNames from 'classnames'
import { getFancyWebPortalUri } from '@utils/url'

export default function NavigationToWebPortal({
  url,
  fullWidth,
  children
}: {
  url: string
  fullWidth?: boolean
  children: ReactNode
}): ReactElement {
  if (!url) return
  return (
    <Link href={`${getFancyWebPortalUri(url)}`} legacyBehavior>
      <a
        target="_blank"
        className={classNames(styles.href, fullWidth && 'w-100')}
      >
        {children}
      </a>
    </Link>
  )
}
