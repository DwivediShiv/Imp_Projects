import React, { useState, ChangeEvent, ReactElement } from 'react'
import styles from './index.module.css'
import { Drawer } from '@mui/material'
import CustomButton from '../Button'
import CustomDropDown from '../Dropdown'

export default function CustomFilter({
  size,
  value,
  category,
  setCategory,
  isTouched,
  setIsTouched,
  resetForm
}: {
  size: 'small' | 'large'
  value: string
  setValue: (value) => void
  category: string
  setCategory: (value) => void
  isTouched: boolean
  setIsTouched: (value) => void
  resetForm: () => void
  startSearch: (e) => void
}): ReactElement {
  const [showFilterDrawer, setShowFilterDrawer] = useState<boolean>(false)

  function handleCategoryChange(
    e: ChangeEvent<HTMLSelectElement>,
    value?: any
  ) {
    !isTouched && setIsTouched(true)
    setCategory(e.target.value)
  }

  const isDesktopView = size === 'large'

  function renderLargeBox() {
    return (
      <div className={styles.container}>
        <form className={styles.form}>
          <div className={`${styles.switchRow} ${styles.filterRow}`}>
            <h6 className={`${styles.noMargin} ${styles.filterTitle}`}>
              Filters
            </h6>
            <CustomButton
              className={styles.resetBtn}
              onClick={() => resetForm()}
              variant="text"
              size="small"
              disableRipple
              color="primary"
              disabled={value === ''}
            >
              Reset
            </CustomButton>
          </div>
          <div className={`${styles.switchRow} ${styles.search}`}>
            <CustomDropDown
              inputName="category"
              label="Category"
              optionCategory="Industry"
              optionKey="name"
              containerClass="exploreFilter"
              customBackground={
                isDesktopView ? '--surface-1-color' : '--surface-1-color'
              }
              deselectText="All"
              deselectValue="All"
              value={category}
              onChange={handleCategoryChange}
              isFilterBox
            />
          </div>
        </form>
      </div>
    )
  }

  function renderSmallBar() {
    return (
      <>
        <Drawer
          anchor="right"
          open={showFilterDrawer}
          onClose={() => setShowFilterDrawer(false)}
          classes={{ root: styles.fancyDrawer, paper: styles.drawerPaper }}
        >
          <div className={styles.fancyDrawer}>{renderLargeBox()}</div>
          <div className={styles.btnContainer}>
            <CustomButton
              variant="contained"
              color="primary"
              onClick={() => setShowFilterDrawer(false)}
              fullWidth
            >
              Done
            </CustomButton>
          </div>
        </Drawer>
      </>
    )
  }

  return size === 'large' ? renderLargeBox() : renderSmallBar()
}
