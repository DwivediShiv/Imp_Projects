import React, { ReactElement } from 'react'
import styles from './index.module.css'
import { Checkbox, FormControlLabel } from '@mui/material'
import CheckboxDash from '@images/checkbox-dash.svg'
import CheckboxEmpty from '@images/checkbox-empty.svg'
import CheckboxTick from '@images/checkbox-tick.svg'

import { useFormikContext } from 'formik'
import { InputProps } from '../InputField'

function CustomCheckbox({ ...props }: InputProps): ReactElement {
  const { defaultChecked, isIndeterminate, onChange, onClick, label, name } =
    props

  const formik = useFormikContext()
  const fieldHelper = formik?.getFieldHelpers(name)
  const fieldValue: boolean = formik
    ? (formik?.getFieldMeta(name)?.value as boolean)
    : defaultChecked

  function handleOnChange(event) {
    const newValue = event.target.checked
    fieldHelper?.setValue(newValue)
    if (onChange) {
      onChange(event)
    }
  }

  return (
    <div className={styles.checkboxContainer}>
      <FormControlLabel
        className={styles.checkboxControl}
        classes={{ label: styles.checkboxLabel }}
        control={
          <Checkbox
            className={styles.checkbox}
            classes={{
              checked: styles.checkboxChecked,
              indeterminate: styles.checkboxIndeterminate,
              root: styles.checkboxRoot
            }}
            checkedIcon={<CheckboxTick />}
            icon={<CheckboxEmpty />}
            indeterminateIcon={<CheckboxDash />}
            checked={fieldValue}
            indeterminate={isIndeterminate}
            onChange={handleOnChange}
            onClick={onClick}
            disableRipple
            data-testid={name ?? ''}
          />
        }
        label={
          <div className={styles.checkboxLabel} title={name}>
            {label}
          </div>
        }
        key={name}
      />
    </div>
  )
}

export default CustomCheckbox
