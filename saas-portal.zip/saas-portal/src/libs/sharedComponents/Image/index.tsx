import React, { ReactElement, useCallback, useState, useEffect } from 'react'
import { Controlled as ControlledZoom } from 'react-medium-image-zoom'
import 'react-medium-image-zoom/dist/styles.css'
import axios from 'axios'
import styles from './index.module.css'

interface ImageZoomableProps {
  src: string
  isFixSizeImage?: boolean
}

export default function ImageZoomable({
  src,
  isFixSizeImage
}: ImageZoomableProps): ReactElement {
  const [isZoomed, setIsZoomed] = useState(false)
  const [base64Img, setBase64Img] = useState<string>()

  const handleZoomChange = useCallback((shouldZoom) => {
    setIsZoomed(shouldZoom)
  }, [])

  useEffect(() => {
    async function getBase64(url) {
      const img = await axios
        .get(url, {
          responseType: 'arraybuffer'
        })
        .then((response) =>
          Buffer.from(response.data, 'binary').toString('base64')
        )
      if (img) {
        setBase64Img(img)
      }
    }
    getBase64(src)
  }, [src])

  return (
    <div className={styles.container}>
      <ControlledZoom
        overlayBgColorEnd="rgba(15, 15, 15, 0.8)"
        zoomMargin={40}
        isZoomed={isZoomed}
        onZoomChange={handleZoomChange}
      >
        <img
          src={
            base64Img
              ? `data:image/jpeg;charset=utf-8;base64,${base64Img}`
              : undefined
          }
          className={`${isFixSizeImage && styles.fixSizeImage} ${
            isZoomed && styles.zoomedImage
          }`}
        />
      </ControlledZoom>
    </div>
  )
}
