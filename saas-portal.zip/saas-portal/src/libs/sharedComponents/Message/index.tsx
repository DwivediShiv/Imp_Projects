import React, { ReactElement } from 'react'
import { ReactNode } from 'react-markdown'
import styles from './index.module.css'
import { WarningCircleIcon as AlertIcon } from '@sharedComponents/Icon/WarningCircleIcon'
import InfoIcon from '@images/icon_information.svg'
import WarningIcon from '@images/icon_warning.svg'
import SuccessIcon from '@images/icon_success.svg'
import { IconSize } from '@utils/constants'

function Message({
  texts,
  template,
  color,
  className,
  header,
  showIcon,
  type,
  children,
  actionButton,
  iconSize = IconSize.Small
}: {
  texts?: string[] | ReactNode[]
  template?: string
  color?: string
  className?: string
  header?: string
  showIcon?: boolean
  type?: string
  children?: ReactNode
  actionButton?: ReactNode
  iconSize?: IconSize
}): ReactElement {
  const displayIcon = (type) => {
    switch (type) {
      case 'info':
        return <InfoIcon className={`${styles.infoIcon} ${iconSize}`} />
      case 'alert':
        return <AlertIcon iconSize={iconSize} state="warning" />
      case 'redAlert':
        return <AlertIcon iconSize={iconSize} state="danger" />
      case 'warning':
        return <WarningIcon className={`${styles.warningIcon} ${iconSize}`} />
      case 'success':
        return <SuccessIcon className={`${styles.successIcon} ${iconSize}`} />
    }
  }

  function getTemplateContent(template: string): ReactElement {
    switch (template) {
      case 'message': {
        return (
          <>
            {showIcon && <div className={styles.icon}>{displayIcon(type)}</div>}
            {texts?.map((value, index) => (
              <div
                key={index}
                className={`${type ? `d-flex ${styles.text}` : styles.default}`}
              >
                {value}
              </div>
            ))}
          </>
        )
      }
      case 'banner': {
        return (
          <>
            <div className={styles.bannerMessage}>
              {showIcon && (
                <div className={styles.bannerIcon}>{displayIcon(type)}</div>
              )}
              {texts?.map((value, index) => (
                <div key={index}>{value}</div>
              ))}
            </div>
            {actionButton && actionButton}
          </>
        )
      }
      case 'alert': {
        return (
          <div className={styles.alertContent}>
            {showIcon && (
              <div className={`iconSizeLarge`}>{displayIcon(type)}</div>
            )}
            <div className={styles.captionContent}>
              {texts?.map((value, index) => (
                <p className="body2" key={index}>
                  {value} {actionButton && actionButton}
                </p>
              ))}
            </div>
          </div>
        )
      }
      default: {
        return (
          <div className={styles.message}>
            {texts?.map((value, index) => (
              <div key={index} className={styles.withDot}>
                {value}
              </div>
            ))}
          </div>
        )
      }
    }
  }

  return (
    <div
      className={`${styles.container} ${type && !template && `w-100`} ${
        className || ''
      } ${styles[className] || ''} ${styles[template]} ${styles[color]} ${
        styles[type]
      }`}
    >
      {header && (
        <div className={styles.header}>
          {showIcon && <AlertIcon className={styles.headerIcon} />}
          <span className={styles.headerContent}>{header}</span>
        </div>
      )}
      {children ||
        (template ? (
          getTemplateContent(template)
        ) : (
          <div className={`${styles.message} ${type && `d-flex`}`}>
            {showIcon && <div className={styles.icon}>{displayIcon(type)}</div>}
            {texts?.map((value, index) => (
              <div
                key={index}
                className={`${
                  type
                    ? `mt-auto mb-auto d-flex ${styles.text}`
                    : styles.default
                }`}
              >
                {value}
              </div>
            ))}
          </div>
        ))}
    </div>
  )
}

export default Message
