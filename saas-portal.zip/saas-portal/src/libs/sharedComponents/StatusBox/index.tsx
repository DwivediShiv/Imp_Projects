import React from 'react'
import { Button as MuiButton } from '@mui/material'
import styles from './index.module.css'

export const statusClassMapping = {
  Invited: styles.statusBoxInactive,
  Unverified: styles.statusBoxUnverified,
  Accepted: styles.statusBoxActive,
  Active: styles.statusBoxActive,
  Inactive: styles.statusBoxDisabled
}
export interface StatusBoxProps {
  status: string
}

export default function StatusBox({
  status
}: StatusBoxProps): React.ReactElement {
  const statusClass = statusClassMapping[status]
  return (
    <MuiButton variant="outlined" className={statusClass}>
      {status}
    </MuiButton>
  )
}
