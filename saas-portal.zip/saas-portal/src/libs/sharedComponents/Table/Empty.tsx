import * as React from 'react'
import styles from './Empty.module.css'

export default function Empty({
  message
}: {
  message?: string
}): React.ReactElement {
  return <div className={styles.empty}>{message || 'No results found'}</div>
}
