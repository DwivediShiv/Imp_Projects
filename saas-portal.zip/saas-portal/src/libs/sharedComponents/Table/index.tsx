import * as React from 'react'
import DataTable, { IDataTableProps } from 'react-data-table-component'
import styles from './index.module.css'
import { Checkbox } from '@mui/material'
import Pagination from '../Pagination'
import Loader from '../Loader'
import CustomIconicCard, {
  CustomIconicCardSize,
  CustomIconicCardState
} from '../IconicCard'
export interface TableProps extends IDataTableProps<any> {
  isLoading?: boolean
  emptyMessage?: string
  sortField?: string
  sortAsc?: boolean
  className?: string
  data: any
  columns: any
  pagination: any
  currentPage?: number
  setCurrentPage?: (value: number) => any
  paginationPerPage: any
  isSelectable?: boolean
  onSelectedRowsChange?: any
}

function Empty({ message }: { message?: string }): React.ReactElement {
  return (
    <div className={styles.empty}>
      {[].length === 0 ? (
        <div className={`${styles.noData}`}>
          <CustomIconicCard
            header="No records found."
            icon="not-found"
            state={CustomIconicCardState.Warning}
            size={CustomIconicCardSize.Big}
          >
            <div>Please adjust your filters and try again.</div>
          </CustomIconicCard>
        </div>
      ) : (
        message || 'No results found'
      )}
    </div>
  )
}

export default function Table({
  data,
  columns,
  isLoading,
  emptyMessage,
  pagination,
  paginationPerPage,
  currentPage,
  setCurrentPage,
  sortField,
  sortAsc,
  className,
  isSelectable = false,
  onSelectedRowsChange,
  ...props
}: TableProps): React.ReactElement {
  const customCheckbox = ({ onChange, checked, ...props }) => (
    <Checkbox
      className={styles.customCheckbox}
      onChange={onChange}
      checked={checked}
      {...props}
    />
  )

  return (
    <DataTable
      columns={columns}
      data={data}
      className={className ? styles.table + ` ${className}` : styles.table}
      noHeader
      selectableRows={isSelectable}
      selectableRowsNoSelectAll
      pagination={pagination || data?.length >= 9}
      paginationPerPage={paginationPerPage || 10}
      noDataComponent={<Empty message={emptyMessage} />}
      progressPending={isLoading}
      progressComponent={<Loader />}
      onSelectedRowsChange={onSelectedRowsChange}
      selectableRowsComponent={customCheckbox}
      paginationComponent={(paginationProps: any) => (
        <Pagination
          {...paginationProps}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          currentRowCount={Math.min(data?.length, paginationPerPage)}
          className="fancyTablePagination"
        />
      )}
      defaultSortFieldId={sortField}
      defaultSortAsc={sortAsc}
      {...props}
    />
  )
}
