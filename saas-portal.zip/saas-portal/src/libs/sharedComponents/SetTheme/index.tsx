import React, { ReactElement } from 'react'
import useDarkMode from 'use-dark-mode'
import { darkModeConfig } from '../../../../app.config'

// This file is not even neccesary at all since we are using _acentrik.css that do not have a light/dark theme class included.
// Only component css that is still using _variable.css will need this file to hack darkModeConfig in after cookie is accepted.
// See https://github.com/donavon/use-dark-mode for more info of `useDarkMode` plugin
export default function CustomSetTheme(): ReactElement {
  useDarkMode(true, darkModeConfig)
  return <></>
}
