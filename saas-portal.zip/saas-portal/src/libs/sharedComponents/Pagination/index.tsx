import { useState, useEffect, ReactElement } from 'react'
import ReactPaginate from 'react-paginate'
import styles from './index.module.css'
import FancyArrow from '@images/arrow.svg'
import * as React from 'react'

export interface PaginationProps {
  className?: string
  totalPages?: number
  currentPage?: number
  setCurrentPage?: (value: number) => any
  onChangePage?(selected: number, totalRows?: number): void
  rowsPerPage?: number
  currentRowCount?: number
  rowCount?: number
  isShow?: boolean
  lazyLoad?: boolean
  showRowPerPage?: boolean
  onChangeRowsPerPage?: (
    currentRowsPerPage: number,
    currentPage: number
  ) => void
}

export default function Pagination({
  className,
  totalPages,
  currentPage,
  setCurrentPage,
  rowsPerPage = 10,
  currentRowCount = 0,
  rowCount = 0,
  lazyLoad = false,
  showRowPerPage = true,
  onChangePage
}: PaginationProps): ReactElement {
  const [smallViewport, setSmallViewport] = useState(true)
  const [displayRowCount, setDisplayRowCount] =
    useState<number>(currentRowCount)
  const fancyPagecount =
    (currentPage ?? 1) - 1 >= 0 ? (currentPage ?? 1) - 1 : 0
  const lazyLoadPageCount = currentPage

  function getTotalPages() {
    if (totalPages) {
      return totalPages
    }

    const doublePageNumber = rowCount / rowsPerPage
    const roundedPageNumber = Math.round(doublePageNumber)
    const total =
      roundedPageNumber < doublePageNumber
        ? roundedPageNumber + 1
        : roundedPageNumber

    return total
  }

  function handlePageChange(page: number = currentPage ?? 0) {
    const nextPage = page + 1

    setCurrentPage && setCurrentPage(page)
    onChangePage && onChangePage(nextPage)

    setDisplayRowCount(
      getTotalPages() === nextPage ? rowCount % rowsPerPage : currentRowCount
    )
  }

  function handleViewportChange(mq: { matches: boolean }) {
    setSmallViewport(!mq.matches)
  }

  useEffect(() => {
    getTotalPages()
  }, [totalPages, rowCount])

  useEffect(() => {
    lazyLoad && handlePageChange()
  }, [currentPage])

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 600px)')
    handleViewportChange(mq)
    mq.addEventListener('change', handleViewportChange)

    return () => {
      mq.removeEventListener('change', handleViewportChange)
    }
  }, [])

  return (
    <div className={className}>
      <div
        data-testid={`pagination-container-${
          smallViewport ? 'small' : 'large'
        }`}
        className={styles.fancyPagination}
      >
        {showRowPerPage && (
          <span className={styles.paginationMsg}>
            Displaying {lazyLoad ? displayRowCount : currentRowCount} out of{' '}
            {rowCount} result(s)
          </span>
        )}
        {getTotalPages() > 1 && (
          <ReactPaginate
            pageCount={getTotalPages()}
            initialPage={lazyLoad ? lazyLoadPageCount : fancyPagecount}
            marginPagesDisplayed={smallViewport ? 0 : 1}
            pageRangeDisplayed={smallViewport ? 3 : 6}
            onPageChange={(data: { selected: number | undefined }) =>
              handlePageChange(data?.selected)
            }
            disableInitialCallback
            previousLabel={
              <FancyArrow
                className={`iconSizeMedium ${styles.arrow} ${styles.previous}`}
              />
            }
            nextLabel={
              <FancyArrow className={`iconSizeMedium ${styles.arrow}`} />
            }
            breakLabel="..."
            containerClassName={styles.pagination}
            pageLinkClassName={styles.number}
            activeLinkClassName={styles.current}
            previousLinkClassName={styles.prev}
            nextLinkClassName={styles.next}
            disabledClassName={styles.prevNextHidden}
            breakLinkClassName={styles.break}
          />
        )}
      </div>
    </div>
  )
}
