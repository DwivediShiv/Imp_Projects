import React, { ReactElement } from 'react'
import styles from './index.module.css'
import Sort from '@images/sort.svg'
import SortActive from '@images/sort_active.svg'

export default function TableHeader({
  title,
  sortable,
  sortActive,
  sortDirection
}: {
  title: string
  sortable?: boolean
  sortActive?: boolean
  sortDirection?: string
}): ReactElement {
  return (
    <div className={`${styles.header} ${sortActive && styles.sorted}`}>
      {title}{' '}
      {sortable && (
        <span
          className={`${styles.headerSortIcon} ${
            sortActive ? styles.rotated : ''
          } ${sortActive && styles[sortDirection || '']}`}
        >
          {sortActive ? <SortActive /> : <Sort />}
        </span>
      )}
    </div>
  )
}
