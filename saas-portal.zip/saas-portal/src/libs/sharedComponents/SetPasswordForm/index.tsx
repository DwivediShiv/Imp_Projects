import styles from './index.module.css'
import { Field, Formik, Form } from 'formik'
import classNames from 'classnames'
import React from 'react'
import Container from '../Container'
import { FormFieldProps } from '@libs/types/Form'
import PasswordStrength from '../PasswordStrength'
import CustomButton from '../Button'
import InputField from '../InputField'
import Loader from '../Loader'

interface PasswordFormContent {
  title: string
  name: string
  fields: FormFieldProps[]
  validate?: (value: string) => any
}

interface SetPwdFormProps {
  content: PasswordFormContent
  initialValues: object
  validationSchema: any
  handleSubmit: any
  loading?: boolean
  message?: string
  fulfilledPolicies: string[]
  userEmail?: string
}

const SetPasswordForm: React.FC<SetPwdFormProps> = ({
  content,
  initialValues,
  validationSchema,
  handleSubmit,
  loading,
  message,
  fulfilledPolicies,
  userEmail
}) => {
  return (
    <div className={styles.content}>
      <Container
        className={classNames(styles.center, styles.headerContent, 'container')}
      >
        <h3 className={styles.desc}>{content.title}</h3>
        <h6 className={styles.desc}>{userEmail}</h6>
      </Container>
      <Formik
        initialValues={initialValues}
        initialStatus="empty"
        validationSchema={validationSchema}
        onSubmit={async (
          values,
          { setSubmitting, resetForm, setFieldError }
        ) => {
          window.scrollTo({ top: 0, left: 0, behavior: 'smooth' })
          await handleSubmit(values, resetForm, setFieldError)
          setSubmitting(false)
        }}
      >
        {({ isValid, dirty }) => {
          return (
            <Form className={styles.form}>
              {content.fields.map((field: FormFieldProps, index: number) =>
                field.passwordPolicies ? (
                  <div
                    key={index}
                    className={`${styles.password} ${
                      fulfilledPolicies.length === field.passwordPolicies.length
                        ? styles.valid
                        : styles.invalid
                    }`}
                  >
                    <Field
                      key={field.name}
                      {...field}
                      component={InputField}
                      customBackground="transparent"
                      validate={content?.validate}
                    />
                    <PasswordStrength
                      key={'password-strength-' + field.name}
                      fulfilledPolicies={fulfilledPolicies}
                      policies={field.passwordPolicies}
                    />
                  </div>
                ) : (
                  <Field
                    key={field.name}
                    {...field}
                    component={InputField}
                    customBackground="transparent"
                  />
                )
              )}

              <div className={styles.actionContainer}>
                <div className={styles.actions}>
                  {loading ? (
                    <div className={styles.loader}>
                      <Loader message={message} />
                    </div>
                  ) : (
                    <CustomButton
                      color="primary"
                      variant="contained"
                      type="submit"
                      className={classNames('w-100')}
                      disabled={!isValid || !dirty}
                    >
                      {content.name}
                    </CustomButton>
                  )}
                </div>
              </div>
            </Form>
          )
        }}
      </Formik>
    </div>
  )
}

export default SetPasswordForm
