import React, { ReactElement, FormEvent } from 'react'
import styles from './index.module.css'
import NotFound from '@images/card_not_found.svg'
import FileWarning from '@images/card_file_warning.svg'
import MailSent from '@images/card_mail_sent.svg'
import Chat from '@images/card_chat.svg'
import ProfileLock from '@images/card_profile_lock.svg'
import CartFail from '@images/card_cart_fail.svg'
import CartSuccess from '@images/card_cart_success.svg'
import Cross from '@images/card_cross.svg'
import Block from '@images/card_block.svg'
import Unavailable from '@images/unavailable.svg'
import UnsupportedNetwork from '@images/card_unsupported_network.svg'
import NoAlgoWarning from '@images/no_algo_warning.svg'
import AccountRequired from '@images/card_account_required.svg'
import { RegistrationFailedIcon as RestrictedAccess } from '../Icon/RegistationFailed'
import AccountPendingValidation from '@images/card_account_pending_validation.svg'
import SwitchWallet from '@images/card_switch_wallet.svg'
import Chart from '@images/chart.svg'
import classNames from 'classnames'
import { Grid } from '@mui/material'
import CustomButton from '../Button'
import { ReactJSXElement } from '@emotion/react/types/jsx-namespace'

const Icon = ({ icon, classes }: { icon?: string; classes: string }) => {
  switch (icon) {
    case 'not-found': {
      return <NotFound className={`${classes} ${styles.notFound}`} alt={icon} />
    }
    case 'file-warning': {
      return <FileWarning className={classes} alt={icon} />
    }
    case 'mail-sent': {
      return <MailSent className={classes} alt={icon} />
    }
    case 'chat': {
      return <Chat className={classes} alt={icon} />
    }
    case 'profile-lock': {
      return <ProfileLock className={classes} alt={icon} />
    }
    case 'cart-fail': {
      return <CartFail className={classes} alt={icon} />
    }
    case 'cart-sucess': {
      return <CartSuccess className={classes} alt={icon} />
    }
    case 'cross': {
      return <Cross className={classes} alt={icon} />
    }
    case 'block': {
      return <Block className={classes} alt={icon} />
    }
    case 'warning':
    case 'restricted-access': {
      return <RestrictedAccess alt={icon} className={classes} />
    }
    case 'unconsumable': {
      return <Unavailable className={classes} alt={icon} />
    }
    case 'unsupported-network': {
      return (
        <UnsupportedNetwork
          alt={icon}
          className={`${classes} ${styles.unsupportedNetwork}`}
        />
      )
    }
    case 'no-algo-warning': {
      return (
        <NoAlgoWarning className={`${classes} ${styles.noAlgo}`} alt={icon} />
      )
    }
    case 'login-required': {
      return (
        <AccountRequired
          className={`${classes} ${styles.loginRequired}`}
          alt={icon}
        />
      )
    }
    case 'pending-kyc-validation': {
      return (
        <AccountPendingValidation
          className={`${classes} ${styles.accountPendingValidation}`}
          alt={icon}
        />
      )
    }
    case 'switch-wallet': {
      return (
        <SwitchWallet
          className={`${classes} ${styles.switchWallet}`}
          alt={icon}
        />
      )
    }
    case 'no-sale-data': {
      return <Chart className={classes} alt={icon} />
    }
    default: {
      return (
        <NotFound
          className={`${classes} ${styles.notFound}`}
          alt="default-not-found"
        />
      )
    }
  }
}

export enum CustomIconicCardState {
  Success = 'success',
  Warning = 'warning',
  Alert = 'alert'
}

export enum CustomIconicCardSize {
  Big = 'big',
  Small = 'small'
}

export default function IconicCard({
  header,
  message,
  className,
  icon,
  state,
  action,
  actionLabel,
  hasShadow = false,
  children,
  size = CustomIconicCardSize.Small,
  ...props
}: {
  header?: string | ReactJSXElement
  message?: string
  className?: string
  icon?: string
  state?: CustomIconicCardState
  children?: ReactElement
  action?: (e: FormEvent<HTMLButtonElement>) => void
  actionLabel?: string
  hasShadow?: boolean
  size?: CustomIconicCardSize
}): ReactElement {
  const classes = classNames('mb-4', styles[state], styles[size])

  const content = () => {
    return (
      <div data-testid="iconic-card" className={styles.iconicCardWrapper}>
        <Icon icon={icon} classes={classes} />
        {header && <h2 className={classNames('bold', 'mb-2')}>{header}</h2>}
        {children && <div className={styles.message}>{children}</div>}
        {actionLabel && action && (
          <div
            className={`${
              size === 'big'
                ? styles.bigActionContainer
                : styles.actionContainer
            }`}
          >
            <CustomButton
              variant="contained"
              color="primary"
              onClick={action}
              className={styles.actionButton}
              fullWidth={size === 'small'}
            >
              {actionLabel}
            </CustomButton>
          </div>
        )}
      </div>
    )
  }

  return size === 'big' ? (
    <Grid container>
      <Grid item xs={2} />
      <Grid
        item
        xs={8}
        className={`center ${styles.content} ${styles[className]}`}
      >
        {content()}
      </Grid>
      <Grid item xs={2} />
    </Grid>
  ) : (
    <>
      <div
        className={`CustomIconicCard ${styles.container} ${styles[className]}`}
      >
        <div className={classNames('center', styles.content)}>{content()}</div>
      </div>
    </>
  )
}
