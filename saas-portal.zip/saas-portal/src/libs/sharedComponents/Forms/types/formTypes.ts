import { FormikErrors } from 'formik'

export interface Field {
  name: string
  label: string
  placeholder?: string
  help?: string
  type: string
  required?: boolean
}

export interface LoginFormContent {
  title: string
  name: string
  fields: Field[]
}

export interface AuthFormProps {
  content: LoginFormContent
  initialValues: object
  validationSchema: object
  handleSubmit: (
    values: object,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ) => Promise<any>
  loading?: boolean
  message?: string
  isAlert?: boolean
}

export interface CommonFormProps {
  handleSubmit: (
    values: object,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ) => Promise<void>
  validationSchema: object
  content: {
    form: {
      data: object[]
    }
    initialValues: object
    title: string
  }
  checkDisabled: (
    dirty: boolean,
    errors: FormikErrors<object>,
    isValid?: boolean
  ) => boolean
  onChangeCheckbox?: (option: string) => void
  loading?: boolean
}

export interface ForgetPasswordForm {
  email: string
}
