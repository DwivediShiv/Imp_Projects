import { Field, Formik, Form } from 'formik'
import React, { ReactElement, useState } from 'react'
import styles from './CommonForm.module.css'
import classNames from 'classnames'
import InputField from '../InputField'
import { FormFieldProps } from '@libs/types/Form'
import { CommonFormProps } from './types/formTypes'
import CustomButton from '../Button'
import { Grid } from '@mui/material'
import Loader from '../Loader'

const CommonForm: React.FC<CommonFormProps> = ({
  handleSubmit,
  validationSchema,
  content,
  checkDisabled,
  onChangeCheckbox,
  loading
}): ReactElement => {
  const formFields = content.form.data
  const [isSelectedOtherCountry, setIsSelectedOtherCountry] =
    useState<boolean>(false)

  return (
    <Formik
      initialValues={content.initialValues}
      validationSchema={validationSchema}
      onSubmit={async (values, { setSubmitting, resetForm, setFieldError }) => {
        await handleSubmit(values, resetForm, setFieldError)
        setSubmitting(false)
      }}
    >
      {({ errors, dirty, isValid }) => {
        return (
          <Form>
            <div className={styles.content} data-testid="formik-form">
              {formFields.map((field: Partial<FormFieldProps>) => {
                if (field.type === 'countryList') {
                  return (
                    <Field
                      className={styles.fieldContainer}
                      key={field.name}
                      validate={(val: string) => {
                        setIsSelectedOtherCountry(val === 'OTHERS')
                      }}
                      {...field}
                      addonInput={isSelectedOtherCountry && field.addonInput}
                      component={InputField}
                      sendCountryName
                    />
                  )
                } else if (
                  field.type === 'checkbox' &&
                  field.optionType === 'group'
                ) {
                  return (
                    <div className={styles.checkBoxContainer} key={field.name}>
                      <div className={styles.textareaLabel}>{field.label}</div>
                      <div className={styles.checkBoxArea}>
                        {field.options?.map((option: string) => (
                          <Field
                            key={option}
                            {...field}
                            label={option}
                            name={option}
                            component={InputField}
                            className={classNames(
                              !field.noBoundary && styles.checkBoxBoundary
                            )}
                            onChange={() => onChangeCheckbox(option)}
                          />
                        ))}
                      </div>
                    </div>
                  )
                } else if (field.type === 'custom') {
                  return (
                    <div className={styles.customFieldContainer}>
                      <Field
                        key={field.name}
                        component={field.getComponent}
                        className={styles.inputbox}
                        {...field}
                      />
                    </div>
                  )
                } else if (field.type === 'customGroup') {
                  const { groupFields } = field
                  return (
                    <Grid
                      className={styles.customFieldContainer}
                      container
                      spacing={4}
                    >
                      {groupFields.map((field) => (
                        <Grid
                          style={{ paddingTop: 0 }}
                          item
                          xs={6}
                          key={field.name}
                        >
                          <Field
                            key={field.name}
                            component={field.getComponent}
                            className={styles.inputbox}
                            {...field}
                          />
                        </Grid>
                      ))}
                    </Grid>
                  )
                } else {
                  return (
                    <Field
                      className={styles.fieldContainer}
                      key={field.name}
                      {...field}
                      component={InputField}
                    />
                  )
                }
              })}

              <div className={styles.containerBtn}>
                {loading ? (
                  <div className={styles.loader}>
                    <Loader />
                  </div>
                ) : (
                  <CustomButton
                    color="primary"
                    variant="contained"
                    type="submit"
                    className={styles.actionButton}
                    disabled={checkDisabled(dirty, errors, isValid)}
                  >
                    {content.title}
                  </CustomButton>
                )}
              </div>
            </div>
          </Form>
        )
      }}
    </Formik>
  )
}

export default CommonForm
