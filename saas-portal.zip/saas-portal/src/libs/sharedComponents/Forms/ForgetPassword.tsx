import React, { useState } from 'react'
import styles from './ForgetPassword.module.css'
import { Field, Formik, Form } from 'formik'
import classNames from 'classnames'
import Container from '../Container'
import { FormFieldProps } from '@libs/types/Form'
import CustomButton from '../Button'
import InputField from '../InputField'
import Loader from '../Loader'
import { useRouter } from 'next/router'
interface ResetLinkFormContent {
  title: string
  name: string
  fields: FormFieldProps[]
  validate?: (value: string) => any
}

interface ForgetPwdFormProps {
  content: ResetLinkFormContent
  initialValues?: object
  validationSchema?: any
  handleSubmit: any
  loading?: boolean
  message?: string
  fulfilledPolicies?: string[]
  userEmail?: string
  actionToken?: string | undefined
}

const ForgetPwdForm: React.FC<ForgetPwdFormProps> = ({
  content,
  initialValues,
  validationSchema,
  handleSubmit,
  message
}) => {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  return (
    <>
      <div className={styles.content}>
        <Container
          className={classNames(
            styles.center,
            styles.headerContent,
            'container'
          )}
        >
          <h3 className={styles.desc}>{content.title}</h3>
          <div className={styles.caption}>
            <p>A reset password link will be sent to </p>
            <p>your business email address.</p>
          </div>
        </Container>
        <Formik
          initialValues={initialValues}
          initialStatus="empty"
          isInitialValid={false}
          validationSchema={validationSchema}
          onSubmit={async (values, { setSubmitting, resetForm }) => {
            window.scrollTo({ top: 0, left: 0, behavior: 'smooth' })
            await handleSubmit(values, resetForm)
            setSubmitting(false)
          }}
        >
          {({ isValid, dirty }) => {
            return (
              <Form className={styles.form}>
                {content.fields.map((field: FormFieldProps) => (
                  <Field
                    key={field.name}
                    {...field}
                    className={styles.inputStyle}
                    component={InputField}
                    customBackground="transparent"
                  />
                ))}

                <div className={styles.actionContainer}>
                  <div className={styles.actions}>
                    {loading ? (
                      <div className={styles.loader}>
                        <Loader message={message} />
                      </div>
                    ) : (
                      <CustomButton
                        color="primary"
                        variant="contained"
                        type="submit"
                        className={classNames('w-100')}
                        disabled={!isValid || !dirty}
                      >
                        Continue
                      </CustomButton>
                    )}
                  </div>
                  <hr className={styles.hrLine} />
                  <footer className={styles.footerSubAction}>
                    <CustomButton
                      color="secondary"
                      onClick={() => router.push('/login')}
                    >
                      Return to Login
                    </CustomButton>
                  </footer>
                </div>
              </Form>
            )
          }}
        </Formik>
      </div>
    </>
  )
}

export default ForgetPwdForm
