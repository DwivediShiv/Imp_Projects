import React from 'react'
import styles from './AuthForm.module.css'
import { Field, Formik, Form } from 'formik'
import classNames from 'classnames'
import { FormFieldProps } from '@libs/types/Form'
import InputField from '../InputField'
import Loader from '../Loader'
import Container from '../Container'
import { AuthFormProps } from './types/formTypes'
import CustomButton from '../Button'
import { useRouter } from 'next/router'

const AuthForm: React.FC<AuthFormProps> = ({
  content,
  initialValues,
  validationSchema,
  handleSubmit,
  loading,
  message,
  isAlert = false
}) => {
  const router = useRouter()
  return (
    <div className={styles.content}>
      <Container
        className={classNames(styles.center, styles.headerContent, 'container')}
      >
        <h3 className={styles.desc}>{content.title}</h3>
      </Container>
      <Formik
        initialValues={initialValues}
        initialStatus="empty"
        validationSchema={validationSchema}
        onSubmit={async (
          values,
          { setSubmitting, resetForm, setFieldError }
        ) => {
          window.scrollTo({ top: 0, left: 0, behavior: 'smooth' })
          await handleSubmit(values, resetForm, setFieldError)
          setSubmitting(false)
        }}
      >
        <Form className={styles.form}>
          {content.fields.map((field: FormFieldProps) => (
            <Field
              key={field.name}
              {...field}
              component={InputField}
              isAlert={isAlert}
              customBackground="transparent"
              additionalComponent={
                field.name === 'password' && (
                  <div className={styles.subAction}>
                    <CustomButton
                      color="secondary"
                      onClick={() => router.push('/forget-password')}
                      className={classNames('float-right')}
                    >
                      Forgot your password?
                    </CustomButton>
                  </div>
                )
              }
            />
          ))}

          <div className={styles.actionContainer}>
            <div className={styles.actions}>
              {loading ? (
                <div className={styles.loader}>
                  <Loader message={message} />
                </div>
              ) : (
                <CustomButton
                  color="primary"
                  variant="contained"
                  type="submit"
                  className={classNames('w-100')}
                >
                  {content.name}
                </CustomButton>
              )}
            </div>
          </div>
        </Form>
      </Formik>
    </div>
  )
}

export default AuthForm
