import React, { ReactElement, ReactNode } from 'react'
import LightbulbIcon from '@images/lightbulb.svg'
import { WarningCircleIcon as AlertIcon } from '../Icon/WarningCircleIcon'
import InfoIcon from '@images/icon_information.svg'
import { Tooltip, IconButton } from '@mui/material'
import styles from './index.module.css'
import { IconSize } from '@utils/constants'
import classNames from 'classnames/bind'
import Markdown from '../Markdown'

export enum InfoIconColor {
  Base = 'baseInfoIcon',
  Dark = 'darkInfoIcon',
  Darker = 'darkerInfoIcon'
}
interface Tooltip {
  title: string
  type?: 'alert' | 'bulb' | 'custom'
  icon?: ReactNode
  placement?:
    | 'bottom-end'
    | 'bottom-start'
    | 'bottom'
    | 'left-end'
    | 'left-start'
    | 'left'
    | 'right-end'
    | 'right-start'
    | 'right'
    | 'top-end'
    | 'top-start'
    | 'top'
  color?: InfoIconColor
  className?: string
  onClick?: (event) => void
}

export default function CustomTooltip({
  title,
  className,
  type,
  icon,
  color,
  placement,
  onClick
}: Tooltip): ReactElement {
  const titles: string[] = title ? title.split('<br/>') : []
  const cx = classNames.bind(styles)
  const iconSize = IconSize.ExtraLarge
  const stylesClasses = cx({
    [iconSize]: iconSize
  })

  const iconStylesClasses = cx({
    [color]: color
  })

  const getIconComponent = (type) => {
    switch (type) {
      case 'alert': {
        return (
          <AlertIcon
            iconSize={IconSize.ExtraLarge}
            state="base"
            className={styles.alertIcon}
          />
        )
      }
      case 'bulb': {
        return (
          <LightbulbIcon
            className={`${stylesClasses} ${styles.lightBulb} ${styles.root}`}
          />
        )
      }
      case 'custom': {
        return icon
      }
      default:
        return (
          <InfoIcon className={`${iconStylesClasses} ${styles.infoIcon}`} />
        )
    }
  }

  const titleContent = () => {
    return (
      <div>
        {titles.map((data, index) => {
          return data ? (
            <div key={`tooltip-${index}`}>
              <Markdown
                className={styles.helpText}
                text={data}
                iconSize={IconSize.Medium}
              />
            </div>
          ) : (
            <br />
          )
        })}
      </div>
    )
  }

  return (
    <Tooltip
      className={className}
      title={titleContent()}
      placement={placement || 'right'}
      arrow
      disableInteractive={false}
      classes={{
        tooltip: styles.tooltip,
        arrow: styles.arrow
      }}
    >
      <IconButton
        classes={{
          root: type === 'custom' ? styles.customButton : styles.buttonRoot
        }}
        onClick={onClick}
        disableFocusRipple
        disableRipple
      >
        {getIconComponent(type)}
      </IconButton>
    </Tooltip>
  )
}
