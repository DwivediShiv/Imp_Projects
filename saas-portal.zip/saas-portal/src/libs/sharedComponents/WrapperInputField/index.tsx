import React from 'react'
import InputField from '../InputField'

const CustomInputField = (props) => {
  const { field, ...restProps } = props

  field.onBlur = restProps.onBlur
  return <InputField {...restProps} field={field} />
}

export default CustomInputField
