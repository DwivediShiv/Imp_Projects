import React, { useRef, useLayoutEffect, memo } from 'react'
import { FilledTextFieldProps, TextField } from '@mui/material'
import usePrevious from './hooks/usePrevious'

export interface SingleInputProps extends FilledTextFieldProps {
  focus?: boolean
}

const SingleInput = (props: SingleInputProps): JSX.Element => {
  const { focus, ...rest } = props
  const inputRef = useRef<HTMLInputElement>(null)
  const prevFocus = usePrevious(!!focus)
  useLayoutEffect(() => {
    if (inputRef.current) {
      if (focus) {
        inputRef.current.focus()
      }
      if (focus && focus !== prevFocus) {
        inputRef.current.focus()
        inputRef.current.select()
      }
    }
  }, [focus, prevFocus])

  return (
    <TextField
      inputRef={inputRef}
      InputProps={{
        disableUnderline: true
      }}
      {...rest}
    />
  )
}

export default memo(SingleInput)
