import { FilledInput } from '@mui/material'
import HelperMessage from '../HelperMessage'
import React, { ReactElement } from 'react'
import styles from './index.module.css'

export default function CustomInput({ ...props }: any): ReactElement {
  const {
    name,
    type,
    max,
    error,
    isValid,
    value,
    autoComplete,
    isPartOfCombination,
    hideValidationMessage,
    label
  } = props

  return (
    <div data-testid="fancy-input-error" className={styles.fancyInputBody}>
      {isPartOfCombination && <p className="body2">{label}</p>}
      <FilledInput
        fullWidth
        disableUnderline
        autoComplete={autoComplete ?? 'off'}
        classes={{
          root: `${styles.root} ${isValid && styles.valid} ${
            error && styles.error
          }`,
          input: styles.inputComponent
        }}
        key={name}
        type={type}
        name={name}
        id={props.name}
        {...props}
        data-testid="fancy-input-input"
      />
      {(error || max) && (
        <div
          className={`${styles.helperText} ${
            error === undefined ? styles.floatRight : styles.spaceBetween
          }`}
        >
          {error && !hideValidationMessage && (
            <HelperMessage message={error} isAlert={!!error} />
          )}
          {max && (
            <div
              className={`${styles.length} ${!!error && styles.error} ${
                isValid && styles.valid
              }`}
            >
              {value?.trim()?.length ?? 0} / {max}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
