import { FilledInputProps } from '@mui/material'

export interface FancyInputTypeProps extends FilledInputProps {
  name: string
  max?: number
  isValid?: boolean
  autoComplete?: string
  isPartOfCombination?: boolean
  hideValidationMessage?: boolean
  label?: string
}
