import React, { FormEvent, ReactElement, ReactNode, useState } from 'react'
import styles from './index.module.css'
import CrossIcon from '@images/cross.svg'
import { Grid, IconButton } from '@mui/material'

interface bannerProps {
  title?: string
  children: ReactNode
  showCloseButton?: boolean
  className?: string
  onClose?: (e: FormEvent) => void
}

export default function CustomBanner({
  title,
  children,
  showCloseButton,
  className,
  onClose
}: bannerProps): ReactElement {
  const [displayBanner, setDisplayBanner] = useState(true)
  const handleClose = (e) => {
    setDisplayBanner(false)
    onClose(e)
  }

  return (
    displayBanner && (
      <div className={`${styles.container} ${className || ''}`}>
        <div className={`${styles.wrapper} `}>
          <Grid container>
            <Grid item lg={2} />
            <Grid item lg={8} md={12} xs={12} className={styles.contentWrapper}>
              <div>
                {title && <h6 className="bold mb-3">{title}</h6>}
                <div className={styles.contentContainer}>{children}</div>
              </div>
              {showCloseButton && (
                <IconButton
                  className={styles.crossButton}
                  onClick={handleClose}
                >
                  <CrossIcon />
                </IconButton>
              )}
            </Grid>
            <Grid item lg={2} />
          </Grid>
        </div>
      </div>
    )
  )
}
