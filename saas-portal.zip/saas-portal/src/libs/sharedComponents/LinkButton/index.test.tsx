import React from 'react'
import { render, fireEvent, screen } from '@testing-library/react'
import LinkButton from '.'
import '@testing-library/jest-dom'
import { IconSize } from '@utils/constants'

const props = {
  title: 'title',
  target: '_blank'
}

function renderLinkButton(props = {}) {
  return render(<LinkButton title={'title'} target={'_blank'} {...props} />)
}

describe('Link Button', () => {
  it('should return some components to be shown in document', () => {
    renderLinkButton()
    expect(screen.getByTestId('link-button')).toBeInTheDocument()
    expect(screen.getByTestId('link-button')).toContainHTML('title')
    expect(screen.getByTestId('new-tab-icon')).toBeInTheDocument()
    expect(screen.getByTestId('link-button')).toContainHTML('new-tab-icon')
    expect(screen.getByTestId('link-button')).toContainHTML(
      'iconSizeSmall iconNewTab'
    )
  })

  it('should simulate the click event', () => {
    const onClick = jest.fn()
    renderLinkButton({ ...props, onClick })
    fireEvent.click(screen.getByTestId('link-button'))
    expect(onClick).toHaveBeenCalledTimes(1)
  })

  it('should expect certain attributes in link button', () => {
    renderLinkButton()
    expect(screen.getByTestId('link-button')).toHaveAttribute(
      'rel',
      'noopener noreferrer'
    )

    expect(screen.getByTestId('link-button')).toHaveAttribute(
      'target',
      '_blank'
    )
  })

  it('should get expected and correct href when the href is passed in', () => {
    const href = 'google.com'
    renderLinkButton({ ...props, href })
    expect(screen.getByTestId('link-button')).toHaveAttribute(
      'href',
      'google.com'
    )
  })

  it('should not return new tab icon when target is undefined', () => {
    const target = undefined
    renderLinkButton({ ...props, target })
    expect(screen.getByTestId('link-button')).not.toContain('new-tab-icon')
  })

  it('should not have title attached if title is undefined', () => {
    const title = undefined
    renderLinkButton({ ...props, title })
    expect(screen.getByTestId('link-button')).toHaveTextContent('')
  })

  it('should return different classname for new tab icon rendering if icon size is passed in', () => {
    const iconSize = IconSize.Large
    renderLinkButton({ ...props, iconSize })
    expect(screen.getByTestId('link-button')).toContainHTML(
      'iconSizeLarge iconNewTab'
    )
  })
})

// import React from 'react'
// describe('Org Admin profile ', () => {
//   it('test', () => {
//     // will remove when uncommented
//     expect('test').toBe('test')
//   })
// })
