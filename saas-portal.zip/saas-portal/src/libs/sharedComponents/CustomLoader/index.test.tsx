import React from 'react'
import { render, screen, waitFor } from '@testing-library/react'
import CustomLoader from './index'

describe('FancyLoader', () => {
  test('should render loader', async () => {
    render(<CustomLoader></CustomLoader>)
    expect(screen.getByTestId('fancy-loader')).toBeVisible()
  })

  it('should render with the provided label', async () => {
    const label = 'Loading'
    render(<CustomLoader progressValue={0} label={label} />)
    await waitFor(() => {
      expect(screen.getByTestId('fancy-loader')).toBeVisible()
    })
  })

  test('should render component with icon', async () => {
    render(<CustomLoader progressValue={0}></CustomLoader>)

    expect(screen.getByTestId('fancy-loader-circular-progress')).toContainHTML(
      '<svg'
    )
    expect(screen.getByTestId('fancy-loader-circular-progress')).toBeVisible()
  })

  test('should render component with icon and label', async () => {
    render(<CustomLoader message="test"></CustomLoader>)

    expect(screen.getByTestId('fancy-loader')).toContainHTML('<svg')
    expect(screen.getByTestId('fancy-loader')).toContainHTML('test')
  })

  it('should render circular progress with label when progress value is greater than 0', () => {
    render(<CustomLoader progressValue={50} />)
    expect(
      screen.getByTestId('fancy-loader-circular-progress-with-label')
    ).toBeInTheDocument()
    expect(
      screen.queryByTestId('fancy-loader-circular-progress')
    ).not.toBeInTheDocument()
  })

  it('should render circular progress without label when progress value is 0', () => {
    render(<CustomLoader />)
    expect(
      screen.getByTestId('fancy-loader-circular-progress')
    ).toBeInTheDocument()
    expect(
      screen.queryByTestId('fancy-loader-circular-progress-with-label')
    ).not.toBeInTheDocument()
  })
})
// import React from 'react'
// describe('Org Admin profile ', () => {
//   it('test', () => {
//     // will remove when uncommented
//     expect('test').toBe('test')
//   })
// })
