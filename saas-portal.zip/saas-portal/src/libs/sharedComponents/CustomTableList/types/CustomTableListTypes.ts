import { ReactJSXElement } from '@emotion/react/types/jsx-namespace'

export interface CustomTableListProps {
  data: any
  sortBy: string
  sortOrder: string
  configuration: Configuration
  totalRecord: number
  paginationSize: number
  handleOnTabChange?: TabChangeHandler
  handleSortChange?: SortChangeHandler
  handlePageChange?: PageChangeHandler
  page: number
  tabIndex: number
  isLoading: boolean
  state?: string
  handleOnSearch?: SearchEventHandler
  filterCriterias: Record<string, string[]>
  searchValue?: string
  noFilteredData: FilterDataFunction
  noDataText?: ReactJSXElement
  noDataAction?: ReactJSXElement
  isSelectable?: boolean
  onSelectedRowsChange?: any
  selectedRows?: any
  clearSelectedRows?: any
}

export interface Configuration {
  data?: any
  title: string
  columns: Column[]
  tabConfig?: TabConfig
  filterCriterias?: { Country: string[]; Industry: string[] }
  exportConfig?: ExportConfig
  searchConfig: SearchConfig
  filterConfig: FilterConfig
  refreshConfig?: any
  buttonConfig?: any
}
export interface FilterConfig {
  clearFilters: ClearFilterHandler
  filters: Filter[]
}

interface ClearFilterHandler {
  (): void
}

export interface Filter {
  id: string
  inputName: string
  label: string
  dynamic: boolean
  containerClass: string
  customBackground: string
  value: string[]
  deselectText: string
  options?: any[] | any
  onValueChange: SetStateFunction<string[]>
  selectType?: string
  onChange: any
}

export interface SetStateFunction<T> {
  (newState: T | ((prevState: T) => T)): void
}
export interface ExportConfig {
  exportFn: ExportFn
  fileName: string
}

interface ExportFn {
  (): void
}

export interface SearchConfig {
  type: string
  name: string
  placeholder: string
  searchValue?: string
}
export interface TabConfig {
  name?: string
  defaultTab: number
  tabList: TabList[]
  button?: ButtonConfig
}

export interface TabList {
  title: string
  key: string
  value: string
  index: number
  icon?: any
}

interface ButtonConfig {
  name: string
  color: 'primary' | 'secondary' | 'default'
  variant: 'contained' | 'outlined' | 'text'
  handleClick: () => void
  href: string
}
export interface Column {
  id: string
  title: string
  type: string
  sortable?: boolean
  sortBy?: string
  class?: string
  rowConfig?: RowConfig
  grow?: number
  style?: string
  sortField?: string
  allowOverflow?: boolean
}

export interface RowConfig {
  cellType: string
  clickable?: any
  value?: string
  class?: string
  href?: string
  param?: string
  format?: string
  actions?: any
}

export interface TransformedFilterCriterias {
  [key: string]: { [key: string]: boolean }
}

interface TabChangeHandler {
  (event: React.ChangeEvent<unknown>, newValue: number): void
}

interface SortChangeHandler {
  (column: { sortField: string }, sortDirection: string): Promise<void>
}
interface PageChangeHandler {
  (page: number): void
}

interface FilterDataFunction {
  (): boolean
}
interface SearchEventHandler {
  (e: React.ChangeEvent<HTMLInputElement>): void
}
