import React, { ReactElement, useEffect, useState } from 'react'
import styles from './index.module.css'
import ExportIcon from '@images/export.svg'
import RefreshIcon from '@mui/icons-material/Refresh'
import CustomIconicCard, {
  CustomIconicCardState,
  CustomIconicCardSize
} from '../IconicCard'
import { useCustomTableList } from './hook/useCustomTableList'
import {
  CustomTableListProps,
  TransformedFilterCriterias
} from './types/CustomTableListTypes'
import InputField from '../InputField'
import Link from 'next/link'
import CustomButton from '../Button'
import Tabs from '../Tabs'
import CustomMultiSelect from '../MultiSelect'
import Table from '../Table'

function CustomTableList({
  data,
  configuration,
  sortBy,
  sortOrder,
  totalRecord,
  paginationSize,
  handleOnTabChange,
  handleSortChange,
  handlePageChange,
  page,
  tabIndex,
  isLoading,
  handleOnSearch,
  filterCriterias,
  noFilteredData,
  noDataText,
  noDataAction,
  isSelectable,
  onSelectedRowsChange,
  clearSelectedRows
}: CustomTableListProps): ReactElement {
  const {
    columns,
    tabConfig,
    exportConfig,
    searchConfig,
    title,
    filterConfig,
    refreshConfig,
    buttonConfig
  } = configuration
  const { getColumns, handleExportData } = useCustomTableList({
    columns,
    sortBy,
    sortOrder
  })

  const [transformedFilterCriteria, setTransformedFilterCriteria] =
    useState<TransformedFilterCriterias>()

  function isObjectEmpty(obj: object): boolean {
    return Object.keys(obj).length === 0
  }

  useEffect(() => {
    const data = filterCriterias
    const updatedData = {}
    for (const key in data) {
      if (data[key]?.length) {
        const updatedKey = Object.fromEntries(
          [...data[key]].map((item) => [item, true])
        )
        updatedData[`${key}`] = updatedKey
      }
    }
    setTransformedFilterCriteria(updatedData)
  }, [filterCriterias])

  return (
    <section className={styles.grid}>
      <div className={styles.header}>
        <h3>{title}</h3>
      </div>
      <div className={styles.contentContainer}>
        {tabConfig?.tabList?.length > 0 && (
          <div className={styles.tabContainer}>
            {(data ||
              tabConfig?.name ||
              (!isLoading && totalRecord === 0 && noFilteredData())) && (
              <Tabs
                items={tabConfig.tabList}
                handleTabChange={handleOnTabChange}
                defaultIndex={tabIndex}
              />
            )}
            {tabConfig?.button &&
              ((totalRecord === 0 && noFilteredData()) || totalRecord > 0) && (
                <Link href={tabConfig.button.href} legacyBehavior>
                  <CustomButton
                    color={tabConfig.button.color}
                    variant={tabConfig.button.variant}
                    className={styles.tabSectionButton}
                    onClick={tabConfig.button.handleClick}
                  >
                    {tabConfig.button.name}
                  </CustomButton>
                </Link>
              )}
          </div>
        )}
        {(data || (!isLoading && totalRecord === 0 && noFilteredData())) && (
          <div className={styles.container}>
            <div className={styles.searchContainer}>
              {searchConfig && (
                <div>
                  <InputField
                    className={styles.inputField}
                    type={searchConfig?.type}
                    name={searchConfig?.name}
                    placeholder={searchConfig?.placeholder}
                    value={searchConfig?.searchValue}
                    onChange={handleOnSearch}
                  />
                </div>
              )}
              <div className={styles.searchButtonContainer}>
                {refreshConfig && (
                  <article
                    className={`${styles.refreshButton} ${
                      totalRecord !== 0 ? '' : styles.disabledBtn
                    }`}
                    onClick={
                      totalRecord !== 0
                        ? refreshConfig?.handleRefreshList
                        : null
                    }
                  >
                    <div
                      className={`${styles.icon} ${
                        totalRecord !== 0 ? '' : styles.disabledBtn
                      }`}
                    >
                      <RefreshIcon className={styles.refreshIcon} />
                      {refreshConfig.name}
                    </div>
                  </article>
                )}

                {buttonConfig && (
                  <article className={styles.exportButton}>
                    <CustomButton
                      key="approve"
                      variant="contained"
                      color="primary"
                      onClick={buttonConfig?.handleClick}
                      disabled={buttonConfig?.disable}
                    >
                      {buttonConfig?.title}
                    </CustomButton>
                  </article>
                )}

                {exportConfig && (
                  <article
                    className={`${styles.exportButton} ${
                      totalRecord !== 0 ? '' : styles.disabledBtn
                    }`}
                    onClick={() =>
                      totalRecord !== 0
                        ? handleExportData(
                            exportConfig.exportFn,
                            exportConfig.fileName
                          )
                        : null
                    }
                  >
                    <div
                      className={`${styles.icon} ${
                        totalRecord !== 0 ? '' : styles.disabledBtn
                      }`}
                    >
                      <ExportIcon width="24" height="24" />
                      Export
                    </div>
                  </article>
                )}
              </div>
            </div>
            <div className={styles.filterContainerOuter}>
              {transformedFilterCriteria &&
                !isObjectEmpty(transformedFilterCriteria) &&
                filterConfig?.filters?.map((filter) => (
                  <div
                    className={styles.filterContainerInner}
                    key={filter?.inputName}
                  >
                    <CustomMultiSelect
                      inputName={filter?.inputName}
                      label={filter?.label}
                      options={
                        filter.dynamic
                          ? transformedFilterCriteria[filter?.id]
                          : filter.options
                      }
                      containerClass={filter?.containerClass}
                      customBackground={filter?.customBackground}
                      value={filter?.value}
                      deselectText="All"
                      onValueChange={filter?.onValueChange}
                      selectType={filter?.selectType}
                      onChange={(e) => {
                        filter?.onChange(
                          e,
                          transformedFilterCriteria[filter?.id]
                        )
                      }}
                    />
                  </div>
                ))}
              <article
                onClick={
                  noFilteredData() && totalRecord !== 0
                    ? filterConfig.clearFilters
                    : null
                }
                className={`${styles.clearFilterBtn} ${
                  noFilteredData() && totalRecord !== 0
                    ? ''
                    : styles.disabledBtn
                }`}
              >
                Reset
              </article>
            </div>
          </div>
        )}

        <div className={styles.tableWrapper}>
          {!data ||
          data?.length < 1 ||
          (!isLoading && totalRecord === 0 && noFilteredData()) ? (
            <div className={`${styles.noData} h-100`}>
              <CustomIconicCard
                header={
                  (totalRecord === 0 && !noFilteredData() && noDataText) ||
                  'No records found.'
                }
                icon="not-found"
                state={CustomIconicCardState.Warning}
                size={CustomIconicCardSize.Big}
              >
                <div>
                  {!isLoading &&
                    totalRecord === 0 &&
                    ((noFilteredData() &&
                      'Please adjust your filters and try again.') ||
                      (!noFilteredData() && noDataAction))}
                </div>
              </CustomIconicCard>
            </div>
          ) : (
            <>
              {data && (
                <Table
                  columns={getColumns()}
                  paginationTotalRows={totalRecord}
                  data={data}
                  paginationServer
                  pagination
                  responsive
                  onSort={handleSortChange}
                  sortServer
                  currentPage={page}
                  paginationDefaultPage={page}
                  paginationPerPage={paginationSize || 10}
                  onChangePage={(page) => {
                    handlePageChange(page)
                  }}
                  isLoading={isLoading}
                  className={styles.table}
                  isSelectable={isSelectable}
                  onSelectedRowsChange={onSelectedRowsChange}
                  clearSelectedRows={clearSelectedRows}
                />
              )}
            </>
          )}
        </div>
      </div>
    </section>
  )
}

export default CustomTableList
