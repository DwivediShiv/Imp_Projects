import React, { ChangeEvent, useState } from 'react'
import { TableColumn } from 'react-data-table-component'
import TableHeader from '@sharedComponents/TableHeader'
import StatusBox from '@sharedComponents/StatusBox'
import styles from '../index.module.css'
import Link from 'next/link'
import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import { addressTruncate } from '@utils/conversion'
import NewStatusBox from '@sharedComponents/StatusFancy'
import { IconSize } from '@utils/constants'

export const getAttribute = (
  attributes: string | any[],
  key: string
): string => {
  for (let i = 0; i < attributes?.length; i++) {
    const attribute = attributes[i]
    if (attribute.name === key) {
      return attribute.value
    }
  }
  return ''
}

export const getRoles = (roles: any[]): React.ReactNode => {
  return <span>{roles.toString()}</span>
}

function getActionItems(row: any, rowConfig: any): React.ReactNode {
  return rowConfig?.actions.map((action) => {
    const type = action?.type
    const clickable = (action?.clickable && action?.clickable(row)) || false
    const hidden = (action?.hidden && action?.hidden(row)) || false
    const ActionImage = action?.image
    const actionStyle = (!clickable && {
      opacity: type === 'text' ? '1' : '0.4',
      color: 'var(--neutral-50-color)',
      fontWeight: 'var(--font-weight-semibold)',
      pointerEvents: 'none' as React.CSSProperties['pointerEvents'],
      display: 'visible'
    }) || {
      color: 'var(--primary-color)',
      fontWeight: 'var(--font-weight-semibold)',
      cursor: 'pointer'
    }
    actionStyle.display = hidden ? 'none' : 'visible'
    switch (type) {
      case 'icon':
        return (
          <ActionImage
            style={actionStyle}
            onClick={() => {
              action?.onClick(row)
            }}
          ></ActionImage>
        )
      case 'text':
        return (
          <span
            style={actionStyle}
            onClick={() => {
              action?.onClick(row)
            }}
          >
            {action.label}
          </span>
        )
    }
  })
}

export const useCustomTableList = ({ columns, sortBy, sortOrder }) => {
  const TimeWithCustomFormat = WithCustomFormat(Time)

  const generateName = (element: any): React.ReactNode => {
    switch (element.type) {
      case 'tableHeader':
        return (
          <TableHeader
            title={element.title}
            sortable={element.sortable}
            sortActive={sortBy === element.sortField}
            sortDirection={sortOrder}
          />
        )
      default:
        break
    }
  }

  const renderField = (text) => {
    return (
      <article className={styles.attributeContent}>
        <p className={styles.wrapText} title={text}>
          {text || '-'}
        </p>
      </article>
    )
  }

  const getCell = (row: any, rowConfig: any): React.ReactNode => {
    let state = '-'
    switch (rowConfig.cellType) {
      case 'fancyStatusField':
        state = row[rowConfig?.value]
          ? row[rowConfig.value]?.toLowerCase()
          : null
        return (
          <article className={styles.statusField}>
            {(state && <NewStatusBox status={state} />) || '-'}
          </article>
        )
      case 'fancyStatusBoolField':
        state =
          row[rowConfig.value] === true ? rowConfig.value.toLowerCase() : null
        return (
          <article className={styles.statusField}>
            {(state && <NewStatusBox status={state} />) || '-'}
          </article>
        )
      case 'address':
        return (
          <p className={styles.wrapText} title={row[rowConfig.value]}>
            {addressTruncate(row[rowConfig?.value])}
          </p>
        )
      case 'nameField': // always clickable
        if (rowConfig.clickable === 'true') {
          let baseUrl = rowConfig.href
          if (
            rowConfig?.conditionalHref?.param &&
            rowConfig.conditionalHref.value &&
            row[rowConfig.conditionalHref.param] ===
              rowConfig.conditionalHref.value
          ) {
            baseUrl = rowConfig.conditionalHref.href
          }

          return (
            <Link href={`${baseUrl}${row[rowConfig?.param]}`} legacyBehavior>
              <article
                className={`${styles.clickable} ${styles.attributeContent}`}
              >
                <p className={styles.wrapText} title={row[rowConfig.value]}>
                  {row[rowConfig.value] || '-'}
                </p>
              </article>
            </Link>
          )
        } else {
          return renderField(row.name)
        }
      case 'clickableField': // conditional clickable
        return (
          <>
            {rowConfig?.clickable(row) ? (
              <Link
                href={rowConfig?.onClick(row)}
                aria-disabled={true}
                legacyBehavior
              >
                <article
                  className={`${styles.clickable} ${styles.attributeContent}`}
                >
                  <p
                    className={styles.wrapText}
                    title={row[rowConfig?.value] || '-'}
                  >
                    {row[rowConfig?.value] || '-'}
                  </p>
                </article>
              </Link>
            ) : (
              <p
                className={styles.wrapText}
                title={row[rowConfig?.value] || '-'}
              >
                {row[rowConfig?.value] || '-'}
              </p>
            )}
          </>
        )
      case 'attributeField':
        return getAttribute(row.attributes, rowConfig.value) || '-'
      case 'roleField':
        return getRoles(row.allowedRoles) || '-'
      case 'dateField':
        return (
          <article className={styles.attributeContent}>
            <TimeWithCustomFormat
              date={row[rowConfig.value]}
              customFormat={rowConfig.format}
            />
          </article>
        )
      case 'actions':
        return (
          <article className={styles.actionContainer}>
            {getActionItems(row, rowConfig)}
          </article>
        )
      case 'assetField':
        return (
          <div
            className={
              row.markedForPurge
                ? `${styles.markedForPurge} ${styles.attributeContent}`
                : `${styles.attributeContent}`
            }
          >
            <span className={styles.purgetext}>
              {row.markedForPurge ? 'Purge in progress' : ''}
            </span>
            <p className={styles.wrapText} title={row[rowConfig?.value] || '-'}>
              {row[rowConfig?.value] || '-'}
            </p>
          </div>
        )
      default:
        return renderField(row[rowConfig.value])
    }
  }

  const getColumns = (): TableColumn<any>[] => {
    return columns.map((config: any) => {
      const column: TableColumn<any> = {}
      column.id = config.id
      column.name = generateName(config)
      column.cell = (row: any) => {
        return (
          (config.cell && config.cell(row)) || getCell(row, config.rowConfig)
        )
      }
      column.grow = config.grow
      column.style = config.style
      column.width = config.width
      column.sortable = config.sortable
      column.sortField = config.sortField
      column.allowOverflow = config.allowOverflow

      return column
    })
  }

  const handleExportData = async (exportFn, fileName) => {
    const response = await exportFn()
    if (response) {
      const url = window.URL.createObjectURL(new Blob([response]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', fileName)
      document.body.appendChild(link)
      link.click()
    }
  }

  return {
    getColumns,
    handleExportData
  }
}
