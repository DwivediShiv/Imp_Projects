import * as React from 'react'
import slugify from 'slugify'
import classNames from 'classnames/bind'
import styles from './index.module.css'

const cx = classNames.bind(styles)

export interface InputRadioProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  options: string[]
  inputSize?: string
}

export default function InputRadio({
  options,
  inputSize,
  ...props
}: InputRadioProps): React.ReactElement {
  return (
    <div className={styles.radioGroup}>
      {options &&
        (options as string[]).map((option: string, index: number) => (
          <div className={styles.radioWrap} key={index}>
            <input
              {...props}
              className={styles[props.type as any]}
              id={slugify(option)}
            />
            <label
              className={cx({
                [styles.radioLabel]: true,
                [inputSize as any]: inputSize
              })}
              htmlFor={slugify(option)}
            >
              {option}
            </label>
          </div>
        ))}
    </div>
  )
}
