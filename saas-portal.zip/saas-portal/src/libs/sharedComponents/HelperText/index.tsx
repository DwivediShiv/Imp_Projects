import React, { ReactElement } from 'react'
import styles from './index.module.css'
import AlertIcon from '@images/alert_circle.svg'
import WarningIcon from '@images/icon_warning.svg'
import InfoIcon from '@images/icon_information.svg'
import TickIcon from '@images/check_circle.svg'
import { ReactNode } from 'react-markdown'

const HelperText = ({
  message,
  state = 'error',
  icon,
  hasIcon,
  className
}: {
  message: string | ReactNode
  state?: 'error' | 'warning' | 'success' | 'info'
  icon?: ReactNode
  hasIcon?: boolean
  className?: string
}): ReactElement => {
  const displayHelperIcon = () => {
    switch (state) {
      case 'error':
        return (
          icon || (
            <AlertIcon
              className={`iconSizeSmall ${styles.messageIcon} ${styles.error}`}
            />
          )
        )
      case 'warning':
        return (
          <span className={`${styles.messageIcon} ${styles.warning}`}>
            {icon || <WarningIcon />}
          </span>
        )
      case 'info':
        return (
          <span className={`${styles.messageIcon} ${styles.info}`}>
            {icon || <InfoIcon />}
          </span>
        )
      case 'success':
        return (
          <span className={`${styles.messageIcon} ${styles.success}`}>
            {icon || <TickIcon />}
          </span>
        )
      default:
        return <span className={styles.messageIcon}>{icon || ''}</span>
    }
  }

  const displayHelperText = (value: string | ReactNode) => {
    return (
      <div className={styles.messageIconWrapper}>
        {hasIcon ?? displayHelperIcon()}
        <span className={styles.message}>{value}</span>
      </div>
    )
  }

  return (
    <div className={`${className} ${styles[state]}`}>
      {displayHelperText(message)}
    </div>
  )
}

export default HelperText
