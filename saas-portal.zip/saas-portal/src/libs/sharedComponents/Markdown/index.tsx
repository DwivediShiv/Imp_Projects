import { IconSize } from '@utils/constants'
import { getFancyWebPortalUri } from '@utils/url'
import React, { ReactElement } from 'react'
import ReactMarkdown from 'react-markdown'
import styles from './index.module.css'
import LinkButton from '../LinkButton'

const Markdown = ({
  text,
  className,
  iconSize
}: {
  text: string | ReactElement
  className?: string
  iconSize?: IconSize
}): ReactElement => {
  const textCleaned = (text as string)?.replace(/\\n/g, '\n ')

  const replaceUrl = (href) => {
    const external = href.startsWith('/') && !href.includes('publish')
    if (external) return getFancyWebPortalUri(href)
    else return href
  }

  return textCleaned === '-' ? (
    <span>-</span>
  ) : (
    <ReactMarkdown
      linkTarget="_blank"
      className={`${styles.acentrik} ${styles.markdown} ${className} `}
      components={{
        a({ target, children, href, ...props }) {
          return (
            <LinkButton
              title={children[0] as string}
              href={replaceUrl(href)}
              iconSize={iconSize}
              target={target}
            />
          )
        }
      }}
    >
      {textCleaned}
    </ReactMarkdown>
  )
}

export default Markdown
