import { Grid, Container } from '@mui/material'
import { useRouter } from 'next/router'
import classNames from 'classnames'
import React, { ReactElement } from 'react'
import styles from './BasicHeaderLayout.module.css'
import BasicHeader from '../Header/BasicHeader'

type childProps = {
  className?: string
  children: ReactElement
}

function BasicHeaderLayout({ className, children }: childProps): ReactElement {
  const router = useRouter()

  const backgroundClass = (): string => {
    switch (router.route) {
      case '/validation-success':
        return `${styles.main} background-validate-status`
      case '/activation-success':
        return `${styles.main} background-validate-status`
      default:
        return `${styles.main} background-auth `
    }
  }

  return (
    <main className={backgroundClass()}>
      <BasicHeader />
      <Grid
        container
        spacing={0}
        className={classNames(styles.containerChild, className)}
      >
        <Grid item lg={2} md={2} />
        <Grid item xs={12} lg={8} md={8} className={styles.contentWrapper}>
          <Container
            disableGutters
            maxWidth={false}
            className={`${styles.content}`}
          >
            {children}
          </Container>
        </Grid>
        <Grid item lg={2} md={2} />
      </Grid>
    </main>
  )
}

export default BasicHeaderLayout
