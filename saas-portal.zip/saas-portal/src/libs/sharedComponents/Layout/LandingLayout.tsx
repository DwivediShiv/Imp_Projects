import { clearClientCache, isCookieAccepted } from '@utils/cookie'
import { getAccessToken } from '@utils/auth'
import { getIsSupportedBrowser } from '@utils/detector'
import { ThemeProvider, useMediaQuery } from '@mui/material'
import { ToastContainer } from 'react-toastify'
import { useAuthorize } from '../../core/context/Authorize'
import AccentrikDarkTheme from '../../../styles/acentrikDarkTheme'
import BasicHeaderLayout from './BasicHeaderLayout'
import CenterCard from './CenterCard'
import classNames from 'classnames'
import CustomCookieBanner from '../CookieBanner'
import CustomBanner from '../Banner'
import AssetGroupIcon from '@images/asset_group.svg'
import ExploreAndBuyIcon from '@images/explore_and_buy.svg'
import React, { ReactElement, useEffect, useState } from 'react'
import styles from './LandingLayout.module.css'
import { useRouter } from 'next/router'
import ManageUsersIcon from '@images/manage_users.svg'
import { useUserPreferences } from '@core/context/UserPreferences'
import CustomHeader from '../Header'
import Sidebar from '../Sidebar'
import CustomSetTheme from '../SetTheme'
import Instance from '@images/instance.svg'
import Cluster from '@images/cluster.svg'

type landingProps = {
  children: ReactElement
  layoutType?: string
  isWithoutHeaderFooter: boolean
  isStaticPage: boolean
}

function layoutLoader(layoutType: string, children: React.ReactElement) {
  switch (layoutType) {
    case 'CenterCard':
      return <CenterCard>{children}</CenterCard>
    default:
      return <div className={styles.defaultLayout}>{children}</div>
  }
}

function LandingLayout({
  children,
  layoutType,
  isStaticPage,
  isWithoutHeaderFooter
}: landingProps): ReactElement {
  const { isSideMenuOpen, setSideMenuOpen } = useUserPreferences()
  const [token, setToken] = useState<string>()
  const [supportBannerClosed, setSupportBannerClosed] = useState(false)
  const [siteMenu, setSideMenu] = useState<unknown>([])

  const isSupportedBrowser = getIsSupportedBrowser()
  const { isLogin, isAdmin, isCustomerMngr, isInfraManager } = useAuthorize()
  const router = useRouter()

  function backgroundClass(): string {
    const defaultStyle = `${
      isStaticPage ? styles.staticPageMain : styles.main
    }  ${!isSideMenuOpen && styles.sideMenuOpen} main-container`
    switch (router.route) {
      case '/changepassword':
        return ` ${defaultStyle} ${styles.changePassword}`
      default:
        return `${defaultStyle}`
    }
  }

  function handleLeftDrawerToggle(): void {
    setSideMenuOpen(!isSideMenuOpen)
  }

  useEffect(() => {
    setSideMenu([])
    if (isLogin) {
      setSideMenu([
        isAdmin && {
          header: 'Management',
          name: <>Users</>,
          link: '/manage-users',
          icon: <ManageUsersIcon />
        },
        isInfraManager && {
          header: isInfraManager && !isAdmin ? 'Management' : '',
          name: <>Instances</>,
          link: '/manage-instance',
          icon: <Instance />
        },
        isCustomerMngr && {
          header:
            isCustomerMngr && !isAdmin && !isInfraManager ? 'Management' : '',
          name: <>Customer</>,
          link: '/manage-customers',
          icon: <ManageUsersIcon />
        },
        isInfraManager && {
          name: <>Cluster</>,
          link: '/cluster-list',
          icon: <Cluster />
        }
      ])
    }
  }, [isAdmin, isCustomerMngr, isInfraManager, isLogin])

  const acentrikClass = 'acentrik app'

  function isTokenNeeded(): boolean {
    return isLogin && !token
  }

  async function fetchData() {
    if (!isTokenNeeded()) {
      return
    }
    const accessToken = await getAccessToken()
    setToken(accessToken)
  }

  useEffect(() => {
    fetchData()
  }, [isLogin])

  const currentLocation = location.pathname.split('/')[1]
  const isNotFoundPage = currentLocation === '404'

  // clear all localStorage, sessionStorage and cookie if no accept cookie
  useEffect(() => {
    !isCookieAccepted() && clearClientCache()
  })
  const isLargeScreen = useMediaQuery('(min-width:1024px)')
  const handleSupportBannerClick = () => {
    setSupportBannerClosed(true)
  }
  const displaySupportBrowserBanner = !isSupportedBrowser

  return (
    <ThemeProvider theme={AccentrikDarkTheme}>
      <div
        id="mainWrapper"
        className={`${classNames(styles.wrapper, acentrikClass)} ${
          isLogin && !isSideMenuOpen && styles.sideMenuOpen
        }`}
      >
        <ToastContainer
          position="top-center"
          icon={false}
          newestOnTop
          limit={2}
          className={`${styles.defaultPosition}
            ${
              !isWithoutHeaderFooter
                ? isSideMenuOpen
                  ? styles.openPosition
                  : styles.closePosition
                : null
            }`}
        />
        {isWithoutHeaderFooter ? (
          <>
            <BasicHeaderLayout className={styles.signupContainerLayout}>
              {children}
            </BasicHeaderLayout>
          </>
        ) : (
          <>
            <CustomHeader
              handleLeftDrawerToggle={handleLeftDrawerToggle}
              isStaticPage={isStaticPage}
            />
            {!isStaticPage && (
              <Sidebar
                handleLeftDrawerToggle={handleLeftDrawerToggle}
                siteItem={siteMenu}
              />
            )}
            <main className={backgroundClass()}>
              {!isStaticPage && <div className={styles.reserveSpaceToolbar} />}
              <div
                className={`${
                  !isStaticPage && !isNotFoundPage && styles.containerLayout
                }`}
              >
                {layoutLoader(layoutType, children)}
              </div>
              {/* {isStaticPage ? <FancyStaticFooter /> : <FancyFooter />} */}
            </main>
          </>
        )}
        {!isCookieAccepted() &&
          ((displaySupportBrowserBanner && supportBannerClosed) ||
            !displaySupportBrowserBanner) && <CustomCookieBanner />}
        {displaySupportBrowserBanner && (
          <CustomBanner
            title={isLargeScreen && 'Unsupported Browser'}
            showCloseButton
            onClose={handleSupportBannerClick}
          >
            {isLargeScreen ? (
              <div>
                You seem to be using an unsupported browser. We recommend using
                Mozilla Firefox, Google Chrome or Microsoft Edge for a better
                marketplace experience.
              </div>
            ) : (
              <div>The data marketplace is best viewed on desktop.</div>
            )}
          </CustomBanner>
        )}
        {/* Hacky set theme of useDarkMode config */}
        {isCookieAccepted() && <CustomSetTheme />}
      </div>
    </ThemeProvider>
  )
}

export default LandingLayout
