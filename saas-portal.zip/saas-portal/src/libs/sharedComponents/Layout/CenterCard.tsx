import React from 'react'
import styles from './CenterCard.module.css'

const CenterCard = ({
  children
}: {
  children: React.ReactElement
}): React.ReactElement => {
  return (
    <div>
      <div className={styles.container}>
        <div className={styles.content}>{children}</div>
      </div>
    </div>
  )
}

export default CenterCard
