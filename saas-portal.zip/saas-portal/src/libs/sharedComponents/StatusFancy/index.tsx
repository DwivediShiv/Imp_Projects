import React from 'react'
import { Button as MuiButton } from '@mui/material'
import styles from './index.module.css'

export const statusClassMapping = {
  invited: styles.statusBoxPending,
  unverified: styles.statusBoxUnverified,
  verified: styles.statusBoxActive,
  accepted: styles.statusBoxActive,
  active: styles.statusBoxActive,
  inactive: styles.statusBoxDisabled,
  pending: styles.statusBoxPending,
  build_failed: styles.statusBoxRejected,
  blocked: styles.statusBoxRejected,
  'build failed': styles.statusBoxRejected,
  'deletion in progress': styles.statusBoxPending,
  'version deployment in progress': styles.statusBoxPending,
  'network deployment in progress': styles.statusBoxPending,
  default: styles.statusBoxProvisioned,
  success: styles.statusBoxActive,
  failed: styles.statusBoxRejected,
  deploying: styles.statusBoxPending,
  deleting: styles.statusBoxPending,
  deleted: styles.statusBoxDisabled
}
export interface StatusBoxProps {
  status: string
}

export default function NewStatusBox({
  status
}: StatusBoxProps): React.ReactElement {
  const statusClass =
    statusClassMapping[status] || statusClassMapping['default']
  return (
    <span className={statusClass}>
      <p>&nbsp;&nbsp;{status}&nbsp;&nbsp;</p>
    </span>
  )
}
