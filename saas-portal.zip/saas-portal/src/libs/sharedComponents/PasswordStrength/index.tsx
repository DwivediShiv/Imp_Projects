import React from 'react'
import styles from './index.module.css'
import { SuccessCircleIcon as Done } from '../Icon/SuccessCircleIcon'
import { Remove } from '@mui/icons-material'

export interface PasswordPolicy {
  name: string
  title: string
}

export default function PasswordStrength({
  fulfilledPolicies,
  policies
}: {
  fulfilledPolicies: string[]
  policies: PasswordPolicy[]
}): JSX.Element {
  return (
    <div className={`acentrik ${styles.passwordStrengthContainer}`}>
      {policies.length !== fulfilledPolicies.length && (
        <>
          <div className={styles.passwordLabel}>
            Password must contain the following:
          </div>
          <div className={styles.passwordMessageWrapper}>
            {policies.map((policy: PasswordPolicy) => (
              <div
                key={policy.name}
                className={`${styles.passwordMessageContainer} ${
                  fulfilledPolicies.includes(policy.name) &&
                  styles.passwordMessageActive
                }`}
              >
                <div className={styles.iconWrapper}>
                  {fulfilledPolicies.includes(policy.name) ? (
                    <Done className={`${styles.successIcon} iconSizeSmall`} />
                  ) : (
                    <Remove className={'iconSizeSmall iconColorFillText3'} />
                  )}
                </div>
                <div className={styles.passwordMessage}>{policy.title}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
