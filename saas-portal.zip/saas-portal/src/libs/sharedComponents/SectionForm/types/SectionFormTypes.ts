interface ButtonProps {
  name: string
  color: string
  variant: string
  disableRipple?: boolean
  disable?: (data: object) => boolean
  onClick?: any
  loading?: boolean
}

interface SectionFieldProps {
  name: string
  label: string
  type?: string
  elementType?: string
  getComponent?: any
  inputProps?: object
  isResizable?: boolean
  multiline?: boolean
  maxRows?: number
}
interface SectionConfig {
  getComponent?(data: object): React.ReactNode
  title?: string
  name: string
  type: string
  getLogo?: () => React.ReactNode
  fields?: SectionFieldProps[]
  leftButtons?: ButtonProps[]
  rightButtons?: ButtonProps[]
  label?: string
  value?: any
  options?: any
}

export interface SectionFormProps {
  sectionConfig: SectionConfig[]
  initialValues: object
  validationSchema: any
  handleSubmit: any
}

export interface ButtonSectionProps {
  leftButtons?: ButtonProps[]
  rightButtons?: ButtonProps[]
  isValid?: boolean
  dirty?: boolean
  resetForm?: any
  touched?: any
}

export interface FieldSectionProps {
  errors?: any
  fields: SectionFieldProps[]
  handleBlur?: any
  dirty?: boolean
  setFieldValue?: any
  values?: object
}
