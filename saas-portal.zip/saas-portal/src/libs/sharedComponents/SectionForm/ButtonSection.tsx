import { Grid } from '@mui/material'
import React from 'react'
import styles from './index.module.css'
import { ButtonSectionProps } from './types/SectionFormTypes'
import CustomButton from '../Button'
import Loader from '../Loader'

const ButtonSection = ({
  leftButtons,
  rightButtons,
  isValid,
  dirty,
  resetForm,
  touched
}: ButtonSectionProps): JSX.Element => {
  return (
    <div className={styles.buttonWrapper}>
      <Grid
        container
        className={styles.container}
        justifyContent="space-between"
      >
        <Grid item>
          {leftButtons?.map((leftButton) => {
            return (
              <CustomButton
                key={leftButton.name}
                {...leftButton}
                onClick={
                  leftButton.name === 'Reset' ? resetForm : leftButton.onClick
                }
                disabled={
                  leftButton.disable ? leftButton.disable({ dirty }) : false
                }
              >
                {leftButton.name}
              </CustomButton>
            )
          })}
        </Grid>
        <Grid item>
          {rightButtons?.map((rightButton) => {
            return rightButton.loading ? (
              <div className={styles.loader}>
                <Loader />
              </div>
            ) : (
              <CustomButton
                key={rightButton.name}
                {...rightButton}
                disabled={rightButton?.disable({ touched, dirty, isValid })}
              >
                {rightButton.name}
              </CustomButton>
            )
          })}
        </Grid>
      </Grid>
    </div>
  )
}

export default ButtonSection
