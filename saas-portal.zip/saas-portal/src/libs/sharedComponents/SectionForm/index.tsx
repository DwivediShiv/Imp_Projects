import { Paper } from '@mui/material'
import { Field, Form, Formik } from 'formik'
import ButtonSection from './ButtonSection'
import FieldsSection from './FieldsSection'
import { SectionFormProps } from './types/SectionFormTypes'
import styles from './index.module.css'
import InputField from '../InputField'

const SectionForm: React.FC<SectionFormProps> = ({
  sectionConfig,
  initialValues,
  validationSchema,
  handleSubmit
}) => {
  return (
    <Formik
      initialValues={initialValues}
      onSubmit={async (values, { setSubmitting, resetForm, setFieldError }) => {
        await handleSubmit(values, resetForm, setFieldError)
        setSubmitting(false)
      }}
      validationSchema={validationSchema}
      enableReinitialize
    >
      {({
        errors,
        dirty,
        resetForm,
        handleBlur,
        setFieldValue,
        isValid,
        touched,
        values
      }) => (
        <Form className={styles.form}>
          {sectionConfig.map((section) => (
            <Paper classes={{ root: styles.boxPaper }} key={section.name}>
              <div className={styles.actionWrapper}>
                {section.title && (
                  <div className={styles.header}>
                    <div className={styles.title}>
                      <h4 className="bold">{section.title}</h4>
                    </div>
                  </div>
                )}
                {(() => {
                  switch (section.type) {
                    case 'form':
                      return (
                        <FieldsSection
                          errors={errors}
                          fields={section?.fields}
                          handleBlur={handleBlur}
                          dirty={dirty}
                          setFieldValue={setFieldValue}
                          values={values}
                        />
                      )
                    case 'button':
                      return (
                        <ButtonSection
                          leftButtons={section?.leftButtons}
                          rightButtons={section?.rightButtons}
                          isValid={isValid}
                          dirty={dirty}
                          resetForm={resetForm}
                          touched={touched}
                        />
                      )
                    case 'networkSelections':
                      return (
                        <InputField
                          type="networkSelection"
                          options={section?.options}
                        />
                      )
                    default:
                      return (
                        <Field
                          name={section.name}
                          component={section.getComponent}
                          className={styles.inputbox}
                          isEditActive
                        />
                      )
                  }
                })()}
              </div>
            </Paper>
          ))}
        </Form>
      )}
    </Formik>
  )
}

export default SectionForm
