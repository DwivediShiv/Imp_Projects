import { Field } from 'formik'
import React from 'react'
import CustomInputField from '../WrapperInputField'
import InputField from '../InputField'
import { Grid } from '@mui/material'
import styles from './index.module.css'
import { FieldSectionProps } from './types/SectionFormTypes'

const FieldsSection = ({
  errors,
  fields,
  handleBlur,
  dirty,
  setFieldValue,
  values
}: FieldSectionProps): JSX.Element => {
  function renderFields(field) {
    switch (field.elementType) {
      case 'custom_input_field':
        return (
          <Field
            {...field}
            component={CustomInputField}
            onBlur={(e) =>
              field.onBlurHandler(e, handleBlur, setFieldValue, errors, dirty)
            }
          />
        )

      case 'custom':
        return (
          <Field
            component={field.getComponent}
            className={styles.fieldContainer}
            {...field}
            dirty={dirty}
            errors={errors}
            values={values}
          />
        )
      default:
        return (
          <Field
            className={field.disabled && styles.fieldDisabled}
            component={InputField}
            {...field}
          />
        )
    }
  }
  return (
    <div className={styles.sectionWrapper}>
      <Grid container spacing={4}>
        {fields.map((field) => (
          <Grid item xs={6} key={field.name}>
            {renderFields(field)}
          </Grid>
        ))}
      </Grid>
    </div>
  )
}

export default FieldsSection
