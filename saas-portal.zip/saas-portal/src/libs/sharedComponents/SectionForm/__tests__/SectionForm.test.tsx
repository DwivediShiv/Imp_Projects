import { fireEvent, render, screen } from '@testing-library/react'
import React from 'react'
import SectionForm from '..'
import user from '@testing-library/user-event'
import * as Yup from 'yup'
import {
  ENTER_VALID_EMAIL,
  MAX_100_CHAR_ALLOWED,
  MAX_500_CHAR_ALLOWED,
  MAX_50_CHAR_ALLOWED,
  REQUIRED_FIELD
} from '@constants/constants'
const sectionConfig = [
  {
    name: 'company_information',
    title: 'Company Information',
    type: 'form',
    fields: [
      {
        name: 'companyName',
        label: 'Company Name*',
        type: 'text',
        elementType: 'input',
        inputProps: { maxLength: 100 }
      },
      {
        name: 'description',
        label: 'Description*',
        type: 'text',
        elementType: 'input',
        isResizable: false,
        multiline: true,
        maxRows: 1,
        inputProps: { maxLength: 500 }
      },
      {
        name: 'businessNumber',
        label: 'Business Number*',
        type: 'text',
        elementType: 'input',
        inputProps: { maxLength: 50 }
      },
      {
        name: 'businessEmailId',
        label: 'Business Email ID*',
        type: 'text',
        elementType: 'input'
      },
      {
        name: 'address',
        label: 'Address*',
        type: 'text',
        elementType: 'input',
        inputProps: { maxLength: 500 }
      },
      {
        name: 'website',
        label: 'Website*',
        type: 'text',
        elementType: 'input',
        inputProps: { maxLength: 500 }
      },
      {
        name: 'contactEmail',
        label: 'Contact Email*',
        type: 'text',
        elementType: 'input'
      }
    ]
  },
  {
    name: 'submit_button',
    type: 'button',
    label: 'Add & Submit',
    leftButtons: [
      {
        name: 'Cancel',
        color: 'secondary',
        variant: 'outlined',
        disableRipple: true,
        onClick: jest.fn()
      },
      {
        name: 'Reset',
        'data-action': 'back',
        color: 'secondary',
        variant: 'text'
      }
    ],
    rightButtons: [
      {
        name: 'Create & Invite',
        variant: 'contained',
        color: 'primary',
        type: 'submit',
        processingLoader: true,
        disable: ({ touched, isValid }) => !(touched?.companyName && isValid)
      }
    ]
  }
]

const initialValues = {
  companyName: '',
  description: '',
  businessNumber: '',
  businessEmailId: '',
  address: '',
  website: '',
  contactEmail: '',
  logo: ''
}

const validationSchema = Yup.object().shape({
  logo: Yup.string(),
  company_logo: Yup.mixed(),
  companyName: Yup.string()
    .required(REQUIRED_FIELD)
    .max(100, MAX_100_CHAR_ALLOWED),
  description: Yup.string()
    .required(REQUIRED_FIELD)
    .max(500, MAX_500_CHAR_ALLOWED),
  businessNumber: Yup.string()
    .required(REQUIRED_FIELD)
    .max(50, MAX_50_CHAR_ALLOWED),
  businessEmailId: Yup.string()
    .email(ENTER_VALID_EMAIL)
    .required(REQUIRED_FIELD),
  address: Yup.string().required(REQUIRED_FIELD).max(500, MAX_500_CHAR_ALLOWED),
  website: Yup.string().required(REQUIRED_FIELD).max(500, MAX_500_CHAR_ALLOWED),
  contactEmail: Yup.string().email(ENTER_VALID_EMAIL).required(REQUIRED_FIELD)
})

const handleSubmit = jest.fn()

describe('Render Section form', () => {
  test('should render the section form', async () => {
    render(
      <SectionForm
        sectionConfig={sectionConfig}
        initialValues={initialValues}
        validationSchema={validationSchema}
        handleSubmit={handleSubmit}
      />
    )
  })
  test('cancel, reset and create and invite buttons to be rendered', async () => {
    render(
      <SectionForm
        sectionConfig={sectionConfig}
        initialValues={initialValues}
        validationSchema={validationSchema}
        handleSubmit={handleSubmit}
      />
    )
    const cancelButton = await screen.findByRole('button', { name: /cancel/i })
    const resetButton = await screen.findByRole('button', { name: /reset/i })
    const createButton = await screen.findByRole('button', {
      name: /create & invite/i
    })

    expect(cancelButton).toBeInTheDocument()
    expect(resetButton).toBeInTheDocument()
    expect(createButton).toBeInTheDocument()
  })
  test('clicking on create button , create button is disabled as no form changes', async () => {
    render(
      <SectionForm
        sectionConfig={sectionConfig}
        initialValues={initialValues}
        validationSchema={validationSchema}
        handleSubmit={handleSubmit}
      />
    )
    const createButton = await screen.findByRole('button', {
      name: /create & invite/i
    })
    expect(createButton).toBeInTheDocument()
    expect(createButton).toBeDisabled()
  })

  test('clicking on reset button', async () => {
    render(
      <SectionForm
        sectionConfig={sectionConfig}
        initialValues={initialValues}
        validationSchema={validationSchema}
        handleSubmit={handleSubmit}
      />
    )
    const companyName = await screen.findByRole('textbox', {
      name: /company name\*/i
    })
    fireEvent.change(companyName, {
      target: { value: 'Mercedes' }
    })
    expect(companyName).toHaveValue('Mercedes')
    const businessEmailId = await screen.findByRole('textbox', {
      name: /business email id\*/i
    })
    fireEvent.change(businessEmailId, {
      target: { value: 'test@test.com' }
    })
    expect(businessEmailId).toHaveValue('test@test.com')

    const resetButton = await screen.findByRole('button', { name: /reset/i })
    expect(resetButton).toBeInTheDocument()
    fireEvent.click(resetButton)

    expect(businessEmailId).toHaveValue('')
    expect(companyName).toHaveValue('')
  })

  test('rendering form fields', async () => {
    render(
      <SectionForm
        sectionConfig={sectionConfig}
        initialValues={initialValues}
        validationSchema={validationSchema}
        handleSubmit={handleSubmit}
      />
    )
    const form = sectionConfig.filter((data) => data.type === 'form')
    form[0].fields.forEach((field) => {
      expect(screen.getByText(field.label)).toBeInTheDocument()
    })
  })
})

describe('Yup validation Login Page', () => {
  it('check yup validations on the form , incorrect values will give error', async () => {
    const values = {
      companyName: '',
      description: '',
      businessNumber: '',
      businessEmailId: 'abc@',
      address: '',
      website: '',
      contactEmail: 'test.id',
      logo: ''
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toBe(false)
  })

  it('check yup validations on the form correct values no error', async () => {
    const values = {
      companyName: 'BMW',
      description: 'Test',
      businessNumber: '12234',
      businessEmailId: 'test@test.com',
      address: '1234',
      website: 'https://google.com',
      contactEmail: 'test@test.com',
      logo: 'abc'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toEqual(true)
  })
})
