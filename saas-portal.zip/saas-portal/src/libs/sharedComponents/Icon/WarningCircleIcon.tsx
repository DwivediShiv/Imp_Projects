import React, { ReactElement } from 'react'
import { IconSize } from '../../constants/constants'
import styles from './index.module.css'
import WarningCircle from '@images/alert_circle.svg'

export function WarningCircleIcon({
  iconSize = IconSize.Large,
  className,
  state = 'warning'
}: {
  iconSize?: string
  className?: string
  state?: 'warning' | 'danger' | 'base'
}) {
  return (
    <WarningCircle
      className={`${iconSize} ${className} ${styles.warningCircle} ${styles[state]}`}
    />
  )
}
