import React from 'react'
import { IconSize } from '../../constants/constants'
import styles from './index.module.css'
import SuccessCircle from '@images/success_circle.svg'
export function SuccessCircleIcon({
  iconSize = IconSize.Large,
  className
}: {
  iconSize?: string
  className?: string
}) {
  return (
    <SuccessCircle
      className={`${iconSize} ${className} ${styles.successIcon}`}
    />
  )
}
