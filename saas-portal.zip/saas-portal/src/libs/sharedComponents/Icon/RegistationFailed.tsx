import React, { ReactElement } from 'react'
import { ImageSize } from '../../constants/constants'
import styles from './index.module.css'
import RegistrationFailed from '@images/registration_failed.svg'

export function RegistrationFailedIcon({
  iconSize = ImageSize.Large,
  className,
  alt = 'registration-failed'
}: {
  iconSize?: string
  className?: string
  alt?: string
}) {
  return (
    <RegistrationFailed
      alt={alt}
      className={`${iconSize} ${className}  ${styles.registrationFailed} `}
    />
  )
}
