// components/FilterBox.tsx
import React, { useState, useRef, useEffect } from 'react'
import ReactDOM from 'react-dom'
import styles from './index.module.css'
import ArrowDropDown from '@images/filterarrow.svg'

interface FilterBoxProps {
  title: string
  listOptions: string[]
  onChange: (title: string, selectedOptions: string[]) => void
}

const FilterBox: React.FC<FilterBoxProps> = ({
  title,
  listOptions,
  onChange
}) => {
  const [selectedOptions, setSelectedOptions] = useState<string[]>([])
  const [showOptions, setShowOptions] = useState<boolean>(false)
  const ref = useRef<HTMLDivElement>(null)
  const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({})

  useEffect(() => {
    if (ref.current) {
      const rect = ref.current.getBoundingClientRect()
      setDropdownStyle({ top: rect.bottom, left: rect.left })
    }
  }, [ref])

  const handleOptionChange = (option: string) => {
    const updatedSelection = selectedOptions.includes(option)
      ? selectedOptions.filter((opt) => opt !== option)
      : [...selectedOptions, option]

    setSelectedOptions(updatedSelection)
    onChange(title, updatedSelection)
  }

  return (
    <div
      ref={ref}
      className={styles.filterBox}
      onClick={() => setShowOptions(!showOptions)}
    >
      <div className={styles.title}>
        {title} &nbsp; {showOptions ? <ArrowDropDown /> : <ArrowDropDown />}
      </div>
      {showOptions &&
        ReactDOM.createPortal(
          <div style={dropdownStyle} className={styles.dropdown}>
            {listOptions.map((option, index) => (
              <div key={index} className={styles.option}>
                <label>
                  <input
                    type="checkbox"
                    checked={selectedOptions.includes(option)}
                    onChange={(e) => {
                      e.stopPropagation()
                      handleOptionChange(option)
                    }}
                  />
                  {option}
                </label>
              </div>
            ))}
          </div>,
          document.body
        )}
    </div>
  )
}

export default FilterBox
