import React, { useEffect, ReactElement, ReactNode } from 'react'
import ReactModal from 'react-modal'
import styles from './index.module.css'
import CrossIcon from '@images/cross.svg'
import { ICON_TYPE } from '@constants/modalConstant'
import { RegistrationFailedIcon as FailedSignup } from '../Icon/RegistationFailed'
import classNames from 'classnames'
import AccountLock from '@images/account_lock.svg'
import MailSuccess from '@images/email_sent.svg'
import MailFailed from '@images/email_failed.svg'
import { useRouter } from 'next/router'
import CustomLoader from '../CustomLoader'
import CustomButton from '../Button'

if (process.env.NODE_ENV !== 'test') ReactModal.setAppElement('#__next')

export interface ModalProps extends ReactModal.Props {
  title?: ReactNode
  type: string
  modalTemplate?: string
  progressValue?: number
  buttonActionMain?: () => void
  buttonActionSub?: () => void
  showCloseButton?: boolean
  onToggleModal: () => void
  titleSize?: 'h2' | 'h3' | 'h6'
  children?: ReactNode
}

interface IconModal {
  icon: ReactNode
  title?: ReactNode
  description: ReactNode[]
}

export default function CustomModal({
  title,
  type,
  modalTemplate,
  progressValue,
  buttonActionMain,
  buttonActionSub,
  showCloseButton = true,
  onToggleModal,
  titleSize,
  children,
  ...props
}: ModalProps): ReactElement {
  const router = useRouter()
  const { shouldCloseOnOverlayClick, isOpen } = props
  const classes = classNames(styles[titleSize])

  function setModalBackdrop() {
    // We are now using same backdrop solution for all browser
    // Firefox will attribute data-showmodal
    // Other browser will use class acentrik-modal-backdrop
    const mainContentDiv = document.getElementById('mainWrapper')
    const topFancyModal = document.getElementsByClassName(
      `${styles.modalOverlay} ${styles.isActive}`
    )

    if (isOpen && mainContentDiv) {
      mainContentDiv.setAttribute('data-showmodal', 'true')
      mainContentDiv.className = `${mainContentDiv.className}${
        mainContentDiv.className.indexOf('acentrik-modal-backdrop') === -1
          ? ' acentrik-modal-backdrop'
          : ''
      }`
      topFancyModal[0]?.classList.remove(`${styles.isActive}`)
    }
  }
  setModalBackdrop()

  useEffect(() => {
    if (shouldCloseOnOverlayClick) {
      const onClickOutside = () => onToggleModal()
      window.addEventListener('click', onClickOutside)
      return () => window.removeEventListener('click', onClickOutside)
    }
  }, [])

  useEffect(() => {
    if (isOpen) {
      return () => {
        const mainContentDiv = document.getElementById('mainWrapper')
        const fancyModalList = document.getElementsByClassName(
          `${styles.modalOverlay}`
        )
        if (fancyModalList.length <= 1 && mainContentDiv) {
          mainContentDiv.setAttribute('data-showmodal', 'false')
        } else {
          fancyModalList[fancyModalList?.length - 2]?.classList.add(
            `${styles.isActive}`
          )
        }

        const modalCount = document.getElementsByClassName(
          'ReactModal__Overlay--after-open'
        )

        if (
          mainContentDiv &&
          mainContentDiv.className.indexOf('acentrik-modal-backdrop') !== -1 &&
          modalCount?.length <= 1
        ) {
          let classes = mainContentDiv.className.split(' ')
          classes = classes.filter((className) => {
            return className !== 'acentrik-modal-backdrop'
          })
          mainContentDiv.className = classes.join(' ')
        }
      }
    }
  }, [isOpen])

  function getModalTemplate(
    template?: string,
    progressValue?: number,
    buttonActionMain?: () => void,
    buttonActionSub?: () => void,
    toggleClose?: () => void
  ): IconModal {
    switch (template) {
      case 'accountLock': {
        return {
          icon: (
            <AccountLock
              className={`imageSizeLarge ${styles.accountLock} ${styles.danger}`}
            />
          ),
          title: 'Account locked',
          description: [
            'Your account has been locked due to multiple failed login attempts. Please click the button below to reset your account. ',
            <CustomButton
              key="accountLock"
              color="primary"
              variant="contained"
              className="mt-6"
              onClick={buttonActionMain}
            >
              Reset Password
            </CustomButton>
          ]
        }
      }

      /* Modal template for invitation accept success - reset password page */
      case 'acceptInvitationSuccess': {
        return {
          icon: <MailSuccess className={`imageSizeLarge ${styles.success}`} />,
          title: 'Accept Invitation Success',
          description: [
            'Invitation process done.',
            <CustomButton
              key="acceptInvitationSuccess"
              color="primary"
              variant="contained"
              className="mt-1"
              onClick={buttonActionMain}
            >
              Return to Login
            </CustomButton>
          ]
        }
      }

      /* Modal template for invitation already accepted - reset password page */
      case 'invitationAccepted': {
        return {
          icon: (
            <MailFailed
              className={`imageSizeLarge ${styles.danger} ${styles.mailFailed}`}
            />
          ),
          title: 'Invitation Accepted',
          description: [
            'User has already accepted the invitation. Please login.',
            <CustomButton
              key="invitationAccepted"
              color="primary"
              variant="contained"
              className="mt-1"
              onClick={buttonActionMain}
            >
              Return to Login
            </CustomButton>
          ]
        }
      }

      /* Modal template for token failure (invalid/expired) - reset password page */
      case 'tokenInvalidFailure': {
        return {
          icon: (
            <MailFailed
              className={`imageSizeLarge ${styles.danger} ${styles.mailFailed}`}
            />
          ),
          title: 'Invalid Invitation Link',
          description: [
            'Invitation Link is invalid/expired. Please contact administrator.',
            <CustomButton
              key="tokenInvalidFailure"
              color="primary"
              variant="contained"
              className="mt-1"
              onClick={buttonActionMain}
            >
              Return to Login
            </CustomButton>
          ]
        }
      }

      case 'resetPasswordSuccess': {
        return {
          icon: <MailSuccess className={`imageSizeLarge ${styles.success}`} />,
          title: 'Password Reset Successful',
          description: [
            'Your password has been changed successfully.',
            <CustomButton
              key="resetPasswordSuccess"
              color="primary"
              variant="contained"
              className="mt-1"
              onClick={buttonActionMain}
            >
              Return to Login
            </CustomButton>
          ]
        }
      }
      case 'resetPasswordFailed': {
        return {
          icon: (
            <MailFailed
              className={`imageSizeLarge ${styles.danger} ${styles.mailFailed}`}
            />
          ),
          title: 'Password Reset Failed',
          description: [
            <>
              We are unable to process this request at the moment, please try
              again later.
            </>,
            <CustomButton
              key="resetPasswordFailed"
              color="primary"
              variant="contained"
              className="mt-1"
              onClick={buttonActionMain}
            >
              Return to Login
            </CustomButton>
          ]
        }
      }
      default: {
        return {
          icon: <CustomLoader />,
          title: 'Processing Transaction',
          description: ['Please do not click refresh or leave the page.']
        }
      }
    }
  }

  const ModalTemplateRender = ({ template }: { template?: IconModal }) => {
    return (
      <>
        <div className={styles.icon}>{template.icon}</div>
        {template.title ? (
          <div className={styles.subtitle}>{template.title}</div>
        ) : (
          <></>
        )}

        {template.description.map((each, index) => {
          return (
            <div key={index} className={styles.description}>
              {each}
            </div>
          )
        })}
      </>
    )
  }

  return (
    <ReactModal
      overlayClassName={`${styles.modalOverlay} ${styles.isActive}`}
      bodyOpenClassName={styles.modalBodyOpen}
      {...props}
      ariaHideApp={false}
      className={`${styles.modal} ${props.className} acentrik`}
    >
      {showCloseButton ? (
        <button
          className={styles.close}
          onClick={onToggleModal}
          data-testid="closeModal"
        >
          <CrossIcon />
        </button>
      ) : (
        <></>
      )}

      {title && (
        <header className={styles.header}>
          <div className={classes}>{title}</div>
        </header>
      )}

      <div className={styles.scrollContainer}>
        {type === ICON_TYPE ? (
          <div className={showCloseButton && styles.iconModalWrapper}>
            <ModalTemplateRender
              template={getModalTemplate(
                modalTemplate,
                progressValue,
                buttonActionMain,
                buttonActionSub,
                onToggleModal
              )}
            />
          </div>
        ) : (
          <>{children}</>
        )}
      </div>
    </ReactModal>
  )
}
