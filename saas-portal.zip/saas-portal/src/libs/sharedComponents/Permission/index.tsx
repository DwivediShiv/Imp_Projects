import React, { ReactElement, useEffect, useState } from 'react'
import CustomIconicCard, {
  CustomIconicCardSize,
  CustomIconicCardState
} from '../IconicCard'
import appConfig from '../../../../app.config'
import { useIsMounted } from '@hooks/useIsMounted'
import styles from './index.module.css'
import {
  getLastVisitUrl,
  isFreeToAccessPage,
  isIconicBigBoard,
  isAllowWithoutLogin
} from '@utils/platformSetting'
import { hasAccess } from '@utils/auth'
import { useAuthorize } from '@core/context/Authorize'
import classNames from 'classnames'
import { IconSize } from '@utils/constants'
import { useRouter } from 'next/router'
import {
  PERMISSION_ADMIN,
  PERMISSION_INFRAMANAGER,
  PERMISSION_CUSTOMERMNGR,
  FAILURE_MESSAGES
} from '@constants/permissionConstants'
import CustomLoader from '../CustomLoader'

export default function Permission({
  eventType,
  children,
  isBigBoardError
}: {
  eventType: string
  children: ReactElement
  isBigBoardError?: boolean
}): ReactElement {
  const [data, updateData] = useState<boolean | 'ERROR'>()
  const [errorMessage, updateError] = useState<ReactElement>()
  const [messageState, updateMessageState] = useState<CustomIconicCardState>()
  const [isFancyIconicBigBoard, setIsFancyIconicBigBoard] =
    useState<boolean>(false)
  const [isFancyRequesting, setIsFancyRequesting] = useState<boolean>(true)
  const [lastVisit, setLastVisit] = useState<string>('/search')
  const [icon, setIcon] = useState<string>()
  const [className, setClassName] = useState<string>()
  const [header, setHeader] = useState<string>()
  const isMounted = useIsMounted()
  const { isLogin, isAdmin } = useAuthorize()

  const router = useRouter()

  useEffect(() => {
    setIsFancyIconicBigBoard(isBigBoardError || isIconicBigBoard())
    const lastVisitPath = getLastVisitUrl()
    setLastVisit(lastVisitPath || lastVisit)
    return () => null
  }, [isBigBoardError, location.pathname])

  useEffect(() => {
    setIsFancyRequesting(true)
    const getData = async () => {
      if (!isMounted()) return
      try {
        if (
          isFreeToAccessPage(eventType) ||
          (!isLogin && isAllowWithoutLogin(eventType))
        ) {
          updateData(true)
          setIsFancyRequesting(false)
        } else if (isLogin) {
          const isUserHasAccess = hasAccess(eventType)
          updateData(isUserHasAccess)
          if (eventType === PERMISSION_ADMIN && isAdmin) {
            updateData(isAdmin)
            setIsFancyRequesting(false)
            return
          }

          if (!isUserHasAccess) {
            setIcon('restricted-access')
            setClassName('alert')
            setHeader('Restricted Access')
            updateMessageState(CustomIconicCardState.Alert)
            updateError(
              <div
                className={`${
                  isFancyIconicBigBoard
                    ? styles.fancyBigMessage
                    : styles.fancyMessage
                }`}
              >
                <div>{FAILURE_MESSAGES.RESTRICTED_ACCESS}</div>
              </div>
            )
          }
          setIsFancyRequesting(false)
        }
      } catch (err) {
        setIsFancyRequesting(false)
      }
    }
    getData()
    // Cleanup function
    return () => updateData(false)
  }, [eventType, isMounted, isLogin])

  const oneSecondToGetWeb3AccountIdTimeout = setTimeout(() => {
    setIsFancyRequesting(false)
    clearInterval(oneSecondToGetWeb3AccountIdTimeout)
  }, 2000)

  if (data === true) {
    return <>{children}</>
  }

  if (isFancyRequesting) {
    return (
      <div
        className={classNames(
          styles.fancyBlock,
          isFancyIconicBigBoard && styles.fancyBigBlock
        )}
      >
        <CustomLoader isCenter customStyle={styles.loader} />
      </div>
    )
  }

  return (
    <div className={classNames(isFancyIconicBigBoard && styles.fancyBigBlock)}>
      <CustomIconicCard
        header={isFancyIconicBigBoard ? header : undefined}
        action={!isAdmin && (() => router.push(lastVisit))}
        icon={icon}
        actionLabel=""
        state={messageState}
        className={className}
        size={
          isFancyIconicBigBoard
            ? CustomIconicCardSize.Big
            : CustomIconicCardSize.Small
        }
      >
        {errorMessage}
      </CustomIconicCard>
    </div>
  )
}
