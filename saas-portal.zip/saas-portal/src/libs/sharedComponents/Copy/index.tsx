import React, { useEffect, useState } from 'react'
import styles from './index.module.css'
import IconCopy from '@images/copy.svg'
import { SuccessCircleIcon as TickIcon } from '../Icon/SuccessCircleIcon'
import { IconColor, IconSize } from '@constants/constants'
import CustomTooltip from '../Tooltip'

export default function Copy({
  copyText,
  className,
  iconSize = IconSize.Medium,
  color = IconColor.Info
}: {
  copyText: string
  className?: any
  iconSize?: IconSize
  color?: IconColor
}) {
  const [isCopied, setIsCopied] = useState<boolean>(false)
  const [tooltipText, setTooltipText] = useState<string>('Copy')

  useEffect(() => {
    setTooltipText(isCopied ? 'Copied!' : 'Copy')
    let timeout
    if (isCopied) {
      timeout = setTimeout(() => setIsCopied(false), 3000)
    }
    return () => {
      clearTimeout(timeout)
    }
  }, [isCopied])

  function handleClick() {
    setIsCopied(true)
    navigator.clipboard.writeText(copyText)
  }

  return (
    <div
      className={`${styles.copyContainer} ${className}`}
      data-testid="fancy-copy"
    >
      <CustomTooltip
        title={tooltipText}
        type="custom"
        onClick={handleClick}
        icon={
          isCopied ? (
            <TickIcon
              className={`${styles.copyButton} ${className} ${iconSize}`}
              data-testid="tick-icon"
            />
          ) : (
            <IconCopy
              className={`${styles.copyIcon} ${className} ${color} ${iconSize}`}
              data-testid="copy-icon"
            />
          )
        }
        placement="top"
      />
    </div>
  )
}
