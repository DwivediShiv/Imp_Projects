import {
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Drawer,
  Toolbar,
  Divider,
  Tooltip,
  ListSubheader
} from '@mui/material'
import React, { ReactElement, useState } from 'react'
import styles from './index.module.css'
import MenuIcon from '@images/menu.svg'
import { useRouter } from 'next/router'

import { useUserPreferences } from '@core/context/UserPreferences'
import {
  fancyNavigation,
  removeDelegateFunction
} from '@utils/fancyDelegateAction'

import classNames from 'classnames'
import appConfig from 'app.config'
import useViewportCheck from '@core/useViewportCheck'
import {
  SET_AUTOCOMPLETE_EXPAND,
  SMALL_DESKTOP_BREAKPOINT
} from '@constants/constants'
import CustomButton from '../Button'

const Sidebar = ({
  handleLeftDrawerToggle,
  siteItem
}: {
  handleLeftDrawerToggle: () => void
  siteItem: any
}): ReactElement => {
  const router = useRouter()
  const { isSideMenuOpen } = useUserPreferences()
  const { windowSize } = useViewportCheck()
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
  const [open, setOpen] = useState<any>({})

  const handleOnHover = (
    event: React.MouseEvent<HTMLDivElement>,
    item
  ): void => {
    if (!isSideMenuOpen) return
    event.stopPropagation()
    setOpen({ ...open, [item.name.props.children]: true })
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
    setOpen({})
  }

  const handleNavigate = (navigateTo: string) => {
    if (router.pathname === navigateTo || router.asPath === navigateTo) return
    removeDelegateFunction(SET_AUTOCOMPLETE_EXPAND)
    fancyNavigation(() => router.push(navigateTo))
    handleClose()
  }

  function renderMenuItem(menuItem: any, i: number, type?: string) {
    if (!menuItem) return null
    const { name, link, icon, header, tooltip } = menuItem
    const isSubmenuHeader: boolean = type === 'menuItem'
    const isBottomNav = type === 'bottomNav'
    const showSubHeader =
      !isSideMenuOpen || windowSize.width < SMALL_DESKTOP_BREAKPOINT

    return (
      <div key={`${name}_sideBar_${i}`}>
        {header && (
          <ListSubheader
            className={`${
              showSubHeader ? styles.listSubHeader : styles.collapsedHeader
            }`}
          >
            {showSubHeader ? (
              header
            ) : (
              <Divider
                className={`${styles.divider} ${styles.subHeaderDivider}`}
              />
            )}
          </ListSubheader>
        )}
        <Tooltip
          title={tooltip || name}
          placement="right"
          arrow
          disableHoverListener={!isSideMenuOpen}
          classes={{
            tooltip: styles.tooltip,
            arrow: styles.arrow
          }}
        >
          <ListItem
            button
            className={styles[type]}
            classes={{
              root: !isSideMenuOpen
                ? styles.listItemRoot
                : styles.listItemRootMenuOpen,
              selected: styles.listItemSelected
            }}
            selected={router.pathname === link || router.asPath === link}
            key={`${link}_link_${i}`}
            onClick={
              isBottomNav
                ? null
                : isSubmenuHeader
                ? (e) => handleOnHover(e, menuItem)
                : () => handleNavigate(link)
            }
            disableRipple
          >
            <ListItemIcon
              classes={{ root: styles.listItemIconRoot }}
              key={`${link}_icon_${i}`}
            >
              {icon}
            </ListItemIcon>
            <ListItemText
              classes={{ root: styles.listItemTextRoot }}
              primary={name}
            />
          </ListItem>
        </Tooltip>
      </div>
    )
  }

  function drawerItem() {
    return (
      <>
        <Toolbar className={styles.toolbar}>
          {isSideMenuOpen && (
            <CustomButton
              className={styles.button}
              onClick={handleLeftDrawerToggle}
            >
              <MenuIcon width="32" height="32" className={styles.menuIcon} />
            </CustomButton>
          )}
        </Toolbar>
        <List classes={{ root: styles.listRoot }}>
          {siteItem
            .filter((value) => value)
            .map((item, i) => renderMenuItem(item, i))}
        </List>
      </>
    )
  }

  return (
    <div
      className={classNames(
        styles[appConfig.customization.theme],
        styles.drawerContainer,
        'sidebar-drawer-container'
      )}
    >
      {windowSize.width < SMALL_DESKTOP_BREAKPOINT ? (
        <Drawer
          anchor="left"
          variant="temporary"
          open={isSideMenuOpen}
          className={classNames(
            styles[appConfig.customization.theme],
            styles.drawer
          )}
          classes={{ root: styles.mobileDrawerRoot, paper: styles.drawerPaper }}
          onClose={handleLeftDrawerToggle}
        >
          {drawerItem()}
        </Drawer>
      ) : (
        <Drawer
          variant="permanent"
          open={isSideMenuOpen}
          className={`${styles.drawer} ${isSideMenuOpen && styles.shrink}`}
          classes={{ root: styles.drawerRoot, paper: styles.drawerPaper }}
        >
          {drawerItem()}
        </Drawer>
      )}
    </div>
  )
}

export default Sidebar
