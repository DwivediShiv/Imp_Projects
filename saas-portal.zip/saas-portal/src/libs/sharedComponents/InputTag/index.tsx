import { useField } from 'formik'
import React, { ReactElement, useState, useEffect } from 'react'
import styles from './index.module.css'
import CustomChips from '../Chips'

export default function InputTag(props: any): ReactElement {
  const { component: Component, value, ...other } = props
  const [field, meta, helper] = useField(props.name)
  const [tagValue, setTagValue] = useState<string[]>(value)

  function handleOnDelete(chip) {
    setTagValue(tagValue.filter((c) => c !== chip))
  }

  function handleOnAdd(chip) {
    setTagValue((c) => [...c, chip])
  }

  useEffect(() => {
    helper.setValue(tagValue)
    return () => null
  }, [tagValue])

  return (
    <Component
      id={props.name}
      value={tagValue}
      newChipKeyCodes={[188]}
      onChange={props.onChange}
      blurBehavior="add"
      onDelete={handleOnDelete}
      onAdd={handleOnAdd}
      disableUnderline
      onBlur={props.onBlur}
      className={styles.inputChips}
      chipRenderer={({ value, handleDelete }, key) => (
        <CustomChips
          key={key}
          size="medium"
          handleDelete={handleDelete}
          label={value}
          color="primary"
          className={styles.chips}
        />
      )}
      {...other}
    />
  )
}
