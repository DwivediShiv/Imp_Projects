import React, { ReactElement } from 'react'
import styles from './BasicHeader.module.css'
import {
  AppBar,
  CssBaseline,
  Toolbar,
  useMediaQuery,
  useScrollTrigger
} from '@mui/material'
import { useRouter } from 'next/router'
import appConfig from 'app.config'

export default function BasicHeader(): ReactElement {
  const router = useRouter()
  const isLargeScreen = useMediaQuery('(min-width:1024px)')
  const scrollTrigger = useScrollTrigger({
    disableHysteresis: true,
    threshold: isLargeScreen ? 39 : 56
  })

  return (
    <>
      <CssBaseline />
      <AppBar
        position="sticky"
        className={`${styles.appBar} ${scrollTrigger && styles.onScroll} ${
          styles[appConfig.customization.theme]
        }`}
        classes={{ root: styles.rootAppBar }}
      >
        <Toolbar className={styles.headerWrapper}>
          <div className={`${styles.buttonsWrapper}`}>
            <div className={styles.fancyLogoWrapper}>
              <div className={styles.logoSubtitle}>Saas Portal</div>
            </div>
          </div>
        </Toolbar>
      </AppBar>
    </>
  )
}
