import {
  Drawer,
  Grid,
  Hidden,
  Link as MuiLink,
  List,
  ListItem,
  ListItemText
} from '@mui/material'
import React, { ReactElement, useState } from 'react'
import styles from './index.module.css'
import router from 'next/router'
import AcentrikLogo from '@images/acentrik_logo_full_large.svg'
import MenuIcon from '@images/menu.svg'
import { setAsLastVisitUrl } from '@utils/platformSetting'
import { useAuthorize } from '@core/context/Authorize'
import CustomButton from '../Button'
import useViewportCheck from '@core/useViewportCheck'
import AuthenticationButtonGroup from './AuthenticationButtonGroup'
import NavigationToWebPortal from '../NavigationToWebPortal'

export default function StaticHeader(): ReactElement {
  const { isLogin } = useAuthorize()
  const { windowSize } = useViewportCheck()
  const [siteMenu, setSiteMenu] = useState<any>([
    {
      name: <>Compute-to-Data</>,
      link: '/computetodata'
    },
    {
      name: <>Contact Us</>,
      link: '/contact-us'
    }
  ])
  const container =
    window !== undefined ? () => window.document.body : undefined
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const handleDrawerToggle = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }

  return (
    <>
      <Grid container className={styles.container}>
        <Grid item sm={6} md={4} lg={2} className={styles.logoWrapper}>
          {windowSize.width < 1440 && (
            <MenuIcon
              className={styles.menuIcon}
              onClick={handleDrawerToggle}
            />
          )}

          <div className={styles.fancyLogoWebPortal}>
            <NavigationToWebPortal url="/">
              <AcentrikLogo className={styles.fancyAcentrikLogo} />
            </NavigationToWebPortal>
          </div>
        </Grid>
        <Grid item lg={1} md={4} />
        {windowSize.width >= 1440 && (
          <Grid item lg={6} className={styles.buttonGroupWrapper}>
            <div className={styles.navButtonGroup}>
              <CustomButton
                variant="outlinedPrimary"
                className={`${styles.noOutlineBtn} ${styles.navButton}`}
                onClick={() => {
                  setAsLastVisitUrl()
                  router.push('/manage-users')
                }}
              >
                Explore Marketplace
              </CustomButton>
              <span className={styles.separator}>|</span>
              <CustomButton
                variant="outlinedPrimary"
                className={`${styles.noOutlineBtn} ${styles.navButton}`}
                onClick={() => {
                  setAsLastVisitUrl()
                  router.push('/computetodata')
                }}
              >
                Compute-to-Data
              </CustomButton>
              <span className={styles.separator}>|</span>
              <CustomButton
                variant="outlinedPrimary"
                className={`${styles.noOutlineBtn} ${styles.navButton}`}
                onClick={() => {
                  setAsLastVisitUrl()
                  router.push('/contact-us')
                }}
              >
                Contact Us
              </CustomButton>
            </div>
          </Grid>
        )}
        <Grid item lg={1} />
        {windowSize.width >= 768 && (
          <Grid
            item
            lg={2}
            md={4}
            sm={6}
            className={styles.authButtonGroupWrapper}
          >
            <AuthenticationButtonGroup />
          </Grid>
        )}
      </Grid>
      <Hidden smUp implementation="css">
        {windowSize.width < 1440 && (
          <Drawer
            container={container}
            variant="temporary"
            anchor="left"
            open={mobileMenuOpen}
            onClose={handleDrawerToggle}
            classes={{ paper: styles.fullHeight }}
            ModalProps={{
              keepMounted: true // Better open performance on mobile.
            }}
          >
            <div className={styles.drawerHeader}>
              <MenuIcon
                onClick={handleDrawerToggle}
                className={styles.menuIcon}
              />
            </div>
            <List className={styles.listRoot}>
              {siteMenu
                .filter((value) => value)
                .map(({ name, link }: { name: string; link: string }, i) => (
                  <MuiLink href={link} key={link}>
                    <ListItem
                      button
                      className={`${styles.listItemRoot} ${
                        router.pathname === link && styles.listItemSelected
                      }`}
                      key={`${link}_link_${i}`}
                    >
                      <ListItemText
                        className={styles.listItemTextRoot}
                        primary={name}
                      />
                    </ListItem>
                  </MuiLink>
                ))}
            </List>
            <>
              {windowSize.width < 768 && (
                <div className={styles.drawAuthGroupWrapper}>
                  <CustomButton
                    color="primary"
                    variant="outlined"
                    onClick={() => {
                      setAsLastVisitUrl()
                      isLogin
                        ? router.push('/manage-users')
                        : router.push('/login')
                    }}
                    fullWidth
                  >
                    Login
                  </CustomButton>
                </div>
              )}
            </>
          </Drawer>
        )}
      </Hidden>
    </>
  )
}
