import React, { ReactElement, useState } from 'react'
import {
  fancyNavigation,
  removeDelegateFunction
} from '@utils/fancyDelegateAction'
import styles from './index.module.css'
import { useRouter } from 'next/router'
import AcentrikLogo from '@images/acentrik_logo_full_large.svg'
import DefaultAvatarIcon from '@images/default_avatar.svg'

import MenuIcon from '@images/menu.svg'
import { keycloakLogout } from '@utils/auth'
import ProfileMenu from './ProfileMenu'
import { useAuthorize } from '@core/context/Authorize'
import { IconSize, SET_AUTOCOMPLETE_EXPAND } from '@constants/constants'
import CustomButton from '../Button'
import AuthenticationButtonGroup from './AuthenticationButtonGroup'

export default function MarketHeader({
  handleLeftDrawerToggle
}: {
  handleLeftDrawerToggle: () => void
}): ReactElement {
  const router = useRouter()
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
  const { isLogin, landingPage } = useAuthorize()
  // const { biconomySocialLogin } = useWagmiBiconomySocialLogin()
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation()
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const handleLogout = async () => {
    removeDelegateFunction(SET_AUTOCOMPLETE_EXPAND)
    fancyNavigation(() => keycloakLogout())
    setAnchorEl(null)
  }

  const handleNavigate = (navigateTo: string, siteTitle?: string) => {
    removeDelegateFunction(SET_AUTOCOMPLETE_EXPAND)
    if (siteTitle) {
      fancyNavigation(() =>
        router.push(`${navigateTo}?title=${siteTitle}`, navigateTo)
      )
    } else {
      fancyNavigation(() => router.push(navigateTo))
    }
    handleClose()
  }

  const handleLogoClick = () => {
    if (router.asPath === landingPage || router.pathname === landingPage) return
    handleNavigate(landingPage)
  }

  return (
    <>
      <span className={styles.sidebarBtn}>
        <CustomButton
          onClick={handleLeftDrawerToggle}
          className={styles.button}
        >
          <MenuIcon width="32" className={styles.menuIcon} />
        </CustomButton>
      </span>

      <div className={`${styles.buttonsWrapper}`}>
        <div className={styles.fancyLogoWrapper}>
          <AcentrikLogo
            className={styles.fancyAcentrikLogo}
            onClick={handleLogoClick}
          />
          <div className={styles.logoSubtitle}>Saas Portal</div>
        </div>
        <div>
          {isLogin ? (
            <div className={styles.logInContainer}>
              <div className={styles.fancyDefaultAvatar}>
                <CustomButton color="primary" onClick={handleClick}>
                  <DefaultAvatarIcon className={IconSize.ExtraLarge} />
                </CustomButton>
              </div>
              <ProfileMenu
                anchorEl={anchorEl}
                handleClose={handleClose}
                handleNavigate={handleNavigate}
                handleLogout={handleLogout}
              />
            </div>
          ) : (
            <AuthenticationButtonGroup />
          )}
        </div>
      </div>
    </>
  )
}
