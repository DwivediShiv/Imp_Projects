import React, { ReactElement } from 'react'
import { Divider, Menu, MenuItem } from '@mui/material'
import styles from './index.module.css'
import LogoutIcon from '@images/profile_menu_logout.svg'
import ChangePasswordIcon from '@images/profile_menu_change_password.svg'

export interface profileMenuProps {
  anchorEl?: HTMLElement
  handleClose?: () => void
  handleNavigate?: (navigateTo: string, siteTitle?: string) => void
  handleLogout?: () => void
}

export default function ProfileMenu({
  anchorEl,
  handleClose,
  handleNavigate,
  handleLogout
}: profileMenuProps): ReactElement {
  return (
    <>
      <Menu
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
        elevation={0}
        anchorOrigin={{
          vertical: 60, // avatar height + arrow tip height
          horizontal: 'right'
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right'
        }}
        classes={{
          paper: styles.profileMenuPaper,
          list: styles.profileMenuList
        }}
      >
        {/* <MenuItem
          disableGutters
          onClick={() => handleNavigate('/changepassword')}
          classes={{ root: styles.profileMenuItem }}
          disableRipple
        >
          <ChangePasswordIcon />
          Change Password
        </MenuItem>
        <Divider className={styles.divider} /> */}
        <MenuItem
          disableGutters
          onClick={handleLogout}
          classes={{ root: styles.profileMenuItem }}
          disableRipple
        >
          <LogoutIcon />
          Log out
        </MenuItem>
      </Menu>
    </>
  )
}
