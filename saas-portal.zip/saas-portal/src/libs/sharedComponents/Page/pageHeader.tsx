import React, { ReactElement, useEffect } from 'react'
import classNames from 'classnames/bind'
import styles from './pageHeader.module.css'
import Container from '../Container'

const cx = classNames.bind(styles)

export default function PageHeader({
  title,
  description,
  center
}: {
  title: string
  description?: string
  center?: boolean
}): ReactElement {
  let styleClasses

  function getRenderStyle() {
    const className = styles.hide
    styleClasses = cx({
      header: true,
      center,
      [className]: className
    })
  }
  getRenderStyle()

  useEffect(() => {
    getRenderStyle()
    return () => null
  })

  return (
    <header className={styleClasses}>
      <Container>
        <h1 className={styles.title}>{title}</h1>
        {description && <p className={styles.description}>{description}</p>}
      </Container>
    </header>
  )
}
