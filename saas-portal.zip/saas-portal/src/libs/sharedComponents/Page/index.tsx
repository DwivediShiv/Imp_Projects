import React, { ReactNode, ReactElement, useEffect } from 'react'
import styles from './index.module.css'
import classNames from 'classnames'
import clsx from 'clsx'
import Container from '../Container'
import PageHeader from './pageHeader'

export interface PageProps {
  children: ReactNode
  title?: string
  description?: string
  noPageHeader?: boolean
  headerCenter?: boolean
}

export default function Page({
  children,
  title,
  description,
  noPageHeader,
  headerCenter
}: PageProps): ReactElement {
  const cx = classNames.bind(styles)
  const className = styles.marginNormal
  const pageClasses = cx({
    [className]: clsx(styles.page, className)
  })

  useEffect(() => {
    return () => null
  })

  return (
    <>
      {title && !noPageHeader && (
        <PageHeader
          title={title}
          description={description}
          center={headerCenter}
        />
      )}
      <div className={pageClasses}>
        <Container>{children}</Container>
      </div>
    </>
  )
}
