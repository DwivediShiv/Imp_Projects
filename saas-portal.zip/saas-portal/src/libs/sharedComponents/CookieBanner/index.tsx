import React, { ReactElement } from 'react'
import CustomBanner from '../Banner'
import styles from './index.module.css'
import { useUserPreferences } from '@core/context/UserPreferences'
import { getFancyWebPortalUri } from '@utils/url'
import { IconSize } from '@utils/constants'
import CustomButton from '../Button'
import LinkButton from '../LinkButton'

export default function CustomCookieBanner(): ReactElement {
  const { setAcceptCookies, isCookieAccepted } = useUserPreferences()

  return (
    !isCookieAccepted && (
      <CustomBanner
        title="Acentrik uses cookies for various purposes"
        className={styles.bannerContainer}
      >
        <div className={styles.content}>
          <p className="body2">
            Certain cookies are required to make our website technically
            accessible and usable for you.
          </p>

          <p className="body2">
            Aside from those required cookies, we use web technologies to
            enhance your browsing experience and for marketing analytics. To
            find out more, read our{' '}
            <LinkButton
              title="Privacy Policy"
              href={getFancyWebPortalUri('/privacy')}
              target="_blank"
              iconSize={IconSize.Medium}
            />{' '}
            and{' '}
            <LinkButton
              title="Cookie Policy"
              href={getFancyWebPortalUri('/cookie')}
              target="_blank"
              iconSize={IconSize.Medium}
            />
            .
          </p>
        </div>
        <div className={styles.accept}>
          <CustomButton
            variant="outlined"
            color="primary"
            onClick={() => {
              setAcceptCookies(true)
            }}
          >
            Agree only to required cookies
          </CustomButton>
          <CustomButton
            classes={{ root: styles.overideBtn }}
            onClick={() => {
              setAcceptCookies(true)
            }}
            color="primary"
            variant="contained"
          >
            Agree to all
          </CustomButton>
        </div>
      </CustomBanner>
    )
  )
}
