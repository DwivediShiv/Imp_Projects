import { InputProps } from '../../TextField'

export interface DropzoneProps extends InputProps {
  name: string
  disabled?: boolean
  isLoading?: boolean
  error?: boolean | string
  sizeLimit?: number
  acceptFileType?: 'dataset' | 'image' | 'algo' | 'eula' | 'logo'
}
