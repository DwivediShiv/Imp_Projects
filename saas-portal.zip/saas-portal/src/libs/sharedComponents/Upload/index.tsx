import React, { ReactElement, useState, useEffect } from 'react'
import { useDropzone } from 'react-dropzone'
import styles from './index.module.css'
import UploadIcon from '@images/upload.svg'
import { useField } from 'formik'
import appConfig from 'app.config'
import { megaByteToByte } from '@utils/conversion'
import UploadImage from '@images/upload_image.svg'
import axios from 'axios'
import FancyImageZoomable from '../Image'
import CustomButton from '../Button'
import CustomLoader from '../CustomLoader'
import { DropzoneProps } from './types/uploadTypes'
import { REJECT_FILE_TYPE } from '@constants/uploadConstant'
import HelperMessage from '../HelperMessage'

export default function Upload({
  name,
  disabled,
  isLoading,
  error,
  sizeLimit,
  acceptFileType = 'image',
  ...props
}: Partial<DropzoneProps>): ReactElement {
  const [field, meta, helpers] = useField(name)
  const [loading, setLoading] = useState(isLoading)
  const [files, setFiles] = useState(props.value || [])
  const [hasError, setHasError] = useState<boolean | string>(error)
  const [base64Img, setBase64Img] = useState<string>()
  const getAcceptFileTypeInfo = () => {
    const result = { types: '', labels: '', sizeLimit: '' }
    switch (acceptFileType) {
      case 'dataset':
      case 'algo':
        result.types = ''
        result.labels = ''
        result.sizeLimit = appConfig.ipfs.uploadLimit
        break
      case 'eula':
        result.types = 'application/pdf'
        result.labels = '.PDF'
        result.sizeLimit = appConfig.ipfs.eulaUploadLimit
        break
      case 'logo':
        result.types = 'image/jpeg, image/png'
        result.labels = 'JPEG, PNG'
        result.sizeLimit = sizeLimit.toString()
        break
      default:
        result.types = 'image/jpeg, image/png'
        result.labels = 'JPEG, PNG'
        result.sizeLimit = appConfig.ipfs.imageUploadLimit
    }
    return { ...result }
  }
  const acceptFileTypeInfo = getAcceptFileTypeInfo()
  const fileSizeLimit = acceptFileTypeInfo.sizeLimit
  const fileSupportLabel = acceptFileTypeInfo.labels
  function bytesToSize(bytes) {
    const sizes: string[] = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    if (bytes === 0) return '0 Bytes'
    const i: number = parseInt(
      Math.floor(Math.log(bytes) / Math.log(1024)).toString()
    )
    if (i === 0) return `${bytes} ${sizes[i]}`
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`
  }

  const onDrop = (acceptedFiles) => {
    setLoading(true)
    helpers.setTouched(true, false)
    const currentFile =
      acceptedFiles && acceptedFiles.length === 1 && acceptedFiles?.[0]
    setHasError(false)

    if (acceptedFiles.length > 1) {
      helpers.setError(
        `Error. Please upload one ${
          acceptFileType === 'image' || acceptFileType === 'logo'
            ? 'image'
            : 'file'
        } only.`
      )
      setHasError(true)
      setLoading(false)
      return
    }

    setFiles(
      acceptedFiles.map((file) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
          contentType: file.type
        })
      )
    )

    if (currentFile.size > megaByteToByte(fileSizeLimit)) {
      acceptedFiles.splice(0, 1)
      helpers.setError(
        `Error. File size exceeded ${fileSizeLimit} MB, please try again.`
      )
      setHasError(true)
      setLoading(false)
      return
    }

    if (
      (acceptFileType === 'dataset' &&
        REJECT_FILE_TYPE.find((fileType) => fileType === currentFile.type)) ||
      !currentFile.type
    ) {
      helpers.setError('Error. Unsupported file format.')
      setHasError(true)
      setLoading(false)
      return
    }
    setLoading(false)
  }

  useEffect(() => {
    if (files && files.length > 0) {
      helpers.setValue(files, false)
    }
    return () => null
  }, [files])

  useEffect(() => {
    async function getBase64(url) {
      const img = await axios
        .get(url, {
          responseType: 'arraybuffer'
        })
        .then((response) =>
          Buffer.from(response.data, 'binary').toString('base64')
        )
      if (img) {
        setBase64Img(img)
      }
    }
    if (files?.length && files[0]?.preview) {
      getBase64(files[0]?.url || files[0]?.preview)
    }
  }, [files])

  const dropZoneProps = {
    noClick: true,
    disabled,
    accept: acceptFileTypeInfo.types,
    onDrop,
    ...props
  }

  const {
    getRootProps,
    getInputProps,
    isDragActive,
    isDragReject,
    acceptedFiles,
    open
  } = useDropzone(dropZoneProps)

  const onRemove = () => {
    acceptedFiles.splice(0, 1)

    setFiles(undefined)
    helpers.setValue(undefined, false)
    helpers.setError(undefined)
    setHasError(false)
  }

  const content = (
    <div>
      <div className={styles.uploadIcon}>
        {acceptFileType !== 'image' ? (
          <UploadIcon className={`iconSizeExtraLarge`} />
        ) : (
          <UploadImage className={`iconSizeExtraLarge`} />
        )}
      </div>
      <div className={styles.dropZoneDescription}>
        <p className={`body2 secondary-text grid-center`}>
          Drag and drop here, or
          <CustomButton
            color="secondary"
            className={styles.browseButton}
            onClick={open}
          >
            browse
          </CustomButton>
        </p>
        <p className={`mt-2 caption ${styles.fileSupportLabel}`}>
          {fileSupportLabel && <>Supported File Type: {fileSupportLabel}</>}
        </p>
        <p className={`mt-1 caption ${styles.fileSize}`}>
          Max file size: {`${fileSizeLimit} MB`}
        </p>
      </div>
    </div>
  )

  const preview = files?.map((file) => (
    <div key={file?.name}>
      <>
        {acceptFileType === 'eula' ? (
          <div className={styles.documentPreview}>
            <p className="caption">
              {file?.name || file?.path}{' '}
              {!isNaN(file?.size) && ` -  ${bytesToSize(file?.size)}`}
            </p>
          </div>
        ) : acceptFileType === 'image' || acceptFileType === 'logo' ? (
          <div className={styles.previewContainer}>
            <FancyImageZoomable src={files[0]?.preview} isFixSizeImage />
          </div>
        ) : (
          <div className={styles.documentPreview}>
            <p className="body2 secondary-text">{file?.name || file?.path}</p>
            {!isNaN(file?.size) && (
              <p className={`mt-1 caption ${styles.fileSize}`}>
                File Size: {bytesToSize(file?.size)}
              </p>
            )}
          </div>
        )}
      </>
      <CustomButton className={styles.remove} color="error" onClick={onRemove}>
        Remove
      </CustomButton>
    </div>
  ))

  const loader = (
    <div className={styles.loader}>
      <CustomLoader
        message={<h5 className="bold">Uploading</h5>}
        progressValue={78}
      />
    </div>
  )
  return (
    <div className={`${hasError && styles.error}`}>
      <div
        {...getRootProps({
          className: isDragActive
            ? `${styles.dropzone} ${styles.dragover}`
            : disabled
            ? `${styles.dropzone} ${styles.disabled}`
            : files && files.length > 0
            ? `${styles.dropzone} ${
                hasError ? styles.errorBorder : styles.successBorder
              }`
            : styles.dropzone
        })}
      >
        <div>
          <input {...getInputProps()} />
          {files &&
          files.length > 0 &&
          Object.keys(files?.[0] || {}).length > 0 ? (
            preview
          ) : (
            <>
              {loading && loader}
              {!loading && content}
            </>
          )}
        </div>
      </div>
      <div className={styles.errorContainer}>
        {hasError && <HelperMessage message={error} isAlert={!!hasError} />}
      </div>
    </div>
  )
}
