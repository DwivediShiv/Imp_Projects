import React, { ReactNode } from 'react'
import CustomIconicCard, {
  CustomIconicCardSize,
  CustomIconicCardState
} from '../IconicCard'
import { setAsLastVisitUrl } from '@utils/platformSetting'
import styles from './index.module.css'
import { useRouter } from 'next/router'
import { useAuthorize } from '@core/context/Authorize'
import CustomButton from '../Button'

interface PrivateRouteProps {
  children: ReactNode
}

const PrivateRoute = ({ children }: PrivateRouteProps) => {
  const router = useRouter()
  const { isLogin } = useAuthorize()

  if (!isLogin) {
    return (
      <div className="privateRouteCard">
        <CustomIconicCard
          header="Account Required"
          icon="login-required"
          size={CustomIconicCardSize.Big}
          state={CustomIconicCardState.Warning}
        >
          <div>
            <div>
              <div className={styles.optionButton}>
                <p>Already have an account? </p>
                <CustomButton
                  color="secondary"
                  onClick={() => router.push('/login')}
                >
                  Login
                </CustomButton>
              </div>
            </div>
          </div>
        </CustomIconicCard>
      </div>
    )
  }

  return <>{children}</>
}
export default PrivateRoute
