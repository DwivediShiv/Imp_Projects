import React, { ReactText } from 'react'
import { cssTransition, toast, ToastOptions } from 'react-toastify'
import TickIcon from '@images/check_circle.svg'
import InfoIcon from '@images/icon_information.svg'
import WarningIcon from '@images/icon_warning.svg'
import ErrorIcon from '@images/error_circle.svg'
import CrossIcon from '@images/cross.svg'
import classNames from 'classnames'
import styles from './index.module.css'

const ToastCloseButton = ({ closeToast }) => (
  <div onClick={closeToast} className={classNames('toast-btn-close')}>
    <CrossIcon />
  </div>
)

const Toast = (
  type: string,
  message?: string,
  toastId?: string,
  className?: string
): ReactText => {
  if (!toast.isActive(toastId)) {
    toast.dismiss()
  }

  const bounce = cssTransition({
    enter: `${styles.animated} ${styles.bounceIn}`,
    exit: `${styles.animated} ${styles.bounceOut}`
  })

  const defaultToastConf: ToastOptions = {
    position: toast.POSITION.TOP_CENTER,
    autoClose: 3000,
    closeOnClick: false,
    closeButton: ToastCloseButton,
    hideProgressBar: true,
    pauseOnHover: true,
    transition: bounce,
    ...(toastId && { toastId }),
    className: `${styles.toastClass} ${className}`
  }

  switch (type) {
    case 'warning':
      return toast.warning(
        <>
          <WarningIcon className={classNames('toast-svg')} />
          <div className={classNames('toast-message')}>{message}</div>
        </>,
        defaultToastConf
      )
    case 'error':
      return toast.error(
        <>
          <ErrorIcon className={classNames('toast-svg')} />
          <div className={classNames('toast-message')}>{message}</div>
        </>,
        defaultToastConf
      )
    case 'success':
      return toast.success(
        <>
          <TickIcon className={classNames('toast-svg')} />
          <div className={classNames('toast-message')}>{message}</div>
        </>,
        defaultToastConf
      )
    case 'info':
      return toast.info(
        <>
          <InfoIcon className={classNames('toast-svg')} />
          <div className={classNames('toast-message')}>{message}</div>
        </>,
        defaultToastConf
      )
    default:
      return toast(message)
  }
}

export default Toast
