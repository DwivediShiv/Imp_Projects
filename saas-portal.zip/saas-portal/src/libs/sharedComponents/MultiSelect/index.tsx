import React, {
  ChangeEvent,
  ReactElement,
  ReactNode,
  useEffect,
  useState
} from 'react'
import styles from './index.module.css'
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  MenuProps
} from '@mui/material'
import { makeStyles as tssReactMakeStyles } from 'tss-react/mui'
import { getStatusColor } from '@utils/fancyStyles'
import useViewportCheck from '@core/useViewportCheck'
import CustomCheckbox from '../Checkbox'
import { setBorderRadius } from '../TextField'

type SelectBoxProps = {
  label?: string | ReactNode
  inputName: string
  options?: any
  value?: string[]
  error?: boolean | string
  isValid?: boolean | string
  isWarning?: boolean
  onChange?: any
  onStateChange?(e: ChangeEvent<any>, state?: any): void
  disabled?: boolean
  isNativeSelect?: boolean
  placeholder?: string
  helperText?: string | ReactNode
  isDisable?: boolean
  containerClass?: string
  deselectText?: string
  deselectValue?: any
  MenuProps?: Partial<MenuProps>
  customBackground?: string
  selectType?: string
  onValueChange?: any
}

const useCustomInputBaseStyles = tssReactMakeStyles<{
  isValid
  isWarning
  error
  label
  inputValue
  name
  customBackground
}>()(
  (
    theme,
    { isValid, isWarning, error, label, inputValue, name, customBackground }
  ) => {
    return {
      root: {
        color: inputValue ? 'var(--light-text-1)' : 'var(--light-text-3)',
        maxHeight: '50px',
        padding: !label && '10px 16px',
        lineHeight: '23px',
        '&:focus': {
          backgroundColor: 'var(--surface-1-color)',
          borderRadius: '5px'
        }
      },
      disabled: {
        color: 'var(--neutral-95-color)',
        backgroundColor: 'var(--surface-2-color)',
        cursor: 'not-allowed'
      },
      icon: {
        color: 'var(--light-text-1)'
      }
    }
  }
)

const useStyles = tssReactMakeStyles<{
  isValid
  isWarning
  error
  name
  customBackground
  expanded
  popperWidth
}>()(
  (
    theme,
    { isValid, isWarning, error, name, customBackground, expanded, popperWidth }
  ) => {
    return {
      label: {
        color: getStatusColor(
          { isValid, isWarning, error },
          'var(--surface-4-color)'
        ),
        '&.Mui-focused': {
          color: getStatusColor(
            { isValid, isWarning, error },
            'var(--surface-4-color)'
          )
        },
        '&.Mui-error': {
          color: 'var(--danger-color)'
        }
      },
      customInput: {
        height: '56px',
        marginRight: name === 'fileSizeType' ? '20px' : '',
        backgroundColor: 'var(--surface-0-color)',
        color: 'var(--light-text-1)',
        borderRadius: setBorderRadius(),
        borderBottomLeftRadius: `${expanded && '0px'}`,
        borderBottomRightRadius: `${expanded && '0px'}`,
        border: 'solid 1px',
        borderColor: getStatusColor({ isValid, isWarning, error }),
        display: 'grid',
        '&.Mui-error': {
          border: '1px solid  var(--danger-color)',
          '&:after': {
            borderColor: 'transparent'
          }
        },
        '&.Mui-focused, &:hover': {
          backgroundColor: 'var(--surface-0-color)'
        }
      },
      paperBG: {
        backgroundColor: 'var(--surface-2-color)',
        color: 'var(--light-text-1)',
        maxHeight: '260px',
        borderRadius: '0px',
        border: '1px solid var(--neutral-70-color)',
        borderBottomLeftRadius: 'var(--border-radius)',
        borderBottomRightRadius: 'var(--border-radius)',
        maxWidth: 'unset !important',
        minWidth: 'unset !important',
        boxShadow: 'var(--dropdown-box-shadow)',
        marginTop: '-1px',
        padding: 'var(--padding-2) 0',
        backgroundImage: 'unset',
        width: popperWidth
      },
      menuList: {
        padding: '0'
      },
      listItem: {
        maxWidth: popperWidth,
        backgroundColor: 'var(--surface-2-color) !important',
        '&:hover': {
          backgroundColor: 'var(--secondary-color-hover) !important'
        },
        '&.Mui-selected': {
          '&:hover': {
            backgroundColor: 'var(--secondary-color-hover) !important'
          }
        }
      }
    }
  }
)

function CustomMultiSelect({
  label,
  inputName,
  options,
  error,
  isValid,
  isWarning,
  disabled,
  customBackground,
  selectType,
  onValueChange,
  ...field
}: SelectBoxProps): ReactElement {
  const [expanded, setExpanded] = useState<boolean>(false)
  const [popperWidth, setPopperWidth] = useState<number>(0)
  const { windowSize } = useViewportCheck()
  const { classes } = useStyles({
    isValid,
    isWarning,
    error,
    name: inputName,
    customBackground,
    expanded,
    popperWidth
  })
  const inputBaseClasses = useCustomInputBaseStyles({
    isValid,
    isWarning,
    error,
    label,
    inputValue: field.value,
    name: inputName,
    customBackground
  }).classes
  const optionKeys = options ? Object.keys(options) : []
  const isNetworkType = selectType === 'network'
  const {
    containerClass,
    onStateChange,
    value,
    onChange,
    deselectText,
    ...otherField
  } = field
  const isAllSelected = value.length === optionKeys.length
  const deselectSelectMenu = () => {
    return (
      deselectText && (
        <MenuItem
          classes={{
            root: classes.listItem,
            selected: styles.selectedItem
          }}
          key={deselectText}
          value={deselectText}
          selected={isAllSelected}
          autoFocus={true}
          className={styles.checkbox}
          disableRipple
          onClick={(e) => e.preventDefault()}
        >
          <CustomCheckbox
            name={deselectText}
            label={deselectText}
            defaultChecked={isAllSelected}
          />
        </MenuItem>
      )
    )
  }

  const renderCheckBox = () => {
    return (
      optionKeys &&
      optionKeys.map((option: string, index: number) => (
        <MenuItem
          classes={{
            root: classes.listItem,
            selected: styles.selectedItem
          }}
          key={index}
          value={option}
          autoFocus={true}
          className={styles.checkbox}
          disableRipple
          onClick={(e) => e.preventDefault()}
        >
          <CustomCheckbox
            name={option}
            label={<span>{option}</span>}
            defaultChecked={value.indexOf(option) > -1}
          />
        </MenuItem>
      ))
    )
  }

  const renderSelectView = (selected: any) => {
    if (selected.length === optionKeys.length || !selected.length)
      return deselectText
    return selected.join(', ')
  }

  const overideContainerStyle =
    (containerClass && styles[containerClass]) || containerClass

  function onSelectStateChange(event: ChangeEvent<any>, state: string) {
    if (state === 'collapsed' && !value.length) onValueChange(optionKeys)
    setExpanded(state === 'expanded')
    onStateChange && onStateChange(event, state)
  }

  useEffect(() => {
    if (!expanded) return
    const textFieldDropdown = document.getElementById(
      `${inputName}_formControl`
    )
    setPopperWidth(textFieldDropdown.clientWidth)
  }, [windowSize.width, expanded])

  return (
    <FormControl
      variant={label ? 'filled' : 'standard'}
      className={overideContainerStyle || ''}
      classes={{ root: styles.root }}
      error={!!error}
      disabled={disabled}
      id={`${inputName}_formControl`}
    >
      {label && (
        <InputLabel
          id={`${inputName}-label`}
          htmlFor={inputName}
          className={styles.label}
          classes={{
            root: classes.label,
            shrink: styles.labelShrink,
            focused: styles.labelFocus
          }}
        >
          {label}
        </InputLabel>
      )}

      <Select
        {...otherField}
        onChange={onChange}
        multiple
        value={value}
        displayEmpty={!label}
        id={inputName}
        className={classes.customInput}
        classes={{ select: styles.selectRoot }}
        onOpen={(event) => onSelectStateChange(event, 'expanded')}
        onClose={(event) => onSelectStateChange(event, 'collapsed')}
        MenuProps={{
          classes: {
            paper: classes.paperBG,
            list: classes.menuList
          },
          variant: 'menu',
          ...field.MenuProps
        }}
        input={<Select classes={inputBaseClasses} disableUnderline />}
        renderValue={renderSelectView}
      >
        {deselectSelectMenu()}
        <hr className={styles.divider} />

        {renderCheckBox()}
      </Select>
    </FormControl>
  )
}

export default CustomMultiSelect
