import React, { ChangeEvent, ReactElement } from 'react'
import styles from './index.module.css'
import HelperMessage from '../HelperMessage'
import { useFormikContext } from 'formik'

export default function Textarea({ ...props }: any): ReactElement {
  const {
    name,
    max,
    value,
    isValid,
    error,
    customBackground,
    hasMaxHeight,
    isResizable,
    onInputChange
  } = props

  const formik = useFormikContext()
  const fieldHelper = formik?.getFieldHelpers(name)

  function handleOnChange(e: ChangeEvent<HTMLInputElement>) {
    const inputValue = e.currentTarget?.value || e.target?.value
    fieldHelper?.setValue(inputValue, true)
    if (onInputChange) {
      onInputChange(inputValue)
    }
  }

  return (
    <div
      className={`${styles.textarea} ${styles.fancyTextarea} ${
        isResizable !== null &&
        isResizable !== undefined &&
        !isResizable &&
        styles.fancyNonDraggableTextarea
      } ${hasMaxHeight && styles.setMaxHeight} ${isValid && styles.valid} ${
        error && styles.error
      }`}
    >
      <textarea
        name={name}
        id={name}
        className={`${styles.textarea} ${styles.fancyTextarea} ${styles[customBackground]}`}
        {...props}
        onChange={handleOnChange}
      />
      {(error || max) && (
        <div
          className={`${styles.helperText} ${
            error === undefined ? styles.floatRight : styles.spaceBetween
          }`}
        >
          {error && <HelperMessage message={error} isAlert={!!error} />}
          {max && (
            <div
              className={`${styles.length} ${!!error && styles.error} ${
                isValid && styles.valid
              }`}
            >
              {value?.trim()?.length ?? 0} / {max}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
