import React, { ReactElement } from 'react'
import styles from './index.module.css'
import DotIcon from '@images/dot.svg'

export interface indicatorProps {
  type: 'dot' | 'tag' | any
  variant:
    | 'default'
    | 'success'
    | 'danger'
    | 'warning'
    | 'disabled'
    | 'provisioned'
    | 'failed'
    | 'pending_verification'
    | 'finalizing_instance'
  className?: string
  children?: any
}

function Indicator({
  type,
  variant,
  className,
  children
}: indicatorProps): ReactElement {
  const renderByType = () => {
    switch (type) {
      case 'dot':
        return (
          <DotIcon
            className={`${styles.dot} ${styles[variant] || ''} ${className}`}
          />
        )
      case 'tag':
        return (
          <span
            className={`${styles.tag} ${styles[variant] || ''} ${className}`}
          >
            {children}
          </span>
        )
      default:
        return (
          <span className={`${styles.normal} ${styles.default} ${className}`}>
            {children}
          </span>
        )
    }
  }

  return renderByType()
}

export default Indicator
