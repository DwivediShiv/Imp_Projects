import moment from 'moment'
import * as React from 'react'

export default function WithCustomFormat(Component: any) {
  return function WithCustomFormatComponent({
    customFormat,
    ...props
  }: any): any {
    if (!customFormat) return <Component {...props} />
    if (!props.date) return '-'
    const date = Array.isArray(props?.date) ? props.date[0] : props.date
    const dateNew = props.isUnix
      ? new Date(Number(date) * 1000)
      : new Date(date)
    return customFormat && moment(dateNew).format(customFormat)
  }
}
