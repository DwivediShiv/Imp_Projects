import { ReactNode } from 'react'
export type RadioButtonProps = {
  label?: string | ReactNode
  name: string
  options?: any[]
  optionType: string
  defaultValue?: string
  error?: any
  disabled?: boolean
  information?: string
  value?: any
  onChange?: any
  rowProp?: boolean
  multipleLineDesc?: boolean
  className?: string
}
