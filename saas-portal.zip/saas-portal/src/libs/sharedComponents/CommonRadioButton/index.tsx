import React, { ReactElement } from 'react'
import styles from './index.module.css'
import {
  FormControl,
  FormControlLabel,
  FormLabel,
  Radio,
  RadioGroup
} from '@mui/material'

import RadioButtonChecked from '@images/radio_button_checked.svg'
import RadioButton from '@images/radio_button_unchecked.svg'
import HelperMessage from '../HelperMessage'
import { makeStyles } from 'tss-react/mui'
import { useFormikContext } from 'formik'
import { RadioButtonProps } from './types'

const useStyles = makeStyles()(() => {
  return {
    root: {
      width: '100%'
    },
    label: {
      lineHeight: 'var(--line-height-p)',
      paddingBottom: 'var(--padding-2)',
      color: 'var(--light-text-1)',
      '&.Mui-focused': {
        color: 'var(--light-text-1)'
      }
    },
    radioButtonLabel: {
      color: 'var(--light-text-2)',
      fontSize: 'var(--acentrik-font-size-body-2)'
    },
    rootRadioBtn: {
      padding: 'var(--padding-2)',
      color: 'var(--neutral-70-color)',
      '&.Mui-checked': {
        color: 'var(--primary-color)'
      }
    },
    radioButton: {
      color: 'var(--primary-color)'
    }
  }
})

function CommonRadioButton(props: RadioButtonProps): ReactElement {
  const {
    label,
    name,
    options,
    optionType,
    error,
    value,
    information,
    disabled,
    defaultValue,
    onChange,
    rowProp = false,
    multipleLineDesc = true,
    className,
    ...restProps
  } = props
  const { classes } = useStyles()
  const formik = useFormikContext()
  const fieldHelper = formik?.getFieldHelpers(name)
  const fieldProps = formik?.getFieldMeta(name)
  const fieldValues = formik?.getFieldMeta(name)?.value ?? value

  function handleChange(event) {
    fieldHelper.setValue(event?.target?.checked, true)
    onChange && onChange(event)
  }

  return (
    <>
      <FormControl
        variant="filled"
        classes={{ root: classes.root }}
        error={error}
      >
        {label && (
          <FormLabel
            classes={{
              root: classes.label
            }}
          >
            {label}
          </FormLabel>
        )}
        <RadioGroup
          id={name}
          aria-label={name}
          name={name}
          onChange={handleChange}
          defaultValue={defaultValue}
          value={fieldValues}
          row={rowProp}
          {...fieldProps}
          className={className || ''}
        >
          {options.map((option: string, index: number) => (
            <FormControlLabel
              key={index}
              classes={{
                root: `${
                  rowProp
                    ? styles.controlledRowLabelRoot
                    : styles.controlledLabelRoot
                } ${multipleLineDesc ? styles.multiple : ''}`,
                label: styles.radioButtonLabel
              }}
              value={option}
              disabled={disabled}
              control={
                <Radio
                  classes={{
                    root: styles.root,
                    checked: styles.radioButtonChecked
                  }}
                  icon={<RadioButton className={styles.radioUnchecked} />}
                  checkedIcon={
                    <RadioButtonChecked className={styles.radioChecked} />
                  }
                  disableRipple
                />
              }
              label={option}
            />
          ))}
        </RadioGroup>
        {error && <HelperMessage message={error} isAlert={!!error} />}
      </FormControl>
    </>
  )
}

export default CommonRadioButton
