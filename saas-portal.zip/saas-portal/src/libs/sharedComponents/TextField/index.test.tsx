import React from 'react'
import { render, screen } from '@testing-library/react'
import FancyTextField from '.'

describe('FancyTextField', () => {
  test('able to render text field', async () => {
    render(
      <FancyTextField type="text" label="text" name="text"></FancyTextField>
    )

    const textField = screen.getByTestId('text')
    expect(textField).toBeInTheDocument()
  })

  test('able to render capcha field', async () => {
    render(
      <FancyTextField
        type="captcha"
        label="captcha"
        name="captcha"
      ></FancyTextField>
    )

    const textField = screen.getByTestId('text')
    expect(textField).toBeInTheDocument()
  })

  test('able to render email field', async () => {
    render(
      <FancyTextField type="email" label="email" name="email"></FancyTextField>
    )

    const textField = screen.getByTestId('text')
    expect(textField).toBeInTheDocument()
  })

  test('able to render FancyTextField disable', async () => {
    render(
      <FancyTextField
        type="text"
        label="text"
        name="text"
        value="test"
        error="error"
        disabled={true}
      ></FancyTextField>
    )

    const textField = screen.getByLabelText('text')
    expect(textField).toBeInTheDocument()
    expect(textField).toHaveValue('test')
    expect(textField).toBeDisabled()
  })

  test('able to render nolabel field', async () => {
    render(
      <FancyTextField
        type="nolabel"
        label="nolabel"
        name="nolabel"
      ></FancyTextField>
    )

    const textField = screen.getByTestId('nolabel')
    expect(textField).toBeInTheDocument()
  })

  test.skip('able to render tags field', async () => {
    render(
      <FancyTextField type="tags" label="tags" name="tags"></FancyTextField>
    )

    const textField = screen.getByTestId('tags')
    expect(textField).toBeInTheDocument()
  })

  test.skip('able to render optionsTags field', async () => {
    render(
      <FancyTextField
        type="optionsTags"
        label="optionsTags"
        name="optionsTags"
        value={['option', 'option2']}
      ></FancyTextField>
    )

    const textField = screen.getByTestId('tags')
    expect(textField).toBeInTheDocument()
  })

  test('able to render default field when no type selected', async () => {
    render(<FancyTextField name="default"></FancyTextField>)

    const textField = screen.getByTestId('default')
    expect(textField).toBeInTheDocument()
  })

  test.skip('able to render helper text', async () => {
    render(
      <FancyTextField
        name="default"
        helperText="helper"
        isValid={false}
        isWarning={false}
        isAlert={false}
        error="error"
        message="error"
      ></FancyTextField>
    )

    const textField = screen.getByTestId('form-control')
    expect(textField).toBeInTheDocument()
    const helper = screen.getByTestId('form-control-helper')
    expect(helper).toBeInTheDocument()
  })
})
