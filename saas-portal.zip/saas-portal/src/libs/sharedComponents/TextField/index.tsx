import React, {
  ChangeEvent,
  FormEvent,
  ReactNode,
  KeyboardEvent,
  ReactElement,
  useState
} from 'react'
import {
  TextField,
  FormControl,
  IconButton,
  FilledInput,
  InputAdornment,
  InputLabel,
  GridSize
} from '@mui/material'
import ChipInput from 'material-ui-chip-input-v5'
import { makeStyles } from 'tss-react/mui'
import styles from './index.module.css'
import Visibility from '@images/icon_visible.svg'
import VisibilityOff from '@images/icon_visible_off.svg'
import MagnifyingGlass from '@images/magnifying-glass.svg'
import {
  getNumberTypeBorder,
  getCustomTagInputHeight,
  getStatusColor
} from '@utils/fancyStyles'
import HelperMessage from '../HelperMessage'
import NumberFormat from 'react-number-format'
// import { FormFieldProps } from 'src/@types/Form'
import { sanitiseNumber } from '@utils/numberValidations'
import { NOTCHED_OUTLINE } from '@constants/constants'
import { FormFieldProps } from '@libs/types/Form'
import InputTag from '../InputTag'

export interface InputProps {
  name: string
  label?: string | ReactNode
  placeholder?: string
  required?: boolean
  help?: string
  type?: string
  value?: any
  decimal?: boolean
  onChange?(
    event:
      | FormEvent<HTMLInputElement | HTMLTextAreaElement>
      | ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
      | ChangeEvent<HTMLSelectElement>
      | ChangeEvent<HTMLTextAreaElement>
      | any,
    value?: any
  ): void
  onKeyUp?(e: KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>): void
  onClick?: (e: FormEvent) => void
  onStateChange?(e: ChangeEvent<any>, state?: any): void
  pattern?: string
  min?: string
  max?: string
  disabled?: boolean
  readOnly?: boolean
  field?: FormFieldProps | any
  error?: string | boolean
  isValid?: boolean
  isWarning?: boolean
  isAlert?: boolean
  containerClassName?: string
  className?: string
  fancyInput?: string
  customBackground?: string
  isFancyPaper?: boolean
  orientation?: 'vertical' | 'horizontal'
  options?: string[]
  optionType?: string
  sortOptions?: boolean
  form?: any
  disableOptions?: string[]
  tooltip?: string
  infotip?: string
  description?: string
  size?: any
  additionalComponent?: ReactElement
  message?: any
  children?: ReactElement
  helperText?: string | boolean
  gridSize?: GridSize
  combineWith?: string[]
  isPartOfCombination?: boolean
  mode?: string
  state?: any
  stateMsg?: any
  disclaimer?: string
  disclaimerValues?: string[]
  isAllowed?: (values: any) => boolean
  isLoading?: boolean
  hasNestedError?: boolean
}

export const setBorderRadius = () => {
  return 'var(--border-radius)'
}

const useStyles = makeStyles<{
  isValid
  isWarning
  isAlert
  isLoading
  error
  name
  type
  customBackground
}>()((theme, { isValid, isWarning, isAlert, isLoading, error, name, type }) => {
  return {
    adornmentRoot: {
      paddingTop: '10px'
    },
    root: {
      color: 'var(--light-text-1)',
      width: '100%'
    },
    label: {
      color: getStatusColor(
        { isValid, isWarning, isAlert, error, isLoading },
        'var(--light-text-3)'
      ),
      '&.Mui-focused': {
        color: getStatusColor(
          { isValid, isWarning, isAlert, error, isLoading },
          'var(--light-text-2)'
        )
      },
      '&.Mui-error': {
        color: 'var(--light-text-3)'
      },
      '&.Mui-disabled': {
        color: 'var(--light-text-3)'
      },
      '&.MuiInputLabel-shrink': {
        letterSpacing: 'var(--letter-spacing)',
        color: getStatusColor(
          { isValid, isWarning, isAlert, error, isLoading },
          'var(--light-text-2)'
        )
      }
    },
    customFilledInput: {
      color: 'var(--light-text-1)',
      border: '1px solid',
      borderColor: getStatusColor({
        isValid,
        isWarning,
        isAlert,
        error,
        isLoading
      }),
      height: '56px',
      borderRadius: 'var(--border-radius)',
      backgroundColor: 'var(--surface-0-color)',
      '&.Mui-focused, &:hover': {
        backgroundColor: 'var(--surface-0-color)'
      },
      '&.Mui-disabled': {
        backgroundColor: 'var(--neutral-95-color)'
      },
      '&.Mui-error': {
        border: '1px solid var(--danger-color)',
        backgroundColor: 'var(--danger-color-background-input)'
      },
      '& input': {
        borderRadius: 'var(--border-radius)'
      },
      '& input:-webkit-autofill, &:has(> input:-webkit-autofill)': {
        boxShadow: `0 0 0 100px ${
          error
            ? 'var(--danger-color-background-input)'
            : 'var(--surface-0-color)'
        } inset`,
        backgroundColor: error
          ? 'var(--danger-color-background-input)'
          : 'var(--surface-0-color)',
        WebkitTextFillColor: 'var(--light-text-1)',
        caretColor: 'var(--light-text-1)'
      },
      '& input:-moz-autofill, &:has(> input:-webkit-autofill)': {
        backgroundColor: error
          ? 'var(--danger-color-background-input)'
          : 'var(--surface-0-color)',
        boxShadow: `0 0 0 100px ${
          error
            ? 'var(--danger-color-background-input)'
            : 'var(--surface-0-color)'
        } inset`,
        WebkitTextFillColor: 'var(--light-text-1)',
        caretColor: 'var(--light-text-1)'
      },
      '& input:autofill': {
        backgroundColor: error
          ? 'var(--danger-color-background-input)'
          : 'var(--surface-0-color)',
        boxShadow: `0 0 0 100px ${
          error
            ? 'var(--danger-color-background-input)'
            : 'var(--surface-0-color)'
        } inset`,
        WebkitTextFillColor: 'var(--light-text-1)',
        caretColor: 'var(--light-text-1)'
      }
    },
    customNoLabelInput: {
      padding: '12px 10px',
      color: 'var(--light-text-1)',
      border: '1px solid',
      borderColor: getStatusColor({
        isValid,
        isWarning,
        isAlert,
        error,
        isLoading
      }),
      borderRadius: setBorderRadius(),
      backgroundColor: 'var(--surface-0-color)',
      '&.Mui-focused, &:hover': {
        backgroundColor: 'var(--surface-0-color)'
      },
      '&.Mui-error': {
        border: '1px solid var(--danger-color)'
      },
      '& input:-webkit-autofill': {
        boxShadow: '0 0 0 100px inset'
      }
    },
    customNoLabelNumber: {
      '& .MuiFilledInput-input': {
        padding: '0'
      },
      padding: 'var(--padding-4) var(--padding-3)',
      height: '56px',
      color: 'var(--light-text-1)',
      border: 'solid',
      borderWidth: getNumberTypeBorder({ type }),
      borderColor: getStatusColor({
        isValid,
        isWarning,
        isAlert,
        error,
        isLoading
      }),
      borderRadius: setBorderRadius(),
      backgroundColor: 'var(--surface-0-color)',
      '&.Mui-focused, &:hover': {
        backgroundColor: 'var(--surface-0-color)'
      },
      '&.Mui-error': {
        border: '1px solid var(--danger-color)'
      },
      '& input:-webkit-autofill': {
        boxShadow: '0 0 0 100px inset'
      }
    },
    customTagInput: {
      padding: 'var(--spacing-3)',
      height: getCustomTagInputHeight({ type }),
      color: 'var(--light-text-1)',
      border: '1px solid',
      borderColor: `${getStatusColor({
        isValid,
        isWarning,
        isAlert,
        error,
        isLoading
      })}`,
      borderRadius: 'var(--border-radius)',
      backgroundColor: 'var(--surface-0-color)',
      '.MuiInputBase-input': {
        height: '100%',
        padding: 'unset'
      },
      '&.Mui-focused, &:hover': {
        backgroundColor: 'var(--surface-0-color)'
      },
      '&.Mui-error': {
        border: '1px solid var(--danger-color)'
      },
      '& input::placeholder': {
        color: 'var(--light-text-3)',
        opacity: 1
      },
      '& input:-webkit-autofill': {
        boxShadow: '0 0 0 100px rgba(0,0,0,0.8) inset'
      },
      '& input::-moz-autofill': {
        boxShadow: '0 0 0 100px rgba(0,0,0,0.8) inset'
      },
      '& input:autofill': {
        boxShadow: '0 0 0 100px rgba(0,0,0,0.8) inset'
      }
    },
    customSearchInput: {
      padding: 'var(--padding-3)'
    },
    searchInput: {
      padding: 'unset',
      height: 'var(--height-standard)'
    }
  }
})

function CustomTextField({
  type,
  label,
  name,
  placeholder,
  field,
  onClick,
  onKeyUp,
  disabled,
  error,
  isValid,
  isWarning,
  isAlert,
  isLoading,
  helperText,
  customBackground,
  mode,
  ...theRestProps
}: Partial<InputProps>): ReactElement {
  const { classes } = useStyles({
    isValid,
    isWarning,
    isAlert,
    isLoading,
    error,
    name,
    type,
    customBackground: customBackground || ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const inputName = name || field.name
  const isNotchedOutlineMode = mode === NOTCHED_OUTLINE

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword)
  }

  const handleMouseDownPassword = (event: any) => {
    event.preventDefault()
  }

  const handleSearchKeyUp = (event) => {
    if (event.keyCode === 13) {
      event.preventDefault()
      return
    }
    onKeyUp && onKeyUp(event)
  }

  const renderInputByType = () => {
    switch (type) {
      case 'search':
        return (
          <>
            {label && (
              <InputLabel
                htmlFor={'filled-adornment-' + inputName}
                classes={{
                  root: classes.label
                }}
                error={!!error}
                {...field}
              >
                {label}
              </InputLabel>
            )}
            <FilledInput
              id={'filled-adornment-' + inputName}
              type="text"
              placeholder={placeholder}
              disableUnderline
              classes={{
                root: `${classes.customFilledInput} ${classes.customSearchInput}`,
                input: !label && classes.searchInput
              }}
              onKeyUp={(e) => handleSearchKeyUp(e)}
              startAdornment={
                <InputAdornment
                  position="start"
                  variant={label ? 'filled' : 'standard'}
                >
                  <MagnifyingGlass
                    className={`iconSizeMedium ${styles.searchIcon} ${
                      label && styles.extraMargin
                    }`}
                    onClick={onClick}
                  />
                </InputAdornment>
              }
              error={!!error}
              {...theRestProps}
              {...field}
            />
          </>
        )
      case 'number':
        return (
          <TextField
            fullWidth
            InputLabelProps={{
              classes: {
                root: classes.label
              },
              shrink: true
            }}
            inputProps={{
              min: 0
            }}
            InputProps={{
              classes: {
                root: classes.customNoLabelNumber
              },
              disableUnderline: true
            }}
            onInput={(e: ChangeEvent<HTMLInputElement>) => {
              e.target.value = sanitiseNumber(
                e.target.value,
                theRestProps?.decimal
              )
            }}
            type="text"
            label={label}
            variant="filled"
            placeholder={placeholder || (typeof label === 'string' && label)}
            disabled={disabled}
            error={!!error}
            {...theRestProps}
            {...field}
          />
        )
      case 'price':
        return (
          <NumberFormat
            fullWidth
            customInput={TextField}
            thousandSeparator
            allowNegative={false}
            InputLabelProps={{
              classes: {
                root: classes.label
              },
              shrink: true
            }}
            InputProps={{
              classes: {
                root: classes.customNoLabelNumber
              },
              disableUnderline: true
            }}
            type="text"
            label={label}
            variant="filled"
            placeholder={placeholder || (typeof label === 'string' && label)}
            disabled={disabled}
            error={!!error}
            {...theRestProps}
            {...field}
          />
        )
      case 'text':
      case 'captcha':
      case 'email':
        return (
          <div
            data-testid="text"
            className={
              isNotchedOutlineMode ? styles.notchedOutlineContainer : ''
            }
          >
            <TextField
              fullWidth
              InputLabelProps={{
                classes: {
                  root: `${classes.label} ${styles.label}`,
                  focused: styles.labelFocused
                },
                required: false
              }}
              InputProps={{
                classes: {
                  root: `${classes.customFilledInput} ${styles.inputRoot} ${
                    type === 'captcha' ? styles.captcha : ''
                  }`,
                  input: styles.inputInput
                },
                disableUnderline: true
              }}
              variant={isNotchedOutlineMode ? 'standard' : 'filled'}
              label={label}
              placeholder={placeholder}
              disabled={disabled}
              error={!!error}
              {...theRestProps}
              {...field}
            />
          </div>
        )
      case 'password':
        return (
          <>
            {label && (
              <InputLabel
                htmlFor={'filled-adornment-' + inputName}
                classes={{
                  root: classes.label
                }}
                error={!!error}
              >
                {label}
              </InputLabel>
            )}
            <FilledInput
              id={'filled-adornment-' + inputName}
              type={showPassword ? 'text' : 'password'}
              onKeyUp={onKeyUp}
              disableUnderline
              classes={{
                root: classes.customFilledInput,
                input: styles.inputInput
              }}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    className={styles.passwordIconLabel}
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    disableRipple
                  >
                    {showPassword ? (
                      <Visibility className={styles.password} />
                    ) : (
                      <VisibilityOff className={styles.password} />
                    )}
                  </IconButton>
                </InputAdornment>
              }
              error={!!error}
              {...theRestProps}
              {...field}
            />
          </>
        )

      case 'nolabel':
        return (
          <TextField
            data-testid="nolabel"
            fullWidth
            InputLabelProps={{
              classes: {
                root: classes.label
              },
              shrink: false
            }}
            InputProps={{
              classes: {
                root: classes.customNoLabelInput
              },
              disableUnderline: true
            }}
            multiline
            variant="filled"
            placeholder={typeof label === 'string' && label}
            disabled={disabled}
            error={!!error}
            {...theRestProps}
            {...field}
          />
        )
      case 'tags':
      case 'optionsTags':
        return (
          <>
            <TextField
              data-testid="tags"
              id={name}
              name={name}
              fullWidth
              InputLabelProps={{
                classes: {
                  root: classes.label
                },
                shrink: false
              }}
              InputProps={{
                className: styles.scrollableOption,
                classes: {
                  root: classes.customTagInput
                },
                disableUnderline: true,
                inputComponent: InputTag,
                inputProps: { component: ChipInput }
              }}
              multiline
              variant="filled"
              placeholder={placeholder}
              disabled={disabled}
              error={!!error}
              {...theRestProps}
              {...field}
            />
            {error && <HelperMessage message={error} isAlert={!!error} />}
          </>
        )
      default:
        return (
          <TextField
            data-testid="default"
            fullWidth
            InputLabelProps={{
              classes: {
                root: classes.label
              }
            }}
            InputProps={{
              classes: {
                root: classes.customFilledInput
              },
              disableUnderline: true
            }}
            variant="filled"
            label={label}
            disabled={disabled}
            error={!!error}
            {...theRestProps}
            {...field}
          />
        )
    }
  }

  return (
    <FormControl
      fullWidth
      className={styles.textField}
      variant="filled"
      disabled={disabled}
      data-testid="form-control"
    >
      {renderInputByType()}

      {helperText && (
        <HelperMessage
          message={helperText || error}
          isValid={isValid}
          isWarning={isWarning}
          isAlert={!!error || isAlert}
          data-testid="form-control-helper"
        />
      )}
    </FormControl>
  )
}

export default CustomTextField
