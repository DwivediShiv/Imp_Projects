import React, { ReactElement } from 'react'
import styles from './index.module.css'
import { LinearProgress } from '@mui/material'

export interface LoaderProps {
  progress?: number
  message?: string
  white?: boolean
  isCenter?: boolean
  customStyle?: string
}

export default function Loader({
  progress,
  message,
  white,
  isCenter,
  customStyle
}: LoaderProps): ReactElement {
  return (
    <>
      {progress ? (
        <div
          data-testid="loader-progress"
          className={`${styles.loaderWrap} ${isCenter && styles.center}  ${
            customStyle || ''
          }`}
        >
          {message && <span className={styles.message}>{message}</span>}
          <LinearProgress variant="determinate" value={progress} />
          {`${Math.round(progress)}%`}
        </div>
      ) : (
        <div
          data-testid="loader-wrap"
          className={`${styles.loaderWrap} ${isCenter && styles.center}  ${
            customStyle || ''
          }`}
        >
          <span className={`${styles.loader} ${white ? styles.white : ''}`} />
          {message && <span className={styles.message}>{message}</span>}
        </div>
      )}
    </>
  )
}
