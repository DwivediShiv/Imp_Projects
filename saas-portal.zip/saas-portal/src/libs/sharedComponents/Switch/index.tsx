import React, { ReactElement } from 'react'
import { Switch, FormControlLabel } from '@mui/material'
import styles from './index.module.css'

export default function CustomSwitch({ label, ...fancyProps }): ReactElement {
  return (
    <>
      <FormControlLabel
        className={styles.label}
        control={
          <Switch
            checked={fancyProps.value || false}
            color="primary"
            {...fancyProps}
            title=""
            className={styles.switch}
          />
        }
        label={label}
        {...fancyProps}
      />
    </>
  )
}
