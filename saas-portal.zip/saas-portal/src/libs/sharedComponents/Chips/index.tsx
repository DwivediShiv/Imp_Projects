import { Chip } from '@mui/material'
import React, { ReactElement } from 'react'
import styles from './index.module.css'
import DeleteIconPrimary from '@images/blue_cross.svg'
import DeleteIconDefault from '@images/cross_default.svg'
import classNames from 'classnames'

type ChipsProps = {
  label?: string
  size?: 'medium' | 'small'
  handleDelete?: React.EventHandler<any>
  isDisabled?: boolean
  color?: 'default' | 'primary' | 'disabled'
  type?: 'label' | 'input'
  className?: string
}

function CustomChips({
  label,
  size,
  handleDelete,
  color,
  className,
  type = 'input',
  isDisabled = false
}: ChipsProps): ReactElement {
  const isDefault = color === 'default'

  const cx = classNames.bind(styles)
  const stylesClasses = cx({
    [className]: className
  })

  let props

  if (type !== 'label') {
    props = {
      onDelete: handleDelete,
      deleteIcon: isDefault ? <DeleteIconDefault /> : <DeleteIconPrimary />
    }
  } else {
    isDisabled = true
  }

  props = {
    ...props,
    ...{
      size,
      label,
      className: `${stylesClasses} ${styles.chips} ${styles[color]} ${
        isDisabled ? styles.disabled : ''
      }`
    }
  }

  return <Chip {...props} />
}

export default CustomChips
