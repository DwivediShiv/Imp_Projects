import { ReactElement, ReactNode } from 'react'
import { Tab, Tabs as TabsList } from '@mui/material'
import styles from './index.module.css'
import * as React from 'react'
import Indicator from '../Indicator'

export interface TabsItem {
  title: string
  content?: ReactNode
  disabled?: boolean
  index: number
  icon?: 'default' | 'success' | 'danger' | 'warning' | 'disabled'
}

export interface TabsProps {
  items: TabsItem[]
  className?: string
  handleTabChange?: (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => void
  defaultIndex?: number
  showRadio?: boolean
}

export default function Tabs({
  items: tabs,
  className = 'tabsRoot',
  handleTabChange,
  defaultIndex: tabIndex
}: TabsProps): ReactElement {
  return (
    <TabsList
      value={tabIndex}
      indicatorColor="primary"
      textColor="primary"
      classes={{ root: styles[className], indicator: styles.tabsIndicator }}
      onChange={handleTabChange}
      sx={{
        minHeight: 'var(--tab-height)',
        height: 'var(--tab-height)'
      }}
    >
      {tabs &&
        tabs.map((option) => {
          const { title, index, icon } = option
          return (
            <Tab
              label={title}
              key={title}
              classes={{ root: styles.sectionTitle }}
              TouchRippleProps={{ classes: { root: styles.ripple } }}
              id={`edit-advance-tabpanel-${index}`}
              aria-labelledby={`edit-advance-tabs-${index}`}
              sx={{
                minHeight: 'var(--tab-height)',
                height: 'var(--tab-height)'
              }}
              icon={icon ? <Indicator type="dot" variant={icon} /> : ''}
              iconPosition="start"
              disableRipple
            ></Tab>
          )
        })}
    </TabsList>
  )
}
