import React, {
  ReactElement,
  ReactNode,
  FormEvent,
  ChangeEvent,
  KeyboardEvent
} from 'react'
import { ErrorMessage } from 'formik'
import styles from './index.module.css'
import { FormFieldProps } from '@libs/types/Form'
import CustomCheckbox from '../Checkbox'
import CustomTextField from '../TextField'
import Textarea from '../TextArea'
import CommonRadioButton from '../CommonRadioButton'

export interface InputProps {
  name: string
  label?: string | ReactNode
  placeholder?: string
  required?: boolean
  help?: string
  tag?: string
  type?: string
  options?: string[]
  optionType?: string
  optionCategory?: string
  sortOptions?: boolean
  additionalComponent?: ReactElement
  additionalLabelComponent?: ReactElement
  value?: string
  onChange?(
    event:
      | FormEvent<HTMLInputElement | HTMLTextAreaElement>
      | ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
      | ChangeEvent<HTMLSelectElement>
      | ChangeEvent<HTMLTextAreaElement>,
    value?: any
  ): void
  onKeyUp?(e: KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>): void
  onClick?: (e: FormEvent) => void
  rows?: number
  multiple?: boolean
  pattern?: string
  min?: string
  max?: string
  disabled?: boolean
  readOnly?: boolean
  field?: FormFieldProps
  form?: any
  prefix?: string | ReactElement
  postfix?: string | ReactElement
  step?: string
  defaultChecked?: boolean
  message?: any
  isWarning?: boolean
  isAlert?: boolean
  size?: 'mini' | 'small' | 'large' | 'default'
  fancyInput?: string
  customBackground?: string
  onBlur?: (e: React.SyntheticEvent) => void
  isIndeterminate?: boolean
  addonInput?: FormFieldProps
  className?: string
  isResizable?: boolean
  mode?: string
  excludedValid?: boolean
  isLoading?: boolean
  multipleLineDesc?: boolean
  showFlag?: boolean
  sendCountryName?: boolean
}

export default function InputField(props: Partial<InputProps>): ReactElement {
  const {
    label,
    type,
    help,
    additionalComponent,
    additionalLabelComponent,
    name,
    field,
    placeholder,
    prefix,
    onClick,
    onKeyUp,
    fancyInput,
    customBackground,
    options,
    optionType,
    optionCategory,
    message,
    isWarning,
    isAlert,
    addonInput,
    disabled,
    isResizable,
    excludedValid,
    mode,
    multipleLineDesc,
    showFlag,
    sendCountryName,
    ...fancyProps
  } = props
  const inputName = name || field?.name
  const hasError =
    props?.form?.touched[inputName] && props?.form?.errors[inputName]
  const isValid =
    props?.form?.touched[inputName] &&
    props?.form?.values[inputName] &&
    !hasError
  const successMessage =
    isValid && message?.success !== undefined && message.success
  const warningMessage =
    isWarning || (message?.warning !== undefined && message.warning)
  const infoMessage = message?.info !== undefined && message.info

  function extraContainerClass(): string {
    return type === 'fancyAssetSelectionMultiple' ? styles.noMargin : ''
  }

  const renderInput = () => {
    switch (type) {
      case 'text':
      case 'email':
      case 'password':
      case 'search':
      case 'captcha':
        return (
          <CustomTextField
            type={type}
            label={label}
            name={name}
            placeholder={placeholder}
            onKeyUp={onKeyUp}
            field={field}
            isWarning={!!warningMessage}
            isValid={!excludedValid && !!isValid}
            isAlert={isAlert}
            error={hasError}
            disabled={disabled}
            fancyInput={fancyInput}
            customBackground={customBackground || ''}
            helperText={
              hasError ? (
                <ErrorMessage name={inputName} />
              ) : (
                successMessage || warningMessage || infoMessage
              )
            }
            mode={mode}
            {...fancyProps}
          />
        )
      // case 'select':
      //   return (
      //     <CustomDropDown
      //       label={label}
      //       placeholder={placeholder}
      //       inputName={inputName}
      //       options={options as any}
      //       optionCategory={optionCategory}
      //       error={hasError}
      //       isValid={!excludedValid && !!isValid}
      //       disabled={disabled}
      //       customBackground={customBackground || ''}
      //       helperText={
      //         hasError ? (
      //           <ErrorMessage name={inputName} />
      //         ) : (
      //           successMessage || warningMessage || infoMessage
      //         )
      //       }
      //       mode={mode}
      //       {...field}
      //     />
      //   )
      // case 'countryList':
      //   return (
      //     <>
      //       <CustomDropDown
      //         label={label}
      //         inputName={inputName}
      //         options={options as any}
      //         error={hasError}
      //         isValid={!!isValid}
      //         MenuListComponent={CountryMenuList({
      //           showFlag,
      //           optionCategory,
      //           sendCountryName
      //         })}
      //         customBackground={customBackground || ''}
      //         helperText={
      //           hasError ? (
      //             <ErrorMessage name={inputName} />
      //           ) : (
      //             successMessage || warningMessage || infoMessage
      //           )
      //         }
      //         value={props?.value}
      //         placeholder={placeholder}
      //         onChange={props?.onChange}
      //         mode={mode}
      //         showFlag={showFlag}
      //         optionCategory={optionCategory}
      //         {...field}
      //       />
      //       {addonInput && (
      //         <>
      //           <div className={styles.extraPadding_3} />
      //           <Field
      //             key={addonInput.name}
      //             {...addonInput}
      //             component={InputField}
      //             additionalLabelComponent={
      //               <div className={styles.extraPadding}>
      //                 {addonInput.extraLabel}
      //               </div>
      //             }
      //           />
      //         </>
      //       )}
      //     </>
      //   )
      // case 'fancyFiles':
      //   return (
      //     <FancyFileInput
      //       {...field}
      //       {...props}
      //       name={name}
      //       error={hasError}
      //       isWarning={isWarning}
      //       placeholder={placeholder}
      //       onChange={props?.onChange}
      //       onBlur={props?.onBlur}
      //       disabled={disabled}
      //       isValid={isValid}
      //       additionalComponent={additionalComponent}
      //       {...fancyProps}
      //     />
      //   )
      // case 'fancySampleFiles':
      //   return (
      //     <FancySampleFilesInput
      //       name={name}
      //       key={name}
      //       error={hasError}
      //       isValid={isValid}
      //       isWarning={!!warningMessage}
      //       {...field}
      //       {...props}
      //     />
      //   )
      // case 'fancyEulaFiles':
      //   return (
      //     <FancyEulaFilesInput
      //       {...field}
      //       {...props}
      //       name={name}
      //       error={hasError}
      //       isValid={isValid}
      //       isWarning={!!warningMessage}
      //       placeholder={placeholder}
      //       onChange={props?.onChange}
      //       onBlur={props?.onBlur}
      //       disabled={disabled}
      //     />
      //   )
      // case 'fancyCustomDockerImage':
      //   return (
      //     <FancyCustomDockerInput
      //       {...field}
      //       {...props}
      //       name={name}
      //       error={hasError}
      //       isWarning={!!warningMessage}
      //       placeholder={placeholder}
      //       onChange={props?.onChange}
      //       onBlur={props?.onBlur}
      //       disabled={disabled}
      //     />
      //   )
      // case 'fancyDatasetFiles':
      //   return (
      //     <FancyAssetFileInput
      //       name={name}
      //       key={name}
      //       error={hasError}
      //       isValid={isValid}
      //       isWarning={!!warningMessage}
      //       onChange={props?.onChange}
      //       onBlur={props?.onBlur}
      //       {...field}
      //       {...props}
      //       disabled={disabled}
      //     />
      //   )
      case 'radioButton':
        return (
          <CommonRadioButton
            label={label}
            name={inputName}
            options={options}
            optionType={optionType}
            multipleLineDesc={multipleLineDesc}
            {...field}
          />
        )
      case 'customCheckbox':
      case 'checkbox':
        return (
          <CustomCheckbox
            label={label}
            name={inputName}
            type="checkbox"
            {...field}
            {...props}
            options={options || (field?.options as any)}
          />
        )
      case 'textarea':
        return (
          <>
            {label && <div className={styles.textareaLabel}>{label}</div>}
            <Textarea
              name={inputName}
              error={hasError}
              isValid={!excludedValid && !!isValid}
              isResizable={isResizable}
              customBackground={customBackground || ''}
              {...field}
              {...props}
            />
          </>
        )
    }
  }

  return (
    <div
      className={`${
        type !== 'checkbox' && styles.textFieldContainer
      } ${extraContainerClass()} ${styles[fancyInput || '']} ${
        props?.className || ''
      }`}
      data-is-submitting={props?.form?.isSubmitting ? true : null}
    >
      {additionalLabelComponent && additionalLabelComponent}
      {renderInput()}

      {additionalComponent && additionalComponent}
    </div>
  )
}
