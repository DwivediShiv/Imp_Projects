import {
  Paper,
  TableBody,
  TableCell,
  TableRow,
  Table,
  Divider
} from '@mui/material'
import React, { useState } from 'react'
import { Field, Form, Formik } from 'formik'
import classNames from 'classnames'
import styles from './index.module.css'
import CustomButton from '../Button'
import InputField from '../InputField'
import { CardConfig, TableInfo } from './types/GridCardTypes'

const GridCard = ({
  cardConfig,
  data,
  setStateData,
  validationSchema
}: {
  cardConfig: CardConfig
  data: object
  setStateData?: (data: boolean) => void
  validationSchema?
}) => {
  const [isEditActive, setIsEditActive] = useState<boolean>(false)

  function table(
    field: TableInfo,
    index: number,
    setFieldValue,
    handleBlur,
    setFieldError,
    errors,
    dirty,
    values
  ) {
    if (!field) return null
    return (
      <TableRow
        key={index}
        classes={{
          root: styles.tableRowRoot
        }}
      >
        <TableCell
          align="left"
          size="small"
          classes={{ root: styles.nameCell }}
        >
          <p
            className={classNames(styles.subtitle, {
              [styles.subtitleOnEdit]:
                isEditActive &&
                (field.editActiveType !== 'custom' || !field.editActiveType)
            })}
          >
            {field.previewTitle}
          </p>
        </TableCell>
        <TableCell align="left" classes={{ root: styles.valueCell }}>
          {isEditActive
            ? (() => {
                switch (field.editActiveType) {
                  case 'custom':
                    return (
                      <Field
                        name={field.name}
                        component={field.getComponent}
                        className={styles.inputbox}
                        isEditActive
                        data={data}
                        setFieldValue={setFieldValue}
                        setFieldError={setFieldError}
                        handleBlur={handleBlur}
                        dirty={dirty}
                        values={values}
                        errors={errors}
                      />
                    )
                  case 'input':
                    return (
                      <Field
                        {...field}
                        component={InputField}
                        type="text"
                        className={
                          field.disabled
                            ? styles.fieldDisabled
                            : styles.inputField
                        }
                      />
                    )
                  default:
                    return field.getValue(data, isEditActive)
                }
              })()
            : field.getValue(data, isEditActive, setStateData)}
        </TableCell>
      </TableRow>
    )
  }
  function cancelEdit() {
    setIsEditActive(false)
  }
  return (
    <Formik
      initialValues={
        cardConfig.getDefaultValues ? cardConfig.getDefaultValues(data) : {}
      }
      onSubmit={(values, { resetForm }) => {
        console.log(values)
        resetForm()
      }}
      validationSchema={validationSchema}
      enableReinitialize
    >
      {({
        errors,
        dirty,
        values,
        resetForm,
        setFieldValue,
        handleBlur,
        setFieldError
      }) => (
        <Form className={styles.form}>
          <Paper classes={{ root: styles.boxPaper }}>
            <div className={styles.actionWrapper}>
              <div className={styles.header}>
                <div className={styles.title}>
                  <h4 className="bold">{cardConfig.title}</h4>
                </div>
                {cardConfig.isEditable && (
                  <div className={styles.actions}>
                    {isEditActive ? (
                      <div className={styles.editActions}>
                        <CustomButton
                          buttonType="link"
                          color="primary"
                          className={styles.actionButton}
                          onClick={() => {
                            cancelEdit()
                            resetForm()
                          }}
                        >
                          Cancel
                        </CustomButton>
                        <Divider
                          orientation="vertical"
                          flexItem
                          variant="fullWidth"
                          className={styles.divider}
                        />

                        <CustomButton
                          buttonType="link"
                          color="primary"
                          className={styles.actionButton}
                          processingLoader={true}
                          disabled={
                            cardConfig.saveDisable
                              ? cardConfig.saveDisable(values, dirty, errors)
                              : !dirty ||
                                Object.getOwnPropertyNames(errors).length > 0
                          }
                          onClick={async () => {
                            console.log(errors)
                            await cardConfig.onSave(
                              values,
                              data,
                              setStateData,
                              setIsEditActive
                            )
                          }}
                        >
                          Save Changes
                        </CustomButton>
                      </div>
                    ) : (
                      <CustomButton
                        buttonType="link"
                        color="primary"
                        className={styles.actionButton}
                        onClick={() => {
                          setIsEditActive(true)
                          resetForm()
                        }}
                      >
                        Edit
                      </CustomButton>
                    )}
                  </div>
                )}
              </div>
              {cardConfig.cardType === 'custom_component' &&
              cardConfig.componentName ? (
                <Field
                  name={cardConfig.componentName}
                  component={cardConfig.getComponent}
                  // className={styles.inputbox}
                  isEditActive={isEditActive}
                  data={data}
                />
              ) : (
                <div className={styles.tableBody}>
                  <Table className={styles.table}>
                    <TableBody>
                      {cardConfig.fields?.map((field, index) =>
                        table(
                          field,
                          index,
                          setFieldValue,
                          handleBlur,
                          setFieldError,
                          errors,
                          dirty,
                          values
                        )
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </Paper>
        </Form>
      )}
    </Formik>
  )
}

export default GridCard
