import { ReactElement } from 'react'

export interface TableInfo {
  type: string
  getComponent?: any
  name: string
  previewTitle: string
  getValue: (
    data: object,
    isEditActive?: boolean,
    setStateData?: (data: boolean) => void
  ) => string | ReactElement | number
  editActiveType?: string
  disabled?: boolean
}
export interface CardConfig {
  getComponent?(data: object): React.ReactNode
  cardType?: string
  title: string
  isEditable?: boolean
  getDefaultValues?: (data: object) => object
  getLogo?: () => React.ReactNode
  componentName?: string
  fields?: TableInfo[]
  onSave?: (
    values: object,
    data?: object,
    setStateData?: (data: boolean) => void,
    setIsEditActive?: (data: boolean) => void
  ) => any
  saveDisable?: (values: object, dirty: boolean, errors: object) => boolean
}
