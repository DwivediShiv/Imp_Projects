import React, { useEffect, useState } from 'react'
import { Button as MuiButton } from '@mui/material'
import styles from './index.module.css'
import { stubFalse } from 'lodash'
import Loader from '../Loader'

const secondsInterval = 5000 // 5 seconds

export default function CustomButton({ children, ...props }) {
  const { processingLoader, ...restProps } = props
  const loader = processingLoader || stubFalse()
  const [isProcessing, setIsProcessing] = useState<boolean>(false)

  useEffect(() => {
    isProcessing && setTimeout(() => setIsProcessing(false), secondsInterval)
  }, [isProcessing])

  async function handleOnClick(e: any) {
    loader && setIsProcessing(true)
    props?.onClick && (await props.onClick(e))
    loader && setIsProcessing(false)
  }

  return isProcessing ? (
    <Loader />
  ) : (
    <MuiButton
      className={props.className}
      data-testid="button"
      classes={{
        root: styles.root,
        outlinedPrimary: styles.outlinedPrimary,
        containedPrimary: styles.containedPrimary,
        containedSecondary: styles.containedSecondary,
        outlinedSecondary:
          props.outlineType === 'warning'
            ? styles.outlinedSecondaryWarning
            : styles.outlinedSecondary,
        text: styles.text,
        textPrimary: styles.textPrimary,
        textSecondary: styles.textSecondary,
        textError: styles.textError,
        outlinedError: styles.outlinedError
      }}
      {...restProps}
      onClick={handleOnClick}
      disableRipple
    >
      {children}
    </MuiButton>
  )
}
