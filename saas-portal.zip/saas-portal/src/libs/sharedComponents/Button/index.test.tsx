// /* eslint-disable testing-library/no-unnecessary-act */
import React from 'react'
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react'
import Button from './index'

describe('Button', () => {
  beforeEach(() => {
    jest.useFakeTimers()
  })

  afterEach(() => {
    jest.useRealTimers()
  })

  it('should render the button with correct text', () => {
    const buttonText = 'Click me'
    render(<Button>{buttonText}</Button>)
    expect(screen.getByText(buttonText)).toBeInTheDocument()
  })

  it('should call the onClick handler when clicked', async () => {
    const handleClick = jest.fn()
    render(<Button onClick={handleClick}>Click me</Button>)
    fireEvent.click(screen.getByTestId('button'))
    await waitFor(() => expect(handleClick).toHaveBeenCalled())
  })

  it('should display the processing loader when clicked and processingLoader is true', async () => {
    const handleClick = jest.fn()
    render(
      <Button onClick={handleClick} processingLoader={true}>
        Click me
      </Button>
    )
    fireEvent.click(screen.getByTestId('button'))
    expect(screen.getByTestId('loader-wrap')).toBeInTheDocument()
    await act(async () => {
      jest.advanceTimersByTime(5000)
    })
    expect(handleClick).toHaveBeenCalled()
    expect(screen.getByTestId('button')).toBeInTheDocument()
  })

  it('should hide the loading indicator after 5 seconds', async () => {
    const buttonText = 'Click me'
    const handleClick = jest.fn()

    render(
      <Button onClick={handleClick} processingLoader>
        {buttonText}
      </Button>
    )

    fireEvent.click(screen.getByTestId('button'))
    expect(screen.getByTestId('loader-wrap')).toBeInTheDocument()
    await waitFor(() =>
      expect(screen.queryByTestId('loader-wrap')).not.toBeInTheDocument()
    )
    expect(screen.getByText(buttonText)).toBeInTheDocument()
  })
})
