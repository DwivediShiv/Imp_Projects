import React, {
  useEffect,
  useState,
  ReactElement,
  createContext,
  useContext,
  ReactNode
} from 'react'
import { getSelectionOptions } from '@utils/fancySelectionOption/index'
import { SelectionOption } from '@libs/types/SelectionOptions'

interface FancyStateValue {
  selectionOptions: any
  getSelectionOptionsByCategory: (category?: string) => SelectionOption[]
}

const FancyStateContext = createContext({} as FancyStateValue)

function FancyStateProvider({
  children
}: {
  children: ReactNode
}): ReactElement {
  const [selectionOptions, setSelectionOptions] = useState([])
  function getSelectionOptionsByCategory(category?: string): SelectionOption[] {
    if (!category) return selectionOptions
    return (
      selectionOptions?.filter((option: any) => option.category === category) ??
      []
    )
  }

  useEffect(() => {
    let attempt = 0
    const maxAttempt = 3

    async function getSelectOptions() {
      try {
        const response = await getSelectionOptions()
        setSelectionOptions(response)
      } catch (err: any) {
        if (attempt < maxAttempt) {
          attempt++
          getSelectOptions()
        }
      }
    }

    getSelectOptions()
  }, [])

  return (
    <FancyStateContext.Provider
      value={{
        selectionOptions,
        getSelectionOptionsByCategory
      }}
    >
      {children}
    </FancyStateContext.Provider>
  )
}

function useFancyState(): FancyStateValue {
  return useContext(FancyStateContext)
}

export { useFancyState }
export default FancyStateProvider
