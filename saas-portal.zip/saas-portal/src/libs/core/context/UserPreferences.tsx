import React, {
  createContext,
  useContext,
  ReactElement,
  ReactNode,
  useState,
  useEffect
} from 'react'
import {
  isCookieAccepted as getIsCookieAccepted,
  setAcceptCookie
} from '@utils/cookie'
import appConfig from 'app.config'
import { isBrowser } from '@libs/utils'

export interface UserPreferencesValue {
  debug: boolean
  setDebug: (value: boolean) => void
  privacyPolicySlug: string
  setPrivacyPolicySlug: (slug: string) => void
  showPPC: boolean
  setShowPPC: (value: boolean) => void
  infiniteApproval: boolean
  setInfiniteApproval: (value: boolean) => void
  locale: string
  setAcceptCookies?: (value: boolean) => void
  isCookieAccepted?: boolean
  setSideMenuOpen?: (value: boolean) => void
  isSideMenuOpen?: boolean
}

const UserPreferencesContext = createContext(null)

const localStorageKey = 'ocean-user-preferences'

function getLocalStorage(): UserPreferencesValue {
  const storageParsed =
    isBrowser && JSON.parse(window.localStorage.getItem(localStorageKey))
  return storageParsed
}

function setLocalStorage(values: Partial<UserPreferencesValue>) {
  return (
    isBrowser &&
    window.localStorage.setItem(localStorageKey, JSON.stringify(values))
  )
}

function UserPreferencesProvider({
  children
}: {
  children: ReactNode
}): ReactElement {
  const localStorage = getLocalStorage()

  // Set default values from localStorage
  const [debug, setDebug] = useState<boolean>(localStorage?.debug || false)
  const [isCookieAccepted, setIsCookieAccepted] = useState<boolean>(
    getIsCookieAccepted()
  )
  const [isSideMenuOpen, setSideMenuOpen] = useState<boolean>(false)
  const [locale, setLocale] = useState<string>()

  const [privacyPolicySlug, setPrivacyPolicySlug] = useState<string>(
    localStorage?.privacyPolicySlug || appConfig.defaultPrivacyPolicySlug
  )

  const [showPPC, setShowPPC] = useState<boolean>(
    localStorage?.showPPC !== false
  )

  const [infiniteApproval, setInfiniteApproval] = useState(
    localStorage?.infiniteApproval || false
  )

  // Write values to localStorage on change
  useEffect(() => {
    if (getIsCookieAccepted())
      setLocalStorage({
        debug,
        privacyPolicySlug,
        showPPC,
        infiniteApproval
      })
  }, [privacyPolicySlug, showPPC, infiniteApproval])

  // Get locale always from user's browser
  useEffect(() => {
    if (!window) return
    setLocale(window.navigator.language)
  }, [])

  function setAcceptCookies(value = true) {
    setAcceptCookie()
    setIsCookieAccepted(value)
  }

  return (
    <UserPreferencesContext.Provider
      value={
        {
          debug,
          locale,
          privacyPolicySlug,
          showPPC,
          infiniteApproval,
          setInfiniteApproval,
          setDebug,
          setPrivacyPolicySlug,
          setShowPPC,
          setAcceptCookies,
          isCookieAccepted,
          isSideMenuOpen,
          setSideMenuOpen
        } as UserPreferencesValue
      }
    >
      {children}
    </UserPreferencesContext.Provider>
  )
}

// Helper hook to access the provider values
const useUserPreferences = (): UserPreferencesValue =>
  useContext(UserPreferencesContext)

export { UserPreferencesProvider, useUserPreferences }
