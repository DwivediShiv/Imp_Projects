import axios from 'axios'
import appConfig from '../../../app.config'
import { getCurrentAccessToken } from '@utils/auth'

export function applyAxiosInterceptor() {
  axios.interceptors.request.use(
    function (config) {
      if (
        config.url.indexOf('auth/access-token') !== -1 ||
        config.url.indexOf('as/login') !== -1
      ) {
        return config
      }
      const accessToken = getCurrentAccessToken()
      if (
        config.url.indexOf(appConfig.api) !== -1 &&
        accessToken &&
        !config.headers.Authorization
      ) {
        config.headers.Authorization = `Bearer ${accessToken}`
      }
      return config
    },
    function (error) {
      return Promise.reject(error)
    }
  )
  axios.interceptors.response.use(
    function (response) {
      return response
    },
    function (error) {
      return Promise.reject(error)
    }
  )
}
