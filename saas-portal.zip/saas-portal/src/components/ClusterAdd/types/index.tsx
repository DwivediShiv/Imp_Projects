export interface AddClusterFormSchema {
  name: string
  version: string
  region: string
  network: string
  awsAccount: string
}
