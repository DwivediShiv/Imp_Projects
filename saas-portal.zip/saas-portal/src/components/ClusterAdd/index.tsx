import React, { ReactElement } from 'react'
import styles from './index.module.css'
import Container from '@sharedComponents/Container'
import CustomButton from '@sharedComponents/Button'
import CustomModal from '@sharedComponents/Modal'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import CommonForm from '@sharedComponents/Forms/CommonForm'
import { useAddClusterConfig } from './hooks/useAddCluster'

function AddClusterModal({ refreshHandler }): ReactElement {
  const {
    formConfig,
    onToggleModal,
    isOpen,
    setIsOpen,
    handleSubmit,
    validationSchema,
    loading
  } = useAddClusterConfig(refreshHandler)

  const checkDisabled = (dirty, errors, isValid) => {
    return !isValid || !dirty
  }

  return (
    <div>
      <CustomButton
        color="primary"
        variant="contained"
        onClick={() => setIsOpen(true)}
      >
        Create Cluster
      </CustomButton>
      <section className={styles.grid}>
        <CustomModal
          type={CUSTOM_TYPE}
          className={`${styles.textarea} ${styles.fancyTextarea} ${styles.fancyModal} ${styles.checkbox} ${styles.checkboxRoot} ${styles.checkboxChecked} ${styles.checkboxLabel} ${styles.checkBoxArea} ${styles.checkboxContainer}`}
          isOpen={isOpen}
          onToggleModal={onToggleModal}
        >
          <div>
            <Container className={styles.headerContent}>
              <div className={styles.title}>Create Cluster</div>
            </Container>
            <CommonForm
              content={formConfig}
              validationSchema={validationSchema}
              handleSubmit={handleSubmit}
              loading={loading}
              checkDisabled={checkDisabled}
            />
          </div>
        </CustomModal>
      </section>
    </div>
  )
}

export default AddClusterModal
