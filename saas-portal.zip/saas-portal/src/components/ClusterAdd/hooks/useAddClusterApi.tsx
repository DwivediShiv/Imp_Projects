import { ADD_CLUSTER_SUCCESS_MSG, ERROR_MSG } from '@constants/constants'
import { useFancyState } from '@core/context/FancyState'
import appConfig from 'app.config'
import axios from 'axios'
import { useState } from 'react'

const useAddClusterApi = () => {
  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState('')
  const { getSelectionOptionsByCategory } = useFancyState()
  const addClusterUrl = `${appConfig.api}/saas-management/api/v1/saas/management/cluster`
  const addCluster = async (
    data,
    setFieldError: (field: string, errorMsg: string) => void
  ) => {
    try {
      setSuccessMsg('')
      setErrorMsg('')
      const regionOptions = await getSelectionOptionsByCategory('Region')
      const regionKey = regionOptions.filter(
        (region) => region.name === data.region
      )[0]?.key
      data.region = regionKey ?? data.region
      const { data: response } = await axios.post(addClusterUrl, data)
      setSuccessMsg(ADD_CLUSTER_SUCCESS_MSG)
      return response
    } catch (error) {
      setSuccessMsg('')
      const {
        code = '',
        error: { additionalData = '' }
      } = error?.response?.data ?? {}
      if (
        (code === 'ERROR_CLUSTER_NAME_ALREADY_EXISTS' ||
          code === 'ERROR_CLUSTER_NAME_ALREADY_EXISTS_REGION') &&
        additionalData
      ) {
        setFieldError('name', additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        if (Array.isArray(additionalData)) {
          const additionalErrors = Object.values(additionalData)
          setErrorMsg(additionalErrors?.length ? additionalErrors[0] : message)
        } else {
          setErrorMsg(additionalData?.length ? additionalData : message)
        }
      } else {
        setErrorMsg(ERROR_MSG)
      }
    }
  }
  return {
    addCluster,
    successMsg,
    errorMsg
  }
}

export default useAddClusterApi
