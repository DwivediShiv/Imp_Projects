import { useAuthorize } from '@core/context/Authorize'
import { useFancyState } from '@core/context/FancyState'
import CustomDropDown from '@sharedComponents/Dropdown'
import { useCallback, useEffect, useState } from 'react'
import useAddClusterApi from './useAddClusterApi'
import { AddClusterFormSchema } from '../types'
import * as Yup from 'yup'
import Toast from '@sharedComponents/Toast'
import useCreateInstanceApi from '@saasportal/components/InstanceAdd/hooks/useCreateInstanceApi'

export const useAddClusterConfig = (refreshHandler) => {
  const { isLogin } = useAuthorize()
  const { instanceVersions, fetchInstanceVersions } = useCreateInstanceApi()
  const { addCluster, errorMsg, successMsg } = useAddClusterApi()
  const [instanceRegions, setInstanceRegions] = useState([])
  const [awsAccounts, setAwsAccounts] = useState([])
  const [instanceNetworks, setInstanceNetworks] = useState([])
  const [isOpen, setIsOpen] = useState<boolean>(false)
  const [loading, setLoading] = useState<boolean>(false)
  const { getSelectionOptionsByCategory } = useFancyState()

  useEffect(() => {
    if (successMsg) {
      Toast('success', successMsg)
    }
    if (errorMsg) {
      Toast('error', errorMsg)
    }
  }, [successMsg, errorMsg])

  const loadSelectionOptions = async () => {
    const regionOptions = await getSelectionOptionsByCategory('Region')
    const instanceRegionNames = regionOptions.map((option) => {
      return option.name
    })
    const options = await getSelectionOptionsByCategory('AWSAccount')
    const awsAccountNames = options.map((option) => {
      return option.name
    })
    const networkOptions = await getSelectionOptionsByCategory('Network')
    const instanceNetworkNames = networkOptions.map((option) => {
      return option.name
    })
    setAwsAccounts(awsAccountNames)
    setInstanceRegions(instanceRegionNames)
    setInstanceNetworks(instanceNetworkNames)
  }

  const validationSchema: Yup.SchemaOf<AddClusterFormSchema> =
    Yup.object().shape({
      name: Yup.string().required('Required Field.'),
      version: Yup.string().required('Required Field.'),
      region: Yup.string().required('Required Field.'),
      network: Yup.string().required('Required Field.'),
      awsAccount: Yup.string().required('Required Field.')
    })

  useEffect(() => {
    if (isLogin) {
      loadSelectionOptions()
      fetchInstanceVersions()
    }
  }, [isLogin])

  const onToggleModal = useCallback(() => {
    setIsOpen((prev) => !prev)
    if (!isOpen) {
      refreshHandler()
    }
  }, [])

  const handleSubmit = async (
    values,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ): Promise<void> => {
    setLoading(true)
    const payload = {
      ...values,
      name: values.name.trim()
    }
    const response = await addCluster(payload, setFieldError)
    setLoading(false)
    if (response?.message) {
      onToggleModal()
    }
  }

  const setOptions = (inputName: string) => {
    switch (inputName) {
      case 'region':
        return instanceRegions

      case 'awsAccount':
        return awsAccounts

      case 'network':
        return instanceNetworks

      case 'version':
        return instanceVersions.map((version) => version.Version)

      default:
        return []
    }
  }

  const dropDownComponent = ({
    field,
    form,
    name,
    excludedValid,
    disabled,
    ...restProps
  }) => {
    const inputName = name || field?.name
    const hasError = form?.touched[inputName] && form?.errors[inputName]
    const isValid =
      form?.touched[inputName] && form?.values[inputName] && !hasError
    const options = setOptions(inputName)

    return (
      <CustomDropDown
        inputName={inputName}
        options={options}
        error={hasError}
        isValid={!excludedValid && !!isValid}
        disabled={disabled}
        {...field}
        {...restProps}
      />
    )
  }

  const formConfig = {
    title: 'Confirm',
    initialValues: {
      name: '',
      network: '',
      region: '',
      version: '',
      awsAccount: ''
    },
    form: {
      data: [
        {
          name: 'name',
          label: 'Cluster Name',
          type: 'text',
          required: true,
          placeholder: 'Enter Cluster Name'
        },
        {
          type: 'customGroup',
          groupFields: [
            {
              name: 'version',
              label: 'Cluster Version',
              type: 'custom',
              required: true,
              getComponent: dropDownComponent
            },
            {
              name: 'awsAccount',
              label: 'Select AWS Account*',
              type: 'custom',
              required: true,
              getComponent: dropDownComponent
            }
          ]
        },
        {
          name: 'network',
          label: 'Network',
          type: 'custom',
          required: true,
          getComponent: dropDownComponent
        },
        {
          name: 'region',
          label: 'Region',
          type: 'custom',
          required: true,
          getComponent: dropDownComponent
        }
      ]
    }
  }
  return {
    formConfig,
    onToggleModal,
    isOpen,
    setIsOpen,
    handleSubmit,
    validationSchema,
    loading
  }
}
