import {
  EXPIRED_OTP_ERR_MSG,
  INVALID_OTP_ERR_MSG,
  LoginFailed,
  STATUS_CODE_EXPIRED_OTP,
  STATUS_CODE_INCORRECT_OTP
} from '@constants/constants'
import appConfig from 'app.config'
import { useState } from 'react'
import useUserLoginApi from './useUserLoginApi'

const useOtpReqConfig = (formValues) => {
  const [isValidOTP, setIsValidOTP] = useState<boolean>(true)
  const [isExpiredOTP, setIsExpiredOTP] = useState<boolean>(false)
  const [errorMessage, setErrorMessage] = useState<string>('')
  const [otp, setOtp] = useState<string>('')
  const [otpInterval, setOtpInterval] = useState<number>(
    Number(appConfig?.otpDuration)
  )
  const { userLogin, resendOTP } = useUserLoginApi()

  const errorCallback = (error) => {
    setIsValidOTP(false)
    if (!error.response) return
    if (error.response.data.code === STATUS_CODE_INCORRECT_OTP) {
      setErrorMessage(INVALID_OTP_ERR_MSG)
      return
    }
    if (error.response.data.code === STATUS_CODE_EXPIRED_OTP) {
      setIsExpiredOTP(true)
      setErrorMessage(EXPIRED_OTP_ERR_MSG)
    } else {
      setErrorMessage(LoginFailed.message)
    }
  }

  const handleSubmit = async (): Promise<void> => {
    if (!otp) {
      setErrorMessage(INVALID_OTP_ERR_MSG)
    }
    await userLogin({
      loginInputs: formValues,
      otp,
      errorCallback
    })
  }

  async function handleResendOTP(): Promise<void> {
    try {
      const response = await resendOTP(formValues)
      if (response.status === 'success') {
        setOtpInterval(Number(appConfig?.otpDuration))
        setIsExpiredOTP(false)
        setIsValidOTP(true)
        setErrorMessage('')
      }
    } catch (error) {
      console.error(error)
    }
  }

  return {
    handleSubmit,
    setOtp,
    handleResendOTP,
    isValidOTP,
    isExpiredOTP,
    errorMessage,
    otp,
    otpInterval,
    setOtpInterval
  }
}

export default useOtpReqConfig
