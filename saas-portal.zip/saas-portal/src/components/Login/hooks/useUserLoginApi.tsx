import { useCallback, useState } from 'react'
import axios from 'axios'
import {
  UserLoginRes,
  LoginForm,
  UserLogin,
  ApiResponse
} from '../types/UserLogin'
import appConfig from 'app.config'
import { LoginFailed } from '@constants/constants'
import { useUserPreferences } from '@core/context/UserPreferences'
import { useRouter } from 'next/router'
import { onKeycloakToken } from '@utils/auth'
import { useAuthorize } from '@core/context/Authorize'

export interface UserLoginResponse {
  data: UserLoginRes
}

export const userLoginApiUrl = `${appConfig.api}/saas-management/api/v1/saas/login`
const resendOtpUrl = `${appConfig.api}/saas-management/api/v1/saas/resend-otp`

export default function useUserLoginApi() {
  const { setRedirect } = useAuthorize()
  const [userLoginData, setUserLoginData] = useState<UserLoginRes | null>(null)
  const [userLoginError, setUserLoginError] = useState<string | null>('')
  const { setAcceptCookies } = useUserPreferences()
  const router = useRouter()

  const userLogin = useCallback(
    async ({ loginInputs, setFieldError, otp, errorCallback }: UserLogin) => {
      try {
        setUserLoginError('')
        const payload = otp ? { ...loginInputs, otp } : loginInputs
        const { data: response } = await axios.put<ApiResponse<UserLoginRes>>(
          userLoginApiUrl,
          payload
        )
        if (!response?.otpRequired) {
          if (response?.data && onKeycloakToken(response?.data)) {
            setAcceptCookies(true)
            setRedirect((prev) => !prev)
          }
          setUserLoginData(response?.data)
          return response?.data
        }
        return response
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (errorCallback) {
            errorCallback(error)
          } else {
            setFieldError('password', LoginFailed.message)
            setUserLoginError(LoginFailed.message)
          }
        } else {
          setUserLoginError('unexpected error')
        }
      }
    },
    []
  )

  const resendOTP = async (loginInputs: LoginForm): Promise<any> => {
    try {
      const { data: response } = await axios.post(resendOtpUrl, loginInputs)

      return response
    } catch (error) {
      console.log(error)
    }
  }

  return {
    userLoginData,
    userLoginError,
    setUserLoginData,
    userLogin,
    resendOTP
  }
}
