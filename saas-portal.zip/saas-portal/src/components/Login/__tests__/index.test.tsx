import React from 'react'
import SaasLogin from '..'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import user from '@testing-library/user-event'
import { onKeycloakToken } from '@utils/auth'
import { validationSchema } from '../hooks/loginConfig'

const mockRouterBack = jest.fn()
const mockRouterPush = jest.fn()

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack,
    push: mockRouterPush
  })
}))

jest.mock('@core/context/UserPreferences', () => ({
  useUserPreferences: () => ({
    setAcceptCookies: jest.fn()
  })
}))

jest.mock('@utils/auth')

function renderComponent(validatedToken?: boolean) {
  const onKeycloakTokenMock = onKeycloakToken as jest.Mock<boolean>

  onKeycloakTokenMock.mockReturnValue(validatedToken)

  render(<SaasLogin />)
}

describe('Login page', () => {
  it('login components should render', async () => {
    renderComponent(true)
    expect(await screen.findByRole('heading', { level: 3 })).toHaveTextContent(
      'Login to your account'
    )
    expect(
      await screen.findByRole('textbox', { name: /business email address/i })
    ).toBeInTheDocument()

    expect(await screen.findByLabelText('Password')).toBeInTheDocument()

    expect(
      await screen.findByRole('button', { name: /Forgot your password/i })
    ).toBeInTheDocument()

    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('login components type values', async () => {
    renderComponent(true)

    const emailInputEl = await screen.findByRole('textbox', {
      name: /business email address/i
    })
    fireEvent.change(emailInputEl, {
      target: { value: 'john.dee@someemail.com' }
    })

    const passwordInputEl = await screen.findByLabelText('Password')
    fireEvent.change(passwordInputEl, {
      target: { value: 'AdminUserTest@123' }
    })

    await waitFor(() => {
      expect(emailInputEl).toHaveValue('john.dee@someemail.com')
    })

    await waitFor(() => {
      expect(passwordInputEl).toHaveValue('AdminUserTest@123')
    })
  })

  it('login components with invalid values', async () => {
    renderComponent(true)

    const emailInputEl = await screen.findByRole('textbox', {
      name: /business email address/i
    })
    user.type(emailInputEl, 'john.dee')

    const passwordInputEl = await screen.findByLabelText('Password')
    user.type(passwordInputEl, 'AdminUser')

    // const loginBtnEl = await screen.findByRole('button', { name: /login/i })
    // user.click(loginBtnEl)

    // TODO negative test
    // expect(
    //   screen.findByText('Please enter a valid email address.')
    // ).toBeInTheDocument()
  })

  it('login with invalid creds', async () => {
    renderComponent(true)

    const emailInputEl = await screen.findByRole('textbox', {
      name: /business email address/i
    })
    user.type(emailInputEl, 'john.dee1@someemail.com')

    const passwordInputEl = await screen.findByLabelText('Password')
    user.type(passwordInputEl, 'UserAdminTest@321')

    // const loginBtnEl = await screen.findByRole('button', { name: /login/i })
    // user.click(loginBtnEl)
  })
})

describe('Yup validation Login Page', () => {
  it('check yup validations on the form , incorrect values will give error', async () => {
    const values = {
      email: 'john.dee',
      password: ''
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toBe(false)
  })

  it('check yup validations on the form correct values no error', async () => {
    const values = {
      email: 'john.dee@someemail.com',
      password: 'AdminUserTest@123'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toEqual(true)
  })
})
