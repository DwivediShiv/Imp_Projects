import { UserLoginRes } from '../types/UserLogin'

export const userLoginData: UserLoginRes = {
  access_token: '1',
  expires_in: 1,
  refresh_expires_in: 2,
  refresh_token: 'Sample Address',
  scope: 'www.nagarro.com',
  token_type: 'test@nagarro.com'
}
