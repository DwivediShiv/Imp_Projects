import { rest } from 'msw'
import { server } from '@utils/msw'
import { ApiResponse, MswHandlerProps, UserLoginRes } from '../types/UserLogin'
import { userLoginData } from './userLoginData'

export function setupGetOrgDataHandler(props?: MswHandlerProps<UserLoginRes>) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(
    'https://api.nagarro.acentrik.io/saas-management/api/v1/as/login',
    async (_, res, ctx) => {
      let json: ApiResponse<UserLoginRes>
      const data = userLoginData

      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
