export interface LoginForm {
  email: string
  password: string
}

export interface UserLogin {
  loginInputs: LoginForm
  setFieldError?: (field: string, errorMsg: string) => void
  otp?: string
  errorCallback?: (error: object) => void
}
export interface UserLoginRes {
  otpRequired?: string
  access_token?: string
  expires_in?: number
  refresh_expires_in?: number
  refresh_token?: string
  scope?: string
  token_type?: string
}

export interface ApiResponse<T> {
  data?: T
  otpRequired?: string
  error?: string | { message: string }
}

export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}
