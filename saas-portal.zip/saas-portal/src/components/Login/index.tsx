import React, { useEffect, useState } from 'react'
import { LoginForm } from './types/UserLogin'
import {
  initialValues,
  loginFormContent,
  validationSchema
} from './hooks/loginConfig'
import useUserLoginApi from './hooks/useUserLoginApi'
import AuthForm from '@sharedComponents/Forms/AuthForm'
import OtpRequestPage from './OtpRequestPage'
import { useAuthorize } from '@core/context/Authorize'
import { useRouter } from 'next/router'

export default function Login() {
  const [isLoginFailed, setIsLoginFailed] = useState<boolean>(false)
  const [authSuccess, setAuthSuccess] = useState(false)
  const [formValues, setFormValues] = useState<Partial<LoginForm>>()
  const { userLoginData, userLoginError, userLogin } = useUserLoginApi()
  const { isLogin, landingPage } = useAuthorize()

  const router = useRouter()

  useEffect(() => {
    if (isLogin && landingPage) {
      router.push(landingPage)
    } else {
      router.push('/login')
    }
  }, [isLogin, landingPage])

  useEffect(() => {
    if (userLoginError) {
      setIsLoginFailed(true)
    }
  }, [userLoginError, userLoginData])

  async function handleSubmit(
    values: LoginForm,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ) {
    const response = await userLogin({ loginInputs: values, setFieldError })
    if (response?.otpRequired) {
      setFormValues(values)
      setAuthSuccess(true)
    }
  }

  return (
    <>
      {authSuccess ? (
        <OtpRequestPage
          formValues={formValues}
          setAuthSuccess={setAuthSuccess}
        />
      ) : (
        <AuthForm
          content={loginFormContent}
          initialValues={initialValues}
          validationSchema={validationSchema}
          handleSubmit={handleSubmit}
          loading={false}
          message="Logging in.."
          isAlert={isLoginFailed}
        />
      )}
    </>
  )
}
