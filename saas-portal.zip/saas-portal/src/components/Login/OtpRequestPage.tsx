import React, { ReactElement, useEffect } from 'react'
import styles from './index.module.css'
import useOtpReqConfig from './hooks/useOtpReqConfig'
import Button from '@sharedComponents/Button'
import HelperText from '@sharedComponents/HelperText'
import OtpInput from '@sharedComponents/Input/OtpInput'
import { LoginForm } from './types/UserLogin'

const OtpRequestPage = ({
  formValues,
  setAuthSuccess
}: {
  formValues: Partial<LoginForm>
  setAuthSuccess?: React.Dispatch<React.SetStateAction<boolean>>
}): ReactElement => {
  const {
    handleSubmit,
    setOtp,
    handleResendOTP,
    isValidOTP,
    isExpiredOTP,
    errorMessage,
    otp,
    otpInterval,
    setOtpInterval
  } = useOtpReqConfig(formValues)

  useEffect(() => {
    const timer =
      otpInterval > 0 &&
      setInterval(() => setOtpInterval(otpInterval - 1), 1000)
    return () => clearInterval(timer)
  }, [otpInterval])

  return (
    <div className={styles.content}>
      <div className={styles.title}>Login Verification</div>
      <div className={styles.subTitle}>
        A one-time password has been sent to
        <span className={`${styles.loginUser} font-semibold`}>
          {formValues?.email ?? '-'}
        </span>
      </div>
      <div>
        <OtpInput
          length={6}
          hasError={!isValidOTP}
          helperMessage={errorMessage}
          onChangeOTP={(otp) => setOtp(otp)}
        />
      </div>
      <div className={styles.otpAction}>
        {isExpiredOTP ? (
          <Button
            color="primary"
            variant="contained"
            buttonType="solid"
            onClick={() => handleResendOTP()}
            fullWidth
          >
            Resend
          </Button>
        ) : (
          <Button
            color="primary"
            variant="contained"
            disabled={otp.length < 6}
            buttonType="solid"
            onClick={() => handleSubmit()}
            fullWidth
          >
            Verify
          </Button>
        )}
      </div>
      <div className={styles.footerSubAction}>
        {!isExpiredOTP && (
          <div className={styles.resendWrapper}>
            <span>{`Didn't receive an OTP?`}</span>
            {otpInterval > 0 ? (
              <span className={`${styles.otpInterval} ml-1`}>
                Resend in {otpInterval}s
              </span>
            ) : (
              <Button
                color="primary"
                buttonType="link"
                className={`${styles.resendBtn} ml-1 font-semibold`}
                onClick={() => handleResendOTP()}
              >
                Resend
              </Button>
            )}
          </div>
        )}
        <hr className={styles.divider} />
        <Button
          color="primary"
          buttonType="link"
          className={styles.returnBtn}
          onClick={() => setAuthSuccess(false)}
        >
          Return to Login
        </Button>
      </div>
    </div>
  )
}

export default OtpRequestPage
