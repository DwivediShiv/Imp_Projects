import React, { useCallback, useEffect } from 'react'
import classNames from 'classnames'

import styles from './index.module.css'
import { useAuthorize } from '@core/context/Authorize'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import {
  PERMISSION_ADMIN,
  PERMISSION_INFRAMANAGER,
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import Container from '@sharedComponents/Container'
import Button from '@sharedComponents/Button'
import Modal from '@sharedComponents/Modal'
import { isLoggedIn } from '@utils/auth'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import CustomTableList from '@sharedComponents/CustomTableList'
import { useManageInstance } from './hooks/useManageInstance'
import useManageInstanceApi from './hooks/useManageInstanceApi'
import CustomButton from '@sharedComponents/Button'
import { useRouter } from 'next/router'
import Loader from '@sharedComponents/CustomLoader'
import Warning from '@libs/sharedComponents/WarningMessage'
import { CustomIconicCardState } from '@libs/sharedComponents/IconicCard'
import { debounce } from 'lodash'

const ManageInstance = () => {
  const { isInfraManager, isLogin } = useAuthorize()

  const router = useRouter()
  const {
    page,
    handlePageChange,
    filterCustomerName,
    filterRegions,
    sortBy,
    sortOrder,
    searchValue,
    status,
    tabIndex,
    handleSortChange,
    handleOnSearch,
    isLoading,
    setIsLoading,
    handleTabChange,
    noFilteredData,
    InstanceListConfig: instanceListConfig,
    setIsModalOpen,
    isModalOpen,
    submitModal,
    init,
    confirmLoader,
    refreshList
  } = useManageInstance()

  const {
    instanceListData,
    instanceListError,
    fetchInstanceList,
    instanceTotal,
    filterCriterias,
    initialLoader,
    instanceListErrorCode
  } = useManageInstanceApi()

  const debouncefetch = useCallback(
    debounce((params) => {
      fetchInstanceList(params)
    }, 500),
    []
  )

  useEffect(() => {
    const param = {
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterCustomerName,
      filterRegions
    }
    debouncefetch(param)
  }, [
    fetchInstanceList,
    filterCustomerName,
    filterRegions,
    page,
    searchValue,
    setIsLoading,
    sortBy,
    sortOrder,
    status,
    init,
    isLogin,
    refreshList
  ])
  const refreshListHandler = () => {
    const param = {
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      filterRegions,
      filterCustomerName
    }
    debouncefetch(param)
  }

  const handleCreateInstance = () => {
    router.push('/create-instance')
  }

  const renderInstanceListData = () => {
    if (instanceListError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = instanceListError

      const isUnauthorize = instanceListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    return (
      <>
        <CustomTableList
          configuration={instanceListConfig}
          data={instanceListData}
          totalRecord={instanceTotal}
          isLoading={isLoading}
          paginationSize={10}
          tabIndex={tabIndex}
          handleOnTabChange={handleTabChange}
          sortBy={sortBy}
          sortOrder={sortOrder}
          handlePageChange={handlePageChange}
          page={page}
          handleSortChange={handleSortChange}
          state={status}
          handleOnSearch={handleOnSearch}
          filterCriterias={filterCriterias}
          searchValue={searchValue}
          noFilteredData={noFilteredData}
        />
        <Modal
          type={CUSTOM_TYPE}
          title="Delete Instance"
          titleSize="h3"
          onToggleModal={() => {
            setIsModalOpen(false)
          }}
          isOpen={isModalOpen}
        >
          Are you sure you want to delete the instance?
          <div className={styles.footer}>
            {!confirmLoader ? (
              <Button
                color="primary"
                variant="contained"
                className={`mt-1 ${styles.confirmButton}`}
                onClick={submitModal}
              >
                Confirm
              </Button>
            ) : (
              <Loader />
            )}
          </div>
        </Modal>
      </>
    )
  }

  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_INFRAMANAGER} isBigBoardError>
        {initialLoader ? (
          <div className={styles.loader}>
            <Loader />
          </div>
        ) : (
          <Container className={classNames(styles.headerContent, 'container')}>
            <section className={styles.grid}>
              <div className={styles.topBar}>
                {!(
                  instanceListError && instanceListErrorCode === ERROR_UNAUTH
                ) &&
                  isInfraManager && <h3 className="bold">Manage Instance</h3>}
                {!(
                  instanceListError && instanceListErrorCode === ERROR_UNAUTH
                ) &&
                  isInfraManager && (
                    <CustomButton
                      color="primary"
                      variant="contained"
                      onClick={handleCreateInstance}
                    >
                      Create Instance
                    </CustomButton>
                  )}
              </div>
            </section>
            {renderInstanceListData()}
          </Container>
        )}
      </Permission>
    </PrivateRoute>
  )
}

export default ManageInstance
