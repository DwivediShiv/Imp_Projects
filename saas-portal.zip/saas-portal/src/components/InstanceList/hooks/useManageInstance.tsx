import React, { useCallback, useMemo, useState } from 'react'
import { Configuration, InstanceDetail } from '../types/ManageInstance'
import { INSTANCE_STATUS, SELECTION_CONSTANTS } from '@constants/constants'
import useManageInstanceApi from './useManageInstanceApi'
import appConfig from 'app.config'
import Delete from '@images/delete.svg'
import { ModalFieldValue } from '@libs/types/Modal'

export const useManageInstance = () => {
  const [page, setPage] = useState(1)
  const [sortBy, setSortBy] = useState<string>('')
  const [sortOrder, setSortOrder] = useState<string>('')
  const [status, setStatus] = useState<string>('')
  const [searchValue, setSearchValue] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>()
  const [tabIndex, setTabIndex] = useState<number>(0)
  const [refreshList, setRefreshList] = useState<number>(0)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalFieldValue, setModalFieldValue] = useState<ModalFieldValue>({
    template: '',
    value: null
  })
  const [init, setInit] = useState<boolean>()
  const [filterCustomerName, setFilterCustomerName] = useState<string[]>([])
  const [filterRegions, setFilterRegions] = useState<string[]>([])
  const { exportInstanceList, deleteInstance } = useManageInstanceApi()
  const [confirmLoader, setConfirmLoader] = useState<boolean>(false)

  const handleRegionSelect = useCallback(
    (
      e: React.ChangeEvent<HTMLInputElement>,
      countryItems: Record<string, string>
    ) => {
      setPage(1)
      e.preventDefault()
      const { value } = e.target
      const countryOptions = Object.keys(countryItems)
      if (
        value[value.length - 1] === SELECTION_CONSTANTS.ALL ||
        value.length === 0
      ) {
        setFilterRegions(
          filterRegions.length === countryOptions.length ? [] : countryOptions
        )
        return
      }
      setFilterRegions(typeof value === 'string' ? value.split(',') : value)
    },
    [setPage, setFilterRegions]
  )

  const handleClearFilter = () => {
    setPage(1)
    setSearchValue('')
    setFilterCustomerName([])
    setFilterRegions([])
    setSortBy('')
    setSortOrder('')
    setTabIndex(0)
    setStatus('')
  }

  function noFilteredData() {
    return (
      searchValue !== '' ||
      filterCustomerName.length > 0 ||
      filterRegions.length > 0 ||
      tabIndex !== 0
    )
  }

  async function onDelete(row) {
    setModalFieldValue({ template: 'deleteUser', value: row })
    setIsModalOpen(true)
  }
  const handleCustomerNameSelect = useCallback(
    (
      e: React.ChangeEvent<HTMLInputElement>,
      CustomerNamess: Record<string, string>
    ) => {
      setPage(1)
      e.preventDefault()
      const { value } = e.target
      const customerOptions = Object.keys(CustomerNamess)

      if (
        value[value.length - 1] === SELECTION_CONSTANTS.ALL ||
        value.length === 0
      ) {
        setFilterCustomerName(
          filterCustomerName.length === customerOptions.length
            ? []
            : customerOptions
        )
      } else {
        setFilterCustomerName(
          typeof value === 'string' ? value.split(',') : value
        )
      }
    },
    [filterCustomerName.length]
  )

  const InstanceListConfig = useMemo(() => {
    return {
      title: '',
      searchConfig: {
        type: 'search',
        name: 'search',
        placeholder: 'Search...',
        searchValue
      },
      exportConfig: {
        exportFn: () =>
          exportInstanceList(searchValue, name, status, sortBy, sortOrder),
        fileName: 'instanceList.csv'
      },
      refreshConfig: {
        name: 'Refresh List',
        handleRefreshList: () => setRefreshList(Math.random())
      },
      columns: [
        {
          id: 'name',
          title: 'Instance Name',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'name',
          class: 'name',
          rowConfig: {
            cellType: 'nameField',
            clickable: 'true',
            value: 'name',
            class: 'nameColumn',
            href: '/instance-details/',
            param: 'id'
          },
          grow: 3.5,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'name'
        },
        {
          id: 'CustomerNames',
          title: 'Customer Name',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'customer_name',
          class: 'customerName',
          rowConfig: {
            cellType: 'default',
            value: 'customerName',
            clickable: 'false',
            class: 'customerName'
          },
          grow: 3.5,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'customer_name'
        },
        {
          id: 'region',
          title: 'Region',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'address',
          class: 'address',
          rowConfig: {
            cellType: 'default',
            clickable: 'false',
            value: 'region',
            class: 'regionColumn'
          },
          grow: 1.25,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'region'
        },
        {
          id: 'version',
          title: 'Version',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'version',
          class: 'version',
          rowConfig: {
            cellType: 'default',
            clickable: 'false',
            value: 'version',
            class: 'versionColumn'
          },
          grow: 1.25,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'version'
        },
        {
          id: 'account',
          title: 'AWS Account',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'awsAccount',
          class: 'awsAccount',
          rowConfig: {
            cellType: 'default',
            clickable: 'false',
            value: 'awsAccount',
            class: 'awsAccountColumn'
          },
          grow: 2.5,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'aws_account'
        },
        {
          id: 'createdAt',
          title: 'Created On',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'created_at',
          class: 'createdAt',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'createdAt',
            class: 'createdAtColumn'
          },
          grow: 3.5,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'created_at',
          allowOverflow: false
        },
        {
          id: 'createdBy',
          title: 'Created By',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'created_by',
          rowConfig: {
            cellType: 'default',
            value: 'createdBy',
            class: 'createdByColumn'
          },
          grow: 3.5,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'created_by',
          allowOverflow: false
        },
        {
          id: 'status',
          title: 'Status',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'status',
          rowConfig: {
            cellType: 'fancyStatusField',
            value: 'status',
            class: 'statusColumn'
          },
          grow: 6,
          style: '{overflow: hidden; textOverflow: ellipsis}',
          sortField: 'status',
          allowOverflow: false
        },

        {
          id: 'actions',
          title: 'Actions',
          type: 'tableHeader',
          sortable: false,
          rowConfig: {
            cellType: 'actions',
            actions: [
              {
                type: 'icon',
                image: Delete,
                clickable: (row: InstanceDetail) => {
                  return [
                    INSTANCE_STATUS.INACTIVE,
                    INSTANCE_STATUS['BUILD FAILED'],
                    INSTANCE_STATUS['DELETION FAILED'],
                    INSTANCE_STATUS['ACTIVATION FAILED'],
                    INSTANCE_STATUS['INACTIVATION FAILED'],
                    INSTANCE_STATUS['NETWORK DEPLOYMENT FAILED'],
                    INSTANCE_STATUS['VERSION DEPLOYMENT FAILED']
                  ].includes(row.status)
                },
                onClick: (row: InstanceDetail) => {
                  onDelete(row)
                }
              }
            ]
          },
          // grow: 1,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          allowOverflow: false
        }
      ],
      tabConfig: {
        defaultTab: 0,
        tabList: [
          {
            title: 'All',
            key: 'all',
            value: '',
            index: 0
          },
          {
            title: 'Success',
            key: 'Active',
            value: 'Active',
            index: 1,
            icon: 'success'
          },
          {
            title: 'In Progress',
            key: 'Provisioned',
            value: 'Provisioned',
            index: 2,
            icon: 'provisioned'
          },
          {
            title: 'Failed',
            key: 'Build Failed',
            value: 'Build Failed',
            index: 3,
            icon: 'failed'
          },
          {
            title: 'Inactive',
            key: 'Inactive',
            value: 'Inactive',
            index: 1,
            icon: 'warning'
          },
          {
            title: 'Pending Verification',
            key: 'Pending Domain Verification',
            value: 'Pending Domain Verification',
            index: 4,
            icon: 'pending_verification'
          },
          {
            title: 'Finalizing Instance',
            key: 'Finalizing Instance',
            value: 'Finalizing Instance',
            index: 5,
            icon: 'finalizing_instance'
          }
        ]
      },
      filterConfig: {
        clearFilters: handleClearFilter,
        filters: [
          {
            id: 'CustomerNames',
            inputName: 'CustomerNames',
            label: 'Customer Name',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterCustomerName,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterCustomerName,
            onChange: handleCustomerNameSelect
          },
          {
            id: 'Regions',
            inputName: 'Regions',
            label: 'Regions',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterRegions,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterRegions,
            onChange: handleRegionSelect
          }
        ]
      }
    }
  }, [
    searchValue,
    filterRegions,
    handleRegionSelect,
    filterCustomerName,
    handleCustomerNameSelect,
    exportInstanceList,
    status,
    sortBy,
    sortOrder
  ])

  const handlePageChange = (page) => {
    setPage(page)
  }
  const {
    tabConfig: { tabList = [] }
  } = InstanceListConfig

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    setSortBy(column.sortField)
    setSortOrder(sortDirection)
  }

  const handleOnSearch = (e) => {
    setPage(1)
    setSearchValue(e.target.value)
  }
  async function submitModal() {
    try {
      setConfirmLoader(true)
      const { id } = modalFieldValue.value
      await deleteInstance(id)
      setIsModalOpen(false)
      setInit(!init)
    } catch (error) {
      console.error('Error deleting instance:', error)
    } finally {
      setConfirmLoader(false)
    }
  }

  const handleTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setPage(1)
    setStatus(tabList[newValue].value)
    setTabIndex(newValue)
  }

  async function handleInstanceCreation() {
    setPage(1)
  }

  return {
    searchValue,
    handleOnSearch,
    handleSortChange,
    handlePageChange,
    handleTabChange,
    tabIndex,
    status,
    sortBy,
    sortOrder,
    InstanceListConfig,
    filterCustomerName,
    filterRegions,
    page,
    isLoading,
    setIsLoading,
    noFilteredData,
    isModalOpen,
    setIsModalOpen,
    submitModal,
    handleInstanceCreation,
    init,
    confirmLoader,
    refreshList
  }
}
