import { useCallback, useState } from 'react'
import axios, { AxiosResponse } from 'axios'
import {
  ApiResponse,
  InstanceDetail,
  InstanceList
} from '../types/ManageInstance'
import appConfig from 'app.config'
import { SELECTION_CONSTANTS, INSTANCE_MESSAGES } from '@constants/constants'
import { buildUrlWithQueryParams } from '@utils/url'
import Toast from '@sharedComponents/Toast'
import { printErrorStack } from '@saasportal/libs/utils'
export interface InstanceListResponse {
  data: InstanceList
}

export let instanceListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/instance/list`

export function getDeleteInstanceUrl(id: string) {
  return `${appConfig.api}/saas-management/api/v1/saas/management/instance/id/${id}`
}

export default function useInstanceListApi() {
  const [instanceListData, setInstanceListData] = useState<any>([])
  const [instanceListError, setInstanceListError] = useState<string | null>('')
  const [instanceTotal, setInstanceTotal] = useState<number>(0)
  const [filterCriterias, setFilterCriterias] = useState<any>()
  const [initialLoader, setInitialLoader] = useState<boolean>(true)
  const [instanceListErrorCode, setInstanceListErrorCode] = useState<
    string | null
  >('')

  const fetchInstanceList = useCallback(
    async ({
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterCustomerName,
      filterRegions
    }) => {
      try {
        const urlParams: Record<string, string> = {}
        setInstanceListError('')
        setInstanceTotal(0)
        setIsLoading(true)

        instanceListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/instance/list`

        if (page) {
          urlParams.page = page
        }

        if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
          urlParams.statusTab = status
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.name = searchValue
        }

        if (filterCustomerName?.length) {
          urlParams.customerNames = filterCustomerName
        }
        if (filterRegions?.length) {
          urlParams.regions = filterRegions
        }

        const { data: response } = await axios.post<
          ApiResponse<InstanceDetail>
        >(instanceListApiUrl, urlParams)

        if (response.filterCriterias) {
          setFilterCriterias(response.filterCriterias)
        }

        setInstanceListData(response.data)
        setInstanceTotal(response.totalRecord)
        setInitialLoader(false)
      } catch (error) {
        setInstanceListErrorCode(error?.response?.data?.code || 'General')
        setInitialLoader(false)
        setInstanceListError(error?.response?.data?.error?.message)
      } finally {
        setInitialLoader(false)
        setIsLoading(false)
      }
    },
    []
  )

  function getExportInstanceUrlParams(
    name?: string,
    customerName?: string,
    statusTab?: string,
    sortBy?: string,
    sortOrder?: string,
    address?: string,
    version?: string,
    createdAt?: any,
    createdBy?: any,
    searchValue?: any
  ): any {
    const urlParams: Record<string, string> = {}
    urlParams.get = 'All'
    if (searchValue !== '') {
      urlParams.searchValue = searchValue
    }
    if (name !== '') {
      urlParams.name = name
    }
    if (customerName !== '') {
      urlParams.customerName = customerName
    }
    if (address?.length) {
      urlParams.address = address
    }

    if (version?.length) {
      urlParams.version = version
    }
    if (createdAt?.length) {
      urlParams.createdAt = createdAt
    }
    if (createdBy?.length) {
      urlParams.createdBy = createdBy
    }

    if (statusTab !== '' && statusTab !== SELECTION_CONSTANTS.ALL) {
      urlParams.statusTab = statusTab
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    return urlParams
  }

  async function exportInstanceList(
    searchValue,
    name,
    statusTab,
    sortBy,
    sortOrder
  ): Promise<string> {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: `${appConfig.api}/saas-management/api/v1/saas/management/instance/list/export`,
        data: getExportInstanceUrlParams(
          searchValue,
          name,
          statusTab,
          sortBy,
          sortOrder
        )
      })
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  async function deleteInstance(id: string): Promise<any> {
    try {
      const response: AxiosResponse = await axios({
        method: 'DELETE',
        url: getDeleteInstanceUrl(id)
      })

      Toast('success', INSTANCE_MESSAGES.INSATNCE_DELETED)
    } catch (error) {
      if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', INSTANCE_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }

  return {
    instanceListData,
    instanceListError,
    setInstanceListData,
    exportInstanceList,
    fetchInstanceList,
    instanceTotal,
    filterCriterias,
    deleteInstance,
    initialLoader,
    instanceListErrorCode
  }
}
