// TODO: validate fields matches with API response
export interface InstanceProfile {
  orgId: string
  name: string
  instanceName: string
  customerName: string
  status: string
  region: string
  version: string
  customDomain: string
  customEmailDomain: string
  tokenAddress: string
  tokenSymbol: string
  decimal: number
  contactEmail: string
  createdBy: string
  enabled?: boolean
  createdAt: string
  awsAccount: string
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

export interface InstanceProfileError {
  type: string
  error: any
}
