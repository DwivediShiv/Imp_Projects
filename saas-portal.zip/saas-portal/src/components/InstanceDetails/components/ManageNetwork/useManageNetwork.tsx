import { isAddress } from 'ethers/lib/utils'
import { REQUIRED_FIELD } from '@constants/constants'
import { useMemo } from 'react'
import * as Yup from 'yup'

export default function useManageNetwork() {
  const networkValidationSchema: Yup.SchemaOf<any> = Yup.object().shape({
    selectNetwork: Yup.string().required(REQUIRED_FIELD),

    tokenAddress: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(
        /^[a-zA-Z0-9]+$/,
        'Token Address should be alphanumeric without spaces.'
      )
      .max(100, 'Token Address is too long, maximum length is 100 characters')
      .test(
        'Invalid Address check',
        'Token Address is invalid',
        function (value: string) {
          if (!isAddress(value)) {
            return false
          }
          return true
        }
      ),

    tokenSymbol: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(
        /^[a-zA-Z0-9]+$/,
        'Token Symbol should be alphanumeric without spaces.'
      ),
    decimal: Yup.string()
      .matches(/^\d+$/, 'Please enter a whole number')
      .test(
        'max-length',
        'Please enter a value less than or equal to 18',
        (value) => !value || parseInt(value, 10) <= 18
      )
      .required(REQUIRED_FIELD)
  })
  const networkCards = useMemo(
    () => ({
      title: 'Network Details',
      fields: [
        {
          name: 'selectNetwork',
          title: 'Select Network*',
          placeholder: 'E.g. Amoy, Sepolia',
          type: 'dropdown',
          required: true
        },
        {
          name: 'tokenAddress',
          title: 'Token Address*',
          placeholder: 'E.g. 0x99f9e4B...',
          type: 'text',
          required: true
        },
        {
          name: 'tokenSymbol',
          title: 'Token Symbol*',
          placeholder: 'E.g. USDC, Matic etc..',
          type: 'text',
          required: true
        },
        {
          name: 'decimal',
          title: 'Decimal*',
          placeholder: 'E.g. 10,15 etc..',
          type: 'text',
          required: true
        }
      ]
    }),
    []
  )

  return { networkCards, networkValidationSchema }
}
