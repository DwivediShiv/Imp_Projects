import { Paper, TableBody, TableCell, TableRow, Divider } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { Field, Form, Formik } from 'formik'
import classNames from 'classnames'
import styles from './index.module.css'
import CustomButton from '@sharedComponents/Button'
import TableHeader from '@sharedComponents/TableHeader'
import { addressTruncate } from '@utils/conversion'
import Copy from '@sharedComponents/Copy'
import { INSTANCE_STATUS, IconColor } from '@constants/constants'
import useManageNetwork from './useManageNetwork'
import { Grid } from '@mui/material'
import Table from '@sharedComponents/Table'
import CustomDropDown from '@sharedComponents/Dropdown'
import InputField from '@sharedComponents/InputField'
import { useFancyState } from '@core/context/FancyState'
import useInstanceProfileApi from '../../hooks/useInstanceDetailApi'
import Toast from '@sharedComponents/Toast'
import {
  ADD_NETWORK,
  GENERAL_ERROR,
  REDEPLOYMENT_SUCCESS
} from '../../constants'
import HelperMessage from '@sharedComponents/HelperMessage'

const ManageNetwork = ({ data, setIsInstanceProfUpdated }) => {
  const [isEditActive, setIsEditActive] = useState<boolean>(false)
  const [networkInfo, setNetworkInfo] = useState([])
  const [shouldResetTable, setShouldResetTable] = useState(false)
  const [newNetworkInfo, setNewNetworkInfo] = useState([])
  const { addInstanceNetwork, instanceProfileError } = useInstanceProfileApi()

  useEffect(() => {
    const networkInfoInitial = data.networks?.map((networkInfo) => {
      const { network, tokenAddress, tokenSymbol, decimal } = networkInfo
      return {
        name: network,
        tokenAddress: tokenAddress,
        tokenSymbol: tokenSymbol,
        decimal: decimal
      }
    })
    setNetworkInfo(networkInfoInitial)
  }, [shouldResetTable, data])

  useEffect(() => {
    if (instanceProfileError && instanceProfileError.error) {
      let errorMessage
      const additionalData =
        instanceProfileError.error?.response?.data?.error?.additionalData
      if (additionalData) {
        if (typeof additionalData === 'string') {
          errorMessage = additionalData
        } else {
          const additionalErrors = Object.values(additionalData)
          errorMessage = additionalErrors?.length && additionalErrors[0]
        }
      } else {
        errorMessage = instanceProfileError.error.message
      }

      Toast('error', errorMessage || GENERAL_ERROR)
    } else if (
      instanceProfileError &&
      instanceProfileError.type === ADD_NETWORK &&
      instanceProfileError.error === null
    ) {
      Toast('success', REDEPLOYMENT_SUCCESS)
    }
  }, [instanceProfileError])

  function cancelEdit() {
    setIsEditActive(false)
    setShouldResetTable((prev) => !prev)
    setNewNetworkInfo([])
  }
  const { networkCards, networkValidationSchema } = useManageNetwork()
  const columns: any = [
    {
      name: (
        <div className={styles.headerContainer}>
          <TableHeader title="Configured Network" />
        </div>
      ),
      selector: function getAssetRow(row) {
        return <div>{row.name}</div>
      },
      allowOverflow: false
    },
    {
      name: (
        <div className={styles.headerContainer}>
          <TableHeader title="Token Address" />
        </div>
      ),
      selector: function getAssetRow(row) {
        return (
          <div className={styles.addressContainer}>
            {addressTruncate(row.tokenAddress) || ''}
            <Copy copyText={row.tokenAddress || ''} color={IconColor.Primary} />
          </div>
        )
      },
      allowOverflow: false
    },
    {
      name: (
        <div className={styles.headerContainer}>
          <TableHeader title="Token Symbol" />
        </div>
      ),
      selector: function getAssetRow(row) {
        return <div>{row.tokenSymbol}</div>
      },
      allowOverflow: false
    },
    {
      name: (
        <div className={styles.headerContainer}>
          <TableHeader title="Decimal" />
        </div>
      ),
      selector: function getAssetRow(row) {
        return <div>{row.decimal}</div>
      },
      allowOverflow: false
    }
  ]

  const [instanceNetworks, setInstanceNetworks] = useState([])
  const [tokenSymbols, setTokenSymbols] = useState([])

  const { getSelectionOptionsByCategory, selectionOptions } = useFancyState()
  async function loadSelectionOptions() {
    const options = await getSelectionOptionsByCategory('NetworkTicker')
    const tokenSymbols = options.map((option) => {
      return option.name
    })

    const options2 = await getSelectionOptionsByCategory('Network')
    const instanceNetworkNames = options2.map((option) => {
      return option.name
    })

    setInstanceNetworks(instanceNetworkNames)
    setTokenSymbols(tokenSymbols)
  }

  useEffect(() => {
    loadSelectionOptions()
  }, [selectionOptions])

  function setOptions(inputName: string) {
    let addedNetworkNames
    switch (inputName) {
      case 'selectNetwork':
        addedNetworkNames = networkInfo.map((network) => {
          return network.name
        })
        return instanceNetworks.filter((network) => {
          return !addedNetworkNames.includes(network)
        })
      case 'tokenSymbol':
        return tokenSymbols
      default:
        return []
    }
  }
  function getDropDownComponent({
    form,
    field,
    name,
    excludedValid,
    disabled,
    ...restProps
  }) {
    const inputName = name || field?.name
    const hasError = form?.touched[inputName] && form?.errors[inputName]
    const isValid =
      form?.touched[inputName] && form?.values[inputName] && !hasError
    const options = setOptions(inputName)
    return (
      <CustomDropDown
        className={styles.fieldContainer}
        inputName={inputName}
        options={options}
        error={hasError}
        isValid={!excludedValid && !!isValid}
        disabled={newNetworkInfo?.length > 0}
        {...field}
        {...restProps}
      />
    )
  }
  function renderFields(field) {
    {
      switch (field.type) {
        case 'text':
          return (
            <Field
              className={`${
                newNetworkInfo?.length > 0 && styles.fieldContainerDisable
              } ${styles.fieldContainer}
              `}
              key={field.name}
              {...field}
              component={InputField}
              disabled={newNetworkInfo?.length > 0}
            />
          )

        case 'dropdown':
          return (
            <Field
              component={getDropDownComponent}
              className={styles.fieldContainer}
              {...field}
            />
          )
        default:
          return null
      }
    }
  }
  const initialValues = {
    selectNetwork: '',
    tokenAddress: '',
    tokenSymbol: '',
    decimal: ''
  }
  async function onSaveNetwork(values) {
    const { decimal, selectNetwork, tokenAddress, tokenSymbol } = values
    const payload = {
      decimal: decimal,
      network: selectNetwork,
      tokenAddress: tokenAddress,
      tokenSymbol: tokenSymbol
    }
    await addInstanceNetwork(data.id, payload)
    setIsInstanceProfUpdated((prev) => !prev)
  }

  const noNetworksToConfigure = instanceNetworks.every((name) =>
    networkInfo.some((network) => network.name === name)
  )

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values, { resetForm }) => {
        resetForm()
      }}
      enableReinitialize
      validationSchema={networkValidationSchema}
    >
      {({ errors, dirty, values, resetForm, setFieldError }) => (
        <Form className={styles.form}>
          <Paper classes={{ root: styles.boxPaper }}>
            <div className={styles.actionWrapper}>
              <div className={styles.header}>
                <div className={styles.title}>
                  <h4 className="bold">Manage Network(s)</h4>
                </div>
                {true && (
                  <div className={styles.actions}>
                    {isEditActive ? (
                      <div className={styles.editActions}>
                        <CustomButton
                          buttonType="link"
                          color="primary"
                          className={styles.actionButton}
                          onClick={() => {
                            cancelEdit()
                            resetForm()
                          }}
                        >
                          Cancel
                        </CustomButton>
                        <Divider
                          orientation="vertical"
                          flexItem
                          variant="fullWidth"
                          className={styles.divider}
                        />

                        <CustomButton
                          buttonType="link"
                          color="primary"
                          className={styles.actionButton}
                          disabled={newNetworkInfo?.length <= 0}
                          type="submit"
                          onClick={async () => {
                            await onSaveNetwork(values)
                            setIsEditActive(false)
                            setNewNetworkInfo([])
                            resetForm()
                          }}
                        >
                          Add Network
                        </CustomButton>
                      </div>
                    ) : (
                      <CustomButton
                        buttonType="link"
                        color="primary"
                        className={
                          (data.status !== INSTANCE_STATUS.ACTIVE ||
                            noNetworksToConfigure) &&
                          styles.hideButton
                        }
                        onClick={() => {
                          setIsEditActive(true)
                        }}
                      >
                        Add Network
                      </CustomButton>
                    )}
                  </div>
                )}
              </div>

              <>
                {isEditActive && data && networkInfo && (
                  <div className={styles.networkPaper}>
                    <div className={`${styles.tableBody}`}>
                      <>
                        <div
                          className={`${styles.manageInfoContainer} ${styles.edit}`}
                        >
                          <div className={styles.manageInfoInputContainer}>
                            <Grid container spacing={3}>
                              <>
                                {networkCards.fields.map(
                                  (field: any, index: number) => (
                                    <Grid item xs={6} key={field.name}>
                                      <div key={`field_${index}`}>
                                        <div className={styles.manageInfoLabel}>
                                          {field.title}
                                        </div>
                                        {renderFields(field)}
                                      </div>
                                    </Grid>
                                  )
                                )}
                                <Grid item xs={12}>
                                  <CustomButton
                                    buttonType="solid"
                                    type="button"
                                    onClick={() => {
                                      const newNetworkInfo = {
                                        name: values.selectNetwork,
                                        tokenAddress: values.tokenAddress,
                                        tokenSymbol: values.tokenSymbol,
                                        decimal: values.decimal
                                      }
                                      setNewNetworkInfo([newNetworkInfo])
                                      setNetworkInfo((prev) => {
                                        return [...prev, newNetworkInfo]
                                      })
                                    }}
                                    disabled={
                                      !dirty ||
                                      Object.getOwnPropertyNames(errors)
                                        .length > 0 ||
                                      newNetworkInfo?.length > 0
                                    }
                                    className={`${styles.addButton}`}
                                  >
                                    Add to Table
                                  </CustomButton>
                                </Grid>
                              </>
                            </Grid>
                          </div>
                        </div>
                      </>
                    </div>
                  </div>
                )}
                {noNetworksToConfigure && (
                  <div className={styles.message}>
                    <HelperMessage
                      className={styles.helperMsg}
                      message={'No more networks to configure'}
                      isInfo
                    />
                  </div>
                )}
                <div className={styles.manageNetwork}>
                  {networkInfo?.length > 0 && (
                    <div className={styles.networkTable}>
                      <Table
                        columns={columns}
                        data={networkInfo}
                        responsive
                        emptyMessage="No network found."
                        pagination={undefined}
                        paginationPerPage={undefined}
                      />
                    </div>
                  )}
                </div>
              </>
            </div>
          </Paper>
        </Form>
      )}
    </Formik>
  )
}

export default ManageNetwork
