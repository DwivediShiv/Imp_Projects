import { useCallback, useState } from 'react'
import axios from 'axios'
import { InstanceProfile, InstanceProfileError } from '../types/InstanceProfile'
import appConfig from 'app.config'
import { convertDate } from '@utils/conversion'
import {
  ADD_NETWORK,
  FETCH_PROFILE,
  UNEXPECTED_ERROR,
  UPDATE_STATUS,
  UPDATE_VERSION
} from '../constants'

export interface InstanceProfileResponse {
  data: InstanceProfile
}

const instanceProfileApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/instance/id`

function instanceProfileUrl(id: string): string {
  return [instanceProfileApiUrl, id].join(`/`)
}

function getUpdateVersionUrl(id, version) {
  return [instanceProfileApiUrl, id, 'version', version].join(`/`)
}

function getAddNetworkUrl(id) {
  return [instanceProfileApiUrl, id, 'network/'].join(`/`)
}

function updateInstanceStatusUrl(id, status) {
  return [instanceProfileApiUrl, id, 'status', status].join(`/`)
}
export default function useInstanceProfileApi() {
  const [instanceProfileData, setInstanceProfileData] =
    useState<InstanceProfile | null>(null)

  const [instanceProfileError, setInstanceProfileError] =
    useState<InstanceProfileError | null>(null)

  const [isInstanceProfUpdated, setIsInstanceProfUpdated] =
    useState<boolean>(false)

  const [instanceDetailErrorCode, setInstanceDetailErrorCode] = useState<
    string | null
  >('')
  const [initialLoader, setInitialLoader] = useState<boolean>(true)

  const fetchInstanceProfile = useCallback(async (instanceID: string) => {
    try {
      const response = await axios.get(instanceProfileUrl(instanceID))

      response.data.createdAt = convertDate(
        response.data.createdAt,
        'DD MMM yyyy'
      )

      setInstanceProfileData(response.data)
      setInitialLoader(false)
    } catch (error) {
      setInitialLoader(false)
      setInstanceDetailErrorCode(error?.response?.data?.code || 'General')
      setInstanceProfileError({
        type: FETCH_PROFILE,
        error: { message: error?.response?.data?.error?.message }
      })
    }
  }, [])

  const updateInstanceStatus = async (
    instanceID: string,
    status,
    setToggling
  ) => {
    try {
      const { data: response } = await axios.patch(
        updateInstanceStatusUrl(instanceID, status)
      )
      setInstanceProfileError({
        type: UPDATE_STATUS,
        error: null
      })
    } catch (error) {
      setInstanceProfileError({
        type: UPDATE_STATUS,
        error: { message: error?.response?.data?.error?.message }
      })
    } finally {
      setToggling(false)
    }
  }

  const updateInstanceVersion = useCallback(
    async (instanceID: string, version) => {
      try {
        const { data: response } = await axios.patch(
          getUpdateVersionUrl(instanceID, version)
        )
        setInstanceProfileError({
          type: UPDATE_VERSION,
          error: null
        })
        return response.data
      } catch (error) {
        setInstanceProfileError({
          type: UPDATE_VERSION,
          error: { message: error?.response?.data?.error?.message }
        })
      }
    },
    []
  )

  const addInstanceNetwork = useCallback(
    async (instanceID: string, payload) => {
      try {
        const { data: response } = await axios.patch(
          getAddNetworkUrl(instanceID),
          payload
        )

        setInstanceProfileError({
          type: ADD_NETWORK,
          error: null
        })
      } catch (error) {
        setInstanceProfileError({
          type: ADD_NETWORK,
          error: { message: error?.response?.data?.error?.message }
        })
      }
    },
    []
  )

  return {
    instanceProfileData,
    instanceProfileError,
    setInstanceProfileData,
    fetchInstanceProfile,
    updateInstanceStatus,

    isInstanceProfUpdated,
    setIsInstanceProfUpdated,
    addInstanceNetwork,
    updateInstanceVersion,
    instanceDetailErrorCode,
    initialLoader
  }
}
