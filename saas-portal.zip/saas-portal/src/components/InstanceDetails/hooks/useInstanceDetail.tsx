import React, { ChangeEvent, useEffect, useMemo, useState } from 'react'
import styles from '../index.module.css'
import { InstanceProfile } from '../types/InstanceProfile'
import useInstanceDetailApi from './useInstanceDetailApi'

import Toast from '@sharedComponents/Toast'
import CustomDropDown from '@sharedComponents/Dropdown'

import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import { ReactElement } from 'react-markdown'
import CustomSwitch from '@sharedComponents/Switch'
import { INSTANCE_STATUS, STATUS_CONSTANTS } from '@constants/constants'
import {
  GENERAL_ERROR,
  STATUS_UPDATED,
  UPDATE_STATUS,
  UPDATE_VERSION,
  VERSION_DEPLOYED_SUCCESS
} from '../constants'
import NewStatusBox from '@sharedComponents/StatusFancy'
import Loader from '@sharedComponents/Loader'

export default function useOrgCards(instanceVersions) {
  const { updateInstanceStatus, instanceProfileError, updateInstanceVersion } =
    useInstanceDetailApi()
  const [showEdit, setShowEdit] = useState<boolean>(false)
  const [toggling, setToggling] = useState<boolean>(false)
  const TimeWithCustomFormat = WithCustomFormat(Time)

  useEffect(() => {
    if (instanceProfileError && instanceProfileError.error) {
      let errorMessage
      const additionalData =
        instanceProfileError.error?.response?.data?.error?.additionalData
      if (additionalData) {
        if (typeof additionalData === 'string') {
          errorMessage = additionalData
        } else {
          const additionalErrors = Object.values(additionalData)
          errorMessage = additionalErrors?.length && additionalErrors[0]
        }
      } else {
        errorMessage = instanceProfileError.error.message
      }

      Toast('error', errorMessage || GENERAL_ERROR)
    } else if (
      instanceProfileError &&
      instanceProfileError.type === UPDATE_VERSION &&
      instanceProfileError.error === null
    ) {
      Toast('success', VERSION_DEPLOYED_SUCCESS)
    } else if (
      instanceProfileError &&
      instanceProfileError.type === UPDATE_STATUS &&
      instanceProfileError.error === null
    ) {
      Toast('success', STATUS_UPDATED)
    }
  }, [instanceProfileError])

  const onSwitchChange = async (
    event: ChangeEvent<HTMLInputElement>,
    setInstanceProfUpdated,
    isActive,
    id
  ) => {
    const status = isActive ? INSTANCE_STATUS.INACTIVE : INSTANCE_STATUS.ACTIVE
    setToggling(true)
    await updateInstanceStatus(id, status, setToggling)
    setInstanceProfUpdated((prev) => !prev)
  }

  const StatusElement = ({ status }) => {
    return (
      <article className={styles.statusField}>
        {(status && <NewStatusBox status={status.toLowerCase()} />) || '-'}
      </article>
    )
  }
  const switchElement = (
    instanceProfile,
    isEditActive,
    setInstanceProfUpdated
  ): ReactElement => {
    let isActive = false
    setShowEdit(false)

    if (instanceProfile?.status === INSTANCE_STATUS.ACTIVE) {
      isActive = true
      setShowEdit(true)
    }

    return (
      <div className={styles.customSwitch}>
        {toggling ? (
          <div className={styles.smallloader}>
            <Loader />
          </div>
        ) : (
          <CustomSwitch
            size="small"
            defaultChecked={false}
            checked={isActive}
            onChange={(e) =>
              onSwitchChange(
                e,
                setInstanceProfUpdated,
                isActive,
                instanceProfile.id
              )
            }
            disabled={isEditActive}
            label={isActive ? 'Active' : 'Inactive'}
            className={isEditActive && styles.inactiveToggle}
          />
        )}
      </div>
    )
  }

  const instanceCards = useMemo(
    () => [
      {
        title: 'Instance Details',
        // isEditable: showEdit,
        fields: [
          {
            type: 'text',
            name: 'instanceName',
            previewTitle: 'Instance Name',
            getValue: (instanceProfile: InstanceProfile) => {
              return instanceProfile?.name || ''
            }
          },
          {
            type: 'text',
            name: 'customerName',
            previewTitle: 'Customer Name',
            getValue: (instanceProfile: InstanceProfile) => {
              return instanceProfile?.customerName || ''
            }
          },
          {
            type: 'text',
            name: 'status',
            previewTitle: 'Status',
            getValue: (
              instanceProfile: InstanceProfile,
              isEditActive,
              setInstanceProfUpdated
            ) => {
              if (
                [INSTANCE_STATUS.ACTIVE, INSTANCE_STATUS.INACTIVE].includes(
                  instanceProfile.status
                )
              ) {
                return switchElement(
                  instanceProfile,
                  isEditActive,
                  setInstanceProfUpdated
                )
              }
              setShowEdit(false)
              return <StatusElement status={instanceProfile?.status || ''} />
            }
          },
          {
            type: 'text',
            name: 'region',
            previewTitle: 'Region',
            getValue: (instanceProfile: InstanceProfile) => {
              return instanceProfile?.region || ''
            }
          },
          {
            type: 'text',
            name: 'version',
            previewTitle: 'Version',
            // editActiveType: 'custom',
            getValue: (instanceProfile: InstanceProfile) =>
              instanceProfile?.version
            // getComponent: ({
            //   data,
            //   isEditActive = false,
            //   field,
            //   form,
            //   name,
            //   excludedValid,
            //   disabled,
            //   ...restProps
            // }) => {
            //   const inputName = name || field?.name
            //   const hasError =
            //     form?.touched[inputName] && form?.errors[inputName]
            //   const isValid =
            //     form?.touched[inputName] && form?.values[inputName] && !hasError
            //   const options = instanceVersions?.map(
            //     (version) => version.Version
            //   )
            //   return (
            //     <>
            //       {instanceVersions?.length ? (
            //         <CustomDropDown
            //           inputName={inputName}
            //           options={options || []}
            //           error={hasError}
            //           isValid={!excludedValid && !!isValid}
            //           disabled={disabled}
            //           {...field}
            //           {...restProps}
            //         />
            //       ) : (
            //         ''
            //       )}
            //     </>
            //   )
            // }
          },
          {
            type: 'text',
            name: 'account',
            previewTitle: 'AWS Account',
            // editActiveType: 'custom',
            getValue: (instanceProfile: InstanceProfile) =>
              instanceProfile?.awsAccount
          },
          {
            type: 'text',
            name: 'customDomain',
            previewTitle: 'Custom Domain',
            getValue: (instanceProfile: InstanceProfile) => (
              <div>{instanceProfile?.customDomain}</div>
            )
          },
          {
            type: 'text',
            name: 'customEmailDomain',
            previewTitle: 'Custom Email Domain',
            getValue: (instanceProfile: InstanceProfile) => (
              <div>{instanceProfile?.customEmailDomain}</div>
            )
          },
          {
            type: 'text',
            name: 'contactEmail',
            previewTitle: 'Contact Email',
            getValue: (orgProfille: InstanceProfile) => {
              return orgProfille?.contactEmail || ''
            }
          },

          {
            type: 'text',
            name: 'createdBy',
            previewTitle: 'Created By',
            getValue: (instanceProfile: InstanceProfile) => {
              return instanceProfile?.createdBy || ''
            }
          }
        ],
        getDefaultValues: (instanceProfile: InstanceProfile) => {
          return {
            version: instanceProfile?.version
          }
        },
        onSave: async (values, instanceProfile, isInstanceProfUpdated) => {
          const { version } = values
          await updateInstanceVersion(instanceProfile?.id, version)
          isInstanceProfUpdated((prev) => !prev)
        }
      }
    ],
    [TimeWithCustomFormat, showEdit, instanceVersions]
  )

  return { instanceCards }
}
