export const UPDATE_STATUS = 'UPDATE_STATUS'
export const FETCH_PROFILE = 'FETCH_PROFILE'
export const UPDATE_VERSION = 'UPDATE_VERSION'
export const ADD_NETWORK = 'ADD_NETWORK'
export const UNEXPECTED_ERROR = 'unexpected error'
export const GENERAL_ERROR = 'Something went wrong please try again!'
export const REDEPLOYMENT_SUCCESS = `Successful. Instance Redeployment has been triggered. 
This may take sometime for Redeployment.`

export const VERSION_DEPLOYED_SUCCESS = 'Successful. New version is deployed.'
export const STATUS_UPDATED = 'Successful. Status updated.'
