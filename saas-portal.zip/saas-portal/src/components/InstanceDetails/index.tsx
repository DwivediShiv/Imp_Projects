import React, { ReactElement, useEffect, useState } from 'react'
import { Grid } from '@mui/material'

import styles from './index.module.css'
import { useRouter } from 'next/router'
import BackIcon from '@images/back_icon.svg'
import useInstanceDetailApi from './hooks/useInstanceDetailApi'
import { useAuthorize } from '@core/context/Authorize'
import useOrgCards from './hooks/useInstanceDetail'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_INFRAMANAGER,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import CustomButton from '@sharedComponents/Button'
import Permission from '@sharedComponents/Permission'
import GridCard from '@sharedComponents/GridCard'
import PrivateRoute from '@sharedComponents/PrivateRoute'

import ManageNetwork from './components/ManageNetwork'
import useCreateInstanceApi from '../InstanceAdd/hooks/useCreateInstanceApi'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Warning from '@sharedComponents/WarningMessage'
import Loader from '@sharedComponents/CustomLoader'

export default function InstanceDetails({
  instanceId
}: {
  instanceId: string
}): ReactElement {
  const { isLogin } = useAuthorize()
  const router = useRouter()
  const { fetchInstanceVersions, instanceVersions } = useCreateInstanceApi()

  useEffect(() => {
    if (isLogin) {
      fetchInstanceVersions()
    }
  }, [isLogin])

  const {
    instanceProfileData,
    instanceProfileError,
    fetchInstanceProfile,
    isInstanceProfUpdated,
    setIsInstanceProfUpdated,
    instanceDetailErrorCode,
    initialLoader
  } = useInstanceDetailApi()

  const { instanceCards } = useOrgCards(instanceVersions)

  useEffect(() => {
    if (isLogin) {
      fetchInstanceProfile(instanceId)
    }
  }, [fetchInstanceProfile, instanceId, isLogin, isInstanceProfUpdated])

  function handleClick() {
    router.back()
  }
  function renderOrgProfileData() {
    if (instanceProfileError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = instanceProfileError?.error?.message

      const isUnauthorize = instanceDetailErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    if (!instanceProfileData) {
      return null
    }

    return (
      <>
        <div className={styles.companyHeader}>
          <h2>{instanceProfileData.name}</h2>
          <h3>Created on {instanceProfileData.createdAt}</h3>
        </div>
        <Grid
          className={styles.content}
          container
          rowSpacing={4}
          columnSpacing={3}
        >
          {instanceCards.map((cardConfig, index) => {
            return (
              <Grid key={index} item xs={12} md={12} lg={8}>
                <GridCard
                  cardConfig={cardConfig}
                  data={instanceProfileData}
                  setStateData={setIsInstanceProfUpdated}
                />
              </Grid>
            )
          })}
          <Grid item xs={12} md={12} lg={8}>
            <ManageNetwork
              data={instanceProfileData}
              setIsInstanceProfUpdated={setIsInstanceProfUpdated}
            />
          </Grid>
        </Grid>
      </>
    )
  }

  return (
    <PrivateRoute>
      <>
        <Permission eventType={PERMISSION_INFRAMANAGER} isBigBoardError>
          {initialLoader ? (
            <div className={styles.loader}>
              <Loader />
            </div>
          ) : (
            <>
              {!instanceProfileError && (
                <CustomButton onClick={handleClick} aria-label="Go Back">
                  <BackIcon />
                </CustomButton>
              )}
              {renderOrgProfileData()}
            </>
          )}
        </Permission>
      </>
    </PrivateRoute>
  )
}
