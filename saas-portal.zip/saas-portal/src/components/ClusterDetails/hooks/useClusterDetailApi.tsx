import { useCallback, useState } from 'react'
import axios from 'axios'
import { ClusterProfile, InstanceProfileError } from '../types/ClusterProfile'
import appConfig from 'app.config'
import { convertDate } from '@utils/conversion'
import {
  ADD_NETWORK,
  DELETE_CLUSTER,
  FETCH_PROFILE,
  UPDATE_STATUS,
  UPDATE_VERSION
} from '../constants'
import Toast from '@saasportal/libs/sharedComponents/Toast'

export interface ClusterProfileResponse {
  data: ClusterProfile
}

const clusterProfileApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/cluster/id`
function clusterProfileUrl(id: string): string {
  return [clusterProfileApiUrl, id].join(`/`)
}
function getUpdateVersionUrl(id, version) {
  return [clusterProfileApiUrl, id, 'version', version].join(`/`)
}

function getAddNetworkUrl(id) {
  return [clusterProfileApiUrl, id, 'network'].join(`/`)
}

function updateInstanceStatusUrl(id, status) {
  return [clusterProfileApiUrl, id, 'status', status].join(`/`)
}

export default function useClusterProfileApi() {
  const [instanceProfileData, setInstanceProfileData] = useState(null)

  const [instanceProfileError, setInstanceProfileError] =
    useState<InstanceProfileError | null>(null)

  const [isInstanceProfUpdated, setIsInstanceProfUpdated] =
    useState<boolean>(false)

  const [instanceDetailErrorCode, setInstanceDetailErrorCode] = useState<
    string | null
  >('')
  const [initialLoader, setInitialLoader] = useState<boolean>(true)

  const fetchClusterProfile = useCallback(async (clusterID: string) => {
    try {
      const response = await axios.get(clusterProfileUrl(clusterID))
      response.data.createdAt = convertDate(
        response.data.createdAt,
        'DD MMM yyyy'
      )
      const clusterStatusMap = {
        success: ['Active'],
        deploying: [
          'Provisioned',
          'Version Deployment In Progress',
          'Network Deployment In Progress'
        ],
        failed: [
          'Build Failed',
          'Deletion Failed',
          'Network Deployment Failed',
          'Version Deployment Failed'
        ],
        deleting: ['Deletion In Progress'],
        deleted: ['Deleted']
      }

      const updateClusterStatus = (status: string) => {
        for (const key in clusterStatusMap) {
          if (clusterStatusMap[key].includes(status)) {
            return key
          }
        }
      }

      response.data.status = updateClusterStatus(response?.data?.status)
      setInstanceProfileData(response?.data)
      setInitialLoader(false)
    } catch (error) {
      setInitialLoader(false)
      setInstanceDetailErrorCode(error?.response?.data?.code || 'General')
      setInstanceProfileError({
        type: FETCH_PROFILE,
        error: { message: error?.response?.data?.error?.message }
      })
    }
  }, [])

  const updateInstanceStatus = async (
    instanceID: string,
    status,
    setToggling
  ) => {
    try {
      const { data: response } = await axios.patch(
        updateInstanceStatusUrl(instanceID, status)
      )
      setInstanceProfileError({
        type: UPDATE_STATUS,
        error: null
      })
    } catch (error) {
      setInstanceProfileError({
        type: UPDATE_STATUS,
        error: { message: error?.response?.data?.error?.message }
      })
    } finally {
      setToggling(false)
    }
  }

  const updateInstanceVersion = useCallback(
    async (clusterID: string, version, setIsEditActive) => {
      try {
        const { data: response } = await axios.patch(
          getUpdateVersionUrl(clusterID, version)
        )
        setIsEditActive(false)
        setInstanceProfileError({
          type: UPDATE_VERSION,
          error: null
        })
        return response.data
      } catch (error) {
        Toast('error', error?.response?.data?.error?.message)
      }
    },
    []
  )

  const addInstanceNetwork = useCallback(
    async (clusterID: string, payload, setIsEditActive) => {
      try {
        const { data: response } = await axios.patch(
          getAddNetworkUrl(clusterID),
          payload
        )
        setIsEditActive(false)
        setInstanceProfileError({
          type: ADD_NETWORK,
          error: null
        })
      } catch (error) {
        Toast('error', error?.response?.data?.error?.message)
      }
    },
    []
  )

  const deleteCluster = async (clusterId, setConfirmLoader) => {
    try {
      setConfirmLoader(true)
      const response = await axios.delete(clusterProfileUrl(clusterId))
      setConfirmLoader(false)
    } catch (error) {
      setConfirmLoader(false)
      Toast('error', error?.response?.data?.error?.message)
    }
  }

  return {
    instanceProfileData,
    instanceProfileError,
    setInstanceProfileData,
    fetchClusterProfile,
    updateInstanceStatus,
    isInstanceProfUpdated,
    setIsInstanceProfUpdated,
    addInstanceNetwork,
    updateInstanceVersion,
    instanceDetailErrorCode,
    initialLoader,
    deleteCluster
  }
}
