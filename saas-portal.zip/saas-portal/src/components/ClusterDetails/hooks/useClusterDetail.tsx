import React, { useEffect, useMemo } from 'react'
import styles from '../index.module.css'
import { ClusterProfile } from '../types/ClusterProfile'
import useInstanceDetailApi from './useClusterDetailApi'

import Toast from '@sharedComponents/Toast'
import CustomDropDown from '@sharedComponents/Dropdown'

import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import {
  GENERAL_ERROR,
  RESTRICT_EDIT_STATES,
  STATUS_UPDATED,
  UPDATE_STATUS,
  UPDATE_VERSION,
  VERSION_DEPLOYED_SUCCESS
} from '../constants'
import NewStatusBox from '@saasportal/libs/sharedComponents/StatusFancy'

export default function useOrgCards(instanceVersions, instanceStatus) {
  const { instanceProfileError, updateInstanceVersion } = useInstanceDetailApi()
  const TimeWithCustomFormat = WithCustomFormat(Time)

  useEffect(() => {
    if (instanceProfileError && instanceProfileError.error) {
      let errorMessage
      const additionalData =
        instanceProfileError.error?.response?.data?.error?.additionalData
      if (additionalData) {
        if (typeof additionalData === 'string') {
          errorMessage = additionalData
        } else {
          const additionalErrors = Object.values(additionalData)
          errorMessage = additionalErrors?.length && additionalErrors[0]
        }
      } else {
        errorMessage = instanceProfileError.error.message
      }

      Toast('error', errorMessage || GENERAL_ERROR)
    } else if (
      instanceProfileError &&
      instanceProfileError.type === UPDATE_VERSION &&
      instanceProfileError.error === null
    ) {
      Toast('success', VERSION_DEPLOYED_SUCCESS)
    } else if (
      instanceProfileError &&
      instanceProfileError.type === UPDATE_STATUS &&
      instanceProfileError.error === null
    ) {
      Toast('success', STATUS_UPDATED)
    }
  }, [instanceProfileError])

  const StatusElement = ({ status }) => {
    return (
      <article className={styles.statusField}>
        {(status && <NewStatusBox status={status.toLowerCase()} />) || '-'}
      </article>
    )
  }

  const instanceCards = useMemo(
    () => [
      {
        title: 'Cluster Details',
        isEditable: !RESTRICT_EDIT_STATES.includes(instanceStatus),
        fields: [
          {
            type: 'text',
            name: 'status',
            previewTitle: 'Status',
            getValue: (clusterProfile: ClusterProfile) => {
              return <StatusElement status={clusterProfile?.status || ''} />
            }
          },
          {
            type: 'text',
            name: 'version',
            previewTitle: 'Cluster Version',
            editActiveType: 'custom',
            getValue: (clusterProfile: ClusterProfile) =>
              clusterProfile?.version,
            getComponent: ({
              data,
              isEditActive = false,
              field,
              form,
              name,
              excludedValid,
              disabled,
              ...restProps
            }) => {
              const inputName = name || field?.name
              const hasError =
                form?.touched[inputName] && form?.errors[inputName]
              const isValid =
                form?.touched[inputName] && form?.values[inputName] && !hasError
              const options = instanceVersions?.map(
                (version) => version.Version
              )
              return (
                <>
                  {instanceVersions?.length ? (
                    <CustomDropDown
                      inputName={inputName}
                      options={options || []}
                      error={hasError}
                      isValid={!excludedValid && !!isValid}
                      disabled={disabled}
                      {...field}
                      {...restProps}
                    />
                  ) : (
                    ''
                  )}
                </>
              )
            }
          },
          {
            type: 'text',
            name: 'Region',
            previewTitle: 'Region',
            getValue: (clusterProfile: ClusterProfile) => {
              return clusterProfile?.region || ''
            }
          },
          {
            type: 'text',
            name: 'contactEmail',
            previewTitle: 'No. of Instance Deployed',
            getValue: (clusterProfile: ClusterProfile) => {
              return clusterProfile?.numberOfInstances ?? ''
            }
          },
          {
            type: 'text',
            name: 'account',
            previewTitle: 'AWS Account',
            // editActiveType: 'custom',
            getValue: (clusterProfile: ClusterProfile) =>
              clusterProfile?.awsAccount
          },
          {
            type: 'text',
            name: 'createdBy',
            previewTitle: 'Created By',
            getValue: (clusterProfile: ClusterProfile) => {
              return clusterProfile?.createdBy || ''
            }
          },
          {
            type: 'text',
            name: 'createdOn',
            previewTitle: 'Created On',
            getValue: (clusterProfile: ClusterProfile) => {
              return clusterProfile?.createdAt || ''
            }
          }
        ],
        getDefaultValues: (clusterProfile: ClusterProfile) => {
          return {
            version: clusterProfile?.version
          }
        },
        onSave: async (
          values,
          clusterProfile,
          isInstanceProfUpdated,
          setIsEditActive
        ) => {
          const { version } = values
          await updateInstanceVersion(
            clusterProfile?.id,
            version,
            setIsEditActive
          )
          isInstanceProfUpdated((prev) => !prev)
        }
      }
    ],
    [TimeWithCustomFormat, instanceVersions, instanceStatus]
  )

  return { instanceCards }
}
