// TODO: validate fields matches with API response
export interface ClusterProfile {
  id: string
  name: string
  awsAccount: string
  region: string
  networks: any
  version: string
  status: string
  numberOfInstances: number
  createdAt: string
  createdBy: string
}
export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

export interface InstanceProfileError {
  type: string
  error: any
}
