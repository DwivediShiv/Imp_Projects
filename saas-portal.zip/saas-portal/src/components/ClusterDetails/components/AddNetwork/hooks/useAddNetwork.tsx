import { REQUIRED_FIELD } from '@constants/constants'
import { convertDate } from '@saasportal/libs/utils/conversion'
import { useMemo } from 'react'
import * as Yup from 'yup'

export default function useAddNetwork() {
  const networkValidationSchema: Yup.SchemaOf<any> = Yup.object().shape({
    network: Yup.string().required(REQUIRED_FIELD)
  })
  let today = new Date().toISOString().split('T')[0]
  today = convertDate(today, 'DD MMM yyyy')
  const networkCards = useMemo(
    () => ({
      title: 'Network Details',
      fields: [
        {
          name: 'network',
          title: 'Network',
          placeholder: 'E.g. Amoy, Sepolia',
          type: 'dropdown',
          required: true
        },
        {
          name: 'date',
          title: 'Add Date',
          type: 'static',
          defaultValue: today,
          readOnly: true
        }
      ]
    }),
    []
  )

  return { networkCards, networkValidationSchema }
}
