import { Paper, Divider } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { Field, Form, Formik } from 'formik'
import styles from './index.module.css'
import CustomButton from '@sharedComponents/Button'
import TableHeader from '@sharedComponents/TableHeader'
import useManageNetwork from './hooks/useAddNetwork'
import { Grid } from '@mui/material'
import Table from '@sharedComponents/Table'
import CustomDropDown from '@sharedComponents/Dropdown'
import InputField from '@sharedComponents/InputField'
import { useFancyState } from '@core/context/FancyState'
import useClusterProfileApi from '../../hooks/useClusterDetailApi'
import Toast from '@sharedComponents/Toast'
import {
  ADD_NETWORK,
  GENERAL_ERROR,
  REDEPLOYMENT_SUCCESS,
  RESTRICT_EDIT_STATES
} from '../../constants'
import HelperMessage from '@sharedComponents/HelperMessage'
import { convertDate } from '@utils/conversion'

const AddNetwork = ({ data, setIsInstanceProfUpdated }) => {
  const [isEditActive, setIsEditActive] = useState<boolean>(false)
  const [networkInfo, setNetworkInfo] = useState([])
  const [shouldResetTable, setShouldResetTable] = useState(false)
  const [newNetworkInfo, setNewNetworkInfo] = useState([])
  const { addInstanceNetwork, instanceProfileError } = useClusterProfileApi()

  useEffect(() => {
    const networkInfoInitial = data.networks?.map((networkInfo) => {
      const { network, createdAt } = networkInfo
      return {
        name: network,
        createdAt: convertDate(createdAt, 'DD MMM yyyy')
      }
    })
    setNetworkInfo(networkInfoInitial)
  }, [shouldResetTable, data])

  useEffect(() => {
    if (instanceProfileError && instanceProfileError.error) {
      let errorMessage
      const additionalData =
        instanceProfileError.error?.response?.data?.error?.additionalData
      if (additionalData) {
        if (typeof additionalData === 'string') {
          errorMessage = additionalData
        } else {
          const additionalErrors = Object.values(additionalData)
          errorMessage = additionalErrors?.length && additionalErrors[0]
        }
      } else {
        errorMessage = instanceProfileError.error.message
      }

      Toast('error', errorMessage || GENERAL_ERROR)
    } else if (
      instanceProfileError &&
      instanceProfileError.type === ADD_NETWORK &&
      instanceProfileError.error === null
    ) {
      Toast('success', REDEPLOYMENT_SUCCESS)
    }
  }, [instanceProfileError])

  function cancelEdit() {
    setIsEditActive(false)
    setShouldResetTable((prev) => !prev)
    setNewNetworkInfo([])
  }
  const { networkCards, networkValidationSchema } = useManageNetwork()
  const columns: any = [
    {
      name: (
        <div className={styles.headerContainer}>
          <TableHeader title="Network Name" />
        </div>
      ),
      selector: function getAssetRow(row) {
        return <div>{row.name}</div>
      },
      grow: 9,
      allowOverflow: false
    },
    {
      name: (
        <div className={styles.headerContainer}>
          <TableHeader title="Added on" />
        </div>
      ),
      selector: function getAssetRow(row) {
        return <div>{row.createdAt}</div>
      },
      grow: 1.5,
      allowOverflow: false
    }
  ]

  const [instanceNetworks, setInstanceNetworks] = useState([])
  const [tokenSymbols, setTokenSymbols] = useState([])

  const { getSelectionOptionsByCategory, selectionOptions } = useFancyState()
  async function loadSelectionOptions() {
    const options = await getSelectionOptionsByCategory('NetworkTicker')
    const tokenSymbols = options.map((option) => {
      return option.name
    })

    const options2 = await getSelectionOptionsByCategory('Network')
    const instanceNetworkNames = options2.map((option) => {
      return option.name
    })

    setInstanceNetworks(instanceNetworkNames)
    setTokenSymbols(tokenSymbols)
  }

  useEffect(() => {
    loadSelectionOptions()
  }, [selectionOptions])

  function setOptions(inputName: string) {
    let addedNetworkNames
    switch (inputName) {
      case 'network':
        addedNetworkNames = networkInfo.map((network) => {
          return network.name
        })
        return instanceNetworks.filter((network) => {
          return !addedNetworkNames.includes(network)
        })
      case 'tokenSymbol':
        return tokenSymbols
      default:
        return []
    }
  }
  function getDropDownComponent({
    form,
    field,
    name,
    excludedValid,
    disabled,
    ...restProps
  }) {
    const inputName = name || field?.name
    const hasError = form?.touched[inputName] && form?.errors[inputName]
    const isValid =
      form?.touched[inputName] && form?.values[inputName] && !hasError
    const options = setOptions(inputName)
    return (
      <CustomDropDown
        className={styles.fieldContainer}
        inputName={inputName}
        options={options}
        error={hasError}
        isValid={!excludedValid && !!isValid}
        disabled={newNetworkInfo?.length > 0}
        {...field}
        {...restProps}
      />
    )
  }
  function renderFields(field) {
    {
      switch (field.type) {
        case 'text':
          return (
            <Field
              className={`${
                newNetworkInfo?.length > 0 && styles.fieldContainerDisable
              } ${styles.fieldContainer}
              `}
              key={field.name}
              {...field}
              component={InputField}
              disabled={newNetworkInfo?.length > 0}
            />
          )

        case 'dropdown':
          return (
            <Field
              component={getDropDownComponent}
              className={styles.fieldContainer}
              {...field}
            />
          )
        default:
          return null
      }
    }
  }
  const initialValues = {
    network: ''
  }
  async function onSaveNetwork(values, setIsEditActive) {
    const { network } = values
    const payload = {
      network: network
    }
    await addInstanceNetwork(data.id, payload, setIsEditActive)
    setIsInstanceProfUpdated((prev) => !prev)
  }

  const noNetworksToConfigure = instanceNetworks.every((name) =>
    networkInfo.some((network) => network.name === name)
  )

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values, { resetForm }) => {
        resetForm()
      }}
      enableReinitialize
      validationSchema={networkValidationSchema}
    >
      {({ errors, dirty, values, resetForm, setFieldError }) => (
        <Form className={styles.form}>
          <Paper classes={{ root: styles.boxPaper }}>
            <div className={styles.actionWrapper}>
              <div className={styles.header}>
                <div className={styles.title}>
                  <h4 className="bold">Cluster Network</h4>
                </div>
                {true && (
                  <div className={styles.actions}>
                    {isEditActive ? (
                      <div className={styles.editActions}>
                        <CustomButton
                          buttonType="link"
                          color="primary"
                          className={styles.actionButton}
                          onClick={() => {
                            cancelEdit()
                            resetForm()
                          }}
                        >
                          Cancel
                        </CustomButton>
                        <Divider
                          orientation="vertical"
                          flexItem
                          variant="fullWidth"
                          className={styles.divider}
                        />

                        <CustomButton
                          buttonType="link"
                          color="primary"
                          className={styles.actionButton}
                          disabled={newNetworkInfo?.length <= 0}
                          processingLoader={true}
                          type="submit"
                          onClick={async () => {
                            await onSaveNetwork(values, setIsEditActive)
                            setNewNetworkInfo([])
                            resetForm()
                          }}
                        >
                          Save Changes
                        </CustomButton>
                      </div>
                    ) : (
                      <>
                        {!RESTRICT_EDIT_STATES.includes(data?.status) && (
                          <CustomButton
                            buttonType="link"
                            color="primary"
                            onClick={() => {
                              setIsEditActive(true)
                            }}
                          >
                            Edit
                          </CustomButton>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>

              <>
                {isEditActive && data && networkInfo && (
                  <div className={styles.networkPaper}>
                    <div className={`${styles.tableBody}`}>
                      <>
                        <div
                          className={`${styles.manageInfoContainer} ${styles.edit}`}
                        >
                          <div className={styles.manageInfoInputContainer}>
                            <Grid container spacing={3}>
                              <>
                                {networkCards.fields.map(
                                  (field: any, index: number) => (
                                    <Grid item xs={6} key={field.name}>
                                      <div
                                        key={`field_${index}`}
                                        className={styles.fieldContainer}
                                      >
                                        <div
                                          className={
                                            field.title === 'Add Date'
                                              ? styles.manageDateLabel
                                              : styles.manageInfoLabel
                                          }
                                        >
                                          {field.title}
                                        </div>
                                        {field.type === 'static' ? (
                                          <div className={styles.staticValue}>
                                            {field.defaultValue}
                                          </div>
                                        ) : (
                                          renderFields(field)
                                        )}
                                      </div>
                                    </Grid>
                                  )
                                )}
                                <Grid item xs={12}>
                                  <CustomButton
                                    buttonType="solid"
                                    type="button"
                                    onClick={() => {
                                      const today = new Date()
                                        .toISOString()
                                        .split('T')[0]
                                      const newNetworkInfo = {
                                        name: values.network,
                                        createdAt: convertDate(
                                          today,
                                          'DD MMM yyyy'
                                        )
                                      }
                                      setNewNetworkInfo([newNetworkInfo])
                                      setNetworkInfo((prev) => {
                                        return [...prev, newNetworkInfo]
                                      })
                                    }}
                                    disabled={
                                      !dirty ||
                                      Object.getOwnPropertyNames(errors)
                                        .length > 0 ||
                                      newNetworkInfo?.length > 0
                                    }
                                    className={`${styles.addButton}`}
                                  >
                                    Add to Table
                                  </CustomButton>
                                </Grid>
                              </>
                            </Grid>
                          </div>
                        </div>
                      </>
                    </div>
                  </div>
                )}
                {noNetworksToConfigure && (
                  <div className={styles.message}>
                    <HelperMessage
                      className={styles.helperMsg}
                      message={'No more networks to configure'}
                      isInfo
                    />
                  </div>
                )}
                <div className={styles.manageNetwork}>
                  {networkInfo?.length > 0 && (
                    <div className={styles.networkTable}>
                      <Table
                        columns={columns}
                        data={networkInfo}
                        responsive
                        emptyMessage="No network found."
                        pagination={undefined}
                        paginationPerPage={undefined}
                      />
                    </div>
                  )}
                </div>
              </>
            </div>
          </Paper>
        </Form>
      )}
    </Formik>
  )
}

export default AddNetwork
