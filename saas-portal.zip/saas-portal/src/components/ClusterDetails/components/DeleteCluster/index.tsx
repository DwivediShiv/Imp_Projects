import React, { useState } from 'react'
import styles from './index.module.css'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import CustomButton from '@sharedComponents/Button'
import Modal from '@sharedComponents/Modal'
import { IconSize } from '@utils/constants'
import Message from '@sharedComponents/Message'
import Loader from '@sharedComponents/Loader'

const DeleteCluster = ({ data, fetchClusterProfile, deleteCluster }) => {
  const [deleteModalOpen, setDeleteModalOpen] = useState<boolean>(false)
  const [confirmLoader, setConfirmLoader] = useState<boolean>(false)

  async function handleConfirmButtonClick() {
    await deleteCluster(data?.id, setConfirmLoader)
    setDeleteModalOpen(false)
    await fetchClusterProfile(data?.id)
  }

  return (
    <div className={styles.delistAssetContainer} id="delist-component">
      <div className={styles.deleteContainer}>
        <div className={styles.header}>
          <div className={styles.title}>
            <h4 className="bold">Delete Cluster</h4>
          </div>
        </div>
        <br />
        <div className={styles.deleteText}>
          <div data-testid="valid-order-captions">
            There are a total of{' '}
            <span className={`semibold`}>{data?.numberOfInstances}</span>{' '}
            instance(s) deployed in this cluster.
          </div>
          After deletion, you and the instance(s) will no longer have access to
          this cluster.
          <br />
          <br />
          If there are instances deployed in this cluster, you cannot perform
          deletion.
        </div>
      </div>

      <Message
        type="warning"
        showIcon
        color="outline"
        iconSize={IconSize.Medium}
        texts={['Please note that this action is irreversible.']}
        className={`mt-6 ${styles.warningMessage}`}
      />

      <CustomButton
        color="error"
        variant="text"
        className={styles.delistButton}
        onClick={() => {
          setDeleteModalOpen(true)
        }}
        data-testid="delist-button"
        disabled={
          data?.numberOfInstances > 0 ||
          data?.status === 'deleting' ||
          data?.status === 'deploying' ||
          data?.status === 'deleted'
        }
      >
        {data?.status === 'deleting' ? 'Deleting...' : 'Delete'}
      </CustomButton>

      {deleteModalOpen && (
        <Modal
          title={'Are you sure you want to delete this Cluster?'}
          titleSize="h3"
          type={CUSTOM_TYPE}
          onToggleModal={() => {
            setDeleteModalOpen(false)
          }}
          isOpen={deleteModalOpen}
          data-testid="delistAsset-Modal"
        >
          <div
            data-testid="warning-captions"
            className={`${data?.numberOfInstances > 0 ? 'mt-6' : 0}`}
          >
            By deleting, you and the instance(s) will no longer have access to
            this cluster.
          </div>
          <footer className={styles.delistAssetButtonFooter}>
            {confirmLoader ? (
              <div className={styles.loader}>
                <Loader />
              </div>
            ) : (
              <CustomButton
                color="secondary"
                variant="contained"
                onClick={handleConfirmButtonClick}
                data-testid="confirm-purchase-button"
              >
                Confirm
              </CustomButton>
            )}
          </footer>
        </Modal>
      )}
    </div>
  )
}
export default DeleteCluster
