import React, { ReactElement, useEffect, useState } from 'react'
import { Grid } from '@mui/material'

import styles from './index.module.css'
import { useRouter } from 'next/router'
import BackIcon from '@images/back_icon.svg'
import useInstanceDetailApi from './hooks/useClusterDetailApi'
import { useAuthorize } from '@core/context/Authorize'
import useOrgCards from './hooks/useClusterDetail'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_ADMIN,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import CustomButton from '@sharedComponents/Button'
import Permission from '@sharedComponents/Permission'
import GridCard from '@sharedComponents/GridCard'
import PrivateRoute from '@sharedComponents/PrivateRoute'

import AddNetwork from './components/AddNetwork'
import { CustomIconicCardState } from '@saasportal/libs/sharedComponents/IconicCard'
import Warning from '@saasportal/libs/sharedComponents/WarningMessage'
import Loader from '@saasportal/libs/sharedComponents/CustomLoader'
import DeleteCluster from './components/DeleteCluster'
import useCreateInstanceApi from '../InstanceAdd/hooks/useCreateInstanceApi'

export default function ClusterDetails({
  instanceId
}: {
  instanceId: string
}): ReactElement {
  const { isLogin } = useAuthorize()
  const router = useRouter()
  const { fetchInstanceVersions, instanceVersions } = useCreateInstanceApi()

  useEffect(() => {
    if (isLogin) {
      fetchInstanceVersions()
    }
  }, [isLogin])

  const {
    instanceProfileData,
    instanceProfileError,
    fetchClusterProfile,
    isInstanceProfUpdated,
    setIsInstanceProfUpdated,
    instanceDetailErrorCode,
    initialLoader,
    deleteCluster
  } = useInstanceDetailApi()
  const { instanceCards } = useOrgCards(
    instanceVersions,
    instanceProfileData?.status
  )

  useEffect(() => {
    if (isLogin) {
      fetchClusterProfile(instanceId)
    }
  }, [fetchClusterProfile, instanceId, isLogin, isInstanceProfUpdated])

  function handleClick() {
    router.back()
  }
  function renderOrgProfileData() {
    if (instanceProfileError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = instanceProfileError?.error?.message

      const isUnauthorize = instanceDetailErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    if (!instanceProfileData) {
      return null
    }

    return (
      <>
        <div className={styles.companyHeader}>
          <h2>{instanceProfileData.name}</h2>
          <h3>Created on {instanceProfileData.createdAt}</h3>
        </div>
        <Grid
          className={styles.content}
          container
          rowSpacing={4}
          columnSpacing={3}
        >
          {instanceCards.map((cardConfig, index) => {
            return (
              <Grid key={index} item xs={12} md={12} lg={8}>
                <GridCard
                  cardConfig={cardConfig}
                  data={instanceProfileData}
                  setStateData={setIsInstanceProfUpdated}
                />
              </Grid>
            )
          })}
          <Grid item xs={12} md={12} lg={8}>
            <AddNetwork
              data={instanceProfileData}
              setIsInstanceProfUpdated={setIsInstanceProfUpdated}
            />
          </Grid>
          <Grid item xs={12} md={12} lg={8}>
            <DeleteCluster
              data={instanceProfileData}
              fetchClusterProfile={fetchClusterProfile}
              deleteCluster={deleteCluster}
            />
          </Grid>
        </Grid>
      </>
    )
  }

  return (
    <PrivateRoute>
      <>
        <Permission eventType={PERMISSION_ADMIN} isBigBoardError>
          {initialLoader ? (
            <div className={styles.loader}>
              <Loader />
            </div>
          ) : (
            <>
              {!instanceProfileError && (
                <CustomButton onClick={handleClick} aria-label="Go Back">
                  <BackIcon />
                </CustomButton>
              )}
              {renderOrgProfileData()}
            </>
          )}
        </Permission>
      </>
    </PrivateRoute>
  )
}
