export const UPDATE_STATUS = 'UPDATE_STATUS'
export const FETCH_PROFILE = 'FETCH_PROFILE'
export const UPDATE_VERSION = 'UPDATE_VERSION'
export const DELETE_CLUSTER = 'DELETE_CLUSTER'
export const ADD_NETWORK = 'ADD_NETWORK'
export const UNEXPECTED_ERROR = 'unexpected error'
export const GENERAL_ERROR = 'Something went wrong please try again!'
export const REDEPLOYMENT_SUCCESS = `Cluster Redeployment has been triggered successfully. 
This may take sometime for Redeployment.`

export const VERSION_DEPLOYED_SUCCESS =
  'New version deployment triggered successfully.'
export const STATUS_UPDATED = 'Successful. Status updated.'
export const ICON_TYPE = 'ICON_TYPE'
export const CUSTOM_TYPE = 'CUSTOM_TYPE'
export const MODAL_TYPE_ORDER = 'MODAL_TYPE_ORDER'
export const MODAL_TYPE_CONFIRM = 'MODAL_TYPE_CONFIRM'

export const RESTRICT_EDIT_STATES = ['deploying', 'deleting', 'deleted']
