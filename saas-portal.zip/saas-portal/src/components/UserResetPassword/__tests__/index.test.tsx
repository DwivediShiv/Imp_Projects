import React from 'react'
import { fireEvent, render, screen } from '@testing-library/react'
import ResetForgetPwd from '..'
import { validationSchema } from '../hooks/usePasswordConfig'
import user from '@testing-library/user-event'

const mockRouterPush = jest.fn()

jest.mock('@utils/passwordUtils', () => {
  const actualTracker = jest.requireActual('@utils/passwordUtils')
  return {
    ...actualTracker,
    onPasswordChange: jest.fn()
  }
})

jest.mock('next/router', () => ({
  useRouter: () => ({
    push: mockRouterPush
  })
}))

const mockValidToken = '5678'

describe('Render Reset Password Page', () => {
  it('Form rendering', async () => {
    render(<ResetForgetPwd actionToken={mockValidToken} />)
    expect(
      await screen.findByRole('heading', {
        name: /Reset your password/i
      })
    ).toHaveTextContent('Reset Your Password')

    expect(await screen.findByText(/new password/i)).toBeInTheDocument()
    expect(await screen.findByText(/confirm password/i)).toBeInTheDocument()
    const confirmLoginBtn = await screen.findByRole('button', {
      name: /confirm & login/i
    })
    expect(confirmLoginBtn).toBeInTheDocument()
    expect(confirmLoginBtn).toBeDisabled()
  })

  it('Confirm button rendering and should be enabled', async () => {
    render(<ResetForgetPwd actionToken={mockValidToken} />)
    const newPassword = await screen.findByLabelText(/new password/i)
    fireEvent.change(newPassword, {
      target: { value: 'TestFridaytest@123' }
    })

    const confirmPasswordEl = await screen.findByLabelText(/confirm password/i)
    fireEvent.change(confirmPasswordEl, {
      target: { value: 'TestFridaytest@123' }
    })

    const confirmLoginBtn = await screen.findByRole('button', {
      name: /confirm & login/i
    })
    expect(confirmLoginBtn).toBeInTheDocument()
    expect(confirmLoginBtn).toBeEnabled()
  })
})

describe('Yup Form Validation', () => {
  it('check yup validations on the reset password form, incorrect values will give error', async () => {
    const values = {
      password: 'TestFridaytest@123',
      passwordConfirmation: 'TestFridaytest'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toBe(false)
  })

  it('check yup validations on the form correct values no error', async () => {
    const values = {
      password: 'TestFridaytest@123',
      passwordConfirmation: 'TestFridaytest@123'
    }

    const isValid = await validationSchema.isValid(values, {
      abortEarly: false
    })
    expect(isValid).toEqual(true)
  })

  it('error messages on form when incorrect value is provided', async () => {
    const values = {
      password: 'TestFridaytest@123',
      passwordConfirmation: 'TestFridaytest'
    }
    try {
      await validationSchema.validate(values, { abortEarly: false })
    } catch (error) {
      // If an error is thrown, the test is successful
      expect(error).toBeDefined()
      expect(error.errors).toEqual(['The passwords entered do not match.'])
      expect(error.errors).toHaveLength(1)
      return
    }
    // If no error is thrown, the test fails
    throw new Error('Validation did not fail as expected')
  })
})
