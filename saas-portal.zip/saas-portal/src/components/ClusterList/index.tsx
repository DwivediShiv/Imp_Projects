import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  PERMISSION_INFRAMANAGER,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import Permission from '@sharedComponents/Permission'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import React, { useCallback, useEffect } from 'react'
import Container from '@sharedComponents/Container'
import classNames from 'classnames'
import styles from './index.module.css'
import AddClusterModal from '../ClusterAdd'
import CustomTableList from '@sharedComponents/CustomTableList'
import useClusterList from './hooks/useClusterList'
import useClusterListApi from './hooks/useClusterListApi'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Warning from '@sharedComponents/WarningMessage'
import Loader from '@sharedComponents/Loader'
import { useAuthorize } from '@core/context/Authorize'
import { debounce } from 'lodash'

const ClusterList = () => {
  const { isAdmin, isLogin } = useAuthorize()
  const {
    page,
    handlePageChange,
    sortBy,
    sortOrder,
    searchValue,
    handleSortChange,
    handleOnSearch,
    isLoading,
    setIsLoading,
    filterRegion,
    noFilteredData,
    clusterListConfig,
    handleTabChange,
    status,
    tabIndex,
    refreshList
  } = useClusterList()

  const {
    clusterListData,
    clusterListError,
    fetchClusterList,
    clusterListTotal,
    filterCriterias,
    initialLoader,
    clusterListErrorCode
  } = useClusterListApi()

  const debouncefetch = useCallback(
    debounce((params) => {
      fetchClusterList(params)
    }, 500),
    []
  )

  useEffect(() => {
    const params = {
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterRegion
    }
    debouncefetch(params)
  }, [
    fetchClusterList,
    page,
    searchValue,
    setIsLoading,
    sortBy,
    sortOrder,
    status,
    filterRegion,
    isLogin,
    refreshList
  ])

  const refreshListHandler = () => {
    fetchClusterList({
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterRegion
    })
  }
  const renderClusterListData = () => {
    if (clusterListError) {
      let header = clusterListError
      let state = CustomIconicCardState.Warning
      let message = ''

      const isUnauthorize = clusterListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    return (
      <>
        <CustomTableList
          configuration={clusterListConfig}
          data={clusterListData}
          totalRecord={clusterListTotal}
          isLoading={isLoading}
          paginationSize={10}
          tabIndex={tabIndex}
          sortBy={sortBy}
          sortOrder={sortOrder}
          handlePageChange={handlePageChange}
          handleOnTabChange={handleTabChange}
          page={page}
          handleSortChange={handleSortChange}
          state={status}
          handleOnSearch={handleOnSearch}
          filterCriterias={filterCriterias}
          searchValue={searchValue}
          noFilteredData={noFilteredData}
        />
      </>
    )
  }
  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_INFRAMANAGER} isBigBoardError>
        {initialLoader ? (
          <div className={styles.loader}>
            <Loader />
          </div>
        ) : (
          <Container className={classNames(styles.headerContent, 'container')}>
            <section className={styles.grid}>
              <div className={styles.topBar}>
                {!(clusterListError && clusterListErrorCode === ERROR_UNAUTH) &&
                  isAdmin && <h3 className="bold">Cluster Management</h3>}
                {!(clusterListError && clusterListErrorCode === ERROR_UNAUTH) &&
                  isAdmin && (
                    <AddClusterModal refreshHandler={refreshListHandler} />
                  )}
              </div>
            </section>
            {renderClusterListData()}
          </Container>
        )}
      </Permission>
    </PrivateRoute>
  )
}

export default ClusterList
