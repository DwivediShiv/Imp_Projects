import appConfig from 'app.config'
import axios from 'axios'
import { useCallback, useState } from 'react'
import { SELECTION_CONSTANTS } from '@constants/constants'
import { capitalizeFirstLetter } from '@utils/conversion'

export const clusterListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/cluster/list`
export const exportClusterListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/cluster/list/export`

const useClusterListApi = () => {
  const [clusterListData, setClusterListData] = useState<any>(null)
  const [clusterListError, setClusterListError] = useState<string | null>('')
  const [clusterListTotal, setClusterListTotal] = useState<number>(0)
  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>()
  const [initialLoader, setInitialLoader] = useState<boolean>(true)
  const [clusterListErrorCode, setClusterListErrorCode] = useState<
    string | null
  >('')

  const clusterStatusMap = {
    success: ['Active'],
    deploying: [
      'Provisioned',
      'Version Deployment In Progress',
      'Network Deployment In Progress'
    ],
    failed: [
      'Build Failed',
      'Deletion Failed',
      'Network Deployment Failed',
      'Version Deployment Failed'
    ],
    deleting: ['Deletion In Progress'],
    deleted: ['Deleted']
  }

  const updateClusterStatus = (status: string) => {
    for (const key in clusterStatusMap) {
      if (clusterStatusMap[key].includes(status)) {
        return key
      }
    }
  }

  const fetchClusterList = useCallback(
    async ({
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterRegion
    }) => {
      try {
        const urlParams: Record<string, string> = {}
        setClusterListError('')
        setClusterListTotal(0)
        setIsLoading(true)

        if (page) {
          urlParams.page = page
        }

        if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
          urlParams.statusTab = status
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.name = searchValue
        }

        if (filterRegion?.length) {
          urlParams.regions = filterRegion
        }

        const { data: response } = await axios.post(
          clusterListApiUrl,
          urlParams
        )

        // Manipulate cluster list data for comma seperated network string and status
        const clustersData = response.data.map((cluster) => {
          // Update comma seperated network
          cluster.networks = cluster.networks
            .map((network) => capitalizeFirstLetter(network.network))
            .join(', ')
          // Update status
          cluster.status = updateClusterStatus(cluster.status)

          return cluster
        })

        if (response.filterCriterias) {
          setFilterCriterias(response.filterCriterias)
        }

        setClusterListData(clustersData)
        setClusterListTotal(response.totalRecord)
        setInitialLoader(false)
      } catch (error) {
        setClusterListErrorCode(error?.response?.data?.code || 'General')
        setInitialLoader(false)
        setClusterListError(error?.response?.data?.error?.message)
      } finally {
        setInitialLoader(false)
        setIsLoading(false)
      }
    },
    []
  )

  function getExportClusterUrlParams(
    searchValue?: any,
    region?: any,
    statusTab?: string,
    sortBy?: string,
    sortOrder?: string
  ): any {
    const urlParams: Record<string, string> = {}
    urlParams.get = 'All'
    if (searchValue !== '') {
      urlParams.name = searchValue
    }
    if (region?.length) {
      urlParams.regions = region
    }

    if (statusTab !== '' && statusTab !== SELECTION_CONSTANTS.ALL) {
      urlParams.statusTab = statusTab
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    return urlParams
  }

  async function exportClusterList(
    searchValue: string,
    region: any,
    statusTab: string,
    sortBy: string,
    sortOrder: string
  ): Promise<string> {
    try {
      const response = await axios({
        method: 'POST',
        url: exportClusterListApiUrl,
        data: getExportClusterUrlParams(
          searchValue,
          region,
          statusTab,
          sortBy,
          sortOrder
        )
      })
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  return {
    fetchClusterList,
    exportClusterList,
    clusterListData,
    clusterListError,
    clusterListTotal,
    filterCriterias,
    initialLoader,
    clusterListErrorCode
  }
}

export default useClusterListApi
