import { SELECTION_CONSTANTS } from '@constants/constants'
import appConfig from 'app.config'
import { useCallback, useMemo, useState } from 'react'
import useClusterListApi from './useClusterListApi'

const useClusterList = () => {
  const [page, setPage] = useState(1)
  const [sortBy, setSortBy] = useState<string>('')
  const [sortOrder, setSortOrder] = useState<string>('')
  const [searchValue, setSearchValue] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>()
  const [filterRegion, setFilterRegion] = useState<string[]>([])
  const [tabIndex, setTabIndex] = useState<number>(0)
  const [status, setStatus] = useState<string>('')
  const [refreshList, setRefreshList] = useState<number>(0)
  const { exportClusterList } = useClusterListApi()

  const handleSelect = useCallback(
    (
      e: React.ChangeEvent<HTMLInputElement>,
      items: Record<string, string>,
      type: string
    ) => {
      setPage(1)
      e.preventDefault()
      const { value } = e.target
      const options = Object.keys(items)
      if (value[value.length - 1] === SELECTION_CONSTANTS.ALL) {
        type === 'region' &&
          setFilterRegion(filterRegion.length === options.length ? [] : options)
        return
      }
      type === 'region' &&
        setFilterRegion(typeof value === 'string' ? value.split(',') : value)
    },
    [filterRegion.length]
  )

  const handleClearFilter = () => {
    setPage(1)
    setSearchValue('')
    setFilterRegion([])
    setSortBy('')
    setSortOrder('')
    setTabIndex(0)
    setStatus('')
  }

  const noFilteredData = () =>
    searchValue !== '' || filterRegion.length > 0 || tabIndex !== 0

  const handlePageChange = (page) => {
    setPage(page)
  }

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    setSortBy(column.sortField)
    setSortOrder(sortDirection)
  }

  const handleOnSearch = (e) => {
    setPage(1)
    setSearchValue(e.target.value)
  }

  const clusterListConfig = useMemo(() => {
    return {
      title: '',
      searchConfig: {
        type: 'search',
        name: 'search',
        placeholder: 'Search...',
        searchValue
      },
      refreshConfig: {
        name: 'Refresh List',
        handleRefreshList: () => setRefreshList(Math.random())
      },
      exportConfig: {
        exportFn: () =>
          exportClusterList(
            searchValue,
            filterRegion,
            status,
            sortBy,
            sortOrder
          ),
        fileName: 'clusterList.csv'
      },
      columns: [
        {
          id: 'name',
          title: 'Cluster Name',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'name',
          class: 'name',
          rowConfig: {
            cellType: 'clickableField',
            clickable: (row) => {
              return true
            },
            value: 'name',
            onClick: (row) => {
              return `/cluster-details/${row.id}`
            }
          },
          grow: 2,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'name'
        },
        {
          id: 'region',
          title: 'Region',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'region',
          class: 'region',
          rowConfig: {
            cellType: 'default',
            value: 'region',
            clickable: 'false'
          },
          grow: 1.5,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'region'
        },
        {
          id: 'networks',
          title: 'Network',
          type: 'tableHeader',
          sortable: false,
          class: 'network',
          rowConfig: {
            cellType: 'default',
            value: 'networks',
            clickable: 'false'
          },
          grow: 1.5,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }'
        },
        {
          id: 'version',
          title: 'Version',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'version',
          class: 'version',
          rowConfig: {
            cellType: 'default',
            value: 'version',
            clickable: 'false'
          },
          grow: 1,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'version'
        },
        {
          id: 'account',
          title: 'AWS Account',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'awsAccount',
          class: 'awsAccount',
          rowConfig: {
            cellType: 'default',
            clickable: 'false',
            value: 'awsAccount',
            class: 'awsAccountColumn'
          },
          grow: 2.5,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'aws_account'
        },
        {
          id: 'createdBy',
          title: 'Created By',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'createdBy',
          class: 'createdBy',
          rowConfig: {
            cellType: 'default',
            value: 'createdBy'
          },
          grow: 2,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'created_by',
          allowOverflow: false
        },
        {
          id: 'createdAt',
          title: 'Created On',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'createdAt',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'createdAt'
          },
          grow: 1.5,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'created_at',
          allowOverflow: false
        },
        {
          id: 'updatedAt',
          title: 'Updated On',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'updatedAt',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'updatedAt'
          },
          grow: 1.75,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'updated_at',
          allowOverflow: false
        },
        {
          id: 'status',
          title: 'Status',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'status',
          rowConfig: {
            cellType: 'fancyStatusField',
            value: 'status',
            class: 'statusColumn'
          },
          grow: 1.5,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'status',
          allowOverflow: false
        }
      ],
      tabConfig: {
        defaultTab: 0,
        tabList: [
          {
            title: 'All',
            key: 'all',
            value: '',
            index: 0
          },
          {
            title: 'Success',
            key: 'Active',
            value: 'Active',
            index: 1,
            icon: 'success'
          },
          {
            title: 'Deploying',
            key: 'Provisioned',
            value: 'Provisioned',
            index: 1,
            icon: 'warning'
          },
          {
            title: 'Failed',
            key: 'Build Failed',
            value: 'Build Failed',
            index: 2,
            icon: 'danger'
          },
          {
            title: 'Deleting',
            key: 'Deletion In Progress',
            value: 'Deletion In Progress',
            index: 3,
            icon: 'disabled'
          },
          {
            title: 'Deleted',
            key: 'Deleted',
            value: 'Deleted',
            index: 3,
            icon: 'failed'
          }
        ]
      },
      filterConfig: {
        clearFilters: handleClearFilter,
        filters: [
          {
            id: 'Regions',
            inputName: 'Region',
            label: 'Region',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterRegion,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterRegion,
            onChange: (e, items) => {
              handleSelect(e, items, 'region')
            }
          }
        ]
      }
    }
  }, [
    searchValue,
    filterRegion,
    exportClusterList,
    sortBy,
    sortOrder,
    status,
    handleSelect
  ])

  const {
    tabConfig: { tabList = [] }
  } = clusterListConfig

  const handleTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setPage(1)
    setStatus(tabList[newValue].value)
    setTabIndex(newValue)
  }

  return {
    clusterListConfig,
    searchValue,
    handleOnSearch,
    handleSortChange,
    handlePageChange,
    sortBy,
    sortOrder,
    page,
    noFilteredData,
    isLoading,
    setIsLoading,
    filterRegion,
    handleTabChange,
    status,
    tabIndex,
    refreshList,
    setRefreshList
  }
}

export default useClusterList
