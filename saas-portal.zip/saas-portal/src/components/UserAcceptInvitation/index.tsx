import React, { useEffect } from 'react'
import usePasswordConfig, {
  initialValues,
  validationSchema
} from './hooks/usePasswordConfig'
import useAcceptInvitation from './hooks/useAcceptInvitation'
import SetPasswordForm from '@sharedComponents/SetPasswordForm'
import { ICON_TYPE } from '@constants/modalConstant'
import CustomModal from '@sharedComponents/Modal'

const AcceptInvitation = ({
  actionToken
}: {
  actionToken: string | undefined
}) => {
  const { fulfilledPolicies, passwordConfig } = usePasswordConfig()
  const {
    loadAcceptInvitationFunc,
    handleSubmit,
    onModalClose,
    userEmail,
    loading,
    modalTemplate,
    openStatusModal
  } = useAcceptInvitation(actionToken)

  useEffect(() => {
    loadAcceptInvitationFunc()
  }, [])

  return (
    <>
      {!openStatusModal && (
        <SetPasswordForm
          content={passwordConfig}
          initialValues={initialValues}
          validationSchema={validationSchema}
          handleSubmit={handleSubmit}
          loading={loading}
          userEmail={userEmail}
          fulfilledPolicies={fulfilledPolicies}
        />
      )}
      <CustomModal
        type={ICON_TYPE}
        modalTemplate={modalTemplate}
        onToggleModal={onModalClose}
        isOpen={openStatusModal}
        buttonActionMain={onModalClose}
      />
    </>
  )
}

export default AcceptInvitation
