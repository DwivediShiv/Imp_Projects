import React from 'react'
import styles from './index.module.css'
import useAddCustomer from './hooks/useAddCustomer'
import { PERMISSION_CUSTOMERMNGR } from '@constants/permissionConstants'
import SectionForm from '@sharedComponents/SectionForm'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'

const AddCustomer = () => {
  const { sectionConfig, initialValues, validationSchema, handleSubmit } =
    useAddCustomer()
  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_CUSTOMERMNGR} isBigBoardError>
        <>
          <section className={styles.grid}>
            <div className={styles.topBar}>
              <h3 className="bold">Add New Customer</h3>
            </div>
          </section>
          <SectionForm
            sectionConfig={sectionConfig}
            initialValues={initialValues}
            validationSchema={validationSchema}
            handleSubmit={handleSubmit}
          />
        </>
      </Permission>
    </PrivateRoute>
  )
}

export default AddCustomer
