export interface Customer {
  name: string
  description: string
  businessNumber: string
  address: string
  country: string
  industry: string
  contactEmail: string
}
