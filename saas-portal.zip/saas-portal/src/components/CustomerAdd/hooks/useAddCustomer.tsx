import { useRouter } from 'next/router'
import React, { useEffect } from 'react'
import * as Yup from 'yup'
import {
  ENTER_VALID_EMAIL,
  MAX_100_CHAR_ALLOWED,
  MAX_200_CHAR_ALLOWED,
  MAX_500_CHAR_ALLOWED,
  MAX_50_CHAR_ALLOWED,
  REQUIRED_FIELD
} from '@constants/constants'
import CustomDropDown from '@sharedComponents/Dropdown'
import Toast from '@sharedComponents/Toast'
import { Customer } from '../types/AddCustomer'
import useAddCustomerApi from './useAddCustomerApi'

const useAddCustomer = () => {
  const router = useRouter()
  const { addCustomer, errorMsg, successMsg } = useAddCustomerApi()

  useEffect(() => {
    if (successMsg) {
      Toast('success', successMsg)
      router.back()
    }
    if (errorMsg) {
      Toast('error', errorMsg)
    }
  }, [successMsg, errorMsg])

  const initialValues: Partial<Customer> = {
    name: '',
    description: '',
    businessNumber: '',
    address: '',
    country: '',
    industry: '',
    contactEmail: ''
  }

  const validationSchema: Yup.SchemaOf<Customer> = Yup.object().shape({
    name: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/.*[a-zA-Z0-9].*/, {
        message: 'Please enter correct Customer Name.'
      })
      .max(100, MAX_100_CHAR_ALLOWED),
    description: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/.*[a-zA-Z0-9].*/, {
        message: 'Please enter correct Description.'
      })
      .max(200, MAX_200_CHAR_ALLOWED),
    businessNumber: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/^[a-zA-Z0-9_\s]*$/, {
        message: 'Please enter correct Business Number.'
      })
      .max(50, MAX_50_CHAR_ALLOWED),
    address: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/.*[a-zA-Z0-9].*/, {
        message: 'Please enter correct Address.'
      })
      .max(100, MAX_100_CHAR_ALLOWED),
    country: Yup.string().required(REQUIRED_FIELD),
    industry: Yup.string().required(REQUIRED_FIELD),
    contactEmail: Yup.string().email(ENTER_VALID_EMAIL).required(REQUIRED_FIELD)
  })

  const onCancel = () => {
    router.back()
  }

  const handleSubmit = async (
    values: Customer,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ): Promise<void> => {
    const payload = {
      ...values,
      name: values.name.trim(),
      businessNumber: values.businessNumber.trim()
    }
    await addCustomer(payload, setFieldError)
  }

  const renderCustomComponent = ({
    form,
    field,
    name,
    excludedValid,
    disabled,
    optionCategory,
    ...restProps
  }) => {
    const inputName = name || field?.name
    const hasError = form?.touched[inputName] && form?.errors[inputName]
    const isValid =
      form?.touched[inputName] && form?.values[inputName] && !hasError

    return (
      <CustomDropDown
        inputName={inputName}
        optionCategory={optionCategory}
        error={hasError}
        isValid={!excludedValid && !!isValid}
        disabled={disabled}
        {...field}
        {...restProps}
      />
    )
  }

  const sectionConfig = [
    {
      name: 'customer_information',
      title: 'Customer Information',
      type: 'form',
      fields: [
        {
          name: 'name',
          label: 'Customer Name*',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 100 }
        },
        {
          name: 'description',
          label: 'Description*',
          type: 'text',
          elementType: 'input',
          isResizable: false,
          multiline: true,
          maxRows: 1,
          inputProps: { maxLength: 500 }
        },
        {
          name: 'businessNumber',
          label: 'Business Number*',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 50 }
        },
        {
          name: 'address',
          label: 'Address*',
          type: 'text',
          elementType: 'input',
          inputProps: { maxLength: 500 }
        },
        {
          name: 'country',
          label: 'Country*',
          elementType: 'custom',
          getComponent: ({
            form,
            field,
            name,
            excludedValid,
            disabled,
            ...restProps
          }) =>
            renderCustomComponent({
              form,
              field,
              name,
              excludedValid,
              disabled,
              optionCategory: 'FullCountry',
              ...restProps
            })
        },
        {
          name: 'industry',
          label: 'Industry*',
          elementType: 'custom',
          getComponent: ({
            field,
            form,
            name,
            excludedValid,
            disabled,
            ...restProps
          }) =>
            renderCustomComponent({
              form,
              field,
              name,
              excludedValid,
              disabled,
              optionCategory: 'Industry',
              ...restProps
            })
        },
        {
          name: 'contactEmail',
          label: 'Contact Email*',
          type: 'text',
          elementType: 'input'
        }
      ]
    },
    {
      name: 'submit_button',
      type: 'button',
      label: 'Add & Submit',
      leftButtons: [
        {
          name: 'Cancel',
          color: 'secondary',
          variant: 'outlined',
          disableRipple: true,
          onClick: onCancel
        },
        {
          name: 'Reset',
          'data-action': 'back',
          color: 'secondary',
          variant: 'text',
          disable: ({ dirty }) => !dirty
        }
      ],
      rightButtons: [
        {
          name: 'Add Customer',
          variant: 'contained',
          color: 'primary',
          type: 'submit',
          processingLoader: true,
          disable: ({ touched, isValid }) => !(touched?.name && isValid)
        }
      ]
    }
  ]
  return { sectionConfig, handleSubmit, initialValues, validationSchema }
}

export default useAddCustomer
