import {
  ADD_CUSTOMER_SUCCESS_MSG,
  ERROR_CUSTOMER_ALREADY_EXISTS,
  ERROR_EMAIL_ALREADY_EXISTS,
  ERROR_MSG
} from '@constants/constants'
import appConfig from 'app.config'
import axios from 'axios'
import { Customer } from '../types/AddCustomer'
import { useState } from 'react'

const useAddCustomerApi = () => {
  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState('')
  const addCustomerUrl = `${appConfig.api}/saas-management/api/v1/saas/management/customer`

  const addCustomer = async (
    data: Customer,
    setFieldError: (field: string, errorMsg: string) => void
  ) => {
    try {
      setSuccessMsg('')
      setErrorMsg('')
      const { data: response } = await axios.post(addCustomerUrl, data)
      setSuccessMsg(ADD_CUSTOMER_SUCCESS_MSG)
    } catch (error) {
      setSuccessMsg('')
      if (error?.response?.data?.code === ERROR_EMAIL_ALREADY_EXISTS.CODE) {
        setFieldError('contactEmail', ERROR_EMAIL_ALREADY_EXISTS.MESSAGE)
      } else if (
        error?.response?.data?.code === ERROR_CUSTOMER_ALREADY_EXISTS &&
        error?.response?.data?.error?.additionalData
      ) {
        setErrorMsg(error?.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        if (Array.isArray(additionalData)) {
          const additionalErrors = Object.values(additionalData)
          setErrorMsg(additionalErrors?.length ? additionalErrors[0] : message)
        } else {
          setErrorMsg(additionalData?.length ? additionalData : message)
        }
      } else {
        setErrorMsg(ERROR_MSG)
      }
    }
  }

  return {
    addCustomer,
    errorMsg,
    successMsg
  }
}

export default useAddCustomerApi
