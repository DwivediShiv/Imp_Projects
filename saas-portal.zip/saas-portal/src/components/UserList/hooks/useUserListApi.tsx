import { useCallback, useState } from 'react'
import axios, { AxiosResponse } from 'axios'
import { ApiResponse, UserDetail, UserList } from '../types/UserList'
import appConfig from 'app.config'
import { SELECTION_CONSTANTS, USER_MESSAGES } from '@constants/constants'
import { buildUrlWithQueryParams } from '@utils/url'
import Toast from '@sharedComponents/Toast'
import { printErrorStack } from '@saasportal/libs/utils'

export interface UserListResponse {
  data: UserList
}

export let userListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/user-list`

/*TODO: Replace with correct Delete API*/
export function getDeleteUserUrl(email: string) {
  return `${appConfig.api}/saas-management/api/v1/saas/user-list/delete-user/${email}`
}

export function getResendInviteURL(email: string): string {
  return `${appConfig.api}/saas-management/api/v1/saas/resend-invite/${email}`
}

export default function useUserListApi() {
  const [userListData, setUserListData] = useState<any>([])
  const [userListError, setUserListError] = useState<string | null>('')
  const [userListTotal, setUserTotal] = useState<number>(0)
  const [initialLoader, setInitialLoader] = useState<boolean>(true)
  const [userListErrorCode, setUserListErrorCode] = useState<string | null>('')

  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>()

  const fetchUserList = useCallback(
    async ({
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterUserRole
    }) => {
      try {
        const urlParams: Record<string, string> = {}
        setUserListError('')
        setUserTotal(0)
        setIsLoading(true)

        userListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/user-list`

        if (page) {
          urlParams.page = page
        }

        if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
          urlParams.state = status
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.email = searchValue
        }

        if (filterUserRole?.length) {
          urlParams.roles = filterUserRole
        }

        // userListApiUrl = buildUrlWithQueryParams(userListApiUrl, urlParams)
        const { data: response } = await axios.post<ApiResponse<UserDetail>>(
          userListApiUrl,
          urlParams
        )

        if (response.filterCriterias) {
          setFilterCriterias(response.filterCriterias)
        }

        setUserListData(response.data)
        setUserTotal(response.totalRecord)
        setInitialLoader(false)
      } catch (error) {
        setUserListErrorCode(error?.response?.data?.code || 'General')
        setInitialLoader(false)
        setUserListError(error?.response?.data?.error?.message)
      } finally {
        setInitialLoader(false)
        setIsLoading(false)
      }
    },
    []
  )

  function getExportUserUrlParam(
    email?: string,
    roles?: string,
    status?: string,
    sortBy?: string,
    sortOrder?: string
  ): any {
    const urlParams: Record<string, string> = {}
    urlParams.get = 'All'

    if (email !== '') {
      urlParams.email = email
    }

    if (roles?.length) {
      urlParams.roles = roles
    }

    if (status !== '' && status !== SELECTION_CONSTANTS.ALL) {
      urlParams.state = status
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    return urlParams
  }

  async function exportUserList(
    searchValue,
    roles,
    status,
    sortBy,
    sortOrder
  ): Promise<string> {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: `${appConfig.api}/saas-management/api/v1/saas/user-list/export`,
        data: getExportUserUrlParam(
          searchValue,
          roles,
          status,
          sortBy,
          sortOrder
        )
      })
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  async function deleteUser(emailId: string): Promise<any> {
    try {
      const response: AxiosResponse = await axios({
        method: 'DELETE',
        url: getDeleteUserUrl(emailId)
      })

      Toast('success', USER_MESSAGES.USER_DELETED)
    } catch (error) {
      if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }

  async function resendInvite(emailId: string): Promise<any> {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: getResendInviteURL(emailId)
      })

      Toast('success', USER_MESSAGES.USER_INVITED)
    } catch (error) {
      if (error.response?.data?.error?.additionalData) {
        Toast('error', error.response?.data?.error?.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }

  return {
    userListData,
    userListError,
    setUserListData,
    exportUserList,
    fetchUserList,
    userListTotal,
    filterCriterias,
    deleteUser,
    resendInvite,
    initialLoader,
    userListErrorCode
  }
}
