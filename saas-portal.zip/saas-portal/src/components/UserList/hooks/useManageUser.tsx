import React, { useMemo, useState } from 'react'
import { Configuration, UserDetail } from '../types/UserList'
import { SELECTION_CONSTANTS, STATE_CONSTANTS } from '@constants/constants'
import useUserListApi from './useUserListApi'
import appConfig from 'app.config'
import Delete from '@images/delete.svg'
import Mail from '@images/mailreset.svg'
import { useRouter } from 'next/router'
import { ModalFieldValue } from '@libs/types/Modal'
export const useManageUser = () => {
  const [page, setPage] = useState(1)
  const [sortBy, setSortBy] = useState<string>('')
  const [sortOrder, setSortOrder] = useState<string>('')
  const [status, setStatus] = useState<string>('')
  const [searchValue, setSearchValue] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>()
  const [tabIndex, setTabIndex] = useState<number>(0)
  const [filterUserRole, setFilterUserRole] = useState<string[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [refreshList, setRefreshList] = useState<number>(0)
  const router = useRouter()
  const [modalFieldValue, setModalFieldValue] = useState<ModalFieldValue>({
    template: '',
    value: null
  })
  const [init, setInit] = useState<boolean>()
  const { exportUserList, deleteUser, resendInvite } = useUserListApi()
  const handleUserRoleSelect = (
    e: React.ChangeEvent<HTMLInputElement>,
    userRoleItems: Record<string, string>
  ) => {
    setPage(1)
    e.preventDefault()
    const { value } = e.target
    const userRoleOptions = Object.keys(userRoleItems)
    if (
      value[value.length - 1] === SELECTION_CONSTANTS.ALL ||
      value.length === 0
    ) {
      setFilterUserRole(
        filterUserRole.length === userRoleOptions.length ? [] : userRoleOptions
      )
      return
    }
    setFilterUserRole(typeof value === 'string' ? value.split(',') : value)
  }

  const handleClearFilter = () => {
    setPage(1)
    setSearchValue('')
    setFilterUserRole([])
    setSortBy('')
    setSortOrder('')
    setStatus('')
    setTabIndex(0)
  }

  function noFilteredData() {
    return searchValue !== '' || filterUserRole.length > 0 || tabIndex !== 0
  }

  async function onDelete(row) {
    setModalFieldValue({ template: 'deleteUser', value: row })
    setIsModalOpen(true)
  }

  const UserListConfig = useMemo(() => {
    return {
      title: '',
      searchConfig: {
        type: 'search',
        name: 'search',
        placeholder: 'Search...',
        searchValue
      },
      refreshConfig: {
        name: 'Refresh List',
        handleRefreshList: () => setRefreshList(Math.random())
      },
      exportConfig: {
        exportFn: () =>
          exportUserList(
            searchValue,
            filterUserRole,
            status,
            sortBy,
            sortOrder
          ),
        fileName: 'userList.csv'
      },
      columns: [
        {
          id: 'email',
          title: 'User Email',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'email',
          class: 'email',
          rowConfig: {
            cellType: 'clickableField',
            clickable: (row) => {
              return (
                row.state === STATE_CONSTANTS.ACCEPTED ||
                row.state === STATE_CONSTANTS.INACTIVE
              )
            },
            value: 'email',
            onClick: (row) => {
              return `/userdetails/${row.profileId}`
            }
          },
          grow: 2.6,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'email'
        },
        {
          id: 'allowedRoles',
          title: 'Roles',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'allowedRoles',
          class: 'allowed_roles',
          rowConfig: {
            cellType: 'default',
            value: 'allowedRoles',
            clickable: 'false',
            class: 'allowedRolesColumn'
          },
          grow: 3,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'allowed_roles'
        },
        {
          id: 'createdDate',
          title: 'Invited On',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'createdDate',
          class: 'createdDate',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'createdDate',
            class: 'createdDateColumn'
          },
          grow: 1.2,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'created_date',
          allowOverflow: false
        },
        {
          id: 'createdBy',
          title: 'Invited By',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'createdBy',
          rowConfig: {
            cellType: 'default',
            value: 'createdBy',
            class: 'createdByColumn'
          },
          grow: 2,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          sortField: 'created_by',
          allowOverflow: false
        },
        {
          id: 'state',
          title: 'Status',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'state',
          rowConfig: {
            cellType: 'fancyStatusField',
            value: 'state',
            class: 'statusColumn'
          },
          // grow: 1,
          style: '{overflow: hidden; textOverflow: ellipsis}',
          sortField: 'state',
          allowOverflow: false
        },
        {
          id: 'actions',
          title: 'Actions',
          type: 'tableHeader',
          sortable: false,
          rowConfig: {
            cellType: 'actions',
            actions: [
              {
                type: 'icon',
                image: Mail,
                clickable: (row: UserDetail) => {
                  return row.state === STATE_CONSTANTS.INVITED
                },
                onClick: (row: UserDetail) => {
                  resendInvite(row.email)
                }
              },
              {
                type: 'icon',
                image: Delete,
                clickable: (row: any) => {
                  return (
                    row.state === STATE_CONSTANTS.INVITED ||
                    row.state === STATE_CONSTANTS.INACTIVE
                  )
                },
                onClick: (row: any) => {
                  onDelete(row)
                }
              }
            ]
          },
          // grow: 1,
          style:
            '{white-space:nowrap;overflow: hidden; text-overflow: ellipsis}',
          allowOverflow: false
        }
      ],
      tabConfig: {
        defaultTab: 0,
        tabList: [
          {
            title: 'All',
            key: 'all',
            value: '',
            index: 0
          },
          {
            title: 'Active',
            key: 'active',
            value: 'active',
            index: 1,
            icon: 'success'
          },
          {
            title: 'Invited',
            key: 'invited',
            value: 'invited',
            index: 2,
            icon: 'warning'
          }
        ]
      },
      filterConfig: {
        clearFilters: handleClearFilter,
        filters: [
          {
            id: 'Roles',
            inputName: 'Roles',
            label: 'User Roles',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterUserRole,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterUserRole,
            onChange: handleUserRoleSelect
          }
        ]
      }
    }
  }, [searchValue, filterUserRole, status, sortBy, sortOrder])

  const {
    tabConfig: { tabList = [] }
  } = UserListConfig

  const handleTabChange = (
    _event: React.ChangeEvent<unknown>,
    newValue: number
  ) => {
    setPage(1)
    setStatus(tabList[newValue].value)
    setTabIndex(newValue)
  }

  const handlePageChange = (page) => {
    setPage(page)
  }

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    setSortBy(column.sortField)
    setSortOrder(sortDirection)
  }

  const handleOnSearch = (e) => {
    setPage(1)
    setSearchValue(e.target.value)
  }

  async function submitModal() {
    const { email } = modalFieldValue.value
    await deleteUser(email)
    setIsModalOpen(false)
    setInit(!init)
  }

  async function handleUserCreation() {
    setPage(1)
  }

  return {
    searchValue,
    handleOnSearch,
    handleSortChange,
    handleTabChange,
    handlePageChange,
    tabIndex,
    status,
    sortBy,
    sortOrder,
    filterUserRole,
    UserListConfig,
    page,
    isLoading,
    setIsLoading,
    noFilteredData,
    isModalOpen,
    setIsModalOpen,
    submitModal,
    handleUserCreation,
    init,
    refreshList
  }
}
