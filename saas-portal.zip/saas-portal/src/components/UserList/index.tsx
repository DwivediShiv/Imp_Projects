import React, { useCallback, useEffect } from 'react'
import classNames from 'classnames'

import styles from './index.module.css'
import { useAuthorize } from '@core/context/Authorize'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_ADMIN,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import Container from '@sharedComponents/Container'
import InviteUserModal from '../UserAdd/components/InviteUserModal'
import Button from '@sharedComponents/Button'
import Modal from '@sharedComponents/Modal'
import { isLoggedIn } from '@utils/auth'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import CustomTableList from '@sharedComponents/CustomTableList'
import { useManageUser } from './hooks/useManageUser'
import useUserListApi from './hooks/useUserListApi'
import Loader from '@sharedComponents/CustomLoader'
import Warning from '@sharedComponents/WarningMessage'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import { debounce } from 'lodash'

const ManageUser = () => {
  const { isAdmin, isLogin } = useAuthorize()
  const {
    page,
    handlePageChange,
    handleTabChange,
    sortBy,
    sortOrder,
    searchValue,
    status,
    tabIndex,
    handleSortChange,
    handleOnSearch,
    isLoading,
    setIsLoading,
    filterUserRole,
    noFilteredData,
    UserListConfig: userListConfig,
    setIsModalOpen,
    isModalOpen,
    submitModal,
    init,
    refreshList
  } = useManageUser()

  const {
    userListData,
    userListError,
    fetchUserList,
    userListTotal,
    filterCriterias,
    initialLoader,
    userListErrorCode
  } = useUserListApi()

  const debouncefetch = useCallback(
    debounce((params) => {
      fetchUserList(params)
    }, 500),
    []
  )

  useEffect(() => {
    const params = {
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterUserRole
    }
    debouncefetch(params)
  }, [
    fetchUserList,
    page,
    searchValue,
    setIsLoading,
    sortBy,
    sortOrder,
    status,
    filterUserRole,
    init,
    isLogin,
    refreshList
  ])

  const refreshListHandler = () => {
    const params = {
      page,
      sortBy,
      sortOrder,
      status,
      searchValue,
      setIsLoading,
      filterUserRole
    }
    debouncefetch(params)
  }

  const renderUserListData = () => {
    if (userListError) {
      let header = userListError
      let state = CustomIconicCardState.Warning
      let message = ''

      const isUnauthorize = userListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    return (
      <>
        <CustomTableList
          configuration={userListConfig}
          data={userListData}
          totalRecord={userListTotal}
          isLoading={isLoading}
          paginationSize={10}
          tabIndex={tabIndex}
          sortBy={sortBy}
          sortOrder={sortOrder}
          handlePageChange={handlePageChange}
          handleOnTabChange={handleTabChange}
          page={page}
          handleSortChange={handleSortChange}
          state={status}
          handleOnSearch={handleOnSearch}
          filterCriterias={filterCriterias}
          searchValue={searchValue}
          noFilteredData={noFilteredData}
        />
        <Modal
          type={CUSTOM_TYPE}
          title="Delete User"
          titleSize="h3"
          onToggleModal={() => {
            setIsModalOpen(false)
          }}
          isOpen={isModalOpen}
        >
          Are you sure you want to delete the user?
          <div className={styles.footer}>
            <Button
              color="primary"
              variant="contained"
              className={`mt-1 ${styles.confirmButton}`}
              onClick={submitModal}
            >
              Confirm
            </Button>
          </div>
        </Modal>
      </>
    )
  }
  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_ADMIN} isBigBoardError>
        {initialLoader ? (
          <div className={styles.loader}>
            <Loader />
          </div>
        ) : (
          <Container className={classNames(styles.headerContent, 'container')}>
            <section className={styles.grid}>
              <div className={styles.topBar}>
                {!(userListError && userListErrorCode === ERROR_UNAUTH) &&
                  isAdmin && <h3 className="bold">Manage Users</h3>}
                {!(userListError && userListErrorCode === ERROR_UNAUTH) &&
                  isAdmin && (
                    <InviteUserModal refreshHandler={refreshListHandler} />
                  )}
              </div>
            </section>
            {renderUserListData()}
          </Container>
        )}
      </Permission>
    </PrivateRoute>
  )
}

export default ManageUser
