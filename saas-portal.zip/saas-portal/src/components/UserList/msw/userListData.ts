import { UserList } from '../types/UserList'

export const userList: UserList = {
  data: [
    {
      id: 1,
      email: 'test.user@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'admin@acentrik.com'
    },
    {
      id: 2,
      email: 'test.user01@email.com',
      allowedRoles: 'Viewer',
      state: 'Invited',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'admin2@acentrik.com'
    },
    {
      id: 3,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 4,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 5,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 6,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 7,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 8,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 9,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 10,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 11,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 12,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    },
    {
      id: 13,
      email: 'test.user02@email.com',
      allowedRoles: 'Admin',
      state: 'Accepted',
      userInviteDate: '2023-08-22T06:02:58.036Z',
      createdBy: 'shruti@nagarro.com'
    }
  ],
  totalRecord: 13
}
