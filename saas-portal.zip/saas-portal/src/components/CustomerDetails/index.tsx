import React, { ReactElement, useEffect } from 'react'
import useCustomerDetails from './hooks/useCustomerDetails'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_CUSTOMERMNGR,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import CustomButton from '@sharedComponents/Button'
import BackIcon from '@images/back_icon.svg'
import { Grid } from '@mui/material'
import GridCard from '@sharedComponents/GridCard'
import appConfig from 'app.config'
import styles from './index.module.css'
import { useAuthorize } from '@core/context/Authorize'
import useCustomerDetailsApi from './hooks/useCustomerDetailsApi'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Warning from '@sharedComponents/WarningMessage'
import Loader from '@sharedComponents/CustomLoader'

const CustomerDetails = ({ customerId }): ReactElement => {
  const { handleBackClick } = useCustomerDetails()
  const TimeWithCustomFormat = WithCustomFormat(Time)
  const { customerInfoCards } = useCustomerDetails()
  const { isLogin } = useAuthorize()
  const {
    customerInfoData,
    getCustomerInfo,
    error,
    initialLoader,
    customerDetailErrorCode
  } = useCustomerDetailsApi()

  useEffect(() => {
    if (isLogin) {
      getCustomerInfo(customerId)
    }
  }, [customerId, isLogin])

  const renderCustomerInfoData = () => {
    if (error) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = error

      const isUnauthorize = customerDetailErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }
    return (
      <div>
        {customerInfoCards.map((cardConfig, index) => {
          return (
            <Grid
              className={styles.content}
              container
              rowSpacing={4}
              columnSpacing={3}
            >
              <Grid key={index} item xs={12} md={12} lg={9}>
                <GridCard cardConfig={cardConfig} data={customerInfoData} />
              </Grid>
            </Grid>
          )
        })}
      </div>
    )
  }

  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_CUSTOMERMNGR} isBigBoardError>
        {initialLoader ? (
          <div className={styles.loader}>
            <Loader />
          </div>
        ) : (
          <>
            {!error && (
              <CustomButton onClick={handleBackClick} aria-label="Go Back">
                <BackIcon />
              </CustomButton>
            )}

            {!error ? (
              <div className="mb-8">
                <h3>{customerInfoData?.name}</h3>
                <p className={`body-1 mt-2 ${styles.headerDescription}`}>
                  Created on:{' '}
                  {
                    <TimeWithCustomFormat
                      date={customerInfoData?.createdAt}
                      customFormat={appConfig.customization.dateFormat}
                    />
                  }
                </p>
              </div>
            ) : null}

            {renderCustomerInfoData()}
          </>
        )}
      </Permission>
    </PrivateRoute>
  )
}

export default CustomerDetails
