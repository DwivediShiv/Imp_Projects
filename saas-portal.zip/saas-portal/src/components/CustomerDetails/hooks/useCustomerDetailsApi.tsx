import { ERROR_MSG } from '@constants/constants'
import appConfig from 'app.config'
import axios from 'axios'
import { useState } from 'react'

export const customerInfoUrl = `${appConfig.api}/saas-management/api/v1/saas/management/customer/id`

const useCustomerDetailsApi = () => {
  const [error, setError] = useState('')
  const [customerInfoData, setCustomerInfoData] = useState(null)
  const [initialLoader, setInitialLoader] = useState<boolean>(true)
  const [customerDetailErrorCode, setCustomerDetailErrorCode] = useState<
    string | null
  >('')
  const getCustomerInfo = async (customerId) => {
    try {
      setError('')
      const { data: response } = await axios.get(
        `${customerInfoUrl}/${customerId}`
      )

      setCustomerInfoData(response)
      setInitialLoader(false)
    } catch (error) {
      setCustomerDetailErrorCode(error?.response?.data?.code || 'General')
      setInitialLoader(false)
      setError(error?.response?.data?.error?.message)
    }
  }
  return {
    getCustomerInfo,
    error,
    customerInfoData,
    initialLoader,
    customerDetailErrorCode
  }
}

export default useCustomerDetailsApi
