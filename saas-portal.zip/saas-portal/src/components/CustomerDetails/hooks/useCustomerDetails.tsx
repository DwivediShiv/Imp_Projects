import { useRouter } from 'next/router'
import { CustomerInfo } from '../types/CustomerDetails'

const useCustomerDetails = () => {
  const router = useRouter()

  const handleBackClick = () => {
    router.back()
  }

  const customerInfoCards = [
    {
      title: 'Customer Information',
      isEditable: false,
      fields: [
        {
          type: 'text',
          name: 'businessNumber',
          previewTitle: 'Business Number',
          getValue: (customerInfo: CustomerInfo) => {
            return customerInfo?.businessNumber || ''
          }
        },
        {
          type: 'text',
          name: 'address',
          previewTitle: 'Address',
          getValue: (customerInfo: CustomerInfo) => {
            return customerInfo?.address || ''
          }
        },
        {
          type: 'text',
          name: 'country',
          previewTitle: 'Country',
          getValue: (customerInfo: CustomerInfo) => {
            return customerInfo?.country || ''
          }
        },
        {
          type: 'text',
          name: 'industry',
          previewTitle: 'Industry',
          getValue: (customerInfo: CustomerInfo) => {
            return customerInfo?.industry || ''
          }
        },
        {
          type: 'text',
          name: 'contactEmail',
          previewTitle: 'Contact Email',
          getValue: (customerInfo: CustomerInfo) => {
            return customerInfo?.contactEmail || ''
          }
        }
      ]
    }
  ]

  return {
    handleBackClick,
    customerInfoCards
  }
}

export default useCustomerDetails
