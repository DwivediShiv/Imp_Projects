export interface CustomerInfo {
  businessNumber?: string
  address: string
  country: string
  industry: string
  contactEmail: string
}
