import appConfig from 'app.config'
import axios from 'axios'
import { useCallback } from 'react'
import Toast from '@sharedComponents/Toast'

const useForgetPasswordApi = () => {
  const postResendEmailUrl = `${appConfig.api}/saas-management/api/v1/saas/send-reset-email`

  const postResendEmail = async (data: { email: string }) => {
    try {
      const { data: response } = await axios.post(postResendEmailUrl, data)
      return response.data
    } catch (error) {
      console.log('error', 'An error occurred: ' + error.message)
      throw error
    }
  }

  return {
    postResendEmail
  }
}

export default useForgetPasswordApi
