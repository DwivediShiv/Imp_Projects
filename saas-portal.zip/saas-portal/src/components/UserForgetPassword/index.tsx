import React from 'react'
import ForgetPasswordForm from '@sharedComponents/Forms/ForgetPassword'
import useForgetPasword, {
  initialValues,
  validationSchema
} from './hooks/useForgetPassword'
import { useRouter } from 'next/router'
import CustomModal from '@sharedComponents/Modal'
import { CUSTOM_TYPE } from '@constants/modalConstant'
import EmailSent from '@images/email_sent.svg'
import styles from './index.module.css'
import CustomButton from '@sharedComponents/Button'

const ForgetPassword = () => {
  const router = useRouter()
  const {
    forgetPasswordConfig,
    userEmail,
    handleSubmit,
    isModalOpen,
    setIsModalOpen
  } = useForgetPasword()

  return (
    <>
      <ForgetPasswordForm
        content={forgetPasswordConfig}
        initialValues={initialValues}
        validationSchema={validationSchema}
        handleSubmit={handleSubmit}
      />
      <CustomModal
        type={CUSTOM_TYPE}
        onToggleModal={() => {
          setIsModalOpen(!isModalOpen)
        }}
        isOpen={isModalOpen}
      >
        <div className={styles.center}>
          <div className="icon-mail mb-4">
            <EmailSent className={`imageSizeLarge ${styles.successIcon}`} />
          </div>
          <h3 className="mb-4 bold">Password Recovery</h3>
          <p>
            An email has been sent to <b>{userEmail}</b>
          </p>
          <p className="mb-4">
            Please click on the link in the email to complete the password reset
            process.
          </p>
          <p className="mb-2 mt-6">
            <CustomButton
              color="primary"
              variant="contained"
              onClick={() => router.push('/login')}
            >
              Return to Login
            </CustomButton>
          </p>
        </div>
      </CustomModal>
    </>
  )
}

export default ForgetPassword
