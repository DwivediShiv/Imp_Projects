import React, { ReactElement, useEffect, useMemo, useState } from 'react'
import { IUserDetailsResult, UserInfo } from '../types/UserInfo'
import Switch from '@sharedComponents/Switch'
import useUserInfoApi from './useUserInfoApi'
import FancyToast from '@sharedComponents/Toast'
import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import appConfig from 'app.config'
import { getUserEmail } from '@utils/auth'
import { MANAGE_USER_DETAILS_CONSTANTS } from '@constants/constants'
import {
  ROLE_ADMIN,
  ROLE_CUSTMNGR,
  ROLE_INFRA_MANAGER
} from '@constants/roleConstants'
import NewStatusBox from '@sharedComponents/StatusFancy'

export default function useUserCards(defaultRoles) {
  const [isEditable, setIsEditable] = useState<boolean>(false)
  const { updateUserRole, userInfoError, updateInactiveRole } = useUserInfoApi()
  const TimeWithCustomFormat = WithCustomFormat(Time)
  const [init, setInit] = useState<boolean>()

  useEffect(() => {
    if (userInfoError) {
      FancyToast('error', MANAGE_USER_DETAILS_CONSTANTS.ERROR)
    } else if (userInfoError === null) {
      FancyToast('success', MANAGE_USER_DETAILS_CONSTANTS.SUCCESS)
    }
  }, [userInfoError])

  function statusElement(status: boolean): ReactElement {
    const enabled = status ? 'true' : 'false'
    const emailVerificationStatus: any = {
      true: { title: 'active', variant: 'success' },
      false: { title: 'inactive', variant: 'warning' }
    }
    return <NewStatusBox status={emailVerificationStatus[enabled].title} />
  }

  const toggleRole = async (profileId: string, switchCategory: string) => {
    try {
      await updateUserRole(profileId, switchCategory)
      setInit(!init)
    } catch (error) {
      console.error(error)
    }
  }

  const onSwitchChange = (profileId: string, switchCategory: string) => {
    toggleRole(profileId, switchCategory)
  }

  const onInActiveToggle = async (
    event: React.ChangeEvent<HTMLInputElement>,
    profileId: string
  ) => {
    try {
      await updateInactiveRole(profileId)
      setInit(!init)
    } catch (userInfoError) {
      console.log('userInfoError')
    }
  }

  function switchElement(
    userHasRole,
    profileId,
    switchCategory,
    disabled
  ): ReactElement {
    return (
      <Switch
        size="small"
        checked={userHasRole}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          onSwitchChange(profileId, switchCategory)
        }
        disabled={disabled}
        label={undefined}
      />
    )
  }

  const userCards = useMemo(
    () => [
      {
        title: 'User Information',
        isEditable: false,
        fields: [
          {
            type: 'text',
            name: 'email',
            previewTitle: 'User Email',
            getValue: (userInfo: UserInfo) => {
              return userInfo?.email || ''
            }
          },
          {
            type: 'text',
            name: 'allowedRoles',
            previewTitle: 'User Role',
            getValue: () => {
              if (defaultRoles) {
                const userRoles = defaultRoles.data.roles.map(
                  (role) => role.name
                )

                const rolesToDisplay = [
                  'admin',
                  'infra-manager',
                  'customer-manager'
                ]
                const displayedRoles = userRoles
                  .filter((role) => rolesToDisplay.includes(role))
                  .map((role) =>
                    role
                      .split('-')
                      .map(
                        (word) => word.charAt(0).toUpperCase() + word.slice(1)
                      )

                      .join(' ')
                  )
                  .sort()

                return displayedRoles.join(', ')
              } else {
                return 'No roles assigned'
              }
            }
          },

          {
            type: 'text',
            name: 'state',
            previewTitle: 'Status',
            getValue: (userInfo: IUserDetailsResult) => {
              const disabled = getUserEmail() === userInfo.email
              return (
                <>
                  <Switch
                    size="small"
                    defaultChecked={false}
                    checked={userInfo?.enabled || false}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
                      onInActiveToggle(event, userInfo.id)
                    }
                    disabled={disabled}
                    label={''}
                  />
                  {statusElement(userInfo.enabled)}
                </>
              )
            }
          },
          {
            type: 'text',
            name: 'userAcceptDate',
            previewTitle: 'Verification Date',
            getValue: (userInfo: UserInfo) => {
              return userInfo?.attributes?.INVITATION_ACCEPTED_ON || [] ? (
                <TimeWithCustomFormat
                  date={userInfo?.attributes?.INVITATION_ACCEPTED_ON}
                  customFormat={appConfig.customization.dateFormat}
                />
              ) : (
                ''
              )
            }
          },
          {
            type: 'text',
            name: 'AdminRole',
            previewTitle: 'Admin Role',
            getValue: (userInfo: UserInfo) => {
              const isAdmin = defaultRoles?.data.roles.some(
                (role) => role.name === ROLE_ADMIN
              )
              const disabled = getUserEmail() === userInfo.email
              return switchElement(isAdmin, userInfo.id, ROLE_ADMIN, disabled)
            }
          },
          {
            type: 'text',
            name: 'InfraManagerRole',
            previewTitle: 'Infra Manager Role',
            getValue: (userInfo: UserInfo) => {
              const isInfraManager = defaultRoles?.data.roles.some(
                (role) => role.name === ROLE_INFRA_MANAGER
              )
              const disabled = getUserEmail() === userInfo.email
              return switchElement(
                isInfraManager,
                userInfo.id,
                ROLE_INFRA_MANAGER,
                disabled
              )
            }
          },
          {
            type: 'text',
            name: 'CustomerManagerRole',
            previewTitle: 'Customer Manager Role',
            getValue: (userInfo: UserInfo) => {
              const isCustomerManager = defaultRoles?.data.roles.some(
                (role) => role.name === ROLE_CUSTMNGR
              )
              const disabled = getUserEmail() === userInfo.email
              return switchElement(
                isCustomerManager,
                userInfo.id,
                ROLE_CUSTMNGR,
                disabled
              )
            }
          },
          {
            type: 'text',
            name: 'createdDate',
            previewTitle: 'Created On',
            getValue: (userInfo: UserInfo) => {
              return userInfo?.attributes?.CREATED_DATE || [] ? (
                <TimeWithCustomFormat
                  date={userInfo?.attributes?.CREATED_DATE || []}
                  customFormat={appConfig.customization.dateFormat}
                />
              ) : (
                ''
              )
            }
          }
        ]
      }
    ],
    [isEditable, defaultRoles]
  )
  return { userCards, init }
}
