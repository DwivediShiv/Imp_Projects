import { useCallback, useEffect, useState } from 'react'
import axios from 'axios'
import { ApiResponse, UserInfo, userRoles } from '../types/UserInfo'
import appConfig from 'app.config'
import Toast from '@sharedComponents/Toast'
import { USER_MESSAGES } from '@constants/constants'
import { printErrorStack } from '@saasportal/libs/utils'

export interface UserInfoResponse {
  data: UserInfo
}

export const userInfoApiUrl = `${appConfig.api}/saas-management/api/v1/saas/users`
export const updateRoleUrl = `${appConfig.api}/saas-management/api/v1/saas/users/`
export const getAllRolesUrl = `${appConfig.api}/saas-management/api/v1/saas/roles`

export function updateActiveStateUrl(id: string): string {
  return `${appConfig.api}/saas-management/api/v1/saas/users/update-state/${id}`
}

export function getUserRoleUrl(profileId: string): string {
  return [userInfoApiUrl, profileId, 'roles'].join('/')
}

export default function useUserInfoApi() {
  const [userInfoData, setUserInfoData] = useState<any>()
  const [userInfoError, setUserInfoError] = useState<string>('')
  const [defaultRoles, setDefaultRoles] = useState<userRoles>()
  const [initialLoader, setInitialLoader] = useState<boolean>(true)
  const [userDetailErrorCode, setUserDetailErrorCode] = useState<string | null>(
    ''
  )

  const getUserInfoWithId = useCallback(async (profileId) => {
    try {
      setUserInfoError('')
      const response = await axios.get(`${userInfoApiUrl}/${profileId}`)
      if (response.data) {
        const {
          id,
          createdTimestamp,
          username,
          enabled,
          totp,
          email,
          attributes,
          disableableCredentialTypes,
          requiredActions,
          access
        } = response.data

        setUserInfoData({
          id,
          createdTimestamp,
          username,
          enabled,
          totp,
          email,
          attributes,
          disableableCredentialTypes,
          requiredActions,
          access
        })
      } else {
        console.error('No data found in the response')
      }
      setInitialLoader(false)
    } catch (error) {
      setUserDetailErrorCode(error?.response?.data?.code || 'General')
      setInitialLoader(false)
      setUserInfoError(error?.response?.data?.error.message)
    }
  }, [])

  const getOrgUserRoles = useCallback(async (profileId: string) => {
    try {
      setUserInfoError('')
      const url = `${getUserRoleUrl(profileId)}`
      const { data: response } = await axios.get<userRoles>(url)
      setDefaultRoles(response)
    } catch (error) {
      setUserInfoError(error?.response?.data?.error.message)
    }
  }, [])

  const updateUserRole = useCallback(
    async (profileId: string, userRole: string) => {
      try {
        setUserInfoError('')
        const { data: response } = await axios.put<ApiResponse<userRoles>>(
          `${updateRoleUrl}\\${userRole}\\${profileId}`
        )
        setUserInfoError(null)
        return response?.data
      } catch (error) {
        if (axios.isAxiosError(error)) {
          setUserInfoError(error.message)
        } else {
          setUserInfoError('unexpected error')
        }
      }
    },
    []
  )

  const getAllOrgRoles = useCallback(async () => {
    try {
      setUserInfoError('')
      const { data: response } = await axios.get(getAllRolesUrl)
      return response?.data
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setUserInfoError(error.message)
      } else {
        setUserInfoError('unexpected error')
      }
    }
  }, [])

  const updateInactiveRole = async (profileId: string) => {
    try {
      const { data: response } = await axios.put<ApiResponse<any>>( // any to be updated as per the response
        updateActiveStateUrl(profileId)
      )
      Toast('success', USER_MESSAGES.USER_INFO_UPDATED)
    } catch (error) {
      if (error.response?.data?.error.additionalData) {
        Toast('error', error.response?.data?.error.additionalData)
      } else if (axios.isAxiosError(error)) {
        const { message = '', additionalData = {} } =
          error?.response?.data?.error ?? {}
        const additionalErrors = Object.values(additionalData)
        Toast('error', additionalErrors?.length ? additionalErrors[0] : message)
      } else {
        Toast('error', USER_MESSAGES.ERROR_COMMON)
        printErrorStack(error)
      }
    }
  }
  return {
    userInfoData,
    userInfoError,
    setUserInfoData,
    getUserInfoWithId,
    getOrgUserRoles,
    defaultRoles,
    updateUserRole,
    getAllOrgRoles,
    updateInactiveRole,
    initialLoader,
    userDetailErrorCode
  }
}
