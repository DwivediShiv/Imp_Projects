import { Grid } from '@mui/material'
import React, { ReactElement, useState, useEffect } from 'react'
import styles from './index.module.css'
import BackIcon from '@images/back_icon.svg'
import { useRouter } from 'next/router'
import useUserInfoApi from './hooks/useUserInfoApi'
import Loader from '@sharedComponents/CustomLoader'
import { useAuthorize } from '@core/context/Authorize'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_ADMIN,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import Permission from '@sharedComponents/Permission'
import useUserCards from './hooks/useUserInfoConfig'
import GridCard from '@sharedComponents/GridCard'
import appConfig from 'app.config'
import CustomButton from '@sharedComponents/Button'
import WithCustomFormat from '@sharedComponents/TimeHOC'
import Time from '@sharedComponents/Time'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Warning from '@sharedComponents/WarningMessage'

function UserDetails({ userId }: { userId: string }): ReactElement {
  const { isLogin } = useAuthorize()
  const TimeWithCustomFormat = WithCustomFormat(Time)
  const router = useRouter()
  const {
    userInfoData,
    getUserInfoWithId,
    userInfoError,
    getOrgUserRoles,
    defaultRoles,
    initialLoader,
    userDetailErrorCode
  } = useUserInfoApi()
  const { userCards, init } = useUserCards(defaultRoles)

  useEffect(() => {
    if (isLogin) {
      getUserInfoWithId(userId)
      getOrgUserRoles(userId)
    }
  }, [getUserInfoWithId, userId, getOrgUserRoles, isLogin, init])

  function handleClick() {
    router.back()
  }

  function renderUserInfoData() {
    if (userInfoError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = userInfoError

      const isUnauthorize = userDetailErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }
    if (!userInfoData) {
      return null
    }
    return (
      <div>
        {userCards.map((cardConfig, index) => {
          return (
            <Grid
              className={styles.content}
              container
              rowSpacing={4}
              columnSpacing={3}
            >
              <Grid key={index} item xs={12} md={12} lg={9}>
                <GridCard cardConfig={cardConfig} data={userInfoData} />
              </Grid>
            </Grid>
          )
        })}
      </div>
    )
  }

  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_ADMIN} isBigBoardError>
        {initialLoader ? (
          <div className={styles.loader}>
            <Loader />
          </div>
        ) : (
          <>
            {!userInfoError && (
              <CustomButton onClick={handleClick} aria-label="Go Back">
                <BackIcon />
              </CustomButton>
            )}

            {!userInfoError ? (
              <div className="mb-8">
                <h3>{userInfoData?.username}&apos;s Details</h3>
                <p className={`body-1 mt-2 ${styles.headerDescription}`}>
                  Last logged in:{' '}
                  {
                    <TimeWithCustomFormat
                      date={userInfoData?.attributes.LAST_LOGIN}
                      customFormat={appConfig.customization.dateFormat}
                    />
                  }
                </p>
              </div>
            ) : null}

            <div>{renderUserInfoData()}</div>
          </>
        )}
      </Permission>
    </PrivateRoute>
  )
}

export default UserDetails
