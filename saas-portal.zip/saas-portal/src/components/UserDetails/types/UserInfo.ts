export interface UserInfo {
  id: number
  org_id?: string
  profileId?: string
  email: string
  allowedRoles: string
  state: string
  userInviteDate?: string
  createdBy?: string
  sortBy?: string
  sortOrder?: string
  createdDate?: string
  activatedOn?: string
  userAcceptDate?: string
  username?: string
  attributes?: IUserAttributes
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

// TODO: Move to `common-js`
export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}

export interface IUserAttributes {
  CREATED_BY?: string[]
  CREATED_DATE?: string[]
  INVITATION_ACCEPTED_ON?: string[]
  LAST_LOGIN?: string[]
  USER_VALIDATE_DATE?: string[]
  LOGIN_COUNT?: string[]
  ROLES_WALLET?: string[]
  STATE?: string[]
  UPDATE_DATE?: string[]
}

export interface IUserDetailsResult {
  id: string
  createdTimestamp?: Date
  username: string
  enabled?: boolean
  emailVerified?: boolean
  email: string
  attributes?: IUserAttributes
}

export interface IUserInfo {
  id: string
  username: string
  isUserValidated?: boolean
  isUserAdmin: boolean
  isEmailVerified: boolean
  lastLoginDate: string
  userValidateDate: string
  attributes?: IUserAttributes
}

export interface RoleInfo {
  id: string
  name: string
  composite: boolean
  clientRole: boolean
  containerId: string
  description: string
}

export interface userRoles {
  roles: RoleInfo[]
  isAdmin: boolean
}
