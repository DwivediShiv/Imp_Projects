import React, { useCallback, useMemo, useState } from 'react'
import { SELECTION_CONSTANTS } from '@constants/constants'
import useCustomersListApi from './useCustomersListApi'
import appConfig from 'app.config'
export const useManageCustomers = () => {
  const [page, setPage] = useState(1)
  const [sortBy, setSortBy] = useState<string>('')
  const [sortOrder, setSortOrder] = useState<string>('')
  const [searchValue, setSearchValue] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>()
  const [filterCountry, setFilterCountry] = useState<string[]>([])
  const [filterIndustry, setFilterIndustry] = useState<string[]>([])
  const { exportCustomersList } = useCustomersListApi()
  const [refreshList, setRefreshList] = useState<number>(0)
  const handleSelect = useCallback(
    (
      e: React.ChangeEvent<HTMLInputElement>,
      items: Record<string, string>,
      type: string
    ) => {
      setPage(1)
      e.preventDefault()
      const { value } = e.target
      const options = Object.keys(items)
      if (value[value.length - 1] === SELECTION_CONSTANTS.ALL) {
        type === 'country' &&
          setFilterCountry(
            filterCountry.length === options.length ? [] : options
          )
        type === 'industry' &&
          setFilterIndustry(
            filterIndustry.length === options.length ? [] : options
          )
        return
      }
      type === 'country' &&
        setFilterCountry(typeof value === 'string' ? value.split(',') : value)
      type === 'industry' &&
        setFilterIndustry(typeof value === 'string' ? value.split(',') : value)
    },
    [filterCountry.length, filterIndustry.length]
  )

  const handleClearFilter = () => {
    setPage(1)
    setSearchValue('')
    setFilterCountry([])
    setFilterIndustry([])
    setSortBy('')
    setSortOrder('')
  }

  function noFilteredData() {
    return (
      searchValue !== '' ||
      filterCountry.length > 0 ||
      filterIndustry.length > 0
    )
  }

  const customersListConfig = useMemo(() => {
    return {
      title: '',
      searchConfig: {
        type: 'search',
        name: 'search',
        placeholder: 'Search...',
        searchValue
      },
      exportConfig: {
        exportFn: () =>
          exportCustomersList(
            searchValue,
            filterCountry,
            filterIndustry,
            sortBy,
            sortOrder
          ),
        fileName: 'customersList.csv'
      },
      refreshConfig: {
        name: 'Refresh List',
        handleRefreshList: () => setRefreshList(Math.random())
      },
      columns: [
        {
          id: 'name',
          title: 'Customer Name',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'name',
          class: 'name',
          rowConfig: {
            cellType: 'clickableField',
            clickable: (row) => {
              return true
            },
            value: 'name',
            onClick: (row) => {
              return `/customer-details/${row.id}`
            }
          },
          grow: 1.75,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'name'
        },
        {
          id: 'businessNumber',
          title: 'Business Number',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'businessNumber',
          class: 'businessNumber',
          rowConfig: {
            cellType: 'default',
            value: 'businessNumber',
            clickable: 'false'
          },
          grow: 1,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'business_number'
        },
        {
          id: 'industry',
          title: 'Industry',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'industry',
          class: 'industry',
          rowConfig: {
            cellType: 'default',
            value: 'industry',
            clickable: 'false'
          },
          grow: 1,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'industry'
        },
        {
          id: 'country',
          title: 'Country',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'country',
          class: 'country',
          rowConfig: {
            cellType: 'default',
            value: 'country',
            clickable: 'false'
          },
          grow: 1,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'country'
        },
        {
          id: 'createdAt',
          title: 'Created On',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'createdAt',
          class: 'createdAt',
          rowConfig: {
            cellType: 'dateField',
            format: appConfig.customization.dateFormat,
            value: 'createdAt'
          },
          grow: 1,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'created_at',
          allowOverflow: false
        },
        {
          id: 'createdBy',
          title: 'Created By',
          type: 'tableHeader',
          sortable: true,
          sortBy: 'createdBy',
          rowConfig: {
            cellType: 'default',
            value: 'createdBy'
          },
          grow: 1.5,
          style:
            '{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis }',
          sortField: 'created_by',
          allowOverflow: false
        }
      ],
      filterConfig: {
        clearFilters: handleClearFilter,
        filters: [
          {
            id: 'Countries',
            inputName: 'Country',
            label: 'Country',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterCountry,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterCountry,
            onChange: (e, items) => {
              handleSelect(e, items, 'country')
            }
          },
          {
            id: 'Industries',
            inputName: 'Industry',
            label: 'Industry',
            dynamic: true,
            containerClass: 'exploreFilter',
            customBackground: '--surface-1-color',
            value: filterIndustry,
            deselectText: SELECTION_CONSTANTS.ALL,
            onValueChange: setFilterIndustry,
            onChange: (e, items) => {
              handleSelect(e, items, 'industry')
            }
          }
        ]
      }
    }
  }, [
    searchValue,
    filterCountry,
    filterIndustry,
    exportCustomersList,
    sortBy,
    sortOrder,
    handleSelect
  ])

  const handlePageChange = (page) => {
    setPage(page)
  }

  const handleSortChange = async (
    column: { sortField: string },
    sortDirection: string
  ) => {
    setSortBy(column.sortField)
    setSortOrder(sortDirection)
  }

  const handleOnSearch = (e) => {
    setPage(1)
    setSearchValue(e.target.value)
  }

  return {
    searchValue,
    handleOnSearch,
    handleSortChange,
    handlePageChange,
    sortBy,
    sortOrder,
    filterIndustry,
    filterCountry,
    customersListConfig,
    page,
    isLoading,
    setIsLoading,
    noFilteredData,
    refreshList
  }
}
