import { useCallback, useState } from 'react'
import axios, { AxiosResponse } from 'axios'
import {
  ApiResponse,
  CustomersDetail,
  CustomersList
} from '../types/CustomersList'
import appConfig from 'app.config'
import { buildUrlWithQueryParams } from '@utils/url'
import { customersListMSW, filterCriteriasMSW } from '../msw/customersListData'

export interface CustomersListResponse {
  data: CustomersList
}

export let customerListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/customer/list`

export default function useCustomersListApi() {
  const [customerListData, setCustomersListData] =
    useState<any>(customersListMSW)
  const [customerListError, setCustomersListError] = useState<string | null>('')
  const [customerListTotal, setCustomersTotal] = useState<number>(
    customersListMSW.totalRecord
  )

  const [filterCriterias, setFilterCriterias] =
    useState<Record<string, string[]>>(filterCriteriasMSW)
  const [initialLoader, setInitialLoader] = useState<boolean>(true)
  const [customerListErrorCode, setCustomerListErrorCode] = useState<
    string | null
  >('')

  const fetchCustomersList = useCallback(
    async ({
      page,
      sortBy,
      sortOrder,
      searchValue,
      setIsLoading,
      filterCountry,
      filterIndustry
    }) => {
      try {
        const urlParams: Record<string, string> = {}
        setCustomersListError('')
        setCustomersTotal(0)
        setIsLoading(true)

        customerListApiUrl = `${appConfig.api}/saas-management/api/v1/saas/management/customer/list`

        if (page) {
          urlParams.page = page
        }

        if (sortBy) {
          urlParams.sortBy = sortBy
        }

        if (sortOrder) {
          urlParams.sortOrder = sortOrder
        }

        if (searchValue !== '') {
          urlParams.name = searchValue
        }

        if (filterCountry?.length) {
          urlParams.country = filterCountry
        }

        if (filterIndustry?.length) {
          urlParams.industry = filterIndustry
        }

        const { data: response } = await axios.post<
          ApiResponse<CustomersDetail>
        >(customerListApiUrl, urlParams)

        if (response.filterCriterias) {
          setFilterCriterias(response.filterCriterias)
        }

        setCustomersListData(response.data)
        setCustomersTotal(response.totalRecord)
        setInitialLoader(false)
      } catch (error) {
        setCustomerListErrorCode(error?.response?.data?.code || 'General')
        setInitialLoader(false)
        setCustomersListError(error?.response?.data?.error?.message)
      } finally {
        setInitialLoader(false)
        setIsLoading(false)
      }
    },
    []
  )

  function getExportCustomersUrlParam(
    name?: string,
    filterCountry?: string,
    filterIndustry?: string,
    sortBy?: string,
    sortOrder?: string
  ): any {
    const urlParams: Record<string, string> = {}
    urlParams.get = 'All'

    if (name !== '') {
      urlParams.name = name
    }

    if (filterCountry?.length) {
      urlParams.country = filterCountry
    }

    if (filterIndustry?.length) {
      urlParams.industry = filterIndustry
    }

    if (sortBy) {
      urlParams.sortBy = sortBy
    }

    if (sortOrder) {
      urlParams.sortOrder = sortOrder
    }

    return urlParams
  }

  async function exportCustomersList(
    searchValue,
    filterCountry,
    filterIndustry,
    sortBy,
    sortOrder
  ): Promise<string> {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: `${appConfig.api}/saas-management/api/v1/saas/management/customer/list/export`,
        data: getExportCustomersUrlParam(
          searchValue,
          filterCountry,
          filterIndustry,
          sortBy,
          sortOrder
        )
      })
      return response.data
    } catch (error) {
      console.error(`Error at exportCustomerList(): ${error}`)
      console.log(error)
    }
  }

  return {
    customerListData,
    customerListError,
    setCustomersListData,
    exportCustomersList,
    fetchCustomersList,
    customerListTotal,
    filterCriterias,
    initialLoader,
    customerListErrorCode
  }
}
