import { CustomersList } from '../types/CustomersList'

export const customersListMSW: CustomersList = {
  data: [
    {
      id: 1,
      name: 'Mercedes-Benz Group',
      business_number: 'SM78123231239',
      industry: 'Automobile',
      country: 'Austria',
      created_date: '2023-08-22T06:02:58.036Z',
      created_by: 'admin@acentrik.com'
    },
    {
      id: 2,
      name: 'Tesla, Inc.',
      business_number: 'TSLA78123231239',
      industry: 'Automobile',
      country: 'United States',
      created_date: '2023-08-23T09:15:42.125Z',
      created_by: 'user@company.com'
    },
    {
      id: 3,
      name: 'Apple Inc.',
      business_number: 'APPL78123231239',
      industry: 'Technology',
      country: 'United States',
      created_date: '2023-08-24T14:30:22.711Z',
      created_by: 'admin@acentrik.com'
    },
    {
      id: 4,
      name: 'Samsung Electronics',
      business_number: 'SAMS78123231239',
      industry: 'Technology',
      country: 'South Korea',
      created_date: '2023-08-25T18:45:15.953Z',
      created_by: 'user@company.com'
    },
    {
      id: 5,
      name: 'Toyota Motor Corporation',
      business_number: 'TOYO78123231239',
      industry: 'Automobile',
      country: 'Japan',
      created_date: '2023-08-26T11:20:33.821Z',
      created_by: 'admin@acentrik.com'
    },
    {
      id: 6,
      name: 'Microsoft Corporation',
      business_number: 'MSFT78123231239',
      industry: 'Technology',
      country: 'United States',
      created_date: '2023-08-27T17:12:47.449Z',
      created_by: 'user@company.com'
    },
    {
      id: 7,
      name: 'Boeing Company',
      business_number: 'BOEI78123231239',
      industry: 'Aerospace',
      country: 'United States',
      created_date: '2023-08-28T20:58:55.673Z',
      created_by: 'admin@acentrik.com'
    },
    {
      id: 8,
      name: 'Amazon.com, Inc.',
      business_number: 'AMZN78123231239',
      industry: 'E-commerce',
      country: 'United States',
      created_date: '2023-08-29T14:37:06.524Z',
      created_by: 'user@company.com'
    },
    {
      id: 9,
      name: 'Ford Motor Company',
      business_number: 'FORD78123231239',
      industry: 'Automobile',
      country: 'United States',
      created_date: '2023-08-30T09:44:11.728Z',
      created_by: 'admin@acentrik.com'
    },
    {
      id: 10,
      name: 'Alphabet Inc. (Google)',
      business_number: 'GOOG78123231239',
      industry: 'Technology',
      country: 'United States',
      created_date: '2023-08-31T16:59:22.913Z',
      created_by: 'user@company.com'
    }
  ],
  totalRecord: 13
}

export const filterCriteriasMSW = {
  Country: ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Czech Republic'],
  Industry: ['Aerospace', 'Agriculture', 'Automotive', 'Blockchain', 'Energy']
}
