import { rest } from 'msw'
import {
  ApiResponse,
  MswHandlerProps,
  CustomersList
} from '../types/CustomersList'
import { customersListMSW } from './customersListData'
import { server } from '@utils/msw'

export function setupGetUserListDataHandler(
  props?: MswHandlerProps<CustomersList>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(
    'https://dev.saas-portal.saas-acentrik.com/saas-management/api/v1/saas/user-list',
    async (_, res, ctx) => {
      let json: ApiResponse<CustomersList>
      const data = customersListMSW

      if (props?.response) {
        json = props.response
      } else {
        json = {
          data
        }
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}
