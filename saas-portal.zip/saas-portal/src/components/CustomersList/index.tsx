import CustomButton from '@sharedComponents/Button'
import Container from '@sharedComponents/Container'
import Link from 'next/link'
import React, { useCallback, useEffect } from 'react'
import classNames from 'classnames'
import styles from './index.module.css'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'
import {
  ERROR_UNAUTH,
  FAILURE_MESSAGES,
  GENERAL_FAILURE,
  PERMISSION_CUSTOMERMNGR,
  RESTRICTED_ACCESS
} from '@constants/permissionConstants'
import { useAuthorize } from '@core/context/Authorize'
import { useManageCustomers } from './hooks/useManageCustomers'
import useCustomersListApi from './hooks/useCustomersListApi'
import CustomTableList from '@sharedComponents/CustomTableList'
import Loader from '@sharedComponents/CustomLoader'
import { CustomIconicCardState } from '@sharedComponents/IconicCard'
import Warning from '@sharedComponents/WarningMessage'
import { debounce } from 'lodash'

const ManageCustomers = () => {
  const { isLogin, isCustomerMngr } = useAuthorize()
  const {
    page,
    handlePageChange,
    sortBy,
    sortOrder,
    searchValue,
    handleSortChange,
    handleOnSearch,
    isLoading,
    setIsLoading,
    filterCountry,
    filterIndustry,
    noFilteredData,
    customersListConfig,
    refreshList
  } = useManageCustomers()

  const {
    customerListData,
    customerListError,
    fetchCustomersList,
    customerListTotal,
    filterCriterias,
    initialLoader,
    customerListErrorCode
  } = useCustomersListApi()

  const debouncefetch = useCallback(
    debounce((params) => {
      fetchCustomersList(params)
    }, 500),
    []
  )

  useEffect(() => {
    const param = {
      page,
      sortBy,
      sortOrder,
      searchValue,
      setIsLoading,
      filterCountry,
      filterIndustry
    }
    debouncefetch(param)
  }, [
    fetchCustomersList,
    page,
    searchValue,
    setIsLoading,
    sortBy,
    sortOrder,
    filterCountry,
    filterIndustry,
    isLogin,
    refreshList
  ])

  const renderCustomersListData = () => {
    if (customerListError) {
      let header = GENERAL_FAILURE
      let state = CustomIconicCardState.Warning
      let message = customerListError

      const isUnauthorize = customerListErrorCode === ERROR_UNAUTH
      if (isUnauthorize) {
        header = RESTRICTED_ACCESS
        state = CustomIconicCardState.Alert
        message = FAILURE_MESSAGES.RESTRICTED_ACCESS
      }
      return (
        <Warning
          message={message}
          header={header}
          icon={isUnauthorize ? 'restricted-access' : 'not-found'}
          state={state}
        />
      )
    }

    return (
      <CustomTableList
        configuration={customersListConfig}
        data={customerListData}
        totalRecord={customerListTotal}
        isLoading={isLoading}
        paginationSize={10}
        sortBy={sortBy}
        sortOrder={sortOrder}
        handlePageChange={handlePageChange}
        page={page}
        handleSortChange={handleSortChange}
        state={status}
        handleOnSearch={handleOnSearch}
        filterCriterias={filterCriterias}
        searchValue={searchValue}
        noFilteredData={noFilteredData}
        tabIndex={0}
      />
    )
  }
  // add customer permision
  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_CUSTOMERMNGR} isBigBoardError>
        {initialLoader ? (
          <div className={styles.loader}>
            <Loader />
          </div>
        ) : (
          <Container className={classNames(styles.headerContent, 'container')}>
            <section className={styles.grid}>
              <div className={styles.topBar}>
                {!(
                  customerListError && customerListErrorCode === ERROR_UNAUTH
                ) &&
                  isCustomerMngr && (
                    <h3 className="bold">Customer Management</h3>
                  )}
                {!(
                  customerListError && customerListErrorCode === ERROR_UNAUTH
                ) &&
                  isCustomerMngr && (
                    <Link href="add-customer" legacyBehavior>
                      <CustomButton
                        color="primary"
                        variant="contained"
                        className={styles.inviteButton}
                      >
                        Add New Customer
                      </CustomButton>
                    </Link>
                  )}
              </div>
            </section>
            {renderCustomersListData()}
          </Container>
        )}
      </Permission>
    </PrivateRoute>
  )
}

export default ManageCustomers
