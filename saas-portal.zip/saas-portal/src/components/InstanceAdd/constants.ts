export const CREATE_INSTANCE = {
  SUCCESS: 'Successful. New Instance creation triggered.',
  ERROR: 'Unable to create new Instance. Please try again later.'
}
export const ERROR_TYPES = {
  CREATE_INSTANCE: 'create_instance',
  FETCH_CUSTOMERS: 'fetch_customers',
  FETCH_VERSIONS: 'fetch_versions'
}

export const UNEXPECTED_ERROR = 'unexpected error'
