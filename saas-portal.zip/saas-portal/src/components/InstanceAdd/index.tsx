import React from 'react'
import styles from './index.module.css'
import useSectionConfig from './hooks/useCreateInstance'
import { PERMISSION_INFRAMANAGER } from '@constants/permissionConstants'
import SectionForm from '@sharedComponents/SectionForm'
import PrivateRoute from '@sharedComponents/PrivateRoute'
import Permission from '@sharedComponents/Permission'

const CreateInstance = () => {
  const { sectionConfig, initialValues, validationSchema, handleSubmit } =
    useSectionConfig()
  return (
    <PrivateRoute>
      <Permission eventType={PERMISSION_INFRAMANAGER} isBigBoardError>
        <>
          <section className={styles.grid}>
            <div className={styles.topBar}>
              <h3 className="bold">Create Instance</h3>
            </div>
          </section>
          <SectionForm
            sectionConfig={sectionConfig}
            initialValues={initialValues}
            validationSchema={validationSchema || {}}
            handleSubmit={handleSubmit}
          />
        </>
      </Permission>
    </PrivateRoute>
  )
}

export default CreateInstance
