import React from 'react'
import { fireEvent, render, screen } from '@testing-library/react'
import { useAuthorize, AuthorizeProviderValue } from '@core/context/Authorize'
import CreateInstance from '..'

const mockRouterBack = jest.fn()

interface RenderOptions {
  authorize: Partial<AuthorizeProviderValue>
}

jest.mock('next/router', () => ({
  useRouter: () => ({
    back: mockRouterBack
  })
}))
jest.mock('@utils/auth', () => ({
  hasAccess: jest.fn().mockReturnValue(true)
}))

jest.mock('@core/context/Authorize')

jest.mock('@core/context/FancyState', () => ({
  useFancyState: jest.fn().mockReturnValue({
    getSelectionOptionsByCategory: jest.fn().mockReturnValue([])
  })
}))

function renderComponent(options: RenderOptions) {
  const useAuthorizeMock = useAuthorize as jest.Mock<
    Partial<AuthorizeProviderValue>
  >
  const { isLogin } = options.authorize

  useAuthorizeMock.mockReturnValue({
    isLogin
  })

  render(<CreateInstance />)
}

describe('create instance ', () => {
  it('login component should render if unauthorized', async () => {
    renderComponent({
      authorize: {
        isLogin: false
      }
    })
    expect(await screen.findByText('Account Required')).toBeInTheDocument()
    expect(
      await screen.findByRole('button', { name: /login/i })
    ).toBeInTheDocument()
  })

  it('render component', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(
      await screen.findByRole('heading', {
        name: /instance information/i
      })
    )
    expect(await screen.findByText(/select customer\*/i)).toBeInTheDocument()
    expect(await screen.findByText(/select aws account\*/i)).toBeInTheDocument()
    expect(await screen.findByText(/instance name\*/i)).toBeInTheDocument()
    expect(await screen.findByText(/description\*/i)).toBeInTheDocument()
    expect(await screen.findByText(/region\*/i)).toBeInTheDocument()
    expect(await screen.findByText(/contact email id\*/i)).toBeInTheDocument()

    expect(await screen.findByText(/network\*/i)).toBeInTheDocument()
    expect(
      await screen.findByRole('textbox', { name: /custom email domain/i })
    ).toBeInTheDocument()
  })

  it('enable custom email domain when typing in domain textbox ', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(
      await screen.findByRole('textbox', { name: /custom email domain/i })
    ).toBeDisabled()
    const customDomainTextBox = await screen.findByRole('textbox', {
      name: /custom domain/i
    })
    fireEvent.change(customDomainTextBox, {
      target: { value: 'domain expansion' }
    })

    expect(
      await screen.findByRole('textbox', { name: /custom email domain/i })
    ).toBeEnabled()
  })

  it('cancel button', async () => {
    renderComponent({
      authorize: {
        isLogin: true
      }
    })
    expect(
      await screen.findByRole('heading', {
        name: /instance information/i
      })
    )

    const cancelButton = await screen.findByRole('button', { name: /cancel/i })
    fireEvent.click(cancelButton)
    expect(mockRouterBack).toHaveBeenCalledTimes(1)
  })

  // it('handles back button', async () => {
  //   setupGetNodeDataHandler({
  //     nodeStatus: EDGE_NODE_STATE.ACTIVE,
  //     private: false
  //   })
  //   renderComponent(
  //     {
  //       authorize: {
  //         isLogin: true
  //       }
  //     }
  //   )
  // expect(
  //   await screen.findByRole('heading', {
  //     name: /instance information/i
  //   })
  // )
  //   const backButton = await screen.findByLabelText(/go back/i)
  //   user.click(backButton)
  //   expect(mockRouterBack).toHaveBeenCalledTimes(1)
  // })
})
