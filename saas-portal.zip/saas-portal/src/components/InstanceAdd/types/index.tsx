export interface Instance {
  instanceCustomer: string
  awsAccount: string
  instanceName: string
  instanceDescription: string
  instanceRegion: string
  contactEmailId: string
  customDomain?: string
  customEmailDomain?: string
  instanceNetwork: string
  instanceVersion: string
  tokenAddress: string
  tokenSymbol: string
  instanceDecimal: number | string
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}
export interface InstanceError {
  type: string
  error: any
}
export interface InstanceCustomers {
  name: string
  id: string
}
