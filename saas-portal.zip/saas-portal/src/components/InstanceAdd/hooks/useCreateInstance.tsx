import { useRouter } from 'next/router'
import React, { useMemo, useEffect, useState } from 'react'
import * as Yup from 'yup'
import {
  ENTER_VALID_EMAIL,
  MAX_100_CHAR_ALLOWED,
  MAX_25_CHAR_ALLOWED,
  MAX_500_CHAR_ALLOWED,
  MAX_50_CHAR_ALLOWED,
  REQUIRED_FIELD
} from '@constants/constants'
import CustomDropDown from '@sharedComponents/Dropdown'
import Toast from '@sharedComponents/Toast'
import InputField from '@sharedComponents/InputField'
import useCreateInstanceApi from './useCreateInstanceApi'
import { Instance } from '../types'
import { CREATE_INSTANCE, ERROR_TYPES } from '../constants'
import { useFancyState } from '@core/context/FancyState'
import { useAuthorize } from '@core/context/Authorize'
import { isAddress } from 'ethers/lib/utils'

const useSectionConfig = () => {
  const {
    createInstance,
    instanceError,
    instanceCustomers,
    instanceVersions,
    fetchInstanceVersions,
    fetchInstanceCustomers
  } = useCreateInstanceApi()
  const { isLogin } = useAuthorize()
  const router = useRouter()
  const [awsAccounts, setAwsAccounts] = useState([])
  const [instanceRegions, setInstanceRegions] = useState([])
  const [instanceNetworks, setInstanceNetworks] = useState([])
  const [tokenSymbols, setTokenSymbols] = useState([])
  const { getSelectionOptionsByCategory, selectionOptions } = useFancyState()
  const [loading, setLoading] = useState<boolean>(false)

  async function loadSelectionOptions() {
    const options = await getSelectionOptionsByCategory('AWSAccount')
    const awsAccountNames = options.map((option) => {
      return option.name
    })
    const regionOptions = await getSelectionOptionsByCategory('Region')
    const instanceRegionNames = regionOptions.map((option) => {
      return option.name
    })
    const networkOptions = await getSelectionOptionsByCategory('Network')
    const instanceNetworkNames = networkOptions.map((option) => {
      return option.name
    })
    const symbolsOptions = await getSelectionOptionsByCategory('NetworkTicker')
    const instanceTokenSymbols = symbolsOptions.map((option) => {
      return option.name
    })
    setAwsAccounts(awsAccountNames)
    setInstanceRegions(instanceRegionNames)
    setInstanceNetworks(instanceNetworkNames)
    setTokenSymbols(instanceTokenSymbols)
  }

  useEffect(() => {
    if (instanceError && instanceError.type === ERROR_TYPES.CREATE_INSTANCE) {
      let errorMessage

      const additionalData =
        instanceError.error?.response?.data?.error?.additionalData
      if (additionalData) {
        if (typeof additionalData === 'string') {
          errorMessage = additionalData
        } else {
          const additionalErrors = Object.values(additionalData) // if object
          errorMessage = additionalErrors?.length && additionalErrors[0]
        }
      } else {
        errorMessage = instanceError.error.message
      }

      Toast('error', errorMessage)
    } else if (instanceError === null) {
      Toast('success', CREATE_INSTANCE.SUCCESS)
      router.back()
    }
  }, [instanceError])

  useEffect(() => {
    if (isLogin) {
      loadSelectionOptions()
      fetchInstanceCustomers()
      fetchInstanceVersions()
    }
  }, [selectionOptions, isLogin])

  const initialValues: Partial<Instance> = {
    instanceCustomer: '',
    awsAccount: '',
    instanceName: '',
    instanceDescription: '',
    instanceRegion: '',
    contactEmailId: '',
    customDomain: '',
    customEmailDomain: '',
    instanceNetwork: '',
    instanceVersion: '',
    tokenAddress: '',
    tokenSymbol: '',
    instanceDecimal: ''
  }
  const validationSchema: Yup.SchemaOf<Instance> = Yup.object().shape({
    instanceCustomer: Yup.string().required(REQUIRED_FIELD),
    awsAccount: Yup.string().required(REQUIRED_FIELD),
    instanceName: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(/^[a-z0-9-]*$/, {
        message:
          'Instance Name should be lowercase alphanumeric and may contain hyphens.'
      })
      .max(25, MAX_25_CHAR_ALLOWED),
    instanceDescription: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .max(500, MAX_500_CHAR_ALLOWED),
    instanceRegion: Yup.string().required(REQUIRED_FIELD),
    contactEmailId: Yup.string()
      .email(ENTER_VALID_EMAIL)
      .required(REQUIRED_FIELD),
    customDomain: Yup.string()
      .trim()
      .matches(
        /^(https?:\/\/)?([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/)?$/,
        'Please enter correct Domain.'
      )
      .max(50, MAX_50_CHAR_ALLOWED),
    customEmailDomain: Yup.string()
      .trim()
      .matches(
        /^(https?:\/\/)?([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/)?$/,
        'Please enter correct Email Domain.'
      )
      .max(50, MAX_50_CHAR_ALLOWED)
      .test(
        'Custom Email Domain Constraint',
        'Custom email domain is required with custom domain',
        function (value: string, context: Yup.TestContext<any>) {
          const { customDomain } = context.parent
          if (customDomain && !value) {
            return false
          }
          return true
        }
      ),
    instanceNetwork: Yup.string().required(REQUIRED_FIELD),
    instanceVersion: Yup.string().required(REQUIRED_FIELD),
    tokenAddress: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(
        /^[a-zA-Z0-9]+$/,
        'Token Address should be alphanumeric without spaces.'
      )
      .max(100, 'Token Address is too long, maximum length is 100 characters')
      .test(
        'Invalid Address check',
        'Token Address is invalid',
        function (value: string) {
          if (!isAddress(value)) {
            return false
          }
          return true
        }
      ),
    tokenSymbol: Yup.string()
      .trim()
      .required(REQUIRED_FIELD)
      .matches(
        /^[a-zA-Z0-9]+$/,
        'Token Symbol should be alphanumeric without spaces.'
      ),
    instanceDecimal: Yup.string()
      .matches(/^\d+$/, 'Please enter a whole number')
      .test(
        'max-length',
        'Please enter a value less than or equal to 18',
        (value) => !value || parseInt(value, 10) <= 18
      )
      .required(REQUIRED_FIELD)
  })

  const onCancel = () => {
    router.back()
  }

  async function formatValues(values: Instance) {
    const {
      instanceName,
      contactEmailId,
      instanceDecimal,
      instanceDescription,
      instanceRegion,
      awsAccount,
      customDomain,
      customEmailDomain,
      instanceCustomer,
      instanceNetwork,
      tokenAddress,
      tokenSymbol,
      instanceVersion
    } = values
    const regionOptions = await getSelectionOptionsByCategory('Region')
    const regionKey = regionOptions.filter(
      (region) => region.name === instanceRegion
    )[0]?.key
    return {
      name: instanceName.trim(),
      contactEmail: contactEmailId,
      decimal: instanceDecimal,
      description: instanceDescription.trim(),
      region: regionKey,
      awsAccount: awsAccount,
      customDomain: customDomain.trim(),
      customEmailDomain:
        customDomain.trim() === '' ? '' : customEmailDomain.trim(),
      customerName: instanceCustomer,
      network: instanceNetwork,
      tokenAddress: tokenAddress.trim(),
      tokenSymbol: tokenSymbol.trim(),
      version: instanceVersion
    }
  }
  const handleSubmit = async (
    values: Instance,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ): Promise<void> => {
    setLoading(true)
    const payload = await formatValues(values)
    await createInstance(payload, setLoading)
  }

  function setOptions(inputName: string) {
    switch (inputName) {
      case 'instanceCustomer':
        return instanceCustomers.map((option) => option?.name)
      case 'awsAccount':
        return awsAccounts

      case 'instanceRegion':
        return instanceRegions

      case 'instanceNetwork':
        return instanceNetworks

      case 'instanceVersion':
        return instanceVersions.map((version) => version.Version)
      case 'tokenSymbol':
        return tokenSymbols

      default:
        return []
    }
  }
  function dropDownComponent({
    field,
    form,
    name,
    excludedValid,
    disabled,
    ...restProps
  }) {
    const inputName = name || field?.name
    const hasError = form?.touched[inputName] && form?.errors[inputName]
    const isValid =
      form?.touched[inputName] && form?.values[inputName] && !hasError
    const options = setOptions(inputName)

    return (
      <CustomDropDown
        inputName={inputName}
        options={options}
        error={hasError}
        isValid={!excludedValid && !!isValid}
        disabled={disabled}
        {...field}
        {...restProps}
      />
    )
  }
  const sectionConfig = useMemo(
    () => [
      {
        name: 'instanceInformation',
        title: 'Instance Information',
        type: 'form',
        fields: [
          {
            name: 'instanceCustomer',
            label: 'Select Customer*',
            elementType: 'custom',
            getComponent: dropDownComponent
          },
          {
            name: 'awsAccount',
            label: 'Select AWS Account*',
            elementType: 'custom',
            getComponent: dropDownComponent
          },
          {
            name: 'instanceName',
            label: 'Instance Name*',
            type: 'text',
            elementType: 'input'
          },
          {
            name: 'instanceDescription',
            label: 'Description*',
            type: 'text',
            elementType: 'input',
            isResizable: false,
            multiline: true,
            maxRows: 1
          },
          {
            name: 'instanceRegion',
            label: 'Region*',
            elementType: 'custom',
            getComponent: dropDownComponent
          },
          {
            name: 'contactEmailId',
            label: 'Contact Email ID*',
            type: 'text',
            elementType: 'input'
          },

          {
            name: 'customDomain',
            label: 'Custom Domain',
            type: 'text',
            elementType: 'input'
          },
          {
            name: 'customEmailDomain',
            label: 'Custom Email Domain',
            elementType: 'custom',
            type: 'text',

            getComponent: ({
              field,
              form,
              name,
              values,
              errors,
              dirty,
              ...rest
            }) => {
              if (!values.customDomain) {
                field.value = ''
                return (
                  <InputField
                    field={field}
                    form={form}
                    {...rest}
                    disabled
                    name="customEmailDomainDisabled"
                  />
                )
              }
              return <InputField field={field} form={form} {...rest} />
            }
          },
          {
            name: 'instanceNetwork',
            label: 'Network*',
            elementType: 'custom',
            getComponent: dropDownComponent
          },
          {
            name: 'instanceVersion',
            label: 'Version*',
            elementType: 'custom',
            getComponent: dropDownComponent
          },
          {
            name: 'tokenAddress',
            label: 'Token Address*',
            type: 'text',
            elementType: 'input'
          },
          {
            name: 'tokenSymbol',
            label: 'Token Symbol*',
            type: 'text',
            elementType: 'input'
          },
          {
            name: 'instanceDecimal',
            label: 'Decimal*',
            type: 'text',
            elementType: 'input'
          }
        ]
      },
      {
        name: 'submit_button',
        type: 'button',
        label: 'Create Instance',
        leftButtons: [
          {
            name: 'Cancel',
            color: 'secondary',
            variant: 'outlined',
            disableRipple: true,
            onClick: onCancel
          },
          {
            name: 'Reset',
            'data-action': 'back',
            color: 'secondary',
            variant: 'text',
            disable: ({ dirty }) => !dirty
          }
        ],
        rightButtons: [
          {
            name: 'Create Instance',
            variant: 'contained',
            color: 'primary',
            type: 'submit',
            processingLoader: true,
            disable: ({ touched, isValid }) =>
              !(touched?.instanceName && isValid),
            loading
          }
        ]
      }
    ],
    [instanceCustomers, awsAccounts, instanceVersions, loading]
  )
  return { sectionConfig, handleSubmit, initialValues, validationSchema }
}

export default useSectionConfig
