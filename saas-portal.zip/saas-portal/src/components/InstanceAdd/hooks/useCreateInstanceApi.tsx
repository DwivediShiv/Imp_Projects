import { useCallback, useState } from 'react'
import axios from 'axios'
import appConfig from 'app.config'
import { ApiResponse, InstanceCustomers, InstanceError } from '../types'
import { ERROR_TYPES, UNEXPECTED_ERROR } from '../constants'

export const createInstanceUrl = `${appConfig.api}/saas-management/api/v1/saas/management/instance`
export const instanceCustomersUrl = `${appConfig.api}/saas-management/api/v1/saas/customer/list`
export const instanceVersionsUrl = `${appConfig.api}/saas-management/api/v1/saas/version/list`

export default function useCreateInstanceApi() {
  const [instanceError, setInstanceError] = useState<InstanceError | null>({
    type: '',
    error: null
  })
  const [instanceCustomers, setInstanceCustomers] = useState<
    InstanceCustomers[]
  >([])

  const [instanceVersions, setInstanceVersions] = useState<any>([])

  const createInstance = useCallback(async (payload: any, setLoading) => {
    try {
      await axios.post<ApiResponse<any>>(createInstanceUrl, payload)
      setInstanceError(null)
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setInstanceError({
          type: ERROR_TYPES.CREATE_INSTANCE,
          error
        })
      } else {
        setInstanceError({
          type: ERROR_TYPES.CREATE_INSTANCE,
          error: { message: UNEXPECTED_ERROR }
        })
      }
    } finally {
      setLoading(false)
    }
  }, [])
  const fetchInstanceCustomers = useCallback(async () => {
    try {
      const { data: response } = await axios.get<ApiResponse<any>>(
        instanceCustomersUrl
      )
      setInstanceCustomers(response.data)
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setInstanceError({
          type: ERROR_TYPES.FETCH_CUSTOMERS,
          error: error
        })
      } else {
        setInstanceError({
          type: ERROR_TYPES.FETCH_CUSTOMERS,
          error: { message: UNEXPECTED_ERROR }
        })
      }
    }
  }, [])
  const fetchInstanceVersions = useCallback(async () => {
    try {
      const { data: response } = await axios.get<ApiResponse<any>>(
        instanceVersionsUrl
      )
      setInstanceVersions(response.data)
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setInstanceError({
          type: ERROR_TYPES.FETCH_VERSIONS,
          error
        })
      } else {
        setInstanceError({
          type: ERROR_TYPES.FETCH_VERSIONS,
          error: { message: UNEXPECTED_ERROR }
        })
      }
    }
  }, [])

  return {
    createInstance,
    instanceError,
    instanceCustomers,
    fetchInstanceCustomers,
    fetchInstanceVersions,
    instanceVersions
  }
}
