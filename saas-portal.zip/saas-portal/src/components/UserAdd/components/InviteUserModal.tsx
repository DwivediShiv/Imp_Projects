import React, { ReactElement, useCallback, useState } from 'react'
import styles from './InviteUserModal.module.css'
import InviteUser from '..'
import Container from '@sharedComponents/Container'
import CustomButton from '@sharedComponents/Button'
import CustomModal from '@sharedComponents/Modal'
import { CUSTOM_TYPE } from '@constants/modalConstant'

function InviteUserModal({ refreshHandler }): ReactElement {
  const [isOpen, setIsOpen] = useState<boolean>(false)

  const onToggleModal = useCallback(() => {
    setIsOpen((prev) => !prev)
    if (!isOpen) {
      refreshHandler()
    }
  }, [])

  function openModal() {
    setIsOpen(true)
  }
  return (
    <div>
      <CustomButton color="primary" variant="contained" onClick={openModal}>
        Invite User
      </CustomButton>
      <section className={styles.grid}>
        <CustomModal
          type={CUSTOM_TYPE}
          className={`${styles.textarea} ${styles.fancyTextarea} ${styles.fancyModal} ${styles.checkbox} ${styles.checkboxRoot} ${styles.checkboxChecked} ${styles.checkboxLabel} ${styles.checkBoxArea} ${styles.checkboxContainer}`}
          isOpen={isOpen}
          onToggleModal={onToggleModal}
        >
          <div>
            <Container className={styles.headerContent}>
              <div className={styles.title}>Invite User</div>
            </Container>
            <InviteUser onToggleModal={onToggleModal} isOpen={false} />
          </div>
        </CustomModal>
      </section>
    </div>
  )
}

export default InviteUserModal
