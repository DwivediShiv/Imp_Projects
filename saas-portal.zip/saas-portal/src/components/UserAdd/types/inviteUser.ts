export interface ApiResponse<T> {
  data?: T
  status?: number
  statusText?: string
  error?: string | { message: string }
}
export interface InviteUserFormSchema {
  email: string
  remarks?: string
}

export interface FormattedValues {
  email: string
  roles: string[]
  remark: string
}
export interface FormValues {
  email: string
  viewer?: boolean
  admin?: boolean
  remarks?: string
}
