import React from 'react'
import { findByRole, fireEvent, render, screen } from '@testing-library/react'
import InviteUser from '..'
import user from '@testing-library/user-event'
import useInviteUserApi from '../hooks/useInviteUserApi'

// jest.mock('wagmi', () => ({
//   createClient: jest.fn().mockReturnValue({
//     config: {
//       autoConnect: false
//     },
//     providers: {}
//   }),
//   useAccount: jest.fn().mockReturnValue({
//     address: '0x'
//   }),
//   useConnect: jest.fn().mockReturnValue({
//     connect: jest.fn(),
//     connectors: []
//   })
// }))

// jest.mock('@utils/ocean', () => ({
//   getOceanConfig: () => jest.fn().mockReturnValue({}),
//   getDevelopmentConfig: () => jest.fn().mockReturnValue({})
// }))

// jest.mock('@context/Authorize')

// interface RenderOptions {
//   authorize: Partial<AuthorizeProviderValue>
// }

// function renderComponent(options: RenderOptions) {
//   const useAuthorizeMock = useAuthorize as jest.Mock<
//     Partial<AuthorizeProviderValue>
//   >
//   const { isLogin } = options.authorize

//   useAuthorizeMock.mockReturnValue({
//     isLogin
//   })

//   render(<OrgProfile />)
// }
// jest.mock('../hooks/useInviteUserApi', () => {
//   return {
//     inviteUser: jest.fn(),
//     inviteUserError: ''
//   }
// })

jest.mock('../hooks/useInviteUserApi', () =>
  jest.fn(() => {
    return {
      inviteUser: jest.fn(),
      inviteUserError: ''
    }
  })
)

function renderComponent() {
  render(
    <InviteUser
      onToggleModal={() => {
        console.log('toggle')
      }}
      isOpen={false}
    />
  )
}

describe('Org Admin profile ', () => {
  // beforeEach(() => {
  //   setupGetOrgDataHandler()
  // })
  it('components rendered and button is disabled ', async () => {
    renderComponent()

    expect(await screen.findByText('User Email ID*')).toBeInTheDocument()
    expect(await screen.findByText('Admin')).toBeInTheDocument()
    const inviteButton = await screen.findByRole('button', {
      name: /Send Invite/i
    })
    expect(inviteButton).toBeInTheDocument()
    expect(inviteButton).toBeDisabled()
  })
  it('email and checkbox fields required for button to be enabled ', async () => {
    renderComponent()

    const adminCheckbox = await screen.findByRole('checkbox', {
      name: /Admin/i
    })
    const emailText = await screen.findByRole('textbox', {
      name: /user email id\*/i
    })
    fireEvent.change(emailText, {
      target: { value: 'test@nagarro.com' }
    })
    fireEvent.click(adminCheckbox)
    const inviteButton = await screen.findByRole('button', {
      name: /Send Invite/i
    })
    expect(inviteButton).toBeInTheDocument()
    expect(inviteButton).toBeEnabled()
  })
  it('submitting form', async () => {
    renderComponent()

    const adminCheckbox = await screen.findByRole('checkbox', {
      name: /admin/i
    })
    const emailText = await screen.findByRole('textbox', {
      name: /user email id\*/i
    })
    user.type(emailText, 'test@nagarro.com')
    user.click(adminCheckbox)
    const inviteButton = await screen.findByRole('button', {
      name: /Send Invite/i
    })

    // user.click(inviteButton) // todo after this
    // const { inviteUser, inviteUserError } = useInviteUserApi()
    // expect(await inviteUser).toBeCalled()
    // console.log('url_log', screen.logTestingPlaygroundURL())
  })
})
