export const invitationData = {}
