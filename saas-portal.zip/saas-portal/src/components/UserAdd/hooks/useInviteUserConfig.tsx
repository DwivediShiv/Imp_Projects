import { VALID_INPUT_ROLES } from '@constants/roleConstants'

export const formConfig = {
  title: 'Send Invite',
  initialValues: {
    email: ''
  },
  form: {
    data: [
      {
        name: 'email',
        label: 'User Email ID*',
        placeholder: 'e.g. joedoe@email.com',
        help: 'Enter user email address.',
        type: 'email',
        required: true
      },
      {
        name: '',
        label: 'Select Role*',
        type: 'checkbox',
        required: true,
        options: VALID_INPUT_ROLES,
        optionType: 'group'
      },
      {
        name: 'remarks',
        placeholder: 'Remarks (Optional)',
        help: 'Remarks',
        type: 'textarea'
      }
    ]
  }
}
