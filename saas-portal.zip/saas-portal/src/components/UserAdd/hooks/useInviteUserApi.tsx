import React, { useCallback, useState } from 'react'
import { ApiResponse, FormattedValues } from '../types/inviteUser'
import appConfig from 'app.config'
import axios from 'axios'
import { ERROR_EMAIL_ALREADY_EXISTS } from '@constants/constants'

export const inviteUserUrl = `${appConfig.api}/saas-management/api/v1/saas/invite-user`

export function getInviteUserUrl(): string {
  return inviteUserUrl
}

export default function useInviteUserApi() {
  const [inviteUserError, setInviteUserError] = useState<string | null>('')

  const inviteUser = useCallback(
    async (
      values: FormattedValues,
      setFieldError: (field: string, errorMsg: string) => void
    ) => {
      try {
        setInviteUserError('')
        const { data: response } = await axios.post<
          ApiResponse<{ status?: string }>
        >(getInviteUserUrl(), values)
        setInviteUserError(null)
        return response.data
      } catch (error) {
        if (
          error.response &&
          error.response.data?.code === ERROR_EMAIL_ALREADY_EXISTS.CODE
        ) {
          setFieldError('email', ERROR_EMAIL_ALREADY_EXISTS.MESSAGE)
        } else if (axios.isAxiosError(error)) {
          setInviteUserError(error.message)
        } else {
          setInviteUserError('unexpected error')
        }
      }
    },
    []
  )
  return {
    inviteUser,
    inviteUserError
  }
}
