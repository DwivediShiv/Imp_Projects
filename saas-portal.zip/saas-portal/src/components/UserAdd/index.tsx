import * as Yup from 'yup'

import React, { ReactElement, useEffect, useState } from 'react'
import useInviteUserApi from './hooks/useInviteUserApi'
import {
  FormValues,
  FormattedValues,
  InviteUserFormSchema
} from './types/inviteUser'
import { formConfig } from './hooks/useInviteUserConfig'
import { ALLOWED_ROLES, ROLE_ADMIN } from '@constants/roleConstants'
import CommonForm from '@sharedComponents/Forms/CommonForm'
import Toast from '@sharedComponents/Toast'

export function formatValues(
  values: FormValues,
  checkedBoxes: string[]
): FormattedValues {
  const roles = []

  for (const selectedRole of checkedBoxes) {
    const selectedRoleKey = selectedRole.toUpperCase().replace(' ', '_')
    roles.push(ALLOWED_ROLES[selectedRoleKey])

    if (selectedRole.toLowerCase() === ROLE_ADMIN) {
      break
    }
  }

  return {
    email: values.email,
    roles,
    remark: values.remarks
  }
}

export const validationSchema: Yup.SchemaOf<InviteUserFormSchema> =
  Yup.object().shape({
    email: Yup.string()
      .email('Please enter a valid email address.')
      .required('Required Field.'),
    remarks: Yup.string()
  })
function InviteUser({
  onToggleModal
}: {
  onToggleModal: () => void
  isOpen: boolean
}): ReactElement {
  const [checkedBoxes, setCheckedBoxes] = useState<string[]>([])
  const { inviteUser, inviteUserError } = useInviteUserApi()

  useEffect(() => {
    if (inviteUserError) {
      Toast('error', 'Unable to save changes. Please try again later.')
      onToggleModal()
    } else if (inviteUserError === null) {
      Toast('success', 'Successful. New user invite has been sent.')
      onToggleModal()
    }
  }, [inviteUserError, onToggleModal])

  async function handleSubmit(
    values: FormValues,
    resetForm: () => void,
    setFieldError: (field: string, errorMsg: string) => void
  ): Promise<void> {
    const formattedValues = formatValues(values, checkedBoxes)
    await inviteUser(formattedValues, setFieldError)
  }
  function checkDisabled(dirty, errors) {
    return !dirty || !!errors.email || checkedBoxes.length == 0
  }

  function onChangeCheckbox(option) {
    setCheckedBoxes((prev) => {
      const index = prev.indexOf(option)
      if (index === -1) {
        return [...prev, option]
      } else {
        return prev.slice(0, index).concat(prev.slice(index + 1))
      }
    })
  }
  return (
    <CommonForm
      content={formConfig}
      validationSchema={validationSchema}
      handleSubmit={handleSubmit}
      checkDisabled={checkDisabled}
      onChangeCheckbox={onChangeCheckbox}
    />
  )
}

export default InviteUser
