module.exports = {
  rbac: {
    url: process.env.NEXT_PUBLIC_RBAC_URL,
    validateMechanism:
      process.env.NEXT_PUBLIC_RBAC_VALIDATE_MECHANISM || 'address',
    authService: process.env.NEXT_PUBLIC_RBAC_AUTH_SERBICE || 'keycloak'
  },

  // Default standard api domain
  api:
    process.env.NEXT_PUBLIC_API_URI ||
    'https://saas-portal.dev.acentrik.io',
  // Org enabled flow
  isOrgEnabled: process.env.NEXT_PUBLIC_IS_ORG_ENABLED || true,
  otpDuration: process.env.NEXT_PUBLIC_AUTH_OTP_DURATION || 60,

  site: {
    baseUrl:
      process.env.NEXT_PUBLIC_SITE_BASE_URL ||
      'https://market.nagarro.acentrik.io/',
    termsAndConditionsUrl:
      process.env.NEXT_PUBLIC_SITE_TERM_AND_CONDITION_URL ||
      'https://acentrik.io/terms-and-conditions',
    cookieSecure: process.env.NEXT_PUBLIC_COOKIE_SECURE || 'true',
    webPortalUrl:
      process.env.NEXT_PUBLIC_SITE_WEB_PORTAL_URL || 'https://acentrik.io'
  },

  // Config for https://github.com/donavon/use-dark-mode
  darkModeConfig: {
    classNameDark: 'dark',
    classNameLight: 'light',
    storageKey: 'oceanDarkMode'
  },

  credentialType: process.env.NEXT_PUBLIC_CREDENTIAL_TYPE || 'address',

  // Set the default privacy policy to initially display
  // this should be the slug of your default policy markdown file
  defaultPrivacyPolicySlug: '/privacy/en',

  // This enables / disables the use of a GDPR compliant
  // privacy preference center to manage cookies on the market
  // If set to true a gdpr.json file inside the content directory
  // is used to create and show a privacy preference center / cookie banner
  // To learn more about how to configure and use this, please refer to the readme
  privacyPreferenceCenter:
    process.env.NEXT_PUBLIC_PRIVACY_PREFERENCE_CENTER || 'false',

  supportEmail:
    process.env.NEXT_PUBLIC_SUPPORT_EMAIL ||
    'support-acentrik@mercedes-benz.com',

  requestTimeout: ~~process.env.NEXT_PUBLIC_REQUEST_TIMEOUT || 25000,
  customization: {
    theme: process.env.NEXT_PUBLIC_CUSTOMIZATION_THEME || 'light',
    dateFormat: 'DD MMM yyyy'
  }
}
