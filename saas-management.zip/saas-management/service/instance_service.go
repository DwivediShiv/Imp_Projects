package service

import (
	"encoding/json"
	"fmt"
	"log"
	"saas-management/common"
	"saas-management/config"
	"saas-management/helper"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	"saas-management/repository"
	"saas-management/utils"
	"strings"

	"github.com/aws/aws-sdk-go-v2/service/codebuild/types"
	"github.com/gin-gonic/gin"
)

const (
	statusInactivation = "Inactivation"
	statusActivation   = "Activation"
	statusVersion      = "Version deployment"
	statusNetwork      = "Network deployment"
)

type instanceService struct {
	instanceRepository repository.InstanceRepository
	config             config.Configuration
}

type InstanceService interface {
	SaveInstance(ctx *gin.Context, apiReq *request.InstanceDetail, adminEmail string) (*response.CreateInstanceResponse, *models.ErrorResponse)
	GetInstanceByID(ctx *gin.Context, instanceID string) (*response.GetInstanceResponse, *models.ErrorResponse)
	GetInstanceList(ctx *gin.Context, cl *request.InstanceList) (*response.InstanceListResponse, *models.ErrorResponse)
	ExportInstanceList(ctx *gin.Context, cl *request.InstanceList) *models.ErrorResponse
	GetVersionList() (*response.VersionListResponse, *models.ErrorResponse)
	CheckProvisionedInstancesStatus()
	CheckPendingVerificationsInstancesStatus()
	CheckFinalizingInstancesStatus()
	DeleteInstance(ctx *gin.Context, instanceID string) *models.ErrorResponse
	ActivateInactivateInstance(ctx *gin.Context, instanceID, status string) *models.ErrorResponse
	DeployInstanceVersion(ctx *gin.Context, instanceID, version string) *models.ErrorResponse
	DeployInstanceNetwork(ctx *gin.Context, network *request.InstanceNetwork, instanceID string) *models.ErrorResponse
	CheckDeletionInProgressInstancesStatus()
	GetReleaseNote(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse)
	CheckActivationInProgressInstancesStatus()
	CheckInactivationInProgressInstancesStatus()
	CheckVersionDeploymentInProgressInstancesStatus()
	CheckNetworkDeploymentInProgressInstancesStatus()
	CheckEmailEligibleInstancesStatus()
}

func NewInstanceService(irepo repository.InstanceRepository, config config.Configuration) InstanceService {
	return &instanceService{
		instanceRepository: irepo,
		config:             config,
	}
}

func (is *instanceService) GetReleaseNote(version string) (*response.ReleaseNoteResponse, *models.ErrorResponse) {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "version is invalid"
		return nil, &err1
	}

	// get release note from s3
	releaseNote, err := helper.GetReleaseNotesFromS3(&is.config, version)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	return &response.ReleaseNoteResponse{Data: releaseNote}, nil
}

func (is *instanceService) GetVersionList() (*response.VersionListResponse, *models.ErrorResponse) {
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	var list []response.VersionDetail
	for _, v := range versions {
		versionDetails := response.VersionDetail{
			Version:     v.Version,
			Description: v.Description,
		}
		list = append(list, versionDetails)
	}
	return &response.VersionListResponse{Data: list}, nil
}

func (is *instanceService) SaveInstance(ctx *gin.Context, apiReq *request.InstanceDetail, adminEmail string) (*response.CreateInstanceResponse, *models.ErrorResponse) {

	// Validate if cluster exists for region, awsaccount and network
	if isClusterExist, _ := is.instanceRepository.IsClusterExistForInstance(apiReq.Region, apiReq.AWSAccount, apiReq.Network); !isClusterExist {
		errMsg := fmt.Sprintf("Either cluster doesn't exist in '%s' region and '%s' aws account on '%s' network or cluster deployment is in progress.", apiReq.Region, apiReq.AWSAccount, apiReq.Network)
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = errMsg
		return nil, &err1
	}

	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}
	if !versionInVersionArray(apiReq.Version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "Version is invalid"
		return nil, &err1
	}

	// validate customer name
	if isCustomerNameExist, _ := is.instanceRepository.IsCustomerNameExist(apiReq.CustomerName); !isCustomerNameExist {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "Customer name is not present"
		return nil, &err1
	}

	// validate instance name
	if isNameExist, _ := is.instanceRepository.IsInstanceNameExist(apiReq.Name); isNameExist {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "Instance name already exists"
		return nil, &err1
	}

	// validate custom domain
	if apiReq.CustomDomain != "" {
		if isCustomDomianExist, _ := is.instanceRepository.IsUniqueCustomDomain(apiReq.CustomDomain); isCustomDomianExist {
			err1 := common.ErrorInvalidRequestInput
			err1.Error.AdditionalData = "Custom domain already exists"
			return nil, &err1
		}
	}

	if err := utils.NewtworkAWSAccountRegionValidation(ctx, &is.config, apiReq.Network, apiReq.AWSAccount, apiReq.Region); err != nil {
		return nil, err
	}

	sesExist := "False"
	isSESRequested := false
	if apiReq.CustomDomain != "" {
		if exists, _ := is.instanceRepository.IsSESDomainExist(apiReq.CustomEmailDomain); exists {
			sesExist = "True"
			isSESRequested = false
		} else {
			isSESRequested = true
		}
	}

	// call lambda to create instance
	createInstanceArgs := &models.CreateInstanceArgs{
		Version:            apiReq.Version,
		AccountType:        apiReq.AWSAccount,
		Region:             apiReq.Region,
		InstanceName:       apiReq.Name,
		InstanceAdminEmail: apiReq.ContactEmail,
		Network:            apiReq.Network,
		TokenAddress:       apiReq.TokenAddress,
		TokenSymbol:        apiReq.TokenSymbol,
		Decimals:           apiReq.Decimal,
		CustomDomain:       apiReq.CustomDomain,
		SESDomain:          apiReq.CustomEmailDomain,
		SESDomainExist:     sesExist,
	}
	buidlID, err := helper.RunCreateInstanceCodeBuildPipeline(&is.config, createInstanceArgs)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	apiReq.BuildID = *buidlID
	id, err := is.instanceRepository.CreateInstance(apiReq, adminEmail, isSESRequested)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	log.Printf("\nInstance '%s' created with id '%s' having buildID '%s'\n", apiReq.Name, id, apiReq.BuildID)
	return &response.CreateInstanceResponse{Message: fmt.Sprintf("instance '%s' created with id '%s'", apiReq.Name, id)}, nil
}

func (is *instanceService) GetInstanceByID(ctx *gin.Context, instanceID string) (*response.GetInstanceResponse, *models.ErrorResponse) {
	instance, err := is.instanceRepository.GetInstanceDetail(instanceID)
	if err != nil {
		err1 := common.ErrorInstanceNotFound
		return nil, &err1
	}
	resp := &response.GetInstanceResponse{
		ID:                instance.UUID.String(),
		Name:              instance.Name,
		CreatedAt:         instance.CreatedAt,
		CreatedBy:         instance.CreatedBy,
		Description:       instance.Description,
		CustomerName:      instance.CustomerName,
		AWSAccount:        instance.AwsAccount,
		Region:            instance.Region,
		ContactEmail:      instance.ContactEmail,
		CustomDomain:      instance.CustomDomain,
		CustomEmailDomain: instance.CustomEmailDomain,
		Version:           instance.Version,
		Status:            instance.Status,
	}

	var networkList []response.Network
	for _, n := range instance.NetworkRecords {
		network := response.Network{
			Network:      n.Network,
			Decimal:      n.Decimal,
			TokenSymbol:  n.TokenSymbol,
			TokenAddress: n.TokenAddress,
		}
		networkList = append(networkList, network)
	}
	resp.Networks = networkList

	return resp, nil
}

func (is *instanceService) GetInstanceList(ctx *gin.Context, cl *request.InstanceList) (*response.InstanceListResponse, *models.ErrorResponse) {
	// Update pagination number of records to 10
	if cl.NumberRecords == 0 {
		cl.NumberRecords = 10
	}

	if cl.Get == "All" {
		cl.NumberRecords = 1000000
	}

	if cl.StatusTab != "" {
		_, exists := repository.SimilarStatuseMap[cl.StatusTab]
		if !exists {
			err1 := common.ErrorInvalidRequestInput
			err1.Error.AdditionalData = fmt.Sprintf("'%s' is invalid statusTab", cl.StatusTab)
			return nil, &err1
		}
	}

	// Get instance list
	list, totalResult, listErr := is.instanceRepository.GetInstanceList(cl)
	if listErr != nil || totalResult == -1 {
		log.Printf("Error while fetching instanceList from db")
		return nil, &common.ErrorDBFailed
	}

	instanceList := []response.GetInstanceResponse{}
	for _, instance := range list {
		resp := response.GetInstanceResponse{
			ID:                instance.UUID.String(),
			Name:              instance.Name,
			CreatedAt:         instance.CreatedAt,
			CreatedBy:         instance.CreatedBy,
			Description:       instance.Description,
			CustomerName:      instance.CustomerName,
			AWSAccount:        instance.AwsAccount,
			Region:            instance.Region,
			ContactEmail:      instance.ContactEmail,
			CustomDomain:      instance.CustomDomain,
			CustomEmailDomain: instance.CustomEmailDomain,
			Version:           instance.Version,
			Status:            instance.Status,
		}

		var networkList []response.Network
		for _, n := range instance.NetworkRecords {
			network := response.Network{
				Network:      n.Network,
				Decimal:      n.Decimal,
				TokenSymbol:  n.TokenSymbol,
				TokenAddress: n.TokenAddress,
			}
			networkList = append(networkList, network)
		}
		resp.Networks = networkList
		instanceList = append(instanceList, resp)
	}

	customers, err := is.instanceRepository.GetUniqueInstanceCustomerNames()
	if err != nil {
		log.Printf("Error while fetching customers from db")
		return nil, &common.ErrorDBFailed

	}
	regions, err := is.instanceRepository.GetUniqueRegions()
	if err != nil {
		log.Printf("Error while fetching regions from db")
		return nil, &common.ErrorDBFailed

	}

	resp := &response.InstanceListResponse{Data: instanceList,
		TotalRecord: totalResult,
		FilterCriterias: response.InstanceFilterCriterias{
			CustomerNames: customers,
			Regions:       regions,
		},
	}

	return resp, nil
}

func (is *instanceService) ExportInstanceList(ctx *gin.Context, cl *request.InstanceList) *models.ErrorResponse {
	// Update pagination number of records to 10
	if cl.NumberRecords == 0 {
		cl.NumberRecords = 10
	}

	if cl.Get == "All" {
		cl.NumberRecords = 1000000
	}

	if cl.StatusTab != "" {
		_, exists := repository.SimilarStatuseMap[cl.StatusTab]
		if !exists {
			err1 := common.ErrorInvalidRequestInput
			err1.Error.AdditionalData = fmt.Sprintf("'%s' is invalid statusTab", cl.StatusTab)
			return &err1
		}
	}

	// Get customer list
	list, totalResult, listErr := is.instanceRepository.GetInstanceList(cl)
	if listErr != nil || totalResult == -1 {
		log.Printf("Error while fetching instanceList from db")
		return &common.ErrorDBFailed
	}

	// Excel Fucntionality
	headers := utils.GenerateInvitedUserRowHeader(common.InstanceListRowHeaders)

	// Generate csv data
	var csvInstanceData strings.Builder
	csvInstanceData.WriteString(headers)

	var lastIndex = len(list) - 1
	for index, instance := range list {
		// Excel Body
		rowBody := generateInstanceRowBody(instance)
		csvInstanceData.WriteString(rowBody)
		if index != lastIndex {
			csvInstanceData.WriteString("\n")
		}
	}

	// Write the sql result to csv file
	fileName := "customer.csv"
	ctx.Header("Content-Type", "application/octet-stream")
	ctx.Header("Content-Disposition", "attachment; filename="+fileName)
	ctx.Header("Content-Disposition", "inline;filename="+fileName)
	ctx.Header("Content-Transfer-Encoding", "binary")
	ctx.Header("Cache-Control", "no-cache")
	ctx.Writer.WriteString(csvInstanceData.String())

	return nil
}

func (is *instanceService) inactivateInstance(ctx *gin.Context, instance *models.Instances, instanceID, status string) *models.ErrorResponse {
	if status == repository.InstanceStatusActive {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "Cannot update to same status!"
		return &err1
	}

	req := &models.InactivateInstanceArgs{
		Version:      instance.Version,
		AccountType:  instance.AwsAccount,
		Region:       instance.Region,
		InstanceName: instance.Name,
	}
	buildID, err := helper.RunInactivateInstanceCodeBuildPipeline(&is.config, req)
	if err != nil {
		log.Printf("Error while deactivating instance '%s' with error: '%v'\n", instance.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = "Deactivating failed! please contact admin."
		return &err1
	}

	// update details in repo
	remarks := fmt.Sprintf("%s\ninactivate build '%s' is triggered", instance.BuildRemarks, *buildID)
	if err = is.instanceRepository.UpdateInstanceInactivateID(instanceID, *buildID, remarks); err != nil {
		log.Printf("Error while updating inactivate build id '%s' for instance '%s' with remarks geting error: '%v'\n", *buildID, instance.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}
	log.Printf("Inactivating build id for instance '%s' with build id: '%v'\n", instance.Name, *buildID)

	return nil
}

func (is *instanceService) activateInstance(ctx *gin.Context, instance *models.Instances, instanceID, status string) *models.ErrorResponse {
	if status == repository.InstanceStatusInactive {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "Cannot update to same status!"
		return &err1
	}

	input := &models.RetryCreateInstanceReq{
		BuildID:     instance.BuildID,
		Region:      instance.Region,
		AccountType: instance.AwsAccount,
	}
	build, err := helper.RerunCreateInstanceCodeBuildPipeline(&is.config, input)
	if err != nil {
		log.Printf("Error while activating instance by reruning '%s' with error: '%v'\n", instance.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = "Activating failed! please contact admin."
		return &err1
	}

	// update the build id
	remarks := fmt.Sprintf("%s\nPrevious build id was '%s' new build started for activating the instance", instance.BuildRemarks, instance.BuildID)
	req := &models.UpdateInstanceRequest{BuildID: *build.Id, Remarks: remarks, Status: repository.InstanceStatusActivationInProgress}
	err = is.instanceRepository.UpdateInstanceBuildAndStatus(instanceID, req)
	if err != nil {
		log.Printf("Error while updating activating build id for instance '%s' with remarks geting error: '%v'\n", instance.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	log.Printf("Activating build id for instance '%s' with build id: '%v'\n", instance.Name, *build.Id)

	return nil
}

func (is *instanceService) ActivateInactivateInstance(ctx *gin.Context, instanceID, status string) *models.ErrorResponse {
	instance, err := is.instanceRepository.GetInstanceDetail(instanceID)
	if err != nil {
		err1 := common.ErrorInstanceNotFound
		return &err1
	}

	switch instance.Status {
	case repository.InstanceStatusInactive:
		return is.activateInstance(ctx, instance, instanceID, status)

	case repository.InstanceStatusActive:
		return is.inactivateInstance(ctx, instance, instanceID, status)
	}

	err1 := &common.ErrorActionNotAllowedFailed
	err1.Error.AdditionalData = "Status toggle is only available when status is 'Active' or 'Inactive'"
	return err1
}

func (is *instanceService) DeployInstanceVersion(ctx *gin.Context, instanceID, version string) *models.ErrorResponse {
	instance, err := is.instanceRepository.GetInstanceDetail(instanceID)
	if err != nil {
		err1 := common.ErrorInstanceNotFound
		return &err1
	}

	// validate version
	versions, err := helper.GetVersionInfoFromS3(&is.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "Version is invalid"
		return &err1
	}

	if instance.Status != repository.InstanceStatusActive {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "action is allowed when status is 'Active'!"
		return &err1
	}

	sesExist := "False"
	if instance.CustomDomain != "" {
		if exists, _ := is.instanceRepository.IsSESDomainExist(instance.CustomEmailDomain); exists {
			sesExist = "True"
		}
	}

	// call lambda to create instance
	nl := len(instance.NetworkRecords)
	network := instance.NetworkRecords[nl-1]
	createInstanceArgs := &models.CreateInstanceArgs{
		Version:            version,
		AccountType:        instance.AwsAccount,
		Region:             instance.Region,
		InstanceName:       instance.Name,
		InstanceAdminEmail: instance.ContactEmail,
		Network:            network.Network,
		TokenAddress:       network.TokenAddress,
		TokenSymbol:        network.TokenSymbol,
		Decimals:           network.Decimal,
		CustomDomain:       instance.CustomDomain,
		SESDomain:          instance.CustomEmailDomain,
		SESDomainExist:     sesExist,
	}

	buildID, err := helper.RunCreateInstanceCodeBuildPipeline(&is.config, createInstanceArgs)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	remarks := fmt.Sprintf("%s\nPrevious build id '%s' & version '%s'. New build started for deploying version '%s' of instance", instance.BuildRemarks, instance.BuildID, instance.Version, version)
	req := &models.UpdateInstanceRequest{BuildID: *buildID, Remarks: remarks, Status: repository.InstanceStatusVersionDeploymentInProgress, Version: version}
	err = is.instanceRepository.UpdateInstanceBuildAndStatus(instanceID, req)
	if err != nil {
		log.Printf("Error while updating deploy version build id for instance '%s' with remarks geting error: '%v'\n", instance.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	log.Printf("\nInstance '%s' having current version '%s' deployment started with build id '%s' for provided version '%s' \n", instance.Name, instance.Version, *buildID, version)
	return nil
}

func (is *instanceService) DeployInstanceNetwork(ctx *gin.Context, network *request.InstanceNetwork, instanceID string) *models.ErrorResponse {
	instance, err := is.instanceRepository.GetInstanceDetail(instanceID)
	if err != nil {
		err1 := common.ErrorInstanceNotFound
		return &err1
	}

	if err := utils.NewtworkSymbolValidation(ctx, &is.config, network.Network); err != nil {
		return err
	}

	if instance.Status != repository.InstanceStatusActive {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "action is allowed when status is 'Active'!"
		return &err1
	}

	// Validate if cluster exists for requested network
	if isClusterExist, _ := is.instanceRepository.IsClusterExistForInstance(instance.Region, instance.AwsAccount, network.Network); !isClusterExist {
		errMsg := fmt.Sprintf("Either cluster doesn't exist in '%s' region and '%s' aws account on '%s' network or cluster deployment is in progress.", instance.Region, instance.AwsAccount, network.Network)
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = errMsg
		return &err1
	}

	sesExist := "False"
	if instance.CustomDomain != "" {
		if exists, _ := is.instanceRepository.IsSESDomainExist(instance.CustomEmailDomain); exists {
			sesExist = "True"
		}
	}

	if _, err = is.instanceRepository.AddNetwork(network, instance.ID); err != nil {
		log.Printf("\nAdding network %s failed: %v \n", network.Network, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = "Network could not be added! please contact admin."
		return &err1
	}

	// call lambda to create instance
	createInstanceArgs := &models.CreateInstanceArgs{
		Version:            instance.Version,
		AccountType:        instance.AwsAccount,
		Region:             instance.Region,
		InstanceName:       instance.Name,
		InstanceAdminEmail: instance.ContactEmail,
		Network:            network.Network,
		TokenAddress:       network.TokenAddress,
		TokenSymbol:        network.TokenSymbol,
		Decimals:           network.Decimal,
		CustomDomain:       instance.CustomDomain,
		SESDomain:          instance.CustomEmailDomain,
		SESDomainExist:     sesExist,
	}

	buildID, err := helper.RunCreateInstanceCodeBuildPipeline(&is.config, createInstanceArgs)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	nl := len(instance.NetworkRecords)
	n := instance.NetworkRecords[nl-1]
	remarks := fmt.Sprintf("%s\nPrevious build id '%s' & network '%s'. New build started for deploying network '%s' of instance", instance.BuildRemarks, instance.BuildID, n.Network, network.Network)
	req := &models.UpdateInstanceRequest{BuildID: *buildID, Remarks: remarks, Status: repository.InstanceStatusNetworkDeploymentInProgress}
	err = is.instanceRepository.UpdateInstanceBuildAndStatus(instanceID, req)
	if err != nil {
		log.Printf("Error while updating deploy network build id for instance '%s' with remarks geting error: '%v'\n", instance.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	log.Printf("\nInstance '%s' having current network '%s' deployment started with build id '%s' for provided network '%s' \n", instance.Name, n.Network, *buildID, network.Network)
	return nil
}

func (is *instanceService) DeleteInstance(ctx *gin.Context, instanceID string) *models.ErrorResponse {
	instance, err := is.instanceRepository.GetInstanceDetail(instanceID)
	if err != nil {
		err1 := common.ErrorInstanceNotFound
		return &err1
	}

	isDeleteAllowed := false
	for _, buildStatus := range repository.SimilarStatuseMap[repository.InstanceStatusFailed] {
		if instance.Status == buildStatus {
			isDeleteAllowed = true
			break
		}
	}
	if instance.Status == repository.InstanceStatusInactive {
		isDeleteAllowed = true
	}

	if !isDeleteAllowed {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "Delete instance is only allowed when status is inactive or failed!"
		return &err1
	}

	// delete instance from aws by calling code build pipeline
	sesExist := false
	if instance.CustomDomain != "" {
		if exists, _ := is.instanceRepository.IsSESDomainExistMoreThanOnce(instance.CustomEmailDomain); exists {
			sesExist = true
		}
	}

	// call lambda to delete instance
	deleteInstanceArgs := &models.DeleteInstanceArgs{
		Version:        instance.Version,
		AccountType:    instance.AwsAccount,
		Region:         instance.Region,
		InstanceName:   instance.Name,
		SESDomain:      instance.CustomEmailDomain,
		SESDomainExist: sesExist,
	}
	buildID, err := helper.RunDeleteInstanceCodeBuildPipeline(&is.config, deleteInstanceArgs)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	// update delete details in repo
	remarks := fmt.Sprintf("%s\nbuild '%s' is triggered for deleting the instance.", instance.BuildRemarks, *buildID)
	if err = is.instanceRepository.UpdateInstanceDeleteID(instanceID, *buildID, remarks); err != nil {
		log.Printf("Error while updating delete build id '%s' for instance '%s' with remarks geting error: '%v'\n", *buildID, instance.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	return nil
}

// Generate instance list export body
func generateInstanceRowBody(entity models.Instances) string {
	var row strings.Builder
	row.WriteString(`"` + entity.Name + `"` + ",")
	row.WriteString(`"` + entity.CustomerName + `"` + ",")
	row.WriteString(entity.Region + ",")
	row.WriteString(entity.Version + ",")
	row.WriteString(entity.CreatedAt.Format("02 Jan 2006") + ",")
	row.WriteString(entity.CreatedBy + ",")
	row.WriteString(entity.Status)
	return row.String()
}

func versionInVersionArray(str string, arr models.VersionInfo) bool {
	for _, v := range arr {
		if v.Version == str {
			return true
		}
	}
	return false
}

func (is *instanceService) CheckProvisionedInstancesStatus() {
	fmt.Println("checking the created instances statuses for further processing!")
	list, totalResult, listErr := is.instanceRepository.GetProvisionedInstanceList()
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while fetching provisioned instanceList from db\ncount: %d\terror if any: '%v'\n", totalResult, listErr)
		return
	}

	// check build status
	for _, instance := range list {
		log.Printf("\nCurrent provisioned in progress instance: %+v\n", instance)
		buildStatus := &models.GetBuildStatus{
			BuildID:     instance.BuildID,
			AccountType: instance.AwsAccount,
			Region:      instance.Region,
		}
		build, err := helper.GetInstanceBuildStatus(&is.config, buildStatus)
		if err != nil {
			log.Printf("Error while fetching provisioned instance '%s' '%s' from aws '%v'\n", instance.Name, instance.BuildID, err)
			continue
		}

		switch buildStatus := build.BuildStatus; buildStatus {
		case types.StatusTypeInProgress:
			log.Printf("Build '%s' is still in progress hence moving to next provisioned instance '%s' from aws '%v'\n", instance.Name, instance.BuildID, err)
			continue
		case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
			if err := is.instanceRepository.UpdateInstanceStatus(instance.UUID.String(), repository.InstanceStatusFailed, string(buildStatus)); err != nil {
				log.Printf("Build '%s' is Failed but error in updating success status '%s' from aws '%v'\n", instance.Name, instance.BuildID, err)
			}
			continue
		case types.StatusTypeSucceeded:
			is.instanceSucceedFlow(instance, string(buildStatus))
			continue
		default:
			log.Printf("Build status for '%s' with id '%s' is unknown '%s'. Please check!\n", instance.Name, instance.BuildID, buildStatus)
		}
	}
}

func (is *instanceService) instanceSucceedFlow(instance models.Instances, buildStatus string) {
	// check if custom domain then 'pending verification' status else 'active'
	if instance.CustomDomain == "" {
		if err := is.instanceRepository.UpdateInstanceStatusWithEmailPending(instance.UUID.String(), repository.InstanceStatusActive, buildStatus, true); err != nil {
			log.Printf("Build '%s' is Succeeded but error in updating success status '%s' from aws '%v'\n", instance.Name, instance.BuildID, err)
		}
		return
	}

	req := &models.GetSSMParamReq{
		AccountType:  instance.AwsAccount,
		Region:       instance.Region,
		InstanceName: instance.Name,
	}
	if instance.CustomDomain != "" && instance.IsSesRequested {
		req.IsSESRequested = true
	}

	entries, err := helper.GetCustomDomainEntriesFromSSM(&is.config, req)
	if err != nil {
		log.Printf("Build '%s' is Succeeded but error in getting custom domain entries '%s' from aws '%v'", instance.Name, instance.BuildID, err)
		return
	}

	modifiedEntries := stringEntriesIntoAWSEntries(entries)
	err = sendDomainEntriesEmail(is.config, instance.ContactEmail, instance.Name, modifiedEntries)
	if err != nil {
		log.Printf("Build '%s' is Succeeded but error in sending email for adding domain entries '%s' from aws '%v'", instance.Name, instance.BuildID, err)
		return
	}

	if err := is.instanceRepository.UpdateInstanceStatus(instance.UUID.String(), repository.InstanceStatusPendingDomainVerification, buildStatus); err != nil {
		log.Printf("Build '%s' is Succeeded but error in updating pending verification status '%s' from aws '%v'", instance.Name, instance.BuildID, err)
	}
	log.Printf("Build '%s' is Succeeded hence moving to next provisioned instance '%s' from aws", instance.Name, instance.BuildID)
}

func (is *instanceService) CheckPendingVerificationsInstancesStatus() {
	fmt.Println("checking the pending instances statuses for further processing!")
	list, totalResult, listErr := is.instanceRepository.GetPendingDomainVerificationInstances()
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while fetching provisioned instanceList from db\ncount: %d\terror if any: '%v'\n", totalResult, listErr)
		return
	}

	for _, instance := range list {
		log.Printf("\nCurrent pending instances %+v\n", instance)
		// call SES API for verification
		cevReq := &models.SESIdentityVerificationReq{CustomEmailDomain: instance.CustomEmailDomain, Region: instance.Region, AccountType: instance.AwsAccount}
		isVerified, err := helper.IsCustomEmailDomainVerified(&is.config, cevReq)
		if !isVerified || err != nil {
			log.Printf("\nCheckPendingVerificationsInstancesStatus CustomeEmailVerification failed for '%s' '%v'\n", instance.Name, err)
			continue
		}

		// call ACM API for verification
		cvReq := &models.CertificateVerificationReq{CustomDomain: instance.CustomDomain, Region: instance.Region, AccountType: instance.AwsAccount}
		isVerified, err = helper.IsCustomDomainCertificateIssued(&is.config, cvReq)
		if !isVerified || err != nil {
			log.Printf("\nCheckPendingVerificationsInstancesStatus CustomeDomainVerification failed for '%s' '%v'\n", instance.Name, err)
			continue
		}

		if err := is.instanceRepository.UpdateInstanceStatus(instance.UUID.String(), repository.InstanceStatusFinalizingInstance, ""); err != nil {
			log.Printf("Instance '%s' Verification is done but error in updating finalizing instance status '%s' from aws '%v'", instance.Name, instance.Status, err)
		}
		log.Printf("Verification is done Build '%s' name '%s' is Succeeded", instance.BuildID, instance.Name)
	}
}

func (is *instanceService) CheckFinalizingInstancesStatus() {
	fmt.Println("checking the finalizing instances statuses for further processing!")
	list, totalResult, listErr := is.instanceRepository.GetFinalizingInstances()
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while finalizing provisioned instanceList from db\ncount: %d\terror if any: '%v'\n", totalResult, listErr)
		return
	}

	for _, instance := range list {
		log.Printf("\nCurrent finalizing instances %+v\n", instance)
		if instance.RetryFlag == 0 {
			input := &models.RetryCreateInstanceReq{
				BuildID:     instance.BuildID,
				Region:      instance.Region,
				AccountType: instance.AwsAccount,
			}
			build, err := helper.RerunCreateInstanceCodeBuildPipeline(&is.config, input)
			if err != nil {
				log.Printf("Error while retrying creating instance '%s' with error: '%v'\n", instance.Name, err)
				continue
			}
			//update the retry status in db so that we check the build status next time
			remarks := fmt.Sprintf("%s\nFirst build id is %s and retried for final success", instance.BuildRemarks, instance.BuildID)
			err = is.instanceRepository.UpdateInstanceRetrialStatus(instance.UUID.String(), *build.Id, remarks)
			if err != nil {
				log.Printf("Error while updating retry flag for instance '%s' with remarks geting error: '%v'\n", instance.Name, err)
				continue
			}
		}
		// checking the retried build status
		buildStatus := &models.GetBuildStatus{
			BuildID:     instance.BuildID,
			AccountType: instance.AwsAccount,
			Region:      instance.Region,
		}
		build, err := helper.GetInstanceBuildStatus(&is.config, buildStatus)
		if err != nil {
			log.Printf("Error while fetching finalizing retried instance '%s' '%s' from aws '%v'\n", instance.Name, instance.BuildID, err)
			continue
		}

		switch buildStatus := build.BuildStatus; buildStatus {
		case types.StatusTypeInProgress:
			log.Printf("'%s' Retried Build '%s' is still in progress hence waiting for some time!\n", instance.Name, instance.BuildID)
			continue
		case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
			remarks := fmt.Sprintf("%s\nretrial build failed with status '%s'", instance.BuildRemarks, buildStatus)
			if err := is.instanceRepository.UpdateInstanceStatus(instance.UUID.String(), repository.InstanceStatusFailed, remarks); err != nil {
				log.Printf("Retried Build '%s' is Failed but error in updating success status '%s' from aws '%v'\n", instance.Name, instance.BuildID, err)
			}
			continue
		case types.StatusTypeSucceeded:
			log.Printf("Retrial Build '%s' name '%s' is Succeeded", instance.BuildID, instance.Name)
			remarks := fmt.Sprintf("%s\nretrial build passed with status '%s'", instance.BuildRemarks, buildStatus)
			if err := is.instanceRepository.UpdateInstanceStatusWithEmailPending(instance.UUID.String(), repository.InstanceStatusActive, remarks, true); err != nil {
				log.Printf("Retried Build '%s' is Succeeded but error in updating success status '%s' from aws '%v'\n", instance.Name, instance.BuildID, err)
			}

			continue
		default:
			log.Printf("Build status for '%s' with id '%s' is unknown '%s'. Please check!\n", instance.Name, instance.BuildID, buildStatus)
		}
	}
}

func (is *instanceService) CheckDeletionInProgressInstancesStatus() {
	fmt.Println("checking the deletion in progress instances statuses for further processing!")
	list, totalResult, listErr := is.instanceRepository.GetDeletionInProgressInstances()
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while deletion in progress instanceList from db\ncount: %d\terror if any: '%v'\n", totalResult, listErr)
		return
	}

	for _, instance := range list {
		log.Printf("\nCurrent deletion in progress instances %+v\n", instance)
		if instance.DeleteStatus == repository.InstanceStatusDeletionFailed {
			continue
		}
		// checking the deleted build status
		buildStatus := &models.GetBuildStatus{
			BuildID:     instance.DeleteBuildID,
			AccountType: instance.AwsAccount,
			Region:      instance.Region,
		}
		build, err := helper.GetInstanceBuildStatus(&is.config, buildStatus)
		if err != nil {
			log.Printf("Error while fetching deletion in progress instance '%s' '%s' from aws '%v'\n", instance.Name, instance.DeleteBuildID, err)
			continue
		}

		switch buildStatus := build.BuildStatus; buildStatus {
		case types.StatusTypeInProgress:
			log.Printf("'%s' Deletion Build '%s' is still in progress hence waiting for some time!\n", instance.Name, instance.DeleteBuildID)
			continue
		case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
			remarks := fmt.Sprintf("%s\ndeletion build failed with status '%s'", instance.BuildRemarks, buildStatus)
			if err := is.instanceRepository.UpdateInstanceDeleteStatus(instance.UUID.String(), repository.InstanceStatusDeletionFailed, string(buildStatus), remarks); err != nil {
				log.Printf("Deletion Build '%s' is Failed but error in updating success status '%s' from aws '%v'\n", instance.Name, instance.DeleteBuildID, err)
			}
			continue
		case types.StatusTypeSucceeded:
			log.Printf("Deletion Build '%s' name '%s' is Succeeded", instance.DeleteBuildID, instance.Name)
			if err := is.instanceRepository.DeleteInstanceByID(instance.UUID.String()); err != nil {
				log.Printf("Deletion Build '%s' is Succeeded but error in updating success status '%s' from aws '%v'\n", instance.Name, instance.DeleteBuildID, err)
			}
			continue
		default:
			log.Printf("Build status for '%s' with id '%s' is unknown '%s'. Please check!\n", instance.Name, instance.DeleteBuildID, buildStatus)
		}
	}
}

func (is *instanceService) CheckInactivationInProgressInstancesStatus() {
	is.checkDeploymentStatuses(repository.InstanceStatusInactivationInProgress, statusInactivation, repository.InstanceStatusInactivationFailed, repository.InstanceStatusInactive)
}

func (is *instanceService) CheckActivationInProgressInstancesStatus() {
	is.checkDeploymentStatuses(repository.InstanceStatusActivationInProgress, statusActivation, repository.InstanceStatusActivationFailed, repository.InstanceStatusActive)
}

func (is *instanceService) CheckVersionDeploymentInProgressInstancesStatus() {
	is.checkDeploymentStatuses(repository.InstanceStatusVersionDeploymentInProgress, statusVersion, repository.InstanceStatusVersionDeploymentFailed, repository.InstanceStatusActive)
}

func (is *instanceService) CheckNetworkDeploymentInProgressInstancesStatus() {
	is.checkDeploymentStatuses(repository.InstanceStatusNetworkDeploymentInProgress, statusNetwork, repository.InstanceStatusNetworkDeploymentFailed, repository.InstanceStatusActive)
}

func (is *instanceService) checkDeploymentStatuses(getStatus, deploymentType, failedStatus, successStatus string) {
	log.Printf("checking the %s in progress instances statuses for further processing!\n", deploymentType)
	list, totalResult, listErr := is.instanceRepository.GetProvisionedInstanceListByStatus(getStatus)
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while %s in progress instanceList from db\ncount: %d\terror if any: '%v'\n", deploymentType, totalResult, listErr)
		return
	}
	for _, instance := range list {
		log.Printf("\nCurrent %s in progress instance: %+v\n", deploymentType, instance)
		// checking the activate build status
		buildStatusRequest := &models.GetBuildStatus{
			BuildID:     instance.BuildID,
			AccountType: instance.AwsAccount,
			Region:      instance.Region,
		}

		if deploymentType == statusInactivation {
			buildStatusRequest.BuildID = instance.InactiveBuildID
		}

		build, err := helper.GetInstanceBuildStatus(&is.config, buildStatusRequest)
		if err != nil {
			log.Printf("Error while fetching %s in progress instance '%s' '%s' from aws '%v'\n", deploymentType, instance.Name, instance.BuildID, err)
			continue
		}

		switch buildStatus := build.BuildStatus; buildStatus {
		case types.StatusTypeInProgress:
			log.Printf("'%s' %s Build '%s' is still in progress hence waiting for some time!\n", instance.Name, deploymentType, instance.BuildID)
			continue
		case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
			log.Printf("%s Build '%s' name '%s' is %s", deploymentType, instance.BuildID, instance.Name, buildStatus)
			remarks := fmt.Sprintf("%s\n%s build '%s' failed with status '%s'", instance.BuildRemarks, deploymentType, instance.BuildID, buildStatus)
			if err := is.instanceRepository.UpdateInstanceStatus(instance.UUID.String(), failedStatus, remarks); err != nil {
				log.Printf("%s Build '%s' is Failed but error in updating success status '%s' from aws '%v'\n", deploymentType, instance.Name, instance.BuildID, err)
			}
			// Delete latest network from networks table
			if deploymentType == statusNetwork {
				if err := is.instanceRepository.DeleteLastAddedNetwork(); err != nil {
					log.Printf("%s Build '%s' is Failed and error in deleting last network entry '%s' from db '%v'\n", deploymentType, instance.Name, instance.BuildID, err)
				}
			}
			continue
		case types.StatusTypeSucceeded:
			log.Printf("%s Build '%s' name '%s' is Succeeded", deploymentType, instance.BuildID, instance.Name)
			if err := is.instanceRepository.UpdateInstanceStatus(instance.UUID.String(), successStatus, ""); err != nil {
				log.Printf("%s Build '%s' is Succeeded but error in updating success status '%s' from aws '%v'\n", deploymentType, instance.Name, instance.BuildID, err)
			}
			continue
		default:
			log.Printf("Build status for '%s' with id '%s' is unknown '%s'. Please check!\n", instance.Name, instance.BuildID, buildStatus)
		}
	}
}

func (is *instanceService) CheckEmailEligibleInstancesStatus() {
	fmt.Println("CheckEmailEligibleInstancesStatus for further processing!")
	list, totalResult, listErr := is.instanceRepository.GetEmailEligibleInstanceList()
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while CheckEmailEligibleInstancesStatus instanceList from db\ncount: %d\terror if any: '%v'\n", totalResult, listErr)
		return
	}

	for _, instance := range list {
		log.Printf("\nCurrent email eligible instance %+v\n", instance)
		customer, err := is.instanceRepository.GetCustomerDetailByName(instance.CustomerName)
		if err != nil {
			log.Printf("Error '%v' in getting customer details '%s' in sending success email for instance '%s' so moving to next in line\n", err, instance.CustomerName, instance.Name)
			continue
		}

		if isInvited, err := utils.SelfInviteUserManagement(instance.Name, instance.CustomDomain, instance.ContactEmail, customer.Country); err != nil || !isInvited {
			log.Printf("'%s' is Active but error in sending success email '%s' '%v' so moving to next in line\n", instance.Name, instance.BuildID, err)
			continue
		}

		//update the retry status in db so that we check the build status next time
		remarks := fmt.Sprintf("%s\nemail sent successfully\n", instance.BuildRemarks)
		if err := is.instanceRepository.UpdateInstanceStatusWithEmailPending(instance.UUID.String(), repository.InstanceStatusActive, remarks, false); err != nil {
			log.Printf("Error while updating retry flag for instance '%s' with remarks geting error: '%v'\n", instance.Name, err)
		}
		log.Printf("\nEmail is sent for domain '%s' if any or default domain '%s'\n", instance.CustomDomain, instance.Name)
	}

}

func sendDomainEntriesEmail(config config.Configuration, adminEmail, instanceName string, entries []models.AWSDomainEntries) error {
	sendEmailURL := config.Info.NotificationURL + "/send/instance/entries"
	input := models.InstanceDomainEntriesEmailRequest{
		To:           adminEmail,
		InstanceName: instanceName,
		Entry:        entries,
	}

	// Call notification service to send email
	sendInvitationEmailErr := utils.SendEmailPostRequest(sendEmailURL, input)
	if sendInvitationEmailErr != nil {
		log.Printf("Send invitation email err: %s", sendInvitationEmailErr.Error())
		return sendInvitationEmailErr
	}
	log.Printf("\nEmail is sent for domain entries '%s'\n", instanceName)
	return nil
}

func stringEntriesIntoAWSEntries(entries []string) []models.AWSDomainEntries {
	var modifiedEntries []models.AWSDomainEntries
	for _, entry := range entries {
		// Unmarshal the string into a slice of structs
		var awsDomainEntries []models.AWSDomainEntries
		if err := json.Unmarshal([]byte(entry), &awsDomainEntries); err != nil {
			fmt.Printf("\nError in unmarshalling : '%s' '%v'\n", entry, err)
			return nil
		}

		modifiedEntries = append(modifiedEntries, awsDomainEntries...)
	}
	return modifiedEntries
}
