package service

import (
	"fmt"
	"log"
	"saas-management/common"
	"saas-management/config"
	"saas-management/models"
	"saas-management/models/response"
	"saas-management/repository"
	"saas-management/utils"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/gin-gonic/gin"
)

type userService struct {
	saasUserRepo repository.SaasUserRepository
	keycloakRepo repository.KeycloakRepository
	config       config.Configuration
}

type UserService interface {
	GetProfileRoles(ctx *gin.Context, profileId string) (response.GetUserProfileRolesResp, *models.ErrorResponse)
	GetUserProfileDetails(ctx *gin.Context, profileId string) (*gocloak.User, *models.ErrorResponse)
	UpdateUserRoleStatus(ctx *gin.Context, profileId string, userRole string) (response.UserRoleUpdateResponse, *models.ErrorResponse)
	UpdateUserStatus(ctx *gin.Context, profileId string, adminEmail string) (response.UpdateUserStatusResp, *models.ErrorResponse)
	DeleteSaasUser(ctx *gin.Context, emailId string, adminEmail string) (response.DeleteSaasUserResp, *models.ErrorResponse)
}

func NewUserService(saasUser repository.SaasUserRepository,
	keycloakRepo repository.KeycloakRepository, config config.Configuration) UserService {
	return userService{
		saasUserRepo: saasUser,
		keycloakRepo: keycloakRepo,
		config:       config,
	}
}

func (i userService) GetProfileRoles(ctx *gin.Context, profileId string) (response.GetUserProfileRolesResp, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("GetProfileRoles loginAdmin error. Err:: %s", err.Error())
		return response.GetUserProfileRolesResp{}, &common.ErrorServiceFailed
	}

	// Get realm roles of keycloak user
	userRealmRoles, realmRoleErr := client.GetRealmRolesByUserID(ctx, token.AccessToken, realm, profileId)
	if realmRoleErr != nil {
		err := common.ErrorUserNotFound
		return response.GetUserProfileRolesResp{}, &err
	}

	return response.GetUserProfileRolesResp{
		Data: response.UserProfileRolesResponse{
			Roles: userRealmRoles,
		},
	}, nil
}

func (i userService) GetUserProfileDetails(ctx *gin.Context, profileId string) (*gocloak.User, *models.ErrorResponse) {
	realm := i.config.Info.Realm

	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("GetProfileRoles loginAdmin error. Err:: %s", err.Error())
		return nil, &common.ErrorServiceFailed
	}

	// Get keycloak user from admin client and token
	userInfo, userDetailsErr := client.GetUserByID(ctx, token.AccessToken, realm, profileId)
	if userDetailsErr != nil {
		return nil, &common.ErrorUserNotFound
	}

	return userInfo, nil
}

func (i userService) UpdateUserRoleStatus(ctx *gin.Context, profileId string, userRole string) (response.UserRoleUpdateResponse, *models.ErrorResponse) {
	realm := i.config.Info.Realm

	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("GetProfileRoles loginAdmin error. Err:: %s", err.Error())
		return response.UserRoleUpdateResponse{}, &common.ErrorServiceFailed
	}

	// Get keycloak user from admin client and token
	profileUserInfo, userDetailsErr := client.GetUserByID(ctx, token.AccessToken, realm, profileId)
	if userDetailsErr != nil {
		return response.UserRoleUpdateResponse{}, &common.ErrorUserNotFound
	}

	jwtPayload, err := utils.GetTokenFromJwtHeader(ctx)
	if err != nil {
		return response.UserRoleUpdateResponse{}, &common.ErrorTokenVerificationFailed
	}

	if jwtPayload.Email == *profileUserInfo.Email {
		return response.UserRoleUpdateResponse{}, &common.ErrorUserStatusUpdate
	}

	// Get all roles for realm
	allRoles, err := client.GetRealmRoles(ctx, token.AccessToken, realm, gocloak.GetRoleParams{})
	if err != nil {
		log.Printf("Realm role fetch error")
		return response.UserRoleUpdateResponse{}, &common.ErrorGetRealmRolesFailed
	}

	// Filter user role from all roles
	roleDetails := utils.FilterRealmRoles(allRoles, userRole)
	if roleDetails == nil {
		log.Printf("filtered role details not found")
		return response.UserRoleUpdateResponse{}, &common.ErrorUpdateRoleFailed
	}

	// Get assigned roles for user
	userRealmRoles, realmRoleErr := client.GetRealmRolesByUserID(ctx, token.AccessToken, realm, profileId)
	if realmRoleErr != nil {
		log.Printf("User role fetch error")
		return response.UserRoleUpdateResponse{}, &common.ErrorGetRealmRolesFailed
	}

	rolesRep := []gocloak.Role{}
	rolesRep = append(rolesRep, *roleDetails)

	// Get profileId and userId for a userId stored in db
	usr := models.SaasUserProfile{}
	userDetailsErr = i.saasUserRepo.GetUserDetailsByProfileIdFromDB(profileId, &usr)
	if userDetailsErr != nil {
		log.Printf("UpdateUserStatus error. Err:: %s", userDetailsErr.Error())
		return response.UserRoleUpdateResponse{}, &common.ErrorDBFailed
	}

	// Check if admin role exist for user (if exist then unassign if not then assign)
	if utils.ContainRole(userRealmRoles, userRole) {
		roles := utils.RemoveElementFromCommaSeperatedString(usr.AllowedRoles, userRole)
		if err = i.saasUserRepo.UpdateUserRolesByProfileID(profileId, roles); err != nil {
			log.Printf("updating failed for user '%s' with role(s) '%s' having '%s'", profileId, roles, err.Error())
			return response.UserRoleUpdateResponse{}, &common.ErrorUpdateRoleFailed
		}
		deleteKeycloakErr := client.DeleteRealmRoleFromUser(ctx, token.AccessToken, realm, profileId, rolesRep)
		if deleteKeycloakErr != nil {
			log.Printf("Error in deleting admin role config err:: %s", deleteKeycloakErr.Error())
			return response.UserRoleUpdateResponse{}, &common.ErrorUpdateRoleFailed
		}
	} else {
		roles := utils.AddElementToCommaSeperatedString(usr.AllowedRoles, userRole)
		if err = i.saasUserRepo.UpdateUserRolesByProfileID(profileId, roles); err != nil {
			log.Printf("updating failed for user '%s' with role(s) '%s' having '%s'", profileId, roles, err.Error())
			return response.UserRoleUpdateResponse{}, &common.ErrorUpdateRoleFailed
		}
		addRoleAddErr := client.AddRealmRoleToUser(ctx, token.AccessToken, realm, profileId, rolesRep)
		if addRoleAddErr != nil {
			log.Printf("Error in adding admin role config err:: %s", addRoleAddErr.Error())
			return response.UserRoleUpdateResponse{}, &common.ErrorUpdateRoleFailed
		}
	}

	return response.UserRoleUpdateResponse{Message: userRole + " role updated successfully"}, nil
}

func (i userService) UpdateUserStatus(ctx *gin.Context, profileId string, adminEmail string) (response.UpdateUserStatusResp, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	saasUserProfile := models.SaasUserProfile{}

	// Get user details from db (user_invitation)
	userDetailsErr := i.saasUserRepo.GetUserDetailsByProfileIdFromDB(profileId, &saasUserProfile)
	if userDetailsErr != nil {
		log.Printf("UpdateUserStatus error. Err:: %s", userDetailsErr.Error())
		return response.UpdateUserStatusResp{}, &common.ErrorDBFailed
	}

	if saasUserProfile.Email == "" {
		log.Printf("User details not found. Err:: %s", profileId)
		return response.UpdateUserStatusResp{}, &common.ErrorUserNotFound
	}

	if saasUserProfile.Email == adminEmail {
		log.Printf("Self update is not allowed. Err:: %s", profileId)
		return response.UpdateUserStatusResp{}, &common.ErrorUserStatusUpdate
	}

	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("GetProfileRoles loginAdmin error. Err:: %s", err.Error())
		return response.UpdateUserStatusResp{}, &common.ErrorServiceFailed
	}

	// Get keycloak user from admin client and token
	profileUserInfo, userDetailsErr := client.GetUserByID(ctx, token.AccessToken, realm, profileId)
	if userDetailsErr != nil {
		return response.UpdateUserStatusResp{}, &common.ErrorUserNotFound
	}

	// Get all roles for realm
	allRoles, err := client.GetRealmRoles(ctx, token.AccessToken, realm, gocloak.GetRoleParams{})
	if err != nil {
		log.Printf("Realm role fetch error")
		return response.UpdateUserStatusResp{}, &common.ErrorGetRealmRolesFailed
	}

	// Filter validated role from all roles
	roleDetails := utils.FilterRealmRoles(allRoles, common.ValidatedRole)
	if roleDetails == nil {
		log.Printf("filtered role details not found")
		return response.UpdateUserStatusResp{}, &common.ErrorUpdateRoleFailed
	}

	rolesRep := []gocloak.Role{}
	rolesRep = append(rolesRep, *roleDetails)

	// Based on current state update db and keycloak
	if saasUserProfile.State == common.InactiveState {
		userEnabled := true
		profileUserInfo.Enabled = &userEnabled
		(*profileUserInfo.Attributes)["STATE"] = []string{common.AcceptedState}
		saasUserProfile.State = common.AcceptedState

		addRoleAddErr := client.AddRealmRoleToUser(ctx, token.AccessToken, realm, profileId, rolesRep)
		if addRoleAddErr != nil {
			log.Printf("Error in adding admin role config err:: %s", addRoleAddErr.Error())
			return response.UpdateUserStatusResp{}, &common.ErrorUpdateRoleFailed
		}
	} else {

		userEnabled := false
		profileUserInfo.Enabled = &userEnabled
		(*profileUserInfo.Attributes)["STATE"] = []string{common.InactiveState}
		saasUserProfile.State = common.InactiveState

		deleteKeycloakErr := client.DeleteRealmRoleFromUser(ctx, token.AccessToken, realm, profileId, rolesRep)
		if deleteKeycloakErr != nil {
			log.Printf("Error in deleting admin role config err:: %s", deleteKeycloakErr.Error())
			return response.UpdateUserStatusResp{}, &common.ErrorUpdateRoleFailed
		}

	}
	saasUserProfile.LastUpdatedBy = adminEmail
	saasUserProfile.LastUpdatedDate = time.Now()

	updateUserErr := client.UpdateUser(ctx, token.AccessToken, realm, *profileUserInfo)
	if updateUserErr != nil {
		fmt.Printf("Update user attribite err: %s", updateUserErr.Error())
		return response.UpdateUserStatusResp{}, &common.ErrorResetEmailFailed
	}

	updateErr := i.saasUserRepo.UpdateSaasUserState(saasUserProfile.Email, saasUserProfile)
	if updateErr != nil {
		log.Printf("Error while updating user in db user err: %s", updateErr.Error())
		return response.UpdateUserStatusResp{}, &common.ErrorDBFailed
	}

	return response.UpdateUserStatusResp{Message: "User status updated successfully"}, nil
}

func (i userService) DeleteSaasUser(ctx *gin.Context, emailId string, adminEmail string) (response.DeleteSaasUserResp, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	saasUserProfile := models.SaasUserProfile{}

	// Get user details from db (user_invitation)
	userDetailsErr := i.saasUserRepo.GetUserDetailsFromDB(emailId, &saasUserProfile)
	if userDetailsErr != nil {
		log.Printf("UpdateUserStatus error. Err:: %s", userDetailsErr.Error())
		return response.DeleteSaasUserResp{}, &common.ErrorDBFailed
	}

	if saasUserProfile.Email == "" {
		log.Printf("User details not found. Err:: %s", emailId)
		return response.DeleteSaasUserResp{}, &common.ErrorUserNotFound
	}

	if saasUserProfile.Email == adminEmail {
		log.Printf("Self update is not allowed. Err:: %s", emailId)
		return response.DeleteSaasUserResp{}, &common.ErrorDeleteUser
	}

	if saasUserProfile.State == common.AcceptedState {
		log.Printf("Active user can not be deleted. Err:: %s", emailId)
		return response.DeleteSaasUserResp{}, &common.ErrorDeleteUser
	}

	if saasUserProfile.ProfileId != "" {
		// Admin client and token for getting user from keycloak
		client, token, err := utils.LoginAdmin(ctx, &i.config)
		if err != nil {
			log.Printf("DeleteSaasUser loginAdmin error. Err:: %s", err.Error())
			return response.DeleteSaasUserResp{}, &common.ErrorServiceFailed
		}

		keycloakUser := gocloak.GetUsersParams{
			Email: gocloak.StringP(emailId),
		}
		// Fetch user based on email
		fetchedUser, fetchErr := client.GetUsers(ctx, token.AccessToken, realm, keycloakUser)
		if fetchErr != nil {
			log.Printf("DeleteSaasUser clientGetUsers error. Err:: %s", fetchErr.Error())
			return response.DeleteSaasUserResp{}, &common.ErrorServiceFailed
		}

		if len(fetchedUser) == 0 {
			log.Printf("DeleteSaasUser user not found. Err:: %s", emailId)
			return response.DeleteSaasUserResp{}, &common.ErrorUserNotFound
		}

		userDetails := *fetchedUser[0]
		// Delete user from keycloak
		deleteErr := client.DeleteUser(ctx, token.AccessToken, realm, *userDetails.ID)
		if deleteErr != nil {
			log.Printf("DeleteSaasUser keycloak delete user failed. Err:: %s", deleteErr.Error())
			return response.DeleteSaasUserResp{}, &common.ErrorDeleteUser
		}
	}

	// Delete user from db
	deleteDbErr := i.saasUserRepo.DeleteSaasUser(saasUserProfile.Email)
	if deleteDbErr != nil {
		log.Printf("Error while deleting user in db user err: %s", deleteDbErr.Error())
		return response.DeleteSaasUserResp{}, &common.ErrorDBFailed
	}

	return response.DeleteSaasUserResp{Message: "User deleted successfully"}, nil
}
