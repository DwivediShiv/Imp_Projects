package service

import (
	"fmt"
	"log"
	"saas-management/common"
	"saas-management/config"
	"saas-management/helper"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	"saas-management/repository"
	"saas-management/utils"
	"strings"

	"github.com/aws/aws-sdk-go-v2/service/codebuild/types"
	"github.com/gin-gonic/gin"
)

const (
	clusterStatusVersion = "Version deployment"
	clusterStatusNetwork = "Network deployment"
)

var ClusterUIStatusMap = map[string][]string{
	"Success": {repository.ClusterStatusActive},
	"Deploying": {repository.ClusterStatusProvisioned,
		repository.ClusterStatusVersionDeploymentInProgress, repository.ClusterStatusNetworkDeploymentInProgress},
	"Failed": {repository.ClusterStatusFailed, repository.ClusterStatusDeletionFailed,
		repository.ClusterStatusNetworkDeploymentFailed, repository.ClusterStatusVersionDeploymentFailed},
	"Deleting": {repository.ClusterStatusDeletionInProgress},
	"Deleted":  {repository.ClusterStatusDeleted},
}

type clusterService struct {
	clusterRepository repository.ClusterRepository
	config            config.Configuration
}

type ClusterService interface {
	SaveCluster(ctx *gin.Context, apiReq *request.ClusterDetail, adminEmail string) (*response.CreateClusterResponse, *models.ErrorResponse)
	GetClusterByID(ctx *gin.Context, clusterId string) (*response.GetClusterResponse, *models.ErrorResponse)
	GetClusterList(ctx *gin.Context, cl *request.ClusterList) (*response.ClusterListResponse, *models.ErrorResponse)
	ExportClusterList(ctx *gin.Context, cl *request.ClusterList) *models.ErrorResponse
	CheckProvisionedClustersStatus()
	DeleteCluster(ctx *gin.Context, clusterID string) *models.ErrorResponse
	DeployClusterVersion(ctx *gin.Context, clusterID, version string) *models.ErrorResponse
	DeployClusterNetwork(ctx *gin.Context, network *request.ClusterNetwork, clusterID string) *models.ErrorResponse
	CheckDeletionInProgressClustersStatus()
	CheckVersionDeploymentInProgressClustersStatus()
	CheckNetworkDeploymentInProgressClustersStatus()
}

func NewClusterService(crepo repository.ClusterRepository, config config.Configuration) ClusterService {
	return &clusterService{
		clusterRepository: crepo,
		config:            config,
	}
}

func (cs *clusterService) SaveCluster(ctx *gin.Context, apiReq *request.ClusterDetail, adminEmail string) (*response.CreateClusterResponse, *models.ErrorResponse) {
	// validate version
	versions, err := helper.GetVersionInfoFromS3(&cs.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}
	if !versionInVersionArray(apiReq.Version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "Version is invalid"
		return nil, &err1
	}

	// validate cluster name
	if isNameExist, _ := cs.clusterRepository.IsClusterNameExist(apiReq.Name, apiReq.AWSAccount); isNameExist {
		err1 := common.ErrorClusterNameAlreadyExists
		err1.Error.AdditionalData = "Cluster name already exists"
		return nil, &err1
	}

	// Validation region name
	if isRegionExist, _ := cs.clusterRepository.IsClusterExistsInRegion(apiReq.Region, apiReq.AWSAccount); isRegionExist {
		errMsg := fmt.Sprintf("Cluster already exists in '%s' region and '%s' aws account.", apiReq.Region, apiReq.AWSAccount)
		err1 := common.ErrorClusterNameAlreadyExistsInRegion
		err1.Error.AdditionalData = errMsg
		return nil, &err1
	}

	if err := utils.NewtworkAWSAccountRegionValidation(ctx, &cs.config, apiReq.Network, apiReq.AWSAccount, apiReq.Region); err != nil {
		return nil, err
	}

	// call lambda to create cluster
	createClusterArgs := &models.CreateClusterArgs{
		ClusterName: apiReq.Name,
		AccountType: apiReq.AWSAccount,
		Version:     apiReq.Version,
		Region:      apiReq.Region,
		Network:     apiReq.Network,
	}
	buidlID, err := helper.RunCreateClusterCodeBuildPipeline(&cs.config, createClusterArgs)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	apiReq.BuildID = *buidlID
	id, err := cs.clusterRepository.CreateCluster(apiReq, adminEmail)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	log.Printf("\nCluster '%s' created with id '%s' having buildID '%s'\n", apiReq.Name, id, apiReq.BuildID)
	return &response.CreateClusterResponse{Message: fmt.Sprintf("Creation of cluster '%s' in region '%s' triggered successfully.", apiReq.Name, apiReq.Region)}, nil
}

func (cs *clusterService) GetClusterByID(ctx *gin.Context, clusterId string) (*response.GetClusterResponse, *models.ErrorResponse) {
	cluster, err := cs.clusterRepository.GetClusterDetail(clusterId)
	if err != nil {
		err1 := common.ErrorClusterNotFound
		return nil, &err1
	}

	// Get number of instances in cluster region
	numberOfIns, numberOfInsErr := cs.clusterRepository.GetNumberOfInstancesInClusterRegion(cluster.Region, cluster.AwsAccount)
	if numberOfInsErr != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return nil, &err1
	}

	resp := &response.GetClusterResponse{
		ID:                cluster.UUID.String(),
		Name:              cluster.Name,
		CreatedAt:         cluster.CreatedAt,
		CreatedBy:         cluster.CreatedBy,
		AWSAccount:        cluster.AwsAccount,
		Region:            cluster.Region,
		Version:           cluster.Version,
		Status:            cluster.Status,
		NumberOfInstances: numberOfIns,
	}

	var networkList []response.ClusterNetwork
	for _, n := range cluster.NetworkRecords {
		network := response.ClusterNetwork{
			Network:   n.Network,
			CreatedAt: n.CreatedAt,
		}
		networkList = append(networkList, network)
	}
	resp.Networks = networkList

	return resp, nil
}

func (cs *clusterService) GetClusterList(ctx *gin.Context, cl *request.ClusterList) (*response.ClusterListResponse, *models.ErrorResponse) {
	// Update pagination number of records to 10
	if cl.NumberRecords == 0 {
		cl.NumberRecords = 10
	}

	if cl.Get == "All" {
		cl.NumberRecords = 1000000
	}

	if cl.StatusTab != "" {
		_, exists := repository.ClusterSimilarStatuseMap[cl.StatusTab]
		if !exists {
			err1 := common.ErrorInvalidRequestInput
			err1.Error.AdditionalData = fmt.Sprintf("'%s' is invalid statusTab", cl.StatusTab)
			return nil, &err1
		}
	}

	// Get cluster list
	list, totalResult, listErr := cs.clusterRepository.GetClusterList(cl)
	if listErr != nil || totalResult == -1 {
		log.Printf("Error while fetching clusterList from db")
		return nil, &common.ErrorDBFailed
	}

	clusterList := []response.GetClusterResponse{}
	for _, cluster := range list {
		resp := response.GetClusterResponse{
			ID:         cluster.UUID.String(),
			Name:       cluster.Name,
			CreatedAt:  cluster.CreatedAt,
			CreatedBy:  cluster.CreatedBy,
			AWSAccount: cluster.AwsAccount,
			Region:     cluster.Region,
			Version:    cluster.Version,
			Status:     cluster.Status,
			UpdatedAt:  cluster.UpdatedAt,
		}

		var networkList []response.ClusterNetwork
		for _, n := range cluster.NetworkRecords {
			network := response.ClusterNetwork{
				Network:   n.Network,
				CreatedAt: n.CreatedAt,
			}
			networkList = append(networkList, network)
		}
		resp.Networks = networkList
		clusterList = append(clusterList, resp)
	}

	regions, err := cs.clusterRepository.GetUniqueClusterRegions()
	if err != nil {
		log.Printf("Error while fetching regions from db")
		return nil, &common.ErrorDBFailed
	}

	resp := &response.ClusterListResponse{Data: clusterList,
		TotalRecord: totalResult,
		FilterCriterias: response.ClusterFilterCriterias{
			Regions: regions,
		},
	}

	return resp, nil
}

func (cs *clusterService) ExportClusterList(ctx *gin.Context, cl *request.ClusterList) *models.ErrorResponse {
	// Update pagination number of records to 10
	if cl.NumberRecords == 0 {
		cl.NumberRecords = 10
	}

	if cl.Get == "All" {
		cl.NumberRecords = 1000000
	}

	if cl.StatusTab != "" {
		_, exists := repository.ClusterSimilarStatuseMap[cl.StatusTab]
		if !exists {
			err1 := common.ErrorInvalidRequestInput
			err1.Error.AdditionalData = fmt.Sprintf("'%s' is invalid statusTab", cl.StatusTab)
			return &err1
		}
	}

	// Get customer list
	list, totalResult, listErr := cs.clusterRepository.GetClusterList(cl)
	if listErr != nil || totalResult == -1 {
		log.Printf("Error while fetching clusterList from db")
		return &common.ErrorDBFailed
	}

	// Excel Fucntionality
	headers := utils.GenerateInvitedUserRowHeader(common.ClusterListRowHeaders)

	// Generate csv data
	var csvClusterData strings.Builder
	csvClusterData.WriteString(headers)

	var lastIndex = len(list) - 1
	for index, cluster := range list {
		// Excel Body
		rowBody := generateClusterRowBody(cluster)
		csvClusterData.WriteString(rowBody)
		if index != lastIndex {
			csvClusterData.WriteString("\n")
		}
	}

	// Write the sql result to csv file
	fileName := "clusters.csv"
	ctx.Header("Content-Type", "application/octet-stream")
	ctx.Header("Content-Disposition", "attachment; filename="+fileName)
	ctx.Header("Content-Disposition", "inline;filename="+fileName)
	ctx.Header("Content-Transfer-Encoding", "binary")
	ctx.Header("Cache-Control", "no-cache")
	ctx.Writer.WriteString(csvClusterData.String())

	return nil
}

func (cs *clusterService) DeployClusterVersion(ctx *gin.Context, clusterID, version string) *models.ErrorResponse {
	cluster, err := cs.clusterRepository.GetClusterDetail(clusterID)
	if err != nil {
		err1 := common.ErrorClusterNotFound
		return &err1
	}

	// validate version
	versions, err := helper.GetVersionInfoFromS3(&cs.config)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}
	if !versionInVersionArray(version, versions) {
		err1 := common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "Version is invalid"
		return &err1
	}

	if utils.Contains(repository.ClusterSimilarStatuseMap[repository.ClusterStatusInProgress], cluster.Status) {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "action is not allowed when deployment is in progress"
		return &err1
	}

	if utils.Contains(repository.ClusterSimilarStatuseMap[repository.ClusterStatusDeleted], cluster.Status) {
		err1 := common.ErrorActionNotAllowedDeleted
		err1.Error.AdditionalData = "action is not allowed when cluster is deleted"
		return &err1
	}

	// call lambda to create cluster
	nl := len(cluster.NetworkRecords)
	network := cluster.NetworkRecords[nl-1]
	createClusterArgs := &models.CreateClusterArgs{
		Version:     version,
		AccountType: cluster.AwsAccount,
		Region:      cluster.Region,
		ClusterName: cluster.Name,
		Network:     network.Network,
	}

	buildID, err := helper.RunCreateClusterCodeBuildPipeline(&cs.config, createClusterArgs)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	remarks := fmt.Sprintf("%s\nPrevious build id '%s' & version '%s'. New build started for deploying version '%s' of cluster", cluster.BuildRemarks, cluster.BuildID, cluster.Version, version)
	req := &models.UpdateClusterRequest{BuildID: *buildID, Remarks: remarks, Status: repository.ClusterStatusVersionDeploymentInProgress, Version: version}
	err = cs.clusterRepository.UpdateClusterBuildAndStatus(clusterID, req)
	if err != nil {
		log.Printf("Error while updating deploy version build id for cluster '%s' with remarks geting error: '%v'\n", cluster.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	log.Printf("\nCluster '%s' having current version '%s' deployment started with build id '%s' for provided version '%s' \n", cluster.Name, cluster.Version, *buildID, version)
	return nil
}

func (cs *clusterService) DeployClusterNetwork(ctx *gin.Context, network *request.ClusterNetwork, clusterID string) *models.ErrorResponse {
	cluster, err := cs.clusterRepository.GetClusterDetail(clusterID)
	if err != nil {
		err1 := common.ErrorClusterNotFound
		return &err1
	}

	if err := utils.NewtworkSymbolValidation(ctx, &cs.config, network.Network); err != nil {
		return err
	}

	if utils.Contains(repository.ClusterSimilarStatuseMap[repository.ClusterStatusInProgress], cluster.Status) {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "action is not allowed when deployment is in progress"
		return &err1
	}

	if utils.Contains(repository.ClusterSimilarStatuseMap[repository.ClusterStatusDeleted], cluster.Status) {
		err1 := common.ErrorActionNotAllowedDeleted
		err1.Error.AdditionalData = "action is not allowed when cluster is deleted"
		return &err1
	}

	if _, err = cs.clusterRepository.AddNetwork(network, cluster.ID); err != nil {
		log.Printf("\nAdding network %s failed: %v \n", network.Network, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = "Network could not be added! please contact admin."
		return &err1
	}

	// call lambda to create cluster
	createClusterArgs := &models.CreateClusterArgs{
		Version:     cluster.Version,
		AccountType: cluster.AwsAccount,
		Region:      cluster.Region,
		ClusterName: cluster.Name,
		Network:     network.Network,
	}

	buildID, err := helper.RunCreateClusterCodeBuildPipeline(&cs.config, createClusterArgs)
	if err != nil {
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	nl := len(cluster.NetworkRecords)
	n := cluster.NetworkRecords[nl-1]
	remarks := fmt.Sprintf("%s\nPrevious build id '%s' & network '%s'. New build started for deploying network '%s' of cluster", cluster.BuildRemarks, cluster.BuildID, n.Network, network.Network)
	req := &models.UpdateClusterRequest{BuildID: *buildID, Remarks: remarks, Status: repository.ClusterStatusNetworkDeploymentInProgress}
	err = cs.clusterRepository.UpdateClusterBuildAndStatus(clusterID, req)
	if err != nil {
		log.Printf("Error while updating deploy network build id for cluster '%s' with remarks geting error: '%v'\n", cluster.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	log.Printf("\nCluster '%s' having current network '%s' deployment started with build id '%s' for provided network '%s' \n", cluster.Name, n.Network, *buildID, network.Network)
	return nil
}

func (cs *clusterService) DeleteCluster(ctx *gin.Context, clusterId string) *models.ErrorResponse {
	cluster, err := cs.clusterRepository.GetClusterDetail(clusterId)
	if err != nil {
		err1 := common.ErrorClusterNotFound
		return &err1
	}

	// Inprogress states - no delete
	isDeleteAllowed := true
	for _, buildStatus := range repository.ClusterSimilarStatuseMap[repository.ClusterStatusInProgress] {
		if cluster.Status == buildStatus {
			isDeleteAllowed = false
			break
		}
	}
	if !isDeleteAllowed {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "Delete cluster is not allowed in in-progress states."
		return &err1
	}

	// Validation based on instance on same region and account
	if exists, _ := cs.clusterRepository.IsInstanceExistsInRegion(cluster.Region, cluster.AwsAccount); exists {
		err1 := common.ErrorActionNotAllowedFailed
		err1.Error.AdditionalData = "Delete cluster is not allowed if instance is present in same region and account."
		return &err1
	}

	// call lambda to delete cluster
	deleteClusterArgs := &models.DeleteClusterArgs{
		Version:     cluster.Version,
		AccountType: cluster.AwsAccount,
		Region:      cluster.Region,
		ClusterName: cluster.Name,
	}
	buildID, err := helper.RunDeleteClusterCodeBuildPipeline(&cs.config, deleteClusterArgs)
	if err != nil {
		log.Printf("Error in deleting cluster: %v", err.Error())
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = "Code build failed for deletion."
		return &err1
	}

	// update delete details in repo
	remarks := fmt.Sprintf("%s\nbuild '%s' is triggered for deleting the cluster.", cluster.BuildRemarks, *buildID)
	if err = cs.clusterRepository.UpdateClusterDeleteID(clusterId, *buildID, remarks); err != nil {
		log.Printf("Error while updating delete build id '%s' for cluster '%s' with remarks geting error: '%v'\n", *buildID, cluster.Name, err)
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return &err1
	}

	return nil
}

// // Generate cluster list export body
func generateClusterRowBody(entity models.Clusters) string {
	var row strings.Builder
	var networkStrings []string

	for _, network := range entity.NetworkRecords {
		networkStrings = append(networkStrings, network.Network)
	}

	// UI status updated
	clusterUiStatus := getClusterUIStatus(entity.Status)

	commaNetwrokString := strings.Join(networkStrings, ", ")
	row.WriteString(`"` + entity.Name + `"` + ",")
	row.WriteString(entity.Region + ",")
	row.WriteString(`"` + commaNetwrokString + `"` + ",")
	row.WriteString(entity.Version + ",")
	row.WriteString(entity.CreatedBy + ",")
	row.WriteString(entity.CreatedAt.Format("02 Jan 2006") + ",")
	row.WriteString(entity.UpdatedAt.Format("02 Jan 2006") + ",")
	row.WriteString(clusterUiStatus)
	return row.String()
}

func (cs *clusterService) CheckProvisionedClustersStatus() {
	fmt.Println("checking the created clusters statuses for further processing!")
	list, totalResult, listErr := cs.clusterRepository.GetProvisionedClusterList()
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while fetching provisioned clusterList from db\ncount: %d\terror if any: '%v'\n", totalResult, listErr)
		return
	}

	// check build status
	for _, cluster := range list {
		log.Printf("\nCurrent provisioned in progress cluster: %+v\n", cluster)
		buildStatus := &models.GetBuildStatus{
			BuildID:     cluster.BuildID,
			AccountType: cluster.AwsAccount,
			Region:      cluster.Region,
		}
		build, err := helper.GetInstanceBuildStatus(&cs.config, buildStatus)
		if err != nil {
			log.Printf("Error while fetching provisioned cluster '%s' '%s' from aws '%v'\n", cluster.Name, cluster.BuildID, err)
			continue
		}

		switch buildStatus := build.BuildStatus; buildStatus {
		case types.StatusTypeInProgress:
			log.Printf("Build '%s' is still in progress hence moving to next provisioned cluster '%s' from aws '%v'\n", cluster.Name, cluster.BuildID, err)
			continue
		case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
			if err := cs.clusterRepository.UpdateClusterStatus(cluster.UUID.String(), repository.ClusterStatusFailed, string(buildStatus)); err != nil {
				log.Printf("Build '%s' is Failed but error in updating success status '%s' from aws '%v'\n", cluster.Name, cluster.BuildID, err)
			}
			continue
		case types.StatusTypeSucceeded:
			cs.clusterSucceedFlow(cluster, string(buildStatus))
			continue
		default:
			log.Printf("Build status for '%s' with id '%s' is unknown '%s'. Please check!\n", cluster.Name, cluster.BuildID, buildStatus)
		}
	}
}

func (cs *clusterService) clusterSucceedFlow(cluster models.Clusters, buildStatus string) {

	if err := cs.clusterRepository.UpdateClusterStatus(cluster.UUID.String(), repository.ClusterStatusActive, buildStatus); err != nil {
		log.Printf("Build '%s' is Succeeded but error in updating pending verification status '%s' from aws '%v'", cluster.Name, cluster.BuildID, err)
	}
	log.Printf("Build '%s' is Succeeded hence moving to next provisioned cluster '%s' from aws", cluster.Name, cluster.BuildID)
}

func (cs *clusterService) CheckDeletionInProgressClustersStatus() {
	fmt.Println("checking the deletion in progress clusters statuses for further processing!")
	list, totalResult, listErr := cs.clusterRepository.GetDeletionInProgressClusters()
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while deletion in progress clusterList from db\ncount: %d\terror if any: '%v'\n", totalResult, listErr)
		return
	}

	for _, cluster := range list {
		log.Printf("\nCurrent deletion in progress clusters %+v\n", cluster)
		if cluster.DeleteStatus == repository.ClusterStatusDeletionFailed {
			continue
		}
		// checking the deleted build status
		buildStatus := &models.GetBuildStatus{
			BuildID:     cluster.DeleteBuildID,
			AccountType: cluster.AwsAccount,
			Region:      cluster.Region,
		}
		build, err := helper.GetInstanceBuildStatus(&cs.config, buildStatus)
		if err != nil {
			log.Printf("Error while fetching deletion in progress cluster '%s' '%s' from aws '%v'\n", cluster.Name, cluster.DeleteBuildID, err)
			continue
		}

		switch buildStatus := build.BuildStatus; buildStatus {
		case types.StatusTypeInProgress:
			log.Printf("'%s' Deletion Build '%s' is still in progress hence waiting for some time!\n", cluster.Name, cluster.DeleteBuildID)
			continue
		case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
			remarks := fmt.Sprintf("%s\ndeletion build failed with status '%s'", cluster.BuildRemarks, buildStatus)
			if err := cs.clusterRepository.UpdateClusterDeleteStatus(cluster.UUID.String(), repository.ClusterStatusDeletionFailed, string(buildStatus), remarks); err != nil {
				log.Printf("Deletion Build '%s' is Failed but error in updating success status '%s' from aws '%v'\n", cluster.Name, cluster.DeleteBuildID, err)
			}
			continue
		case types.StatusTypeSucceeded:
			remarks := fmt.Sprintf("Deletion Build '%s' name '%s' is Succeeded", cluster.DeleteBuildID, cluster.Name)
			if err := cs.clusterRepository.UpdateClusterDeleteStatus(cluster.UUID.String(), repository.ClusterStatusDeleted, string(buildStatus), remarks); err != nil {
				log.Printf("Deletion Build '%s' is Succeeded but error in updating success status '%s' from aws '%v'\n", cluster.Name, cluster.DeleteBuildID, err)
			}
			continue
		default:
			log.Printf("Build status for '%s' with id '%s' is unknown '%s'. Please check!\n", cluster.Name, cluster.DeleteBuildID, buildStatus)
		}
	}
}

func (cs *clusterService) CheckVersionDeploymentInProgressClustersStatus() {
	cs.checkDeploymentStatuses(repository.ClusterStatusVersionDeploymentInProgress, clusterStatusVersion, repository.ClusterStatusVersionDeploymentFailed, repository.ClusterStatusActive)
}

func (cs *clusterService) CheckNetworkDeploymentInProgressClustersStatus() {
	cs.checkDeploymentStatuses(repository.ClusterStatusNetworkDeploymentInProgress, clusterStatusNetwork, repository.ClusterStatusNetworkDeploymentFailed, repository.ClusterStatusActive)
}

func (cs *clusterService) checkDeploymentStatuses(getStatus, deploymentType, failedStatus, successStatus string) {
	log.Printf("checking the %s in progress clusters statuses for further processing!\n", deploymentType)
	list, totalResult, listErr := cs.clusterRepository.GetProvisionedClusterListByStatus(getStatus)
	if listErr != nil || totalResult < 1 {
		log.Printf("Error while %s in progress clusterList from db\ncount: %d\terror if any: '%v'\n", deploymentType, totalResult, listErr)
		return
	}
	for _, cluster := range list {
		log.Printf("\nCurrent %s in progress cluster: %+v\n", deploymentType, cluster)
		// checking the activate build status
		buildStatusRequest := &models.GetBuildStatus{
			BuildID:     cluster.BuildID,
			AccountType: cluster.AwsAccount,
			Region:      cluster.Region,
		}

		build, err := helper.GetInstanceBuildStatus(&cs.config, buildStatusRequest)
		if err != nil {
			log.Printf("Error while fetching %s in progress cluster '%s' '%s' from aws '%v'\n", deploymentType, cluster.Name, cluster.BuildID, err)
			continue
		}

		switch buildStatus := build.BuildStatus; buildStatus {
		case types.StatusTypeInProgress:
			log.Printf("'%s' %s Build '%s' is still in progress hence waiting for some time!\n", cluster.Name, deploymentType, cluster.BuildID)
			continue
		case types.StatusTypeFault, types.StatusTypeFailed, types.StatusTypeStopped, types.StatusTypeTimedOut:
			log.Printf("%s Build '%s' name '%s' is %s", deploymentType, cluster.BuildID, cluster.Name, buildStatus)
			remarks := fmt.Sprintf("%s\n%s build '%s' failed with status '%s'", cluster.BuildRemarks, deploymentType, cluster.BuildID, buildStatus)
			if err := cs.clusterRepository.UpdateClusterStatus(cluster.UUID.String(), failedStatus, remarks); err != nil {
				log.Printf("%s Build '%s' is Failed but error in updating success status '%s' from aws '%v'\n", deploymentType, cluster.Name, cluster.BuildID, err)
			}
			// Delete latest network from cluster_networks table
			if deploymentType == clusterStatusNetwork {
				if err := cs.clusterRepository.DeleteLastAddedClusterNetwork(); err != nil {
					log.Printf("%s Build '%s' is Failed and error in deleting last network entry '%s' from db '%v'\n", deploymentType, cluster.Name, cluster.BuildID, err)
				}
			}
			continue
		case types.StatusTypeSucceeded:
			log.Printf("%s Build '%s' name '%s' is Succeeded", deploymentType, cluster.BuildID, cluster.Name)
			if err := cs.clusterRepository.UpdateClusterStatus(cluster.UUID.String(), successStatus, ""); err != nil {
				log.Printf("%s Build '%s' is Succeeded but error in updating success status '%s' from aws '%v'\n", deploymentType, cluster.Name, cluster.BuildID, err)
			}
			continue
		default:
			log.Printf("Build status for '%s' with id '%s' is unknown '%s'. Please check!\n", cluster.Name, cluster.BuildID, buildStatus)
		}
	}
}

func getClusterUIStatus(status string) string {
	for key, UiStatus := range ClusterUIStatusMap {
		if utils.Contains(UiStatus, status) {
			return key
		}
	}
	return ""
}
