package service

import (
	"fmt"
	"log"
	"saas-management/common"
	"saas-management/config"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	"saas-management/repository"
	"saas-management/utils"
	"strings"

	"github.com/gin-gonic/gin"
)

type customerService struct {
	custRepo     repository.CustomerRepository
	keycloakRepo repository.KeycloakRepository
	config       config.Configuration
}

type CustomerService interface {
	SaveCustomer(ctx *gin.Context, apiReq *request.CustomerDetail, adminEmail string) (*response.CreateCustomerResponse, *models.ErrorResponse)
	GetCustomerByID(ctx *gin.Context, customerID string) (*response.GetCustomerResponse, *models.ErrorResponse)
	GetCustomerList(ctx *gin.Context, cl *request.CustomerList) (*response.CustomerListResponse, *models.ErrorResponse)
	GetCustomerNameList(ctx *gin.Context, cl *request.CustomerNameList) (*response.CustomerNameListResponse, *models.ErrorResponse)
	ExportCustomerList(ctx *gin.Context, cl *request.CustomerList) *models.ErrorResponse
	ChangeCustomerStatus(ctx *gin.Context, cl *request.CustomerStatusChangeRequest) (*response.CustomerGenericResponse, *models.ErrorResponse)
	DeleteCustomer(ctx *gin.Context, id string) (*response.CustomerGenericResponse, *models.ErrorResponse)
}

func NewCustomerService(cusRepo repository.CustomerRepository,
	keycloakRepo repository.KeycloakRepository, config config.Configuration) CustomerService {
	return &customerService{
		custRepo:     cusRepo,
		keycloakRepo: keycloakRepo,
		config:       config,
	}
}

func (cs *customerService) SaveCustomer(ctx *gin.Context, apiReq *request.CustomerDetail, adminEmail string) (*response.CreateCustomerResponse, *models.ErrorResponse) {
	if err := utils.CountryIndustryValidation(ctx, &cs.config, apiReq.Country, apiReq.Industry); err != nil {
		return &response.CreateCustomerResponse{Message: "Customer creation failed!"}, err
	}

	id, err := cs.custRepo.CreateCustomer(apiReq, adminEmail)
	if err != nil {
		return &response.CreateCustomerResponse{Message: "Customer creation failed!"}, err
	}

	return &response.CreateCustomerResponse{Message: fmt.Sprintf("Customer created with id '%s'", id)}, nil
}

func (cs *customerService) GetCustomerByID(ctx *gin.Context, customerID string) (*response.GetCustomerResponse, *models.ErrorResponse) {
	customer, err := cs.custRepo.GetCustomerDetail(customerID)
	if err != nil {
		err1 := common.ErrorCustomerNotFound
		return nil, &err1
	}

	resp := &response.GetCustomerResponse{
		ID:             customer.UUID.String(),
		Name:           customer.Name,
		CreatedAt:      customer.CreatedAt,
		CreatedBy:      customer.CreatedBy,
		Industry:       customer.Industry,
		Country:        customer.Country,
		BusinessNumber: customer.BusinessNumber,
		Description:    customer.Description,
		Address:        customer.Address,
		ContactEmail:   customer.ContactEmail,
		UpdatedAt:      customer.UpdatedAt,
		UpdatedBy:      customer.UpdatedBy,
	}
	return resp, nil
}

func (cs *customerService) GetCustomerList(ctx *gin.Context, cl *request.CustomerList) (*response.CustomerListResponse, *models.ErrorResponse) {
	// Update pagination number of records to 10
	if cl.NumberRecords == 0 {
		cl.NumberRecords = 10
	}

	if cl.Get == "All" {
		cl.NumberRecords = 1000000
	}

	// Get customer list
	list, totalResult, listErr := cs.custRepo.GetCustomerList(cl)
	if listErr != nil || totalResult == -1 {
		log.Printf("Error while fetching customerList from db")
		return nil, &common.ErrorDBFailed
	}

	customerList := []response.GetCustomerResponse{}
	for _, v := range list {
		resp := response.GetCustomerResponse{
			ID:             v.UUID.String(),
			Name:           v.Name,
			CreatedAt:      v.CreatedAt,
			CreatedBy:      v.CreatedBy,
			Industry:       v.Industry,
			Country:        v.Country,
			BusinessNumber: v.BusinessNumber,
			Description:    v.Description,
			Address:        v.Address,
			ContactEmail:   v.ContactEmail,
			UpdatedAt:      v.UpdatedAt,
			UpdatedBy:      v.UpdatedBy,
		}
		customerList = append(customerList, resp)
	}

	countries, err := cs.custRepo.GetUniqueCountries()
	if err != nil {
		log.Printf("Error while fetching countries from db")
		return nil, &common.ErrorDBFailed

	}
	industries, err := cs.custRepo.GetOrgUniqueIndustries()
	if err != nil {
		log.Printf("Error while fetching industries from db")
		return nil, &common.ErrorDBFailed

	}

	resp := &response.CustomerListResponse{Data: customerList,
		TotalRecord: totalResult,
		FilterCriterias: response.CustomerFilterCriterias{
			Countries:  countries,
			Industries: industries,
		},
	}

	return resp, nil
}

func (cs *customerService) GetCustomerNameList(ctx *gin.Context, cl *request.CustomerNameList) (*response.CustomerNameListResponse, *models.ErrorResponse) {
	// Update pagination number of records to 10
	if cl.NumberRecords == 0 {
		cl.NumberRecords = 10
	}

	if cl.Get == "All" {
		cl.NumberRecords = 1000000
	}

	// Get customer list
	list, totalResult, listErr := cs.custRepo.GetCustomerNameList(cl)
	if listErr != nil || totalResult == -1 {
		log.Printf("Error while fetching customerList from db")
		return nil, &common.ErrorDBFailed
	}

	customerList := []response.GetCustomerNameResponse{}
	for _, v := range list {
		resp := response.GetCustomerNameResponse{
			ID:   v.UUID.String(),
			Name: v.Name,
		}
		customerList = append(customerList, resp)
	}

	resp := &response.CustomerNameListResponse{Data: customerList}

	return resp, nil
}

func (cs *customerService) ExportCustomerList(ctx *gin.Context, cl *request.CustomerList) *models.ErrorResponse {
	// Update pagination number of records to 10
	if cl.NumberRecords == 0 {
		cl.NumberRecords = 10
	}

	if cl.Get == "All" {
		cl.NumberRecords = 1000000
	}

	// Get customer list
	list, totalResult, listErr := cs.custRepo.GetCustomerList(cl)
	if listErr != nil || totalResult == -1 {
		log.Printf("Error while fetching customerList from db")
		return &common.ErrorDBFailed
	}

	// Excel Fucntionality
	headers := utils.GenerateInvitedUserRowHeader(common.CustomerListRowHeaders)

	// Generate csv data
	var csvCustomerData strings.Builder
	csvCustomerData.WriteString(headers)

	var lastIndex = len(list) - 1
	for index, customer := range list {
		// Excel Body
		rowBody := generateCustomerRowBody(customer)
		csvCustomerData.WriteString(rowBody)
		if index != lastIndex {
			csvCustomerData.WriteString("\n")
		}
	}

	// Write the sql result to csv file
	fileName := "customer.csv"
	ctx.Header("Content-Type", "application/octet-stream")
	ctx.Header("Content-Disposition", "attachment; filename="+fileName)
	ctx.Header("Content-Disposition", "inline;filename="+fileName)
	ctx.Header("Content-Transfer-Encoding", "binary")
	ctx.Header("Cache-Control", "no-cache")
	ctx.Writer.WriteString(csvCustomerData.String())

	return nil
}

func (cs *customerService) ChangeCustomerStatus(ctx *gin.Context, cr *request.CustomerStatusChangeRequest) (*response.CustomerGenericResponse, *models.ErrorResponse) {
	_, err := cs.custRepo.GetCustomerDetail(cr.ID)
	if err != nil {
		err1 := common.ErrorCustomerNotFound
		return nil, &err1
	}

	if err := cs.custRepo.UpdateCustomerStatus(cr.ID, cr.Status); err != nil {
		err1 := &common.ErrorDBFailed
		err1.Error.AdditionalData = err.Error()
		return nil, err1
	}

	successMsg := fmt.Sprintf("status changed to '%s' successfully", cr.Status)
	return &response.CustomerGenericResponse{Message: successMsg}, nil
}

func (cs *customerService) DeleteCustomer(ctx *gin.Context, id string) (*response.CustomerGenericResponse, *models.ErrorResponse) {
	customer, err := cs.custRepo.GetCustomerDetail(id)
	if err != nil {
		err1 := common.ErrorCustomerNotFound
		return nil, &err1
	}

	if customer.Status == "Active" {
		err1 := &common.ErrorInvalidRequestInput
		err1.Error.AdditionalData = "Customer with Active status channot be deleted"
		return nil, err1
	}

	if err := cs.custRepo.DeleteCustomer(id); err != nil {
		err1 := &common.ErrorDBFailed
		err1.Error.AdditionalData = err.Error()
		return nil, err1
	}

	msg := fmt.Sprintf("customer with id '%s' is deleted successfully", id)
	return &response.CustomerGenericResponse{Message: msg}, nil
}

// Generate customer list export body
func generateCustomerRowBody(entity models.Customer) string {
	var row strings.Builder
	row.WriteString(`"` + entity.Name + `"` + ",")
	row.WriteString(`"` + entity.BusinessNumber + `"` + ",")
	row.WriteString(`"` + entity.Country + `"` + ",")
	row.WriteString(`"` + entity.Industry + `"` + ",")
	row.WriteString(entity.CreatedAt.Format("02 Jan 2006") + ",")
	row.WriteString(entity.CreatedBy)
	return row.String()
}
