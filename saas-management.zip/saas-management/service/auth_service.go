package service

import (
	"fmt"
	"log"
	"saas-management/common"
	"saas-management/config"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	"saas-management/repository"
	"saas-management/utils"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
)

type authService struct {
	saasUserRepo repository.SaasUserRepository
	keycloakRepo repository.KeycloakRepository
	config       config.Configuration
}

type AuthService interface {
	LoginUser(ctx *gin.Context, userEmail string, requestInput request.UserLoginRequest) (response.LoginUserResponse, *models.ErrorResponse)
	ResendOTP(ctx *gin.Context, userEmail string) *models.ErrorResponse
	ResetEmail(ctx *gin.Context, userEmail string) *models.ErrorResponse
	ResetPassword(ctx *gin.Context, actionToken, pwd string) *models.ErrorResponse
	ChangePassword(ctx *gin.Context, actionToken string, pwdReq *request.ChangePasswordRequest) *models.ErrorResponse
	GenerateAccessToken(ctx *gin.Context, res models.JWT) (response.LoginUserResponse, *models.ErrorResponse)
}

func NewAuthService(saasUser repository.SaasUserRepository,
	keycloakRepo repository.KeycloakRepository, config config.Configuration) AuthService {
	return authService{
		saasUserRepo: saasUser,
		keycloakRepo: keycloakRepo,
		config:       config,
	}
}

func (i authService) ResendOTP(ctx *gin.Context, userEmail string) *models.ErrorResponse {
	realm := i.config.Info.Realm

	// Get admin token for updating keycloak attributes
	client, adminToken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("ResendOTP loginAdmin error. Err:: %s", err.Error())
		return &common.ErrorServiceFailed
	}

	// Create keycloak user object
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(userEmail),
	}

	// Fetch user based on email
	fetchedUser, err := client.GetUsers(ctx, adminToken.AccessToken, realm, keycloakUser)
	if err != nil {
		log.Printf("ResendOTP clientGetUsers err: %s", err.Error())
		return &common.ErrorGeneralFailure
	}

	// User doesn't exist in keycloak
	if len(fetchedUser) == 0 {
		return &common.ErrorUserAuthenticationFailed
	}

	user := *fetchedUser[0]
	if user.Attributes == nil {
		emptyAttributes := make(map[string][]string)
		user.Attributes = &emptyAttributes
	}

	utils.GenerateNewOTP(user, ctx, &i.config, realm)
	return nil
}

func (i authService) ResetEmail(ctx *gin.Context, userEmail string) *models.ErrorResponse {
	realm := i.config.Info.Realm
	portalURL := i.config.Info.PortalURL

	// Get admin token for updating keycloak attributes
	client, adminToken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("ResendOTP loginAdmin error. Err:: %s", err.Error())
		return &common.ErrorGenericFailure
	}

	randomString, err1 := utils.UpdateUserAttributeResetPassword(ctx, client, *adminToken, userEmail, realm)
	if err1 != nil {
		log.Printf("ResendOTP update user attributes error. Err:: %s", err1.Error.Message)
		return &common.ErrorServiceFailed
	}

	// Fetch user based on email
	err1 = utils.SendResetPasswordEmail(&i.config, ctx, randomString, userEmail, portalURL)
	if err1 != nil {
		log.Printf("ResendOTP SendResetPasswordEmail err: %s", err1.Error.Message)
		return &common.ErrorGenericFailure
	}

	return nil
}

func (i authService) ResetPassword(ctx *gin.Context, actionToken, pwd string) *models.ErrorResponse {
	tokenClaims, tokenVerifyErr := utils.VerifySignedActionToken(&i.config, ctx, actionToken)
	if tokenVerifyErr != nil {
		errMsg := fmt.Sprintf("Verify Token error. Err:: %s", tokenVerifyErr.Error())
		errResp := common.ErrorTokenVerificationFailed
		errResp.Error.AdditionalData = errMsg
		return &errResp
	}

	realm := &i.config.Info.Realm
	email, tokenRamdomString := tokenClaims.Email, tokenClaims.StandardClaims.Subject

	// Get admin token for updating keycloak attributes
	client, adminToken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("ResendOTP loginAdmin error. Err:: %s", err.Error())
		return &common.ErrorGenericFailure
	}

	// Fetch user based on email
	err1 := utils.ResetUserPassword(ctx, client, *adminToken, email, *realm, pwd, tokenRamdomString)
	if err1 != nil {
		log.Printf("ResetPassword ResetUserPassword err: %s", err1.Error.Message)
		return &common.ErrorGenericFailure
	}

	return nil
}

func (i authService) ChangePassword(ctx *gin.Context, actionToken string, pwdReq *request.ChangePasswordRequest) *models.ErrorResponse {
	realm := i.config.Info.Realm
	clientID := i.config.Info.ClientId

	// Get admin token for getting and updating
	client, adminToken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("ChangePassword loginAdmin error. Err:: %s", err.Error())
		return &common.ErrorGenericFailure
	}

	// Get keycloak user details
	userInfo, userinfoErr := client.GetUserInfo(ctx, actionToken, realm)
	if err != nil {
		log.Printf("ChangePassword err: %s", userinfoErr.Error())
		return &common.ErrorGenericFailure
	}

	// Login keycloak user for selected realm with user email and current password
	_, err = utils.KeycloakLoginUser(ctx, clientID, realm, &i.config, *userInfo.Email, pwdReq.CurrentPassword)
	if err != nil {
		log.Printf("ChangePassword keycloakLoginUser err: %s", err.Error())
		return &common.ErrorChangePasswordMismatch
	}

	err = client.SetPassword(ctx, adminToken.AccessToken, gocloak.PString(userInfo.Sub), realm, pwdReq.Password, false)
	if err != nil {
		log.Printf("ChangePassword SetPassword err: %s", err.Error())
		return &common.ErrorPasswordChangeFailed
	}

	return nil
}

func (i authService) LoginUser(ctx *gin.Context, userEmail string, requestInput request.UserLoginRequest) (response.LoginUserResponse, *models.ErrorResponse) {
	var resp response.LoginUserResponse
	realm := i.config.Info.Realm
	clientID := i.config.Info.ClientId

	userEntity, ifUserExistsErr := i.keycloakRepo.IfUserExists(userEmail)
	if ifUserExistsErr != nil {
		log.Printf("Error while checking if user exists in DB. Err::%v", ifUserExistsErr)
		return resp, &common.ErrorDBFailed
	}

	if userEntity == nil || len(userEntity.ID) <= 1 {
		log.Printf("User login with non-existent credential: %s\n", userEmail)
		return resp, &common.ErrorUserAuthenticationFailed
	}

	// Get admin token for updating keycloak attributes
	client, adminToken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("loginUser loginAdmin error. Err:: %s", err.Error())
		return resp, &common.ErrorServiceFailed
	}

	// Create keycloak user object
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(userEmail),
	}

	// Fetch user based on email
	fetchedUser, err := client.GetUsers(ctx, adminToken.AccessToken, realm, keycloakUser)
	if err != nil {
		log.Printf("loginUser clientGetUsers err: %s", err.Error())
		return resp, &common.ErrorGeneralFailure
	}

	// User doesn't exist in keycloak
	if len(fetchedUser) == 0 {
		return resp, &common.ErrorUserAuthenticationFailed
	}

	user := *fetchedUser[0]
	if user.Attributes == nil {
		emptyAttributes := make(map[string][]string)
		user.Attributes = &emptyAttributes
	}

	// Login keycloak user for selected realm and requested email
	token, err := utils.KeycloakLoginUser(ctx, clientID, realm, &i.config, userEmail, requestInput.Password)
	if err != nil {
		log.Printf("loginUser keycloakLoginUser err: %s", err.Error())
		return resp, &common.ErrorUserAuthenticationFailed
	}

	if requestInput.OTP == "" {
		utils.GenerateNewOTP(user, ctx, &i.config, realm)
		return resp, &common.ErrorLoginOtpRequired
	}

	//verification of provided otp
	otpInfo := utils.GetUserAttribute(user, "OTP", "")
	if otpInfo[0] != requestInput.OTP {
		return resp, &common.ErrorLoginOtpIncorrect

	}
	previousOtpExpiry, _ := time.Parse(time.RFC3339, otpInfo[1])
	currentTime := time.Now()
	isExpired := previousOtpExpiry.Before(currentTime)
	if isExpired {
		return resp, &common.ErrorLoginOtpExpired
	}

	// Update keycloak user attribute
	loginAt := time.Now().Format(time.RFC3339)
	(*user.Attributes)[common.LAST_LOGIN_ATTRIBUTE] = []string{loginAt}
	err2 := client.UpdateUser(ctx, adminToken.AccessToken, realm, user)
	if err2 != nil {
		log.Printf("LoginUser err: %s", err2.Error())
		return resp, &common.ErrorUserAuthenticationFailed
	}

	resp = response.LoginUserResponse{
		Data: response.LoginResp{
			AccessToken:      token.AccessToken,
			TokenType:        token.TokenType,
			ExpiresIn:        token.ExpiresIn,
			RefreshToken:     token.RefreshToken,
			RefreshExpiresIn: token.RefreshExpiresIn,
		},
	}

	return resp, nil
}

func (i authService) GenerateAccessToken(ctx *gin.Context, res models.JWT) (response.LoginUserResponse, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	claims := &models.Claims{}
	parsedRefreshToken, _ := jwt.ParseWithClaims(res.RefreshToken, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(""), nil
	})
	clientID := parsedRefreshToken.Claims.(*models.Claims).Azp
	token, err := utils.KeycloakGetToken(ctx, clientID, realm, &i.config, res.RefreshToken)
	if err != nil {
		log.Printf("generateAccessToken keycloakGetToken err: %s", err.Error())
		return response.LoginUserResponse{}, &common.ErrorServiceFailed
	}

	resp := response.LoginResp{
		AccessToken:      token.AccessToken,
		ExpiresIn:        token.ExpiresIn,
		RefreshToken:     token.RefreshToken,
		RefreshExpiresIn: token.RefreshExpiresIn,
	}

	return response.LoginUserResponse{
		Data: resp,
	}, nil
}
