package service

import (
	"fmt"
	"log"
	"net/url"
	"saas-management/common"
	"saas-management/config"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	"saas-management/repository"
	"saas-management/utils"
	"strings"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
)

type inviteUserService struct {
	saasUserRepo repository.SaasUserRepository
	keycloakRepo repository.KeycloakRepository
	config       config.Configuration
}

type InviteUserService interface {
	InviteUser(ctx *gin.Context, apiReq request.InviteUserRequest, newUserEmail string, tokenPayload *models.Claims) (response.InviteUserResponse, *models.ErrorResponse)
	AcceptInvite(ctx *gin.Context, actionToken, password string) (response.AcceptInviteResponse, *models.ErrorResponse)
	LoginUser(ctx *gin.Context, userEmail string, requestInput request.UserLoginRequest) (response.LoginUserResponse, *models.ErrorResponse)
	GetUserState(ctx *gin.Context, actionToken string) (response.GetUserStateResponse, *models.ErrorResponse)
	GetProfileRoles(ctx *gin.Context, profileId string) (response.GetUserProfileRolesResp, *models.ErrorResponse)
	GenerateAccessToken(ctx *gin.Context, res models.JWT) (response.LoginUserResponse, *models.ErrorResponse)
	InvitedUserList(ctx *gin.Context, apiReq request.SearchInvitedUser, adminEmail string) (response.UserListRespone, *models.ErrorResponse)
	ExportInvitedUserList(ctx *gin.Context, apiReq request.SearchInvitedUser, adminEmail string) *models.ErrorResponse
	ResendInviteUser(ctx *gin.Context, emailId string, adminEmail string) (response.InviteUserResponse, *models.ErrorResponse)
}

func NewInviteUserService(saasUser repository.SaasUserRepository,
	keycloakRepo repository.KeycloakRepository, config config.Configuration) InviteUserService {
	return inviteUserService{
		saasUserRepo: saasUser,
		keycloakRepo: keycloakRepo,
		config:       config,
	}
}

func (i inviteUserService) InviteUser(ctx *gin.Context, apiReq request.InviteUserRequest, newUserEmail string, tokenPayload *models.Claims) (response.InviteUserResponse, *models.ErrorResponse) {
	// Check email is present in db
	isEmailPresent, emailErr := i.saasUserRepo.IsEmailPresentInDB(newUserEmail)
	if emailErr != nil {
		log.Printf("Error while Getting data from DB. Err:: %s", emailErr.Error())
		return response.InviteUserResponse{}, &common.ErrorDBFailed
	}
	if isEmailPresent {
		errMsg := fmt.Sprintf("User already invited: %s", newUserEmail)
		err := common.ErrorEmailExists
		err.Error.AdditionalData = errMsg
		return response.InviteUserResponse{}, &err
	}
	allowedRoles := ""

	// Comma seperated roles from req input roles
	if utils.Contains(*apiReq.Roles, common.ADMIN_CONSTANT) {

		log.Println("***common.ValidRoles", common.ValidRoles)
		// Admin role should have all roles
		allowedRoles = strings.Join(common.ValidRoles, ",")
	} else {
		allowedRoles = strings.Join(*apiReq.Roles, ",")
	}

	var roleName string
	// Role name for email template selection
	if utils.Contains(*apiReq.Roles, common.ADMIN_CONSTANT) {
		roleName = common.AdminRole
	} else if utils.Contains(*apiReq.Roles, common.INFRA_CONSTANT) && utils.Contains(*apiReq.Roles, common.CUSTOMER_CONSTANT) {
		roleName = "both"
	} else if utils.Contains(*apiReq.Roles, common.INFRA_CONSTANT) {
		roleName = common.InfraManagerRole
	} else if utils.Contains(*apiReq.Roles, common.CUSTOMER_CONSTANT) {
		roleName = common.CustomerManagerRole
	}

	// Add new user details in db
	newUserData := models.SaasUserProfile{}
	newUserData.Email = newUserEmail
	newUserData.UserInviteDate = time.Now()
	newUserData.AllowedRoles = allowedRoles
	newUserData.State = common.InvitedState
	newUserData.Remark = apiReq.Remark
	newUserData.CreatedBy = tokenPayload.Email
	newUserData.LastUpdatedBy = tokenPayload.Email

	createErr := i.saasUserRepo.SaveSaasUser(newUserData)
	if createErr != nil {
		log.Printf("Error while Adding New Saas User to the DB. Err:: %s", createErr.Error())
		return response.InviteUserResponse{}, &common.ErrorDBFailed
	}

	// Send email with invitation link
	if err := sendInvitationEmailSaasUsers(ctx, i.config, newUserEmail, tokenPayload.Email, roleName); err != nil {
		// log.Printf("Send Inviation Email err: %s", err.Error())
		return response.InviteUserResponse{}, &common.ErrorSendNotificationFailed
	}

	return response.InviteUserResponse{Status: "Successfully sent the invitation"}, nil
}

func (i inviteUserService) AcceptInvite(ctx *gin.Context, actionToken, password string) (response.AcceptInviteResponse, *models.ErrorResponse) {
	var resp response.AcceptInviteResponse
	email, tokenErr := i.verifyToken(ctx, actionToken)
	if tokenErr != nil {
		return resp, tokenErr
	}

	realm := i.config.Info.Realm
	client, admintoken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("AcceptInvite loginAdmin error. Err:: %s", err.Error())
		return resp, &common.ErrorServiceFailed
	}

	// Add user to keycloak
	userId, addUserErr := i.addNewKeycloakUser(ctx, client, admintoken, email, realm, password)
	if addUserErr != nil {
		log.Printf("Error occured while creating a new user in keycloak: %s", email)
		return resp, addUserErr
	}

	log.Printf("New user %v created in %v organization.Keycloak UserID %v", email, realm, userId)

	resp.Status = "password updated successfully"
	return resp, nil
}

// Add a User to keycloak
func (i inviteUserService) addNewKeycloakUser(ctx *gin.Context, client *gocloak.GoCloak, adminToken *gocloak.JWT, email string, realm string, password string) (string, *models.ErrorResponse) {
	var keycloakUserId string
	saasUserProfile := models.SaasUserProfile{}

	// Get user details from db (user_invitation)
	userDetailsErr := i.saasUserRepo.GetUserDetailsFromDB(email, &saasUserProfile)
	if userDetailsErr != nil {
		log.Printf("GetUserDetailsFromDB error. Err:: %s", userDetailsErr.Error())
		return keycloakUserId, &common.ErrorDBFailed
	}

	// Capitalize or sentence casing for user roles
	roles := utils.CapitalizeWords(saasUserProfile.AllowedRoles)

	// All roles comma seperated
	allRoles := strings.Split(roles, ",")

	// Credentials to be set, passed by user
	var credentials = []gocloak.CredentialRepresentation{
		{
			Type:      gocloak.StringP("password"),
			Temporary: gocloak.BoolP(false),
			Value:     gocloak.StringP(password),
		},
	}

	// Add user db details to keycloak attributes
	attributes := map[string][]string{
		common.INVITATION_ACCEPTED_ON: {time.Now().Format(time.RFC3339)},
		common.CREATED_BY:             {saasUserProfile.CreatedBy},
		common.CREATED_DATE:           {saasUserProfile.CreatedDate.Format(time.RFC3339)},
		common.UPDATED_BY:             {saasUserProfile.LastUpdatedBy},
		common.UPDATE_DATE:            {time.Now().Format(time.RFC3339)},
		common.STATE:                  {common.AcceptedState},
	}

	// Configure keycloak related properties
	keycloakUser := gocloak.User{
		Email:           gocloak.StringP(email),
		Enabled:         gocloak.BoolP(true),
		Username:        gocloak.StringP(email),
		EmailVerified:   gocloak.BoolP(true),
		RequiredActions: &[]string{""},
		Credentials:     &credentials,
		Attributes:      &attributes,
	}

	// Add new user to keycloak
	keycloakUserId, createUserError := client.CreateUser(ctx, adminToken.AccessToken, realm, keycloakUser)
	if createUserError != nil {
		log.Printf("Create User err: %s", createUserError.Error())
		return keycloakUserId, &common.ErrorCreateUserFailed
	}

	// Validate user by adding validated realm role
	keycloakRealmRoleAddErr := utils.AddRealmRolesToInvitedUser(ctx, client, adminToken.AccessToken, realm, keycloakUserId, allRoles)
	if keycloakRealmRoleAddErr != nil {
		log.Printf("keycloak realm role add to user err: %s", keycloakRealmRoleAddErr.Error.Message)
		return keycloakUserId, keycloakRealmRoleAddErr
	}

	// Update user table state as Active, user_accepted time and profile Id as keycloak user ID
	saasUserProfile.State = common.AcceptedState
	saasUserProfile.UserAcceptDate = time.Now()
	saasUserProfile.LastUpdatedDate = time.Now()
	saasUserProfile.ProfileId = keycloakUserId

	updateErr := i.saasUserRepo.UpdateSaasUserState(email, saasUserProfile)
	if updateErr != nil {
		log.Printf("Error while updating user in db user err: %s", updateErr.Error())
		return keycloakUserId, &common.ErrorDBFailed
	}

	// return newly created user ID from keycloak
	return keycloakUserId, nil
}

func (i inviteUserService) verifyToken(ctx *gin.Context, actionToken string) (string, *models.ErrorResponse) {
	// Get token claims from action token
	var email string
	tokenClaims, tokenVerifyErr := utils.VerifySignedActionToken(&i.config, ctx, actionToken)
	if tokenVerifyErr != nil {
		errMsg := fmt.Sprintf("Verify Token error. Err:: %s", tokenVerifyErr.Error())
		errResp := common.ErrorTokenVerificationFailed
		errResp.Error.AdditionalData = errMsg
		return email, &errResp
	}

	// Check token is generated for invite saas user
	if tokenClaims.Subject != common.InviteSaasUser {
		errMsg := "invalid token"
		errResp := common.ErrorTokenVerificationFailed
		errResp.Error.AdditionalData = errMsg
		return email, &errResp
	}
	// Get email from token
	email = tokenClaims.Email
	return email, nil
}

func (i inviteUserService) LoginUser(ctx *gin.Context, userEmail string, requestInput request.UserLoginRequest) (response.LoginUserResponse, *models.ErrorResponse) {
	var resp response.LoginUserResponse
	realm := i.config.Info.Realm
	clientID := i.config.Info.ClientId

	userEntity, ifUserExistsErr := i.keycloakRepo.IfUserExists(userEmail)
	if ifUserExistsErr != nil {
		log.Printf("Error while checking if user exists in DB. Err::%v", ifUserExistsErr)
		return resp, &common.ErrorDBFailed
	}

	if userEntity == nil || len(userEntity.ID) <= 1 {
		log.Printf("User login with non-existent credential: %s\n", userEmail)
		return resp, &common.ErrorUserAuthenticationFailed
	}

	// Get admin token for updating keycloak attributes
	client, adminToken, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("loginUser loginAdmin error. Err:: %s", err.Error())
		return resp, &common.ErrorServiceFailed
	}

	// Create keycloak user object
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(userEmail),
	}

	// Fetch user based on email
	fetchedUser, err := client.GetUsers(ctx, adminToken.AccessToken, realm, keycloakUser)
	if err != nil {
		log.Printf("loginUser clientGetUsers err: %s", err.Error())
		return resp, &common.ErrorGeneralFailure
	}

	// User doesn't exist in keycloak
	if len(fetchedUser) == 0 {
		return resp, &common.ErrorUserAuthenticationFailed
	}

	user := *fetchedUser[0]
	if user.Attributes == nil {
		emptyAttributes := make(map[string][]string)
		user.Attributes = &emptyAttributes
	}

	// Login keycloak user for selected realm and requested email
	token, err := utils.KeycloakLoginUser(ctx, clientID, realm, &i.config, userEmail, requestInput.Password)
	if err != nil {
		log.Printf("loginUser keycloakLoginUser err: %s", err.Error())
		return resp, &common.ErrorUserAuthenticationFailed
	}

	// Update keycloak user attribute
	loginAt := time.Now().Format(time.RFC3339)
	(*user.Attributes)[common.LAST_LOGIN_ATTRIBUTE] = []string{loginAt}
	err2 := client.UpdateUser(ctx, adminToken.AccessToken, realm, user)
	if err2 != nil {
		log.Printf("LoginUser err: %s", err2.Error())
		return resp, &common.ErrorUserAuthenticationFailed
	}

	resp = response.LoginUserResponse{
		Data: response.LoginResp{
			AccessToken:      token.AccessToken,
			TokenType:        token.TokenType,
			ExpiresIn:        token.ExpiresIn,
			RefreshToken:     token.RefreshToken,
			RefreshExpiresIn: token.RefreshExpiresIn,
		},
	}

	return resp, nil
}

func (i inviteUserService) GetUserState(ctx *gin.Context, actionToken string) (response.GetUserStateResponse, *models.ErrorResponse) {
	var getUserStateResponse response.GetUserStateResponse
	var errMsg string

	tokenClaims, tokenError := utils.VerifySignedActionToken(&i.config, ctx, actionToken)
	if tokenError != nil {
		jwtError, hasJwtError := tokenError.(*jwt.ValidationError)

		if hasJwtError && jwtError.Errors == jwt.ValidationErrorExpired {
			errMsg = fmt.Sprint(jwtError.Errors)
		} else {
			errMsg = fmt.Sprintf("Token verification error : %s", tokenError.Error())
		}
		common.ErrorTokenVerificationFailed.Error.AdditionalData = errMsg

		return getUserStateResponse, &common.ErrorTokenVerificationFailed
	}

	getUserDetailsErr := i.saasUserRepo.GetUserDetailsFromDB(tokenClaims.Email, &getUserStateResponse.Data)
	if getUserDetailsErr != nil || getUserStateResponse.Data.State == "" {
		log.Printf("Org user details not found: %s", tokenClaims.Email)
		return getUserStateResponse, &common.ErrorUserNotFound
	}

	return getUserStateResponse, nil
}

func (i inviteUserService) GetProfileRoles(ctx *gin.Context, profileId string) (response.GetUserProfileRolesResp, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, &i.config)
	if err != nil {
		log.Printf("GetProfileRoles loginAdmin error. Err:: %s", err.Error())
		return response.GetUserProfileRolesResp{}, &common.ErrorServiceFailed
	}

	// Get realm roles of keycloak user
	userRealmRoles, realmRoleErr := client.GetRealmRolesByUserID(ctx, token.AccessToken, realm, profileId)
	if realmRoleErr != nil {
		errMsg := realmRoleErr.Error()
		err := common.ErrorEmailExists
		err.Error.AdditionalData = errMsg
		return response.GetUserProfileRolesResp{}, &err
	}

	return response.GetUserProfileRolesResp{
		Data: response.UserProfileRolesResponse{
			Roles: userRealmRoles,
		},
	}, nil
}

func (i inviteUserService) GenerateAccessToken(ctx *gin.Context, res models.JWT) (response.LoginUserResponse, *models.ErrorResponse) {
	realm := i.config.Info.Realm
	claims := &models.Claims{}
	parsedRefreshToken, _ := jwt.ParseWithClaims(res.RefreshToken, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(""), nil
	})
	clientID := parsedRefreshToken.Claims.(*models.Claims).Azp
	token, err := utils.KeycloakGetToken(ctx, clientID, realm, &i.config, res.RefreshToken)
	if err != nil {
		log.Printf("generateAccessToken keycloakGetToken err: %s", err.Error())
		return response.LoginUserResponse{}, &common.ErrorServiceFailed
	}

	resp := response.LoginResp{
		AccessToken:      token.AccessToken,
		ExpiresIn:        token.ExpiresIn,
		RefreshToken:     token.RefreshToken,
		RefreshExpiresIn: token.RefreshExpiresIn,
	}

	return response.LoginUserResponse{
		Data: resp,
	}, nil
}

func sendInvitationEmail(c *gin.Context, config config.Configuration, email string, adminUserEmail string, orgName string) error {
	// Generate signed action token
	actionToken, tokenError := utils.GenerateSignedAccessToken(config, common.InviteSaasUser, email)
	if tokenError != nil {
		log.Printf("Generate Token err: %s", tokenError.Error())
		return tokenError
	}

	// Generate a invitation link to attach in email
	invitationLink := config.Info.PortalURL + "/accept-invite?actiontoken=" + actionToken

	// Generate parameter for sending a mail
	sendEmailURL, err := url.Parse(config.Info.NotificationURL + "/send/mail/accept_invitation/" + url.PathEscape(email) + "?adminUser=" + adminUserEmail + "&orgName=" + orgName + "&link=" + invitationLink)
	if err != nil {
		log.Printf("Encode link err: %s", err.Error())
		return err
	}

	// Call notification service to send email
	sendInvitationEmailErr := utils.SendEmailRequest(sendEmailURL)
	if sendInvitationEmailErr != nil {
		log.Printf("Send invitation email err: %s", sendInvitationEmailErr.Error())
		return sendInvitationEmailErr
	}
	return nil
}

// Invitation email for saas users
func sendInvitationEmailSaasUsers(c *gin.Context, config config.Configuration, email string, adminUserEmail string, roleName string) error {
	var notificationTemplate string
	// Generate signed action token
	actionToken, tokenError := utils.GenerateSignedAccessToken(config, common.InviteSaasUser, email)
	if tokenError != nil {
		log.Printf("Generate Token err: %s", tokenError.Error())
		return tokenError
	}

	// Generate a invitation link to attach in email
	invitationLink := config.Info.PortalURL + "/accept-invite?actiontoken=" + actionToken

	// Role based email template
	if strings.EqualFold(roleName, common.AdminRole) {
		notificationTemplate = "invitation_saas_admin"
	} else if strings.EqualFold(roleName, common.InfraManagerRole) {
		notificationTemplate = "invitation_saas_infra"
	} else if strings.EqualFold(roleName, common.CustomerManagerRole) {
		notificationTemplate = "invitation_saas_customer"
	} else {
		notificationTemplate = "invitation_saas_infra_customer"
	}

	// Generate parameter for sending a mail
	sendEmailURL, err := url.Parse(config.Info.NotificationURL + "/send/mail/" + notificationTemplate + "/" + url.PathEscape(email) + "?adminUser=" + adminUserEmail + "&link=" + invitationLink)
	if err != nil {
		log.Printf("Encode link err: %s", err.Error())
		return err
	}

	// Call notification service to send email
	sendInvitationEmailErr := utils.SendEmailRequest(sendEmailURL)
	if sendInvitationEmailErr != nil {
		log.Printf("Send invitation email err: %s", sendInvitationEmailErr.Error())
		return sendInvitationEmailErr
	}
	return nil
}

func (i inviteUserService) InvitedUserList(ctx *gin.Context, apiReq request.SearchInvitedUser, adminEmail string) (response.UserListRespone, *models.ErrorResponse) {
	// Update pagination number of records to 10
	if apiReq.NumberRecords == 0 {
		apiReq.NumberRecords = 10
	}

	if apiReq.Get == "All" {
		apiReq.NumberRecords = 1000000
	}

	// Get user list
	userList, totalResult, userListErr := i.saasUserRepo.InvitedUserListFromDB(apiReq, adminEmail)
	if userListErr != nil || totalResult == -1 {
		log.Printf("Error while fetching userlist from db")
		return response.UserListRespone{}, &common.ErrorDBFailed
	}

	// Get valid role list
	roleList := common.ValidRoleList

	resp := response.UserListRespone{
		Data:        userList,
		TotalRecord: totalResult,
		FilterCriterias: response.UserFilterCriterias{
			Roles: roleList,
		},
	}

	return resp, nil
}

func (i inviteUserService) ExportInvitedUserList(ctx *gin.Context, apiReq request.SearchInvitedUser, adminEmail string) *models.ErrorResponse {
	// Update pagination number of records to 10
	if apiReq.NumberRecords == 0 {
		apiReq.NumberRecords = 10
	}

	if apiReq.Get == "All" {
		apiReq.NumberRecords = 1000000
	}

	// Get user list
	userList, totalResult, userListErr := i.saasUserRepo.InvitedUserListFromDB(apiReq, adminEmail)
	if userListErr != nil || totalResult == -1 {
		log.Printf("Error while fetching userlist from db")
		return &common.ErrorDBFailed
	}

	// Excel Fucntionality
	headers := utils.GenerateInvitedUserRowHeader(common.UserListRowHeaders)

	// Generate csv data
	var csvUserData strings.Builder
	csvUserData.WriteString(headers)

	var lastIndex = len(userList) - 1
	for index, userEntity := range userList {

		// Excel Body
		rowBody := utils.GenerateInvitedUserRowBody(userEntity)

		csvUserData.WriteString(rowBody)
		if index != lastIndex {
			csvUserData.WriteString("\n")
		}
	}

	// Write the sql result to csv file
	fileName := "saas_invited_user.csv"
	ctx.Header("Content-Type", "application/octet-stream")
	ctx.Header("Content-Disposition", "attachment; filename="+fileName)
	ctx.Header("Content-Disposition", "inline;filename="+fileName)
	ctx.Header("Content-Transfer-Encoding", "binary")
	ctx.Header("Cache-Control", "no-cache")
	ctx.Writer.WriteString(csvUserData.String())

	return nil
}

func (i inviteUserService) ResendInviteUser(ctx *gin.Context, emailId string, adminEmail string) (response.InviteUserResponse, *models.ErrorResponse) {

	// Initialized varaibales
	userProfile := models.SaasUserProfile{}

	// normalize email input
	newUserEmail, newUserEmailErr := utils.NormalizeEmail(emailId)
	if newUserEmailErr != nil {
		log.Printf("ResendInviteUser mailParseAddress error. Err:: %s", newUserEmailErr.Error())
		return response.InviteUserResponse{}, &common.ErrorInvalidEmail
	}

	// Check the validation of user email
	if !utils.IsEmailValid(newUserEmail) {
		log.Printf("invalid email address: %s", newUserEmail)
		return response.InviteUserResponse{}, &common.ErrorInvalidEmail
	}

	// Get user details from db (saas_user_invitation)
	userProfileError := i.saasUserRepo.GetUserDetailsFromDB(newUserEmail, &userProfile)
	// Check for any error or db user details with empty state
	if userProfileError != nil || userProfile.State == "" {
		log.Printf("User not found %s", newUserEmail)
		return response.InviteUserResponse{}, &common.ErrorUserNotFound
	}

	if userProfile.State == common.AcceptedState {
		log.Printf("User has already accepted the invitation %s", newUserEmail)
		return response.InviteUserResponse{}, &common.ErrorInvitationAlreadyAccepted
	}

	var roleName string
	userRoles := strings.Split(userProfile.AllowedRoles, ",")
	// Role name for email template selection
	if utils.Contains(userRoles, common.ADMIN_CONSTANT) {
		roleName = common.AdminRole
	} else if utils.Contains(userRoles, common.INFRA_CONSTANT) && utils.Contains(userRoles, common.CUSTOMER_CONSTANT) {
		roleName = "both"
	} else if utils.Contains(userRoles, common.INFRA_CONSTANT) {
		roleName = common.InfraManagerRole
	} else if utils.Contains(userRoles, common.CUSTOMER_CONSTANT) {
		roleName = common.CustomerManagerRole
	}

	// Send email with invitation link
	if err := sendInvitationEmailSaasUsers(ctx, i.config, newUserEmail, adminEmail, roleName); err != nil {
		return response.InviteUserResponse{}, &common.ErrorSendNotificationFailed
	}

	return response.InviteUserResponse{Status: "Successfully sent the invitation"}, nil
}
