package controller

import (
	"fmt"
	"log"
	"net/http"
	"saas-management/common"
	"saas-management/helper"
	"saas-management/models"
	"saas-management/models/request"
	pkg "saas-management/pkg/common"
	"saas-management/service"
	"saas-management/utils"

	"github.com/gin-gonic/gin"
)

type InviteUserController struct {
	inviteUserService service.InviteUserService
}

func NewInviteUserController(inviteUserService service.InviteUserService) InviteUserController {
	return InviteUserController{
		inviteUserService: inviteUserService,
	}
}

//	 InviteUser		godoc
//		@Summary		Invite Saas User
//		@Description	Save details of invited user in Db.
//		@Param			tags	body	request.InviteUserRequest	true	"Create user"
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.InviteUserResponse{}
//		@Router			/api/v1/saas/invite-user [POST]
func (i InviteUserController) InviteUser(ctx *gin.Context) {
	inviteUserReq := request.InviteUserRequest{}
	if err := ctx.ShouldBindJSON(&inviteUserReq); err != nil {
		errMsg := fmt.Sprintf("InviteUser Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	newUserEmail, validationErr := validateRolesAndEmailInRequest(ctx, inviteUserReq)
	if validationErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, *validationErr, &validationErr.Error.Message)
		return
	}

	// Get admin token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.inviteUserService.InviteUser(ctx, inviteUserReq, newUserEmail, tokenPayload)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 AcceptInvite	godoc
//		@Summary		Accept Invite
//		@Description	Save details of invited user in Keycloak.
//		@Param			tags	body	request.AcceptInviteRequest	true	"Create user in keycloak"
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.AcceptInviteResponse{}
//		@Router			/api/v1/saas/accept-invite [POST]
func (i InviteUserController) AcceptInvite(ctx *gin.Context) {
	// Get auth token present in header
	authHeader := ctx.GetHeader("Authorization")
	if authHeader == "" {
		errMsg := "authorization token not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	actionToken := authHeader[len("Bearer "):]

	var requestInput request.AcceptInviteRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("AcceptInvite shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	err := pkg.ValidatePassword(requestInput.Password)
	if err != nil {
		errMsg := err.Error()
		errResp := common.ErrorPasswordValidationFailed
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorPasswordValidationFailed, &errMsg)
		return
	}

	resp, serviceErr := i.inviteUserService.AcceptInvite(ctx, actionToken, requestInput.Password)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, resp)

}

//	 GetUserState	godoc
//		@Summary		Get Invited User State
//		@Description	Get Invited User State
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	models.SaasUserProfile
//		@Router			/api/v1/saas/invited/user-state [GET]
func (i InviteUserController) GetUserState(ctx *gin.Context) {
	authHeader := ctx.GetHeader("Authorization")
	if authHeader == "" {
		errMsg := "authorization token not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	actionToken := authHeader[len("Bearer "):]

	serviceResp, serviceErr := i.inviteUserService.GetUserState(ctx, actionToken)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 InviteUser		godoc
//		@Summary		Invited Userlist
//		@Description	Get invited user list.
//		@Param			tags	queryparams
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.InvitedUserlistResponse{}
//		@Router			/api/v1/saas/user-list [GET]
func (i InviteUserController) InvitedUserList(ctx *gin.Context) {
	searchUserReq := request.SearchInvitedUser{}
	if err := ctx.ShouldBindJSON(&searchUserReq); err != nil {
		errMsg := fmt.Sprintf("InvitedUserList Method ShouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.inviteUserService.InvitedUserList(ctx, searchUserReq, tokenPayload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 InviteUser		godoc
//		@Summary		Export Invited Userlist
//		@Description	Export invited user list.
//		@Param			tags	queryparams
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.InvitedUserlistResponse{}
//		@Router			/api/v1/saas/user-list/export [GET]
func (i InviteUserController) ExportInvitedUserList(ctx *gin.Context) {
	searchUserReq := request.SearchInvitedUser{}
	if err := ctx.ShouldBindJSON(&searchUserReq); err != nil {
		errMsg := fmt.Sprintf("ExportInvitedUserList Method ShouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceErr := i.inviteUserService.ExportInvitedUserList(ctx, searchUserReq, tokenPayload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	return
}

//	 InviteUser		godoc
//		@Summary		Resend Invitation
//		@Description	Resend invite to user.
//		@Param			tags	email
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.InvitedUserlistResponse{}
//		@Router			/api/v1/saas/resend-invite/":emailId" [GET]
func (i InviteUserController) ResendInviteUser(ctx *gin.Context) {

	emailId := ctx.Param("emailId")
	if emailId == "" {
		errMsg := "emailId not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.inviteUserService.ResendInviteUser(ctx, emailId, tokenPayload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

// Method to validate saas invite user' request input
func validateRolesAndEmailInRequest(ctx *gin.Context, inviteUserReq request.InviteUserRequest) (newUserEmail string, errResponse *models.ErrorResponse) {
	//remove duplicates roles from all roles
	*inviteUserReq.Roles = utils.RemoveDuplicate(*inviteUserReq.Roles)

	// Validate input roles
	if inviteUserReq.Roles != nil && len(*inviteUserReq.Roles) > 0 {
		for _, inputRole := range *inviteUserReq.Roles {
			if !utils.IsValidSaasUserRole(inputRole) {
				errMsg := "role is not a valid role"
				errResponse = &common.ErrorInvalidRequestInput
				errResponse.Error.AdditionalData = map[string]string{"roles": errMsg}
				break
			}
		}
	}

	// normalize email input
	newUserEmail, newUserEmailErr := utils.NormalizeEmail(inviteUserReq.Email)
	if newUserEmailErr != nil {
		log.Printf("InviteUser mailParseAddress error. Err:: %s", newUserEmailErr.Error())
		errResponse = &common.ErrorInvalidEmail
		return
	}

	// Check the validation of user email
	if !utils.IsEmailValid(newUserEmail) {
		log.Printf("invalid email address: %s", newUserEmail)
		errResponse = &common.ErrorInvalidEmail
		return
	}

	return
}
