package controller

import (
	"net/http"
	"saas-management/common"
	"saas-management/helper"
	"saas-management/service"
	"saas-management/utils"
	"strings"

	"github.com/gin-gonic/gin"
)

type UserController struct {
	userService service.UserService
}

func NewUserController(userService service.UserService) UserController {
	return UserController{
		userService: userService,
	}
}

//	 GetUserProfileRoles	godoc
//		@Summary		Get User Profile Roles
//		@Description	Get User Profile Roles
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.GetUserProfileRolesResp
//		@Router			/api/v1/saas/users/:profileId/roles [GET]
func (i UserController) GetUserProfileRoles(ctx *gin.Context) {
	profileId := ctx.Param("profileId")
	if profileId == "" {
		errMsg := "profileId not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.userService.GetProfileRoles(ctx, profileId)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 GetUserProfileRoles	godoc
//		@Summary		Get User Profile Details
//		@Description	Get User Profile Details
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.GetUserProfileRolesResp
//		@Router			/api/v1/saas/users/:profileId [GET]
func (i UserController) GetUserProfileDetails(ctx *gin.Context) {
	profileId := ctx.Param("profileId")
	if profileId == "" {
		errMsg := "profileId not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.userService.GetUserProfileDetails(ctx, profileId)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 InviteUser		godoc
//		@Summary		Toggle User Role
//		@Description	Toggle User Role
//		@Param			tags	email
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.InvitedUserlistResponse{}
//		@Router			/api/v1/saas/resend-invite/:emailId" [GET]
func (i UserController) UpdateUserRoleStatus(ctx *gin.Context) {

	profileId := ctx.Param("profileId")
	userRole := strings.ToLower(ctx.Param("role"))
	if profileId == "" {
		errMsg := "profileId or role not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.userService.UpdateUserRoleStatus(ctx, profileId, userRole)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 InviteUser		godoc
//		@Summary		Toggle User State
//		@Description	Toggle User State
//		@Param			tags	profileId
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.UpdateUserStatusResp{}
//		@Router			/api/v1/saas/users/update-state/:profileId" [GET]
func (i UserController) UpdateUserStatus(ctx *gin.Context) {

	profileId := ctx.Param("profileId")
	if profileId == "" {
		errMsg := "profileId is not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.userService.UpdateUserStatus(ctx, profileId, tokenPayload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 InviteUser		godoc
//		@Summary		Delete user
//		@Description	Delete user
//		@Param			tags	emailId
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.DeleteUserStatusResp{}
//		@Router			/api/v1/saas/user-list/delete-user/:emailId" [GET]
func (i UserController) DeleteSaasUser(ctx *gin.Context) {

	emailId := ctx.Param("emailId")
	if emailId == "" {
		errMsg := "emailId not present"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := i.userService.DeleteSaasUser(ctx, emailId, tokenPayload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}
