package controller

import (
	"fmt"
	"net/http"
	"saas-management/common"
	"saas-management/helper"
	"saas-management/models/request"
	"saas-management/service"
	"saas-management/utils"
	"strings"

	"github.com/gin-gonic/gin"
)

type CustomerController struct {
	CustomerService service.CustomerService
}

func NewCustomerController(cs service.CustomerService) *CustomerController {
	return &CustomerController{
		CustomerService: cs,
	}
}

func (cc *CustomerController) CreateCustomer(ctx *gin.Context) {
	cr := request.CustomerDetail{}
	if err := ctx.ShouldBindJSON(&cr); err != nil {
		errMsg := fmt.Sprintf("CreateCustomer Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Check the validation of user name
	if !utils.HasSpecialCharactersInStartAndEndOfString(cr.Name) {
		errMsg := fmt.Sprintf("Created Customer Name is invalid")
		errResp := common.ErrorInvalidName
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	cr.Name = strings.Trim(cr.Name, " ")

	// Check the validation of business number
	if !utils.ValidateAlphanumericWithSpaceInput(cr.BusinessNumber) {
		errMsg := fmt.Sprintf("Customer Business Number is invalid")
		errResp := common.ErrorInvalidBusinessNumber
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// normalize email input
	newUserEmail, newUserEmailErr := utils.NormalizeEmail(cr.ContactEmail)
	if newUserEmailErr != nil {
		errMsg := fmt.Sprintf("CreateCustomer mailParseAddress. Err:: %s", newUserEmailErr)
		errResp := common.ErrorInvalidEmail
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Check the validation of user email
	if !utils.IsEmailValid(newUserEmail) {
		errMsg := fmt.Sprintf("Customer Contact Email is invalid")
		errResp := common.ErrorInvalidEmail
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	payload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	cr.ContactEmail = newUserEmail
	serviceResp, serviceErr := cc.CustomerService.SaveCustomer(ctx, &cr, payload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusCreated, serviceResp)
}

func (cc *CustomerController) GetCustomerByID(ctx *gin.Context) {
	customerID := ctx.Param("customerId")
	if customerID == "" {
		errMsg := "GetCustomerByID empty CustomerID error"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.CustomerService.GetCustomerByID(ctx, customerID)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (cc *CustomerController) GetCustomerList(ctx *gin.Context) {
	cl := request.CustomerList{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("GetCustomerList Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.CustomerService.GetCustomerList(ctx, &cl)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (cc *CustomerController) GetCustomerNameList(ctx *gin.Context) {
	cl := request.CustomerNameList{}
	if err := ctx.ShouldBindQuery(&cl); err != nil {
		errMsg := fmt.Sprintf("GetCustomerNameList Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.CustomerService.GetCustomerNameList(ctx, &cl)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (cc *CustomerController) ExportCustomerList(ctx *gin.Context) {
	cl := request.CustomerList{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("ExportCustomerList Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceErr := cc.CustomerService.ExportCustomerList(ctx, &cl)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
}

func (cc *CustomerController) ChangeCustomerStatus(ctx *gin.Context) {
	cr := request.CustomerStatusChangeRequest{}
	if err := ctx.ShouldBindJSON(&cr); err != nil {
		errMsg := fmt.Sprintf("CreateCustomer Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.CustomerService.ChangeCustomerStatus(ctx, &cr)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (cc *CustomerController) DeleteCustomer(ctx *gin.Context) {
	customerID := ctx.Param("customerId")
	if customerID == "" {
		errMsg := "GetCustomerByID empty CustomerID error"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.CustomerService.DeleteCustomer(ctx, customerID)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}
