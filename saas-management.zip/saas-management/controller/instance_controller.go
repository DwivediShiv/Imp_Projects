package controller

import (
	"fmt"
	"net/http"
	"saas-management/common"
	"saas-management/helper"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	"saas-management/service"
	"saas-management/utils"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

type InstanceController struct {
	InstanceService service.InstanceService
}

func NewInstanceController(is service.InstanceService) *InstanceController {
	return &InstanceController{
		InstanceService: is,
	}
}

func (ic *InstanceController) CreateInstance(ctx *gin.Context) {
	// Get admin token payload
	payload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	cr := request.InstanceDetail{}
	if err := ctx.ShouldBindJSON(&cr); err != nil {
		errMsg := fmt.Sprintf("CreateInstance Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	errResp, errMsg := validateSaveInstanceFields(ctx, cr)
	if errMsg != "" {
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := ic.InstanceService.SaveInstance(ctx, &cr, payload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusCreated, serviceResp)
}

func (ic *InstanceController) GetInstanceByID(ctx *gin.Context) {
	instanceID := ctx.Param("instanceId")
	if instanceID == "" {
		errMsg := "GetInstanceByID empty instanceID error"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := ic.InstanceService.GetInstanceByID(ctx, instanceID)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (ic *InstanceController) GetInstanceList(ctx *gin.Context) {
	cl := request.InstanceList{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("GetInstanceList Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := ic.InstanceService.GetInstanceList(ctx, &cl)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (ic *InstanceController) ExportInstanceList(ctx *gin.Context) {
	cl := request.InstanceList{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("ExportInstanceList Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceErr := ic.InstanceService.ExportInstanceList(ctx, &cl)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
}

func (ic *InstanceController) VersionList(ctx *gin.Context) {
	list, serviceErr := ic.InstanceService.GetVersionList()
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, list)
}

func (ic *InstanceController) GetReleaseNote(ctx *gin.Context) {
	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	resp, serviceErr := ic.InstanceService.GetReleaseNote(version)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, resp)
}

func (ic *InstanceController) DeleteInstance(ctx *gin.Context) {
	instanceID := ctx.Param("instanceId")
	if instanceID == "" {
		errMsg := "DeleteInstance empty instanceID error"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceErr := ic.InstanceService.DeleteInstance(ctx, instanceID)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, &response.InstanceGenericResponse{Message: "instance deletion triggered successfully."})
}

func (ic *InstanceController) ActivateInactiveInstance(ctx *gin.Context) {
	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	instanceID := ctx.Param("instanceId")
	if instanceID == "" {
		errMsg := "empty instanceID"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	status := ctx.Param("status")
	if status == "" {
		errMsg := "empty status"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	if status == "Active" || status == "Inactive" {
		serviceErr := ic.InstanceService.ActivateInactivateInstance(ctx, instanceID, status)
		if serviceErr != nil {
			helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
			return
		}
		ctx.JSON(http.StatusOK, &response.InstanceGenericResponse{Message: "instance " + status + " process started"})
		return
	}

	errMsg := "invalid status"
	errResp := common.ErrorInvalidRequestInput
	errResp.Error.AdditionalData = errMsg
	helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
}

func (ic *InstanceController) DeployInstanceVersion(ctx *gin.Context) {
	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	instanceID := ctx.Param("instanceId")
	if instanceID == "" {
		errMsg := "empty instanceID"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := ic.InstanceService.DeployInstanceVersion(ctx, instanceID, version)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, &response.InstanceGenericResponse{Message: "instance version deployment started"})
}

func (ic *InstanceController) DeployInstanceNetwork(ctx *gin.Context) {
	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	cl := request.InstanceNetwork{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("DeployInstanceNetwork Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	instanceID := ctx.Param("instanceId")
	if instanceID == "" {
		errMsg := "empty instanceID"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Check if the field value is a numeric string
	value, err := strconv.Atoi(cl.Decimal)
	if err != nil || value > 99 {
		errMsg := "Decimal is either not numeric or more than 99"
		errResp := common.ErrorInvalidDecimal
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := ic.InstanceService.DeployInstanceNetwork(ctx, &cl, instanceID)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, &response.InstanceGenericResponse{Message: "instance network deployment started"})
}

func validateSaveInstanceFields(ctx *gin.Context, cr request.InstanceDetail) (errResp models.ErrorResponse, errMsg string) {
	// Check the validation of user email
	if !utils.IsAlphanumericWithOptionalHyphenInBetween(cr.Name) {
		errMsg = "Instance Name is invalid"
		errResp = common.ErrorInvalidName
		errResp.Error.AdditionalData = errMsg
		return
	}
	cr.Name = strings.Trim(cr.Name, " ")

	// normalize email input
	newUserEmail, newUserEmailErr := utils.NormalizeEmail(cr.ContactEmail)
	if newUserEmailErr != nil {
		errMsg = "Contact Email is invalid"
		errResp = common.ErrorInvalidEmail
		errResp.Error.AdditionalData = errMsg
		return
	}
	cr.ContactEmail = newUserEmail

	// Check the validation of user email
	if !utils.IsEmailValid(newUserEmail) {
		errMsg = "Contact Email is invalid"
		errResp = common.ErrorInvalidEmail
		errResp.Error.AdditionalData = errMsg
		return
	}

	// Check the validation of domain
	if cr.CustomDomain != "" {
		if !utils.IsValidDomain(cr.CustomDomain, 50) {
			errMsg = "Custom Domain is invalid"
			errResp = common.ErrorInvalidCustomDomain
			errResp.Error.AdditionalData = errMsg
			return
		}
		if cr.CustomEmailDomain == "" {
			errMsg = "Custom Email Domain is required when Custom Domain is provided"
			errResp = common.ErrorInvalidCustomEmailDomain
			errResp.Error.AdditionalData = errMsg
		}
	}

	// Check the validation of domain
	if cr.CustomEmailDomain != "" {
		if !utils.IsValidDomain(cr.CustomEmailDomain, 50) {
			errMsg = "Custom Email Domain is invalid"
			errResp = common.ErrorInvalidCustomEmailDomain
			errResp.Error.AdditionalData = errMsg
			return
		}
		if cr.CustomDomain == "" {
			errMsg = "Custom Domain is required when Custom Email Domain is provided"
			errResp = common.ErrorInvalidCustomDomain
			errResp.Error.AdditionalData = errMsg
			return
		}
	}

	// Check the validation of domain
	if !utils.IsValidAlphanumeric(cr.TokenAddress) {
		errMsg = "Token Address is invalid"
		errResp = common.ErrorInvalidTokenAddress
		errResp.Error.AdditionalData = errMsg
		return
	}

	// Check the validation of domain
	if !utils.IsValidAlphanumeric(cr.TokenSymbol) {
		errMsg = "token Symbol is invalid"
		errResp = common.ErrorInvalidTokenSymbol
		errResp.Error.AdditionalData = errMsg
		return
	}

	// Check if the field value is a numeric string
	value, err := strconv.Atoi(cr.Decimal)
	if err != nil || value > 99 {
		errMsg = "Decimal is either not numeric or more than 99"
		errResp = common.ErrorInvalidDecimal
		errResp.Error.AdditionalData = errMsg
		return
	}

	return
}
