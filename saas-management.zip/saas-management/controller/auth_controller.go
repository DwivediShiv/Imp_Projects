package controller

import (
	"fmt"
	"net/http"
	"saas-management/common"
	"saas-management/helper"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	pkg "saas-management/pkg/common"
	"saas-management/service"
	"saas-management/utils"

	"github.com/gin-gonic/gin"
)

type AuthController struct {
	authService service.AuthService
}

func NewAuthController(authService service.AuthService) AuthController {
	return AuthController{
		authService: authService,
	}
}

//	 GenerateAccessToken		godoc
//		@Summary		Generate Access Token
//		@Description	Generate Access Token
//		@Param			tags	body	models.JWT	true "Generate Token"
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.LoginUserResponse{}
//		@Router			/api/v1/saas/access-token [POST]
func (i AuthController) GenerateAccessToken(ctx *gin.Context) {
	var res models.JWT
	if err := ctx.ShouldBindJSON(&res); err != nil {
		errMsg := fmt.Sprintf("generateAccessToken shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorGeneralFailure
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}
	serviceResp, serviceErr := i.authService.GenerateAccessToken(ctx, res)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 LoginUser		godoc
//		@Summary		Login User
//		@Description	Login User and give token
//		@Param			tags	body	request.UserLoginRequest	true	"Login user"
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.LoginUserResponse{}
//		@Router			/api/v1/saas/login [PUT]
func (i AuthController) LoginUser(ctx *gin.Context) {
	var requestInput request.UserLoginRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("loginUser shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	userEmail, emailErr := utils.NormalizeEmail(requestInput.Email)
	if emailErr != nil {
		errMsg := fmt.Sprintf("LoginUser mailParseAddress error. Err:: %s", emailErr.Error())
		errResp := common.ErrorInvalidEmail
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Check the validation of user email
	if !utils.IsEmailValid(userEmail) {
		errMsg := fmt.Sprintf("invalid email address: %s", userEmail)
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorInvalidEmail, &errMsg)
		return
	}

	serviceResp, serviceErr := i.authService.LoginUser(ctx, userEmail, requestInput)
	if serviceErr != nil {
		if serviceErr != &common.ErrorLoginOtpRequired {
			helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
			return
		}
		ctx.JSON(http.StatusOK, response.LoginUserResponse{OTPRequired: true})
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

//	 ResendOTP		godoc
//		@Summary		Resend OTP
//		@Description	Resend OTP for the user
//		@Param			tags	body	request.ResendOTPRequest
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.GenericResponse{}
//		@Router			/api/v1/saas/resend-otp [POST ]
func (i AuthController) ResendOTP(ctx *gin.Context) {
	var requestInput request.ResendOTPRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("ResendOTP shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	userEmail, emailErr := utils.NormalizeEmail(requestInput.Email)
	if emailErr != nil {
		errMsg := fmt.Sprintf("ResendOTP mailParseAddress error. Err:: %s", emailErr.Error())
		errResp := common.ErrorInvalidEmail
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Check the validation of user email
	if !utils.IsEmailValid(userEmail) {
		errMsg := fmt.Sprintf("invalid email address: %s", userEmail)
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorInvalidEmail, &errMsg)
		return
	}

	serviceErr := i.authService.ResendOTP(ctx, userEmail)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, response.GenericResponse{Status: "success"})
}

func (i AuthController) ResetEmail(ctx *gin.Context) {
	var requestInput request.ResetEmaildRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("ResetEmail shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	userEmail, emailErr := utils.NormalizeEmail(requestInput.Email)
	if emailErr != nil {
		errMsg := fmt.Sprintf("ResetEmail mailParseAddress error. Err:: %s", emailErr.Error())
		errResp := common.ErrorInvalidEmail
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Check the validation of user email
	if !utils.IsEmailValid(userEmail) {
		errMsg := fmt.Sprintf("invalid email address: %s", userEmail)
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorInvalidEmail, &errMsg)
		return
	}

	serviceErr := i.authService.ResetEmail(ctx, userEmail)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, response.GenericResponse{Status: "success"})
}

func (i AuthController) ResetPassword(ctx *gin.Context) {
	var requestInput request.ResetPasswordRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("ResetPassword shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get auth token present in header
	authHeader := ctx.GetHeader("Authorization")
	actionToken := authHeader[len("Bearer "):]

	err := pkg.ValidatePassword(requestInput.Password)
	if err != nil {
		errMsg := err.Error()
		errResp := common.ErrorPasswordValidationFailed
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := i.authService.ResetPassword(ctx, actionToken, requestInput.Password)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, response.GenericResponse{Status: "success"})
}

//	 ChangePassword		godoc
//		@Summary		Change Password
//		@Description	Change password for the user
//		@Param			tags	body	request.ChangePasswordRequest
//		@Produce		application/json
//		@Tags			user
//		@Success		200	{object}	response.GenericResponse{}
//		@Router			/api/v1/saas/change-password [PUT ]
func (i AuthController) ChangePassword(ctx *gin.Context) {
	var requestInput request.ChangePasswordRequest
	if err := ctx.ShouldBindJSON(&requestInput); err != nil {
		errMsg := fmt.Sprintf("ChangePassword shouldBindJSON err: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get auth token present in header
	authHeader := ctx.GetHeader("Authorization")
	actionToken := authHeader[len("Bearer "):]

	err := pkg.ValidatePassword(requestInput.Password)
	if err != nil {
		errMsg := err.Error()
		errResp := common.ErrorPasswordValidationFailed
		helper.ErrorResponse(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := i.authService.ChangePassword(ctx, actionToken, &requestInput)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, response.GenericResponse{Status: "Password changed successfully."})
}
