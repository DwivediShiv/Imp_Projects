package controller

import (
	"fmt"
	"net/http"
	"saas-management/common"
	"saas-management/helper"
	"saas-management/models/request"
	"saas-management/models/response"
	"saas-management/service"
	"saas-management/utils"

	"github.com/gin-gonic/gin"
)

type ClusterController struct {
	ClusterService service.ClusterService
}

func NewClusterController(is service.ClusterService) *ClusterController {
	return &ClusterController{
		ClusterService: is,
	}
}

func (cc *ClusterController) CreateCluster(ctx *gin.Context) {
	// Get admin token payload
	payload, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	cr := request.ClusterDetail{}
	if err := ctx.ShouldBindJSON(&cr); err != nil {
		errMsg := fmt.Sprintf("CreateCluster Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.ClusterService.SaveCluster(ctx, &cr, payload.Email)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusCreated, serviceResp)
}

func (cc *ClusterController) GetClusterByID(ctx *gin.Context) {
	clusterId := ctx.Param("clusterId")
	if clusterId == "" {
		errMsg := "GetClusterByID empty clusterId error"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.ClusterService.GetClusterByID(ctx, clusterId)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (cc *ClusterController) GetClusterList(ctx *gin.Context) {
	cl := request.ClusterList{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("GetClusterList Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceResp, serviceErr := cc.ClusterService.GetClusterList(ctx, &cl)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}

	ctx.JSON(http.StatusOK, serviceResp)
}

func (cc *ClusterController) ExportClusterList(ctx *gin.Context) {
	cl := request.ClusterList{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("ExportClusterList Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceErr := cc.ClusterService.ExportClusterList(ctx, &cl)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
}

func (cc *ClusterController) DeleteCluster(ctx *gin.Context) {
	clusterID := ctx.Param("clusterId")
	if clusterID == "" {
		errMsg := "DeleteCluster empty clusterID error"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	serviceErr := cc.ClusterService.DeleteCluster(ctx, clusterID)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, &response.ClusterGenericResponse{Message: "cluster deletion triggered successfully."})
}

func (cc *ClusterController) DeployClusterVersion(ctx *gin.Context) {
	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	clusterID := ctx.Param("clusterId")
	if clusterID == "" {
		errMsg := "empty clusterID"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	version := ctx.Param("version")
	if version == "" {
		errMsg := "empty version"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := cc.ClusterService.DeployClusterVersion(ctx, clusterID, version)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, &response.ClusterGenericResponse{Message: "cluster version deployment started"})
}

func (cc *ClusterController) DeployClusterNetwork(ctx *gin.Context) {
	// Get admin token payload
	_, tokenErr := utils.GetTokenFromJwtHeader(ctx)
	if tokenErr != nil {
		errMsg := "Invalid/Expired token"
		errResp := common.ErrorTokenVerificationFailed
		helper.ErrorResponse(ctx, http.StatusUnauthorized, errResp, &errMsg)
		return
	}

	cl := request.ClusterNetwork{}
	if err := ctx.ShouldBindJSON(&cl); err != nil {
		errMsg := fmt.Sprintf("DeployClusterNetwork Method shouldBindJSON error. Err:: %s", err.Error())
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = common.GetAdditionalErrorData(err)
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	clusterID := ctx.Param("clusterId")
	if clusterID == "" {
		errMsg := "empty clusterID"
		errResp := common.ErrorInvalidRequestInput
		errResp.Error.AdditionalData = errMsg
		helper.ErrorResponseWithAdditionalData(ctx, http.StatusBadRequest, errResp, &errMsg)
		return
	}

	serviceErr := cc.ClusterService.DeployClusterNetwork(ctx, &cl, clusterID)
	if serviceErr != nil {
		helper.ErrorResponseWithAdditionalData(ctx, serviceErr.ResponseCode, *serviceErr, &serviceErr.Error.Message)
		return
	}
	ctx.JSON(http.StatusOK, &response.ClusterGenericResponse{Message: "cluster network deployment started"})
}
