package config

import (
	"log"
	"strings"

	"saas-management/config"

	"github.com/spf13/viper"
)

// LoadConfig - reads configuration from file or environment variables.
func LoadConfig(path string, name string) (config.Configuration, error) {
	viper.AddConfigPath(path)
	viper.SetConfigName(name)
	viper.SetConfigType("yaml")

	// Replace config values with environment variables if any
	viper.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	viper.AutomaticEnv()

	var cfg config.Configuration

	if err := viper.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); ok {
			// Config file not found; ignore error if desired
			log.Println("no such config file")
		} else {
			// Config file was found but another error was produced
			log.Println("read config error")
		}
		return cfg, err
	}

	// Config file found and successfully parse
	err := viper.Unmarshal(&cfg)
	return cfg, err
}
