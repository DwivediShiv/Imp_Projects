package router

import (
	"fmt"
	"saas-management/common"
	"saas-management/config"
	"saas-management/controller"
	"saas-management/middleware"
	"saas-management/repository"
	"saas-management/service"

	"github.com/gin-gonic/gin"
	"github.com/robfig/cron/v3"
	"gorm.io/gorm"
)

func PrepareRoutes(config *config.Configuration, router *gin.Engine, userDb, keycloakDb *gorm.DB) error {
	router.Use(middleware.CORS(config.API))

	saasUserRepository := repository.NewSaasUserRepository(userDb)
	customerRepository := repository.NewCustomerRepository(userDb)
	instanceRepository := repository.NewInstanceRepository(userDb)
	clusterRepository := repository.NewClusterRepository(userDb)
	keycloakRepository := repository.NewKeycloakRepository(keycloakDb)
	authService := service.NewAuthService(saasUserRepository, keycloakRepository, *config)
	inviteUserService := service.NewInviteUserService(saasUserRepository, keycloakRepository, *config)
	userService := service.NewUserService(saasUserRepository, keycloakRepository, *config)
	customerService := service.NewCustomerService(customerRepository, keycloakRepository, *config)
	instanceService := service.NewInstanceService(instanceRepository, *config)
	clusterService := service.NewClusterService(clusterRepository, *config)
	authController := controller.NewAuthController(authService)
	inviteUserController := controller.NewInviteUserController(inviteUserService)
	userController := controller.NewUserController(userService)
	customerController := controller.NewCustomerController(customerService)
	instanceController := controller.NewInstanceController(instanceService)
	clusterController := controller.NewClusterController(clusterService)

	apiGroup := router.Group("/api")
	v1Group := apiGroup.Group("/v1")

	saasGroup := v1Group.Group("/saas")
	{
		saasGroup.GET("/invited/user-state", inviteUserController.GetUserState)
		saasGroup.POST("/accept-invitation", inviteUserController.AcceptInvite)
	}

	authGroup := saasGroup.Group("")
	{
		authGroup.PUT("/login", authController.LoginUser)
		authGroup.POST("/resend-otp", authController.ResendOTP)
		authGroup.POST("/access-token", authController.GenerateAccessToken)
		authGroup.POST("/send-reset-email", authController.ResetEmail)
		authGroup.POST("/reset-password", authController.ResetPassword)
		authGroup.PUT("/change-password", authController.ChangePassword)
	}

	validateUserGroup := saasGroup.Group("")
	{
		// Validate for user role
		validateUserGroup.Use(func(c *gin.Context) {
			middleware.ValidateByRealmRole(c, keycloakDb, config, common.UserRole)
		})

		validateUserGroup.GET("/customer/list", customerController.GetCustomerNameList)
		validateUserGroup.GET("/version/list", instanceController.VersionList)
		// api to get profile roles from keycloak
		validateUserGroup.GET("/users/:profileId/roles", userController.GetUserProfileRoles)

	}

	validateCustomerManagerGroup := saasGroup.Group("/management")
	{
		// Validate for user role
		validateCustomerManagerGroup.Use(func(c *gin.Context) {
			middleware.ValidateByRealmRole(c, keycloakDb, config, common.CustomerManagerRole)
		})
		validateCustomerManagerGroup.POST("/customer", customerController.CreateCustomer)
		validateCustomerManagerGroup.GET("/customer/id/:customerId", customerController.GetCustomerByID)
		validateCustomerManagerGroup.POST("/customer/list", customerController.GetCustomerList)
		validateCustomerManagerGroup.POST("/customer/list/export", customerController.ExportCustomerList)
		validateCustomerManagerGroup.PATCH("/customer/", customerController.ChangeCustomerStatus)
		validateCustomerManagerGroup.DELETE("/customer/id/:customerId", customerController.DeleteCustomer)
	}

	validateInfraManagerGroup := saasGroup.Group("/management")
	{
		// Validate for user role
		validateInfraManagerGroup.Use(func(c *gin.Context) {
			middleware.ValidateByRealmRole(c, keycloakDb, config, common.InfraManagerRole)
		})
		validateInfraManagerGroup.POST("/instance", instanceController.CreateInstance)
		validateInfraManagerGroup.GET("/instance/id/:instanceId", instanceController.GetInstanceByID)
		validateInfraManagerGroup.POST("/instance/list", instanceController.GetInstanceList)
		validateInfraManagerGroup.POST("/instance/list/export", instanceController.ExportInstanceList)
		validateInfraManagerGroup.DELETE("/instance/id/:instanceId", instanceController.DeleteInstance)
		validateInfraManagerGroup.PATCH("/instance/id/:instanceId/status/:status", instanceController.ActivateInactiveInstance)
		validateInfraManagerGroup.PATCH("/instance/id/:instanceId/version/:version", instanceController.DeployInstanceVersion)
		validateInfraManagerGroup.PATCH("/instance/id/:instanceId/network/", instanceController.DeployInstanceNetwork)
		// Get Release Note
		validateInfraManagerGroup.GET("/version/:version/release-note", instanceController.GetReleaseNote)

		// Cluster management
		validateInfraManagerGroup.POST("/cluster", clusterController.CreateCluster)
		validateInfraManagerGroup.GET("/cluster/id/:clusterId", clusterController.GetClusterByID)
		validateInfraManagerGroup.POST("/cluster/list", clusterController.GetClusterList)
		validateInfraManagerGroup.POST("/cluster/list/export", clusterController.ExportClusterList)
		validateInfraManagerGroup.DELETE("/cluster/id/:clusterId", clusterController.DeleteCluster)
		validateInfraManagerGroup.PATCH("/cluster/id/:clusterId/version/:version", clusterController.DeployClusterVersion)
		validateInfraManagerGroup.PATCH("/cluster/id/:clusterId/network", clusterController.DeployClusterNetwork)
	}

	validateAdminGroup := saasGroup.Group("")
	{
		// Validate for Admin role
		validateAdminGroup.Use(func(c *gin.Context) {
			middleware.ValidateByRealmRole(c, keycloakDb, config, common.AdminRole)
		})

		//api to invite user via email and save details in saas db
		validateAdminGroup.POST("/invite-user", inviteUserController.InviteUser)

		// api to get invited user list
		validateAdminGroup.POST("/user-list", inviteUserController.InvitedUserList)

		// api to export invited user list
		validateAdminGroup.POST("/user-list/export", inviteUserController.ExportInvitedUserList)

		// admin to resend invite
		validateAdminGroup.POST("/resend-invite/:emailId", inviteUserController.ResendInviteUser)

		// Toggle user role
		validateAdminGroup.PUT("/users/:role/:profileId", userController.UpdateUserRoleStatus)

		// Active/Inactive User
		validateAdminGroup.PUT("/users/update-state/:profileId", userController.UpdateUserStatus)

		// Delete User
		validateAdminGroup.DELETE("/user-list/delete-user/:emailId", userController.DeleteSaasUser)

		// api to get user details based on profile id
		validateAdminGroup.GET("/users/:profileId", userController.GetUserProfileDetails)

	}

	createCronJobs(config, instanceService)
	createClusterCronJobs(config, clusterService)
	return nil
}

func createCronJobs(config *config.Configuration, instanceService service.InstanceService) {
	c := cron.New()
	c.AddFunc("@every "+config.Instance.PI_CronJobDuration, instanceService.CheckProvisionedInstancesStatus)
	c.AddFunc("@every "+config.Instance.PDVI_CronJobDuration, instanceService.CheckPendingVerificationsInstancesStatus)
	c.AddFunc("@every "+config.Instance.FI_CronJobDuration, instanceService.CheckFinalizingInstancesStatus)
	c.AddFunc("@every "+config.Instance.DI_CronJobDuration, instanceService.CheckDeletionInProgressInstancesStatus)
	c.AddFunc("@every "+config.Instance.AI_CronJobDuration, instanceService.CheckActivationInProgressInstancesStatus)
	c.AddFunc("@every "+config.Instance.II_CronJobDuration, instanceService.CheckInactivationInProgressInstancesStatus)
	c.AddFunc("@every "+config.Instance.VDI_CronJobDuration, instanceService.CheckVersionDeploymentInProgressInstancesStatus)
	c.AddFunc("@every "+config.Instance.NDI_CronJobDuration, instanceService.CheckNetworkDeploymentInProgressInstancesStatus)
	c.AddFunc("@every "+config.Instance.EEI_CronJobDuration, instanceService.CheckEmailEligibleInstancesStatus)
	c.Start()
	printCronJobEntries(c.Entries())
}

func createClusterCronJobs(config *config.Configuration, clusterService service.ClusterService) {
	c := cron.New()
	c.AddFunc("@every "+config.Instance.PI_CronJobDuration, clusterService.CheckProvisionedClustersStatus)
	c.AddFunc("@every "+config.Instance.DI_CronJobDuration, clusterService.CheckDeletionInProgressClustersStatus)
	c.AddFunc("@every "+config.Instance.VDI_CronJobDuration, clusterService.CheckVersionDeploymentInProgressClustersStatus)
	c.AddFunc("@every "+config.Instance.NDI_CronJobDuration, clusterService.CheckNetworkDeploymentInProgressClustersStatus)
	c.Start()
	printCronJobEntries(c.Entries())
}

func printCronJobEntries(entries []cron.Entry) {
	fmt.Printf("\nCron Info: %+v\n", entries)
}
