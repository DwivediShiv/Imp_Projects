package helper

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"

	models "saas-management/models"
)

// Error fails context with given status code and error message.
func ErrorResponse(c *gin.Context, code int, errorResponse models.ErrorResponse, errorMessage *string) {
	c.JSON((code), gin.H{
		"error": errorResponse.Error,
		"code":  errorResponse.Code,
	})

	log.Printf("\nError %d: %v\nErrorMessage: %v\n", code, errorResponse.Error.Message, *errorMessage)
}

func ErrorResponseWithAdditionalData(c *gin.Context, code int, errorResponse models.ErrorResponse, errorMessage *string) {
	c.JSON((code), gin.H{
		"error": errorResponse.Error,
		"code":  errorResponse.Code,
	})

	log.Printf("\nError %d: %v\nErrorMessage: %v\n", code, errorResponse.Error.Message, *errorMessage)
}

// Respond is a wrapper used to handle API responses
func Respond(c *gin.Context, status int, body gin.H) {
	c.JSON(status, body)
}

// Respond is a wrapper used to handle API responses for any interface
func RespondRaw(c *gin.Context, status int, body interface{}) {
	c.JSON(status, body)
}

// status is used to handle optional status code params
func status(i []int) (status int) {
	if len(i) == 0 {
		status = http.StatusBadRequest
	} else {
		status = i[0]
	}
	return
}
