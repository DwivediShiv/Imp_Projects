package helper

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	cfg "saas-management/config"
	models "saas-management/models"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials/stscreds"
	"github.com/aws/aws-sdk-go-v2/service/acm"
	acmtypes "github.com/aws/aws-sdk-go-v2/service/acm/types"
	"github.com/aws/aws-sdk-go-v2/service/codebuild"
	"github.com/aws/aws-sdk-go-v2/service/codebuild/types"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/aws/aws-sdk-go-v2/service/ses"
	sestypes "github.com/aws/aws-sdk-go-v2/service/ses/types"
	"github.com/aws/aws-sdk-go-v2/service/ssm"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

const (
	certificateRegion = "us-east-1"
	cdnDomainName     = "/%s/acentrik/cdn_route53_record_fqdns"
	sesDomainEntries  = "/%s/acentrik/ssm_custom_ses_validation_route53_record_fqdns"
	acmDomainEntries  = "/%s/acentrik/ssm_custom_acm_validation_route53_record_fqdns"
)

func createS3Client(awsConfig aws.Config) (*s3.Client, *s3.PresignClient) {
	// Create S3 service client
	svc := s3.NewFromConfig(awsConfig)
	presignClient := s3.NewPresignClient(svc)
	return svc, presignClient
}

func getCertificateAWSConfig(configuration *cfg.Configuration, roleArn string) aws.Config {
	// Initialize the AWS configuration
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	cfg, err := config.LoadDefaultConfig(ctx)
	if err != nil {
		log.Fatalf("Failed to load AWS configuration: %v", err)
	}

	// Create the STS client
	stsClient := sts.NewFromConfig(cfg)

	// Assume the role to get temporary credentials
	appCreds := stscreds.NewAssumeRoleProvider(stsClient, roleArn)

	_, err = appCreds.Retrieve(ctx)
	if err != nil {
		log.Printf("\n error in getting assume role '%s' temp creds: %s in getCertificateAWSConfig\n", roleArn, err)
		return aws.Config{}
	}

	// Create the AWS SDK v2 configuration with the temporary credentials
	awsCfg := aws.Config{
		Region:      certificateRegion,
		Credentials: aws.NewCredentialsCache(appCreds),
	}
	return awsCfg
}

func createAWSConfig(configuration *cfg.Configuration) aws.Config {
	reg := configuration.AWS_Prod.Region
	roleArn := configuration.AWS_Prod.ARN
	// Initialize the AWS configuration
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	cfg, err := config.LoadDefaultConfig(ctx)
	if err != nil {
		log.Fatalf("Failed to load AWS configuration: %v", err)
		return aws.Config{}
	}

	// Create the STS client
	stsClient := sts.NewFromConfig(cfg)

	// Assume the role to get temporary credentials
	appCreds := stscreds.NewAssumeRoleProvider(stsClient, roleArn)

	_, err = appCreds.Retrieve(ctx)
	if err != nil {
		log.Printf("\n error in getting assume role '%s' '%s' temp creds: %s in createAWSConfig\n", reg, roleArn, err)
		return aws.Config{}
	}

	// Create the AWS SDK v2 configuration with the temporary credentials
	awsCfg := aws.Config{
		Region:      reg,
		Credentials: aws.NewCredentialsCache(appCreds),
	}
	return awsCfg
}

func createAWSConfigForNonProd(configuration *cfg.Configuration) aws.Config {
	reg := configuration.AWS_Non_Prod.Region
	roleArn := configuration.AWS_Non_Prod.ARN
	// Initialize the AWS configuration
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	cfg, err := config.LoadDefaultConfig(ctx)
	if err != nil {
		log.Fatalf("Failed to load AWS configuration: %v", err)
	}

	// Create the STS client
	stsClient := sts.NewFromConfig(cfg)

	// Assume the role to get temporary credentials
	appCreds := stscreds.NewAssumeRoleProvider(stsClient, roleArn)

	_, err = appCreds.Retrieve(ctx)
	if err != nil {
		log.Printf("\n error in getting assume role '%s' '%s' temp creds: %s in createAWSConfigForNonProd\n", reg, roleArn, err)
		return aws.Config{}
	}

	// Create the AWS SDK v2 configuration with the temporary credentials
	awsCfg := aws.Config{
		Region:      reg,
		Credentials: aws.NewCredentialsCache(appCreds),
	}
	return awsCfg
}

func GetVersionInfoFromS3(configuration *cfg.Configuration) (models.VersionInfo, error) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	awsConfig, err := config.LoadDefaultConfig(ctx, config.WithRegion(configuration.Instance.Bucket_Region))
	if err != nil {
		log.Printf("error in creating cfg for aws for '%s' region: %v", err, configuration.Instance.Bucket_Region)
		return nil, err
	}

	s3Client, _ := createS3Client(awsConfig)
	requestInput := &s3.GetObjectInput{
		Bucket: aws.String(configuration.Instance.Bucket_Shared),
		Key:    aws.String(configuration.Instance.BasePath + configuration.Instance.VersionFileName),
	}

	result, err := s3Client.GetObject(ctx, requestInput)
	if err != nil {
		log.Printf("error in getting object from s3: %v", err)
		return nil, err
	}
	defer result.Body.Close()

	// capture all bytes from upload
	b, err := ioutil.ReadAll(result.Body)
	if err != nil {
		log.Printf("error in reading object from s3: %v", err)
		return nil, err
	}

	var obj models.VersionInfo
	if err = json.Unmarshal(b, &obj); err != nil {
		log.Printf("error in unmarshalling s3 object: %v", err)
		return nil, err
	}

	return obj, err
}

func GetReleaseNotesFromS3(configuration *cfg.Configuration, releaseVersion string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	awsConfig, err := config.LoadDefaultConfig(ctx, config.WithRegion(configuration.Instance.Bucket_Region))
	if err != nil {
		log.Printf("error in creating cfg for aws for '%s' region: %v", err, configuration.Instance.Bucket_Region)
		return "", err
	}

	s3Client, _ := createS3Client(awsConfig)
	filename := configuration.Instance.BasePath + releaseVersion + "/" + configuration.Instance.ReleaseNotesFileName
	requestInput := &s3.GetObjectInput{
		Bucket: aws.String(configuration.Instance.Bucket_Shared),
		Key:    aws.String(filename),
	}

	result, err := s3Client.GetObject(ctx, requestInput)
	if err != nil {
		log.Printf("error in getting object from s3: %v", err)
		return "", err
	}
	defer result.Body.Close()

	// capture all bytes from upload
	mdContent, err := ioutil.ReadAll(result.Body)
	if err != nil {
		log.Printf("error in reading object from s3: %v", err)
		return "", err
	}

	return string(mdContent), err
}

func RunCreateInstanceCodeBuildPipeline(configuration *cfg.Configuration, req *models.CreateInstanceArgs) (*string, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)
	svc := codebuild.NewFromConfig(awsConfig)
	var evo []types.EnvironmentVariable

	if req.CustomDomain != "" {
		evo = []types.EnvironmentVariable{
			{Name: aws.String("region"), Value: aws.String(req.Region)},
			{Name: aws.String("instance_name"), Value: aws.String(req.InstanceName)},
			{Name: aws.String("instance_admin_email"), Value: aws.String(req.InstanceAdminEmail)},
			{Name: aws.String("network"), Value: aws.String(req.Network)},
			{Name: aws.String("token_address"), Value: aws.String(req.TokenAddress)},
			{Name: aws.String("token_symbol"), Value: aws.String(req.TokenSymbol)},
			{Name: aws.String("decimals"), Value: aws.String(req.Decimals)},
			{Name: aws.String("custom_domain"), Value: aws.String(req.CustomDomain)},
			{Name: aws.String("ses_domain"), Value: aws.String(req.SESDomain)},
			{Name: aws.String("ses_domain_exists"), Value: aws.String(req.SESDomainExist)},
		}
	} else {
		evo = []types.EnvironmentVariable{
			{Name: aws.String("region"), Value: aws.String(req.Region)},
			{Name: aws.String("instance_name"), Value: aws.String(req.InstanceName)},
			{Name: aws.String("instance_admin_email"), Value: aws.String(req.InstanceAdminEmail)},
			{Name: aws.String("network"), Value: aws.String(req.Network)},
			{Name: aws.String("token_address"), Value: aws.String(req.TokenAddress)},
			{Name: aws.String("token_symbol"), Value: aws.String(req.TokenSymbol)},
			{Name: aws.String("decimals"), Value: aws.String(req.Decimals)},
		}
	}

	input := &codebuild.StartBuildInput{
		ProjectName:                  aws.String("instance_create"),
		EnvironmentVariablesOverride: evo,
		SourceVersion:                &req.Version,
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()

	output, err := svc.StartBuild(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error building create instance pipeline: %v\nReq: '%s' '%s' '%s'\n", err, req.InstanceName, req.Region, req.CustomDomain)
		return nil, err
	}

	fmt.Printf("Started build for project 'create_instance' with build obj: %+v\n", output)
	return output.Build.Id, nil
}

// Creare Cluster CodeBuild Pipeline
func RunCreateClusterCodeBuildPipeline(configuration *cfg.Configuration, req *models.CreateClusterArgs) (*string, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)
	svc := codebuild.NewFromConfig(awsConfig)

	evo := []types.EnvironmentVariable{
		{Name: aws.String("region"), Value: aws.String(req.Region)},
		{Name: aws.String("network"), Value: aws.String(req.Network)},
	}

	input := &codebuild.StartBuildInput{
		ProjectName:                  aws.String("cluster_create"),
		EnvironmentVariablesOverride: evo,
		SourceVersion:                &req.Version,
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()

	output, err := svc.StartBuild(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error building create cluster pipeline: %v\nReq: '%s' '%s'\n", err, req.ClusterName, req.Region)
		return nil, err
	}

	fmt.Printf("Started build for project 'cluster_create' with build obj: %+v\n", output)
	return output.Build.Id, nil
}

func RunDeleteInstanceCodeBuildPipeline(configuration *cfg.Configuration, req *models.DeleteInstanceArgs) (*string, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)
	svc := codebuild.NewFromConfig(awsConfig)
	var evo []types.EnvironmentVariable

	if req.SESDomainExist {
		evo = []types.EnvironmentVariable{
			{Name: aws.String("region"), Value: aws.String(req.Region)},
			{Name: aws.String("instance_name"), Value: aws.String(req.InstanceName)},
			{Name: aws.String("ses_domain"), Value: aws.String(req.SESDomain)},
			{Name: aws.String("ses_domain_in_use"), Value: aws.String("True")},
		}
	} else {
		evo = []types.EnvironmentVariable{
			{Name: aws.String("region"), Value: aws.String(req.Region)},
			{Name: aws.String("instance_name"), Value: aws.String(req.InstanceName)},
			{Name: aws.String("ses_domain_in_use"), Value: aws.String("False")},
		}
	}

	input := &codebuild.StartBuildInput{
		ProjectName:                  aws.String("instance_destroy"),
		EnvironmentVariablesOverride: evo,
		SourceVersion:                &req.Version,
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	output, err := svc.StartBuild(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error building delete instance pipeline: %v\nReq: '%s' '%s' '%s'\n", err, req.InstanceName, req.Region, req.Version)
		return nil, err
	}

	fmt.Printf("Started build for project 'instance_destroy' with build obj: %+v\n", output)
	return output.Build.Id, nil
}

// Delete cluster codebuild pipeline
func RunDeleteClusterCodeBuildPipeline(configuration *cfg.Configuration, req *models.DeleteClusterArgs) (*string, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)
	svc := codebuild.NewFromConfig(awsConfig)
	var evo []types.EnvironmentVariable

	evo = []types.EnvironmentVariable{
		{Name: aws.String("region"), Value: aws.String(req.Region)},
	}

	input := &codebuild.StartBuildInput{
		ProjectName:                  aws.String("cluster_destroy"),
		EnvironmentVariablesOverride: evo,
		SourceVersion:                &req.Version,
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	output, err := svc.StartBuild(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error building delete cluster pipeline: %v\nReq: '%s' '%s' '%s'\n", err, req.ClusterName, req.Region, req.Version)
		return nil, err
	}

	fmt.Printf("Started build for project 'cluster_destroy' with build obj: %+v\n", output)
	return output.Build.Id, nil
}

func RunInactivateInstanceCodeBuildPipeline(configuration *cfg.Configuration, req *models.InactivateInstanceArgs) (*string, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)
	svc := codebuild.NewFromConfig(awsConfig)

	evo := []types.EnvironmentVariable{
		{Name: aws.String("region"), Value: aws.String(req.Region)},
		{Name: aws.String("instance_name"), Value: aws.String(req.InstanceName)},
	}
	input := &codebuild.StartBuildInput{
		ProjectName:                  aws.String("instance_deactivate"),
		EnvironmentVariablesOverride: evo,
		SourceVersion:                &req.Version,
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	output, err := svc.StartBuild(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error building inactivate instance pipeline: %v\nReq: '%s' '%s' '%s'\n", err, req.InstanceName, req.Region, req.Version)
		return nil, err
	}

	fmt.Printf("Started build for project 'instance_deactivate' with build obj: %+v\n", output)
	return output.Build.Id, nil
}

func GetInstanceBuildStatus(configuration *cfg.Configuration, req *models.GetBuildStatus) (*types.Build, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)

	// Create CodeBuild service client
	svc := codebuild.NewFromConfig(awsConfig)

	input := &codebuild.BatchGetBuildsInput{
		Ids: []string{req.BuildID},
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	output, err := svc.BatchGetBuilds(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error getbuild status: %v\nReq: '%s' '%s' '%s'\n", err, req.BuildID, req.Region, req.AccountType)
		return nil, err
	}

	bnf := output.BuildsNotFound
	if len(bnf) > 0 {
		fmt.Printf("\nBuildsNotFoundError for id '%s' '%d' '%+v'\n", req.BuildID, len(bnf), bnf)
	}

	fmt.Printf("BatchGetBuilds returned for '%s' for '%s' account with obj count %v\n", req.BuildID, req.AccountType, len(output.Builds))
	return &output.Builds[0], nil
}

func IsCustomEmailDomainVerified(configuration *cfg.Configuration, req *models.SESIdentityVerificationReq) (bool, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)

	// Create service client
	svc := ses.NewFromConfig(awsConfig)
	input := &ses.GetIdentityVerificationAttributesInput{
		Identities: []string{req.CustomEmailDomain},
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	output, err := svc.GetIdentityVerificationAttributes(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error get identity verification status: %v\nReq: '%s' '%s'\n", err, req.CustomEmailDomain, req.AccountType)
		return false, err
	}

	status := output.VerificationAttributes[req.CustomEmailDomain].VerificationStatus
	if status == sestypes.VerificationStatusSuccess {
		return true, nil
	}

	fmt.Printf("\n IsCustomEmailDomainVerified status for '%s' is '%s'\n", req.CustomEmailDomain, status)
	return false, nil
}

func IsCustomDomainCertificateIssued(configuration *cfg.Configuration, req *models.CertificateVerificationReq) (bool, error) {
	roleArn := configuration.AWS_Non_Prod.ARN
	if req.AccountType == "Prod" {
		roleArn = configuration.AWS_Prod.ARN

	}
	awsConfig := getCertificateAWSConfig(configuration, roleArn)

	// Create service client
	svc := acm.NewFromConfig(awsConfig)

	input := &acm.ListCertificatesInput{
		CertificateStatuses: []acmtypes.CertificateStatus{acmtypes.CertificateStatusIssued},
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	output, err := svc.ListCertificates(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error get acm certificate '%s' status: %v\nReq: '%s' '%s'\n", req.CustomDomain, err, req.Region, req.AccountType)
		return false, err
	}

	for _, cert := range output.CertificateSummaryList {
		if *cert.DomainName == req.CustomDomain {
			return true, nil
		}
	}

	fmt.Printf("\n IsCustomDomainCertificateIssued status for '%s' is not issued\n", req.CustomDomain)
	return false, nil
}

func RerunCreateInstanceCodeBuildPipeline(configuration *cfg.Configuration, req *models.RetryCreateInstanceReq) (*types.Build, error) {
	awsConfig := getAWSConfig(configuration, req.AccountType)

	// Create CodeBuild service client
	svc := codebuild.NewFromConfig(awsConfig)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()

	input := &codebuild.RetryBuildInput{Id: aws.String(req.BuildID)}
	output, err := svc.RetryBuild(ctx, input)
	if err != nil {
		fmt.Printf("\nGot error in retry create instance pipeline '%s' status: %v\nReq: '%s' '%s'\n", req.BuildID, err, req.Region, req.AccountType)
		return nil, err
	}

	return output.Build, nil
}

func GetCustomDomainEntriesFromSSM(configuration *cfg.Configuration, req *models.GetSSMParamReq) ([]string, error) {
	entries := []string{}
	entry, err := getSSMParam(configuration, req, cdnDomainName)
	if err != nil {
		return nil, err
	}
	entries = append(entries, entry)

	entry, err = getSSMParam(configuration, req, acmDomainEntries)
	if err != nil {
		return nil, err
	}
	entries = append(entries, entry)

	if req.IsSESRequested {
		entry, err := getSSMParam(configuration, req, sesDomainEntries)
		if err != nil {
			return nil, err
		}
		entries = append(entries, entry)
	}

	return entries, nil
}

func getSSMParam(configuration *cfg.Configuration, req *models.GetSSMParamReq, paramName string) (string, error) {
	awsConfig := getAWSConfigWithProvidedRegion(configuration, req.AccountType, req.Region)
	// Create ssm service client
	svc := ssm.NewFromConfig(awsConfig)
	name := fmt.Sprintf(paramName, req.InstanceName)

	requestInput := &ssm.GetParameterInput{
		Name: aws.String(name),
	}

	output, err := svc.GetParameter(context.TODO(), requestInput)
	if err != nil {
		log.Printf("\nerror in getting object '%s' '%s' '%s' into ssm: %v\n", name, req.InstanceName, req.Region, err)
		return "", err
	}

	return *output.Parameter.Value, err
}

func getAWSConfig(configuration *cfg.Configuration, accountType string) aws.Config {
	if accountType == "Non-Prod" {
		return createAWSConfigForNonProd(configuration)
	}
	return createAWSConfig(configuration)
}

func getAWSConfigWithProvidedRegion(configuration *cfg.Configuration, accountType, reg string) aws.Config {
	roleArn := configuration.AWS_Non_Prod.ARN
	if accountType == "Prod" {
		roleArn = configuration.AWS_Prod.ARN
	}

	// Initialize the AWS configuration
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*300)
	defer cancel()
	cfg, err := config.LoadDefaultConfig(ctx)
	if err != nil {
		log.Fatalf("Failed to load AWS configuration: %v", err)
	}

	// Create the STS client
	stsClient := sts.NewFromConfig(cfg)

	// Assume the role to get temporary credentials
	appCreds := stscreds.NewAssumeRoleProvider(stsClient, roleArn)

	_, err = appCreds.Retrieve(ctx)
	if err != nil {
		log.Printf("\n error in getting assume role '%s' '%s' temp creds: %s in createAWSConfigForNonProd\n", reg, roleArn, err)
		return aws.Config{}
	}

	// Create the AWS SDK v2 configuration with the temporary credentials
	awsCfg := aws.Config{
		Region:      reg,
		Credentials: aws.NewCredentialsCache(appCreds),
	}
	return awsCfg

}
