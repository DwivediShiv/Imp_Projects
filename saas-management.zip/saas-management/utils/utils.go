package utils

import (
	"bufio"
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/mail"
	"net/url"
	"os"
	"regexp"
	"saas-management/common"
	"saas-management/config"
	"saas-management/helper"
	"saas-management/models"
	"saas-management/models/response"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/dchest/uniuri"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
	"gorm.io/gorm"
)

type TokenHandler models.TokenHandler

const (
	grantTypeClientCredentials      = "client_credentials"
	RESET_PASSWORD_RANDOM_ATTRIBUTE = "RESET_PASS_RAND"
	LOGIN_COUNT                     = "LOGIN_COUNT"
	OTP                             = "OTP"
	OTP_LENGTH                      = 6
	otpChars                        = "1234567890"
	FULL_COUNTRY                    = "FULLCOUNTRY"
	FULL_NETWORK                    = "Network"
	FULL_AWS_ACCOUNT                = "AWSAccount"
	FULL_REGION                     = "Region"
	FULL_INDUSTRY                   = "Industry"
	VIEWER_ROLE                     = "viewer"
	Admin_ROLE                      = "Admin"
	FULL_TOKEN_SYMBOL               = "NetworkTicker"
	selfInviteAPIURL                = "https://api.%s.acentrik.io/user-management/api/v1/as/self-invite"
	selfInviteAPIURLForCustomDomain = "https://api.%s/user-management/api/v1/as/self-invite"
)

// common function to remove duplicates from a slice of int or string
func RemoveDuplicate[T string | int](sliceList []T) []T {
	allKeys := make(map[T]bool)
	list := []T{}
	for _, item := range sliceList {
		if _, value := allKeys[item]; !value {
			allKeys[item] = true
			list = append(list, item)
		}
	}
	return list
}

// Method to check for valid saas roles
func IsValidSaasUserRole(role string) bool {
	for _, validRole := range common.ValidRoles {
		if strings.EqualFold(role, validRole) {
			return true
		}
	}
	return false
}

func GetTokenFromJwtHeader(c *gin.Context) (*models.Claims, error) {
	authHeader := c.GetHeader("Authorization")
	if len(authHeader) == 0 {
		return &models.Claims{}, errors.New("authorization header is required")
	}
	tokenString := authHeader[len("Bearer"):]
	tokenString = strings.TrimLeft(tokenString, " ")
	claims := &models.Claims{}
	token, _ := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(""), nil
	})

	if token == nil || claims.ExpiresAt < time.Now().Unix() {
		return nil, errors.New("invalid/expired token")
	}

	return token.Claims.(*models.Claims), nil
}

// Normalize email (lower_case, trim, parse address)
func NormalizeEmail(email string) (string, error) {
	emailRes := strings.ToLower(email)
	emailRes = strings.TrimSpace(emailRes)
	_, err := mail.ParseAddress(emailRes)
	if err != nil {
		return "", err
	}
	return emailRes, nil
}

func IsEmailValid(emailAddress string) bool {
	emailRegex := regexp.MustCompile(`^(([^/<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$`)
	return emailRegex.MatchString(emailAddress)
}

func ConvertNetworkVarcharArrayToStringArray(input string) []string {
	// Remove the surrounding curly braces if they exist
	if strings.HasPrefix(input, "{") && strings.HasSuffix(input, "}") {
		input = input[1 : len(input)-1]
	}

	// Split the string into an array using the comma as the delimiter
	return strings.Split(input, ",")
}

func HasSpecialCharactersInStartAndEndOfString(str string) bool {
	emailRegex := regexp.MustCompile(`^[a-zA-Z0-9](.*[a-zA-Z0-9])?$`)
	return emailRegex.MatchString(str)
}

func IsValidDomain(str string, maxLen int) bool {
	domainRegex := regexp.MustCompile(`^([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$`)
	return len(str) <= maxLen && domainRegex.MatchString(str)
}

func IsValidAlphanumeric(str string) bool {
	regex := regexp.MustCompile(`^[a-zA-Z0-9]+$`)
	return regex.MatchString(str)
}

func IsAlphanumericWithOptionalHyphenInBetween(s string) bool {
	regex := regexp.MustCompile(`^[a-zA-Z0-9]+(-[a-zA-Z0-9]+)*$`)
	return regex.MatchString(s)

}

func ValidateAlphanumericWithSpaceInput(input string) bool {
	regex := regexp.MustCompile(`^[a-zA-Z0-9 ]+$`)
	return regex.MatchString(input)
}

func changeToDBRoles(input string) string {
	// Split the input string by "-"
	words := strings.Split(input, "-")

	// Capitalize the first letter of each word
	for i, word := range words {
		words[i] = strings.Title(word)
	}

	// Join the words back together with spaces
	result := strings.Join(words, " ")

	return result
}

func RemoveElementFromCommaSeperatedString(rolesString string, roleToDelete string) string {
	rolesString = strings.Trim(rolesString, ",")
	roleToDelete = changeToDBRoles(roleToDelete)
	if rolesString == roleToDelete {
		return CapitalizeWords(VIEWER_ROLE)
	}

	// Split the roles into a slice
	roleSlice := strings.Split(rolesString, ",")

	// Loop through the slice to remove the specified role
	for i := range roleSlice {
		currentRole := roleSlice[i]
		if currentRole == roleToDelete {
			// Remove the role if it matches the specified role to delete
			roleSlice = append(roleSlice[:i], roleSlice[i+1:]...)
			break
		}
	}

	if len(roleSlice) <= 1 {
		return roleSlice[0]
	}

	return sortArray(roleSlice)
}

func AddElementToCommaSeperatedString(actualString string, element string) string {
	actualString = strings.Trim(actualString, ",")

	lowerActualString := strings.ToLower(actualString)
	lowerViewerString := strings.ToLower(VIEWER_ROLE)
	capitalizedFirstLetter := changeToDBRoles(element)

	// remove viewer role from string and add the element
	if lowerActualString == lowerViewerString {
		return capitalizedFirstLetter
	}

	// Check if roleToAdd is already present
	roleSlice := strings.Split(actualString, ",")
	rolePresent := false
	for _, role := range roleSlice {
		if role == capitalizedFirstLetter {
			rolePresent = true
			break
		}
	}

	// If roleToAdd is not present, append it
	if !rolePresent {
		roleSlice = append(roleSlice, capitalizedFirstLetter)
	}

	return sortArray(roleSlice)
}

// Function to make "Admin" the first value in the slice
func sortArray(arr []string) string {
	sort.Strings(arr)
	return strings.Join(arr, ",")
}

// Captial the first letter of word
func CapitalizeWords(input string) string {
	words := strings.Split(input, ",")
	capitalizedWords := make([]string, len(words))

	for i, word := range words {
		word = strings.TrimSpace(word)
		word = strings.ReplaceAll(word, " ", "-")
		if word != "" {
			capitalizedWords[i] = strings.ToUpper(string(word[0])) + strings.ToLower(word[1:])
		}
	}

	return strings.Join(capitalizedWords, ",")
}

func GenerateSignedAccessToken(config config.Configuration, subject string, email string) (string, error) {
	privateKeyImported, privateKeyImportError := GetPrivateKey(&config)
	if privateKeyImportError != nil {
		fmt.Printf("Import Key err: %s", privateKeyImportError.Error())
		return "", privateKeyImportError
	}

	// Create token handler with this key
	tokenHandler := &TokenHandler{privateKeyImported}

	// Generate new signed token using tokenhandler
	_, _, actionToken, tokenError := tokenHandler.NewToken(subject, email, config.Auth.VerificationTokenDuration)

	return actionToken, tokenError
}

// Generate new JWT Token
func (e *TokenHandler) NewToken(subject string, email string, tokenExpiresIn string) (int64, int64, string, error) {
	createdAt := time.Now().Unix()
	tokenExpiry, err := strconv.ParseInt(tokenExpiresIn, 10, 64)
	if err != nil {
		tokenExpiry = int64(common.DefaultTokenExpiresIn)
	}
	expiresAt := createdAt + tokenExpiry
	t := jwt.NewWithClaims(jwt.SigningMethodRS256, models.Claims{
		StandardClaims: jwt.StandardClaims{
			Subject:   subject,
			ExpiresAt: expiresAt,
			IssuedAt:  createdAt,
			NotBefore: createdAt,
		},
		Email: email,
	})
	signedString, err := t.SignedString(e.PrivateKey)
	return createdAt, expiresAt, signedString, err
}

// Get Private Key (Pem File)
func GetPrivateKey(config *config.Configuration) (*rsa.PrivateKey, error) {
	fmt.Println("private key file", config.Info.PrivateKeyFile)
	privateKeyFile, err := os.Open(config.Info.PrivateKeyFile)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	pemfileinfo, _ := privateKeyFile.Stat()
	var size int64 = pemfileinfo.Size()
	pembytes := make([]byte, size)
	buffer := bufio.NewReader(privateKeyFile)
	_, err = buffer.Read(pembytes)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	data, _ := pem.Decode([]byte(pembytes))
	privateKeyFile.Close()
	privateKeyImported, err := x509.ParsePKCS1PrivateKey(data.Bytes)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	return privateKeyImported, err
}

// loginAdmin Login to keycloak for Admin REST APIs
func LoginAdmin(c *gin.Context, config *config.Configuration) (*gocloak.GoCloak, *gocloak.JWT, error) {
	client := gocloak.NewClient(config.Auth.Host)

	if config.Auth.GrantType == common.GrantTypeClientCredentials {
		//Login to keycloak using grant_type:client_credentials with a service account
		token, err := client.LoginClient(c, config.Auth.AdminClientId, config.Auth.AdminClientSecret,
			config.Auth.AdminRealm)

		return client, token, err
	} else {
		//Login to keycloak using grant_type:password with an admin account
		token, err := client.LoginAdmin(c, config.Auth.AdminUsername, config.Auth.AdminPassword,
			config.Auth.AdminRealm)

		return client, token, err
	}
}

// Verify JWT Token
func (e TokenHandler) Verify(token string) (*models.Claims, error) {
	parsed, err := jwt.ParseWithClaims(token, &models.Claims{}, func(t *jwt.Token) (interface{}, error) {
		return &e.PrivateKey.PublicKey, nil
	})

	if err != nil {
		jwtError, hasError := err.(*jwt.ValidationError)

		if hasError && jwtError.Errors == jwt.ValidationErrorExpired {
			claims := parsed.Claims.(*models.Claims)
			return claims, jwtError
		}

		return &models.Claims{}, err
	}

	if claims, ok := parsed.Claims.(*models.Claims); ok && parsed.Valid {
		return claims, nil
	}
	return &models.Claims{}, errors.New("invalid token")
}

// Verify last token to action token
func VerifyLastToken(actionToken string, user gocloak.User, config *config.Configuration) (bool, string, error) {
	if (len((*user.Attributes)[common.LAST_VERIFICATION_TOKEN]) == 0) || *user.EmailVerified {
		return false, "", nil
	}

	lastVerificationToken := (*user.Attributes)[common.LAST_VERIFICATION_TOKEN][0]
	verificationToken := strings.Split(lastVerificationToken, "_")
	stringTokenExpireAt := verificationToken[0]
	stringTokenIssueAt := verificationToken[1]
	today := time.Now()

	tokenExpireAt, _ := stringToTime(stringTokenExpireAt)
	lastTokenHasExpired := today.After(tokenExpireAt)

	if actionToken != "" {
		privateKeyImported, err := GetPrivateKey(config)
		if err != nil {
			fmt.Printf("Import Key err: %s", err.Error())

			return false, "", err
		}
		tokenHandler := &TokenHandler{privateKeyImported}
		parsed, _ := jwt.ParseWithClaims(actionToken, &models.Claims{}, func(t *jwt.Token) (interface{}, error) {
			return &tokenHandler.PrivateKey.PublicKey, nil
		})

		claims, _ := parsed.Claims.(*models.Claims)
		intLastTokenExpiry, _ := strconv.ParseInt(stringTokenExpireAt, 10, 64)
		intLastTokenIssueAt, _ := strconv.ParseInt(stringTokenIssueAt, 10, 64)

		if claims.ExpiresAt != intLastTokenExpiry || claims.IssuedAt != intLastTokenIssueAt {
			return false, common.JWT_TOKEN_NOT_MATCH_ERROR_CODE, errors.New("invalid token")
		}

	}

	if !lastTokenHasExpired {
		return true, "", nil
	}

	return false, common.JWT_TOKEN_NOT_MATCH_ERROR_CODE, errors.New("token expired")

}

func stringToTime(s string) (time.Time, error) {
	sec, err := strconv.ParseInt(s, 10, 64)
	if err != nil {
		return time.Time{}, err
	}
	return time.Unix(sec, 0), nil
}

func GetUserInfoByEmail(client *gocloak.GoCloak, context *gin.Context, adminToken string, realm string, email string) (gocloak.User, error) {
	var fetchedUser []*gocloak.User
	var user gocloak.User
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(email),
	}

	fetchedUser, err := client.GetUsers(context, adminToken, realm, keycloakUser)

	if err != nil {
		return user, err
	}

	if len(fetchedUser) == 0 {
		return user, errors.New("no user found")
	}

	user = *fetchedUser[0]

	if user.Attributes == nil {
		emptyAttributes := make(map[string][]string)
		user.Attributes = &emptyAttributes
	}

	return user, nil
}

func SendEmailRequest(sendEmailURL *url.URL) error {
	sendEmailURL.RawQuery = sendEmailURL.Query().Encode()
	req, err := http.NewRequest("PUT", sendEmailURL.String(), nil)

	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return err
	}

	resp, err := http.DefaultClient.Do(req)

	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return err
	}

	if resp.StatusCode >= 200 && resp.StatusCode <= 299 {
		fmt.Println("HTTP Status is in the 2xx range")
	} else {
		fmt.Printf("Send Email err: %s", resp.Status)
		return errors.New(resp.Status)
	}

	return nil
}

func SendEmailPostRequest(sendEmailURL string, input any) error {
	// Convert struct to JSON
	jsonData, err := json.Marshal(input)
	if err != nil {
		fmt.Println("Error marshaling JSON:", err)
		return err
	}

	req, err := http.NewRequest("POST", sendEmailURL, bytes.NewBuffer(jsonData))
	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return err
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return err
	}

	if resp.StatusCode >= 200 && resp.StatusCode <= 299 {
		fmt.Println("HTTP Status is in the 2xx range")
	} else {
		fmt.Printf("Send Email err: %s", resp.Status)
		return errors.New(resp.Status)
	}

	return nil
}

// Get realm for a user from keycloakdb
func GetRealmNameByUsername(keycloakDb *gorm.DB, username string) (string, error) {
	var realmName string

	// Get realm_id from keycloak table for user
	tx := keycloakDb.Table("user_entity").Where("username = ?", username)
	tx.Select("realm_id")
	rows, err := tx.Rows()

	if err != nil {
		return "", err
	}
	defer rows.Close()
	for rows.Next() {
		tx.ScanRows(rows, &realmName)
	}

	return realmName, nil
}

func ContainRole(roles []*gocloak.Role, checkRole string) bool {
	for _, role := range roles {
		if gocloak.PString(role.Name) == checkRole {
			return true
		}
	}
	return false
}

func Contains(elems []string, v string) bool {
	for _, s := range elems {
		if v == s {
			return true
		}
	}
	return false
}

func VerifySignedActionToken(config *config.Configuration, c *gin.Context, actionToken string) (*models.Claims, error) {
	log.Println("** inside verify signed action token", actionToken)
	privateKeyImported, privateKeyImportError := GetPrivateKey(config)
	if privateKeyImportError != nil {
		errMsg := fmt.Sprintf("Import Key err: %s", privateKeyImportError.Error())
		helper.ErrorResponse(c, http.StatusBadRequest, common.ErrorTokenVerificationFailed, &errMsg)
		return nil, privateKeyImportError
	}

	// Create token handler with this key
	tokenHandler := &TokenHandler{privateKeyImported}
	log.Println("** after tokem claims", tokenHandler)

	// Validate signed action token using private key token handler
	tokenClaims, tokenError := tokenHandler.Verify(actionToken)
	log.Println("** after token claims", tokenClaims)

	return tokenClaims, tokenError
}

// Get validated role and add it to the user
func AddRealmRolesToInvitedUser(c *gin.Context, client *gocloak.GoCloak, adminToken string, realm string, userId string, allRoles []string) *models.ErrorResponse {
	roleToAdd := []gocloak.Role{}
	roles, err := client.GetRealmRoles(c, adminToken, realm, gocloak.GetRoleParams{})
	if err != nil {
		log.Print(err.Error())
		return &common.ErrorGetRealmRolesFailed
	}

	//filter for validated role
	validatedRole := FilterRealmRoles(roles, common.ValidatedRole)
	roleToAdd = append(roleToAdd, *validatedRole)

	// filter for user role
	userRole := FilterRealmRoles(roles, common.UserRole)
	roleToAdd = append(roleToAdd, *userRole)

	// filter for infra manager role
	infraManagerRole := FilterRealmRoles(roles, common.InfraManagerRole)

	// filter for customer manager role
	customerManagerRole := FilterRealmRoles(roles, common.CustomerManagerRole)

	// Add admin,publisher,consumer role if present
	for _, attrRole := range allRoles {
		if strings.ToLower(attrRole) == common.AdminRole {
			role := FilterRealmRoles(roles, common.AdminRole)
			if role != nil {
				roleToAdd = append(roleToAdd, *role)
			}
			roleToAdd = append(roleToAdd, *infraManagerRole)
			roleToAdd = append(roleToAdd, *customerManagerRole)
		} else if strings.ToLower(attrRole) == common.InfraManagerRole {
			roleToAdd = append(roleToAdd, *infraManagerRole)
		} else {
			roleToAdd = append(roleToAdd, *customerManagerRole)
		}
	}

	if len(roleToAdd) > 0 {
		if err := client.AddRealmRoleToUser(c, adminToken, realm, userId, roleToAdd); err != nil {
			return &common.ErrorAddRealmRolesFailed
		}
	}

	return nil
}

// filter role value based on roles input
func FilterRealmRoles(roles []*gocloak.Role, roleName string) *gocloak.Role {

	// Initialized variabls
	var roleDetails *gocloak.Role
	// find role present in roles array
	for _, role := range roles {
		if role.Name != nil && *role.Name == roleName {
			roleDetails = role
			break
		}
	}

	return roleDetails
}

// keycloakLoginUser Login to keycloak using admin
func KeycloakLoginUser(c *gin.Context, clientID string, realm string, config *config.Configuration, userName string, password string) (*gocloak.JWT, error) {
	client := gocloak.NewClient(config.Auth.Host)
	token, err := client.Login(c, clientID, "", realm, userName, password)
	if err != nil {
		fmt.Printf("LoginUser Error %s", err)
		return nil, err
	}
	return token, err
}

// keycloak get Access Token with Refresh Token
func KeycloakGetToken(c *gin.Context, clientID string, realm string, config *config.Configuration, refreshToken string) (*gocloak.JWT, error) {
	client := gocloak.NewClient(config.Auth.Host)
	token, err := client.RefreshToken(c, refreshToken, clientID, "", realm)
	if err != nil {
		fmt.Printf("RefreshToken Error %s", err)
		return nil, err
	}
	return token, err
}

// Generate header for  invited user list
func GenerateInvitedUserRowHeader(headers []string) string {
	rowHeaders := strings.Join(headers, ",")
	rowHeaders = rowHeaders + "\n"
	return rowHeaders
}

// Generate invited user list export body
func GenerateInvitedUserRowBody(userEntity response.UserProfileResp) string {
	var row strings.Builder
	row.WriteString(userEntity.Email + ",")
	row.WriteString(`"` + userEntity.AllowedRoles + `"` + ",")
	row.WriteString(userEntity.CreatedDate.Format("02 Jan 2006") + ",")
	row.WriteString(userEntity.CreatedBy + ",")
	row.WriteString(userEntity.State + ",")
	return row.String()
}

func GetUserAttribute(user gocloak.User, attribute string, defaultValue string) []string {
	userAttribute := (*user.Attributes)[attribute]

	if len(userAttribute) == 0 {
		userAttribute = []string{defaultValue}
	}

	return userAttribute
}

func ResetUserPassword(c *gin.Context, client *gocloak.GoCloak, admintoken gocloak.JWT, emailId string, realm string, password string, tokenRamdomString string) *models.ErrorResponse {
	// Create keycloak user object
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(emailId),
	}

	// Fetch keycloak user based on email
	fetchedUser, err := client.GetUsers(c, admintoken.AccessToken, realm, keycloakUser)
	if err != nil {
		return &common.ErrorGetKeycloakUserNotFound
	}

	// Get keycloak attributes
	userAttributes := *fetchedUser[0].Attributes
	if strings.TrimRight(tokenRamdomString, "\n") != userAttributes[RESET_PASSWORD_RANDOM_ATTRIBUTE][0] {
		println("NOT EQUAL")
		return &common.ErrorGenericFailure
	}

	// Reset attributes values in keycloak
	userAttributes[LOGIN_COUNT] = []string{"0"}
	userAttributes[RESET_PASSWORD_RANDOM_ATTRIBUTE] = []string{""}

	// Update keycloak user with new attribute values
	err = client.UpdateUser(c, admintoken.AccessToken, realm, *fetchedUser[0])
	if err != nil {
		return &common.ErrorUserAuthenticationFailed
	}

	// Set the new password given by user as input
	err = client.SetPassword(c, admintoken.AccessToken, *fetchedUser[0].ID, realm, password, false)
	if err != nil {
		fmt.Printf("resetPassword clientSetPassword err: %s", err.Error())
		return &common.ErrorServiceFailed
	}

	return nil
}

func UpdateUserAttributeResetPassword(c *gin.Context, client *gocloak.GoCloak, admintoken gocloak.JWT, emailId string, realm string) (string, *models.ErrorResponse) {
	// Create keycloak user object
	keycloakUser := gocloak.GetUsersParams{
		Email: gocloak.StringP(emailId),
	}

	// Fetch keycloak user based on email
	fetchedUser, err := client.GetUsers(c, admintoken.AccessToken, realm, keycloakUser)
	if err != nil {
		return "", &common.ErrorGetKeycloakUserNotFound
	}

	if len(fetchedUser) == 0 {
		return "", &common.ErrorGetKeycloakUserNotFound
	}

	// Update keycloak attributes and add reset password property
	user := *fetchedUser[0]
	if user.Attributes == nil {
		emptyAttributes := make(map[string][]string)
		user.Attributes = &emptyAttributes
	}
	randomString := uniuri.NewLen(30)
	(*user.Attributes)[RESET_PASSWORD_RANDOM_ATTRIBUTE] = []string{randomString}
	updateUserErr := client.UpdateUser(c, admintoken.AccessToken, realm, user)
	if updateUserErr != nil {
		fmt.Printf("Update user attribite err: %s", updateUserErr.Error())
		return "", &common.ErrorResetEmailFailed
	}

	return randomString, nil
}

func SendResetPasswordEmail(config *config.Configuration, c *gin.Context, randomString string, emailId string, sendUrl string) *models.ErrorResponse {
	// Generate signed action token
	actionToken, tokenError := GenerateSignedAccessToken(*config, randomString, emailId)
	if tokenError != nil {
		fmt.Printf("Generate Token err: %s", tokenError.Error())
		return &common.ErrorTokenGenerationFailed
	}

	// Generate verify link
	verifyLink := sendUrl + "/reset?actiontoken=" + actionToken

	// Send email url with reset password token attached with link
	sendEmailURL, err := url.Parse(config.Info.NotificationURL + "/send/mail/resetpass/" + url.PathEscape(emailId) + "?link=" + verifyLink)
	if err != nil {
		fmt.Printf("sendResetEmail urlParse err: %s", err.Error())
		return &common.ErrorGeneralFailure
	}

	// Send email using notification api
	sendEmailErr := SendEmailRequest(sendEmailURL)
	if sendEmailErr != nil {
		fmt.Printf("sendResetEmail sendEmailRequest err: %s", sendEmailErr.Error())
		return &common.ErrorServiceFailed
	}

	return nil
}

func GenerateNewOTP(user gocloak.User, c *gin.Context, config *config.Configuration, realm string) {
	client, adminToken, err := LoginAdmin(c, config)
	if err != nil {
		errMsg := fmt.Sprintf("generateNewOTP loginAdmin config err: %s", err.Error())
		helper.ErrorResponse(c, http.StatusBadRequest, common.ErrorServiceFailed, &errMsg)
		return
	}

	otp, _ := generateOTP(OTP_LENGTH)
	otpDuration, _ := strconv.Atoi(config.Auth.OtpDuration)
	otpExpiry := time.Now().Add(time.Second * time.Duration(otpDuration+5)).Format(time.RFC3339)

	(*user.Attributes)[OTP] = []string{otp, otpExpiry}
	client.UpdateUser(c, adminToken.AccessToken, realm, user)
	sendOtpNotification(c, config, gocloak.PString(user.Email), otp)
}

func generateOTP(length int) (string, error) {
	buffer := make([]byte, length)
	_, err := rand.Read(buffer)
	if err != nil {
		return "", err
	}

	otpCharsLength := len(otpChars)
	for i := 0; i < length; i++ {
		buffer[i] = otpChars[int(buffer[i])%otpCharsLength]
	}

	return string(buffer), nil
}

func CountryIndustryValidation(c *gin.Context, config *config.Configuration, country string, industry string) *models.ErrorResponse {
	if country == "" || industry == "" {
		return nil
	}

	if country != "" {
		// Country validation
		validcountry, apiErr := validCategory(config, c, FULL_COUNTRY, country, "")
		if apiErr != nil {
			errMsg := fmt.Sprintf("assetManagement isValidCategory API call error. Err: %s", apiErr.Error())
			err1 := common.ErrorServiceFailed
			err1.Error.AdditionalData = errMsg
			return &err1
		}
		if !validcountry {
			errMsg := "country is not a valid country"
			errResponse := &common.ErrorInvalidRequestInput
			errResponse.Error.AdditionalData = map[string]string{"country": errMsg}
			return errResponse
		}
	}

	if industry != "" {
		// Industry validation
		validIndustry, apiErr := validCategory(config, c, FULL_INDUSTRY, industry, "")
		if apiErr != nil {
			errMsg := fmt.Sprintf("assetManagement isValidCategory API call error. Err: %s", apiErr.Error())
			err1 := common.ErrorServiceFailed
			err1.Error.AdditionalData = errMsg
			return &err1
		}
		if !validIndustry {
			errMsg := "Industry is not a valid industry"
			errResponse := &common.ErrorInvalidRequestInput
			errResponse.Error.AdditionalData = map[string]string{"industry": errMsg}
			return errResponse
		}
	}
	return nil
}

func NewtworkAWSAccountRegionValidation(c *gin.Context, config *config.Configuration, network string, awsAccount string, region string) *models.ErrorResponse {
	if network == "" || awsAccount == "" || region == "" {
		return nil
	}

	if network != "" {
		// network validation
		valid, apiErr := validCategory(config, c, FULL_NETWORK, network, "")
		if apiErr != nil {
			errMsg := fmt.Sprintf("assetManagement isValidCategory API call error. Err: %s", apiErr.Error())
			err1 := common.ErrorServiceFailed
			err1.Error.AdditionalData = errMsg
			return &err1
		}
		if !valid {
			errMsg := "network is not a valid network"
			errResponse := &common.ErrorInvalidRequestInput
			errResponse.Error.AdditionalData = map[string]string{"network": errMsg}
			return errResponse
		}
	}

	if awsAccount != "" {
		// awsaccount validation
		valid, apiErr := validCategory(config, c, FULL_AWS_ACCOUNT, awsAccount, "")
		if apiErr != nil {
			errMsg := fmt.Sprintf("assetManagement isValidCategory API call error. Err: %s", apiErr.Error())
			err1 := common.ErrorServiceFailed
			err1.Error.AdditionalData = errMsg
			return &err1
		}
		if !valid {
			errMsg := "awsAccount is not a valid awsAccount"
			errResponse := &common.ErrorInvalidRequestInput
			errResponse.Error.AdditionalData = map[string]string{"awsAccount": errMsg}
			return errResponse
		}
	}

	if region != "" {
		// region validation
		valid, apiErr := validCategory(config, c, FULL_REGION, "", region)
		if apiErr != nil {
			errMsg := fmt.Sprintf("assetManagement isValidCategory API call error. Err: %s", apiErr.Error())
			err1 := common.ErrorServiceFailed
			err1.Error.AdditionalData = errMsg
			return &err1
		}
		if !valid {
			errMsg := "region is not a valid region"
			errResponse := &common.ErrorInvalidRequestInput
			errResponse.Error.AdditionalData = map[string]string{"region": errMsg}
			return errResponse
		}
	}

	return nil
}

func NewtworkSymbolValidation(c *gin.Context, config *config.Configuration, network string) *models.ErrorResponse {
	if network == "" {
		return nil
	}

	if network != "" {
		// network validation
		valid, apiErr := validCategory(config, c, FULL_NETWORK, network, "")
		if apiErr != nil {
			errMsg := fmt.Sprintf("assetManagement isValidCategory API call error. Err: %s", apiErr.Error())
			err1 := common.ErrorServiceFailed
			err1.Error.AdditionalData = errMsg
			return &err1
		}
		if !valid {
			errMsg := "network is not a valid network"
			errResponse := &common.ErrorInvalidRequestInput
			errResponse.Error.AdditionalData = map[string]string{"network": errMsg}
			return errResponse
		}
	}

	return nil
}

func validCategory(config *config.Configuration, c *gin.Context, category, name, key string) (bool, error) {
	var response models.SelectionOptionsResp
	rawUrl := config.AssetManagementURL + "/api/v1/general/isValidCategory" + "?category=" + category + "&name=" + name + "&key=" + key
	parsedUrl, _ := url.Parse(rawUrl)
	parsedUrl.RawQuery = parsedUrl.Query().Encode()
	apiResp, err := http.Get(parsedUrl.String())
	if err != nil {
		return false, fmt.Errorf("assetManagement isValidCategory API error. Err:: %s", err.Error())
	}

	defer apiResp.Body.Close()
	body, err := ioutil.ReadAll(apiResp.Body)
	if err != nil {
		return false, fmt.Errorf("assetManagement isValidCategory API ioutil ReadAll response error.Err:: %s", err.Error())
	}

	json.Unmarshal(body, &response)
	if response.IsValidCategory {
		return true, nil
	}
	return false, nil
}

func SelfInviteUserManagement(instanceName, customDomain, adminEmail, country string) (bool, error) {
	var response models.SelfInviteResp
	rawURL := fmt.Sprintf(selfInviteAPIURL, instanceName)

	if customDomain != "" {
		rawURL = fmt.Sprintf(selfInviteAPIURLForCustomDomain, customDomain)
	}
	requestBody := []byte(`{"email": "` + adminEmail + `", "country": "` + country + `"}`)

	apiResp, err := http.Post(rawURL, "application/json", bytes.NewBuffer(requestBody))
	if err != nil {
		return false, fmt.Errorf("userManagement self-invite API error. Err:: %s", err.Error())
	}

	if apiResp.StatusCode != http.StatusOK {
		return false, fmt.Errorf("userManagement self-invite API returned '%d'", apiResp.StatusCode)
	}

	defer apiResp.Body.Close()
	body, err := ioutil.ReadAll(apiResp.Body)
	if err != nil {
		return false, fmt.Errorf("userManagement self-invite API ioutil ReadAll response error.Err:: %s", err.Error())
	}

	json.Unmarshal(body, &response)
	if response.Invited {
		return true, nil
	}
	return false, nil
}

func StringInArray(str string, arr []string) bool {
	for _, b := range arr {
		if b == str {
			return true
		}
	}
	return false
}
