package utils

import (
	"fmt"
	"net/http"
	"net/url"
	"saas-management/config"

	"github.com/gin-gonic/gin"
)

func sendOtpNotification(c *gin.Context, config *config.Configuration, email string, otp string) error {
	return sendPutMail(c, config, "/send/otp/request_otp_saas/"+url.PathEscape(email)+"?otp="+otp)
}

func sendHttpRequest(req *http.Request) (*http.Response, error) {
	resp, err := http.DefaultClient.Do(req)

	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return resp, err
	}

	if resp.StatusCode >= 200 && resp.StatusCode <= 299 {
		fmt.Println("HTTP Status is in the 2xx range")
	} else {
		fmt.Printf("Send Email err")
		return resp, err
	}

	return resp, nil
}

func sendPutMail(c *gin.Context, config *config.Configuration, path string) error {
	sendEmailPath, err := getNotificationPath(config, path)
	if err != nil {
		return err
	}

	req, err := http.NewRequest("PUT", sendEmailPath, nil)

	if err != nil {
		fmt.Printf("Send Email err: %s", err.Error())
		return err
	}

	resp, err := sendHttpRequest(req)
	_ = resp
	if err != nil {
		return err
	}

	return nil
}

func getNotificationPath(config *config.Configuration, path string) (string, error) {
	sendEmailURL, err := url.Parse(config.Info.NotificationURL + path)
	if err != nil {
		fmt.Printf("Encode link err: %s", err.Error())
		return "", err
	}

	sendEmailURL.RawQuery = sendEmailURL.Query().Encode()
	return sendEmailURL.String(), nil
}
