package config

// Application Configuration
type Configuration struct {
	API
	Info
	Database
	Auth
	Role
	AWS_Prod
	AWS_Non_Prod
	Instance
}

// API configuration
type API struct {
	ListenAddress string
	Port          string
	CORS          struct {
		AllowOrigins []string
	}
}

// Auth configuration
type Info struct {
	ClientId           string
	Realm              string
	PortalURL          string
	PrivateKeyFile     string
	NotificationURL    string
	AssetManagementURL string
}

// Auth configuration
type Auth struct {
	Host                      string
	AdminUsername             string
	AdminPassword             string
	AdminRealm                string
	AdminClientId             string
	AdminClientSecret         string
	GrantType                 string
	VerificationTokenDuration string
	OtpDuration               string
}

// Role configuration
type Role struct {
	User      string
	Admin     string
	Validated string
}

type PostgresDBConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	DB       string
}

// Database configuration
type Database struct {
	Postgres   PostgresDBConfig
	KeycloakDb PostgresDBConfig
}

type AWS_Prod struct {
	Region string
	ARN    string
}
type AWS_Non_Prod struct {
	Region string
	ARN    string
}

type Instance struct {
	BasePath             string
	ReleaseNotesFileName string
	VersionFileName      string
	Bucket_Shared        string
	Bucket_Region        string
	PI_CronJobDuration   string
	FI_CronJobDuration   string
	DI_CronJobDuration   string
	PDVI_CronJobDuration string
	AI_CronJobDuration   string
	II_CronJobDuration   string
	VDI_CronJobDuration  string
	NDI_CronJobDuration  string
	EEI_CronJobDuration  string
}
