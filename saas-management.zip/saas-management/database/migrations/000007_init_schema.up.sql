ALTER TABLE instances
ADD
    is_ses_requested bool NOT NULL DEFAULT false;