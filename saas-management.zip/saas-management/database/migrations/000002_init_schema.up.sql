INSERT INTO saas_user_invitation (email, allowed_roles, state, created_by) values
('test.user@nagarro.com', 'admin', 'Invited', 'NAGARRO_TEST_SYSTEM');