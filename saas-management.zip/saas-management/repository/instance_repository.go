package repository

import (
	"errors"
	"fmt"
	"log"
	"saas-management/models"
	"saas-management/models/request"
	"strings"

	"github.com/jackc/pgx/v5/pgconn"
	"gorm.io/gorm"
)

type InstanceRepository interface {
	CreateInstance(customer *request.InstanceDetail, creatorEmail string, isSESRequested bool) (string, error)
	AddNetwork(customer *request.InstanceNetwork, instanceID uint) (string, error)
	GetInstanceDetail(email string) (*models.Instances, error)
	GetInstanceList(input *request.InstanceList) ([]models.Instances, int64, error)
	GetUniqueRegions() ([]string, error)
	GetUniqueInstanceCustomerNames() ([]string, error)
	IsUniqueCustomDomain(customDomain string) (bool, error)
	IsCustomerNameExist(string) (bool, error)
	IsSESDomainExist(string) (bool, error)
	IsSESDomainExistMoreThanOnce(string) (bool, error)
	GetProvisionedInstanceList() ([]models.Instances, int64, error)
	GetPendingDomainVerificationInstances() ([]models.Instances, int64, error)
	GetFinalizingInstances() ([]models.Instances, int64, error)
	GetDeletionInProgressInstances() ([]models.Instances, int64, error)
	UpdateInstanceStatus(uuid, status, remarks string) error
	UpdateInstanceStatusWithEmailPending(uuid, status, remarks string, emailPending bool) error
	UpdateInstanceRetrialStatus(uuid, buildID, remarks string) error
	UpdateInstanceDeleteID(uuid, buildID, remarks string) error
	UpdateInstanceDeleteStatus(uuid, status, buildStatus, remarks string) error
	DeleteInstanceByID(uuid string) error
	IsInstanceNameExist(name string) (bool, error)
	IsClusterExistForInstance(region string, accountType string, network string) (bool, error)
	UpdateInstanceInactivateID(uuid, buildID, remarks string) error
	UpdateInstanceInactivateStatus(uuid, status, remarks string) error
	UpdateInstanceBuildAndStatus(uuid string, req *models.UpdateInstanceRequest) error
	GetProvisionedInstanceListByStatus(status string) ([]models.Instances, int64, error)
	GetEmailEligibleInstanceList() ([]models.Instances, int64, error)
	GetCustomerDetailByName(name string) (*models.Customer, error)
	DeleteLastAddedNetwork() error
}

const (
	InstanceStatusProvisioned                 = "Provisioned"
	InstanceStatusPendingDomainVerification   = "Pending Domain Verification"
	InstanceStatusFinalizingInstance          = "Finalizing Instance"
	InstanceStatusFailed                      = "Build Failed"
	InstanceStatusDeletionFailed              = "Deletion Failed"
	InstanceStatusActivationFailed            = "Activation Failed"
	InstanceStatusInactivationFailed          = "Inactivation Failed"
	InstanceStatusNetworkDeploymentFailed     = "Network Deployment Failed"
	InstanceStatusVersionDeploymentFailed     = "Version Deployment Failed"
	InstanceStatusDeletionInProgress          = "Deletion In Progress"
	InstanceStatusInactivationInProgress      = "Inactivation In Progress"
	InstanceStatusActivationInProgress        = "Activation In Progress"
	InstanceStatusVersionDeploymentInProgress = "Version Deployment In Progress"
	InstanceStatusNetworkDeploymentInProgress = "Network Deployment In Progress"
	InstanceStatusInactive                    = "Inactive"
	InstanceStatusActive                      = "Active"
)

var SimilarStatuseMap = map[string][]string{
	InstanceStatusActive:                    {InstanceStatusActive},
	InstanceStatusInactive:                  {InstanceStatusInactive},
	InstanceStatusPendingDomainVerification: {InstanceStatusPendingDomainVerification},
	InstanceStatusFinalizingInstance:        {InstanceStatusFinalizingInstance},
	InstanceStatusProvisioned: {InstanceStatusProvisioned, InstanceStatusActivationInProgress, InstanceStatusInactivationInProgress,
		InstanceStatusDeletionInProgress, InstanceStatusVersionDeploymentInProgress, InstanceStatusNetworkDeploymentInProgress},
	InstanceStatusFailed: {InstanceStatusFailed, InstanceStatusDeletionFailed, InstanceStatusActivationFailed, InstanceStatusInactivationFailed,
		InstanceStatusNetworkDeploymentFailed, InstanceStatusVersionDeploymentFailed},
}

func NewInstanceRepository(db *gorm.DB) InstanceRepository {
	return &instanceRepository{Db: db}
}

type instanceRepository struct {
	Db *gorm.DB
}

func (ir *instanceRepository) CreateInstance(cus *request.InstanceDetail, creatorEmail string, isSESRequested bool) (string, error) {
	instanceNetwork := models.Networks{
		Decimal:      cus.Decimal,
		TokenSymbol:  cus.TokenSymbol,
		TokenAddress: cus.TokenAddress,
		Network:      cus.Network,
	}
	instance := &models.Instances{
		BuildID:           cus.BuildID,
		CreatedBy:         creatorEmail,
		UpdatedBy:         creatorEmail,
		Name:              cus.Name,
		CustomerName:      cus.CustomerName,
		Description:       cus.Description,
		Region:            cus.Region,
		ContactEmail:      cus.ContactEmail,
		AwsAccount:        cus.AWSAccount,
		CustomDomain:      cus.CustomDomain,
		CustomEmailDomain: cus.CustomEmailDomain,
		NetworkRecords:    []models.Networks{instanceNetwork},
		Version:           cus.Version,
		Status:            InstanceStatusProvisioned,
		IsSesRequested:    isSESRequested,
	}

	err := ir.Db.Create(instance).Error
	if err != nil {
		// Check if err is of type *pgconn.PgError and error code is 23505, which is the error code for unique_violation
		if pgErr, ok := err.(*pgconn.PgError); ok && pgErr.Code == "23505" {
			return "", errors.New("instance name already exists")
		}
		return "", err
	}
	return instance.UUID.String(), nil
}

func (ir *instanceRepository) AddNetwork(req *request.InstanceNetwork, instanceID uint) (string, error) {
	var id string
	sqlString := "INSERT INTO networks (instances_id,decimal,token_symbol,token_address,network) VALUES (?,?,?,?,?) Returning uuid"
	if err := ir.Db.Raw(sqlString, instanceID, req.Decimal, req.TokenSymbol, req.TokenAddress, req.Network).Scan(&id).Error; err != nil {
		return "", err
	}
	fmt.Printf("\n ID: %s\n", id)
	return id, nil
}

func (ir *instanceRepository) GetInstanceDetail(id string) (*models.Instances, error) {
	instance := &models.Instances{}
	err := ir.Db.Preload("NetworkRecords").Where("uuid = ?", id).First(instance).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("instance '%s' not found", id)
		}
		return nil, err
	}
	return instance, nil
}

func (ir *instanceRepository) GetInstanceList(searchParmas *request.InstanceList) ([]models.Instances, int64, error) {
	// Initialized variables
	var instances []models.Instances
	var totalResult int64
	instanceListTxn := ir.Db.Preload("NetworkRecords").Model(&models.Instances{})

	// return similar group statused instances
	if searchParmas.StatusTab != "" {
		similar, exists := SimilarStatuseMap[searchParmas.StatusTab]
		if !exists {
			return nil, -1, fmt.Errorf("'%s' is invalid statusTab", searchParmas.StatusTab)
		}
		instanceListTxn.Where("status IN ?", similar)
	}

	// If name param is present
	if searchParmas.Name != "" {
		instanceListTxn.Where("LOWER(name) LIKE ?", "%"+strings.ToLower(searchParmas.Name)+"%")
	}

	// If customer name param is present
	if len(searchParmas.CustomerNames) > 0 {
		filterForCombinedQuery(instanceListTxn, "customer_name", searchParmas.CustomerNames)
	}

	// If customer name param is present
	if len(searchParmas.Regions) > 0 {
		filterForCombinedQuery(instanceListTxn, "region", searchParmas.Regions)
	}

	// sortBy or sortOrder as params
	orderBySerachColumns(instanceListTxn, searchParmas.SortBy, searchParmas.SortOrder)

	// Get total count of result
	instanceListTxn.Count(&totalResult)

	// Apply pagination on the result
	offset := (searchParmas.Page - 1) * searchParmas.NumberRecords
	offsetErr := instanceListTxn.Limit(searchParmas.NumberRecords).Offset(offset).Find(&instances).Error
	if offsetErr != nil {
		fmt.Printf("offsetErr: %v\n", offsetErr)
		return nil, -1, offsetErr
	}

	return instances, totalResult, nil
}

func (ir *instanceRepository) GetProvisionedInstanceList() ([]models.Instances, int64, error) {
	return ir.GetProvisionedInstanceListByStatus(InstanceStatusProvisioned)
}

func (ir *instanceRepository) GetPendingDomainVerificationInstances() ([]models.Instances, int64, error) {
	return ir.GetProvisionedInstanceListByStatus(InstanceStatusPendingDomainVerification)
}

func (ir *instanceRepository) GetFinalizingInstances() ([]models.Instances, int64, error) {
	return ir.GetProvisionedInstanceListByStatus(InstanceStatusFinalizingInstance)
}

func (ir *instanceRepository) GetDeletionInProgressInstances() ([]models.Instances, int64, error) {
	return ir.GetProvisionedInstanceListByStatus(InstanceStatusDeletionInProgress)
}

func (ir *instanceRepository) GetEmailEligibleInstanceList() ([]models.Instances, int64, error) {
	// Initialized variables
	var instances []models.Instances
	var totalResult int64
	instanceListTxn := ir.Db.Preload("NetworkRecords").Model(&models.Instances{})

	// Get total count of result
	err := instanceListTxn.Where("status = ? AND email_pending = true", InstanceStatusActive).Order("created_at asc").Count(&totalResult).Find(&instances).Error
	if err != nil {
		return nil, -1, err
	}

	return instances, totalResult, nil
}

func (ir *instanceRepository) GetProvisionedInstanceListByStatus(status string) ([]models.Instances, int64, error) {
	// Initialized variables
	var instances []models.Instances
	var totalResult int64
	instanceListTxn := ir.Db.Preload("NetworkRecords").Model(&models.Instances{})

	// Get total count of result
	err := instanceListTxn.Where("status = ?", status).Order("created_at asc").Count(&totalResult).Find(&instances).Error
	if err != nil {
		return nil, -1, err
	}

	return instances, totalResult, nil
}

func (ir *instanceRepository) GetUniqueRegions() ([]string, error) {
	var result []string
	tx := ir.Db.Table("instances").Order("region asc")
	tx.Select("DISTINCT region")
	rows, err := tx.Rows()

	if err != nil {
		return nil, err
	}

	// Get all rows of countries
	defer rows.Close()
	for rows.Next() {
		var countryItem string
		tx.ScanRows(rows, &result)
		result = append(result, countryItem)
	}

	// Remove the last null element
	if len(result) > 0 {
		result = result[:len(result)-1]
	}

	return result, nil
}

func (cr *instanceRepository) GetCustomerDetailByName(name string) (*models.Customer, error) {
	var customer models.Customer
	err := cr.Db.Table("customers").Where("name = ?", name).First(&customer).Error
	return &customer, err
}

func (ir *instanceRepository) GetUniqueInstanceCustomerNames() ([]string, error) {
	var result []string
	tx := ir.Db.Table("instances").Order("customer_name asc")
	tx.Select("DISTINCT customer_name")

	rows, err := tx.Rows()
	if err != nil {
		return nil, err
	}

	// Get all rows
	defer rows.Close()
	for rows.Next() {
		var countryItem string
		tx.ScanRows(rows, &result)
		result = append(result, countryItem)
	}

	// Remove the last null element
	if len(result) > 0 {
		result = result[:len(result)-1]
	}

	return result, nil
}

func (ir *instanceRepository) IsUniqueCustomDomain(customDomain string) (bool, error) {
	var instance models.Instances
	err := ir.Db.Where("custom_domain = ?", customDomain).First(&instance).Error
	if err != nil {
		return false, err
	}

	if instance.Name != "" {
		return true, nil
	}

	return false, nil
}

func (ir *instanceRepository) IsCustomerNameExist(customerName string) (bool, error) {
	var customer models.Customer
	err := ir.Db.Table("customers").Where("name = ?", customerName).First(&customer).Error
	if err != nil {
		return false, err
	}

	if customer != (models.Customer{}) {
		return true, nil
	}

	return false, nil
}

func (ir *instanceRepository) IsSESDomainExist(sesDomain string) (bool, error) {
	var ins models.Instances
	err := ir.Db.Where("custom_email_domain = ?", sesDomain).First(&ins).Error
	if err != nil {
		return false, err
	}

	if ins.ID != 0 {
		return true, nil
	}

	return false, nil
}

func (ir *instanceRepository) IsSESDomainExistMoreThanOnce(sesDomain string) (bool, error) {
	var ins []models.Instances
	err := ir.Db.Where("custom_email_domain = ? and status != ?", sesDomain, InstanceStatusDeletionInProgress).Find(&ins).Error
	if err != nil {
		return false, err
	}

	if len(ins) > 1 {
		return true, nil
	}

	return false, nil
}

func (ir *instanceRepository) IsInstanceNameExist(name string) (bool, error) {
	var ins models.Instances
	err := ir.Db.Where("name = ?", name).First(&ins).Error
	if err != nil {
		return false, err
	}

	if ins.ID != 0 {
		return true, nil
	}

	return false, nil
}

func (ir *instanceRepository) IsClusterExistForInstance(region string, accountType string, network string) (bool, error) {
	var cls []models.Clusters
	clusterDetailsTxn := ir.Db.Table("clusters as cls").Joins("INNER JOIN cluster_networks as cnet on cnet.clusters_id = cls.id")
	err := clusterDetailsTxn.Where("LOWER(cls.region) = ? and cls.aws_account = ? and cnet.network = ? and cls.status = ?", strings.ToLower(region), accountType, network, ClusterSimilarStatuseMap[ClusterStatusActive]).Find(&cls).Error
	if err != nil {
		return false, err
	}

	if len(cls) > 0 {
		return true, nil
	}

	return false, nil
}

func (ir *instanceRepository) UpdateInstanceStatus(uuid, status, remarks string) error {
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("status", status)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (ir *instanceRepository) UpdateInstanceStatusWithEmailPending(uuid, status, remarks string, emailPending bool) error {
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("status", status).UpdateColumn("email_pending", emailPending)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (ir *instanceRepository) UpdateInstanceRetrialStatus(uuid, buildID, remarks string) error {
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("retry_flag", 1).UpdateColumn("build_id", buildID)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (ir *instanceRepository) UpdateInstanceDeleteID(uuid, buildID, remarks string) error {
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("delete_build_id", buildID).UpdateColumn("status", InstanceStatusDeletionInProgress)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (ir *instanceRepository) UpdateInstanceDeleteStatus(uuid, status, buildStatus, remarks string) error {
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("delete_status", buildStatus).UpdateColumn("status", status)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (ir *instanceRepository) UpdateInstanceInactivateID(uuid, buildID, remarks string) error {
	log.Printf("\nUpdateInstanceInactivateID: uuid: %s inactivate_buildId :%s status: %s\n", uuid, buildID, InstanceStatusInactivationInProgress)
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("inactive_build_id", buildID).UpdateColumn("status", InstanceStatusInactivationInProgress)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (ir *instanceRepository) UpdateInstanceBuildAndStatus(uuid string, req *models.UpdateInstanceRequest) error {
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("status", req.Status).UpdateColumn("build_id", req.BuildID)
	if req.Remarks != "" {
		tx.UpdateColumn("build_remarks", req.Remarks)
	}
	if req.Version != "" {
		tx.UpdateColumn("version", req.Version)
	}
	return tx.Error
}

func (ir *instanceRepository) UpdateInstanceInactivateStatus(uuid, status, remarks string) error {
	tx := ir.Db.Table("instances").Where("uuid = ?", uuid).UpdateColumn("inactive_status", status)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (ir *instanceRepository) DeleteInstanceByID(uuid string) error {
	// Find the instance record by uuid
	var instance models.Instances
	if err := ir.Db.Unscoped().Where("uuid = ?", uuid).First(&instance).Error; err != nil {
		return err // Instance not found
	}

	// Delete the associated networks
	if err := ir.Db.Unscoped().Where("instances_id = ?", instance.ID).Delete(&models.Networks{}).Error; err != nil {
		return err // Error deleting associated networks
	}

	// Delete the instance itself
	if err := ir.Db.Unscoped().Delete(&instance).Error; err != nil {
		return err // Error deleting instance
	}

	return nil
}

// Method to delete latest (last added) network in networks table
func (ir *instanceRepository) DeleteLastAddedNetwork() error {
	// Delete latest network
	var network models.Networks
	if err := ir.Db.Order("created_at desc").First(&network).Delete(&network).Error; err != nil {
		return err // Error deleting latest network
	}

	return nil
}
