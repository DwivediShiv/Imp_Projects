package repository

import (
	"errors"
	"fmt"
	"saas-management/models"
	"saas-management/models/request"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgconn"
	"gorm.io/gorm"
)

type ClusterRepository interface {
	CreateCluster(cluster *request.ClusterDetail, creatorEmail string) (string, error)
	AddNetwork(customer *request.ClusterNetwork, clusterID uint) (string, error)
	GetClusterDetail(clusterId string) (*models.Clusters, error)
	GetClusterList(input *request.ClusterList) ([]models.Clusters, int64, error)
	GetUniqueClusterRegions() ([]string, error)
	GetProvisionedClusterList() ([]models.Clusters, int64, error)
	GetDeletionInProgressClusters() ([]models.Clusters, int64, error)
	UpdateClusterStatus(uuid, status, remarks string) error
	UpdateClusterDeleteID(uuid, buildID, remarks string) error
	UpdateClusterDeleteStatus(uuid, status, buildStatus, remarks string) error
	IsClusterNameExist(name string, accountType string) (bool, error)
	IsInstanceExistsInRegion(region string, accountType string) (bool, error)
	IsClusterExistsInRegion(region string, accountType string) (bool, error)
	UpdateClusterBuildAndStatus(uuid string, req *models.UpdateClusterRequest) error
	GetProvisionedClusterListByStatus(status string) ([]models.Clusters, int64, error)
	DeleteLastAddedClusterNetwork() error
	GetNumberOfInstancesInClusterRegion(region string, accountType string) (int, error)
}

const (
	ClusterStatusProvisioned                 = "Provisioned"
	ClusterStatusFailed                      = "Build Failed"
	ClusterStatusDeletionFailed              = "Deletion Failed"
	ClusterStatusNetworkDeploymentFailed     = "Network Deployment Failed"
	ClusterStatusVersionDeploymentFailed     = "Version Deployment Failed"
	ClusterStatusDeletionInProgress          = "Deletion In Progress"
	ClusterStatusDeleted                     = "Deleted"
	ClusterStatusVersionDeploymentInProgress = "Version Deployment In Progress"
	ClusterStatusNetworkDeploymentInProgress = "Network Deployment In Progress"
	ClusterStatusActive                      = "Active"
	ClusterStatusDeletion                    = "Deletion"
	ClusterStatusInProgress                  = "InProgress"
)

var ClusterSimilarStatuseMap = map[string][]string{
	ClusterStatusActive: {ClusterStatusActive},
	ClusterStatusProvisioned: {ClusterStatusProvisioned,
		ClusterStatusVersionDeploymentInProgress, ClusterStatusNetworkDeploymentInProgress},
	ClusterStatusFailed: {ClusterStatusFailed, ClusterStatusDeletionFailed,
		ClusterStatusNetworkDeploymentFailed, ClusterStatusVersionDeploymentFailed},
	ClusterStatusDeleted:            {ClusterStatusDeleted},
	ClusterStatusDeletionInProgress: {ClusterStatusDeletionInProgress},
	ClusterStatusDeletion:           {ClusterStatusDeleted, ClusterStatusDeletionInProgress},
	ClusterStatusInProgress: {ClusterStatusProvisioned,
		ClusterStatusVersionDeploymentInProgress, ClusterStatusNetworkDeploymentInProgress, ClusterStatusDeletionInProgress},
}

func NewClusterRepository(db *gorm.DB) ClusterRepository {
	return &clusterRepository{Db: db}
}

type clusterRepository struct {
	Db *gorm.DB
}

func (cr *clusterRepository) CreateCluster(cus *request.ClusterDetail, creatorEmail string) (string, error) {
	clusterNetwork := models.ClusterNetworks{
		Network: cus.Network,
	}
	cluster := &models.Clusters{
		BuildID:        cus.BuildID,
		CreatedBy:      creatorEmail,
		UpdatedBy:      creatorEmail,
		Name:           cus.Name,
		Region:         cus.Region,
		AwsAccount:     cus.AWSAccount,
		NetworkRecords: []models.ClusterNetworks{clusterNetwork},
		Version:        cus.Version,
		Status:         ClusterStatusProvisioned,
	}

	err := cr.Db.Create(cluster).Error
	if err != nil {
		// Check if err is of type *pgconn.PgError and error code is 23505, which is the error code for unique_violation
		if pgErr, ok := err.(*pgconn.PgError); ok && pgErr.Code == "23505" {
			return "", errors.New("cluster name already exists")
		}
		return "", err
	}
	return cluster.UUID.String(), nil
}

func (cr *clusterRepository) AddNetwork(req *request.ClusterNetwork, clusterID uint) (string, error) {
	var id string
	sqlString := "INSERT INTO cluster_networks (clusters_id,network) VALUES (?,?) Returning uuid"
	if err := cr.Db.Raw(sqlString, clusterID, req.Network).Scan(&id).Error; err != nil {
		return "", err
	}
	fmt.Printf("\n ID: %s\n", id)
	return id, nil
}

func (cr *clusterRepository) GetClusterDetail(clusterId string) (*models.Clusters, error) {
	cluster := &models.Clusters{}
	err := cr.Db.Preload("NetworkRecords").Where("uuid = ?", clusterId).First(cluster).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("cluster '%s' not found", clusterId)
		}
		return nil, err
	}
	return cluster, nil
}

func (cr *clusterRepository) GetClusterList(searchParmas *request.ClusterList) ([]models.Clusters, int64, error) {
	// Initialized variables
	var clusters []models.Clusters
	var totalResult int64
	clusterListTxn := cr.Db.Preload("NetworkRecords").Model(&models.Clusters{})

	// return similar group statused clusters
	if searchParmas.StatusTab != "" {
		similar, exists := ClusterSimilarStatuseMap[searchParmas.StatusTab]
		if !exists {
			return nil, -1, fmt.Errorf("'%s' is invalid statusTab", searchParmas.StatusTab)
		}
		clusterListTxn.Where("status IN ?", similar)
	}

	// If name param is present
	if searchParmas.Name != "" {
		clusterListTxn.Where("LOWER(name) LIKE ?", "%"+strings.ToLower(searchParmas.Name)+"%")
	}

	// If customer name param is present
	if len(searchParmas.Regions) > 0 {
		filterForCombinedQuery(clusterListTxn, "region", searchParmas.Regions)
	}

	// sortBy or sortOrder as params
	orderBySerachColumns(clusterListTxn, searchParmas.SortBy, searchParmas.SortOrder)

	// Get total count of result
	clusterListTxn.Count(&totalResult)

	// Apply pagination on the result
	offset := (searchParmas.Page - 1) * searchParmas.NumberRecords
	offsetErr := clusterListTxn.Limit(searchParmas.NumberRecords).Offset(offset).Find(&clusters).Error
	if offsetErr != nil {
		fmt.Printf("offsetErr: %v\n", offsetErr)
		return nil, -1, offsetErr
	}

	return clusters, totalResult, nil
}

func (cr *clusterRepository) GetProvisionedClusterList() ([]models.Clusters, int64, error) {
	return cr.GetProvisionedClusterListByStatus(ClusterStatusProvisioned)
}

func (cr *clusterRepository) GetDeletionInProgressClusters() ([]models.Clusters, int64, error) {
	return cr.GetProvisionedClusterListByStatus(ClusterStatusDeletionInProgress)
}

func (cr *clusterRepository) GetProvisionedClusterListByStatus(status string) ([]models.Clusters, int64, error) {
	// Initialized variables
	var clusters []models.Clusters
	var totalResult int64
	clusterListTxn := cr.Db.Preload("NetworkRecords").Model(&models.Clusters{})

	// Get total count of result
	err := clusterListTxn.Where("status = ?", status).Order("created_at asc").Count(&totalResult).Find(&clusters).Error
	if err != nil {
		return nil, -1, err
	}

	return clusters, totalResult, nil
}

func (cr *clusterRepository) GetUniqueClusterRegions() ([]string, error) {
	var result []string
	tx := cr.Db.Table("clusters").Order("region asc")
	tx.Select("DISTINCT region")
	rows, err := tx.Rows()

	if err != nil {
		return nil, err
	}

	// Get all rows of countries
	defer rows.Close()
	for rows.Next() {
		var region string
		tx.ScanRows(rows, &result)
		result = append(result, region)
	}

	// Remove the last null element
	if len(result) > 0 {
		result = result[:len(result)-1]
	}

	return result, nil
}

func (cr *clusterRepository) IsClusterNameExist(name string, accountType string) (bool, error) {
	var cls models.Clusters
	err := cr.Db.Where("name = ? and aws_account = ? and status not IN ?", name, accountType, ClusterSimilarStatuseMap[ClusterStatusDeletion]).First(&cls).Error
	if err != nil {
		return false, err
	}

	if cls.ID != 0 {
		return true, nil
	}

	return false, nil
}

func (cr *clusterRepository) IsInstanceExistsInRegion(region string, accountType string) (bool, error) {
	var ins []models.Instances
	err := cr.Db.Where("LOWER(region) = ? and aws_account = ?", strings.ToLower(region), accountType).Find(&ins).Error
	if err != nil {
		return false, err
	}

	if len(ins) > 0 {
		return true, nil
	}

	return false, nil
}

func (cr *clusterRepository) IsClusterExistsInRegion(region string, accountType string) (bool, error) {
	var ins []models.Clusters
	err := cr.Db.Where("LOWER(region) = ? and aws_account = ? and status not IN ?", strings.ToLower(region), accountType, ClusterSimilarStatuseMap[ClusterStatusDeletion]).Find(&ins).Error
	if err != nil {
		return false, err
	}

	if len(ins) > 0 {
		return true, nil
	}

	return false, nil
}

func (cr *clusterRepository) UpdateClusterStatus(uuid, status, remarks string) error {
	tx := cr.Db.Table("clusters").Where("uuid = ?", uuid).UpdateColumn("status", status)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

// Method to update cluster delete id
func (cr *clusterRepository) UpdateClusterDeleteID(uuid, buildID, remarks string) error {
	tx := cr.Db.Table("clusters").Where("uuid = ?", uuid).UpdateColumn("delete_build_id", buildID).UpdateColumn("status", ClusterStatusDeletionInProgress)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (cr *clusterRepository) UpdateClusterDeleteStatus(uuid, status, buildStatus, remarks string) error {
	tx := cr.Db.Table("clusters").Where("uuid = ?", uuid).UpdateColumn("delete_status", buildStatus).UpdateColumn("status", status)
	if remarks != "" {
		tx.UpdateColumn("build_remarks", remarks)
	}
	return tx.Error
}

func (cr *clusterRepository) UpdateClusterBuildAndStatus(uuid string, req *models.UpdateClusterRequest) error {
	tx := cr.Db.Table("clusters").Where("uuid = ?", uuid).UpdateColumn("status", req.Status).UpdateColumn("build_id", req.BuildID).UpdateColumn("updated_at", time.Now())
	if req.Remarks != "" {
		tx.UpdateColumn("build_remarks", req.Remarks)
	}
	if req.Version != "" {
		tx.UpdateColumn("version", req.Version)
	}
	return tx.Error
}

// Method to delete latest (last added) network in cluster_networks table
func (cr *clusterRepository) DeleteLastAddedClusterNetwork() error {
	// Delete latest network
	var network models.ClusterNetworks
	if err := cr.Db.Order("created_at desc").First(&network).Delete(&network).Error; err != nil {
		return err // Error deleting latest network
	}

	return nil
}

// Method to get instances in cluster region and accountType
func (cr *clusterRepository) GetNumberOfInstancesInClusterRegion(region string, accountType string) (int, error) {
	var ins []models.Instances
	err := cr.Db.Where("LOWER(region) = ? and aws_account = ?", strings.ToLower(region), accountType).Find(&ins).Error
	if err != nil {
		return 0, err
	}
	return len(ins), nil
}
