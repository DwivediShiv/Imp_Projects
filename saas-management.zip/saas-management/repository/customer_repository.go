package repository

import (
	"errors"
	"fmt"
	"saas-management/common"
	"saas-management/models"
	"saas-management/models/request"
	"strings"

	"github.com/jackc/pgx/v5/pgconn"
	"gorm.io/gorm"
)

type CustomerRepository interface {
	CreateCustomer(customer *request.CustomerDetail, creatorEmail string) (string, *models.ErrorResponse)
	GetCustomerDetail(email string) (*models.Customer, error)
	GetCustomerList(input *request.CustomerList) ([]models.Customer, int64, error)
	GetCustomerNameList(input *request.CustomerNameList) ([]models.Customer, int64, error)
	GetUniqueCountries() ([]string, error)
	GetOrgUniqueIndustries() ([]string, error)
	UpdateCustomerStatus(id, status string) error
	DeleteCustomer(id string) error
}

func NewCustomerRepository(db *gorm.DB) CustomerRepository {
	return &customerRepository{Db: db}
}

type customerRepository struct {
	Db *gorm.DB
}

func (cr *customerRepository) CreateCustomer(cus *request.CustomerDetail, creatorEmail string) (string, *models.ErrorResponse) {
	customer := &models.Customer{
		CreatedBy:      creatorEmail,
		UpdatedBy:      creatorEmail,
		Name:           cus.Name,
		BusinessNumber: cus.BusinessNumber,
		Address:        cus.Address,
		Description:    cus.Description,
		Country:        cus.Country,
		ContactEmail:   cus.ContactEmail,
		Industry:       cus.Industry,
		Status:         "Active",
	}

	err := cr.Db.Create(customer).Error
	if err != nil {
		// Check if err is of type *pgconn.PgError and error code is 23505, which is the error code for unique_violation
		if pgErr, ok := err.(*pgconn.PgError); ok && pgErr.Code == common.UniqueKeyViolationCode {
			msg := pgErr.Error()
			for constraint, errMsg := range common.CustomerUniqueConstraintMap {
				if strings.Contains(msg, constraint) {
					err1 := common.ErrorEntryAlreadyExist
					err1.Error.AdditionalData = errMsg
					return "", &err1
				}
			}
		}
		err1 := common.ErrorServiceFailed
		err1.Error.AdditionalData = err.Error()
		return "", &err1
	}
	return customer.UUID.String(), nil
}

func (cr *customerRepository) GetCustomerDetail(id string) (*models.Customer, error) {
	customer := &models.Customer{}
	err := cr.Db.Where("uuid = ?", id).First(customer).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("customer '%s' not found", id)
		}
		return nil, err
	}
	return customer, nil
}

func (cr *customerRepository) GetCustomerList(userSearchParams *request.CustomerList) ([]models.Customer, int64, error) {
	// Initialized variables
	var customers []models.Customer
	var totalResult int64
	customerListTxn := cr.Db.Table("customers")

	// If name param is present
	if userSearchParams.Name != "" {
		customerListTxn.Where("LOWER(name) LIKE ?", "%"+strings.ToLower(userSearchParams.Name)+"%")
	}

	// If email param is present
	if len(userSearchParams.Countries) > 0 {
		filterForInQueryCaseInsensitive(customerListTxn, "country", userSearchParams.Countries)
	}

	// If state param is present
	if len(userSearchParams.Industries) > 0 {
		filterForInQueryCaseInsensitive(customerListTxn, "industry", userSearchParams.Industries)
	}

	// sortBy or sortOrder as params
	orderBySerachColumns(customerListTxn, userSearchParams.SortBy, userSearchParams.SortOrder)

	// Get total count of result
	customerListTxn.Count(&totalResult)

	// Apply pagination on the result
	offset := (userSearchParams.Page - 1) * userSearchParams.NumberRecords
	rows, offsetErr := customerListTxn.Limit(userSearchParams.NumberRecords).Offset(offset).Select("*").Rows()
	if offsetErr != nil {
		return nil, -1, offsetErr
	}

	defer rows.Close()
	for rows.Next() {
		var customer models.Customer
		customerListTxn.ScanRows(rows, &customer)
		customers = append(customers, customer)
	}

	return customers, totalResult, nil
}

func (cr *customerRepository) GetCustomerNameList(userSearchParams *request.CustomerNameList) ([]models.Customer, int64, error) {
	// Initialized variables
	var customers []models.Customer
	var totalResult int64
	customerListTxn := cr.Db.Table("customers").Where("status!= 'Inactive'")

	// sortBy or sortOrder as params
	orderBySerachColumns(customerListTxn, userSearchParams.SortBy, userSearchParams.SortOrder)

	// Get total count of result
	customerListTxn.Count(&totalResult)

	// Apply pagination on the result
	offset := (userSearchParams.Page - 1) * userSearchParams.NumberRecords
	rows, offsetErr := customerListTxn.Limit(userSearchParams.NumberRecords).Offset(offset).Select("name,uuid").Rows()
	if offsetErr != nil {
		return nil, -1, offsetErr
	}

	defer rows.Close()
	for rows.Next() {
		var customer models.Customer
		customerListTxn.ScanRows(rows, &customer)
		customers = append(customers, customer)
	}

	return customers, totalResult, nil
}

func orderBySerachColumns(tx *gorm.DB, sortBy, sortOrder string) {

	// Defualt value set
	if sortBy == "" {
		sortBy = "created_at"
	}
	if sortOrder == "" {
		sortOrder = "desc"
	}

	// Get sort order in param
	tx.Order(sortBy + " " + sortOrder)
}

func (cr *customerRepository) UpdateCustomerStatus(id, status string) error {
	return cr.Db.Table("customers").Where("uuid = ?", id).Update("status", status).Error
}

//

func (cr *customerRepository) DeleteCustomer(id string) error {
	return cr.Db.Exec("DELETE FROM customers WHERE uuid = ?", id).Error
}

// Get all existing countries in org table
func (cr *customerRepository) GetUniqueCountries() ([]string, error) {
	var result []string
	tx := cr.Db.Table("customers").Order("country asc")
	tx.Select("DISTINCT country")
	tx.Where("country is not null")
	rows, err := tx.Rows()

	if err != nil {
		return nil, err
	}

	// Get all rows of countries
	defer rows.Close()
	for rows.Next() {
		var countryItem string
		tx.ScanRows(rows, &result)
		result = append(result, countryItem)
	}

	// Remove the last null element
	if len(result) > 0 {
		result = result[:len(result)-1]
	}

	return result, nil
}

// Get all existing industries in org table
func (cr *customerRepository) GetOrgUniqueIndustries() ([]string, error) {
	var result []string
	tx := cr.Db.Table("customers").Order("industry asc")
	tx.Select("DISTINCT industry")
	tx.Where("industry is not null")
	rows, err := tx.Rows()

	if err != nil {
		return nil, err
	}

	// Get all rows of countries
	defer rows.Close()
	for rows.Next() {
		var countryItem string
		tx.ScanRows(rows, &result)
		result = append(result, countryItem)
	}

	// Remove the last null element
	if len(result) > 0 {
		result = result[:len(result)-1]
	}

	return result, nil
}
