package repository

import (
	"saas-management/common"
	"saas-management/models"
	"saas-management/models/request"
	"saas-management/models/response"
	"strings"

	"gorm.io/gorm"
)

type SaasUserRepository interface {
	IsEmailPresentInDB(email string) (bool, error)
	SaveSaasUser(newUserData models.SaasUserProfile) error
	GetUserDetailsFromDB(email string, model interface{}) error
	GetUserDetailsByProfileIdFromDB(profileId string, model interface{}) error
	UpdateUserRolesByProfileID(profileId string, roles string) error
	UpdateSaasUserState(userReqEmail string, saasUserProfile models.SaasUserProfile) error
	DeleteSaasUser(userReqEmail string) error
	InvitedUserListFromDB(userSearchParams request.SearchInvitedUser, adminEmail string) ([]response.UserProfileResp, int64, error)
}

func NewSaasUserRepository(db *gorm.DB) SaasUserRepository {
	return saasUserRepository{
		userDb: db,
	}
}

type saasUserRepository struct {
	userDb *gorm.DB
}

func (i saasUserRepository) IsEmailPresentInDB(email string) (bool, error) {
	var count int64
	err := i.userDb.Table("saas_user_invitation as iui").Where("iui.email = ?", email).Count(&count).Error

	return count > 0, err
}

func (i saasUserRepository) SaveSaasUser(newUserData models.SaasUserProfile) error {
	err := i.userDb.Transaction(func(tx *gorm.DB) error {
		err := i.userDb.Table("saas_user_invitation").Create(&newUserData).Error
		return err
	})
	return err
}

func (i saasUserRepository) UpdateUserRolesByProfileID(profileID string, roles string) error {
	err := i.userDb.Transaction(func(tx *gorm.DB) error {
		err := i.userDb.Table("saas_user_invitation").Where("profile_id = ?", profileID).UpdateColumn("allowed_roles", roles).Error
		return err
	})
	return err
}

func (i saasUserRepository) GetUserDetailsFromDB(email string, model interface{}) error {
	userProfileTxn := i.userDb.Table("saas_user_invitation as iui").Select("*").Where("iui.email = ?", email)
	rows, err := userProfileTxn.Rows()

	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		userProfileTxn.ScanRows(rows, model)
	}

	return nil
}

func (i saasUserRepository) GetUserDetailsByProfileIdFromDB(profileId string, model interface{}) error {
	userProfileTxn := i.userDb.Table("saas_user_invitation as iui").Select("*").Where("iui.profile_id = ?", profileId)
	rows, err := userProfileTxn.Rows()

	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		userProfileTxn.ScanRows(rows, model)
	}

	return nil
}

func (i saasUserRepository) UpdateSaasUserState(userReqEmail string, saasUserProfile models.SaasUserProfile) error {
	err := i.userDb.Table("saas_user_invitation").
		Where("email = ?", userReqEmail).
		Updates(map[string]interface{}{
			"user_accept_date":  saasUserProfile.UserAcceptDate,
			"state":             saasUserProfile.State,
			"profile_id":        saasUserProfile.ProfileId,
			"last_updated_by":   saasUserProfile.LastUpdatedBy,
			"last_updated_date": saasUserProfile.LastUpdatedDate,
		}).Error

	if err != nil {
		return err
	}
	return nil
}

func (i saasUserRepository) DeleteSaasUser(userReqEmail string) error {
	err := i.userDb.Table("saas_user_invitation").Where("email = ?", userReqEmail).Delete(userReqEmail).Error

	if err != nil {
		return err
	}
	return nil
}

func (i saasUserRepository) InvitedUserListFromDB(userSearchParams request.SearchInvitedUser, adminEmail string) ([]response.UserProfileResp, int64, error) {
	// Initialized variables
	var userProfileList []response.UserProfileResp
	var totalResult int64

	userListTxn := i.userDb.Table("saas_user_invitation as iui")

	// If email param is present
	if userSearchParams.Email != "" {
		userListTxn.Where("LOWER(email) LIKE ?", "%"+strings.ToLower(userSearchParams.Email)+"%")
	}

	// If state param is present
	if userSearchParams.State != "" {
		userListTxn.Where("UPPER(STATE) = ?", strings.ToUpper(userSearchParams.State))
	}

	// If role is present
	if len(userSearchParams.Roles) > 0 {
		filterForCombinedQuery(userListTxn, common.ROLES_COLUMN, userSearchParams.Roles)
	}

	// sortBy or sortOrder as params
	orderByInvitedUserColumns(userListTxn, userSearchParams)

	// Get total count of result
	userListTxn.Count(&totalResult)

	// Apply pagination on the result
	offset := (userSearchParams.Page - 1) * userSearchParams.NumberRecords
	rows, offsetErr := userListTxn.Limit(userSearchParams.NumberRecords).Offset(offset).Select("*").Rows()
	if offsetErr != nil {
		return nil, -1, offsetErr
	}

	defer rows.Close()
	for rows.Next() {
		var userProfile response.UserProfileResp
		userListTxn.ScanRows(rows, &userProfile)
		userProfileList = append(userProfileList, userProfile)
	}

	return userProfileList, totalResult, nil
}

// Set order by for invited user list
func orderByInvitedUserColumns(tx *gorm.DB, param request.SearchInvitedUser) {
	// Defualt value set
	if param.SortBy == "" {
		param.SortBy = "created_date"
	}
	if param.SortOrder == "" {
		param.SortOrder = "desc"
	}

	// Get sort order in param
	tx.Order(param.SortBy + " " + param.SortOrder)
}

// filter data and append results to SIMILAR TO Tag
func filterForCombinedQuery(tx *gorm.DB, columnName string, values []string) {
	var combinedCol string
	for index, colValue := range values {
		if index == 0 {
			combinedCol += "%" + strings.ToUpper(colValue) + "%"
		} else {
			combinedCol += "|%" + strings.ToUpper(colValue) + "%"
		}
	}
	tx.Where("UPPER("+columnName+") SIMILAR TO ?", combinedCol)
}

// filter data and append results to IN Tag
func filterForInQueryCaseInsensitive(tx *gorm.DB, columnName string, values []string) {
	uppercaseValues := make([]string, len(values))
	for i, v := range values {
		uppercaseValues[i] = strings.ToUpper(v)
	}
	tx.Where("UPPER("+columnName+") IN ?", uppercaseValues)
}
