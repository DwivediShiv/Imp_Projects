package middleware

import (
	"fmt"
	"log"
	"net/http"
	"saas-management/common"
	"saas-management/config"
	"saas-management/helper"
	"saas-management/utils"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// Middleware for auth token keycloak realm role validation
func ValidateByRealmRole(ctx *gin.Context, keycloakDb *gorm.DB, config *config.Configuration, role string) {
	realm := config.Info.Realm
	// Get auth token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)

	if tokenErr != nil {
		errResp := common.ErrorTokenVerificationFailed
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": gin.H{"message": "User Unauthorized"},
			"code": errResp.Code})
		return
	}

	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, config)
	if err != nil {
		errMsg := fmt.Sprintf("ValidateByRealmRole loginAdmin config err: %s", err.Error())
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorServiceFailed, &errMsg)
		return
	}

	// Get realm roles of keycloak user
	userRealmRoles, realmRoleErr := client.GetRealmRolesByUserID(ctx, token.AccessToken, realm, tokenPayload.Subject)
	if realmRoleErr != nil {
		log.Printf("Error occured while getting realm roles. Err:: %v", realmRoleErr)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": gin.H{"message": "User Unauthorized"},
			"code": "Error_UnAuthorizedUserAction"})
		return
	}

	// Validate if provided role is assigned to user
	if !utils.ContainRole(userRealmRoles, role) {
		fmt.Println("Error occured : " + role + " is not assigned to " + tokenPayload.Email)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": gin.H{"message": "User Unauthorized"},
			"code": "Error_UnAuthorizedUserAction"})
	}
}

// Middleware for auth token keycloak realm role validation. this func will return not fail if any of the provided role exists
func ValidateForAnyRealmRole(ctx *gin.Context, keycloakDb *gorm.DB, config *config.Configuration, roles ...string) {
	realm := config.Info.Realm
	// Get auth token payload
	tokenPayload, tokenErr := utils.GetTokenFromJwtHeader(ctx)

	if tokenErr != nil {
		errResp := common.ErrorTokenVerificationFailed
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": gin.H{"message": "User Unauthorized"},
			"code": errResp.Code})
		return
	}

	// Admin client and token for getting user from keycloak
	client, token, err := utils.LoginAdmin(ctx, config)
	if err != nil {
		errMsg := fmt.Sprintf("ValidateForAnyRealmRole loginAdmin config err: %s", err.Error())
		helper.ErrorResponse(ctx, http.StatusBadRequest, common.ErrorServiceFailed, &errMsg)
		return
	}

	// Get realm roles of keycloak user
	userRealmRoles, realmRoleErr := client.GetRealmRolesByUserID(ctx, token.AccessToken, realm, tokenPayload.Subject)
	if realmRoleErr != nil {
		log.Printf("Error occured while getting realm roles. Err:: %v", realmRoleErr)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": gin.H{"message": "User Unauthorized"},
			"code": "Error_UnAuthorizedUserAction"})
		return
	}

	// Validate if any of the provided roles is/are assigned to user
	noRolePresent := true
	for _, role := range roles {
		if utils.ContainRole(userRealmRoles, role) {
			return
		}
	}

	if noRolePresent {
		fmt.Printf("\nError occured : '%+v' is not assigned to '%s'", roles, tokenPayload.Email)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": gin.H{"message": "User Unauthorized"},
			"code": "Error_UnAuthorizedUserAction"})
	}
}
