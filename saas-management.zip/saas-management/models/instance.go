package models

import (
	"time"

	"github.com/google/uuid"
)

type Instances struct {
	UUID              uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();index:idx_customer_uuid"`
	ID                uint      `gorm:"primarykey;autoIncrementIncrement"`
	CreatedAt         time.Time
	UpdatedAt         time.Time
	Name              string `gorm:"uniqueIndex:idx_instance_name"`
	AwsAccount        string
	CustomerName      string
	Description       string
	Region            string
	CustomDomain      string
	CustomEmailDomain string
	ContactEmail      string
	Status            string
	NetworkRecords    []Networks `gorm:"foreignkey:InstancesID"`
	Version           string
	CreatedBy         string
	UpdatedBy         string
	BuildID           string
	DeleteBuildID     string
	DeleteStatus      string
	InactiveBuildID   string
	InactiveStatus    string
	BuildRemarks      string
	RetryFlag         int
	EmailPending      bool
	IsSesRequested    bool
}

type Networks struct {
	UUID         uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();index:idx_customer_uuid"`
	ID           uint      `gorm:"primarykey;autoIncrementIncrement"`
	InstancesID  uint
	Decimal      string
	Network      string
	TokenSymbol  string
	TokenAddress string
	CreatedAt    time.Time
	UpdatedAt    time.Time
}

type UpdateInstanceRequest struct {
	Version string
	BuildID string
	Remarks string
	Status  string
}
