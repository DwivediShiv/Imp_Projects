package models

type CreateClusterArgs struct {
	ClusterName string
	AccountType string
	Version     string
	Region      string
	Network     string
}

// type GetBuildStatus struct {
// 	BuildID     string
// 	AccountType string
// 	Region      string
// }

// type SESIdentityVerificationReq struct {
// 	CustomEmailDomain string
// 	AccountType       string
// 	Region            string
// }

// type CertificateVerificationReq struct {
// 	AccountType  string
// 	Region       string
// 	CustomDomain string
// }

// type RetryCreateInstanceReq struct {
// 	AccountType string
// 	Region      string
// 	BuildID     string
// }

// type GetSSMParamReq struct {
// 	AccountType    string
// 	Region         string
// 	InstanceName   string
// 	IsSESRequested bool
// }

type DeleteClusterArgs struct {
	Version     string
	AccountType string
	Region      string
	ClusterName string
}

// type InactivateInstanceArgs struct {
// 	Version      string
// 	AccountType  string
// 	Region       string
// 	InstanceName string
// }

// type InstanceDomainEntriesEmailRequest struct {
// 	To           string             `json:"to"`
// 	InstanceName string             `json:"instanceName"`
// 	Entry        []AWSDomainEntries `json:"entry"`
// }

// type AWSDomainEntries struct {
// 	Name  string `json:"name"`
// 	Type  string `json:"type"`
// 	Value string `json:"value"`
// }
