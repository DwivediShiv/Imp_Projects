package models

type CreateInstanceArgs struct {
	Version            string
	AccountType        string
	Region             string
	InstanceName       string
	InstanceAdminEmail string
	Network            string
	TokenAddress       string
	TokenSymbol        string
	Decimals           string
	// optional below
	CustomDomain   string
	SESDomainExist string
	SESDomain      string
}

type GetBuildStatus struct {
	BuildID     string
	AccountType string
	Region      string
}

type SESIdentityVerificationReq struct {
	CustomEmailDomain string
	AccountType       string
	Region            string
}

type CertificateVerificationReq struct {
	AccountType  string
	Region       string
	CustomDomain string
}

type RetryCreateInstanceReq struct {
	AccountType string
	Region      string
	BuildID     string
}

type GetSSMParamReq struct {
	AccountType    string
	Region         string
	InstanceName   string
	IsSESRequested bool
}

type DeleteInstanceArgs struct {
	Version      string
	AccountType  string
	Region       string
	InstanceName string
	// optional below
	SESDomainExist bool
	SESDomain      string
}

type InactivateInstanceArgs struct {
	Version      string
	AccountType  string
	Region       string
	InstanceName string
}

type InstanceDomainEntriesEmailRequest struct {
	To           string             `json:"to"`
	InstanceName string             `json:"instanceName"`
	Entry        []AWSDomainEntries `json:"entry"`
}

type AWSDomainEntries struct {
	Name  string `json:"name"`
	Type  string `json:"type"`
	Value string `json:"value"`
}
