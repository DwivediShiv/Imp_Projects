package models

type VersionInfo []struct {
	Version     string `json:"version"`
	ReleaseNote string `json:"releaseNote"`
	Description string `json:"description"`
}
