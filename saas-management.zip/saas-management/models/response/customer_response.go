package response

import "time"

type CreateCustomerResponse struct {
	Message string `json:"message"`
}

type GetCustomerResponse struct {
	ID             string    `json:"id"`
	Name           string    `json:"name"`
	BusinessNumber string    `json:"businessNumber"`
	Description    string    `json:"description"`
	Industry       string    `json:"industry"`
	Country        string    `json:"country"`
	Address        string    `json:"address"`
	ContactEmail   string    `json:"contactEmail"`
	CreatedAt      time.Time `json:"createdAt"`
	CreatedBy      string    `json:"createdBy"`
	UpdatedAt      time.Time `json:"updatedAt"`
	UpdatedBy      string    `json:"updatedBy"`
}

type CustomerListResponse struct {
	Data            []GetCustomerResponse   `json:"data"`
	FilterCriterias CustomerFilterCriterias `json:"filterCriterias"`
	TotalRecord     int64                   `json:"totalRecord"`
}

type CustomerFilterCriterias struct {
	Countries  []string `db:"countries"`
	Industries []string `db:"industries"`
}
type CustomerGenericResponse struct {
	Message string `json:"message"`
}

type CustomerNameListResponse struct {
	Data []GetCustomerNameResponse `json:"data"`
}

type GetCustomerNameResponse struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}
