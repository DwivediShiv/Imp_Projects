package response

import "time"

type CreateClusterResponse struct {
	Message string `json:"message"`
}

type GetClusterResponse struct {
	ID                string           `json:"id"`
	Name              string           `json:"name"`
	AWSAccount        string           `json:"awsAccount"`
	Region            string           `json:"region"`
	Networks          []ClusterNetwork `json:"networks"`
	Version           string           `json:"version"`
	Status            string           `json:"status"`
	NumberOfInstances int              `json:"numberOfInstances"`
	CreatedAt         time.Time        `json:"createdAt"`
	CreatedBy         string           `json:"createdBy"`
	UpdatedAt         time.Time        `json:"updatedAt"`
}

type ClusterNetwork struct {
	Network   string    `json:"network"`
	CreatedAt time.Time `json:"createdAt"`
}

type ClusterListResponse struct {
	Data            []GetClusterResponse   `json:"data"`
	FilterCriterias ClusterFilterCriterias `json:"filterCriterias"`
	TotalRecord     int64                  `json:"totalRecord"`
}

type ClusterFilterCriterias struct {
	Regions []string `db:"regions"`
}

type ClusterGenericResponse struct {
	Message string `json:"message"`
}
