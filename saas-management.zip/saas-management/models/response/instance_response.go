package response

import "time"

type CreateInstanceResponse struct {
	Message string `json:"message"`
}

type GetInstanceResponse struct {
	ID                string    `json:"id"`
	Name              string    `json:"name"`
	CustomerName      string    `json:"customerName"`
	AWSAccount        string    `json:"awsAccount"`
	Description       string    `json:"description"`
	Region            string    `json:"region"`
	ContactEmail      string    `json:"contactEmail"`
	CustomDomain      string    `json:"customDomain"`
	CustomEmailDomain string    `json:"customEmailDomain"`
	Networks          []Network `json:"networks"`
	Version           string    `json:"version"`
	CreatedAt         time.Time `json:"createdAt"`
	CreatedBy         string    `json:"createdBy"`
	Status            string    `json:"status"`
}

type Network struct {
	Network      string `json:"network"`
	Decimal      string `json:"decimal"`
	TokenSymbol  string `json:"tokenSymbol"`
	TokenAddress string `json:"tokenAddress"`
}

type InstanceListResponse struct {
	Data            []GetInstanceResponse   `json:"data"`
	FilterCriterias InstanceFilterCriterias `json:"filterCriterias"`
	TotalRecord     int64                   `json:"totalRecord"`
}

type InstanceFilterCriterias struct {
	CustomerNames []string `db:"customerNames"`
	Regions       []string `db:"regions"`
}
type InstanceGenericResponse struct {
	Message string `json:"message"`
}

type VersionListResponse struct {
	Data []VersionDetail `json:"data"`
}

type VersionDetail struct {
	Version     string
	Description string
}

type ReleaseNoteResponse struct {
	Data string `json:"data"`
}
