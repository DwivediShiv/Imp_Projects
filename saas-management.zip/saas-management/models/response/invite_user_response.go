package response

import "time"

type InviteUserResponse struct {
	Status string `json:"status"`
}

type AcceptInviteResponse struct {
	Status string `json:"status"`
}

type LoginUserResponse struct {
	Data        LoginResp `json:"data"`
	OTPRequired bool      `json:"otpRequired"`
}

type LoginResp struct {
	AccessToken      string `json:"access_token"`
	TokenType        string `json:"token_type"`
	ExpiresIn        int    `json:"expires_in"`
	RefreshToken     string `json:"refresh_token"`
	RefreshExpiresIn int    `json:"refresh_expires_in"`
	Scope            string `json:"scope"`
}

type UserProfileResp struct {
	UserAcceptDate  time.Time `json:"userAcceptDate"`
	UserInviteDate  time.Time `json:"userInviteDate"`
	Email           string    `json:"email"`
	AllowedRoles    string    `json:"allowedRoles"`
	ProfileId       string    `json:"profileId"`
	State           string    `json:"state"`
	Remark          string    `json:"remark"`
	CreatedDate     time.Time `json:"createdDate"`
	CreatedBy       string    `json:"createdBy"`
	LastUpdatedDate time.Time `json:"lastUpdateDate"`
	LastUpdatedBy   string    `json:"lastUpdatedBy"`
}

type UserFilterCriterias struct {
	Roles []string `db:"roles"`
}

type UserListRespone struct {
	Data            []UserProfileResp   `json:"data"`
	FilterCriterias UserFilterCriterias `json:"filterCriterias"`
	TotalRecord     int64               `json:"totalRecord"`
}

type GenericResponse struct {
	Status string `json:"status"`
}
