package response

import (
	"github.com/Nerzal/gocloak/v13"
)

type GetUserProfileRolesResp struct {
	Data UserProfileRolesResponse `json:"data"`
}

type UserProfileRolesResponse struct {
	Roles []*gocloak.Role `json:"roles"`
}

type UserRoleUpdateResponse struct {
	Message string `json:"message"`
}

type UpdateUserStatusResp struct {
	Message string `json:"message"`
}

type DeleteSaasUserResp struct {
	Message string `json:"message"`
}
