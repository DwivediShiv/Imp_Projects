package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Customer struct {
	Model
	Name           string `gorm:"uniqueIndex:idx_name"`
	BusinessNumber string `gorm:"uniqueIndex:idx_business_number"`
	Industry       string
	Country        string
	Description    string
	Address        string
	ContactEmail   string
	Status         string
	CreatedBy      string
	UpdatedBy      string
	DeletedBy      string
}

type Model struct {
	UUID      uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();index:idx_customer_uuid"`
	ID        uint      `gorm:"primarykey;autoIncrementIncrement"`
	CreatedAt time.Time
	UpdatedAt time.Time
	DeletedAt gorm.DeletedAt `gorm:"index"`
}
