package models

type SelectionOptionsResp struct {
	IsValidCategory bool `json:"isValidCategory"`
}

type SelfInviteResp struct {
	Invited bool `json:"invited"`
}
