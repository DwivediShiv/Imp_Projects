package models

import "time"

// User Profile Model
type SaasUserProfile struct {
	ID              int       `json:"id" gorm:"primary_key;autoIncrementIncrement"`
	UserAcceptDate  time.Time `json:"userAcceptDate"`
	UserInviteDate  time.Time `json:"userInviteDate"`
	Email           string    `json:"email"`
	AllowedRoles    string    `json:"allowedRoles"`
	ProfileId       string    `json:"profileId"`
	State           string    `json:"state"`
	Remark          string    `json:"remark"`
	CreatedDate     time.Time `json:"createdDate"`
	CreatedBy       string    `json:"createdBy"`
	LastUpdatedDate time.Time `json:"lastUpdateDate"`
	LastUpdatedBy   string    `json:"lastUpdatedBy"`
}

type JWT struct {
	AccessToken      string `json:"access_token"`
	IDToken          string `json:"id_token"`
	ExpiresIn        int    `json:"expires_in"`
	RefreshExpiresIn int    `json:"refresh_expires_in"`
	RefreshToken     string `json:"refresh_token"`
	TokenType        string `json:"token_type"`
	NotBeforePolicy  int    `json:"not-before-policy"`
	SessionState     string `json:"session_state"`
	Scope            string `json:"scope"`
}