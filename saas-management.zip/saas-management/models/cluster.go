package models

import (
	"time"

	"github.com/google/uuid"
)

type Clusters struct {
	ID             uint      `gorm:"primarykey;autoIncrementIncrement"`
	UUID           uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();index:idx_customer_uuid"`
	Name           string    `gorm:"uniqueIndex:idx_cluster_name"`
	AwsAccount     string
	Region         string
	Version        string
	NetworkRecords []ClusterNetworks `gorm:"foreignkey:ClustersID"`
	Status         string
	BuildID        string
	BuildRemarks   string
	RetryFlag      int
	DeleteBuildID  string
	DeleteStatus   string
	CreatedAt      time.Time
	CreatedBy      string
	UpdatedAt      time.Time
	UpdatedBy      string
}

type ClusterNetworks struct {
	ID         uint      `gorm:"primarykey;autoIncrementIncrement"`
	UUID       uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();index:idx_customer_uuid"`
	ClustersID uint
	Network    string
	CreatedAt  time.Time
	UpdatedAt  time.Time
}

type UpdateClusterRequest struct {
	Version string
	BuildID string
	Remarks string
	Status  string
}
