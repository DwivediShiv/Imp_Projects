package keycloak

type UserAttr uint

const (
	CompanyName UserAttr = iota
	Purpose
	LastLogin
	IsMarketingConsent
)

func (userAttribute UserAttr) ToConstant() string {
	switch userAttribute {
	case CompanyName:
		return "COMPANY_NAME"
	case Purpose:
		return "PURPOSE"
	case LastLogin:
		return "LAST_LOGIN"
	case IsMarketingConsent:
		return "IS_MARKETING_CONSENT"
	}
	return ""
}
