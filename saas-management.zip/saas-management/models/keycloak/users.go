package keycloak

type KeyCloakUserEntity struct {
	ID               string                  `json:"id"`
	Username         string                  `json:"username"`
	EmailVerified    bool                    `json:"emailVerified"`
	Attributes       []KeycloakUserAttribute `json:"attributes,omitempty" gorm:"-"`
	Roles            []KeycloakRole          `json:"roles,omitempty" gorm:"-"`
	CreatedTimestamp int64                   `json:"createdTimestamp"`
}

func (KeyCloakUserEntity) TableName() string { return "user_entity" }

type KeycloakUserAttribute struct {
	Name   string `json:"name"`
	Value  string `json:"value"`
	UserId string `json:"user_id"`
}

func (KeycloakUserAttribute) TableName() string { return "user_attribute" }

type KeycloakRole struct {
	ID         string `json:"id"`
	Name       string `json:"name"`
	ClientRole bool   `json:"clientRole"`
	RealmId    string `json:"RealmId"`
}

func (KeycloakRole) TableName() string { return "keycloak_role" }

type Wallet struct {
	Address string   `json:"address"`
	Role    []string `json:"roles"`
}

type ProfileRole struct {
	Role   []string `json:"roles"`
	Wallet []Wallet `json:"wallets"`
}

type KeycloakCustomProfile struct {
	Domain    string   `json:"domain"`
	Email     string   `json:"email"`
	UserRoles []string `json:"userRoles"`
}
