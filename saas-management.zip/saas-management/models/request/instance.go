package request

type InstanceDetail struct {
	Name              string `json:"name" binding:"required,max=25"`
	CustomerName      string `json:"customerName" binding:"required,max=100"`
	AWSAccount        string `json:"awsAccount" binding:"required,max=100"`
	Description       string `json:"description" binding:"required,max=100"`
	Decimal           string `json:"decimal" binding:"required,numeric,gte=0,max=99"`
	TokenSymbol       string `json:"tokenSymbol" binding:"required,max=100"`
	TokenAddress      string `json:"tokenAddress" binding:"required,max=100"`
	Region            string `json:"region" binding:"required,max=50"`
	ContactEmail      string `json:"contactEmail" binding:"required,max=100"`
	CustomDomain      string `json:"customDomain" binding:"max=50"`
	CustomEmailDomain string `json:"customEmailDomain" binding:"max=50"`
	Network           string `json:"network" binding:"required,max=50"`
	Version           string `json:"version" binding:"required,max=50"`
	BuildID           string `json:"-"`
}

// Search params for list
type InstanceList struct {
	Get           string   `json:"get"`
	Name          string   `json:"name"`
	CustomerNames []string `json:"customerNames"`
	Regions       []string `json:"regions"`
	Page          int      `json:"page" default:"1"`
	NumberRecords int      `json:"numberRecords" default:"10"`
	StatusTab     string   `json:"statusTab" binding:"omitempty"`
	SortBy        string   `json:"sortBy"`
	SortOrder     string   `json:"sortOrder"`
}

type InstanceNetwork struct {
	Decimal      string `json:"decimal" binding:"required,numeric,gte=0,max=99"`
	TokenSymbol  string `json:"tokenSymbol" binding:"required,max=100"`
	TokenAddress string `json:"tokenAddress" binding:"required,max=100"`
	Network      string `json:"network" binding:"required,max=50"`
}
