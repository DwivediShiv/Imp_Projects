package request

type InviteUserRequest struct {
	Email  string    `json:"email" binding:"required"`
	Roles  *[]string `json:"roles" binding:"required,min=1"`
	Remark string    `json:"remark"`
}

type AcceptInviteRequest struct {
	Password string `json:"password" binding:"required,min=15"`
}

type UserLoginRequest struct {
	Email    string `json:"email" binding:"required"`
	Password string `json:"password" binding:"required"`
	OTP      string `json:"otp"`
}

type ResendOTPRequest struct {
	Email string `json:"email" binding:"required"`
}

type ResetEmaildRequest struct {
	Email string `json:"email" binding:"required"`
}

type ResetPasswordRequest struct {
	Password string `json:"password" binding:"required,min=15"`
}

// Request input for change password
type ChangePasswordRequest struct {
	CurrentPassword string `json:"currentPassword" binding:"required"`
	Password        string `json:"password" binding:"required"`
}

// Search params for admin invited user list
type SearchInvitedUser struct {
	Email         string   `json:"email"`
	Get           string   `json:"get"`
	Country       string   `json:"country"`
	Roles         []string `json:"roles"`
	State         string   `json:"state"`
	Page          int      `json:"page" default:"1"`
	NumberRecords int      `json:"numberRecords" default:"10"`
	SortBy        string   `json:"sortBy"`
	SortOrder     string   `json:"sortOrder"`
}
