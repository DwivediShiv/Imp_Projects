package request

type CustomerDetail struct {
	Name           string `json:"name" binding:"required,max=100"`
	BusinessNumber string `json:"businessNumber" binding:"required,max=50"`
	Description    string `json:"description" binding:"required,max=500"`
	Industry       string `json:"industry" binding:"required"`
	Country        string `json:"country" binding:"required"`
	Address        string `json:"address" binding:"required,max=500"`
	ContactEmail   string `json:"contactEmail" binding:"required"`
}

// Search params for list
type CustomerList struct {
	Get           string   `json:"get"`
	Name          string   `json:"name"`
	Industries    []string `json:"industry"`
	Countries     []string `json:"country"`
	Page          int      `json:"page" default:"1"`
	NumberRecords int      `json:"numberRecords" default:"10"`
	SortBy        string   `json:"sortBy"`
	SortOrder     string   `json:"sortOrder"`
}

// Search params for name list
type CustomerNameList struct {
	Get           string `form:"get"`
	Page          int    `form:"page" default:"1"`
	NumberRecords int    `form:"numberRecords" default:"10"`
	SortBy        string `form:"sortBy"`
	SortOrder     string `form:"sortOrder"`
}

type CustomerStatusChangeRequest struct {
	ID     string `json:"id" binding:"required,uuid4"`
	Status string `json:"status" binding:"required,oneof=Active Inactive"`
}
