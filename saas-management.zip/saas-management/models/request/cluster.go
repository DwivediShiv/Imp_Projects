package request

type ClusterDetail struct {
	Name       string `json:"name" binding:"required,max=25"`
	AWSAccount string `json:"awsAccount" binding:"required,max=100"`
	Region     string `json:"region" binding:"required,max=50"`
	Network    string `json:"network" binding:"required,max=50"`
	Version    string `json:"version" binding:"required,max=50"`
	BuildID    string `json:"-"`
}

// Search params for list
type ClusterList struct {
	Get           string   `json:"get"`
	Name          string   `json:"name"`
	Regions       []string `json:"regions"`
	Networks      []string `json:"networks"`
	Page          int      `json:"page" default:"1"`
	NumberRecords int      `json:"numberRecords" default:"10"`
	StatusTab     string   `json:"statusTab" binding:"omitempty"`
	SortBy        string   `json:"sortBy"`
	SortOrder     string   `json:"sortOrder"`
}

type ClusterNetwork struct {
	Network string `json:"network" binding:"required,max=50"`
}
