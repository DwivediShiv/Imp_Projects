package common

var ValidRoles = []string{
	"Admin",
	"Infra Manager",
	"Customer Manager",
}

const UniqueKeyViolationCode = "23505"

var CustomerUniqueConstraintMap = map[string]string{
	"customers_name_key":            "Customer already exists",
	"customers_business_number_key": "Business number already exists",
}
var ValidRoleList = []string{
	"Admin", "Infra Manager", "Customer Manager",
}

var UserListRowHeaders = []string{
	"User Email", "Roles", "Invited On", "Invited By", "Status",
}

var CustomerListRowHeaders = []string{
	"Customer Name", "Business Number", "Country", "Industry", "Created On", "Created By",
}

var InstanceListRowHeaders = []string{
	"Instance Name", "Customer Name", "Region", "Version", "Created On", "Created By", "Status",
}

var ClusterListRowHeaders = []string{
	"Cluster Name", "Region", "Network", "Version", "Created By", "Created On", "Updated On", "Status",
}

const (
	ADMIN_CONSTANT    = "Admin"
	INFRA_CONSTANT    = "Infra Manager"
	CUSTOMER_CONSTANT = "Customer Manager"
)

const (
	InvitedState                   = "Invited"
	AcceptedState                  = "Active"
	InactiveState                  = "Inactive"
	GrantTypeClientCredentials     = "client_credentials"
	DefaultTokenExpiresIn          = 86400 * 3 // 3600 = 1hour  //86400 = 1 day
	LAST_VERIFICATION_TOKEN        = "LAST_VERIFICATION_TOKEN"
	JWT_TOKEN_NOT_MATCH_ERROR_CODE = "544"
	EMAIL_VERIFIED_DATE            = "EMAIL_VERIFIED_DATE"
	InviteSaasUser                 = "InviteSaasUser"
	AdminRole                      = "admin"
	InfraManagerRole               = "infra-manager"
	CustomerManagerRole            = "customer-manager"
	ValidatedRole                  = "validated"
	UserRole                       = "user"
	ROLES_COLUMN                   = "allowed_roles"
)

// constants related to keycloak
const (
	INVITATION_ACCEPTED_ON = "INVITATION_ACCEPTED_ON"
	CREATED_BY             = "CREATED_BY"
	CREATED_DATE           = "CREATED_DATE"
	UPDATED_BY             = "UPDATED_BY"
	UPDATE_DATE            = "UPDATE_DATE"
	STATE                  = "STATE"
	LAST_LOGIN_ATTRIBUTE   = "LAST_LOGIN"
)
