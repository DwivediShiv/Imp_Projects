package common

import (
	"net/http"
	"saas-management/models"
)

var (
	ErrorInvalidRequestInput = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Request Inputs are not valid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_INVALID_REQUEST_INPUT",
	}

	ErrorClusterNameAlreadyExists = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Cluster name already exists",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_CLUSTER_NAME_ALREADY_EXISTS",
	}

	ErrorClusterNameAlreadyExistsInRegion = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Cluster already exists in region and aws account",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_CLUSTER_NAME_ALREADY_EXISTS_REGION",
	}

	ErrorInvalidEmail = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Email Id is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_EMAIL",
	}

	ErrorInvalidCustomDomain = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Custom Domain is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_CUSTOM_DOMAIN",
	}

	ErrorInvalidCustomEmailDomain = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Custom Email Domain is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_CUSTOM_EMAIL_DOMAIN",
	}

	ErrorInvalidTokenAddress = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Token Address is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_TOKEN_ADDRESS",
	}

	ErrorInvalidTokenSymbol = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Token Symbol is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_TOKEN_SYMBOL",
	}

	ErrorInvalidDecimal = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Decimal is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_DECIMAL",
	}

	ErrorInvalidName = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Name is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_NAME",
	}

	ErrorInvalidBusinessNumber = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Business number is invalid",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVALID_BUSINESS_NUMBER",
	}

	ErrorEmailExists = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Email already exists",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "EMAIL_ALREADY_EXISTS",
	}

	ErrorServiceFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Service failed",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "SERVICE_FAILED",
	}

	ErrorActionNotAllowedFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Action not allowed as build is in progress",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ACTION_NOT_ALLOWED",
	}

	ErrorActionNotAllowedDeleted = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Action not allowed as cluster is deleted",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ACTION_NOT_ALLOWED",
	}

	ErrorGeneralFailure = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "General failure",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "GENERAL_FAILURE",
	}

	ErrorSendNotificationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Invitation notification failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "INVITATION_NOTIFICATION_FAILED",
	}

	ErrorDbFetchFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Unable to fetch data",
		},
		ResponseCode: http.StatusServiceUnavailable,
		Code:         "ERROR_FETCH_FAILED",
	}

	ErrorGetKeycloakUserNotFound = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User profile not found",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_GET_USER_PROFILE_NOT_FOUND",
	}

	ErrorDBFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "DB Failure",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "ERROR_DB_FAILED",
	}

	ErrorUserAuthenticationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User authentication failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_USER_AUTHENTICATION_FAILED",
	}
	ErrorTokenGenerationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Token Generation failed",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "ERROR_TOKEN_GENERATION_FAILED",
	}

	ErrorLoginOtpIncorrect = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "OTP incorrect.",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_LOGIN_OTP_INCORRECT", // INCORRECT_OTP
	}
	ErrorLoginOtpExpired = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "OTP expired.",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_LOGIN_OTP_EXPIRED", // EXPIRED_OTP
	}
	ErrorResetEmailFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Failed sending reset email.",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "ERROR_RESET_EMAIL_FAILED",
	}
	ErrorLoginOtpRequired = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "OTP required.",
		},
		Code: "ERROR_LOGIN_OTP_REQUIRED", // required
	}

	ErrorPasswordValidationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Password validation failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "PASSWORD_VALIDATION_FAILED",
	}

	ErrorChangePasswordMismatch = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User current password mismatch.",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "CURRENT_PASSWORD_MISMATCH",
	}

	ErrorPasswordChangeFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User password change failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "PASSWORD_CHANGE_FAILED",
	}

	ErrorTokenVerificationFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Token verification failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "TOKEN_VERIFICATION_FAILED",
	}

	ErrorInvitationAlreadyAccepted = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User has already accepted the invitation. Please login",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_INVITATION_ALREADY_ACCEPTED",
	}

	ErrorGetRealmRolesFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Get roles failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_GET_REALM_ROLES_FAILED",
	}

	ErrorAddRealmRolesFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Add roles failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_ADD_REALM_ROLES_FAILED",
	}

	ErrorUpdateRoleFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Update roles failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_UPDATE_ROLE_FAILED",
	}

	ErrorCreateUserFailed = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Create user failed",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "ERROR_CREATE_USER_FAILED",
	}
	ErrorGenericFailure = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Generic failure",
		},
		ResponseCode: http.StatusInternalServerError,
		Code:         "ERROR_GENERIC_FAILURE",
	}

	ErrorInstanceNotFound = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Instance not found",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_INSTANCE_NOT_FOUND",
	}

	ErrorClusterNotFound = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Cluster not found",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_CLUSTER_NOT_FOUND",
	}

	ErrorCustomerNotFound = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Customer not found",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_CUSTOMER_NOT_FOUND",
	}

	ErrorUserNotFound = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User not found",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_USER_NOT_FOUND",
	}

	ErrorUserAlreadyExist = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User already exist",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_USER_ALREADY_EXIST",
	}
	ErrorEntryAlreadyExist = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Entry already exist",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_ENTRY_ALREADY_EXIST",
	}

	ErrorUserStatusUpdate = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "Same user cannot be updated",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_USER_STATUS_UPDATE",
	}

	ErrorDeleteUser = models.ErrorResponse{
		Error: models.ErrorDetail{
			Message: "User deletion failed",
		},
		ResponseCode: http.StatusBadRequest,
		Code:         "ERROR_DELETE_USER",
	}
)
