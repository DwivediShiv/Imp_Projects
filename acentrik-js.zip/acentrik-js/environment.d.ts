export {};

  declare global {
    namespace NodeJS {
      interface ProcessEnv extends Dict<string> {
        PRIVATE_KEY: string;
        RPC_URL: string;
        INFURA_PROJECT_ID: string;
        SMART_ACCOUNT_ADDRESS: string;
        SMART_ACCOUNT_SESSION_VALIDATION_MODULE_ADDRESS: string;
        SMART_ACCOUNT_PAYMASTER_URL: string;
        SMART_ACCOUNT_PAYMASTER_KEY: string;
        SMART_ACCOUNT_BUNDLER_URL: string;
        SMART_ACCOUNT_BUNDLER_KEY: string;
        OCEAN_AQUARIUS_URL: string;
        OCEAN_PROVIDER_URL: string;
        BICONOMY_DASHBOARD_URL: string;
        BICONOMY_DASHBOARD_AUTH_TOKEN: string;
      }
    }
  }
