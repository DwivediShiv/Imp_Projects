export const ApiContentTypes = {
  json: 'application/json',
};

export const ACCOUNT_PROVIDERS = {
  BICONOMY: 'BICONOMY',
  ALCHEMY: 'ALCHEMY',
  EOA: 'EOA',
};

export const commandToEventType = {
  publish: 'publish',
  editAsset: 'publish',
  allowAlgo: 'publish',
  disAllowAlgo: 'publish',
  aggregate: 'compute',
  multipleCompute: 'compute',
  compute: 'compute',
  stopCompute: 'compute',
  getJobStatus: 'compute',
  getJobResults: 'compute',
  downloadJobResults: 'compute',
  download: 'consume',
};

export const DATA_ASSET_TYPES = {
  DATASET: 'dataset',
  ALGORITHM: 'algorithm',
};

export const ATTRIBUTE_MAX_CHARACTERS = {
  NAME: 70,
  OVERVIEW: 300,
  DESCRIPTION: 5000,
};

export const ASSET_TYPE = {
  DATASET: 'dataset',
  ALGORITHM: 'algorithm',
};

export const INPUT_OUTPUT_FILE_TYPES = [
  'csv',
  'delta',
  'json',
  'orc',
  'parquet',
  'rds',
  'xlsx',
];

export const CATEGORIES_LIST = [
  'Aerospace',
  'Agriculture',
  'Automotive',
  'Blockchain',
  'Construction',
  'Education',
  'Energy',
  'ESG',
  'Financial Services',
  'Food and Beverages',
  'Government',
  'Healthcare',
  'Information Technology',
  'Insurance',
  'Manufacturing',
  'Real Estate',
  'Services',
  'Tourism',
  'Others',
];

export const ACCESS_PERMISSIONS = { ALLOW: 'allow', DENY: 'deny' };

export const ALGORITHM_TYPE = {
  BASIC: 'basic',
  FEDERATED: 'federated',
  AGGREGATE: 'aggregate',
};

export interface Credential {
  type: string;
  values: string[];
}

export interface Credentials {
  allow: Credential[];
  deny: Credential[];
}

export interface FileEncryptRequestData {
  nftAddress: string;
  datatokenAddress: string;
  files: FileEncrypt[];
}

export interface FileEncrypt {
  type: string;
  url: string;
  method: string;
  headers?: { [key: string]: string };
}

export const UNLIMITED_TIMEOUT = 'unlimited';
export const UNLIMITED_TIMEOUT_VALUE = 0;
