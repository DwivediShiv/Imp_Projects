import { Config } from '@oceanprotocol/lib';
import {
  EOAProvidersBootstrapOptions,
  NonAccountAbstractionProviders,
  eoabootstrapOptions,
} from '..';
import { publishAsset } from '../../asset-manager/create-asset';
import { download } from '../../asset-manager/download-asset';
import { startCompute } from '../../asset-manager/start-compute';
import { startMultipleCompute } from '../../asset-manager/start-multiple-compute';
import { aggregation } from '../../asset-manager/aggregation';
import { Signer } from 'ethers';
import { getDdo } from '../../asset-manager/get-ddo';
import { customComputeStatus } from '../../asset-manager/get-job-status';
import { getJobResult } from '../../asset-manager/get-job-result';
import { downloadJobResult } from '../../asset-manager/download-job-result';
import { stopCompute } from '../../asset-manager/stop-compute';
import { disAllowAlgo } from '../../asset-manager/disallow-algo';
import { allowAlgo } from '../../asset-manager/allow-algo';
import { editAsset } from '../../asset-manager/edit-asset';
import { getOceanConfig } from '../helper';
import { WalletAdapter } from '../../types/walletAdapter';

export class EOAdapter implements WalletAdapter {
  private nonaccountAbstractionProviders: NonAccountAbstractionProviders;
  private options: EOAProvidersBootstrapOptions;
  private signer: Signer;
  public chainId: number;
  private isBrowser: boolean;
  private config: Config;
  constructor(
    chainId: string,
    inputOptions: EOAProvidersBootstrapOptions,
    browserFlag?: boolean,
  ) {
    const options = eoabootstrapOptions.parse(inputOptions);
    this.options = options;
    this.config = getOceanConfig(options);
    this.nonaccountAbstractionProviders = new NonAccountAbstractionProviders(
      chainId,
      this.config,
      options,
    );
    this.isBrowser = browserFlag ? true : false;
    this.signer = this.nonaccountAbstractionProviders.signer;
    this.chainId = this.nonaccountAbstractionProviders.chainId;
  }

  async publish(asset: any): Promise<void> {
    console.log('start publishing for Non-AA flow');
    const encryptDDO = true;
    const aquarius = this.nonaccountAbstractionProviders.Aquarius;
    try {
      const urlAssetId = await publishAsset(
        asset.nft.name,
        asset.nft.symbol,
        this.signer,
        asset.services[0].files,
        asset,
        this.options.oceanProviderUri || '',
        this.config,
        aquarius,
        encryptDDO,
        '',
        '',
        '',
        '',
      );
      console.log('Asset published. ID:  ' + urlAssetId);
    } catch (e) {
      console.error('Error when publishing dataset from file: ' + asset);
      console.error(e);
      return;
    }
  }
  async download(datasetDID: string, destinationFilePath: string) {
    const result = await download(
      datasetDID,
      destinationFilePath,
      this.signer,
      this.config,
      this.isBrowser,
      this.options.oceanAquariusUri,
      '',
      '',
      '',
    );
    console.log(result);
    return result;
  }
  async compute(datasetDID: string, algoDid: string) {
    const result = await startCompute(
      datasetDID,
      algoDid,
      this.signer,
      this.chainId,
      this.config,
      this.options.oceanAquariusUri,
      '',
      '',
      '',
    );
    console.log('result', result);
  }
  async aggregate(guid: string) {
    const result = await aggregation(
      guid,
      this.signer,
      this.config,
      this.options.oceanProviderUri,
      this.options.oceanAquariusUri,
      '',
    );
  }
  async multipleCompute(datasetDIDsAndAlgoFile, fedAlgoDid) {
    const { datasetDIDs, algoDIDs } = datasetDIDsAndAlgoFile;
    console.log(datasetDIDs, algoDIDs);
    const jobId = await startMultipleCompute(
      datasetDIDs,
      algoDIDs,
      fedAlgoDid,
      this.signer,
      this.options.oceanAquariusUri,
      this.config,
      '',
      '',
      '',
    );
  }
  async getJobStatus(datasetInfo: string[]): Promise<void> {
    customComputeStatus(
      datasetInfo[0],
      datasetInfo[1],
      this.signer,
      this.options.oceanAquariusUri,
      '',
    );
  }

  async getJobResults(datasetInfo: string[]): Promise<void> {
    getJobResult(
      datasetInfo[0],
      datasetInfo[1],
      this.signer,
      this.options.oceanAquariusUri,
      '',
    );
  }

  async downloadJobResults(datasetInfo: string[]): Promise<any> {
    const result = await downloadJobResult(
      datasetInfo[0],
      datasetInfo[1],
      datasetInfo[2],
      datasetInfo[3],
      this.signer,
      this.isBrowser,
      this.options.oceanProviderUri,
      this.options.oceanAquariusUri,
    );
    return result;
  }

  async stopCompute(datasetInfo: string[]): Promise<void> {
    stopCompute(
      datasetInfo[0],
      datasetInfo[1],
      this.signer,
      this.options.oceanAquariusUri,
    );
  }

  async getDDO(datasetDID: string): Promise<void> {
    getDdo(datasetDID, this.options.oceanAquariusUri);
  }

  async disAllowAlgo(datasetAndAlgoDID: string[]): Promise<void> {
    disAllowAlgo(
      datasetAndAlgoDID[0],
      datasetAndAlgoDID[1],
      this.signer,
      this.chainId,
      this.options.oceanAquariusUri,
      this.options.oceanProviderUri,
      '',
      '',
      '',
    );
  }

  async allowAlgo(datasetAndAlgoDID: string[]): Promise<void> {
    allowAlgo(
      datasetAndAlgoDID[0],
      datasetAndAlgoDID[1],
      this.signer,
      this.chainId,
      this.options.oceanAquariusUri,
      this.options.oceanProviderUri,
      '',
    );
  }

  async editAsset(datasetDIDsFilePathAndAlgoDID: string[]): Promise<void> {
    const result = await editAsset(
      datasetDIDsFilePathAndAlgoDID[0],
      datasetDIDsFilePathAndAlgoDID[1],
      datasetDIDsFilePathAndAlgoDID[2],
      this.signer,
      this.chainId,
      this.config,
      this.options.oceanAquariusUri,
      this.options.oceanProviderUri,
      '',
      '',
      '',
      '',
    );
    result == 'null'
      ? console.log(
          'Result: null, edit Asset failed. Pls check the logs for failure.',
        )
      : console.log('Result of edit asset:', result, ' ');
    console.log('Edit Asset process completed');
  }
}
