import { Aquarius, Config, ConfigHelper } from '@oceanprotocol/lib';
import { publishAsset } from '../../asset-manager/create-asset';
import { download } from '../../asset-manager/download-asset';
import { startCompute } from '../../asset-manager/start-compute';
import { aggregation } from '../../asset-manager/aggregation';
import { startMultipleCompute } from '../../asset-manager/start-multiple-compute';
import { customComputeStatus } from '../../asset-manager/get-job-status';
import { getJobResult } from '../../asset-manager/get-job-result';
import { downloadJobResult } from '../../asset-manager/download-job-result';
import { getDdo } from '../../asset-manager/get-ddo';
import { stopCompute } from '../../asset-manager/stop-compute';
import { disAllowAlgo } from '../../asset-manager/disallow-algo';
import { allowAlgo } from '../../asset-manager/allow-algo';
import { editAsset } from '../../asset-manager/edit-asset';
import { Signer } from 'ethers';
import { WalletAdapter } from '../../types/walletAdapter';
import {
  AlchemyAccountAbstractionProviders,
  AlchemyProvidersBootstrapOptions,
  alchemyBootstrapOptions,
  commonFieldsValidationMetadata,
} from '../providers';
import { getOceanConfig } from '../helper';

export class AlchemyAdapter implements WalletAdapter {
  private options: AlchemyProvidersBootstrapOptions;
  private signer: Signer;
  private chainId: number;
  private accountAbstractionProviders: AlchemyAccountAbstractionProviders;
  private isBrowser: boolean;
  private config: Config;

  constructor(
    inputOptions: AlchemyProvidersBootstrapOptions,
    browserFlag?: boolean,
  ) {
    this.isBrowser = browserFlag ? true : false;
    const options = alchemyBootstrapOptions.parse(inputOptions);
    this.options = options;
    this.config = getOceanConfig(options);
    this.accountAbstractionProviders = new AlchemyAccountAbstractionProviders(
      this.options,
    );
    this.signer = this.accountAbstractionProviders.signer;
    this.chainId = this.accountAbstractionProviders._chainId;
  }

  async publish(asset: any): Promise<void> {
    console.log('start publishing for Alchemy AA flow');
    const isEncryptDDO = true;
    const aquarius = new Aquarius(this.options.oceanAquariusUri || '');
    if (!asset?.services[0]?.serviceEndpoint) {
      console.error('Service endpoint not provided');
      return;
    }
    
    try {
      const urlAssetId = await publishAsset(
        asset.nft.name,
        asset.nft.symbol,
        this.signer,
        asset?.services?.[0]?.files,
        asset,
        this.options.oceanProviderUri || '',
        this.config,
        aquarius,
        isEncryptDDO,
        '',
        '',
        '',
        this.options.smartAccountAddress,
        asset?.services[0]?.additionalInformation?.alternateWalletAddress,
        asset?.services[0]?.serviceEndpoint,
      );
      console.log('Asset published. ID:  ' + urlAssetId);
    } catch (e) {
      console.error('Error when publishing dataset from file: ' + asset);
      console.error(e);
      return;
    }
  }

  async download(datasetDID: string, destinationFilePath: string) {
    const result = await download(
      datasetDID,
      destinationFilePath,
      this.signer,
      this.config,
      this.isBrowser,
      this.options.oceanAquariusUri,
      '',
      '',
      this.options.smartAccountAddress,
    );
    return result;
  }

  async compute(datasetDID: string, algoDid: string) {
    const result = await startCompute(
      datasetDID,
      algoDid,
      this.signer,
      this.chainId,
      this.config,
      this.options.oceanAquariusUri,
      '',
      '',
      this.options.smartAccountAddress,
    );
    console.log('result', result);
  }

  async aggregate(guid: string) {
    const result = await aggregation(
      guid,
      this.signer,
      this.config,
      this.options.oceanProviderUri,
      this.options.oceanAquariusUri,
      this.options.smartAccountAddress,
    );
  }

  async multipleCompute(datasetDIDsAndAlgoFile, fedAlgoDid) {
    const { datasetDIDs, algoDIDs } = datasetDIDsAndAlgoFile;
    console.log(datasetDIDs, algoDIDs);
    const jobId = await startMultipleCompute(
      datasetDIDs,
      algoDIDs,
      fedAlgoDid,
      this.signer,
      this.options.oceanAquariusUri,
      this.config,
      '',
      '',
      this.options.smartAccountAddress,
    );
  }

  async getJobStatus(datasetInfo: string[]): Promise<void> {
    customComputeStatus(
      datasetInfo[0],
      datasetInfo[1],
      this.signer,
      this.options.oceanAquariusUri,
      this.options.smartAccountAddress,
    );
  }

  async getJobResults(datasetInfo: string[]): Promise<void> {
    getJobResult(
      datasetInfo[0],
      datasetInfo[1],
      this.signer,
      this.options.oceanAquariusUri,
      this.options.smartAccountAddress,
    );
  }

  async downloadJobResults(datasetInfo: string[]): Promise<any> {
    const resultUrl = await downloadJobResult(
      datasetInfo[0],
      datasetInfo[1],
      datasetInfo[2],
      datasetInfo[3],
      this.signer,
      this.isBrowser,
      this.options.oceanProviderUri,
      this.options.oceanAquariusUri,
    );
    return resultUrl;
  }

  async stopCompute(datasetInfo: string[]): Promise<void> {
    stopCompute(
      datasetInfo[0],
      datasetInfo[1],
      this.signer,
      this.options.oceanAquariusUri,
    );
  }

  async getDDO(datasetDID: string): Promise<void> {
    getDdo(datasetDID, this.options.oceanAquariusUri);
  }

  async disAllowAlgo(datasetAndAlgoDID: string[]): Promise<void> {
    disAllowAlgo(
      datasetAndAlgoDID[0],
      datasetAndAlgoDID[1],
      this.signer,
      this.chainId,
      this.options.oceanAquariusUri,
      this.options.oceanProviderUri,
      '',
      '',
      this.options.smartAccountAddress,
    );
  }

  async allowAlgo(datasetAndAlgoDID: string[]): Promise<void> {
    allowAlgo(
      datasetAndAlgoDID[0],
      datasetAndAlgoDID[1],
      this.signer,
      this.chainId,
      this.options.oceanAquariusUri,
      this.options.oceanProviderUri,
      '',
      '',
      this.options.smartAccountAddress,
    );
  }

  async editAsset(datasetDIDsFilePathAndAlgoDID: string[]): Promise<void> {
    const result = await editAsset(
      datasetDIDsFilePathAndAlgoDID[0],
      datasetDIDsFilePathAndAlgoDID[1],
      datasetDIDsFilePathAndAlgoDID[2],
      this.signer,
      this.chainId,
      this.config,
      this.options.oceanAquariusUri,
      this.options.oceanProviderUri,
      '',
      '',
      this.options.smartAccountAddress,
    );
    result == 'null'
      ? console.log(
          'Result: null, edit Asset failed. Pls check the logs for failure.',
        )
      : console.log('Result of edit asset:', result, ' ');
    console.log('Edit Asset process completed');
  }
}
