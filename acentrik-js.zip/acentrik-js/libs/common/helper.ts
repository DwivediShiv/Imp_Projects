import axios from 'axios';
import {
  Aquarius,
  ComputeAlgorithm,
  Asset,
  DDO,
  ProviderComputeInitialize,
  Datatoken,
  ProviderFees,
  ConsumeMarketFee,
  Config,
  approveWei,
  getEventFromTx,
  orderAsset,
  ProviderInstance,
  Nft,
  LoggerInstance,
  DownloadResponse,
  ConfigHelper,
  FixedRateExchange,
} from '@oceanprotocol/lib';
import { ethers, Signer } from 'ethers';
import * as Path from 'path-browserify';

import {
  // accountAbstractionProviders,
  AAProvidersBootstrapOptions,
  AlchemyProvidersBootstrapOptions,
  EOAProvidersBootstrapOptions,
  UNLIMITED_TIMEOUT,
  UNLIMITED_TIMEOUT_VALUE,
} from '../common';
import { getAccessDetails } from '../utils/accessDetailsAndPricing';
import { AssetExtended } from '../asset-manager/start-multiple-compute';
import { assert } from 'console';
import { getFileEncryptRequestData } from '../asset-manager';

export async function isOrderable(
  asset: Asset | DDO,
  serviceId: string,
  algorithm: ComputeAlgorithm,
  algorithmDDO: Asset | DDO,
): Promise<boolean> {
  const datasetService = asset.services.find((s) => s.id === serviceId);
  if (!datasetService) return false;

  if (datasetService.type === 'compute') {
    if (algorithm.meta) {
      if (datasetService.compute.allowRawAlgorithm) return true;
      return false;
    }
    if (algorithm.documentId) {
      const algoService = algorithmDDO.services.find(
        (s) => s.id === algorithm.serviceId,
      );
      if (algoService && algoService.type === 'compute') {
        if (algoService.serviceEndpoint !== datasetService.serviceEndpoint) {
          LoggerInstance.error(
            'ERROR: Both assets with compute service are not served by the same provider',
          );
          return false;
        }
      }
    }
  }
  return true;
}

export async function handleComputeOrder(
  order: ProviderComputeInitialize,
  asset: AssetExtended,
  payerAccount: Signer,
  consumerAddress: string,
  serviceIndex: number,
  datatoken: Datatoken,
  config: Config,
  providerFees: ProviderFees,
  providerUrl: string,
  accountAddr?: string,
  consumeMarkerFee?: ConsumeMarketFee,
) {
  let orderStartedTx;
  if (order.providerFee && order.providerFee.providerFeeAmount) {
    const txApproveProvider = await approveWei(
      payerAccount,
      config,
      await payerAccount.getAddress(),
      order.providerFee.providerFeeToken,
      asset.services[0].datatokenAddress,
      order.providerFee.providerFeeAmount,
    );
    console.log('approve fee');
    if (txApproveProvider.constructor.name !== 'BigNumber') {
      const txApproveReceipt = await txApproveProvider.wait();
      if (!txApproveReceipt?.transactionHash) {
        console.log('Failed to approve');
        return;
      }
    }
  }
  const accessDetails =
    asset?.accessDetails ||
    (await getAccessDetails(
      asset.services[0].datatokenAddress,
      config,
      asset.services[0].timeout, //Describing how long the service can be used after consumption is initiated.
      accountAddr || (await payerAccount.getAddress()),
    ));

  const currentTimestamp = Date.now() / 1000;

  console.log(
    'value of order.providerFee.validUntil:',
    order.providerFee?.validUntil,
    '  (~~accessDetails?.providerFee?.validUntil):',
    ~~accessDetails?.providerFee?.validUntil,
    ' currentTimestamp:',
    currentTimestamp,
  );
  if (~~accessDetails?.providerFee?.validUntil > currentTimestamp) {
    if (accessDetails.isOwned) {
      console.log('Provider Fee valid and asset owned.');
      return accessDetails.validOrderTx;
    } else {
      console.log(
        'Provider fee valid but IsOwned is false. Creating new order..',
      );
      const txStartOrder = await orderAsset(
        asset,
        payerAccount,
        config,
        datatoken,
        providerUrl,
        consumerAddress,
        consumeMarkerFee,
        providerFees,
      );
      const tx = await txStartOrder.wait();
      orderStartedTx = getEventFromTx(tx, 'OrderStarted');
      return orderStartedTx.transactionHash;
    }
  } else {
    console.log('provider fee not valid(expired)');

    if (accessDetails.isOwned) {
      console.log(
        'Provider fee expired but asset already owned. Reusing order...',
      );
      if (!order.providerFee) return order.validOrder;
      const tx = await datatoken.reuseOrder(
        asset.services[0].datatokenAddress,
        accessDetails.validOrderTx,
        order.providerFee,
      );
      console.log('executed reuseOrder - tx:', tx);
      const reusedTx = await tx.wait();

      const orderReusedTx = getEventFromTx(reusedTx, 'OrderReused');
      return orderReusedTx.transactionHash;
    } else {
      console.log('Creating order again..');
      const txStartOrder = await orderAsset(
        asset,
        payerAccount,
        config,
        datatoken,
        providerUrl,
        consumerAddress,
        consumeMarkerFee,
        providerFees,
      );

      const tx = await txStartOrder.wait();
      orderStartedTx = getEventFromTx(tx, 'OrderStarted');

      return orderStartedTx.transactionHash;
    }
  }
}

export async function updateEditAssetMetadata(
  owner: Signer,
  updatedDdo: any,
  existingDdo: any,
  paymentCollector: string,
  providerUrl: string,
  aquariusInstance: Aquarius,
  chainId: number,
  config,
  macOsProviderUrl?: string,
  accountAddr?: string,
) {
  const nft = new Nft(owner, chainId);
  if (updatedDdo?.services[0]?.files?.files) {
    const filesEncrypted = await ProviderInstance.encrypt(
      getFileEncryptRequestData(
        updatedDdo.services[0].files.files,
        updatedDdo.nftAddress,
        updatedDdo.datatokens?.[0]?.address,
      ),
      chainId,
      updatedDdo.services[0].serviceEndpoint,
    );
    updatedDdo.services[0].files = filesEncrypted;
  }

  const validateResult = await aquariusInstance.validate(updatedDdo);
  let updateDdoTX = {};
  const accessDetails = await getAccessDetails(
    existingDdo.services[0].datatokenAddress,
    config,
    existingDdo.services[0].timeout,
    accountAddr || (await owner.getAddress()),
  );

  const providerResponse = await ProviderInstance.encrypt(
    updatedDdo,
    updatedDdo.chainId,
    providerUrl,
  );
  const encryptedResponse = await providerResponse;
  updateDdoTX = await nft.setMetadata(
    updatedDdo.nftAddress,
    accountAddr || (await owner.getAddress()),
    0,
    providerUrl,
    '',
    ethers.utils.hexlify(2),
    encryptedResponse,
    validateResult.hash,
  );

  const datatokenInstance = new Datatoken(owner);
  const dtAddress = existingDdo?.datatokens[0]?.address;
  const paymentCollectorOld =
    await datatokenInstance.getPaymentCollector(dtAddress);
  if (
    paymentCollector &&
    paymentCollector?.toLowerCase() !== paymentCollectorOld?.toLowerCase()
  ) {
    const setPaymentCollectorTxResponse =
      await datatokenInstance.setPaymentCollector(
        existingDdo.services[0].datatokenAddress,
        (accountAddr as any) || (await owner.getAddress()),
        paymentCollector,
      );

    const setPaymentCollectorTxReceipt =
      await setPaymentCollectorTxResponse.wait();

    if (!setPaymentCollectorTxReceipt) {
      console.log('Failed to update Revenue Address');
    }
  }
  if (existingDdo.nft.state !== updatedDdo.nft.state) {
    const setNFTStateTxResponse = await nft.setMetadataState(
      existingDdo.nftAddress,
      (accountAddr as any) || (await owner.getAddress()),
      updatedDdo.nft.state,
    );
    const setNFTStateTxReceipt = setNFTStateTxResponse.wait();
    if (!setNFTStateTxReceipt) {
      console.log('Failed to Update State');
    }
  }
  if (updatedDdo.stats.price.value !== existingDdo.stats.price.value) {
    if (existingDdo.stats.price.value !== 0) {
      const fixedRateInstance = new FixedRateExchange(
        config.fixedRateExchangeAddress,
        owner,
        config?.chainId,
        config,
      );
      const setPriceResponse = await fixedRateInstance.setRate(
        accessDetails.addressOrId,
        updatedDdo?.stats?.price?.value.toString(),
      );
      const setPriceReceipt = await setPriceResponse.wait();
      if (!setPriceReceipt) {
        console.log('Failed to Update Asset Price');
      }
    }
  }
  if (updatedDdo.nft.owner !== existingDdo.nft.owner) {
    const setOwnerTxResponse = await nft.safeTransferNft(
      existingDdo.nftAddress,
      existingDdo.nft.owner,
      updatedDdo.nft.owner,
    );
    const setOwnerTxReceipt = await setOwnerTxResponse.wait();
    if (!setOwnerTxReceipt) {
      console.log('Failed to transfer ownership.');
    }
  }

  return updateDdoTX;
}

export async function updateAssetMetadata(
  owner: Signer,
  updatedDdo: DDO,
  providerUrl: string,
  aquariusInstance: Aquarius,
  chainId: number,
  macOsProviderUrl?: string,
  accountAddr?: string,
) {
  const nft = new Nft(owner, chainId);
  const providerResponse = await ProviderInstance.encrypt(
    updatedDdo,
    updatedDdo.chainId,
    providerUrl,
  );
  const encryptedResponse = await providerResponse;
  const validateResult = await aquariusInstance.validate(updatedDdo);
  const updateDdoTX = await nft.setMetadata(
    updatedDdo.nftAddress,
    accountAddr || (await owner.getAddress()),
    0,
    providerUrl,
    '',
    ethers.utils.hexlify(2),
    encryptedResponse,
    validateResult.hash,
  );
  return updateDdoTX;
}

export function fancyConvertSecondsToTimeoutOfDurationType(
  timeout: number,
  timeoutDurationType: string,
): number {
  const timeoutValue = timeout;
  if (isNaN(timeoutValue) || timeoutValue < 0) return -1;

  switch (timeoutDurationType) {
    case 'hour(s)':
      return timeoutValue * 3600;
    case 'day(s)':
      return timeoutValue * 86400;
    case 'month(s)':
      // Assume 1 month duration of 30 days for conversion
      return timeoutValue * (30 * 86400);
    case 'year(s)':
      // Assume a year duration of 365 days for conversion
      return timeoutValue * (365 * 86400);
    case UNLIMITED_TIMEOUT:
      return UNLIMITED_TIMEOUT_VALUE;
    default:
      return -1;
  }
}

export function getOceanConfig(
  options:
    | AAProvidersBootstrapOptions
    | EOAProvidersBootstrapOptions
    | AlchemyProvidersBootstrapOptions,
): Config {
  const oceanInitialConfig = new ConfigHelper().getConfig(
    parseInt(options.chainId) || 137,
    options?.infuraProjectId,
  ) as Config;
  const oceanCustomConfig = {
    ...oceanInitialConfig,
    metadataCacheUri: oceanInitialConfig?.metadataCacheUri,
    subgraphUri: options?.subgraphUri || '',
    providerUri: options?.oceanProviderUri || oceanInitialConfig?.providerUri,
    oceanTokenAddress:
      options?.baseToken || oceanInitialConfig?.oceanTokenAddress,
    baseTokenDecimals: parseInt(options?.tokenDecimal as string) || 18,
  };
  return oceanCustomConfig;
}

export const NFT_ABI = [
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'AddedManager',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'AddedTo725StoreList',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'AddedToCreateERC20List',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'AddedToMetadataList',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'approved',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'Approval',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'operator',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'bool',
        name: 'approved',
        type: 'bool',
      },
    ],
    name: 'ApprovalForAll',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'CleanedPermissions',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'contractAddress',
        type: 'address',
      },
    ],
    name: 'ContractCreated',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'key',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'value',
        type: 'bytes',
      },
    ],
    name: 'DataChanged',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'uint256',
        name: '_operation',
        type: 'uint256',
      },
      {
        indexed: true,
        internalType: 'address',
        name: '_to',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: '_value',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: '_data',
        type: 'bytes',
      },
    ],
    name: 'Executed',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'createdBy',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'state',
        type: 'uint8',
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'decryptorUrl',
        type: 'string',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'flags',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'data',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'metaDataHash',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'MetadataCreated',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'updatedBy',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'state',
        type: 'uint8',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'MetadataState',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'updatedBy',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'state',
        type: 'uint8',
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'decryptorUrl',
        type: 'string',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'flags',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'data',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'metaDataHash',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'MetadataUpdated',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'validator',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'metaDataHash',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'v',
        type: 'uint8',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'r',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 's',
        type: 'bytes32',
      },
    ],
    name: 'MetadataValidated',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'RemovedFrom725StoreList',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'RemovedFromCreateERC20List',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'RemovedFromMetadataList',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'RemovedManager',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'newTokenAddress',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'templateAddress',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'name',
        type: 'string',
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'symbol',
        type: 'string',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'cap',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'creator',
        type: 'address',
      },
    ],
    name: 'TokenCreated',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'updatedBy',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'tokenURI',
        type: 'string',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'tokenID',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'TokenURIUpdate',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'Transfer',
    type: 'event',
  },
  {
    stateMutability: 'payable',
    type: 'fallback',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_managerAddress',
        type: 'address',
      },
    ],
    name: 'addManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address[]',
        name: 'addresses',
        type: 'address[]',
      },
      {
        internalType: 'enum ERC721RolesAddress.RolesType[]',
        name: 'roles',
        type: 'uint8[]',
      },
    ],
    name: 'addMultipleUsersToRoles',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address',
      },
    ],
    name: 'addTo725StoreList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address',
      },
    ],
    name: 'addToCreateERC20List',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address',
      },
    ],
    name: 'addToMetadataList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'approve',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    name: 'auth',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
    ],
    name: 'balanceOf',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'baseURI',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'cleanPermissions',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '_templateIndex',
        type: 'uint256',
      },
      {
        internalType: 'string[]',
        name: 'strings',
        type: 'string[]',
      },
      {
        internalType: 'address[]',
        name: 'addresses',
        type: 'address[]',
      },
      {
        internalType: 'uint256[]',
        name: 'uints',
        type: 'uint256[]',
      },
      {
        internalType: 'bytes[]',
        name: 'bytess',
        type: 'bytes[]',
      },
    ],
    name: 'createERC20',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '_operation',
        type: 'uint256',
      },
      {
        internalType: 'address',
        name: '_to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: '_value',
        type: 'uint256',
      },
      {
        internalType: 'bytes',
        name: '_data',
        type: 'bytes',
      },
    ],
    name: 'executeCall',
    outputs: [],
    stateMutability: 'payable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'getApproved',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_key',
        type: 'bytes32',
      },
    ],
    name: 'getData',
    outputs: [
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getId',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8',
      },
    ],
    stateMutability: 'pure',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getMetaData',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8',
      },
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
    ],
    name: 'getPermissions',
    outputs: [
      {
        components: [
          {
            internalType: 'bool',
            name: 'manager',
            type: 'bool',
          },
          {
            internalType: 'bool',
            name: 'deployERC20',
            type: 'bool',
          },
          {
            internalType: 'bool',
            name: 'updateMetadata',
            type: 'bool',
          },
          {
            internalType: 'bool',
            name: 'store',
            type: 'bool',
          },
        ],
        internalType: 'struct ERC721RolesAddress.Roles',
        name: '',
        type: 'tuple',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getTokensList',
    outputs: [
      {
        internalType: 'address[]',
        name: '',
        type: 'address[]',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'hasMetaData',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        internalType: 'string',
        name: 'name_',
        type: 'string',
      },
      {
        internalType: 'string',
        name: 'symbol_',
        type: 'string',
      },
      {
        internalType: 'address',
        name: 'tokenFactory',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'additionalERC20Deployer',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'additionalMetaDataUpdater',
        type: 'address',
      },
      {
        internalType: 'string',
        name: 'tokenURI',
        type: 'string',
      },
      {
        internalType: 'bool',
        name: 'transferable_',
        type: 'bool',
      },
    ],
    name: 'initialize',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'operator',
        type: 'address',
      },
    ],
    name: 'isApprovedForAll',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'datatoken',
        type: 'address',
      },
    ],
    name: 'isDeployed',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address',
      },
    ],
    name: 'isERC20Deployer',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'isInitialized',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'metaDataDecryptorAddress',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'metaDataDecryptorUrl',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'metaDataState',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'name',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'ownerOf',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address',
      },
    ],
    name: 'removeFrom725StoreList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address',
      },
    ],
    name: 'removeFromCreateERC20List',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address',
      },
    ],
    name: 'removeFromMetadataList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_managerAddress',
        type: 'address',
      },
    ],
    name: 'removeManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'safeTransferFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'operator',
        type: 'address',
      },
      {
        internalType: 'bool',
        name: 'approved',
        type: 'bool',
      },
    ],
    name: 'setApprovalForAll',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'string',
        name: '_baseURI',
        type: 'string',
      },
    ],
    name: 'setBaseURI',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_key',
        type: 'bytes32',
      },
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes',
      },
    ],
    name: 'setDataERC20',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint8',
        name: '_metaDataState',
        type: 'uint8',
      },
      {
        internalType: 'string',
        name: '_metaDataDecryptorUrl',
        type: 'string',
      },
      {
        internalType: 'string',
        name: '_metaDataDecryptorAddress',
        type: 'string',
      },
      {
        internalType: 'bytes',
        name: 'flags',
        type: 'bytes',
      },
      {
        internalType: 'bytes',
        name: 'data',
        type: 'bytes',
      },
      {
        internalType: 'bytes32',
        name: '_metaDataHash',
        type: 'bytes32',
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'validatorAddress',
            type: 'address',
          },
          {
            internalType: 'uint8',
            name: 'v',
            type: 'uint8',
          },
          {
            internalType: 'bytes32',
            name: 'r',
            type: 'bytes32',
          },
          {
            internalType: 'bytes32',
            name: 's',
            type: 'bytes32',
          },
        ],
        internalType: 'struct ERC721Template.metaDataProof[]',
        name: '_metadataProofs',
        type: 'tuple[]',
      },
    ],
    name: 'setMetaData',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'uint8',
            name: 'metaDataState',
            type: 'uint8',
          },
          {
            internalType: 'string',
            name: 'metaDataDecryptorUrl',
            type: 'string',
          },
          {
            internalType: 'string',
            name: 'metaDataDecryptorAddress',
            type: 'string',
          },
          {
            internalType: 'bytes',
            name: 'flags',
            type: 'bytes',
          },
          {
            internalType: 'bytes',
            name: 'data',
            type: 'bytes',
          },
          {
            internalType: 'bytes32',
            name: 'metaDataHash',
            type: 'bytes32',
          },
          {
            internalType: 'uint256',
            name: 'tokenId',
            type: 'uint256',
          },
          {
            internalType: 'string',
            name: 'tokenURI',
            type: 'string',
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'validatorAddress',
                type: 'address',
              },
              {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8',
              },
              {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32',
              },
              {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32',
              },
            ],
            internalType: 'struct ERC721Template.metaDataProof[]',
            name: 'metadataProofs',
            type: 'tuple[]',
          },
        ],
        internalType: 'struct ERC721Template.metaDataAndTokenURI',
        name: '_metaDataAndTokenURI',
        type: 'tuple',
      },
    ],
    name: 'setMetaDataAndTokenURI',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint8',
        name: '_metaDataState',
        type: 'uint8',
      },
    ],
    name: 'setMetaDataState',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_key',
        type: 'bytes32',
      },
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes',
      },
    ],
    name: 'setNewData',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
      {
        internalType: 'string',
        name: 'tokenURI',
        type: 'string',
      },
    ],
    name: 'setTokenURI',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes4',
        name: 'interfaceId',
        type: 'bytes4',
      },
    ],
    name: 'supportsInterface',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'symbol',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'index',
        type: 'uint256',
      },
    ],
    name: 'tokenByIndex',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'index',
        type: 'uint256',
      },
    ],
    name: 'tokenOfOwnerByIndex',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'tokenURI',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'totalSupply',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'transferFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'transferable',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'withdrawETH',
    outputs: [],
    stateMutability: 'payable',
    type: 'function',
  },
  {
    stateMutability: 'payable',
    type: 'receive',
  },
];

export const WHITELISTED_METHODS_NFT = [
  'addManager',
  'addMultipleUsersToRoles',
  'addTo725StoreList',
  'addToCreateERC20List',
  'addToMetadataList',
  'approve',
  'cleanPermissions',
  'createERC20',
  'executeCall',
  'initialize',
  'removeFrom725StoreList',
  'removeFromCreateERC20List',
  'removeFromMetadataList',
  'removeManager',
  'safeTransferFrom',
  'setApprovalForAll',
  'setBaseURI',
  'setDataERC20',
  'setMetaData',
  'setMetaDataAndTokenURI',
  'setMetaDataState',
  'setNewData',
  'setTokenURI',
  'transferFrom',
  'withdrawETH',
];

export const DATATOKEN_TEMPLATE2_ABI = [
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'AddedMinter',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'AddedPaymentManager',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'spender',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'value',
        type: 'uint256',
      },
    ],
    name: 'Approval',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'CleanedPermissions',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'consumeMarketFeeAddress',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'consumeMarketFeeToken',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'consumeMarketFeeAmount',
        type: 'uint256',
      },
    ],
    name: 'ConsumeMarketFee',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'currentMinter',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'newMinter',
        type: 'address',
      },
    ],
    name: 'MinterApproved',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'currentMinter',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'newMinter',
        type: 'address',
      },
    ],
    name: 'MinterProposed',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'dispenserContract',
        type: 'address',
      },
    ],
    name: 'NewDispenser',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'exchangeContract',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'baseToken',
        type: 'address',
      },
    ],
    name: 'NewFixedRate',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'caller',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: '_newPaymentCollector',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'NewPaymentCollector',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'providerAddress',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'consumerAddress',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'providerData',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'providerSignature',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'consumerData',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'consumerSignature',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'OrderExecuted',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'caller',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'number',
        type: 'uint256',
      },
    ],
    name: 'OrderReused',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'consumer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'payer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'serviceIndex',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'publishMarketAddress',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'OrderStarted',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'providerFeeAddress',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'providerFeeToken',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'providerFeeAmount',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'providerData',
        type: 'bytes',
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'v',
        type: 'uint8',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'r',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 's',
        type: 'bytes32',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'validUntil',
        type: 'uint256',
      },
    ],
    name: 'ProviderFee',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'PublishMarketFeeAddress',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'PublishMarketFeeToken',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'PublishMarketFeeAmount',
        type: 'uint256',
      },
    ],
    name: 'PublishMarketFee',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'caller',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'PublishMarketFeeAddress',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'PublishMarketFeeToken',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'PublishMarketFeeAmount',
        type: 'uint256',
      },
    ],
    name: 'PublishMarketFeeChanged',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'RemovedMinter',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256',
      },
    ],
    name: 'RemovedPaymentManager',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'value',
        type: 'uint256',
      },
    ],
    name: 'Transfer',
    type: 'event',
  },
  {
    stateMutability: 'payable',
    type: 'fallback',
  },
  {
    inputs: [],
    name: 'BASE',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'DOMAIN_SEPARATOR',
    outputs: [
      {
        internalType: 'bytes32',
        name: '',
        type: 'bytes32',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'PERMIT_TYPEHASH',
    outputs: [
      {
        internalType: 'bytes32',
        name: '',
        type: 'bytes32',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_minter',
        type: 'address',
      },
    ],
    name: 'addMinter',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_paymentManager',
        type: 'address',
      },
    ],
    name: 'addPaymentManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'spender',
        type: 'address',
      },
    ],
    name: 'allowance',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'spender',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256',
      },
    ],
    name: 'approve',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    name: 'authERC20',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address',
      },
    ],
    name: 'balanceOf',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256',
      },
    ],
    name: 'burn',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256',
      },
    ],
    name: 'burnFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'consumer',
            type: 'address',
          },
          {
            internalType: 'uint256',
            name: 'serviceIndex',
            type: 'uint256',
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'providerFeeAddress',
                type: 'address',
              },
              {
                internalType: 'address',
                name: 'providerFeeToken',
                type: 'address',
              },
              {
                internalType: 'uint256',
                name: 'providerFeeAmount',
                type: 'uint256',
              },
              {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8',
              },
              {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32',
              },
              {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32',
              },
              {
                internalType: 'uint256',
                name: 'validUntil',
                type: 'uint256',
              },
              {
                internalType: 'bytes',
                name: 'providerData',
                type: 'bytes',
              },
            ],
            internalType: 'struct ERC20TemplateEnterprise.providerFee',
            name: '_providerFee',
            type: 'tuple',
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'consumeMarketFeeAddress',
                type: 'address',
              },
              {
                internalType: 'address',
                name: 'consumeMarketFeeToken',
                type: 'address',
              },
              {
                internalType: 'uint256',
                name: 'consumeMarketFeeAmount',
                type: 'uint256',
              },
            ],
            internalType: 'struct ERC20TemplateEnterprise.consumeMarketFee',
            name: '_consumeMarketFee',
            type: 'tuple',
          },
        ],
        internalType: 'struct ERC20TemplateEnterprise.OrderParams',
        name: '_orderParams',
        type: 'tuple',
      },
      {
        internalType: 'address',
        name: 'dispenserContract',
        type: 'address',
      },
    ],
    name: 'buyFromDispenserAndOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'consumer',
            type: 'address',
          },
          {
            internalType: 'uint256',
            name: 'serviceIndex',
            type: 'uint256',
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'providerFeeAddress',
                type: 'address',
              },
              {
                internalType: 'address',
                name: 'providerFeeToken',
                type: 'address',
              },
              {
                internalType: 'uint256',
                name: 'providerFeeAmount',
                type: 'uint256',
              },
              {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8',
              },
              {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32',
              },
              {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32',
              },
              {
                internalType: 'uint256',
                name: 'validUntil',
                type: 'uint256',
              },
              {
                internalType: 'bytes',
                name: 'providerData',
                type: 'bytes',
              },
            ],
            internalType: 'struct ERC20TemplateEnterprise.providerFee',
            name: '_providerFee',
            type: 'tuple',
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'consumeMarketFeeAddress',
                type: 'address',
              },
              {
                internalType: 'address',
                name: 'consumeMarketFeeToken',
                type: 'address',
              },
              {
                internalType: 'uint256',
                name: 'consumeMarketFeeAmount',
                type: 'uint256',
              },
            ],
            internalType: 'struct ERC20TemplateEnterprise.consumeMarketFee',
            name: '_consumeMarketFee',
            type: 'tuple',
          },
        ],
        internalType: 'struct ERC20TemplateEnterprise.OrderParams',
        name: '_orderParams',
        type: 'tuple',
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'exchangeContract',
            type: 'address',
          },
          {
            internalType: 'bytes32',
            name: 'exchangeId',
            type: 'bytes32',
          },
          {
            internalType: 'uint256',
            name: 'maxBaseTokenAmount',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'swapMarketFee',
            type: 'uint256',
          },
          {
            internalType: 'address',
            name: 'marketFeeAddress',
            type: 'address',
          },
        ],
        internalType: 'struct ERC20TemplateEnterprise.FreParams',
        name: '_freParams',
        type: 'tuple',
      },
    ],
    name: 'buyFromFreAndOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'cap',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'cleanFrom721',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'cleanPermissions',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_dispenser',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'maxTokens',
        type: 'uint256',
      },
      {
        internalType: 'uint256',
        name: 'maxBalance',
        type: 'uint256',
      },
      {
        internalType: 'bool',
        name: 'withMint',
        type: 'bool',
      },
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    name: 'createDispenser',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'fixedPriceAddress',
        type: 'address',
      },
      {
        internalType: 'address[]',
        name: 'addresses',
        type: 'address[]',
      },
      {
        internalType: 'uint256[]',
        name: 'uints',
        type: 'uint256[]',
      },
    ],
    name: 'createFixedRate',
    outputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'decimals',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8',
      },
    ],
    stateMutability: 'pure',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'spender',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'subtractedValue',
        type: 'uint256',
      },
    ],
    name: 'decreaseAllowance',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getDispensers',
    outputs: [
      {
        internalType: 'address[]',
        name: '',
        type: 'address[]',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getERC721Address',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getFixedRates',
    outputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'contractAddress',
            type: 'address',
          },
          {
            internalType: 'bytes32',
            name: 'id',
            type: 'bytes32',
          },
        ],
        internalType: 'struct ERC20TemplateEnterprise.fixedRate[]',
        name: '',
        type: 'tuple[]',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getId',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8',
      },
    ],
    stateMutability: 'pure',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getPaymentCollector',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
    ],
    name: 'getPermissions',
    outputs: [
      {
        components: [
          {
            internalType: 'bool',
            name: 'minter',
            type: 'bool',
          },
          {
            internalType: 'bool',
            name: 'paymentManager',
            type: 'bool',
          },
        ],
        internalType: 'struct ERC20Roles.RolesERC20',
        name: '',
        type: 'tuple',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getPublishingMarketFee',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'spender',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'addedValue',
        type: 'uint256',
      },
    ],
    name: 'increaseAllowance',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'string[]',
        name: 'strings_',
        type: 'string[]',
      },
      {
        internalType: 'address[]',
        name: 'addresses_',
        type: 'address[]',
      },
      {
        internalType: 'address[]',
        name: 'factoryAddresses_',
        type: 'address[]',
      },
      {
        internalType: 'uint256[]',
        name: 'uints_',
        type: 'uint256[]',
      },
      {
        internalType: 'bytes[]',
        name: 'bytes_',
        type: 'bytes[]',
      },
    ],
    name: 'initialize',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'user',
        type: 'address',
      },
    ],
    name: 'isERC20Deployer',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'isInitialized',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address',
      },
    ],
    name: 'isMinter',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'value',
        type: 'uint256',
      },
    ],
    name: 'mint',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'name',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    name: 'nonces',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32',
      },
      {
        internalType: 'bytes',
        name: 'providerData',
        type: 'bytes',
      },
      {
        internalType: 'bytes',
        name: 'providerSignature',
        type: 'bytes',
      },
      {
        internalType: 'bytes',
        name: 'consumerData',
        type: 'bytes',
      },
      {
        internalType: 'bytes',
        name: 'consumerSignature',
        type: 'bytes',
      },
      {
        internalType: 'address',
        name: 'consumerAddress',
        type: 'address',
      },
    ],
    name: 'orderExecuted',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    name: 'permissions',
    outputs: [
      {
        internalType: 'bool',
        name: 'minter',
        type: 'bool',
      },
      {
        internalType: 'bool',
        name: 'paymentManager',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'spender',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'value',
        type: 'uint256',
      },
      {
        internalType: 'uint256',
        name: 'deadline',
        type: 'uint256',
      },
      {
        internalType: 'uint8',
        name: 'v',
        type: 'uint8',
      },
      {
        internalType: 'bytes32',
        name: 'r',
        type: 'bytes32',
      },
      {
        internalType: 'bytes32',
        name: 's',
        type: 'bytes32',
      },
    ],
    name: 'permit',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_minter',
        type: 'address',
      },
    ],
    name: 'removeMinter',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_paymentManager',
        type: 'address',
      },
    ],
    name: 'removePaymentManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32',
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'providerFeeAddress',
            type: 'address',
          },
          {
            internalType: 'address',
            name: 'providerFeeToken',
            type: 'address',
          },
          {
            internalType: 'uint256',
            name: 'providerFeeAmount',
            type: 'uint256',
          },
          {
            internalType: 'uint8',
            name: 'v',
            type: 'uint8',
          },
          {
            internalType: 'bytes32',
            name: 'r',
            type: 'bytes32',
          },
          {
            internalType: 'bytes32',
            name: 's',
            type: 'bytes32',
          },
          {
            internalType: 'uint256',
            name: 'validUntil',
            type: 'uint256',
          },
          {
            internalType: 'bytes',
            name: 'providerData',
            type: 'bytes',
          },
        ],
        internalType: 'struct ERC20TemplateEnterprise.providerFee',
        name: '_providerFee',
        type: 'tuple',
      },
    ],
    name: 'reuseOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'router',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes',
      },
    ],
    name: 'setData',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_newPaymentCollector',
        type: 'address',
      },
    ],
    name: 'setPaymentCollector',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_publishMarketFeeAddress',
        type: 'address',
      },
      {
        internalType: 'address',
        name: '_publishMarketFeeToken',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: '_publishMarketFeeAmount',
        type: 'uint256',
      },
    ],
    name: 'setPublishingMarketFee',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'consumer',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'serviceIndex',
        type: 'uint256',
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'providerFeeAddress',
            type: 'address',
          },
          {
            internalType: 'address',
            name: 'providerFeeToken',
            type: 'address',
          },
          {
            internalType: 'uint256',
            name: 'providerFeeAmount',
            type: 'uint256',
          },
          {
            internalType: 'uint8',
            name: 'v',
            type: 'uint8',
          },
          {
            internalType: 'bytes32',
            name: 'r',
            type: 'bytes32',
          },
          {
            internalType: 'bytes32',
            name: 's',
            type: 'bytes32',
          },
          {
            internalType: 'uint256',
            name: 'validUntil',
            type: 'uint256',
          },
          {
            internalType: 'bytes',
            name: 'providerData',
            type: 'bytes',
          },
        ],
        internalType: 'struct ERC20TemplateEnterprise.providerFee',
        name: '_providerFee',
        type: 'tuple',
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'consumeMarketFeeAddress',
            type: 'address',
          },
          {
            internalType: 'address',
            name: 'consumeMarketFeeToken',
            type: 'address',
          },
          {
            internalType: 'uint256',
            name: 'consumeMarketFeeAmount',
            type: 'uint256',
          },
        ],
        internalType: 'struct ERC20TemplateEnterprise.consumeMarketFee',
        name: '_consumeMarketFee',
        type: 'tuple',
      },
    ],
    name: 'startOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'symbol',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'totalSupply',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256',
      },
    ],
    name: 'transfer',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256',
      },
    ],
    name: 'transferFrom',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'withdrawETH',
    outputs: [],
    stateMutability: 'payable',
    type: 'function',
  },
  {
    stateMutability: 'payable',
    type: 'receive',
  },
];

export const WHITELISTED_METHODS_DATATOKEN = [
  'addMinter',
  'addPaymentManager',
  'approve',
  'burn',
  'burnFrom',
  'buyFromDispenserAndOrder',
  'buyFromFreAndOrder',
  'cleanFrom721',
  'cleanPermissions',
  'createDispenser',
  'createFixedRate',
  'decreaseAllowance',
  'increaseAllowance',
  'initialize',
  'mint',
  'orderExecuted',
  'permit',
  'removeMinter',
  'removePaymentManager',
  'reuseOrder',
  'setData',
  'setPaymentCollector',
  'setPublishingMarketFee',
  'startOrder',
  'transfer',
  'transferFrom',
  'withdrawETH',
];

export interface ApiResponse<T> {
  data?: T;
  error?: string | { message: string };
}

export interface MswHandlerProps<T> {
  status?: number;
  response?: ApiResponse<T>;
  error?: Error;
}

export async function addERC721PolicyToPaymaster(
  policyAddress: string,
  biconomyDashboardAuthToken: string,
  smartAccountPaymasterKey: string,
  paymasterWhiteListingUrl: string,
) {
  try {
    const payload = {
      name: `NFT${policyAddress.slice(-6)}`,
      address: policyAddress,
      abi: JSON.stringify(NFT_ABI),
      whitelistedMethods: WHITELISTED_METHODS_NFT,
    };

    await axios.post<ApiResponse<any>>(paymasterWhiteListingUrl, payload, {});
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.message !== 'contract_exists') {
        return error.message;
      }
    } else {
      return 'unexpected error';
    }
  }
}

export async function addDatatokenPolicyToPaymaster(
  policyAddress: string,
  biconomyDashboardAuthToken: string,
  smartAccountPaymasterKey: string,
  paymasterWhiteListingUrl: string,
) {
  try {
    const payload = {
      name: `DT${policyAddress.slice(-6)}`,
      address: policyAddress,
      abi: JSON.stringify(DATATOKEN_TEMPLATE2_ABI),
      whitelistedMethods: WHITELISTED_METHODS_DATATOKEN,
    };

    await axios.post<ApiResponse<any>>(paymasterWhiteListingUrl, payload, {});
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.message !== 'contract_exists') {
        return error.message;
      }
    } else {
      return 'unexpted error';
    }
  }
}

export async function handleAbstractWhitelistingFlow(
  nftAddress: string,
  datatokenAddress: string,
  biconomyDashboardAuthToken: string,
  smartAccountPaymasterKey: string,
  paymentManagementUrl?: string,
) {
  const paymasterWhiteListingUrl = paymentManagementUrl
    ? `${paymentManagementUrl}/abstract/whitelisting`
    : 'https://paymaster-dashboard-backend.prod.biconomy.io/api/v2/public/sdk/smart-contract';
  const erc721PolicyError = await addERC721PolicyToPaymaster(
    nftAddress,
    biconomyDashboardAuthToken,
    smartAccountPaymasterKey,
    paymasterWhiteListingUrl,
  );
  const datatokenPolicyError = await addDatatokenPolicyToPaymaster(
    datatokenAddress,
    biconomyDashboardAuthToken,
    smartAccountPaymasterKey,
    paymasterWhiteListingUrl,
  );
  if (erc721PolicyError || datatokenPolicyError) {
    console.log(erc721PolicyError || datatokenPolicyError);
  }
}

export function validateHTTPHeaders(httpHeaders) {
  if (!httpHeaders || httpHeaders.length === 0) {
    return false;
  }

  for (let i = 0; i < httpHeaders.length; i++) {
    const param = httpHeaders[i];

    if (
      !param.key ||
      param.key.trim() === '' ||
      !param.value ||
      param.value.trim() === ''
    ) {
      return false;
    }
  }

  return true;
}

export function validateConsumerParameters(consumerParameters) {
  if (!consumerParameters || consumerParameters.length === 0) {
    return false;
  }

  for (let i = 0; i < consumerParameters.length; i++) {
    const param = consumerParameters[i];
    const typeLists = ['string', 'int', 'boolean', 'Options'];

    if (
      !param.name ||
      param.name.trim() === '' ||
      !param.type ||
      param.type.trim() === '' ||
      !typeLists.includes(param.type) ||
      !param.label ||
      param.label.trim() === '' ||
      !param.description ||
      !param.required ||
      param.required !== true
    ) {
      return false;
    }
  }

  return true;
}

export function checkIsLocalPath(value: string): boolean {
  try {
    if (value === '' || typeof value !== 'string') {
      return false;
    }

    const normalizedPath = Path?.normalize(value);

    if (Path?.isAbsolute(normalizedPath)) {
      if (Path?.sep === '\\') {
        return (
          /^[A-Za-z]:\\/.test(normalizedPath) ||
          normalizedPath?.startsWith('\\\\')
        );
      } else {
        return normalizedPath?.startsWith('/');
      }
    }
    return false;
  } catch (error) {
    return false;
  }
}
