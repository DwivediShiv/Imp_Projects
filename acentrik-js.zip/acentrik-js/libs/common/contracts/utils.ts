import { ethers } from 'ethers';
import { contractInterfaces } from './interfaces';

export const BICONOMY_TRANSACTION_METHODS = [
  {
    name: 'createNftWithErc20WithDispenser',
    excludeEthersMethods: ['eth_estimateGas'],
  },
  {
    name: 'createNftWithErc20WithFixedRate',
    excludeEthersMethods: ['eth_estimateGas'],
  },
  { name: 'setMetaData', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'setMetaDataAndTokenURI', excludeEthersMethods: ['eth_estimateGas'] },
  {
    name: 'buyFromDispenserAndOrder',
    excludeEthersMethods: ['eth_estimateGas'],
  },
  { name: 'buyFromFreAndOrder', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'mint', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'buyDT', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'dispense', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'startOrder', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'approve', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'setMetaDataState', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'safeTransferNft', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'safeTransferFrom', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'reuseOrder', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'setPaymentCollector', excludeEthersMethods: ['eth_estimateGas'] },
  { name: 'setRate', excludeEthersMethods: ['eth_estimateGas'] },
];

type TransactionDescription = ethers.utils.TransactionDescription;

export function parseTransactionDataUsingInterfaces(
  data: string | any,
): TransactionDescription | undefined {
  if (!data) {
    return;
  }
  const totalInterfaces = contractInterfaces.length;
  let trxDescription: TransactionDescription | undefined = undefined;
  for (let i = 0; i < totalInterfaces; i++) {
    try {
      const contractInterface = contractInterfaces[i].value;
      trxDescription = contractInterface.parseTransaction({ data });
      break;
    } catch {
      continue;
    }
  }
  // if (!trxDescription) {
  //   console.warn(
  //     "It appears conrtact interfaces wasn't able to parse the data",
  //     data,
  //   );
  // }
  return trxDescription;
}

export function shouldTransactionGaslessTransactions(
  transactionName: string,
): boolean {
  return !!BICONOMY_TRANSACTION_METHODS.find((m) => m.name === transactionName);
}
