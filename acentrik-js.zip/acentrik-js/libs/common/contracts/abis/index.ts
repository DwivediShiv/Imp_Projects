import { abi as DISPENSER_ABI } from '@oceanprotocol/contracts/artifacts/contracts/pools/dispenser/Dispenser.sol/Dispenser.json';
import { abi as ERC721_FACTORY_ABI } from '@oceanprotocol/contracts/artifacts/contracts/ERC721Factory.sol/ERC721Factory.json';
import { abi as ERC721_TEMPLATE_ABI } from '@oceanprotocol/contracts/artifacts/contracts/templates/ERC721Template.sol/ERC721Template.json';
import { abi as ERC20_TEMPLATE_ABI } from '@oceanprotocol/contracts/artifacts/contracts/templates/ERC20TemplateEnterprise.sol/ERC20TemplateEnterprise.json';

// TODO: Fetch ABIs via third party lib instead of maintaining a copy
export * from './fixed-rate-exchange.abi';
export * from './paymaster.abi';

export {
  DISPENSER_ABI,
  ERC721_FACTORY_ABI,
  ERC721_TEMPLATE_ABI,
  ERC20_TEMPLATE_ABI,
};
