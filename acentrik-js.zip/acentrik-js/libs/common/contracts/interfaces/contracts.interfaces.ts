import { ethers } from 'ethers';
import {
  DISPENSER_ABI,
  ERC721_FACTORY_ABI,
  FIXED_RATE_EXCHNGE_ABI,
  ERC721_TEMPLATE_ABI,
  ERC20_TEMPLATE_ABI,
} from '../abis';

export const erc721FactoryInterface = new ethers.utils.Interface(
  ERC721_FACTORY_ABI,
);

export const nftInterface = new ethers.utils.Interface(ERC721_TEMPLATE_ABI);

export const datatokenInterface = new ethers.utils.Interface(
  ERC20_TEMPLATE_ABI,
);

export const dispenserInterface = new ethers.utils.Interface(DISPENSER_ABI);

export const fixedRateExchangeInterface = new ethers.utils.Interface(
  FIXED_RATE_EXCHNGE_ABI,
);

export const contractInterfaces = [
  {
    name: 'erc721FactoryInterface',
    value: erc721FactoryInterface,
  },
  {
    name: 'nftInterface',
    value: nftInterface,
  },
  {
    name: 'datatokenInterface',
    value: datatokenInterface,
  },
  {
    name: 'dispenserInterface',
    value: dispenserInterface,
  },
  {
    name: 'fixedRateExchangeInterface',
    value: fixedRateExchangeInterface,
  },
];
