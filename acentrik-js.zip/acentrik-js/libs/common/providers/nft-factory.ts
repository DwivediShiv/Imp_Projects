import { Config, NftFactory } from '@oceanprotocol/lib';
import { ethers } from 'ethers';

export interface NftFactoryOptions {
  oceanConfig: Config;
  signer: ethers.Wallet;
}

export function createNftFactory(options: NftFactoryOptions) {
  return new NftFactory(options.oceanConfig.nftFactoryAddress, options.signer);
}
