import { Signer, ethers } from 'ethers';
import { z } from 'zod';
import { BiconomySmartAccountV2 } from '@biconomy/account';
import {
  Aquarius,
  Config,
  ConfigHelper,
  Nft,
  NftFactory,
} from '@oceanprotocol/lib';
import { createChainId } from './ethers-chainid';
import { createJsonRpcProvider } from './ethers-jsonrpc-provider';
import { createSigner } from './ethers-signer';
import { createNft } from './nft';
import { createNftFactory } from './nft-factory';
import { createOceanConfig } from './ocean-config';
import { createSmartAccount } from './smart-account';
import { transactionManager } from './transaction-manager';
import { createAlchemySmartAccount } from './alchemy/smart-account';
import {
  MultiOwnerModularAccount,
  MultiOwnerPluginActions,
  PluginManagerActions,
  AccountLoupeActions,
} from '@alchemy/aa-accounts';
import { AlchemySmartAccountClient } from '@alchemy/aa-alchemy';
import {
  ACCESS_PERMISSIONS,
  ACCOUNT_PROVIDERS,
  ALGORITHM_TYPE,
  ASSET_TYPE,
  ATTRIBUTE_MAX_CHARACTERS,
  CATEGORIES_LIST,
  INPUT_OUTPUT_FILE_TYPES,
} from '../constants';
import { LocalAccountSigner } from '@alchemy/aa-core';

export const alchemyBootstrapOptions = z.object({
  apiKey: z.string({ required_error: 'Please add Api Key' }),
  rpcUrl: z
    .string({ required_error: 'Please add RPC URL' })
    .url({ message: 'Please add valid RPC URL' }),
  privateKey: z
    .string({ required_error: 'Please add private key' })
    .length(64, 'The length of private key should be 64 characters'),
  smartAccountAddress: z
    .string({ required_error: 'Please add smart account address' })
    .startsWith('0x', 'The smart account address should be a valid hex'),
  infuraProjectId: z.string({ required_error: 'Please add infura project ID' }),
  chainId: z.string({ required_error: 'Please add Chain Id' }),
  oceanAquariusUri: z
    .string({ required_error: 'Please add Aquarius url' })
    .url({ message: 'Please add valid Aquarius url' }),
  subgraphUri: z
    .string({ required_error: 'Please add subgraph url' })
    .url({ message: 'Please add valid subgraph url' }),
  oceanProviderUri: z
    .string({ required_error: 'Please add oceanProvider url' })
    .url({ message: 'Please add valid oceanProvider url' }),
  userRole: z.string({ required_error: 'Please add USER_ROLE' }),
  eventType: z.string({ required_error: 'No EventType found' }),
  baseToken: z.string().optional(),
  tokenDecimal: z.string().optional(),
});
export type AlchemyProvidersBootstrapOptions = z.infer<
  typeof alchemyBootstrapOptions
>;

export const aabootstrapOptions = z.object({
  rpcUrl: z
    .string({ required_error: 'Please add RPC URL' })
    .url({ message: 'Please add valid RPC URL' }),
  privateKey: z
    .string({ required_error: 'Please add private key' })
    .length(64, 'The length of private key should be 64 characters'),
  smartAccountAddress: z
    .string({ required_error: 'Please add smart account address' })
    .startsWith('0x', 'The smart account address should be a valid hex'),
  smartAccountBundlerKey: z.string({
    required_error: 'Please add smart account bundler key',
  }),
  smartAccountBundlerUrl: z
    .string({ required_error: 'Please add smart account bundler url' })
    .url({ message: 'Please add valid smart account bundler url' }),
  smartAccountPaymasterKey: z.string({
    required_error: 'Please add smart account paymaster key',
  }),
  smartAccountPaymasterUrl: z
    .string({ required_error: 'Please add smart account paymaster url' })
    .url({ message: 'Please add valid smart account paymastter url' }),
  smartAccountSessionValidationModuleAddress: z
    .string({
      required_error:
        'Please add smart account session validation module address',
    })
    .startsWith(
      '0x',
      'The smart account session validation module address should be a valid hex',
    ),
  infuraProjectId: z.string({ required_error: 'Please add infura project ID' }),
  chainId: z.string({ required_error: 'Please add Chain Id' }),
  paymentManagementUrl: z.string({
    required_error: 'Please add Payment Manager URL',
  }),
  oceanAquariusUri: z
    .string({ required_error: 'Please add Aquarius url' })
    .url({ message: 'Please add valid Aquarius url' }),
  subgraphUri: z
    .string({ required_error: 'Please add subgraph url' })
    .url({ message: 'Please add valid subgraph url' }),
  oceanProviderUri: z
    .string({ required_error: 'Please add oceanProvider url' })
    .url({ message: 'Please add valid oceanProvider url' }),
  biconomyDashboardAuthToken: z.string({
    required_error: 'Please add BICONOMY_DASHBOARD_AUTH_TOKEN',
  }),
  biconomyDashboardURL: z
    .string({ required_error: 'Please add BICONOMY_DASHBOARD_URL' })
    .url({ message: 'Please add valid BICONOMY_DASHBOARD_URL' }),
  userRole: z.string({ required_error: 'Please add USER_ROLE' }),
  merkleRoot: z.string({ required_error: 'Please add MERKLE_ROOT' }),
  sessionKeys: z.string({ required_error: 'Please add SESSION_KEYS' }),
  baseToken: z.string({ required_error: 'No BaseToken found' }),
  tokenDecimal: z.string({ required_error: 'No TokenDecimal found' }),
});

function ensureNonEmptyArray<T extends readonly unknown[]>(
  arr: T,
): [T[0], ...T] {
  if (arr.length === 0) {
    throw new Error('Array must contain at least one item');
  }
  return arr as unknown as [T[0], ...T];
}
const categoriesList = ensureNonEmptyArray(CATEGORIES_LIST);
const fileTypeRegex = new RegExp(`\\.(${INPUT_OUTPUT_FILE_TYPES.join('|')})$`);

export const commonFieldsValidationMetadata = z.object({
  type: z
    .string({ required_error: 'Required field' })
    .regex(/dataset|algorithm/, {
      message: `Type field must be either '${ASSET_TYPE.DATASET}' or '${ASSET_TYPE.ALGORITHM}'`,
    }),
  name: z
    .string({
      required_error: 'Required field',
    })
    .max(
      ATTRIBUTE_MAX_CHARACTERS.NAME,
      `Name field exceeded ${ATTRIBUTE_MAX_CHARACTERS.NAME} characters`,
    ),
  overview: z
    .string({ required_error: 'Required field' })
    .max(
      ATTRIBUTE_MAX_CHARACTERS.OVERVIEW,
      `Overview field exceeded ${ATTRIBUTE_MAX_CHARACTERS.OVERVIEW} characters`,
    ),
  description: z
    .string({ required_error: 'Required field' })
    .max(
      ATTRIBUTE_MAX_CHARACTERS.DESCRIPTION,
      `Description field exceeded ${ATTRIBUTE_MAX_CHARACTERS.DESCRIPTION} characters`,
    ),
  categories: z.array(z.enum(categoriesList), {
    required_error: 'Required field',
    invalid_type_error: 'Invalid value for categories field',
  }),
  accessPermission: z
    .string({
      required_error: 'Required field',
    })
    .regex(/allow|deny/, {
      message: `Access Permissions field must be either '${ACCESS_PERMISSIONS.ALLOW}' or '${ACCESS_PERMISSIONS.DENY}'`,
    }),
  eulaUrl: z
    .string({ required_error: 'Required field' })
    .url('EULA Url field must be a valid URL.'),
  serviceType: z
    .string({ required_error: 'Required field' })
    .regex(/access|compute/, {
      message: `Service Type field must be either 'access' or 'compute'`,
    }),
  serviceFilesType: z.string({ required_error: 'Required field' }),
  serviceFilesUrl: z
    .string({ required_error: 'Required field' })
    .url('Service Files Url field must be a valid URL.'),
  serviceEndpoint: z
    .string({ required_error: 'Required field' })
    .url('Service Endpoint field must be a valid URL.'),
  sampleFileUrl: z
    .string({ required_error: 'Required field' })
    .url('Sample File Url field must be a valid URL.'),
  timeout: z
    .number({ required_error: 'Required field' })
    .superRefine((val, ctx) => {
      if (![900, 3600, 86400, 604800, 2630000].includes(val)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Timeout field must be one of 900, 3600, 86400, 604800, or 2630000.`,
        });
      }
    }),
  isExperimental: z.boolean({
    required_error: 'Required field',
    invalid_type_error: 'Invalid type for IsExperimental field',
  }),
  tags: z
    .array(z.string(), {
      invalid_type_error: 'Tags field is expected to an array',
    })
    .optional(),
  priceType: z
    .string({
      invalid_type_error: 'Price type field must be a string',
    })
    .optional(),
  postPayType: z
    .string({
      invalid_type_error: 'Post pay type field must be a string',
    })
    .optional(),
  postPayPriceTokenSymbol: z
    .string({
      invalid_type_error: 'Post pay price token symbol field must be a string',
    })
    .optional(),
  postPayPriceValue: z
    .string({
      invalid_type_error: 'Post pay price value field must be a string',
    })
    .optional(),
  price: z
    .string()
    .regex(/^\d+$/, {
      message: 'Price field must contain only digits',
    })
    .optional(),
});
export type CommonFieldsValidationMetadata = z.infer<
  typeof commonFieldsValidationMetadata
>;

export const publishDatasetFieldsValidationMetadata = z.object({
  aggregateOnly: z.boolean({
    required_error: 'Required field',
    invalid_type_error: 'Invalid type for AggregateOnly field',
  }),
});
export type PublishDatasetFieldsValidationMetadata = z.infer<
  typeof publishDatasetFieldsValidationMetadata
>;

export const publishAlgorithmFieldsValidationMetadata = z.object({
  inputFileType: z
    .string()
    .regex(fileTypeRegex, {
      message: `Input file type must be one of the following: ${INPUT_OUTPUT_FILE_TYPES.map((type) => `'.${type}'`).join(', ')}`,
    })
    .optional(),
  outputFileType: z
    .string()
    .regex(fileTypeRegex, {
      message: `Output file type must be one of the following: ${INPUT_OUTPUT_FILE_TYPES.map((type) => `'.${type}'`).join(', ')}`,
    })
    .optional(),
  algorithmType: z
    .string({ required_error: 'Required field' })
    .regex(/basic|federated|aggregate/, {
      message: `Algorithm Type field must be either '${ALGORITHM_TYPE.BASIC}', '${ALGORITHM_TYPE.FEDERATED}' or '${ALGORITHM_TYPE.AGGREGATE}'`,
    }),
  algorithmEntrypoint: z.string({ required_error: 'Required field' }),
  algorithmImage: z.string({ required_error: 'Required field' }),
  algorithmTag: z.string({ required_error: 'Required field' }),
  algorithmChecksum: z
    .string({ required_error: 'Required field' })
    .regex(/^sha256:[a-fA-F0-9]{64}$/, {
      message: 'Algorithm checksum field must be a valid sha256 checksum',
    }),
  algorithmReferenceUrl: z
    .string({ required_error: 'Required field' })
    .url('Algorithm reference url field must be a valid URL.'),
});
export type PublishAlgorithmFieldsValidationMetadata = z.infer<
  typeof publishAlgorithmFieldsValidationMetadata
>;

export const eoabootstrapOptions = z.object({
  rpcUrl: z
    .string({ required_error: 'Please add RPC URL' })
    .url({ message: 'Please add valid RPC URL' }),
  privateKey: z
    .string({ required_error: 'Please add private key' })
    .length(64, 'The length of private key should be 64 characters'),
  infuraProjectId: z.string({ required_error: 'Please add infura project ID' }),
  chainId: z.string({ required_error: 'Please add Chain Id' }),
  paymentManagementUrl: z.string({
    required_error: 'Please add Payment Manager URL',
  }),
  oceanAquariusUri: z
    .string({ required_error: 'Please add oceanAquarius url' })
    .url({ message: 'Please add valid oceanAquarius url' }),
  subgraphUri: z
    .string({ required_error: 'Please add subgraph url' })
    .url({ message: 'Please add valid subgraph url' }),
  oceanProviderUri: z
    .string({ required_error: 'Please add oceanProvider url' })
    .url({ message: 'Please add valid oceanProvider url' }),
  baseToken: z.string({ required_error: 'No BaseToken found' }),
  tokenDecimal: z.string({ required_error: 'No TokenDecimal found' }),
});

export type AAProvidersBootstrapOptions = z.infer<typeof aabootstrapOptions>;

export type EOAProvidersBootstrapOptions = z.infer<typeof eoabootstrapOptions>;
export class NonAccountAbstractionProviders {
  public signer: Signer;
  public config: Config;
  public aquarius: Aquarius;
  public providerUrl: string;
  public macOsProviderUrl: string;
  public chainId: number;

  constructor(
    network: string | number,
    config: Config,
    options: EOAProvidersBootstrapOptions,
  ) {
    const { privateKey, rpcUrl, oceanAquariusUri } = options;
    this.initializeEthereum(
      network,
      config,
      privateKey,
      oceanAquariusUri,
      rpcUrl,
    );
  }

  private async initializeEthereum(
    network: string | number,
    config: Config,
    privateKey: string,
    oceanAquariusUri: string,
    rpcUrl: string,
  ): Promise<void> {
    const provider = new ethers.providers.JsonRpcProvider(rpcUrl);
    console.log('Using RPC: ' + rpcUrl);

    this.signer = new ethers.Wallet(privateKey, provider);
    this.chainId = parseInt(network as string);
    this.config = config;
    this.providerUrl = this.config.providerUri!;
    this.macOsProviderUrl &&
      console.log(' -> MacOS provider url :', this.macOsProviderUrl);
    this.aquarius = new Aquarius(oceanAquariusUri);
    console.log('Using Aquarius :', oceanAquariusUri);
  }
  async getChainId(): Promise<number> {
    return this.signer?.getChainId();
  }
  get getSigner(): Signer {
    return this.signer;
  }
  get oceanConfig(): Config {
    return this.config;
  }
  get Aquarius(): Aquarius {
    return this.aquarius;
  }
}

export class AlchemyAccountAbstractionProviders {
  public _jsonRpcProvider: ethers.providers.JsonRpcProvider;
  public _chainId: number;
  public _signer: ethers.Wallet;
  public _smartAccount: any;
  public _oceanConfig: Config;
  public _nftFactory: NftFactory;
  public _nft: Nft;

  constructor(options: AlchemyProvidersBootstrapOptions) {
    this.bootstrap(options);
  }
  async bootstrap(options: AlchemyProvidersBootstrapOptions) {
    try {
      this._jsonRpcProvider = createJsonRpcProvider({
        rpcUrl: options.rpcUrl,
      });

      this._chainId = parseInt(options.chainId);

      this._signer = createSigner({
        privateKey: options.privateKey,
        chainId: this._chainId,
        jsonRpcProvider: this._jsonRpcProvider,
      });

      const alchemySigner = LocalAccountSigner.privateKeyToAccountSigner(
        `0x${options.privateKey}`,
      );
      this._smartAccount = await createAlchemySmartAccount({
        orgSmartAccount: options.smartAccountAddress,
        chainId: this._chainId,
        signer: alchemySigner,
        userRole: options.userRole,
        apiKey: options.apiKey,
        eventType: options.eventType,
      });

      transactionManager.init(
        this._signer,
        this._smartAccount,
        undefined,
        ACCOUNT_PROVIDERS.ALCHEMY,
      );

      this._oceanConfig = createOceanConfig({
        chainId: this._chainId,
        infuraProjectId: options.infuraProjectId,
      });

      this._nftFactory = createNftFactory({
        oceanConfig: this._oceanConfig,
        signer: this._signer,
      });

      this._nft = createNft({
        chainId: this._chainId,
        signer: this._signer,
      });
    } catch (e) {
      console.log('Unable to boostrap the CLI: ', e);
    }
  }

  get jsonRpcProvider() {
    return this._jsonRpcProvider;
  }

  get chainId() {
    return this._chainId;
  }

  get signer() {
    return this._signer;
  }

  get smartAccount() {
    return this._smartAccount;
  }

  get oceanConfig() {
    return this._oceanConfig;
  }

  get nftFactory() {
    return this._nftFactory;
  }

  get nft() {
    return this._nft;
  }
}

export class AccountAbstractionProviders {
  public _jsonRpcProvider: ethers.providers.JsonRpcProvider;
  public _chainId: number;
  public _signer: ethers.Wallet;
  public _smartAccount: BiconomySmartAccountV2;
  public _oceanConfig: Config;
  public _nftFactory: NftFactory;
  public _nft: Nft;

  constructor(options: AAProvidersBootstrapOptions) {
    this.bootstrap(options);
  }
  async bootstrap(options: AAProvidersBootstrapOptions) {
    try {
      this._jsonRpcProvider = createJsonRpcProvider({
        rpcUrl: options.rpcUrl,
      });

      this._chainId = parseInt(options.chainId);

      this._signer = createSigner({
        privateKey: options.privateKey,
        chainId: this._chainId,
        jsonRpcProvider: this._jsonRpcProvider,
      });

      this._smartAccount = await createSmartAccount({
        accountAddress: options.smartAccountAddress,
        chainId: this._chainId,
        jsonRpcProvider: this._jsonRpcProvider,
        signer: this._signer,
        bundlerKey: options.smartAccountBundlerKey,
        bundlerUrl: options.smartAccountBundlerUrl,
        paymasterKey: options.smartAccountPaymasterKey,
        paymasterUrl: options.smartAccountPaymasterUrl,
        debug: false,
        userRole: options.userRole,
        merkleRoot: options.merkleRoot,
        sessionKeys: options.sessionKeys,
      });

      transactionManager.init(
        this._signer,
        this._smartAccount,
        options.smartAccountSessionValidationModuleAddress,
        ACCOUNT_PROVIDERS.BICONOMY,
      );

      this._oceanConfig = createOceanConfig({
        chainId: this._chainId,
        infuraProjectId: options.infuraProjectId,
      });

      this._nftFactory = createNftFactory({
        oceanConfig: this._oceanConfig,
        signer: this._signer,
      });

      this._nft = createNft({
        chainId: this._chainId,
        signer: this._signer,
      });
    } catch (e) {
      console.log('Unable to boostrap the CLI: ', e);
    }
  }

  get jsonRpcProvider() {
    return this._jsonRpcProvider;
  }

  get chainId() {
    return this._chainId;
  }

  get signer() {
    return this._signer;
  }

  get smartAccount() {
    return this._smartAccount;
  }

  get oceanConfig() {
    return this._oceanConfig;
  }

  get nftFactory() {
    return this._nftFactory;
  }

  get nft() {
    return this._nft;
  }
}
