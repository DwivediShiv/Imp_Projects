import { BigNumber, ethers } from 'ethers';
import { TransactionResponse } from '@ethersproject/abstract-provider';
import { transactionManager } from './transaction-manager';

export interface SignerOptions {
  privateKey: string;
  jsonRpcProvider: ethers.providers.JsonRpcProvider;
  chainId: number;
}

export function createSigner(options: SignerOptions): ethers.Wallet {
  const privateKey = options.privateKey;
  const signer = new ethers.Wallet(privateKey, options.jsonRpcProvider);

  signer.sendTransaction = async function (
    transaction,
  ): Promise<TransactionResponse | any> {
    const hexTx = (<any>this.provider.constructor).hexlifyTransaction(
      transaction,
      {
        from: true,
      },
    );
    try {
      const hash = await options.jsonRpcProvider.send('eth_sendTransaction', [
        hexTx,
      ]);
      const trxResult = transactionManager.getTransactionResult();
      //  can remove `trxResult?.receipt` if removing biconomy
      const userOpReceipt: any = trxResult?.receipt || trxResult;

      return {
        data: hexTx,
        chainId: options.chainId,
        value: transaction.value as BigNumber,
        hash,
        blockHash: userOpReceipt?.blockHash,
        blockNumber: userOpReceipt?.blockNumber,
        from: userOpReceipt?.from,
        confirmations: userOpReceipt?.confirmations,
        nonce: trxResult?.nonce,
        gasLimit: transaction.gasLimit as BigNumber,
        wait: async () => userOpReceipt,
      };
    } catch (e) {
      console.log('eth_sendTransaction failed: ', e);
    }
  };
  return signer;
}
