import {
  createMultiOwnerModularAccount,
  sessionKeyPluginActions,
  pluginManagerActions,
  accountLoupeActions,
  multiOwnerPluginActions,
} from '@alchemy/aa-accounts';
import {
  createSmartAccountClient,
  Address,
  LocalAccountSigner,
} from '@alchemy/aa-core';
import axios, { AxiosResponse } from 'axios';
import { Signer, ethers } from 'ethers';
import { chain } from 'lodash';
import { ApiResponse } from '../../helper';
import { http, Hex } from 'viem';
import {
  getAlchemyCoreChainConfig,
  fancyGetAlchemyPaymasterAddress,
  getAlchemyRpcTransport,
} from './utils';
import { getSponsorTransactionUrl } from '../../../utils/api';
import { createModularAccountAlchemyClient } from '@alchemy/aa-alchemy';
import { type PrivateKeyAccount } from 'viem';

interface AlchemySmartAccountOptions {
  apiKey: string;
  chainId: number;
  userRole: string;
  orgSmartAccount: string;
  signer: LocalAccountSigner<PrivateKeyAccount>;
  eventType: string;
}

export async function createAlchemySmartAccount(
  options: AlchemySmartAccountOptions,
) {
  const { apiKey, chainId, userRole, orgSmartAccount, signer, eventType } =
    options;
  if (!eventType) return null
  const rpcTransport = http(getAlchemyRpcTransport(chainId) + apiKey);

  const smartAccountClient = createSmartAccountClient({
    opts: {
      txMaxRetries: 150,
      txRetryIntervalMs: 5000,
      txRetryMultiplier: 1,
    },
    transport: rpcTransport,
    chain: getAlchemyCoreChainConfig(chainId),
    account: await createMultiOwnerModularAccount({
      transport: rpcTransport,
      chain: getAlchemyCoreChainConfig(chainId),
      signer,
      accountAddress:
        orgSmartAccount && userRole !== 'super-admin'
          ? (orgSmartAccount as Address)
          : undefined,
    }),
    paymasterAndData: {
      dummyPaymasterAndData: () => {
        return `${fancyGetAlchemyPaymasterAddress(chainId)}0x` as Hex;
      },
      paymasterAndData: async (userop, opts) => {
        try {
          const [
            initCode,
            nonce,
            callData,
            maxFeePerGas,
            maxPriorityFeePerGas,
          ] = await Promise.all([
            (userop as any)?.initCode,
            userop?.nonce,
            userop?.callData,
            userop?.maxFeePerGas,
            userop?.maxPriorityFeePerGas,
          ]);
          // Construct the message
          const message = JSON.stringify({
            signerAddress: opts.account.publicKey,
            eventType,
            timestamp: new Date().toISOString(),
            component: 'sdk',
          });

          const [dummySignature, signature] = await Promise.all([
            opts?.client?.account?.getDummySignature(),
            signer.signMessage(message),
          ]);

          const payload = {
            authService: 'signature',
            message,
            chainId,
            dummySignature,
            entryPoint: opts?.client?.account?.getEntryPoint().address,
            userOperation: {
              ...userop,
              initCode,
              callData: ethers.utils.hexlify(callData),
              maxFeePerGas: ethers.utils.hexlify(maxFeePerGas as any),
              maxPriorityFeePerGas: ethers.utils.hexlify(
                maxPriorityFeePerGas as any,
              ),
              nonce: ethers.utils.hexlify(nonce),
            },
          };
          const apiResponse: AxiosResponse = await axios.post<ApiResponse<any>>(
            getSponsorTransactionUrl(),
            payload,
            {
              headers: {
                Authorization: signature,
              },
            },
          );
          if (apiResponse.status === 200) {
            return { ...userop, ...apiResponse.data.sponsorData.result };
          }
          return userop;
        } catch (e) {
          console.error('[paymasterAndData] Sponsorship Error=', e);
          return userop;
        }
      },
    },
  })
    .extend(sessionKeyPluginActions)
    .extend(pluginManagerActions)
    .extend(accountLoupeActions)
    .extend(multiOwnerPluginActions);

  const isEligible = await smartAccountClient.checkGasSponsorshipEligibility({
    uo: [
      {
        data: '0x',
        target: (await signer.getAddress()) as Address,
        value: 0n,
      },
    ],
    account: smartAccountClient.account,
  });
  console.log(`Credential input is ${isEligible ? 'valid' : 'invalid'}.`);
  return smartAccountClient;
}
