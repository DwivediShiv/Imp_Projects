import { getAlchemyPaymasterAddress } from '@alchemy/aa-alchemy';
import { polygon, polygonAmoy, sepolia } from '@alchemy/aa-core';
import { Chain } from 'viem';

export function getAlchemyCoreChainConfig(chainId: number): Chain | any {
  switch (chainId) {
    case 11155111:
      return sepolia;
    case 137:
      return polygon;
    case 80002:
      return polygonAmoy;
  }
}

// Refer to: https://docs.alchemy.com/reference/gas-manager-deployment-addresses
export function fancyGetAlchemyPaymasterAddress(chainId: number): string {
  return getAlchemyPaymasterAddress(
    getAlchemyCoreChainConfig(chainId) as Chain,
  );
}

export function getAlchemyRpcTransport(chainId: number): string | undefined {
  switch (chainId) {
    case 11155111:
      return 'https://eth-sepolia.g.alchemy.com/v2/';
    case 137:
      return 'https://polygon-mainnet.g.alchemy.com/v2/';
    case 80002:
      return 'https://polygon-amoy.g.alchemy.com/v2/';
  }
}
