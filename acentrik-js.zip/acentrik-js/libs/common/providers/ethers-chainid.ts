import { ethers } from 'ethers';

export interface ChainOptions {
  jsonRpcProvider: ethers.providers.JsonRpcProvider;
}

export async function createChainId(options: ChainOptions): Promise<number> {
  const network = await options.jsonRpcProvider.getNetwork();
  return network.chainId;
}
