import { ConfigHelper, Config } from '@oceanprotocol/lib';

export interface OceanConfigOptions {
  infuraProjectId: string;
  chainId: number;
}

export function createOceanConfig(options: OceanConfigOptions): Config {
  // TODO: Enhance the config to support subgrapb, rbac, ocean token, ocean symbol and other ocean configs
  return new ConfigHelper().getConfig(options.chainId, options.infuraProjectId);
}
