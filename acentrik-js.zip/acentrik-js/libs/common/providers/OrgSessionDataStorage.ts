import {
    ISessionStorage,
    SessionLeafNode,
    SessionSearchParam,
    SessionStatus
  } from '@biconomy/modules/dist/src/interfaces/ISessionStorage'
  import { Wallet, Signer } from 'ethers'
  import { CreateSessionDataParams } from '@biconomy/modules'
  
  export interface SmartAccountSessionProps {
    merkleRoot: string
    sessionKeys: SessionLeafNode[]
  }
  
  export class OrgSessionDataStorage implements ISessionStorage {
    private organizationId: string
    private privateSessionKeys: SmartAccountSessionProps
    private initMerkleRootTransaction: boolean
  
    constructor(sessionKeys: SmartAccountSessionProps) {
      this.organizationId
      this.privateSessionKeys = sessionKeys
      this.initMerkleRootTransaction = false
    }
  
    private validateSearchParam(param: SessionSearchParam): void | boolean {
      if (param.sessionPublicKey) {
        return true
      } else {
        throw new Error('SessionPublicKey is only Valid search Parameter.')
      }
    }
  
    private getPrivateSessionData(): SmartAccountSessionProps {
      return this.privateSessionKeys
    }
  
    private mapSessionKeysToCreateSessionParams(
      sessionKey: SessionLeafNode
    ): CreateSessionDataParams {
      const {
        sessionPublicKey,
        validAfter,
        validUntil,
        sessionKeyData,
        sessionValidationModule
      } = sessionKey
  
      return {
        sessionPublicKey,
        validAfter,
        validUntil,
        sessionKeyData,
        sessionValidationModule
      }
    }
  
    resetStorageSessionKeys() {
      this.privateSessionKeys = {
        merkleRoot: '',
        sessionKeys: []
      }
    }
  
    getCleanedSessionData(
      sessionKeys: SessionLeafNode[]
    ): CreateSessionDataParams[] {
      const cleanedSessionData = sessionKeys.map(
        this.mapSessionKeysToCreateSessionParams
      )
      return cleanedSessionData
    }
  
    async addSessionData(sessionKey: SessionLeafNode): Promise<void> {
      const { sessionKeys: cachedKeys } = this.getPrivateSessionData()
      const index = cachedKeys.findIndex(
        (key) => key.sessionPublicKey === sessionKey.sessionPublicKey
      )
  
      if (index !== -1) {
        sessionKey.sessionValidationModule =
          sessionKey.sessionValidationModule.toLowerCase()
  
        sessionKey.sessionPublicKey = sessionKey.sessionPublicKey.toLowerCase()
  
        sessionKey.status = 'ACTIVE'
        this.privateSessionKeys.sessionKeys[index] = sessionKey
      } else {
        sessionKey.sessionValidationModule =
          sessionKey.sessionValidationModule.toLowerCase()
  
        sessionKey.sessionPublicKey = sessionKey.sessionPublicKey.toLowerCase()
        sessionKey.status = 'ACTIVE'
        this.privateSessionKeys.sessionKeys.push(sessionKey)
      }
    }
  
    removeSessionData(sessionPublicKey: string): SessionLeafNode[] {
      const { sessionKeys: cachedKeys } = this.getPrivateSessionData()
      const finalSessionKeys = cachedKeys.filter(
        (sessionKey) =>
          sessionKey.sessionPublicKey.toLowerCase() !==
          sessionPublicKey.toLowerCase()
      )
      return finalSessionKeys
    }
  
    async getSessionData(param: SessionSearchParam): Promise<SessionLeafNode> {
      this.validateSearchParam(param);
  
      const { sessionKeys } = this.getPrivateSessionData()
      const sessionKey = sessionKeys.find((s: SessionLeafNode) => {
        if (param.sessionPublicKey && param.sessionValidationModule) {
          return (
            s.sessionPublicKey.toLowerCase() ===
              param.sessionPublicKey.toLowerCase() &&
            s.sessionValidationModule ===
              param.sessionValidationModule.toLowerCase() &&
            (!param.status || s.status === param.status)
          )
        } else {
          return undefined
        }
      })
  
      if (!sessionKey) {
        throw new Error("Session not found.");
      }
      return sessionKey;
    }
  
    async updateSessionStatus(
      param: SessionSearchParam,
      status: SessionStatus
    ): Promise<void> {
      // Not Implementing till we have actual use for this
    }
  
    async clearPendingSessions(): Promise<void> {
      // Not Implementing till we have actual use for this
    }
  
    async addSigner(signer: Wallet): Promise<Wallet> {
      // Not Implementing till we have actual use for this
      return undefined
    }
  
    async getSignerByKey(sessionPublicKey: string): Promise<Signer> {
      // Not Implementing till we have actual use for this
      return undefined
    }
  
    async getSignerBySession(param: SessionSearchParam): Promise<Signer> {
      // Not Implementing till we have actual use for this
      return undefined
    }
  
    async getAllSessionData(
      param?: SessionSearchParam
    ): Promise<SessionLeafNode[]> {
      return this.privateSessionKeys.sessionKeys
    }
  
    getMerkleRoot(): Promise<string> {
      const { merkleRoot } = this.getPrivateSessionData()
      return Promise.resolve(merkleRoot)
    }
  
    async setMerkleRoot(merkleRoot: string): Promise<void> {
      if (!this.initMerkleRootTransaction) {
        this.initMerkleRootTransaction = true
        this.privateSessionKeys.merkleRoot = merkleRoot
      } else {
        this.privateSessionKeys.merkleRoot = merkleRoot
      }
      return Promise.resolve()
    }
  
  
    async updateSessionKeysInDataStorage(): Promise<void> {
      // Not needed in Sdk
    }
  
    async addUserSessionKey(
      addSessionParam: CreateSessionDataParams
    ): Promise<CreateSessionDataParams[]> {
      const sessionKeys = await this.getAllSessionData()
      let finalSessionKeys: CreateSessionDataParams[]
      if (sessionKeys.length !== 0) {
        const existingSessionKeys = this.getCleanedSessionData(sessionKeys)
        finalSessionKeys = [...existingSessionKeys, addSessionParam]
      } else {
        finalSessionKeys = [addSessionParam]
      }
      return finalSessionKeys
    }
  
    async removeUserSessionKey(
      userEoa: string
    ): Promise<CreateSessionDataParams[]> {
      const sessionKeys = await this.getAllSessionData()
      let finalSessionKeys: CreateSessionDataParams[]
      if (sessionKeys.length !== 0) {
        const filteredKeys = this.removeSessionData(userEoa)
        finalSessionKeys = this.getCleanedSessionData(filteredKeys)
      } else {
        finalSessionKeys = []
      }
      return finalSessionKeys
    }
  
    async updateSessionKeys(
      addSessionParam: CreateSessionDataParams
    ): Promise<CreateSessionDataParams[]> {
      const sessionKeys = await this.getAllSessionData()
      const existingSessionKeys = this.getCleanedSessionData(sessionKeys)
      let sessionFound = false
  
      const finalSessionKeys: CreateSessionDataParams[] = existingSessionKeys.map(
        (key) => {
          if (key.sessionPublicKey === addSessionParam.sessionPublicKey) {
            sessionFound = true
            return addSessionParam
          } else {
            return key
          }
        }
      )
      if (!sessionFound) {
        throw Error('User Session Key not Found')
      }
      return finalSessionKeys
    }
  
    async replaceSessionKey(
      addSessionParam: CreateSessionDataParams,
      addressToReplace: string
    ): Promise<CreateSessionDataParams[]> {
      const sessionKeys = await this.getAllSessionData()
      let filteredKeys: SessionLeafNode[]
      if (sessionKeys.length !== 0) {
        filteredKeys = this.removeSessionData(addressToReplace)
      } else {
        filteredKeys = []
      }
  
      let finalSessionKeys: CreateSessionDataParams[]
      if (filteredKeys.length !== 0) {
        const existingSessionKeys = this.getCleanedSessionData(filteredKeys)
        finalSessionKeys = [...existingSessionKeys, addSessionParam]
      } else {
        finalSessionKeys = [addSessionParam]
      }
      return finalSessionKeys
    }
  }
  