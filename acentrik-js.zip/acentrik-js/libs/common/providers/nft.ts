import { Nft } from '@oceanprotocol/lib';
import { ethers } from 'ethers';

export interface NftOptions {
  signer: ethers.Wallet;
  chainId: number;
}

export function createNft(options: NftOptions) {
  return new Nft(options.signer, options.chainId);
}
