import { ethers } from 'ethers';
import {
  BiconomySmartAccountV2,
  BiconomySmartAccountV2Config,
} from '@biconomy/account';
import {
  CreateSessionDataParams,
  DEFAULT_ENTRYPOINT_ADDRESS,
  ECDSAOwnershipValidationModule,
  SessionKeyManagerModule,
} from '@biconomy/modules';
import { BiconomyPaymaster, IPaymaster } from '@biconomy/paymaster';
import { Bundler, IBundler } from '@biconomy/bundler';
import { Logger } from '@biconomy/common';
import {
  OrgSessionDataStorage,
  SmartAccountSessionProps,
} from './OrgSessionDataStorage';
import { SessionLeafNode } from '@biconomy/modules/dist/src/interfaces/ISessionStorage';
import { AcetrikSessionKeyManagerModule } from './OrgSessionKeyManagerModule';

export interface SmartAccountOptions {
  jsonRpcProvider: ethers.providers.JsonRpcProvider;
  signer: ethers.Wallet;
  chainId: number;
  paymasterUrl: string;
  paymasterKey: string;
  bundlerUrl: string;
  bundlerKey: string;
  accountAddress: string;
  debug: boolean;
  userRole: string,
  merkleRoot: string,
  sessionKeys: any
}

export async function instantiateSessionKeyManagerModule(
  smartAccount: BiconomySmartAccountV2,
  options: SmartAccountOptions
) {
  // fetch role as environment variable super-admin ,admin, user-role check from market
  const userRole = options.userRole;

  if (userRole === 'super-admin') {
    return smartAccount;
  }
  const smartAccountAddress = await smartAccount?.getAccountAddress()

  const marketSessionKeys: SmartAccountSessionProps = {
    merkleRoot: options.merkleRoot,
    sessionKeys: JSON.parse(options.sessionKeys)
  }
  const OrgSessionStore = new OrgSessionDataStorage(marketSessionKeys)

  const skmModule = await AcetrikSessionKeyManagerModule.create({
    smartAccountAddress,
    entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
    version: 'V1_0_0',
    OrgStorage: OrgSessionStore
  })
  
  skmModule.sessionStorageClient = new OrgSessionDataStorage(marketSessionKeys)

  const sessionKeys: SessionLeafNode[] =
    await skmModule.sessionStorageClient.getAllSessionData();

  let existingSessionKeys: CreateSessionDataParams[];
  if (sessionKeys.length !== 0) {
    existingSessionKeys = (
      skmModule.sessionStorageClient as OrgSessionDataStorage
    ).getCleanedSessionData(sessionKeys);
    await skmModule.createSessionData(existingSessionKeys);
  }
  smartAccount?.setActiveValidationModule(skmModule);
  return smartAccount;
}

export async function createSmartAccount(
  options: SmartAccountOptions,
): Promise<BiconomySmartAccountV2> {
  Logger.isDebug = options.debug;

  const ecdsaModule = await ECDSAOwnershipValidationModule.create({
    signer: options.signer,
    entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
    version: 'V1_0_0',
  });

  const paymaster: IPaymaster = new BiconomyPaymaster({
    paymasterUrl: [
      options.paymasterUrl,
      options.chainId,
      options.paymasterKey,
    ].join('/'),
  });

  const bundler: IBundler = new Bundler({
    bundlerUrl: [options.bundlerUrl, options.chainId, options.bundlerKey].join(
      '/',
    ),
    chainId: options.chainId,
    entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
    userOpReceiptIntervals: {
      [options.chainId]: 3000,
    },
  });

  const smartAccountConfig: BiconomySmartAccountV2Config = {
    chainId: options.chainId,
    defaultValidationModule: ecdsaModule,
    entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
    provider: options.jsonRpcProvider,
    bundler,
    paymaster,
    accountAddress: options.accountAddress,
  };

  const smartAccount = await BiconomySmartAccountV2.create(smartAccountConfig);
  const activeSmartAccount = instantiateSessionKeyManagerModule(smartAccount, options);
  return activeSmartAccount;
}
