import { ethers } from 'ethers';
import { Transaction } from '@biconomy/core-types';
import { transactionManager } from './transaction-manager';

export interface JsonRpcProviderOptions {
  rpcUrl: string;
}

export function createJsonRpcProvider(
  options: JsonRpcProviderOptions,
): ethers.providers.JsonRpcProvider {
  const rpcUrl = options.rpcUrl;
  const provider = new ethers.providers.JsonRpcProvider(rpcUrl);
  const jsonRpcProviderSend = provider.send.bind(provider);
  provider.send = async function (method: string, params: Transaction[]) {
    return await transactionManager.sendTransaction(
      method,
      params,
      jsonRpcProviderSend,
    );
  };
  return provider;
}
