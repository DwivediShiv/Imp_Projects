import { BiconomySmartAccountV2 } from '@biconomy/account';
import { UserOpReceipt } from '@biconomy/bundler';
import { Transaction } from '@biconomy/core-types';
import { ethers } from 'ethers';
import {
  IHybridPaymaster,
  PaymasterMode,
  SponsorUserOperationDto,
} from '@biconomy/paymaster';
import {
  parseTransactionDataUsingInterfaces,
  shouldTransactionGaslessTransactions,
} from '../contracts';
import { ACCOUNT_PROVIDERS } from '../constants';

export type JsonRpcProviderSendFn = (
  method: string,
  params: Transaction[],
) => Promise<unknown>;

class TransactionManager {
  private sendResult: UserOpReceipt | null;
  private signer: ethers.Wallet;
  private smartAccount: any;
  private sessionValidationModuleAddress?: string;
  private accountAbstractionProvider?: string;

  init(
    signer: ethers.Wallet,
    smartAccount: any | BiconomySmartAccountV2,
    sessionValidationModuleAddress?: string,
    accountAbstractionProvider?: string,
  ) {
    this.signer = signer;
    this.smartAccount = smartAccount;
    this.sessionValidationModuleAddress = sessionValidationModuleAddress;
    this.accountAbstractionProvider = accountAbstractionProvider;
  }

  setTransactionResult(result: UserOpReceipt | null) {
    this.sendResult = result;
  }

  getTransactionResult(): UserOpReceipt | null {
    return this.sendResult;
  }

  clearTransactionResult() {
    this.sendResult = null;
  }

  async sendTransaction(
    method: string,
    params: Transaction[],
    jsonRpcProviderSend: JsonRpcProviderSendFn,
  ): Promise<string | unknown> {
    if (method === 'eth_estimateGas') {
      return 0;
    }

    const txnDescription = parseTransactionDataUsingInterfaces(params[0]?.data);

    if (
      txnDescription &&
      shouldTransactionGaslessTransactions(txnDescription.name)
    ) {
      try {
        if (
          this.accountAbstractionProvider ===
          ACCOUNT_PROVIDERS.ALCHEMY
        ) {
          return await this.initiateAlchemyTransaction(params);
        }
        return await this.initiateGaslessTransaction(params);
      } catch (e) {
        console.error(
          '[transactionManager]: Error in executing eth_sendTransaction using biconomy: ',
          method,
          params,
          e,
        );
        return '';
      }
    } else {
      try {
        return await jsonRpcProviderSend(method, params);
      } catch (e) {
        console.error(
          "[transactionManager]: Error in executing jsonRpcProvider's request: ",
          method,
          params,
          e,
        );
        return '';
      }
    }
  }

  private async initiateAlchemyTransaction(
    params: Transaction[],
  ): Promise<string> {
    try {
      const isAccountSessionKey = await this.smartAccount.isAccountSessionKey({
        key: this.smartAccount.account.publicKey,
        account: this.smartAccount.account,
      });
      console.log('isAccountSessionKey=', isAccountSessionKey);
      if (isAccountSessionKey) {
        const signer = this.signer;

        const sessionKeyUo = await this.smartAccount.executeWithSessionKey({
          args: [
            [
              {
                target: ethers.utils.getAddress(params[0]?.to),
                data: ethers.utils.hexlify(params[0]?.data as any),
                value: ethers.utils.hexlify(params[0]?.value || 0n),
              },
            ],
            await signer.getAddress(),
          ],
        });
        const txHash = await this.smartAccount.waitForUserOperationTransaction({
          hash: sessionKeyUo.hash,
        });
        console.log('[sk.txHash]=', txHash);
        const txReceipt = await this.smartAccount.getTransactionReceipt({
          hash: txHash,
        });
        this.sendResult = txReceipt;
        return txHash;
      } else {
        const uoHash = await this.smartAccount.sendUserOperation({
          uo: {
            target: ethers.utils.getAddress(params[0]?.to),
            data: ethers.utils.hexlify(params[0]?.data as any),
          },
        });
        const txHash =
          await this.smartAccount.waitForUserOperationTransaction(uoHash);
        console.log('[txHash]=', txHash);
        const txReceipt = await this.smartAccount.getTransactionReceipt({
          hash: txHash,
        });
        this.sendResult = txReceipt;
        return txHash;
      }
    } catch (e) {
      console.error(
        '[transactionManager]: failed to execute user operations: ',
        e,
      );
      return '';
    }
  }

  private async initiateGaslessTransaction(
    params: Transaction[],
  ): Promise<string | undefined> {
    try {
      const userOp = await this.smartAccount.buildUserOp(params || [], {
        params: {
          sessionSigner: this.signer,
          sessionValidationModule: this.sessionValidationModuleAddress,
        },
      });

      const biconomyPaymaster = this.smartAccount
        .paymaster as IHybridPaymaster<SponsorUserOperationDto>;

      const paymasterServiceData: SponsorUserOperationDto = {
        mode: PaymasterMode.SPONSORED,
        smartAccountInfo: {
          name: 'BICONOMY',
          version: '2.0.0',
        },
        calculateGasLimits: true,
      };

      const result = await biconomyPaymaster.getPaymasterAndData(
        userOp,
        paymasterServiceData,
      );
      userOp.paymasterAndData = result.paymasterAndData;

      if (
        result.callGasLimit &&
        result.verificationGasLimit &&
        result.preVerificationGas
      ) {
        userOp.callGasLimit = result.callGasLimit;
        userOp.verificationGasLimit = result.verificationGasLimit;
        userOp.preVerificationGas = result.preVerificationGas;
      }

      const userOpResponse = await this.smartAccount.sendUserOp(userOp, {
        sessionSigner: this.signer,
        sessionValidationModule: this.sessionValidationModuleAddress,
      });

      const response = await userOpResponse.wait();
      this.sendResult = response;

      return this.sendResult?.receipt?.transactionHash;
    } catch (e) {
      console.error(
        '[transactionManager]: failed to execute user operations: ',
        e,
      );
      return '';
    }
  }
}

export const transactionManager = new TransactionManager();
