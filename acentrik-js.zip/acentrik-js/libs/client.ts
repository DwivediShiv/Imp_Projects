import fs from 'fs';
import { Aquarius } from '@oceanprotocol/lib';
import {
  AAProvidersBootstrapOptions,
  ACCOUNT_PROVIDERS,
  AlchemyAdapter,
  AlchemyProvidersBootstrapOptions,
  UNLIMITED_TIMEOUT,
  commandToEventType,
} from './common';
import { WalletAdapter } from './types/walletAdapter';
import { AAAdapter } from './common/adapters/aa-adapter';
import { EOAdapter } from './common/adapters/eoa-adapter';
import { downloadFile, readFileAndBootstrap } from './file-handler';
import { SdkParamsValues } from './types/publishTemplate';
import {
  getAlgorithmPublishDdo,
  getDatasetPublishDdo,
} from './template-converter/publish-template';
import { getEditDatasetDdo } from './template-converter/edit-template/getEditDatasetDdo';
import { getEditAlgoDdo } from './template-converter/edit-template/getEditAlgoDdo';
require('dotenv').config();

export default class Client {
  async executeCommand(
    command: string,
    args: string[],
    type: string,
  ): Promise<void> {
    const adapter = await this.createAdapter(type, command);
    if (!adapter) {
      console.log('Unknown adapter type:', type);
      return;
    }

    const commandMap: { [key: string]: () => Promise<void> } = {
      publish: async () => this.publishCommand(adapter, args),
      download: async () => this.downloadCommand(adapter, args),
      compute: () => adapter.compute(args[0], args[1]),
      aggregate: () => adapter.aggregate(args[0]),
      multipleCompute: async () => this.multipleComputeCommand(adapter, args),
      getDDO: () => adapter.getDDO(args[0]),
      getJobStatus: () => adapter.getJobStatus(args),
      getJobResults: () => adapter.getJobResults(args),
      downloadJobResults: async () =>
        this.downloadJobResultsCommand(adapter, args),
      stopCompute: () => adapter.stopCompute(args),
      disAllowAlgo: () => adapter.disAllowAlgo(args),
      allowAlgo: () => adapter.allowAlgo(args),
      editAsset: async () => this.editAssetCommand(adapter, args),
    };

    const execute = commandMap[command];
    if (execute) {
      await execute();
    } else {
      console.log('Unknown command. Type `help` to list all commands');
    }
  }

  private async publishCommand(
    adapter: WalletAdapter,
    args: string[],
  ): Promise<void> {
    try {
      const asset = JSON.parse(await fs.promises.readFile(args[0], 'utf8'));
      const envObj: SdkParamsValues = this.getEnvParams();

      if (this.isUnlimitedTimeoutDisabled(envObj, asset)) {
        console.error('Input error: Unlimited timeout is disabled');
        return;
      }

      let ddoAssetDetails = {};
      if (asset.type === 'dataset') {
        ddoAssetDetails = getDatasetPublishDdo(asset, envObj);
      } else if (asset.type === 'algorithm') {
        ddoAssetDetails = getAlgorithmPublishDdo(asset, envObj);
      }

      await adapter.publish(ddoAssetDetails);
    } catch (e) {
      console.log('Error while reading file:', e);
    }
  }

  private async downloadCommand(
    adapter: WalletAdapter,
    args: string[],
  ): Promise<void> {
    const result = await adapter.download(args[0], args[1]);
    const { filename } = await downloadFile(result, args[1]);
    console.log('File downloaded successfully:', `${args[1]}/${filename}`);
  }

  private async multipleComputeCommand(
    adapter: WalletAdapter,
    args: string[],
  ): Promise<void> {
    try {
      const { datasetDIDs, algoDIDs } = await readFileAndBootstrap(args[0]);
      await adapter.multipleCompute({ datasetDIDs, algoDIDs }, args[1]);
    } catch (e) {
      console.log('Error while reading file:', e);
    }
  }

  private async downloadJobResultsCommand(
    adapter: WalletAdapter,
    args: string[],
  ): Promise<void> {
    try {
      const result = await adapter.downloadJobResults(args);
      const { filename } = await downloadFile(result, args[3]);
      console.log('File downloaded successfully:', `${args[3]}/${filename}`);
    } catch (error) {
      console.log('Error while downloading job results');
    }
  }

  private async editAssetCommand(
    adapter: WalletAdapter,
    args: string[],
  ): Promise<void> {
    try {
      const asset = JSON.parse(await fs.promises.readFile(args[1], 'utf8'));
      const envObj = this.getEditEnvParams();

      if (this.isUnlimitedTimeoutDisabled(envObj, asset)) {
        console.error('Input error: Unlimited timeout is disabled');
        return;
      }

      const acc = new Aquarius(envObj.oceanAquariusUri as string);
      const existingDdo = await acc.waitForAqua(args[0]);

      if (!existingDdo) {
        console.error('Error fetching DDO. Does this asset exist?', args[0]);
        return;
      }

      let ddoAssetDetails = {};
      if (existingDdo.metadata.type === 'dataset') {
        ddoAssetDetails = getEditDatasetDdo(asset, existingDdo, envObj);
      } else if (existingDdo.metadata.type === 'algorithm') {
        ddoAssetDetails = getEditAlgoDdo(asset, existingDdo, envObj);
      }
      await adapter.editAsset([
        ddoAssetDetails,
        existingDdo,
        asset?.alternateWalletAddress,
      ]);
    } catch (e) {
      console.log('Error while reading file:', e);
    }
  }

  protected async createAdapter(
    type: string,
    command: string,
  ): Promise<WalletAdapter | null> {
    const eventType = commandToEventType[command] || '';
    const commonOptions = this.getCommonOptions();

    switch (type) {
      case ACCOUNT_PROVIDERS.ALCHEMY:
        return new AlchemyAdapter(
          this.getAlchemyOptions(commonOptions, eventType),
        );
      case ACCOUNT_PROVIDERS.BICONOMY:
        return new AAAdapter(this.getBiconomyOptions(commonOptions));
      case ACCOUNT_PROVIDERS.EOA:
      default:
        return new EOAdapter(process.env.CHAIN_ID || '', commonOptions);
    }
  }

  private getCommonOptions() {
    return {
      rpcUrl: process.env.RPC_URL || '',
      privateKey: process.env.PRIVATE_KEY || '',
      infuraProjectId: process.env.INFURA_PROJECT_ID || '',
      oceanProviderUri: process.env.OCEAN_PROVIDER_URL || '',
      subgraphUri: process.env.SUBGRAPH_URI || '',
      oceanAquariusUri: process.env.OCEAN_AQUARIUS_URL || '',
      chainId: process.env.CHAIN_ID || '',
      userRole: process.env.USER_ROLE || '',
      paymentManagementUrl: process.env.PAYMENT_MANAGEMENT_URL || '',
      baseToken: process.env.BASE_TOKEN || '',
      tokenDecimal: process.env.BASE_TOKEN_DECIMAL || '',
    };
  }

  private getAlchemyOptions(
    commonOptions: any,
    eventType: string,
  ): AlchemyProvidersBootstrapOptions {
    return {
      ...commonOptions,
      apiKey: process.env.API_KEY || '',
      smartAccountAddress: process.env.SMART_ACCOUNT_ADDRESS || '',
      subgraphUri: process.env.SUBGRAPH_URI || '',
      oceanAquariusUri: process.env.OCEAN_AQUARIUS_URL || '',
      eventType,
    };
  }

  private getBiconomyOptions(commonOptions: any): AAProvidersBootstrapOptions {
    return {
      ...commonOptions,
      smartAccountAddress: process.env.SMART_ACCOUNT_ADDRESS || '',
      smartAccountBundlerKey: process.env.SMART_ACCOUNT_BUNDLER_KEY || '',
      smartAccountBundlerUrl: process.env.SMART_ACCOUNT_BUNDLER_URL || '',
      smartAccountPaymasterKey: process.env.SMART_ACCOUNT_PAYMASTER_KEY || '',
      smartAccountPaymasterUrl: process.env.SMART_ACCOUNT_PAYMASTER_URL || '',
      smartAccountSessionValidationModuleAddress:
        process.env.SMART_ACCOUNT_SESSION_VALIDATION_MODULE_ADDRESS || '',
      biconomyDashboardAuthToken:
        process.env.BICONOMY_DASHBOARD_AUTH_TOKEN || '',
      biconomyDashboardURL: process.env.BICONOMY_DASHBOARD_URL || '',
      merkleRoot: process.env.MERKLE_ROOT || '',
      sessionKeys: process.env.SESSION_KEYS || '',
    };
  }

  private getEnvParams(): SdkParamsValues {
    return {
      chainId: process.env.CHAIN_ID,
      source: process.env.SOURCE,
      orgId: process.env.ORG_ID,
      signer: process.env.SIGNER_ADDRESS,
      baseToken: process.env.BASE_TOKEN,
      assetManagementTokenName: process.env.ASSET_MANAGEMENT_TOKEN_NAME,
      assetManagementTokenPrefix:
        process.env.ASSET_MANAGEMENT_TOKEN_SYMBOL_PREFIX,
      assetManagementTokenImageUrl:
        process.env.ASSET_MANAGEMENT_TOKEN_IMAGE_URL,
      serviceEndpoints: process.env.SERVICE_ENDPOINTS,
      isDisableParameterizeAsset: process.env.IS_DISABLE_PARAMETERIZE_ASSET,
      isDisableUnlimitedTimeout: process.env.IS_DISABLE_UNLIMITED_TIMEOUT,
    };
  }

  private getEditEnvParams() {
    return {
      baseToken: process.env.BASE_TOKEN,
      oceanAquariusUri: process.env.OCEAN_AQUARIUS_URL,
      serviceEndpoints: process.env.SERVICE_ENDPOINTS,
      signer: process.env.SIGNER_ADDRESS,
      isDisableParameterizeAsset: process.env.IS_DISABLE_PARAMETERIZE_ASSET,
      isDisableUnlimitedTimeout: process.env.IS_DISABLE_UNLIMITED_TIMEOUT,
    };
  }

  private isUnlimitedTimeoutDisabled(envObj: any, asset: any): boolean {
    return (
      envObj.isDisableUnlimitedTimeout === 'true' &&
      asset.timeoutDurationType?.toLowerCase() === UNLIMITED_TIMEOUT
    );
  }
}
