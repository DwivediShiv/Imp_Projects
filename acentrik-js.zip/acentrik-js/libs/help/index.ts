import { format } from 'node:util';

export function help() {
  console.log(`
  Usage:
  $ npm run cli <command> <arguments>


  Example:
  $ npm run cli publishDataset /Users/<username>/acentrik-js/data.json

===============================================

  Commands:
  getDDO                datasetDID                                      gets DDO for an asset using the asset did 
  publish               metadataFilePath                                reads MEDATDATA_FILE and publishes a new asset with access service or compute service
  editAsset             datasetDID metadataFilePath                     updates DDO using the metadata items in the file
  download              datasetDID destinationFolderPath                downloads an asset into destination folder
  allowAlgo             datasetDID algoDID                              approves an algorithm to run on a dataset
  disAllowAlgo          datasetDID algoDID                              removes an approved algorithm from the dataset approved algos
  compute          datasetDID algoDID                              starts a compute job on the mentioned dataset using the inputed algorithm's id
  stopCompute           datasetDID jobID                                stops the compute process for the mentioned dataset with the given job id
  getJobStatus          datasetDID jobID                                displays the compute job compute status
  getJobResults         datasetDID jobID                                displays the array containing compute results and logs filesn
  downloadJobResults    jobID resultIndex datasetDid destinationFolderPath         downloads compute job results
  multipleCompute  datasetDIDsFilePath algoDID                     starts multiiple compute jobs on the mentioned datasets using the inputed algorithm's id
  aggregate           multipleC2D's guid                              starts aggregation of the multiple c2d results using the guid provided 

===============================================
  `);

  console.log(
    'Commands Examples:',
    `
  'npm run cli getDDO did:op:35834588985efa12f7bd71eb45b585e4315695efbb70bed9621137ee927a9a97'

  'npm run cli publish C:/Development/NagarroDev/acentrik-js/data-files/publish-free-data.json'
  
  'npm run cli download did:op:40a348c9f10bfe8e4a49169ffe4c8248e72fd812d362d39772fdbb49646ba1f0 C:/Development/NagarroDev/acentrik-js/download'
  
  'npm run cli multipleCompute 'C:/Development/NagarroDev/acentrik-js/data-files/datasets-dids.json' did:op:46f36db17f50f111ff2d3e47fd130cfbfa1c496c945a3ca9ea3ad52b224c8e9a'
  
  'npm run cli aggregate b4d8a88c-6ef5-4901-9b98-f1fb353745bc'
  
  'npm run cli editAsset did:op:68d041f4694edd946b72a285101115d3b7f652f84834d624dd041a2058844071 C:/Development/NagarroDev/acentrik-js/data-files/data-edit-new.json'
  
  'npm run cli allowAlgo did:op:35834588985efa12f7bd71eb45b585e4315695efbb70bed9621137ee927a9a97 did:op:d8bd14ac38261a0b07c18cf39f61eda7cc7bfce72db40bfe7c2b09c33e0d404f'

  'npm run cli disAllowAlgo did:op:35834588985efa12f7bd71eb45b585e4315695efbb70bed9621137ee927a9a97 did:op:d8bd14ac38261a0b07c18cf39f61eda7cc7bfce72db40bfe7c2b09c33e0d40'

  'npm run cli compute did:op:3edbda079bdd012e5e4467dc21963cc3014034965ef2d700c88768963a640d2b did:op:68d041f4694edd946b72a285101115d3b7f652f84834d624dd041a2058844071'
  
  'npm run cli stopCompute did:op:cefcdd9c5e1287cfce73e954882dfe4d8465abdd42b2d3a80df2ea53558feb0e db62c51b94b14e55b120ba31b6d6cf06'
  
  'npm run cli getJobStatus did:op:cefcdd9c5e1287cfce73e954882dfe4d8465abdd42b2d3a80df2ea53558feb0e e027981125534c2ca1f562f0279e6023'

  'npm run cli getJobResults did:op:cefcdd9c5e1287cfce73e954882dfe4d8465abdd42b2d3a80df2ea53558feb0e e027981125534c2ca1f562f0279e6023'
  
  'npm run cli downloadJobResults e027981125534c2ca1f562f0279e6023 1 did:op:cefcdd9c5e1287cfce73e954882dfe4d8465abdd42b2d3a80df2ea53558feb0e C:/Development/NagarroDev/acentrik-js/download/'
  
===============================================
  `,
  );
}
