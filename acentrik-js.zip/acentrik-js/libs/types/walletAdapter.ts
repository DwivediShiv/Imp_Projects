export interface WalletAdapter {
  publish(metadataFilePath: any): Promise<void>;
  download(datasetDID: string, destinationFilePath: any): Promise<any>;
  compute(datasetDID: string, algoDid: string): Promise<void>;
  aggregate(guid: string): Promise<void>;
  multipleCompute(
    datasetAndAlgoDID: any,
    fedAlgoDid: string,
  ): Promise<void>;
  getJobStatus(datasetInfo: string[]): Promise<void>;
  getJobResults(datasetInfo: string[]): Promise<void>;
  downloadJobResults(datasetInfo: string[]): Promise<any>;
  stopCompute(datasetInfo: string[]): Promise<void>;
  allowAlgo(datasetAndAlgoDID: string[]): Promise<void>;
  disAllowAlgo(datasetAndAlgoDID: string[]): Promise<void>;
  getDDO(datasetDID: string): Promise<void>;
  editAsset(datasetDIDsFilePathAndAlgoDID: string[]): Promise<void>;
}