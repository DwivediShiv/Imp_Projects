export interface ConsumerParameter {
  name: string;
  type: string;
  label: string;
  required: boolean;
  description?: string;
  default: any;
  options?: string[];
}

export interface AssetFileHeader {
  key: string;
  value: string;
}

export interface PublishCommonDetails {
  type: 'dataset' | 'algorithm';
  name: string;
  overview: string;
  description: string;
  assetUrl: string;
  tags?: string[];
  categories: string[];
  accessPermission: string;
  author: string;
  timeout: number;
  timeoutDurationType?: string;
  isExperimental: boolean;
  inputFileType?: string;
  outputFileType?: string;
  eulaUrl?: string;
  sampleFileUrl?: string;
  serviceType: string;
  serviceEndpoint: string;
  serviceFilesType?: string;
  serviceFilesUrl?: string;
  priceType?: string;
  postPayType?: string;
  postPayTokenSymbol?: string;
  postPayPriceValue?: string;
  price?: string;
  alternateWalletAddress?: string;
  httpHeaders?: AssetFileHeader[];
}

export interface PublishDatasetDetails extends PublishCommonDetails {
  aggregateOnly?: boolean;
  consumerParameters?: ConsumerParameter[];
}

export interface PublishAlgorithmDetails extends PublishCommonDetails {
  algorithmType: string;
  algorithmEntrypoint: string;
  algorithmImage: string;
  algorithmTag: string;
  algorithmChecksum: string;
  algorithmReferenceUrl: string;
}

export interface SdkParamsValues {
  chainId?: string | undefined;
  source?: string | undefined;
  orgId?: string | undefined;
  signer?: string | undefined;
  baseToken?: string | undefined;
  assetManagementTokenName?: string | undefined;
  assetManagementTokenPrefix?: string | undefined;
  assetManagementTokenImageUrl?: string | undefined;
  oceanAquariusUri?: string | undefined;
  serviceEndpoints?: string | undefined;
  isDisableParameterizeAsset?: string | undefined;
  isDisableUnlimitedTimeout?: string | undefined;
}
