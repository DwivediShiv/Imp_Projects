/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: ComputeOrdersByPayer
// ====================================================

export interface ComputeOrdersByPayer_tokens_orders_payer {
  __typename: "User";
  id: string;
}

export interface ComputeOrdersByPayer_tokens_orders_datatoken {
  __typename: "Token";
  address: string;
}

export interface ComputeOrdersByPayer_tokens_orders {
  __typename: "Order";
  payer: ComputeOrdersByPayer_tokens_orders_payer;
  serviceIndex: number;
  datatoken: ComputeOrdersByPayer_tokens_orders_datatoken;
}

export interface ComputeOrdersByPayer_tokens {
  __typename: "Token";
  /**
   * orders created with the datatoken, only available for datatokens
   */
  orders: ComputeOrdersByPayer_tokens_orders[] | null;
  id: string;
  /**
   * datatoken creation transaction id
   */
  tx: string;
  /**
   * block time datatoken was created
   */
  createdTimestamp: number;
}

export interface ComputeOrdersByPayer {
  tokens: ComputeOrdersByPayer_tokens[];
}

export interface ComputeOrdersByPayerVariables {
  user_in?: string[] | null;
}
