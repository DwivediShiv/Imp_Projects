/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FancyAlgoTokenOrders
// ====================================================

export interface FancyAlgoTokenOrders_orders_payer {
  __typename: "User";
  id: string;
}

export interface FancyAlgoTokenOrders_orders_datatoken {
  __typename: "Token";
  address: string;
}

export interface FancyAlgoTokenOrders_orders {
  __typename: "Order";
  payer: FancyAlgoTokenOrders_orders_payer;
  /**
   * transaction hash - token address - from address
   */
  id: string;
  serviceIndex: number;
  datatoken: FancyAlgoTokenOrders_orders_datatoken;
  providerFee: string | null;
  tx: string;
  createdTimestamp: number;
}

export interface FancyAlgoTokenOrders {
  orders: FancyAlgoTokenOrders_orders[];
}

export interface FancyAlgoTokenOrdersVariables {
  datatoken_in?: string[] | null;
}
