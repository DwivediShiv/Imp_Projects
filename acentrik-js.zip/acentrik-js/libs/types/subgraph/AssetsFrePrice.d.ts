/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AssetsFrePrice
// ====================================================

export interface AssetsFrePrice_fixedRateExchanges_baseToken {
  __typename: "Token";
  id: string;
  symbol: string | null;
  address: string;
}

export interface AssetsFrePrice_fixedRateExchanges_datatoken {
  __typename: "Token";
  id: string;
  address: string;
  symbol: string | null;
}

export interface AssetsFrePrice_fixedRateExchanges {
  __typename: "FixedRateExchange";
  /**
   * fixed rate exchange id
   */
  id: string;
  price: any;
  baseToken: AssetsFrePrice_fixedRateExchanges_baseToken;
  datatoken: AssetsFrePrice_fixedRateExchanges_datatoken;
}

export interface AssetsFrePrice {
  fixedRateExchanges: AssetsFrePrice_fixedRateExchanges[];
}

export interface AssetsFrePriceVariables {
  datatoken_in?: string[] | null;
}
