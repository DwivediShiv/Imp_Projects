/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AssetFreePrice
// ====================================================

export interface AssetFreePrice_dispensers_token {
  __typename: "Token";
  id: string;
  address: string;
}

export interface AssetFreePrice_dispensers {
  __typename: "Dispenser";
  token: AssetFreePrice_dispensers_token;
  active: boolean;
  allowedSwapper: string | null;
  isMinter: boolean | null;
  /**
   * max tokens that can be dispensed
   */
  maxTokens: any;
  /**
   * max balance of requester. If the balance is higher, the dispense is rejected
   */
  maxBalance: any;
  /**
   * if using the enterprise template the owner will always be the erc721 factory, for normal template it will a user
   */
  owner: string | null;
}

export interface AssetFreePrice {
  dispensers: AssetFreePrice_dispensers[];
}

export interface AssetFreePriceVariables {
  datatoken?: string | null;
}
