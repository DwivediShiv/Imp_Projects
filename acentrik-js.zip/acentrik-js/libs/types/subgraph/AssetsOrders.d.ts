/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AssetsOrders
// ====================================================

export interface AssetsOrders_orders_datatoken {
  __typename: "Token";
  address: string;
}

export interface AssetsOrders_orders_payer {
  __typename: "User";
  id: string;
}

export interface AssetsOrders_orders {
  __typename: "Order";
  datatoken: AssetsOrders_orders_datatoken;
  createdTimestamp: number;
  tx: string;
  payer: AssetsOrders_orders_payer;
}

export interface AssetsOrders {
  orders: AssetsOrders_orders[];
}

export interface AssetsOrdersVariables {
  datatokenId_in?: string[] | null;
}
