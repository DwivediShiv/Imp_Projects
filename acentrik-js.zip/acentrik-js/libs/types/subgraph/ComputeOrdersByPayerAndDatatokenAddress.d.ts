/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: ComputeOrdersByPayerAndDatatokenAddress
// ====================================================

export interface ComputeOrdersByPayerAndDatatokenAddress_tokens_orders_payer {
  __typename: "User";
  id: string;
}

export interface ComputeOrdersByPayerAndDatatokenAddress_tokens_orders_datatoken {
  __typename: "Token";
  address: string;
}

export interface ComputeOrdersByPayerAndDatatokenAddress_tokens_orders {
  __typename: "Order";
  payer: ComputeOrdersByPayerAndDatatokenAddress_tokens_orders_payer;
  serviceIndex: number;
  datatoken: ComputeOrdersByPayerAndDatatokenAddress_tokens_orders_datatoken;
}

export interface ComputeOrdersByPayerAndDatatokenAddress_tokens {
  __typename: "Token";
  /**
   * orders created with the datatoken, only available for datatokens
   */
  orders: ComputeOrdersByPayerAndDatatokenAddress_tokens_orders[] | null;
  id: string;
  /**
   * datatoken creation transaction id
   */
  tx: string;
  /**
   * block time datatoken was created
   */
  createdTimestamp: number;
}

export interface ComputeOrdersByPayerAndDatatokenAddress {
  tokens: ComputeOrdersByPayerAndDatatokenAddress_tokens[];
}

export interface ComputeOrdersByPayerAndDatatokenAddressVariables {
  user: string;
  datatokenAddress: string;
}
