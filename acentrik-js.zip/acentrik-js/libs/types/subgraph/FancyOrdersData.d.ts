/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FancyOrdersData
// ====================================================

export interface FancyOrdersData_orders_consumer {
  __typename: "User";
  id: string;
}

export interface FancyOrdersData_orders_datatoken_nft {
  __typename: "Nft";
  /**
   * same as id, it's just for easy discoverability
   */
  address: string;
}

export interface FancyOrdersData_orders_datatoken {
  __typename: "Token";
  id: string;
  address: string;
  symbol: string | null;
  /**
   * address of ERC721 that owns the token, valid only for datatokens
   */
  nft: FancyOrdersData_orders_datatoken_nft | null;
}

export interface FancyOrdersData_orders {
  __typename: "Order";
  consumer: FancyOrdersData_orders_consumer;
  datatoken: FancyOrdersData_orders_datatoken;
  providerFee: string | null;
  createdTimestamp: number;
  tx: string;
}

export interface FancyOrdersData {
  orders: FancyOrdersData_orders[];
}

export interface FancyOrdersDataVariables {
  user_in?: string[] | null;
}
