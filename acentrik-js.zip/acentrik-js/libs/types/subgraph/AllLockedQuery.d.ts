/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AllLockedQuery
// ====================================================

export interface AllLockedQuery_veOCEANs {
  __typename: "VeOCEAN";
  /**
   * total amount of locked tokens
   */
  lockedAmount: any;
}

export interface AllLockedQuery {
  veOCEANs: AllLockedQuery_veOCEANs[];
}
