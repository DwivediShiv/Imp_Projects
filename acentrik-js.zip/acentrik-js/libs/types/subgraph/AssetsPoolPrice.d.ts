/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AssetsPoolPrice
// ====================================================

export interface AssetsPoolPrice_pools_datatoken {
  __typename: "Token";
  address: string;
  symbol: string | null;
}

export interface AssetsPoolPrice_pools_baseToken {
  __typename: "Token";
  symbol: string | null;
}

export interface AssetsPoolPrice_pools {
  __typename: "Pool";
  /**
   * pool address
   */
  id: string;
  spotPrice: any;
  datatoken: AssetsPoolPrice_pools_datatoken;
  baseToken: AssetsPoolPrice_pools_baseToken;
  datatokenLiquidity: any;
  baseTokenLiquidity: any;
}

export interface AssetsPoolPrice {
  pools: AssetsPoolPrice_pools[];
}

export interface AssetsPoolPriceVariables {
  datatokenAddress_in?: string[] | null;
}
