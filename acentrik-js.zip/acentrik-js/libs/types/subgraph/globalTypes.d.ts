/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

//==============================================================
// START Enums and Input Objects
//==============================================================

export enum NftUpdateType {
  METADATA_CREATED = "METADATA_CREATED",
  METADATA_UPDATED = "METADATA_UPDATED",
  STATE_UPDATED = "STATE_UPDATED",
  TOKENURI_UPDATED = "TOKENURI_UPDATED",
}

//==============================================================
// END Enums and Input Objects
//==============================================================
