/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FancyComputeOrders
// ====================================================

export interface FancyComputeOrders_orders_payer {
  __typename: "User";
  id: string;
}

export interface FancyComputeOrders_orders_reuses {
  __typename: "OrderReuse";
  id: string;
  createdTimestamp: number;
  tx: string;
}

export interface FancyComputeOrders_orders_datatoken {
  __typename: "Token";
  address: string;
}

export interface FancyComputeOrders_orders {
  __typename: "Order";
  payer: FancyComputeOrders_orders_payer;
  reuses: FancyComputeOrders_orders_reuses[] | null;
  /**
   * transaction hash - token address - from address
   */
  id: string;
  serviceIndex: number;
  datatoken: FancyComputeOrders_orders_datatoken;
  providerFee: string | null;
  tx: string;
  createdTimestamp: number;
}

export interface FancyComputeOrders {
  orders: FancyComputeOrders_orders[];
}

export interface FancyComputeOrdersVariables {
  user_in?: string[] | null;
}
