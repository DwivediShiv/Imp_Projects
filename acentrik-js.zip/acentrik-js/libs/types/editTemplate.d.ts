import { AssetFileHeader, ConsumerParameter } from './publishTemplate';

export interface EditCommonDetails {
  name?: string;
  overview?: string;
  description?: string;
  assetUrl?: string;
  tags?: string[];
  categories?: string[];
  accessPermission?: string;
  author?: string;
  timeout?: number;
  timeoutDurationType?: string;
  isExperimental?: boolean;
  inputFileType?: string;
  outputFileType?: string;
  eulaUrl?: string;
  sampleFileUrl?: string;
  serviceEndpoint?: string;
  serviceFilesUrl?: string;
  priceType?: string;
  postPayType?: string;
  postPayTokenSymbol?: string;
  postPayPriceValue?: string;
  price?: string;
  alternateWalletAddress?: string;
  httpHeaders?: AssetFileHeader[];
  paymentCollector?: string;
  owner?: string;
  nftState?: string;
  organization?: string;
}

export interface EditDatasetDetails extends EditCommonDetails {
  consumerParameters?: ConsumerParameter[];
}

export interface EditAlgorithmDetails extends EditCommonDetails {
  algorithmType?: string;
  algorithmEntrypoint?: string;
  algorithmImage?: string;
  algorithmTag?: string;
  algorithmChecksum?: string;
  algorithmReferenceUrl?: string;
}
