import { TokenInfo } from "./TokenInfo"
import { ProviderFees } from "@oceanprotocol/lib"

  /**
   * @interface AccessDetails
   * @prop {'fixed' | 'free' | 'NOT_SUPPORTED'}  type
   * @prop {string} price can be either spotPrice/rate
   * @prop {string} addressOrId for fixed/free this is an id.
   * @prop {TokenInfo} baseToken
   * @prop {TokenInfo} datatoken
   * @prop {bool} isPurchasable checks if you can buy a datatoken from fixed rate exchange/dispenser.
   * @prop {bool} isOwned checks if there are valid orders for this, it also takes in consideration timeout
   * @prop {string} validOrderTx  the latest valid order tx, it also takes in consideration timeout
   * @prop {string} publisherMarketOrderFee this is here just because it's more efficient, it's allready in the query
   * @prop {ProviderFees} validProviderFees  the latest valid order providerfees if there where any, checks them against current timestamp
   */
  export interface AccessDetails {
    type:
      | 'fixed'
      | 'Premium'
      | 'premium'
      | 'free'
      | 'Free'
      | 'NOT_SUPPORTED'
      | 'Post-pay'
      | 'post-pay'
      | ''
    price: string
    templateId: number
    addressOrId: string
    baseToken: TokenInfo
    datatoken: TokenInfo
    isPurchasable?: boolean
    isOwned: boolean
    validOrderTx: string
    publisherMarketOrderFee: string
    providerFee?: ProviderFees
    validProviderFees?: ProviderFees
    providerData?: any
  }