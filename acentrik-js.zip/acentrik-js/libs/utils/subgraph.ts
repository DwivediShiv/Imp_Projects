import { OperationContext } from 'urql'
import { Asset, Config, LoggerInstance } from '@oceanprotocol/lib'
// import appConfig from 'app.config'
// import { BestPrice } from 'src/models/BestPrice'

export interface UserLiquidity {
  price: string
  oceanBalance: string
}

export interface PriceList {
  [key: string]: string
}

export interface AssetListPrices {
  ddo: Asset
  price: any
}

interface DidAndDatatokenMap {
  [name: string]: string
}

// const FreeQuery = gql`
//   query AssetsFreePrice($datatoken_in: [String!]) {
//     dispensers(orderBy: id, where: { token_in: $datatoken_in }) {
//       token {
//         id
//         address
//       }
//       active
//       allowedSwapper
//       isMinter
//       maxTokens
//       maxBalance
//       owner
//     }
//   }
// `

// const FreQuery = gql`
//   query AssetsFrePrice($datatoken_in: [String!]) {
//     fixedRateExchanges(orderBy: id, where: { datatoken_in: $datatoken_in }) {
//       id
//       price
//       baseToken {
//         id
//         symbol
//         address
//       }
//       datatoken {
//         id
//         address
//         symbol
//       }
//     }
//   }
// `

// const PreviousOrderQuery = gql`
//   query AssetPreviousOrder($id: String!, $account: String!) {
//     orders(
//       first: 1
//       where: { datatoken: $id, payer: $account }
//       orderBy: createdTimestamp
//       orderDirection: desc
//     ) {
//       providerFee
//       createdTimestamp
//       tx
//     }
//   }
// `

// const UserTokenOrders = gql`
//   query OrdersData($user: String!) {
//     orders(
//       orderBy: createdTimestamp
//       orderDirection: desc
//       where: { consumer: $user }
//     ) {
//       consumer {
//         id
//       }
//       datatoken {
//         id
//         address
//         symbol
//       }
//       consumerMarketToken {
//         address
//         symbol
//       }
//       createdTimestamp
//       tx
//     }
//   }
// `

// const OpcFeesQuery = gql`
//   query OpcFeesQuery($id: ID!) {
//     opc(id: $id) {
//       swapOceanFee
//       swapNonOceanFee
//       orderFee
//       providerFee
//     }
//   }
// `

// const OpcsApprovedTokensQuery = gql`
//   query OpcsApprovedTokensQuery {
//     opcs {
//       approvedTokens {
//         address: id
//         symbol
//         name
//         decimals
//       }
//     }
//   }
// `

export function getQueryContext(config: Config): OperationContext {
  try {
    const queryContext: OperationContext = {
      url: `${config.subgraphUri}/subgraphs/name/oceanprotocol/ocean-subgraph`,
      requestPolicy: 'cache-and-network'
    }
    return queryContext
  } catch (error) {
    LoggerInstance.error('Get query context error: ', error.message)
  }
}

// export async function fetchData(
//   query: TypedDocumentNode,
//   variables: any,
//   context: OperationContext
// ): Promise<any> {
//   try {
//     if (!query) throw new Error('Invalid query')
//     const client = getUrqlClientInstance()

//     const response = await client?.query(query, variables, context).toPromise()
//     return response
//   } catch (error) {
//     LoggerInstance.error('Error fetchData: ', error.message)
//   }
//   return null
// }

// export async function fetchDataForMultipleChains(
//   query: TypedDocumentNode,
//   variables: any,
//   chainIds: number[]
// ): Promise<any[]> {
//   let datas: any[] = []
//   try {
//     for (const chainId of chainIds) {
//       if (!chainId) throw new Error(`Invalid Chain ID`)
//       const context: OperationContext = {
//         url: `${getSubgraphUri(
//           chainId
//         )}/subgraphs/name/oceanprotocol/ocean-subgraph`,
//         requestPolicy: 'network-only'
//       }
//       const response = await fetchData(query, variables, context)
//       if (!response || response.error) continue
//       datas = datas.concat(response.data)
//     }
//   } catch (error) {
//     LoggerInstance.error('Error fetchDataForMultipleChains: ', error.message)
//   }
//   return datas
// }

// export async function fancyFetchDataForMultipleChains(
//   query: TypedDocumentNode,
//   variables: any,
//   chainIds: number[]
// ): Promise<any> {
//   const datas = {}
//   try {
//     for (const chainId of chainIds) {
//       if (!chainId) throw new Error(`Invalid Chain ID`)
//       const context: OperationContext = {
//         url: `${getSubgraphUri(
//           chainId
//         )}/subgraphs/name/oceanprotocol/ocean-subgraph`,
//         requestPolicy: 'network-only'
//       }
//       const response = await fetchData(query, variables, context)
//       if (!response || response.error) continue
//       datas[chainId] = response.data
//     }
//   } catch (error) {
//     LoggerInstance.error('Error fetchDataForMultipleChains: ', error.message)
//   }
//   return datas
// }

// export async function getOpcFees(chainId: number) {
//   let opcFees
//   const variables = {
//     id: 1
//   }
//   const context = getQueryContext(chainId)
//   try {
//     const response: OperationResult<OpcFeesData> = await fetchData(
//       OpcFeesQuery,
//       variables,
//       context
//     )
//     opcFees = response?.data?.opc
//   } catch (error) {
//     LoggerInstance.error('Error getOpcFees: ', error.message)
//     throw Error(error.message)
//   }
//   return opcFees
// }

// export async function getPreviousOrders(
//   id: string,
//   account: string,
//   assetTimeout: string
// ): Promise<string> {
//   const variables = { id, account }
//   const fetchedPreviousOrders: OperationResult<AssetPreviousOrder> =
//     await fetchData(PreviousOrderQuery, variables, null)
//   if (fetchedPreviousOrders.data?.orders?.length === 0) return null
//   const latestOrder = fetchedPreviousOrders?.data?.orders[0]
//   const providerFee = JSON.parse(latestOrder.providerFee) as ProviderFees
//   const providerData = getProviderData(providerFee)
//   const expiry =
//     (providerData
//       ? providerData.timestamp + providerData.timeout
//       : fetchedPreviousOrders?.data?.orders[0]?.createdTimestamp +
//         Number(assetTimeout)) * 1000
//   assetTimeout = providerData && providerData.timeout?.toString()
//   const now = Date.now()
//   return now <= expiry || assetTimeout === '0'
//     ? fetchedPreviousOrders?.data?.orders[0]?.tx
//     : null
// }

// function transformPriceToBestPrice(
//   frePrice: AssetsFrePriceFixedRateExchange[],
//   freePrice: AssetFreePriceDispenser[]
// ) {
//   if (frePrice?.length > 0) {
//     // TODO Hacky hack, temporary™: set isConsumable to true for fre assets.
//     // isConsumable: 'true'
//     const price: any = {
//       type: 'exchange',
//       value: frePrice[0]?.price,
//       address: frePrice[0]?.id,
//       exchangeId: frePrice[0]?.id,
//       symbol: frePrice[0]?.baseToken?.symbol,
//       ocean: 0,
//       datatoken: 0,
//       pools: [],
//       isConsumable: 'true'
//     }
//     return price
//   } else if (freePrice?.length > 0) {
//     const price: any = {
//       type: 'free',
//       value: 0,
//       address: freePrice[0]?.token.id,
//       exchangeId: '',
//       ocean: 0,
//       datatoken: 0,
//       pools: [],
//       isConsumable: 'true',
//       minterApproved: freePrice[0]?.isMinter,
//       symbol: ''
//     }
//     return price
//   } else {
//     const price: any = {
//       type: '',
//       value: 0,
//       address: '',
//       exchangeId: '',
//       ocean: 0,
//       datatoken: 0,
//       pools: [],
//       isConsumable: 'false',
//       symbol: ''
//     }
//     return price
//   }
// }

// async function getAssetsExchangesAndDatatokenMap(
//   assets: Asset[]
// ): Promise<
//   [
//     AssetsFrePriceFixedRateExchange[],
//     AssetFreePriceDispenser[],
//     DidAndDatatokenMap
//   ]
// > {
//   const didDTMap: DidAndDatatokenMap = {}
//   const chainAssetLists: any = {}

//   for (const ddo of assets) {
//     didDTMap[ddo?.datatokens?.[0]?.address?.toLowerCase()] = ddo.id
//     //  harcoded until we have chainId on assets
//     if (chainAssetLists[ddo.chainId]) {
//       chainAssetLists[ddo.chainId].push(
//         ddo?.datatokens?.[0]?.address?.toLowerCase()
//       )
//     } else {
//       chainAssetLists[ddo.chainId] = []
//       chainAssetLists[ddo.chainId].push(
//         ddo?.datatokens?.[0]?.address?.toLowerCase()
//       )
//     }
//   }
//   let frePriceResponse: AssetsFrePriceFixedRateExchange[] = []
//   let freePriceResponse: AssetFreePriceDispenser[] = []

//   for (const chainKey in chainAssetLists) {
//     const freVariables = {
//       datatoken_in: chainAssetLists[chainKey]
//     }
//     const freeVariables = {
//       datatoken_in: chainAssetLists[chainKey]
//     }

//     const queryContext = getQueryContext(Number(chainKey))

//     const chainFrePriceResponse: OperationResult<AssetsFrePrice> =
//       await fetchData(FreQuery, freVariables, queryContext)

//     frePriceResponse = frePriceResponse.concat(
//       chainFrePriceResponse?.data?.fixedRateExchanges
//     )

//     const chainFreePriceResponse: OperationResult<AssetsFreePrice> =
//       await fetchData(FreeQuery, freeVariables, queryContext)

//     freePriceResponse = freePriceResponse.concat(
//       chainFreePriceResponse?.data?.dispensers
//     )
//   }
//   return [frePriceResponse, freePriceResponse, didDTMap]
// }

// export async function getAssetsPriceList(assets: Asset[]): Promise<PriceList> {
//   const priceList: PriceList = {}

//   const values: [
//     AssetsFrePriceFixedRateExchange[],
//     AssetFreePriceDispenser[],
//     DidAndDatatokenMap
//   ] = await getAssetsExchangesAndDatatokenMap(assets)
//   const frePriceResponse = values[0]
//   const freePriceResponse = values[1]
//   const didDTMap: DidAndDatatokenMap = values[2]

//   if (frePriceResponse)
//     for (const frePrice of frePriceResponse) {
//       priceList[didDTMap[frePrice.datatoken?.address]] = frePrice.price
//     }
//   if (freePriceResponse)
//     for (const freePrice of freePriceResponse) {
//       if (freePrice.isMinter)
//         priceList[didDTMap[freePrice.token?.address]] = '0'
//     }
//   return priceList
// }

// export async function getAssetsBestPrices(
//   assets: Asset[]
// ): Promise<AssetListPrices[]> {
//   const assetsWithPrice: AssetListPrices[] = []

//   const values: [
//     AssetsFrePriceFixedRateExchange[],
//     AssetFreePriceDispenser[],
//     DidAndDatatokenMap
//   ] = await getAssetsExchangesAndDatatokenMap(assets)

//   const frePriceResponse = values[0]
//   const freePriceResponse = values[1]
//   for (const ddo of assets) {
//     const dataToken = ddo.datatokens?.[0]?.address.toLowerCase()
//     const frePrice: AssetsFrePriceFixedRateExchange[] = []
//     const freePrice: AssetFreePriceDispenser[] = []
//     const fre = frePriceResponse.find(
//       (fre: AssetsFrePriceFixedRateExchange) =>
//         fre?.datatoken?.address === dataToken
//     )
//     fre && frePrice.push(fre)
//     const free = freePriceResponse.find(
//       (free: AssetFreePriceDispenser) => free?.token?.address === dataToken
//     )
//     free && freePrice.push(free)
//     const bestPrice = transformPriceToBestPrice(frePrice, freePrice)
//     assetsWithPrice.push({
//       ddo,
//       price: bestPrice
//     })
//   }

//   return assetsWithPrice
// }

// export async function getUserTokenOrders(
//   accountId: string,
//   chainIds: number[]
// ): Promise<OrdersData[]> {
//   const data: OrdersData[] = []
//   const variables = { user: accountId?.toLowerCase() }

//   try {
//     const tokenOrders = await fetchDataForMultipleChains(
//       UserTokenOrders,
//       variables,
//       chainIds
//     )
//     for (let i = 0; i < tokenOrders?.length; i++) {
//       tokenOrders[i].orders.forEach((tokenOrder: OrdersData) => {
//         data.push(tokenOrder)
//       })
//     }

//     return data
//   } catch (error) {
//     LoggerInstance.error('Error getUserTokenOrders', error.message)
//   }
// }

// export async function getUserSales(
//   accountId: string,
//   chainIds: number[]
// ): Promise<number> {
//   try {
//     const result = await getPublishedAssets(accountId, chainIds, null)
//     const { totalOrders } = result.aggregations
//     return totalOrders.value
//   } catch (error) {
//     LoggerInstance.error('Error getUserSales', error.message)
//   }
// }

// export async function getTopAssetsPublishers(
//   chainIds: number[],
//   nrItems = 9
// ): Promise<AccountTeaserVM[]> {
//   const publishers: AccountTeaserVM[] = []

//   const result = await getTopPublishers(chainIds, null)
//   const { topPublishers } = result.aggregations

//   for (let i = 0; i < topPublishers.buckets.length; i++) {
//     publishers.push({
//       address: topPublishers.buckets[i].key,
//       nrSales: parseInt(topPublishers.buckets[i].totalSales.value)
//     })
//   }

//   publishers.sort((a, b) => b.nrSales - a.nrSales)

//   return publishers.slice(0, nrItems)
// }

// export async function getOpcsApprovedTokens(
//   chainId: number
// ): Promise<TokenInfo[]> {
//   const context = getQueryContext(chainId)

//   try {
//     const response = await fetchData(OpcsApprovedTokensQuery, null, context)
//     return response?.data?.opcs[0].approvedTokens
//   } catch (error) {
//     LoggerInstance.error('Error getOpcsApprovedTokens: ', error.message)
//     throw Error(error.message)
//   }
// }
