import { gql, 
  OperationContext, 
  OperationResult,
  createClient,
  dedupExchange,
  fetchExchange,
  TypedDocumentNode } from 'urql'
import { getQueryContext } from './subgraph'
import {
  TokenPriceQuery,
  TokenPriceQuery_token as TokenPrice,
  TokenPriceQuery_token_orders as TokenOrder
} from '../types/subgraph/TokenPriceQuery'
import {
  TokensPriceQuery,
} from '../types/subgraph/TokensPriceQuery'
import {
  Config,
  LoggerInstance,
  ProviderFees} from '@oceanprotocol/lib'
import { ethers } from 'ethers'
import {

} from 'urql'
import { AccessDetails } from '../types/Price'
import { AssetExtended } from '../asset-manager/start-multiple-compute'

const tokensPriceQuery = gql`
  query TokensPriceQuery($datatokenIds: [ID!], $account: String) {
    tokens(where: { id_in: $datatokenIds }) {
      id
      symbol
      name
      publishMarketFeeAddress
      publishMarketFeeToken
      publishMarketFeeAmount
      orders(
        where: { payer: $account }
        orderBy: createdTimestamp
        orderDirection: desc
      ) {
        tx
        serviceIndex
        createdTimestamp
        providerFee
        providerFeeValidUntil
        reuses(orderBy: createdTimestamp, orderDirection: desc) {
          id
          caller
          createdTimestamp
          tx
          block
          providerFee
          providerFeeValidUntil
        }
      }
      dispensers {
        id
        active
        isMinter
        maxBalance
        token {
          id
          name
          symbol
        }
      }
      fixedRateExchanges {
        id
        exchangeId
        price
        publishMarketSwapFee
        baseToken {
          symbol
          name
          address
          decimals
        }
        datatoken {
          symbol
          name
          address
        }
        active
      }
    }
  }
`
const tokenPriceQuery = gql`
  query TokenPriceQuery($datatokenId: ID!, $account: String) {
    token(id: $datatokenId) {
      id
      symbol
      name
      publishMarketFeeAddress
      publishMarketFeeToken
      publishMarketFeeAmount
      orders(
        where: { payer: $account }
        orderBy: createdTimestamp
        orderDirection: desc
      ) {
        tx
        serviceIndex
        createdTimestamp
        providerFee
        providerFeeValidUntil
        reuses(orderBy: createdTimestamp, orderDirection: desc) {
          id
          caller
          createdTimestamp
          tx
          block
          providerFee
          providerFeeValidUntil
        }
      }
      dispensers {
        id
        active
        isMinter
        maxBalance
        token {
          id
          name
          symbol
        }
      }
      fixedRateExchanges {
        id
        exchangeId
        price
        publishMarketSwapFee
        baseToken {
          symbol
          name
          address
          decimals
        }
        datatoken {
          symbol
          name
          address
        }
        active
      }
    }
  }
`

const tokensValidOrdersQuery = gql`
  query TokensValidOrdersQuery($datatokenId: ID!) {
    tokens(where: { address: $datatokenId }) {
      id
      orders {
        tx
        createdTimestamp
        providerFee
      }
    }
  }
`

export function getProviderData(providerFee: ProviderFees): any { //TODO: add interface providerdata
  if (!providerFee?.providerData) {
    return null
  }
  const providerDataBytes = ethers.utils.arrayify(providerFee?.providerData)
  const stringProviderData = String.fromCharCode(...providerDataBytes)
  const providerData: any = JSON.parse(stringProviderData)  //TODO: add interface providerdata
  return providerData
}

function getAccessDetailsFromTokenPrice(
  tokenPrice: TokenPrice,
  timeout?: number
): any { //TODO: need to add accessDetails interface
  const accessDetails = {} as AccessDetails

  // Return early when no supported pricing schema found.
  if (
    tokenPrice?.dispensers?.length === 0 &&
    tokenPrice?.fixedRateExchanges?.length === 0
  ) {
    accessDetails.type = 'NOT_SUPPORTED'
    return accessDetails
  }

  if ((tokenPrice?.orders?.length || 0) > 0) {
    const order = tokenPrice.orders[0] as TokenOrder
    const currentTimestamp = Date.now() / 1000
    const reusedOrder = order?.reuses?.length > 0 ? order.reuses[0] : null
    // the last valid order should be the last reuse order tx id if there is one
    const isFancyReused = reusedOrder?.providerFeeValidUntil > currentTimestamp
    accessDetails.providerFee = JSON.parse(
      isFancyReused ? reusedOrder.providerFee : order.providerFee
    )
    accessDetails.providerData = getProviderData(accessDetails.providerFee)
    const hasProviderData = !!accessDetails.providerData
    // asset is owned if there is an order and asset has timeout 0 (forever) or if the condition is valid
    const isProviderDataTimeoutValid =
      hasProviderData &&
      (accessDetails.providerData?.timeout === 0 ||
        currentTimestamp - accessDetails.providerData?.timestamp <
          accessDetails.providerData?.timeout)
    const isAssetTimeoutValid =
      !hasProviderData &&
      (timeout === 0 || currentTimestamp - order.createdTimestamp < timeout)

    accessDetails.isOwned = isProviderDataTimeoutValid || isAssetTimeoutValid
    if (accessDetails.isOwned) {
      accessDetails.validOrderTx = isFancyReused ? reusedOrder.tx : order.tx
    }
  }

  // TODO: fetch order fee from sub query
  accessDetails.publisherMarketOrderFee =
    tokenPrice?.publishMarketFeeAmount || '0'

  // free is always the best price
  if (tokenPrice?.dispensers?.length > 0) {
    const dispenser = tokenPrice.dispensers[0]
    accessDetails.type = 'free'
    accessDetails.addressOrId = dispenser.token.id
    accessDetails.price = '0'
    accessDetails.isPurchasable = dispenser.active
    accessDetails.datatoken = {
      address: dispenser.token.id,
      name: dispenser.token.name,
      symbol: dispenser.token.symbol
    }
    return accessDetails
  }

  // checking for fixed price
  if (tokenPrice?.fixedRateExchanges?.length > 0) {
    const fixed = tokenPrice.fixedRateExchanges[0]
    accessDetails.type = 'fixed'
    accessDetails.addressOrId = fixed.exchangeId
    accessDetails.price = fixed.price
    // in theory we should check dt balance here, we can skip this because in the market we always create fre with minting capabilities.
    accessDetails.isPurchasable = fixed.active
    accessDetails.baseToken = {
      address: fixed.baseToken.address,
      name: fixed.baseToken.name,
      symbol: fixed.baseToken.symbol,
      decimals: fixed.baseToken.decimals
    }
    accessDetails.datatoken = {
      address: fixed.datatoken.address,
      name: fixed.datatoken.name,
      symbol: fixed.datatoken.symbol
    }
  }
  return accessDetails
}

// export interface Options {
//   isAbstractFlow: boolean
// }
/**
 * This will be used to get price including fees before ordering
 * @param {AssetExtended} asset
 * @return {Promise<OrdePriceAndFee>}
 */
// export async function getOrderPriceAndFees(
//   asset: AssetExtended,
//   accountId: string,
//   signer?: Signer,
//   providerFees?: ProviderFees,
//   options?: Options
// ): Promise<OrderPriceAndFees> {
//   const orderPriceAndFee = {
//     price: '0',
//     publisherMarketOrderFee:
//       asset?.accessDetails?.publisherMarketOrderFee ||
//       publisherMarketOrderFee ||
//       '0',
//     publisherMarketFixedSwapFee: '0',
//     consumeMarketOrderFee: consumeMarketOrderFee || '0',
//     consumeMarketFixedSwapFee: '0',
//     providerFee: {
//       providerFeeAmount: '0'
//     },
//     opcFee: '0'
//   } as OrderPriceAndFees

//   // fetch provider fee

//   // Fixed: ProviderInstance.initialize here is prevented from calling for Compute, Compute uses InitializeCompute
//   const initializeData =
//     !providerFees &&
//     !getServiceByName(asset, 'compute') &&
//     (await ProviderInstance.initialize(
//       asset?.id,
//       asset?.services[0].id,
//       0,
//       accountId,
//       asset?.services[0].serviceEndpoint
//     ))
//   orderPriceAndFee.providerFee = providerFees || initializeData?.providerFee
//   // fetch price and swap fees
//   if (asset?.accessDetails?.type === 'fixed') {
//     const fixed = await getFixedBuyPrice(
//       asset?.accessDetails,
//       asset?.chainId,
//       signer
//     )
//     orderPriceAndFee.price = fixed.baseTokenAmount
//     orderPriceAndFee.opcFee = fixed.oceanFeeAmount
//     orderPriceAndFee.publisherMarketFixedSwapFee = fixed.marketFeeAmount
//     orderPriceAndFee.consumeMarketFixedSwapFee = fixed.consumeMarketFeeAmount
//   }
//   if (
//     asset?.accessDetails?.type === 'free' &&
//     (asset?.metadata?.additionalInformation?.postpayType === 'setPrice' ||
//       asset?.metadata?.additionalInformation?.postpayType === 'payPerByte')
//   ) {
//     const price = JSON.parse(
//       asset?.metadata?.additionalInformation?.price || {}
//     )?.value

//     orderPriceAndFee.price = price
//   }
//   // calculate full price, we assume that all the values are in ocean, otherwise this will be incorrect
//   if (!options.isAbstractFlow) {
//     orderPriceAndFee.price = new Decimal(+orderPriceAndFee.price || 0)
//       .add(new Decimal(+orderPriceAndFee?.consumeMarketOrderFee || 0))
//       .add(new Decimal(+orderPriceAndFee?.publisherMarketOrderFee || 0))
//       .add(
//         new Decimal(
//           (orderPriceAndFee?.providerFee?.providerFeeAmount &&
//             (await unitsToAmount(
//               signer,
//               orderPriceAndFee?.providerFee?.providerFeeToken,
//               orderPriceAndFee?.providerFee?.providerFeeAmount?.toString()
//             ))) ||
//             0
//         )
//       )
//       .toString()
//   }

//   return orderPriceAndFee
// }

/**
 * @param {number} chainId
 * @param {string} datatokenAddress
 * @param {number} timeout timout of the service, this is needed to return order details
 * @param {string} account account that wants to buy, is needed to return order details
 * @returns {Promise<AccessDetails>}
 */
export async function getAccessDetails(
  datatokenAddress: string,
  config: Config,
  timeout?: number,
  account = '',
): Promise<any> { // TODO: add accessDetails interface
  try {
    const queryContext = getQueryContext(config)
    const tokenQueryResult: OperationResult<
      TokenPriceQuery,
      { datatokenId: string; account: string }
    > = await fetchData(
      tokenPriceQuery,
      {
        datatokenId: datatokenAddress.toLowerCase(),
        account: account?.toLowerCase()
      },
      queryContext,
      config
    )

    const tokenPrice: TokenPrice = tokenQueryResult?.data?.token
    const accessDetails = getAccessDetailsFromTokenPrice(tokenPrice, timeout)
    return accessDetails
  } catch (error) {
    LoggerInstance.error('Error getting access details: ', error.message)
  }
}

export async function getAccessDetailsForAssets(
  assets: AssetExtended[],
  account = '',
  config: Config
): Promise<AssetExtended[]> {
  const assetsExtended: AssetExtended[] = assets
  const chainAssetLists: { [key: number]: string[] } = {}

  try {
    for (const asset of assets) {
      if (chainAssetLists[asset.chainId]) {
        chainAssetLists[asset.chainId].push(
          asset.services[0].datatokenAddress.toLowerCase()
        )
      } else {
        chainAssetLists[asset.chainId] = []
        chainAssetLists[asset.chainId].push(
          asset.services[0].datatokenAddress.toLowerCase()
        )
      }
    }

    for (const chainKey in chainAssetLists) {
      const queryContext = getQueryContext(config)
      const tokenQueryResult: OperationResult<
        TokensPriceQuery,
        { datatokenIds: [string]; account: string }
      > = await fetchData(
        tokensPriceQuery,
        {
          datatokenIds: chainAssetLists[chainKey],
          account: account?.toLowerCase()
        },
        queryContext,
        config
      )
      tokenQueryResult.data?.tokens.forEach((token) => {
        const currentAsset: any = assetsExtended.find(
          (asset) =>
            asset.services[0].datatokenAddress.toLowerCase() === token.id
        )
        const accessDetails = getAccessDetailsFromTokenPrice(
          token,
          currentAsset?.services[0]?.timeout
        )

        currentAsset.accessDetails = accessDetails
      })
    }
    return assetsExtended
  } catch (error) {
    LoggerInstance.error('Error getting access details: ', error.message)
  }
}

// export async function getValidOrdersForAssets(asset: Asset): Promise<number> {
//   try {
//     const context: OperationContext = {
//       url: `${getSubgraphUri(
//         asset?.chainId
//       )}/subgraphs/name/oceanprotocol/ocean-subgraph`,
//       requestPolicy: 'network-only'
//     }

//     const result = await fetchData(
//       tokensValidOrdersQuery,
//       {
//         datatokenId: asset?.datatokens?.[0]?.address.toLowerCase()
//       },
//       context
//     )

//     const currentTimestamp = Date.now() / 1000
//     let validOrders = 0
//     const accessDetails = {} as AccessDetails

//     result?.data?.tokens?.forEach((token) => {
//       token?.orders?.forEach((order) => {
//         accessDetails.providerFee = JSON.parse(order.providerFee)
//         accessDetails.providerData = getProviderData(accessDetails.providerFee)
//         if (
//           currentTimestamp <
//           accessDetails.providerData?.timestamp +
//             accessDetails.providerData?.timeout
//         ) {
//           validOrders++
//         }
//       })
//     })
//     return validOrders || 0
//   } catch (error) {
//     LoggerInstance.error(
//       'Error in retrieving valid orders for assets: ',
//       error.message
//     )
//   }
//   return 0
// }

export async function fetchData(
  query: TypedDocumentNode,
  variables: any,
  context: OperationContext,
  config: Config
): Promise<any> {
  try {
    if (!query) throw new Error('Invalid query')
    const client = createUrqlClient(config.subgraphUri);

    const response = await client?.query(query, variables, context).toPromise()
    return response
  } catch (error) {
    LoggerInstance.error('Error fetchData: ', error.message)
  }
  return null
}

function createUrqlClient(subgraphUri: string) {
  const client = createClient({
    url: `${subgraphUri}/subgraphs/name/oceanprotocol/ocean-subgraph`,
    exchanges: [dedupExchange, fetchExchange]
  })
  return client
}
