export function dateToStringNoMS(date: Date): string {
    return date.toISOString().replace(/\.[0-9]{3}Z/, 'Z');
  }
  