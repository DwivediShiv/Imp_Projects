export function getSponsorTransactionUrl(): string {
  return `${process.env.PAYMENT_MANAGEMENT_URL}/abstract/sponsor/transaction`;
}