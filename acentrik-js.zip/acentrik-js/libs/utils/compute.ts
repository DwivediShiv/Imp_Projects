export const JSON_CONTENT_TYPE = 'application/json'
export const hexPattern = /^(?:0x)*([a-f0-9]+)$/i;

export function inputMatch(
  did: string,
  pattern: RegExp,
): {
  valid: boolean;
  formattedDID: string;
} {
  const matches = did.match(pattern);
  return matches
    ? {
        valid: true,
        formattedDID: matches[1],
      }
    : {
        valid: false,
        formattedDID: did,
      };
}

export function formatDIDAsHex(did = ''): string {
  const { valid, formattedDID } = inputMatch(did, hexPattern);
  return (valid ? '0x' : '') + formattedDID;
}

export function objectToQueryString(
  consumerAddress: string,
  jobId: string,
  federatedCompute: boolean,
  smartAccountId: string,
  did?: string,
  guid?: string
): string {
  let queryString = `?consumerAddress=${consumerAddress}`;

  if (did) {
    queryString += `&documentId=${did}`;
  }

  if (jobId) {
    queryString += `&jobId=${jobId}`;
  }
  if (federatedCompute) {
    queryString += `&federatedCompute=${federatedCompute}`;
  }
  if (guid) {
    queryString += `&guid=${guid}`;
  }
  if (smartAccountId) {
    queryString += `&smartAccount=${smartAccountId}`;
  }

  return queryString;
}
