import { promises as fs } from 'fs';
import * as path from 'path';
import { DownloadResponse } from '@oceanprotocol/lib';

export async function readFileAndBootstrap(filePath: string) {
  if (!filePath) {
    console.error('Please specify file path');
    return;
  }
  const data = await fs.readFile(filePath, 'utf-8');
  const parsed = JSON.parse(data);

  return parsed;
}


export async function downloadFile(
  url: string,
  downloadPath: string,
  index?: number,
): Promise<DownloadResponse> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error('Response error.');
  }

  let filename: string;
  try {
    filename = response.headers
      .get('content-disposition')!
      .match(/attachment;filename=(.+)/)![1];
  } catch {
    try {
      filename = url.split('/').pop() as string;
    } catch {
      filename = `file${index}`;
    }
  }

  const filePath = path.join(downloadPath, filename);
  const data = await response.arrayBuffer();

  try {
    await fs.writeFile(filePath, Buffer.from(data));
  } catch (err) {
    console.error('Error while saving the file:', err.message);
  }

  return { data, filename };
}
