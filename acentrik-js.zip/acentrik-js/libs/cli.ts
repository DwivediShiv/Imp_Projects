import Client from './client';
import { ACCOUNT_PROVIDERS } from './common/constants';
import { help } from './help';
require('dotenv').config();

export async function start() {
  const args = process.argv.slice(2);
  const commandName = args[0];
  if (commandName === 'help') {
    help();
    return;
  }
  const client = new Client();
  let type: 'EOA' | string = 'EOA';
  if (process.env.SMART_ACCOUNT_ADDRESS && process.env.API_KEY) {
    type = ACCOUNT_PROVIDERS.ALCHEMY;
  }
  // Console.log being used in cli.test.ts
  console.log('[Cli.ts] args=', args);
  await client.executeCommand(commandName, args.slice(1), type);
}

start();
