import {
  EditAlgorithmDetails,
  EditDatasetDetails,
} from '../../types/editTemplate';
import { SdkParamsValues } from '../../types/publishTemplate';

export const dummySdkParams: SdkParamsValues = {
  oceanAquariusUri: 'https://dummyAquariusUri.io',
  baseToken: '0x456',
  serviceEndpoints:
    '{"Dummy Edge Node":"https://dummyProvider.io", "Updated Edge Node":"https://updatedProvider.io"}',
  isDisableParameterizeAsset: 'false',
  isDisableUnlimitedTimeout: process.env.IS_DISABLE_UNLIMITED_TIMEOUT,
};

export const existingDatasetDdo = {
  '@context': ['https://w3id.org/did/v1'],
  id: 'dummyDatasetdid123',
  nftAddress: '0x123',
  version: '4.1.0',
  chainId: 123,
  metadata: {
    created: '2024-07-25T07:22:09.839Z',
    updated: '2024-07-25T09:01:54.651Z',
    type: 'dataset',
    name: 'Dummy Dataset',
    description: 'Dummy Overview',
    tags: ['test'],
    author: '',
    license: 'https://dummylicense.com',
    categories: ['dummyCategory'],
    additionalInformation: {
      termsAndConditions: true,
      source: 'dummySource',
      accessPermission: 'allow',
      organization: 'org-123',
      signer: '0x456',
    },
  },
  services: [
    {
      id: 'id123',
      type: 'access',
      files: '0x123',
      datatokenAddress: '0xdata123token',
      serviceEndpoint: 'https://dummyProvider.io',
      timeout: 3600,
      description: 'Dummy description',
      additionalInformation: {
        source: 'dummySource',
        isExperimental: false,
        sampleType: 'URL',
        links: [],
        input: {
          fileType: '',
        },
        output: {
          fileType: '',
          screenshot: '',
        },
      },
    },
  ],
  event: {
    tx: '0xtxn123',
    block: 123,
    from: '0x987',
    contract: '0x789',
    datetime: '2024-07-25T09:35:50',
  },
  nft: {
    address: '0x321',
    name: 'Dummy Token',
    symbol: 'DummyT-1',
    state: 0 as 0 | 1 | 2 | 3 | 4 | 5,
    tokenURI: '0x123',
    owner: '0x123',
    created: '2024-07-25T07:22:46',
  },
  datatokens: [
    {
      address: '0x12343',
      name: 'DummyDT',
      symbol: 'DummyDT-1',
      serviceId: '1234321',
    },
  ],
  stats: {
    allocated: 0,
    orders: 0,
    price: {
      value: 2,
    },
  },
  purgatory: {
    state: false,
  },
};

export const editMetadataDataset: EditDatasetDetails = {
  name: 'Updated dataset',
  overview: 'Updated overview',
  description: 'Updated description',
  categories: ['updatedCategory'],
  accessPermission: 'deny',
};
export const editPricingDataset: EditDatasetDetails = {
  price: '1',
  httpHeaders: [
    {
      key: 'dummyKey',
      value: 'dummyValue',
    },
  ],
};

export const editServicesDataset: EditDatasetDetails = {
  serviceEndpoint: 'Updated Edge Node',
  timeout: 1,
  timeoutDurationType: 'day(s)',
  description: 'Updated description',
  isExperimental: true,
  consumerParameters: [
    {
      name: 'paramName',
      type: 'string',
      label: 'ParamLabel',
      default: '',
      description: 'ParamDesc',
      required: true,
    },
  ],
};

export const editOwnershipAndStateDataset: EditDatasetDetails = {
  owner: 'new123',
  nftState: 'inactive',
};

export const existingAlgorithmDdo = {
  '@context': ['https://w3id.org/did/v1'],
  id: 'dummyDatasetdid123',
  nftAddress: '0x123',
  version: '4.1.0',
  chainId: 123,
  metadata: {
    created: '2024-07-25T07:22:09.839Z',
    updated: '2024-07-25T09:01:54.651Z',
    type: 'algorithm',
    name: 'Dummy Algorithm',
    description: 'Dummy Overview',
    tags: ['test'],
    author: '',
    license: 'https://dummylicense.com',
    categories: ['dummyCategory'],
    additionalInformation: {
      termsAndConditions: true,
      source: 'dummySource',
      accessPermission: 'allow',
      organization: 'org-123',
      signer: '0x456',
      algorithmType: 'Basic',
    },
    algorithm: {
      language: 'lang123',
      version: '1',
      container: {
        entrypoint: 'lang algo',
        image: 'publicImage',
        tag: 'langTag',
        checksum: 'checksum123',
        referenceUrl: 'https://referenceUrl.com',
      },
    },
  },
  services: [
    {
      id: 'id123',
      type: 'access',
      files: '0x123',
      datatokenAddress: '0xdata123token',
      serviceEndpoint: 'https://dummyProvider.io',
      timeout: 3600,
      description: 'Dummy description',
      additionalInformation: {
        source: 'dummySource',
        isExperimental: false,
        sampleType: 'URL',
        links: [],
        input: {
          fileType: '',
        },
        output: {
          fileType: '',
          screenshot: '',
        },
      },
    },
  ],
  event: {
    tx: '0xtxn123',
    block: 123,
    from: '0x987',
    contract: '0x789',
    datetime: '2024-07-25T09:35:50',
  },
  nft: {
    address: '0x321',
    name: 'Dummy Token',
    symbol: 'DummyT-1',
    state: 0 as 0 | 1 | 2 | 3 | 4 | 5,
    tokenURI: '0x123',
    owner: '0x123',
    created: '2024-07-25T07:22:46',
  },
  datatokens: [
    {
      address: '0x12343',
      name: 'DummyDT',
      symbol: 'DummyDT-1',
      serviceId: '1234321',
    },
  ],
  stats: {
    allocated: 0,
    orders: 0,
    price: {
      value: 2,
    },
  },
  purgatory: {
    state: false,
  },
};

export const editMetadataAlgorithm: EditAlgorithmDetails = {
  name: 'Updated algorithm',
  overview: 'Updated overview',
  description: 'Updated description',
  categories: ['updatedCategory'],
  accessPermission: 'deny',
  algorithmEntrypoint: 'updatedEntryPoint',
  algorithmImage: 'updatedImage',
  algorithmTag: 'updatedTag',
};
export const editPricingAlgorithm: EditAlgorithmDetails = {
  price: '1',
  httpHeaders: [
    {
      key: 'dummyKey',
      value: 'dummyValue',
    },
  ],
};

export const editServicesAlgorithm: EditAlgorithmDetails = {
  serviceEndpoint: 'Updated Edge Node',
  timeout: 1,
  timeoutDurationType: 'day(s)',
  description: 'Updated description',
  isExperimental: true,
};

export const editOwnershipAndStateAlgorithm: EditAlgorithmDetails = {
  owner: 'new123',
  nftState: 'inactive',
};
