import {
  getEditAlgoDdo,
  getEditDatasetDdo,
} from '../../template-converter/edit-template';

import {
  editMetadataAlgorithm,
  editMetadataDataset,
  editOwnershipAndStateAlgorithm,
  editOwnershipAndStateDataset,
  editPricingAlgorithm,
  editPricingDataset,
  editServicesAlgorithm,
  editServicesDataset,
  existingAlgorithmDdo,
  existingDatasetDdo,
} from './editTemplateTestData';
import { dummySdkParams } from './editTemplateTestData';

describe('edit dataset', () => {
  it('should generate dataset ddo after editing metadata', async () => {
    const updatedDDO = await getEditDatasetDdo(
      editMetadataDataset,
      existingDatasetDdo,
      dummySdkParams,
    );
    expect(updatedDDO.metadata.name).toBe('Updated dataset');
    expect(updatedDDO.metadata.description).toBe('Updated overview');
    expect(updatedDDO.metadata.categories).toStrictEqual(['updatedCategory']);
    expect(updatedDDO.metadata.additionalInformation.accessPermission).toBe(
      'deny',
    );
    expect(updatedDDO.credentials).toBeDefined();
  });

  it('should generate dataset ddo after editing price', async () => {
    const updatedDDO = await getEditDatasetDdo(
      editPricingDataset,
      existingDatasetDdo,
      dummySdkParams,
    );
    expect(updatedDDO.metadata.name).toBe('Dummy Dataset');
    expect(updatedDDO.stats.price.value).toBe(1);
  });

  it('should generate dataset ddo after editing service', async () => {
    const updatedDDO = await getEditDatasetDdo(
      editServicesDataset,
      existingDatasetDdo,
      dummySdkParams,
    );
    expect(updatedDDO.services[0].description).toBe('Updated description');
    expect(updatedDDO.services[0].timeout).toBe(86400);
    expect(updatedDDO.services[0].additionalInformation.isExperimental).toBe(
      true,
    );
    expect(updatedDDO.services[0].serviceEndpoint).toBe(
      'https://updatedProvider.io',
    );
    expect(updatedDDO.services[0].consumerParameters).toBeDefined();
  });

  it('should update owner details as transfer ownership', async () => {
    const updatedDDO = await getEditDatasetDdo(
      editOwnershipAndStateDataset,
      existingDatasetDdo,
      dummySdkParams,
    );
    expect(updatedDDO.nft.owner).toBe('new123');
    expect(updatedDDO.nft.state).toBe(4);
  });
});

describe('edit algorithm', () => {
  it('should generate algorithm ddo after editing metadata', async () => {
    const updatedDDO = await getEditAlgoDdo(
      editMetadataAlgorithm,
      existingAlgorithmDdo,
      dummySdkParams,
    );
    expect(updatedDDO.metadata.name).toBe('Updated algorithm');
    expect(updatedDDO.metadata.description).toBe('Updated overview');
    expect(updatedDDO.metadata.categories).toStrictEqual(['updatedCategory']);
    expect(updatedDDO.metadata.additionalInformation.accessPermission).toBe(
      'deny',
    );
    expect(updatedDDO.credentials).toBeDefined();
    expect(updatedDDO.metadata.algorithm.language).toBe('lang123');
    expect(updatedDDO.metadata.algorithm.version).toBe('1');
    expect(updatedDDO.metadata.algorithm.container.entrypoint).toBe(
      'updatedEntryPoint',
    );
    expect(updatedDDO.metadata.algorithm.container.image).toBe('updatedImage');
    expect(updatedDDO.metadata.algorithm.container.tag).toBe('updatedTag');
    expect(updatedDDO.metadata.algorithm.container.checksum).toBe(
      'checksum123',
    );
  });

  it('should generate algorithm ddo after editing price', async () => {
    const updatedDDO = await getEditAlgoDdo(
      editPricingAlgorithm,
      existingAlgorithmDdo,
      dummySdkParams,
    );
    expect(updatedDDO.metadata.name).toBe('Dummy Algorithm');
    expect(updatedDDO.stats.price.value).toBe(1);
  });

  it('should generate algorithm ddo after editing service', async () => {
    const updatedDDO = await getEditAlgoDdo(
      editServicesAlgorithm,
      existingAlgorithmDdo,
      dummySdkParams,
    );
    expect(updatedDDO.services[0].description).toBe('Updated description');
    expect(updatedDDO.services[0].timeout).toBe(86400);
    expect(updatedDDO.services[0].additionalInformation.isExperimental).toBe(true);
    expect(updatedDDO.services[0].serviceEndpoint).toBe('https://updatedProvider.io')
  });

  it('should update owner details as transfer ownership and update state', async () => {
    const updatedDDO = await getEditAlgoDdo(
      editOwnershipAndStateAlgorithm,
      existingAlgorithmDdo,
      dummySdkParams,
    );
    expect(updatedDDO.nft.owner).toBe('new123');
    expect(updatedDDO.nft.state).toBe(4);
  });
});
