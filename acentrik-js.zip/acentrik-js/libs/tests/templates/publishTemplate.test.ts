import { getAlgorithmPublishDdo, getDatasetPublishDdo } from '../../template-converter/publish-template';
import {
  downloadFreeDataset,
  downloadPremiumDataset,
  computeFreeDataset,
  computePremiumDataset,
  publicBasicFreeAlgo,
  publicBasicPremiumAlgo,
  privateBasicFreeAlgo,
  privateBasicPremiumAlgo,
  dummySdkParams,
  computePremiumDatasetUnlimited
} from './publishTemplateTestData';

describe('publish dataset', () => {
  it('should generate download free dataset', async () => {
    const downloadFreeDatasetDDO = getDatasetPublishDdo(downloadFreeDataset, dummySdkParams)
    expect(downloadFreeDatasetDDO.nft).toBeDefined();
    expect(downloadFreeDatasetDDO.services).toBeDefined();
    expect(downloadFreeDatasetDDO.metadata).toBeDefined();
    expect(downloadFreeDatasetDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(downloadFreeDatasetDDO.services[0].consumerParameters).not.toBeDefined();
    expect(downloadFreeDatasetDDO.stats).toBeDefined();
    expect(downloadFreeDatasetDDO.chainId).toBe(123);
    expect(downloadFreeDatasetDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(downloadFreeDatasetDDO.services[0].type).toBe('access');
    expect(downloadFreeDatasetDDO.metadata.type).toBe('dataset');
  });

  it('should generate download premium dataset', async () => {
    const downloadPremiumDatasetDDO = getDatasetPublishDdo(downloadPremiumDataset, dummySdkParams)
    expect(downloadPremiumDatasetDDO.nft).toBeDefined();
    expect(downloadPremiumDatasetDDO.services).toBeDefined();
    expect(downloadPremiumDatasetDDO.metadata).toBeDefined();
    expect(downloadPremiumDatasetDDO.stats).toBeDefined();
    expect(downloadPremiumDatasetDDO.services[0].files.files[0].headers).toBeDefined();
    expect(downloadPremiumDatasetDDO.services[0].consumerParameters).toBeDefined();
    expect(downloadPremiumDatasetDDO.chainId).toBe(123);
    expect(downloadPremiumDatasetDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(downloadPremiumDatasetDDO.services[0].type).toBe('access');
    expect(downloadPremiumDatasetDDO.metadata.type).toBe('dataset');
    expect(downloadPremiumDatasetDDO.stats.price.value).toBe('1');
  });

  it('should generate compute free dataset', async () => {
    const computeFreeDatasetDDO = getDatasetPublishDdo(computeFreeDataset, dummySdkParams)
    expect(computeFreeDatasetDDO.nft).toBeDefined();
    expect(computeFreeDatasetDDO.services).toBeDefined();
    expect(computeFreeDatasetDDO.metadata).toBeDefined();
    expect(computeFreeDatasetDDO.stats).toBeDefined();
    expect(computeFreeDatasetDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(computeFreeDatasetDDO.services[0].consumerParameters).not.toBeDefined();
    expect(computeFreeDatasetDDO.chainId).toBe(123);
    expect(computeFreeDatasetDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(computeFreeDatasetDDO.services[0].type).not.toBe('access');
    expect(computeFreeDatasetDDO.services[0].type).toBe('compute');
    expect(computeFreeDatasetDDO.metadata.type).toBe('dataset');
    expect(computeFreeDatasetDDO.stats.price.value).toBe('0');
  });

  it('should generate compute premium dataset', async () => {
    const computePremiumDatasetDDO = getDatasetPublishDdo(computePremiumDataset, dummySdkParams)
    expect(computePremiumDatasetDDO.nft).toBeDefined();
    expect(computePremiumDatasetDDO.services).toBeDefined();
    expect(computePremiumDatasetDDO.metadata).toBeDefined();
    expect(computePremiumDatasetDDO.stats).toBeDefined();
    expect(computePremiumDatasetDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(computePremiumDatasetDDO.services[0].consumerParameters).not.toBeDefined();
    expect(computePremiumDatasetDDO.chainId).toBe(123);
    expect(computePremiumDatasetDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(computePremiumDatasetDDO.services[0].type).not.toBe('access');
    expect(computePremiumDatasetDDO.services[0].type).toBe('compute');
    expect(computePremiumDatasetDDO.metadata.type).toBe('dataset');
    expect(computePremiumDatasetDDO.stats.price.value).toBe('11');
  });

  it('should generate compute premium dataset with unlimited timeout', async () => {
    const computePremiumDatasetDDO = getDatasetPublishDdo(computePremiumDatasetUnlimited, dummySdkParams)
    expect(computePremiumDatasetDDO.nft).toBeDefined();
    expect(computePremiumDatasetDDO.services).toBeDefined();
    expect(computePremiumDatasetDDO.metadata).toBeDefined();
    expect(computePremiumDatasetDDO.stats).toBeDefined();
    expect(computePremiumDatasetDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(computePremiumDatasetDDO.services[0].consumerParameters).not.toBeDefined();
    expect(computePremiumDatasetDDO.chainId).toBe(123);
    expect(computePremiumDatasetDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(computePremiumDatasetDDO.services[0].type).not.toBe('access');
    expect(computePremiumDatasetDDO.services[0].type).toBe('compute');
    expect(computePremiumDatasetDDO.services[0].timeout).toBe(0);
    expect(computePremiumDatasetDDO.metadata.type).toBe('dataset');
    expect(computePremiumDatasetDDO.stats.price.value).toBe('11');
  });
});

describe('publish algorithm', () => {

  it('should generate public basic free algorithm', async () => {
    const publicBasicFreeAlgoDDO = getAlgorithmPublishDdo(publicBasicFreeAlgo, dummySdkParams)
    expect(publicBasicFreeAlgoDDO.nft).toBeDefined();
    expect(publicBasicFreeAlgoDDO.services).toBeDefined();
    expect(publicBasicFreeAlgoDDO.metadata).toBeDefined();
    expect(publicBasicFreeAlgoDDO.stats).toBeDefined();
    expect(publicBasicFreeAlgoDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(publicBasicFreeAlgoDDO.services[0].consumerParameters).not.toBeDefined();
    expect(publicBasicFreeAlgoDDO.chainId).toBe(123);
    expect(publicBasicFreeAlgoDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(publicBasicFreeAlgoDDO.services[0].type).toBe('access');
    expect(publicBasicFreeAlgoDDO.metadata.type).toBe('algorithm');
    expect(publicBasicFreeAlgoDDO.stats.price.value).toBe('0');
  });

  it('should generate public basic premium algorithm', async () => {
    const publicBasicPremiumAlgoDDO = getAlgorithmPublishDdo(publicBasicPremiumAlgo, dummySdkParams)
    expect(publicBasicPremiumAlgoDDO.nft).toBeDefined();
    expect(publicBasicPremiumAlgoDDO.services).toBeDefined();
    expect(publicBasicPremiumAlgoDDO.metadata).toBeDefined();
    expect(publicBasicPremiumAlgoDDO.stats).toBeDefined();
    expect(publicBasicPremiumAlgoDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(publicBasicPremiumAlgoDDO.services[0].consumerParameters).not.toBeDefined();
    expect(publicBasicPremiumAlgoDDO.chainId).toBe(123);
    expect(publicBasicPremiumAlgoDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(publicBasicPremiumAlgoDDO.services[0].type).toBe('access');
    expect(publicBasicPremiumAlgoDDO.metadata.type).toBe('algorithm');
    expect(publicBasicPremiumAlgoDDO.stats.price.value).toBe('11');
  });

  it('should generate private basic free algorithm', async () => {
    const privateBasicFreeAlgoDDO = getAlgorithmPublishDdo(privateBasicFreeAlgo, dummySdkParams)
    expect(privateBasicFreeAlgoDDO.nft).toBeDefined();
    expect(privateBasicFreeAlgoDDO.services).toBeDefined();
    expect(privateBasicFreeAlgoDDO.metadata).toBeDefined();
    expect(privateBasicFreeAlgoDDO.stats).toBeDefined();
    expect(privateBasicFreeAlgoDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(privateBasicFreeAlgoDDO.services[0].consumerParameters).not.toBeDefined();
    expect(privateBasicFreeAlgoDDO.chainId).toBe(123);
    expect(privateBasicFreeAlgoDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(privateBasicFreeAlgoDDO.services[0].type).toBe('compute');
    expect(privateBasicFreeAlgoDDO.metadata.type).toBe('algorithm');
    expect(privateBasicFreeAlgoDDO.stats.price.value).toBe('0');
  });

  it('should generate private basic premium algorithm', async () => {
    const privateBasicPremiumAlgoDDO = getAlgorithmPublishDdo(privateBasicPremiumAlgo, dummySdkParams)
    expect(privateBasicPremiumAlgoDDO.nft).toBeDefined();
    expect(privateBasicPremiumAlgoDDO.services).toBeDefined();
    expect(privateBasicPremiumAlgoDDO.metadata).toBeDefined();
    expect(privateBasicPremiumAlgoDDO.stats).toBeDefined();
    expect(privateBasicPremiumAlgoDDO.services[0].files.files[0].headers).not.toBeDefined();
    expect(privateBasicPremiumAlgoDDO.services[0].consumerParameters).not.toBeDefined();
    expect(privateBasicPremiumAlgoDDO.chainId).toBe(123);
    expect(privateBasicPremiumAlgoDDO.services[0].serviceEndpoint).toBe('https://dummyProvider.io');
    expect(privateBasicPremiumAlgoDDO.services[0].type).toBe('compute');
    expect(privateBasicPremiumAlgoDDO.metadata.type).toBe('algorithm');
    expect(privateBasicPremiumAlgoDDO.stats.price.value).toBe('11');
  });
  });
