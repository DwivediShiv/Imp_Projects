import {
  startMultipleCompute,
  getAuthToken,
  convertToExpiryTimestamp,
  getProviderNonceUrl,
  getProviderAuthTokenUrl,
  getComputeStartUrl,
  AssetExtended,
} from '../asset-manager/start-multiple-compute';
import { Aquarius, ConfigHelper, ProviderInstance } from '@oceanprotocol/lib';
import { Signer } from 'ethers';
import axios from 'axios';
import { config } from './constants';
import { isOrderable, handleComputeOrder } from '../common/helper';

jest.mock('@oceanprotocol/lib', () => ({
  Aquarius: jest.fn(),
  ConfigHelper: jest.fn(),
  Datatoken: jest.fn(),
  LoggerInstance: {
    log: jest.fn(),
  },
  ProviderInstance: {
    signProviderRequest: jest.fn().mockResolvedValue('mockSignature'),
    initializeCompute: jest.fn(),
    getComputeEnvironments: jest.fn().mockResolvedValue({
      1: [{ id: 'mockComputeEnvId' }],
    }),
  },
}));

jest.mock('../common/helper', () => ({
  isOrderable: jest.fn(),
  handleComputeOrder: jest.fn(),
  handleAbstractWhitelistingFlow: jest.fn(),
}));

jest.mock('axios');

function setMockAssetAlgoValues(value1, value2) {
  (Aquarius as jest.Mock).mockImplementation(() => ({
    waitForAqua: jest
      .fn()
      .mockResolvedValueOnce(value1)
      .mockResolvedValue(value2),
  }));
}

function setAxiosGetMockResponse() {
  (axios.get as jest.Mock).mockResolvedValueOnce({ data: { nonce: 1 } });
  (axios.get as jest.Mock).mockResolvedValue({
    data: { token: 'mockAuthToken' },
  });
  (axios.post as jest.Mock).mockResolvedValue({
    data: [{ jobId: 'mockJobId', txnReceipt: 'mockTxnReceipt' }],
  });
}

const assetDetails1 = {
  id: '123',
  chainId: 1,
  services: [
    {
      id: 'mockServiceId123',
      type: 'compute',
      datatokenAddress: 'mockTokenAddress',
      timeout: 0,
      serviceEndpoint: 'mockServiceEndpoint',
    },
  ],
} as AssetExtended;

const assetDetails2  = {
  id: '456',
  chainId: 1,
  services: [
    {
      id: 'mockServiceId456',
      type: 'compute',
      datatokenAddress: 'mockTokenAddress',
      timeout: 0,
      serviceEndpoint: 'mockServiceEndpoint',
    },
  ],
} as AssetExtended;

describe('convertToExpiryTimestamp', () => {
  it('should convert seconds to epoch timestamp', () => {
    const timeInSeconds = 3600;
    const currentTime = Math.floor(Date.now() / 1000);
    const expiryTimestamp = convertToExpiryTimestamp(timeInSeconds);
    expect(expiryTimestamp).toBeGreaterThanOrEqual(currentTime + 3600);
  });
});

describe('getProviderNonceUrl', () => {
  it('should return correct nonce URL', () => {
    const providerUri = 'http://provider';
    const address = '0x123';
    const expectedUrl = 'http://provider/api/services/nonce?userAddress=0x123';
    expect(getProviderNonceUrl(providerUri, address)).toEqual(expectedUrl);
  });
});

describe('getProviderAuthTokenUrl', () => {
  it('should return correct auth token URL', () => {
    const providerUri = 'http://provider';
    const expectedUrl = 'http://provider/api/services/createAuthToken';
    expect(getProviderAuthTokenUrl(providerUri)).toEqual(expectedUrl);
  });
});

describe('getComputeStartUrl', () => {
  it('should return correct compute start URL', () => {
    const providerUri = 'http://provider';
    const expectedUrl = 'http://provider/api/services/compute';
    expect(getComputeStartUrl(providerUri)).toEqual(expectedUrl);
  });
});

describe('getAuthToken', () => {
  it('should return an auth token', async () => {
    const signer = {} as Signer;
    const providerUri = 'http://provider';
    const address = '0x123';
    const expirationTimeStamp = 0;

    setAxiosGetMockResponse();

    const result = await getAuthToken(
      signer,
      providerUri,
      address,
      expirationTimeStamp,
    );
    expect(result).toEqual('mockAuthToken');
  });
});

describe('startMultipleCompute', () => {
  let owner: Signer;
  let consoleErrorSpy: jest.SpyInstance;
  let consoleLogSpy: jest.SpyInstance;
  const datasetDIDs = ['did:op:123', 'did:op:456'];
  const algorithmDIDs = ['did:op:789'];
  const federatedAlgorithmDID = 'did:op:101112';
  const oceanAquariusUri = 'http://aquarius';

  beforeEach(() => {
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
    owner = {
      getChainId: jest.fn().mockResolvedValue(1),
      getAddress: jest.fn().mockResolvedValue('0x123'),
    } as unknown as Signer;
    (ConfigHelper as jest.Mock).mockImplementation(() => ({
      getConfig: jest.fn().mockResolvedValue(config),
    }));
  });

  afterEach(() => {
    jest.clearAllMocks();
    consoleErrorSpy.mockRestore();
    consoleLogSpy.mockRestore();
  });
  
  it('should start compute jobs and return job IDs', async () => {
    setMockAssetAlgoValues(assetDetails1, assetDetails2);
    setAxiosGetMockResponse();

    (isOrderable as jest.Mock).mockReturnValue(true);
    (handleComputeOrder as jest.Mock)
      .mockResolvedValueOnce('0xAlgoTransferTxId')
      .mockResolvedValue('0xDatasetTransferTxId');

    (ProviderInstance.initializeCompute as jest.Mock).mockResolvedValue({
      algorithm: { providerFee: '0', transferTxId: '0xAlgoTransferTxId' },
      datasets: [{ providerFee: '0', transferTxId: '0xDatasetTransferTxId' }],
    });

    await startMultipleCompute(
      datasetDIDs,
      algorithmDIDs,
      federatedAlgorithmDID,
      owner,
      oceanAquariusUri,
      config,
      '',
      '',
      'mockSmartAccountAddress'
    );

    expect(consoleLogSpy).toHaveBeenLastCalledWith(
        'Here is the jobId',["mockJobId", "mockJobId"]
      );
  });
});
