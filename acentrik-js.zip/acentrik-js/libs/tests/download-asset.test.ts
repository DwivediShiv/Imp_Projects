import { download } from '../asset-manager/download-asset';
import {
  Aquarius,
  ProviderInstance,
  orderAsset,
  Config,
} from '@oceanprotocol/lib';
import { handleAbstractWhitelistingFlow } from '../common/helper';
import { getAccessDetails } from '../utils/accessDetailsAndPricing';
import { config } from './constants';

jest.mock('@oceanprotocol/lib', () => {
  return {
    Aquarius: jest.fn(),
    Datatoken: jest.fn(),
    ProviderInstance: {
      getDownloadUrl: jest.fn().mockResolvedValue('mockDownloadUrl'),
    },
    orderAsset: jest.fn().mockResolvedValue({
      wait: jest.fn().mockResolvedValue({ transactionHash: 'mockTxHash' }),
    }),
  };
});

jest.mock('../common/helper', () => {
  return {
    handleAbstractWhitelistingFlow: jest.fn(),
  };
});

jest.mock('../utils/accessDetailsAndPricing', () => {
  return {
    getAccessDetails: jest.fn(),
  };
});

function setMockDataDdoValue(value) {
  (Aquarius as jest.Mock).mockImplementation(() => ({
    waitForAqua: jest.fn().mockResolvedValue(value),
  }));
}

function setMockAccessDetailsValue(value) {
  (getAccessDetails as jest.Mock).mockResolvedValue(value);
}

  const dataDdoDetails = {
    id: 'DID',
    nft: { address: 'mockNftAddress' },
    datatokens: [{ address: 'mockDatatokenAddress' }],
    services: [
      {
        id: 1,
        serviceEndpoint: 'mockProviderURI',
        datatokenAddress: 'mockDatatokenAddress',
      },
    ],
    metadata: {},
  }

describe('download', () => {
  let mockSigner;

  beforeEach(() => {
    jest.clearAllMocks();
    mockSigner = {
      getAddress: jest.fn().mockResolvedValue('mockSignerAddress'),
      getChainId: jest.fn().mockResolvedValue(1),
    };
    setMockDataDdoValue(dataDdoDetails);
    setMockAccessDetailsValue({
        isOwned: false,
        validOrderTx: null,
        type: 'paid',
      });
  });

  it('should log an error if dataDdo is not found', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    setMockDataDdoValue(null);

    await download(
      'datasetDID',
      'destinationFolderPath',
      mockSigner,
      config,
      false,
      'oceanAquariusUrl',
      '',
      '',
      'mockSmartAccount',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error fetching DDO datasetDID.  Does this asset exists?',
    );

    consoleErrorSpy.mockRestore();
  });

  it('should whitelist required contract if accountAddr, biconomyDashboardAuthToken, and smartAccountPaymasterKey are provided', async () => {
    await download(
      'datasetDID',
      'destinationFolderPath',
      mockSigner,
      config,
      false,
      'oceanAquariusUrl',
      'biconomyDashboardAuthToken',
      'smartAccountPaymasterKey',
      'accountAddr',
    );

    expect(handleAbstractWhitelistingFlow).toHaveBeenCalledWith(
      'mockNftAddress',
      'mockDatatokenAddress',
      'biconomyDashboardAuthToken',
      'smartAccountPaymasterKey',
    );
  });

  it('should order asset if asset is not owned', async () => {
    const result = await download(
      'datasetDID',
      'destinationFolderPath',
      mockSigner,
      config,
      false,
      'oceanAquariusUrl',
      '',
      '',
      'mockSmartAccount'
    );

    expect(result).toBe('mockDownloadUrl');
    expect(ProviderInstance.getDownloadUrl).toHaveBeenCalledWith(
      'DID',
      1,
      0,
      'mockTxHash',
      'mockProviderURI',
      mockSigner,
      {
        smartAccount: 'mockSmartAccount'
      },
    );
  });

  it('should return the download URL', async () => {
    const result = await download(
      'datasetDID',
      'destinationFolderPath',
      mockSigner,
      config,
      false,
      'oceanAquariusUrl',
      '',
      '',
      'mockSmartAccount'
    );

    expect(result).toBe('mockDownloadUrl');
  });

  it('should log an error if orderAsset returns null', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    (orderAsset as jest.Mock).mockResolvedValueOnce(null);

    await download(
      'datasetDID',
      'destinationFolderPath',
      mockSigner,
      config,
      false,
      'oceanAquariusUrl',
      '',
      '',
      'mockSmartAccount'
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error ordering access for datasetDID.  Do you have enought tokens?',
    );

    consoleErrorSpy.mockRestore();
  });
});
