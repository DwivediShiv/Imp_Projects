import { editAsset } from '../asset-manager/edit-asset';
import { Aquarius } from '@oceanprotocol/lib';
import { handleAbstractWhitelistingFlow, updateEditAssetMetadata } from '../common/helper';
import { Config } from '@oceanprotocol/lib';

jest.mock('@oceanprotocol/lib', () => {
  return {
    Aquarius: jest.fn(),
    ProviderInstance: {
      encrypt: jest.fn().mockResolvedValue('mockEncryptedResponse'),
    },
  };
});

jest.mock('../common/helper', () => {
  return {
    handleAbstractWhitelistingFlow: jest.fn(),
    updateEditAssetMetadata: jest.fn().mockResolvedValue('mockUpdateAssetTx'),
  };
});

const oceanCustomConfig = {
  chainId: 1,
  network: 'network',
  subgraphUri: 'oceanSubgraphUri',
  explorerUri: 'oceanExplorerUri',
  providerUri: 'oceanProviderUri',
  metadataCacheUri: 'metadataCacheUri',
  oceanTokenAddress: '0x123',
  baseTokenDecimals: '2',
  oceanTokenSymbol: '',
  transactionBlockTimeout: 1,
  transactionConfirmationBlocks: 1,
  transactionPollingTimeout: 1,
  gasFeeMultiplier: 1
} as Config;


function setMockAssetValue(value) {
  (Aquarius as jest.Mock).mockImplementation(() => ({
    waitForAqua: jest.fn().mockResolvedValue(value),
    validate: jest.fn().mockResolvedValue({ hash: 'mockValidateHash' }),
  }));
}

describe('editAsset', () => {
  let mockSigner;
  const options = { key: 'newValue', metadata: {updated: new Date()}  }

  beforeEach(() => {
    jest.clearAllMocks();
    mockSigner = {
      getAddress: jest.fn().mockResolvedValue('mockSignerAddress'),
    };
  });

  it('should update asset with given options', async () => {
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
    setMockAssetValue({
      nft: { owner: 'mockOwner', address: 'mockNftAddress' },
      datatokens: [{ address: 'mockDatatokenAddress' }],
    });

    await editAsset(
      options,
      { key: 'value' },
      '',
      mockSigner,
      1,
      oceanCustomConfig,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress', 
      'paymentManagementUrl',
    );

    expect(updateEditAssetMetadata).toHaveBeenCalledWith(
      mockSigner,
      expect.objectContaining({ key: 'newValue' }),
      expect.objectContaining({ key: 'value' }),
      '',
      'oceanProviderUri',
      expect.any(Object),
      1,
      oceanCustomConfig,
      '',
      'mockSmartAccountAddress'
    );

    consoleLogSpy.mockRestore();
  });

  it('should return updateAssetTx', async () => {
    setMockAssetValue({
      nft: { owner: 'mockOwner', address: 'mockNftAddress' },
      datatokens: [{ address: 'mockDatatokenAddress' }],
    });

    const result = await editAsset(
      options,
      { key: 'value' },
      '',
      mockSigner,
      1,
      oceanCustomConfig,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress', 
      'paymentManagementUrl',
    );

    expect(result).toBe('mockUpdateAssetTx');
  });
});
