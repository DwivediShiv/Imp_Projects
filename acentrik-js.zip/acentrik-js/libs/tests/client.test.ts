import fs from 'fs';
import Client from '../client';
import { AAAdapter } from '../common/adapters/aa-adapter';
import { EOAdapter } from '../common/adapters/eoa-adapter';
import { downloadFile } from '../file-handler';
import { ACCOUNT_PROVIDERS, AlchemyAdapter } from '../common';

jest.mock('fs', () => ({
  promises: {
    readFile: jest.fn(),
  },
}));
jest.mock('../common/adapters/alchemy-adapter');
jest.mock('../common/adapters/aa-adapter');
jest.mock('../common/adapters/eoa-adapter');
jest.mock('../file-handler');

const mockDatasetDdo = { id: 'mock-dataset-ddo' };

jest.mock('../template-converter/publish-template', () => {
  return {
    getDatasetPublishDdo: jest.fn().mockReturnValue({ id: 'mock-dataset-ddo' }),
    getAlgorithmPublishDdo: jest.fn().mockReturnValue({ id: 'mock-algo-ddo' }),
  };
});

class TestClient extends Client {
  public getAdapter(type: string, command: string) {
    return this.createAdapter(type, command);
  }
}

describe('Client', () => {
  let client: TestClient;

  beforeEach(() => {
    client = new TestClient();
    jest.clearAllMocks();
  });

  describe('executeCommand', () => {
    it('should call publish method on adapter for publish command', async () => {
      const mockAsset = { type: 'dataset' };
      const mockFileContent = JSON.stringify(mockAsset);

      (fs.promises.readFile as jest.Mock).mockResolvedValue(mockFileContent);

      const mockAdapter = {
        publish: jest.fn().mockResolvedValue(undefined),
      };

      jest
        .spyOn(client, 'createAdapter' as any)
        .mockResolvedValue(mockAdapter as any);

      await client.executeCommand(
        'publish',
        ['test.json'],
        ACCOUNT_PROVIDERS.ALCHEMY,
      );

      expect(fs.promises.readFile).toHaveBeenCalledWith('test.json', 'utf8');
      expect(mockAdapter.publish).toHaveBeenCalledWith(mockDatasetDdo);
    });

    it('should call download method on adapter for download command', async () => {
      const mockResult = { data: 'test-data' };
      const mockFile = { filename: 'test-file' };
      const mockAdapter = {
        download: jest.fn().mockResolvedValue(mockResult),
      };
      (downloadFile as jest.Mock).mockResolvedValue(mockFile);
      jest
        .spyOn(client, 'createAdapter' as any)
        .mockReturnValue(mockAdapter as any);

      await client.executeCommand(
        'download',
        ['arg1', 'arg2'],
        ACCOUNT_PROVIDERS.ALCHEMY,
      );

      expect(mockAdapter.download).toHaveBeenCalledWith('arg1', 'arg2');
      expect(downloadFile).toHaveBeenCalledWith(mockResult, 'arg2');
    });

    it('should handle unknown command', async () => {
      jest.spyOn(console, 'log').mockImplementation(() => {});

      await client.executeCommand(
        'unknownCommand',
        [],
        ACCOUNT_PROVIDERS.ALCHEMY,
      );

      expect(console.log).toHaveBeenCalledWith(
        'Unknown command. Type `help` to list all commands',
      );
    });

    // Add more tests for other commands as needed...
  });

  describe('createAdapter', () => {
    it('should create AlchemyAdapter for ALCHEMY type', async () => {
      process.env.API_KEY = 'test-api-key';
      process.env.SMART_ACCOUNT_ADDRESS = 'test-smart-account-address';

      const adapter = await client.getAdapter(
        ACCOUNT_PROVIDERS.ALCHEMY,
        'publish',
      );

      expect(adapter).toBeInstanceOf(AlchemyAdapter);
    });

    it('should create AAAdapter for BICONOMY type', async () => {
      process.env.SMART_ACCOUNT_BUNDLER_KEY = 'test-bundler-key';

      const adapter = await client.getAdapter(
        ACCOUNT_PROVIDERS.BICONOMY,
        'publish',
      );

      expect(adapter).toBeInstanceOf(AAAdapter);
    });

    it('should create EOAdapter for EOA type', async () => {
      const adapter = await client.getAdapter(ACCOUNT_PROVIDERS.EOA, 'publish');

      expect(adapter).toBeInstanceOf(EOAdapter);
    });

    it('should return null for unknown type', async () => {
      const adapter = await client.getAdapter('UNKNOWN', 'publish');

      expect(adapter).toBeInstanceOf(EOAdapter);
    });
  });
});
