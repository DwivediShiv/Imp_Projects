import { stopCompute } from '../asset-manager/stop-compute';
import { Aquarius, ProviderInstance } from '@oceanprotocol/lib';

jest.mock('@oceanprotocol/lib', () => {
  return {
    Aquarius: jest.fn(),
    ProviderInstance: {
      computeStop: jest.fn().mockResolvedValue('mockJobStatus'),
    },
  };
});

function setMockResolvedDdoValue(value) {
  (Aquarius as jest.Mock).mockImplementation(() => ({
    waitForAqua: jest.fn().mockResolvedValue(value),
  }));
}

describe('stopCompute', () => {
  let mockSigner;

  beforeEach(() => {
    jest.clearAllMocks();
    mockSigner = {
      getAddress: jest.fn().mockResolvedValue('mockSignerAddress'),
    };
  });

  it('should log an error if asset is not found', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    setMockResolvedDdoValue(null);

    await stopCompute(
      'datasetDID',
      'jobID',
      mockSigner,
      'oceanAquariusUri',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error fetching DDO datasetDID.  Does this asset exists?'
    );

    consoleErrorSpy.mockRestore();
  });

  it('should call ProviderInstance.computeStop with correct parameters and log job status', async () => {
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
    setMockResolvedDdoValue({
      services: [{ serviceEndpoint: 'mockProviderURI' }],
    });

    await stopCompute(
      'datasetDID',
      'jobID',
      mockSigner,
      'oceanAquariusUri',
    );

    expect(ProviderInstance.computeStop).toHaveBeenCalledWith(
      'datasetDID',
      'mockSignerAddress',
      'jobID',
      'mockProviderURI',
      mockSigner
    );
    expect(consoleLogSpy).toHaveBeenCalledWith('stopped compute', 'mockJobStatus');

    consoleLogSpy.mockRestore();
  });
});
