import { commandToEventType } from '../common/constants';

describe('commandToEventType', () => {
  it('should map commands to the correct event types', () => {
    const expectedMappings = {
      publish: 'publish',
      editAsset: 'publish',
      allowAlgo: 'publish',
      disAllowAlgo: 'publish',
      aggregate: 'compute',
      multipleCompute: 'compute',
      compute: 'compute',
      stopCompute: 'compute',
      getJobStatus: 'compute',
      getJobResults: 'compute',
      downloadJobResults: 'compute',
      download: 'consume',
    };

    Object.keys(expectedMappings).forEach((command) => {
      expect(commandToEventType[command]).toBe(expectedMappings[command]);
    });
  });

  it('should have the correct number of mappings', () => {
    const expectedNumberOfMappings = 12;
    expect(Object.keys(commandToEventType).length).toBe(
      expectedNumberOfMappings,
    );
  });

  it('should have only the expected keys', () => {
    const expectedKeys = [
      'publish',
      'editAsset',
      'allowAlgo',
      'disAllowAlgo',
      'aggregate',
      'multipleCompute',
      'compute',
      'stopCompute',
      'getJobStatus',
      'getJobResults',
      'downloadJobResults',
      'download',
    ];

    expect(Object.keys(commandToEventType)).toEqual(
      expect.arrayContaining(expectedKeys),
    );
    expect(Object.keys(commandToEventType).length).toBe(expectedKeys.length);
  });
});
