import { disAllowAlgo } from '../asset-manager/disallow-algo';
import { Aquarius } from '@oceanprotocol/lib';
import { Signer } from 'ethers';

jest.mock('@oceanprotocol/lib', () => {
  return {
    Aquarius: jest.fn(),
    ProviderInstance: {
      checkDidFiles: jest.fn().mockResolvedValue([{ checksum: 'mockChecksum' }]),
    },
  };
});

jest.mock('../common/helper', () => {
  return {
    handleAbstractWhitelistingFlow: jest.fn(),
    updateAssetMetadata: jest.fn().mockResolvedValue({
      wait: jest.fn().mockResolvedValue('mockTxReceipt'),
    }),
  };
});

function setMockAssetAlgoValues(value) {
  (Aquarius as jest.Mock).mockImplementation(() => ({
    waitForAqua: jest.fn().mockResolvedValue(value),
  }));
}

describe('disAllowAlgo', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should log an error if asset is not found', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    setMockAssetAlgoValues(null);

    await disAllowAlgo(
      'datasetDID',
      'algoDID',
      {} as Signer,
      1,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error fetching DDO datasetDID.  Does this asset exists?'
    );

    consoleErrorSpy.mockRestore();
  });

  it('should log an error if user is not the owner of the asset', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    setMockAssetAlgoValues({ nft: { owner: 'differentAddress' } });

    await disAllowAlgo(
      'datasetDID',
      'algoDID',
      {} as Signer,
      1,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'You are not the owner of this asset, and there for you cannot update it.'
    );

    consoleErrorSpy.mockRestore();
  });

  it('should log an error if asset service is not compute type', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    setMockAssetAlgoValues({
      services: [{ type: 'download' }],
      nft: { owner: 'mockSmartAccountAddress' },
    });

    await disAllowAlgo(
      'datasetDID',
      'algoDID',
      {} as Signer,
      1,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error getting computeService for datasetDID.  Does this asset has an computeService?'
    );

    consoleErrorSpy.mockRestore();
  });

  it('should log an error if there are no trusted algorithms', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    setMockAssetAlgoValues({
      services: [{ type: 'compute', compute: { publisherTrustedAlgorithms: [] } }],
      nft: { owner: 'mockSmartAccountAddress' },
    });

    await disAllowAlgo(
      'datasetDID',
      'algoDID',
      {} as Signer,
      1,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      ' datasetDID.  Does this asset has an computeService?'
    );

    consoleErrorSpy.mockRestore();
  });

  it('should log an error if algorithm is not in trusted list', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    setMockAssetAlgoValues({
      services: [{
        type: 'compute',
        compute: {
          publisherTrustedAlgorithms: [{ did: 'differentAlgoDID' }]
        }
      }],
      nft: { owner: 'mockSmartAccountAddress' },
    });

    await disAllowAlgo(
      'datasetDID',
      'algoDID',
      {} as Signer,
      1,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      ' datasetDID.  is not allowed by the publisher to run on algoDID'
    );

    consoleErrorSpy.mockRestore();
  });

  it('should log success messages when algorithm is removed from trusted list', async () => {
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
    setMockAssetAlgoValues({
      services: [{
        type: 'compute',
        compute: {
          publisherTrustedAlgorithms: [{ did: 'algoDID' }]
        }
      }],
      nft: { owner: 'mockSmartAccountAddress' },
    });

    await disAllowAlgo(
      'datasetDID',
      'algoDID',
      {} as Signer,
      1,
      'oceanAquariusUri',
      'oceanProviderUri',
      '',
      '',
      'mockSmartAccountAddress',
    );

    expect(consoleLogSpy).toHaveBeenCalledWith(
      'asset removed from trusted algos', 'mockTxReceipt'
    );
    expect(consoleLogSpy).toHaveBeenCalledWith('DisAllow Algo command completed');

    consoleLogSpy.mockRestore();
  });
});
