// test/cli.test.ts
import { ACCOUNT_PROVIDERS } from '../common/constants';
import Client from '../client';
import { help } from '../help';
import { start } from '../cli';

// Mock dependencies
jest.mock('../client');
jest.mock('../help');

describe('start function', () => {
  let originalArgv: string[];
  let originalEnv: NodeJS.ProcessEnv;

  beforeEach(() => {
    originalArgv = process.argv;
    originalEnv = process.env;
    process.argv = ['node', 'cli.ts'];
    process.env = {};
    jest.resetModules(); // Reset the module registry before each test
    jest.clearAllMocks(); // Clear all mocks before each test
  });

  afterEach(() => {
    process.argv = originalArgv;
    process.env = originalEnv;
  });

  it('should call help function when command is help', async () => {
    process.argv.push('help');
    await start();
    expect(help).toHaveBeenCalledTimes(1);
  });

  it('should create a Client and call executeCommand with type ALCHEMY', async () => {
    process.env.SMART_ACCOUNT_ADDRESS = 'some_address';
    process.env.API_KEY = 'some_api_key';
    process.argv.push('someCommand', 'arg1', 'arg2');

    const clientInstance = new Client();
    (Client as jest.Mock).mockImplementation(() => clientInstance);
    clientInstance.executeCommand = jest.fn();

    await start();

    expect(Client).toHaveBeenCalledTimes(2);
    expect(clientInstance.executeCommand).toHaveBeenCalledTimes(1);
    expect(clientInstance.executeCommand).toHaveBeenCalledWith(
      'someCommand',
      ['arg1', 'arg2'],
      ACCOUNT_PROVIDERS.ALCHEMY,
    );
  });

  it('should create a Client and call executeCommand with type EOA', async () => {
    process.argv.push('someCommand', 'arg1', 'arg2');

    const clientInstance = new Client();
    (Client as jest.Mock).mockImplementation(() => clientInstance);
    clientInstance.executeCommand = jest.fn();

    await start();

    expect(Client).toHaveBeenCalledTimes(2);
    expect(clientInstance.executeCommand).toHaveBeenCalledTimes(1);
    expect(clientInstance.executeCommand).toHaveBeenCalledWith(
      'someCommand',
      ['arg1', 'arg2'],
      'EOA',
    );
  });

  it('should log args to console', async () => {
    console.log = jest.fn(); // Mock console.log
    process.argv.push('someCommand', 'arg1', 'arg2');

    const clientInstance = new Client();
    (Client as jest.Mock).mockImplementation(() => clientInstance);
    clientInstance.executeCommand = jest.fn();

    await start();

    expect(console.log).toHaveBeenCalledWith('[Cli.ts] args=', [
      'someCommand',
      'arg1',
      'arg2',
    ]);
  });
});
