import { Config } from '@oceanprotocol/lib';

export const config: Config = {
  chainId: 1,
  network: 'Any network',
  metadataCacheUri: 'metadataCahceUri',
  nodeUri: 'nodeUri',
  providerUri: 'providerUri',
  subgraphUri: 'subgraphUri',
  explorerUri: 'exploreUri',
  nftFactoryAddress: '0xNftFactoryAddress',
  dispenserAddress: '0xDispenserAddress',
  fixedRateExchangeAddress: '0xFixedRateExchangeAddress',
  oceanTokenAddress: '0x12A3z456W7d8901cc23dS82b9DB733fZ9ccBA000',
  oceanTokenSymbol: 'OCEAN',
  transactionBlockTimeout: 50,
  transactionConfirmationBlocks: 1,
  transactionPollingTimeout: 750,
  gasFeeMultiplier: 1.1,
};

export const mockDummyDatasetDetails = {
  id: 'mockDummyDataset',
  chainId: 1,
  accessDetails: {},
  services: [
    {
      id: 'mockServiceId',
      type: 'compute',
      datatokenAddress: 'mockTokenAddress',
      timeout: 0,
      serviceEndpoint: 'mockServiceEndpoint',
    },
  ],
};

export const getAggAlgoAssetsArr = [
  {
    id: 'mockAlgoDID',
    accessDetails: {},
    services: [
      {
        id: 'mockServiceId',
        datatokenAddress: 'mockTokenAddress',
        timeout: 0,
      },
    ],
  },
]

export const computeJobsDetails = [
  {
    smartAccount: 'mockSmartAccount',
    agreementId: 'mockAggrementId',
    jobId: 'mockJobId',
    owner: 'mockOwner',
    status: 70,
    statusText: 'Job finished',
    dateCreated: new Date(),
    results: new Array(4),
    stopreq: 0,
    removed: 0,
    guid: 'mockGuId',
    algoDID: 'mockAlgoDID',
    inputDID: ['mockInputDID'],
    aggregateAlgoDID: 'mockAggAlgoDID',
    provider_session_auth_token: 'mockAuthToken',
  },
]

export const computeAssetDetails = {
  documentId: 'mockDummyDataset',
  serviceId: 'mockServiceId',
  transferTxId: 'mockDatasetTxReceipt',
  userdata: {
    guid: 'mockGuid',
    aggregateAlgorithmId: '-',
    providerAuthToken: '-',
    smartAccount: 'mockSmartAccountAddress'
  },
}

export const computeAlgorithm = {
  documentId: 'mockAlgoDID',
  serviceId: 'mockServiceId',
  transferTxId: 'mockAlgoTxReceipt',
  userdata: {
    smartAccount: 'mockSmartAccountAddress'
  },
  algocustomdata: {
    resultUrls: [{ job_url: 'mockUrl', job_headers: { AuthToken: '123' } }],
  },
}

export const aquariusAssetDetails = {
  services: [
    {
      serviceEndpoint: 'http://provider.uri',
      datatokenAddress: '0xTokenAddress',
      id: '0',
    },
  ],
};

export const aquariusAlgoDetails = {
    services: [
      {
        serviceEndpoint: 'http://algo.provider.uri',
        datatokenAddress: '0xAlgoTokenAddress',
        id: '1',
      },
    ],
  }

  export const computeEnvsDetails = [
    {
      id: 'env1',
      maxJobDuration: 3600,
      consumerAddress: '0xConsumerAddress',
    },
  ]