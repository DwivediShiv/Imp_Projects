import { getDdo } from '../asset-manager/get-ddo';
import { Aquarius } from '@oceanprotocol/lib';

jest.mock('@oceanprotocol/lib', () => {
  return {
    Aquarius: jest.fn()
  };
});

function setMockResolvedDdoValue(value) {
    (Aquarius as jest.Mock).mockImplementation(() => ({
        waitForAqua: jest.fn().mockResolvedValue(value)
      }));
}

describe('getDdo', () => {
  it('should log an error if resolvedDDO is null', async () => {
    const datasetDID = 'your-dataset-did';
    const oceanAquariusUri = 'your-ocean-aquarius-uri';
    setMockResolvedDdoValue(null)

    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();

    await getDdo(datasetDID, oceanAquariusUri);

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      `Error fetching Asset with DID: ${datasetDID}.  Does this asset exists?`
    );

    consoleErrorSpy.mockRestore();
  });

  it('should log the DDO if resolvedDDO is with value', async () => {
    const datasetDID = 'your-dataset-did';
    const oceanAquariusUri = 'your-ocean-aquarius-uri';
    const resolvedDDO = { sample: 'data' };
    setMockResolvedDdoValue(resolvedDDO)

    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    await getDdo(datasetDID, oceanAquariusUri);

    expect(consoleLogSpy).toHaveBeenCalledWith('DDO: ', JSON.stringify(resolvedDDO));

    consoleLogSpy.mockRestore();
  });
});

