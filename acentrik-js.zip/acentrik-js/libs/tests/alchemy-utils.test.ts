import { getAlchemyPaymasterAddress } from '@alchemy/aa-alchemy';
import { polygon, polygonAmoy, sepolia } from '@alchemy/aa-core';
import { Chain } from 'viem';
import {
  getAlchemyCoreChainConfig,
  fancyGetAlchemyPaymasterAddress,
  getAlchemyRpcTransport,
} from '../common/providers/alchemy/utils';

jest.mock('@alchemy/aa-alchemy', () => ({
  getAlchemyPaymasterAddress: jest.fn(),
}));

jest.mock('@alchemy/aa-core', () => ({
  polygon: { name: 'Polygon' },
  polygonAmoy: { name: 'PolygonAmoy' },
  sepolia: { name: 'Sepolia' },
}));

describe('getAlchemyCoreChainConfig', () => {
  it('should return sepolia config for chainId 11155111', () => {
    expect(getAlchemyCoreChainConfig(11155111)).toEqual(sepolia);
  });

  it('should return polygon config for chainId 137', () => {
    expect(getAlchemyCoreChainConfig(137)).toEqual(polygon);
  });

  it('should return polygonAmoy config for chainId 80002', () => {
    expect(getAlchemyCoreChainConfig(80002)).toEqual(polygonAmoy);
  });

  it('should return undefined for an unknown chainId', () => {
    expect(getAlchemyCoreChainConfig(99999)).toBeUndefined();
  });
});

describe('fancyGetAlchemyPaymasterAddress', () => {
  it('should call getAlchemyPaymasterAddress with the correct config for chainId 11155111', () => {
    fancyGetAlchemyPaymasterAddress(11155111);
    expect(getAlchemyPaymasterAddress).toHaveBeenCalledWith(sepolia);
  });

  it('should call getAlchemyPaymasterAddress with the correct config for chainId 137', () => {
    fancyGetAlchemyPaymasterAddress(137);
    expect(getAlchemyPaymasterAddress).toHaveBeenCalledWith(polygon);
  });

  it('should call getAlchemyPaymasterAddress with the correct config for chainId 80002', () => {
    fancyGetAlchemyPaymasterAddress(80002);
    expect(getAlchemyPaymasterAddress).toHaveBeenCalledWith(polygonAmoy);
  });
});

describe('getAlchemyRpcTransport', () => {
  it('should return the correct RPC URL for chainId 11155111', () => {
    expect(getAlchemyRpcTransport(11155111)).toBe(
      'https://eth-sepolia.g.alchemy.com/v2/',
    );
  });

  it('should return the correct RPC URL for chainId 137', () => {
    expect(getAlchemyRpcTransport(137)).toBe(
      'https://polygon-mainnet.g.alchemy.com/v2/',
    );
  });

  it('should return the correct RPC URL for chainId 80002', () => {
    expect(getAlchemyRpcTransport(80002)).toBe(
      'https://polygon-amoy.g.alchemy.com/v2/',
    );
  });

  it('should return undefined for an unknown chainId', () => {
    expect(getAlchemyRpcTransport(99999)).toBeUndefined();
  });
});
