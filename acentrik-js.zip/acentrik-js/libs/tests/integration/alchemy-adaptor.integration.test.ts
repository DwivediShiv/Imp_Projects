import {
  ACCOUNT_PROVIDERS,
  AlchemyAccountAbstractionProviders,
} from '../../common';
import { ethers } from 'ethers';
import { createJsonRpcProvider } from '../../common/providers/ethers-jsonrpc-provider';
import { createModularAccountAlchemyClient } from '@alchemy/aa-alchemy';
import { LocalAccountSigner } from '@alchemy/aa-core';
import { createAlchemySmartAccount } from '../../common/providers/alchemy/smart-account';
import {
  getAlchemyRpcTransport,
  getAlchemyCoreChainConfig,
} from '../../common/providers/alchemy/utils';
import { createSigner } from '../../common/providers/ethers-signer';
import { createNft } from '../../common/providers/nft';
import { createNftFactory } from '../../common/providers/nft-factory';
import { createOceanConfig } from '../../common/providers/ocean-config';
import { transactionManager } from '../../common/providers/transaction-manager';

const createJsonRpcProviderMock = createJsonRpcProvider as jest.Mock;
const createSignerMock = createSigner as jest.Mock;
const createOceanConfigMock = createOceanConfig as jest.Mock;
const createNftFactoryMock = createNftFactory as jest.Mock;
const createNftMock = createNft as jest.Mock;
const LocalAccountSignerMock =
  LocalAccountSigner.privateKeyToAccountSigner as jest.Mock;
const getAlchemyRpcTransportMock = getAlchemyRpcTransport as jest.Mock;
const getAlchemyCoreChainConfigMock = getAlchemyCoreChainConfig as jest.Mock;
const createModularAccountAlchemyClientMock =
  createModularAccountAlchemyClient as jest.Mock;

jest.mock('../../common/providers/ethers-jsonrpc-provider', () => ({
  createJsonRpcProvider: jest.fn(),
}));

jest.mock('@alchemy/aa-alchemy', () => ({
  createModularAccountAlchemyClient: jest.fn(),
  createSmartAccountClient: jest.fn(),
}));

jest.mock('@alchemy/aa-core', () => ({
  LocalAccountSigner: {
    privateKeyToAccountSigner: jest.fn(),
  },
}));

jest.mock('../../common/providers/alchemy/smart-account', () => ({
  createAlchemySmartAccount: jest.fn(),
}));

jest.mock('../../common/providers/alchemy/utils', () => ({
  getAlchemyRpcTransport: jest.fn(),
  getAlchemyCoreChainConfig: jest.fn(),
}));

jest.mock('../../common/providers/ethers-signer', () => ({
  createSigner: jest.fn(),
}));

jest.mock('../../common/providers/nft', () => ({
  createNft: jest.fn(),
}));

jest.mock('../../common/providers/nft-factory', () => ({
  createNftFactory: jest.fn(),
}));

jest.mock('../../common/providers/ocean-config', () => ({
  createOceanConfig: jest.fn(),
}));

jest.mock('../../common/providers/transaction-manager', () => ({
  transactionManager: {
    init: jest.fn(),
  },
}));

describe('AlchemyAccountAbstractionProviders Integration Test', () => {
  const options = {
    rpcUrl: 'https://mock-rpc-url',
    chainId: '1',
    privateKey: 'mockPrivateKey',
    smartAccountAddress: 'mockSmartAccountAddress',
    userRole: 'mockUserRole',
    apiKey: 'mockApiKey',
    infuraProjectId: 'mockInfuraProjectId',
    eventType: 'consume',
  };

  const mockJsonRpcProvider = { provider: 'mockJsonRpcProvider' };
  const mockSigner = ethers.Wallet;
  const mockOceanConfig = { config: 'mockOceanConfig' };
  const mockNftFactory = { factory: 'mockNftFactory' };
  const mockNft = { nft: 'mockNft' };

  beforeEach(() => {
    createJsonRpcProviderMock.mockReturnValue(mockJsonRpcProvider);
    createSignerMock.mockReturnValue(mockSigner);
    createOceanConfigMock.mockReturnValue(mockOceanConfig);
    createNftFactoryMock.mockReturnValue(mockNftFactory);
    createNftMock.mockReturnValue(mockNft);
    LocalAccountSignerMock.mockReturnValue('mockAlchemySigner');
    getAlchemyRpcTransportMock.mockReturnValue('mockRpcTransport');
    getAlchemyCoreChainConfigMock.mockReturnValue('mockChainConfig');
    createModularAccountAlchemyClientMock.mockResolvedValue({
      extend: jest.fn().mockReturnThis(),
      checkGasSponsorshipEligibility: jest.fn().mockResolvedValue(true),
      account: 'mockAccount',
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should ensure all components are initialized correctly', async () => {
    const alchemyAccountAbstractionProvidersInstance =
      new AlchemyAccountAbstractionProviders(options as any);

    expect(createJsonRpcProvider).toHaveBeenCalledWith({
      rpcUrl: options.rpcUrl,
    });
    expect(createSigner).toHaveBeenCalledWith({
      privateKey: options.privateKey,
      chainId: parseInt(options.chainId),
      jsonRpcProvider: mockJsonRpcProvider,
    });

    expect(createAlchemySmartAccount).toHaveBeenCalledWith({
      orgSmartAccount: options.smartAccountAddress,
      chainId: parseInt(options.chainId),
      signer: 'mockAlchemySigner' as any,
      userRole: options.userRole,
      apiKey: options.apiKey,
      eventType: options.eventType,
    });

    const alchemySmartAccount = await createAlchemySmartAccount({
      orgSmartAccount: options.smartAccountAddress,
      chainId: parseInt(options.chainId),
      signer: 'mockAlchemySigner' as any,
      userRole: options.userRole,
      apiKey: options.apiKey,
      eventType: options.eventType,
    });

    expect(transactionManager.init).toHaveBeenCalledWith(
      mockSigner,
      alchemySmartAccount,
      undefined,
      ACCOUNT_PROVIDERS.ALCHEMY,
    );
    expect(transactionManager.init).toHaveBeenCalled();

    expect(createOceanConfig).toHaveBeenCalledWith({
      chainId: parseInt(options.chainId),
      infuraProjectId: options.infuraProjectId,
    });

    expect(createNftFactory).toHaveBeenCalledWith({
      oceanConfig: { config: 'mockOceanConfig' },
      signer: mockSigner,
    });

    expect(createNft).toHaveBeenCalledWith({
      chainId: parseInt(options.chainId),
      signer: mockSigner,
    });

    expect(alchemyAccountAbstractionProvidersInstance.jsonRpcProvider).toEqual(
      mockJsonRpcProvider,
    );
    expect(alchemyAccountAbstractionProvidersInstance.oceanConfig).toEqual(
      mockOceanConfig,
    );
    expect(alchemyAccountAbstractionProvidersInstance.nftFactory).toEqual(
      mockNftFactory,
    );
    expect(alchemyAccountAbstractionProvidersInstance.nft).toEqual(mockNft);
    expect(alchemyAccountAbstractionProvidersInstance.chainId).toEqual(
      parseInt(options.chainId),
    );
  });

  it('should handle bootstrap method error gracefully', async () => {
    createJsonRpcProviderMock.mockImplementationOnce(() => {
      throw new Error('mock error');
    });

    // Mock console.log
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    const alchemyAccountAbstractionProvidersInstance =
      new AlchemyAccountAbstractionProviders(options as any);

    await expect(
      alchemyAccountAbstractionProvidersInstance.bootstrap(options as any),
    ).resolves.not.toThrow();

    expect(consoleLogSpy).toHaveBeenCalledWith(
      'Unable to boostrap the CLI: ',
      new Error('mock error'),
    );

    // Restore console.log
    consoleLogSpy.mockRestore();
  });
});
