import { publishAsset } from '../asset-manager/create-asset';
import {
  Aquarius,
  ProviderInstance,
  NftFactory,
} from '@oceanprotocol/lib';
import { Signer } from 'ethers';
import { config } from './constants';

jest.mock('@oceanprotocol/lib', () => ({
  Aquarius: jest.fn(),
  getHash: jest.fn().mockReturnValue('mockid123321'),
  getEventFromTx: jest
    .fn()
    .mockReturnValue({
      args: {
        newTokenAddress: '0x1234567890abcdef1234567890abcdef12345678',
      },
    }),
  ProviderInstance: {
    encrypt: jest.fn(),
  },
  Nft: jest.fn().mockReturnValue({
    setMetadataAndTokenURI: jest.fn(),
  }),
  NftFactory: jest.fn(),
  ethers: jest.fn().mockReturnValue({
    utils: jest.fn().mockReturnValue({
      getAddress: jest
        .fn()
        .mockReturnValue('0x1234567890abcdef1234567890abcdef12345678'),
    }),
  }),
}));

describe('publishAsset', () => {
  let owner: Signer;
  let aquariusInstance: Aquarius;

  beforeEach(() => {
    owner = {
      getAddress: jest.fn().mockResolvedValue('0xOwnerAddress'),
      getChainId: jest.fn().mockResolvedValue(1),
    } as unknown as Signer;

    aquariusInstance = new Aquarius('http://aquarius.url');
    aquariusInstance.validate = jest
      .fn()
      .mockResolvedValue({ hash: 'metadataHash' });
  });

  it('should call createNftWithDatatoken if price value is missing ', async () => {
    const name = 'TestAsset';
    const symbol = 'TST';
    const assetUrl = { files: 'http://asset.url' };
    const ddo = {
      services: [{ files: '' }],
      nft: {
        name: 'TestAsset',
        symbol: 'TST',
        description: 'Test asset description',
      },
      stats: {
        price: { value: '' },
      },
    };
    const providerUrl = 'http://provider.url';
    const encryptDDO = true;

    const nftFactoryMock = {
      createNftWithDatatoken: jest.fn().mockResolvedValue({
        wait: jest.fn().mockResolvedValue({
          events: [
            {
              event: 'NFTCreated',
              args: { newTokenAddress: '0xNftAddress' },
            },
            {
              event: 'TokenCreated',
              args: { newTokenAddress: '0xDatatokenAddress' },
            },
          ],
        }),
      }),
    };
    (NftFactory as jest.Mock).mockImplementation(() => nftFactoryMock);
    (ProviderInstance.encrypt as jest.Mock).mockResolvedValue('encryptedData');

    const ddoId = await publishAsset(
      name,
      symbol,
      owner,
      assetUrl,
      ddo,
      providerUrl,
      config,
      aquariusInstance,
      encryptDDO,
      '',
      '',
      '',
      'mockSmartAccountAddress'
    );

    expect(ddoId).toBeDefined();
    expect(
      nftFactoryMock.createNftWithDatatoken,
    ).toHaveBeenCalled();
    expect(ProviderInstance.encrypt).toHaveBeenCalled();
    expect(aquariusInstance.validate).toHaveBeenCalled();
  });

  it('should publish a free asset successfully with encrypt ddo', async () => {
    const name = 'TestAsset';
    const symbol = 'TST';
    const assetUrl = { files: 'http://asset.url' };
    const ddo = {
      services: [{ files: '' }],
      nft: {
        name: 'TestAsset',
        symbol: 'TST',
        description: 'Test asset description',
      },
      stats: {
        price: { value: '0' },
      },
    };
    const providerUrl = 'http://provider.url';
    const encryptDDO = true;

    const nftFactoryMock = {
      createNftWithDatatokenWithDispenser: jest.fn().mockResolvedValue({
        wait: jest.fn().mockResolvedValue({
          events: [
            {
              event: 'NFTCreated',
              args: { newTokenAddress: '0xNftAddress' },
            },
            {
              event: 'TokenCreated',
              args: { newTokenAddress: '0xDatatokenAddress' },
            },
          ],
        }),
      }),
    };
    (NftFactory as jest.Mock).mockImplementation(() => nftFactoryMock);
    (ProviderInstance.encrypt as jest.Mock).mockResolvedValue('encryptedData');

    const ddoId = await publishAsset(
      name,
      symbol,
      owner,
      assetUrl,
      ddo,
      providerUrl,
      config,
      aquariusInstance,
      encryptDDO,
      '',
      '',
      '',
      'mockSmartAccountAddress'
    );

    expect(ddoId).toBeDefined();
    expect(
      nftFactoryMock.createNftWithDatatokenWithDispenser,
    ).toHaveBeenCalled();
    expect(ProviderInstance.encrypt).toHaveBeenCalled();
    expect(aquariusInstance.validate).toHaveBeenCalled();
  });

  it('should publish a premium asset successfully with encrypt ddo', async () => {
    const name = 'TestAsset';
    const symbol = 'TST';
    const assetUrl = { files: 'http://asset.url' };
    const ddo = {
      services: [{ files: '' }],
      nft: {
        name: 'TestAsset',
        symbol: 'TST',
        description: 'Test asset description',
      },
      stats: {
        price: { value: '1' },
      },
    };
    const providerUrl = 'http://provider.url';
    const encryptDDO = true;

    const nftFactoryMock = {
      createNftWithDatatokenWithFixedRate: jest.fn().mockResolvedValue({
        wait: jest.fn().mockResolvedValue({
          events: [
            {
              event: 'NFTCreated',
              args: { newTokenAddress: '0xNftAddress' },
            },
            {
              event: 'TokenCreated',
              args: { newTokenAddress: '0xDatatokenAddress' },
            },
          ],
        }),
      }),
    };
    (NftFactory as jest.Mock).mockImplementation(() => nftFactoryMock);
    (ProviderInstance.encrypt as jest.Mock).mockResolvedValue('encryptedData');

    const ddoId = await publishAsset(
      name,
      symbol,
      owner,
      assetUrl,
      ddo,
      providerUrl,
      config,
      aquariusInstance,
      encryptDDO,
      '',
      '',
      '',
      'mockSmartAccountAddress'
    );

    expect(ddoId).toBeDefined();
    expect(
      nftFactoryMock.createNftWithDatatokenWithFixedRate,
    ).toHaveBeenCalled();
    expect(ProviderInstance.encrypt).toHaveBeenCalled();
    expect(aquariusInstance.validate).toHaveBeenCalled();
  });
});
