import { downloadJobResult } from '../asset-manager/download-job-result';
import { Aquarius, ProviderInstance } from '@oceanprotocol/lib';
import { Signer } from 'ethers';

jest.mock('@oceanprotocol/lib', () => ({
  ProviderInstance: {
    getComputeResultUrl: jest.fn(),
  },
  Aquarius: jest.fn().mockImplementation(() => ({
    waitForAqua: jest.fn(),
  })),
}));

describe('downloadJobResult', () => {
  let owner: Signer;
  let consoleErrorSpy: jest.SpyInstance;

  beforeEach(() => {
    owner = {
      getAddress: jest.fn().mockResolvedValue('0x123'),
    } as unknown as Signer;
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
  });

  afterEach(() => {
    jest.clearAllMocks();
    consoleErrorSpy.mockRestore();
  });

  it('should fetch the job result and return the result', async () => {
    const mockJobResult = 'http://example.com/result';
    const mockServiceEndpoint = 'http://provider.uri';

    (Aquarius as jest.Mock).mockImplementation(() => ({
      waitForAqua: jest.fn().mockResolvedValue({
        services: [{ serviceEndpoint: mockServiceEndpoint }],
      }),
    }));

    (ProviderInstance.getComputeResultUrl as jest.Mock).mockResolvedValue(
      mockJobResult,
    );

    const result = await downloadJobResult(
      'jobID123',
      '0',
      'assetId',
      'path/to/destination',
      owner,
      false,
      'http://provider.uri',
      'oceanAquariusUri',
    );

    expect(ProviderInstance.getComputeResultUrl).toHaveBeenCalledWith(
      mockServiceEndpoint,
      owner,
      'jobID123',
      0,
    );
    expect(result).toBe(mockJobResult);
  });

  it('should handle error response from result url function', async () => {
    const mockError = new Error('Failed to fetch result');

    (Aquarius as jest.Mock).mockImplementation(() => ({
      waitForAqua: jest.fn().mockResolvedValue({
        services: [{ serviceEndpoint: 'http://provider.uri' }],
      }),
    }));

    (ProviderInstance.getComputeResultUrl as jest.Mock).mockRejectedValue(
      mockError,
    );

    await downloadJobResult(
      'jobID123',
      'invalid_index',
      'assetId',
      'path/to/destination',
      owner,
      false,
      'http://provider.uri',
      'http://aquarius.uri',
    );
    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error while downloading the job result: ',
      mockError,
    );
  });
});
