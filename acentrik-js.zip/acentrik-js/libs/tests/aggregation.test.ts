import axios from 'axios';
import {
  buyDatasetNew,
  fetchDummyDataset,
  getAssets,
  prepareResultURLsForAggregateAlgo,
} from '../asset-manager/start-multiple-compute';
import { ProviderInstance } from '@oceanprotocol/lib';
import { getAccessDetails } from '../utils/accessDetailsAndPricing';
import { aggregation } from '../asset-manager/aggregation';
import {
  computeAlgorithm,
  computeAssetDetails,
  config,
  getAggAlgoAssetsArr,
  mockDummyDatasetDetails,
} from './constants';

jest.mock('axios', () => {
  const computeJobsDetails = {
    data: [
      {
        agreementId: 'mockAggrementId',
        jobId: 'mockJobId',
        owner: 'mockOwner',
        status: 70,
        statusText: 'Job finished',
        dateCreated: new Date(),
        results: new Array(4),
        guid: 'mockGuId',
        algoDID: 'mockAlgoDID',
        inputDID: ['mockInputDID'],
        aggregateAlgoDID: 'mockAggAlgoDID',
        provider_session_auth_token: 'mockAuthToken',
      },
    ],
  };
  return {
    get: jest.fn().mockResolvedValue(computeJobsDetails),
  };
});

jest.mock('@oceanprotocol/lib', () => {
  return {
    ProviderInstance: {
      computeStart: jest.fn().mockResolvedValue([{ jobId: 'mockJobId' }]),
      getComputeEnvironments: jest.fn().mockResolvedValue({
        1: [{ id: 'mockComputeEnvId' }],
      }),
    },
  };
});

jest.mock('../asset-manager/start-multiple-compute', () => ({
  prepareResultURLsForAggregateAlgo: jest.fn().mockResolvedValue([{ job_url: 'mockUrl', job_headers: { AuthToken: '123' } }]),
  getAssets: jest.fn().mockResolvedValue([
    {
      id: 'mockAlgoDID',
      services: [
        {
          id: 'mockServiceId',
          datatokenAddress: 'mockTokenAddress',
          timeout: 0,
        },
      ],
    },
  ]),
  fetchDummyDataset: jest.fn().mockResolvedValue({
    id: 'mockDummyDataset',
    chainId: 1,
    accessDetails:{},
    services: [
      {
        id: 'mockServiceId',
        type: 'compute',
        datatokenAddress: 'mockTokenAddress',
        timeout: 0,
        serviceEndpoint: 'mockServiceEndpoint',
      },
    ],
  }),
  getAccessDetails: jest.fn(),
  buyDatasetNew: jest.fn(),
  getComputeEnviroment: jest.fn().mockResolvedValue({id:"mockComputeEnvId"}),
}));

jest.mock('../utils/accessDetailsAndPricing', () => {
  return {
    getAccessDetails: jest.fn(),
  };
});

const mockOceanProviderUri = 'http://mock-ocean-provider';
const mockOceanAquariusUri = 'http://mock-ocean-aquarius';
const mockSmartAccount = 'mockSmartAccountAddress';

describe('aggregation', () => {
  let mockSigner;
  let consoleErrorSpy: jest.SpyInstance;
  let consoleLogSpy: jest.SpyInstance;

  beforeEach(() => {
    mockSigner = {
      getAddress: jest.fn().mockResolvedValue('mockSignerAddress'),
      getChainId: jest.fn().mockResolvedValue(1),
    };
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
  });

  afterEach(() => {
    jest.clearAllMocks();
    consoleErrorSpy.mockRestore();
    consoleLogSpy.mockRestore();
  });

  it('should successfully aggregate compute jobs', async () => {
    (getAccessDetails as jest.Mock).mockResolvedValue({});
    (buyDatasetNew as jest.Mock).mockResolvedValue({
      algoTxReceipt: 'mockAlgoTxReceipt',
      datasetTxReceipt: 'mockDatasetTxReceipt',
    });

    await aggregation(
      'mockGuid',
      mockSigner,
      config,
      mockOceanProviderUri,
      mockOceanAquariusUri,
      mockSmartAccount,
    );

    expect(mockSigner.getAddress).toHaveBeenCalled();
    expect(axios.get).toHaveBeenCalledWith(
      `${mockOceanProviderUri}/api/services/compute?consumerAddress=mockSignerAddress&guid=mockGuid&federatedCompute=true`,
    );
    expect(prepareResultURLsForAggregateAlgo).toHaveBeenCalledWith(
      expect.any(Array),
      mockSigner,
      mockOceanProviderUri,
    );
    expect(getAssets).toHaveBeenCalledWith(
      ['mockAggAlgoDID'],
      mockOceanAquariusUri,
    );
    expect(fetchDummyDataset).toHaveBeenCalledWith(
      'mockAggAlgoDID',
      1,
      mockOceanAquariusUri,
    );
    expect(getAccessDetails).toHaveBeenCalledTimes(2);
    expect(buyDatasetNew).toHaveBeenCalledWith(
      mockDummyDatasetDetails,
      getAggAlgoAssetsArr[0],
      'mockGuid',
      mockSigner,
      config,
      '',
      '',
      mockSmartAccount,
    );

    expect(ProviderInstance.computeStart).toHaveBeenCalledWith(
      'mockServiceEndpoint',
      mockSigner,
      'mockComputeEnvId',
      computeAssetDetails,
      computeAlgorithm,
      undefined,
      [],
      {
        publishAlgorithmLog: true,
        publishOutput: true,
      },
    );
  });

  it('should handle empty resultURLData', async () => {
    (prepareResultURLsForAggregateAlgo as jest.Mock).mockResolvedValue(undefined);

    await aggregation(
      'mockGuid',
      mockSigner,
      config,
      mockOceanProviderUri,
      mockOceanAquariusUri,
      mockSmartAccount,
    );

    expect(consoleLogSpy).toHaveBeenCalledTimes(1);
    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error occured in resultURLData',
    );
  });
});
