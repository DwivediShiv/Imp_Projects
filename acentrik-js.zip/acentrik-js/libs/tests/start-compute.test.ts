import {
  Aquarius,
  ProviderInstance,
  Config,
} from '@oceanprotocol/lib';
import { Signer } from 'ethers';
import { startCompute } from '../asset-manager/start-compute';
import { isOrderable, handleComputeOrder } from '../common/helper';
import { aquariusAlgoDetails, aquariusAssetDetails, computeEnvsDetails, config } from './constants';

jest.mock('@oceanprotocol/lib', () => ({
  Aquarius: jest.fn(),
  ProviderInstance: {
    getComputeEnvironments: jest.fn(),
    getServiceEndpoints: jest.fn(),
    getEndpointURL: jest.fn(),
    initializeCompute: jest.fn(),
    computeStart: jest.fn(),
  },
  Datatoken: jest.fn(),
}));

jest.mock('../common/helper', () => ({
  isOrderable: jest.fn(),
  handleComputeOrder: jest.fn(),
  handleAbstractWhitelistingFlow: jest.fn(),
}));

describe('startCompute', () => {
  let owner: Signer;
  let mockAquariusInstance: any;
  let consoleErrorSpy: jest.SpyInstance;
  let consoleLogSpy: jest.SpyInstance;

  beforeEach(() => {
    owner = {
      getAddress: jest.fn().mockResolvedValue('0x123'),
    } as unknown as Signer;
    mockAquariusInstance = {
      waitForAqua: jest.fn(),
    };
    (Aquarius as jest.Mock).mockImplementation(() => mockAquariusInstance);
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
  });

  afterEach(() => {
    jest.clearAllMocks();
    consoleErrorSpy.mockRestore();
    consoleLogSpy.mockRestore();
  });

  it('should log an error if dataDdo is not found', async () => {
    mockAquariusInstance.waitForAqua.mockResolvedValue(null);

    await startCompute(
      'datasetDID123',
      'algoDID123',
      owner,
      '1',
      config,
      'http://aquarius.uri',
      '',
      '',
      'mockSmartAccount'
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error fetching DDO datasetDID123.  Does this asset exists?',
    );
  });

  it('should log an error if algoDdo is not found', async () => {
    mockAquariusInstance.waitForAqua
      .mockResolvedValueOnce(aquariusAssetDetails)
      .mockResolvedValueOnce(null);

    await startCompute(
      'datasetDID123',
      'algoDID123',
      owner,
      '1',
      config,
      'http://aquarius.uri',
      '',
      '',
      'mockSmartAccount'
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error fetching DDO algoDID123.  Does this asset exists?',
    );
  });

  it('should handle missing computeEnv', async () => {
    mockAquariusInstance.waitForAqua
      .mockResolvedValueOnce(aquariusAssetDetails)
      .mockResolvedValueOnce(aquariusAlgoDetails);

    (ProviderInstance.getComputeEnvironments as jest.Mock).mockResolvedValue(
      [],
    );

    await startCompute(
      'datasetDID123',
      'algoDID123',
      owner,
      '1',
      config,
      'http://aquarius.uri',
      '',
      '',
      'mockSmartAccount'
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error getting compute environments!',
    );
  });

  it('should handle non-orderable assets', async () => {
    mockAquariusInstance.waitForAqua
      .mockResolvedValueOnce(aquariusAssetDetails)
      .mockResolvedValueOnce(aquariusAlgoDetails);

    (ProviderInstance.getComputeEnvironments as jest.Mock).mockResolvedValue(computeEnvsDetails);
    (ProviderInstance.getServiceEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getEndpointURL as jest.Mock).mockReturnValue({
      urlPath: 'http://endpoint.url',
    });

    (isOrderable as jest.Mock).mockReturnValue(false);

    await startCompute(
      'datasetDID123',
      'algoDID123',
      owner,
      '1',
      config,
      'http://aquarius.uri',
      '',
      '',
      'mockSmartAccount'
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error Cannot start compute job using the dataset DID & algorithm DID provided',
    );
  });

  it('should handle provider initialization errors', async () => {
    mockAquariusInstance.waitForAqua
      .mockResolvedValueOnce(aquariusAssetDetails)
      .mockResolvedValueOnce(aquariusAlgoDetails);

    (ProviderInstance.getComputeEnvironments as jest.Mock).mockResolvedValue(computeEnvsDetails);
    (ProviderInstance.getServiceEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getEndpointURL as jest.Mock).mockReturnValue({
      urlPath: 'http://endpoint.url',
    });

    (isOrderable as jest.Mock).mockReturnValue(true);

    (ProviderInstance.initializeCompute as jest.Mock).mockResolvedValue({
      algorithm: { error: 'Some error' },
    });

    await startCompute(
      'datasetDID123',
      'algoDID123',
      owner,
      '1',
      config,
      'http://aquarius.uri',
      '',
      '',
      'mockSmartAccount'
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error initializing Provider for the compute job using dataset DID datasetDID123 and algorithm DID algoDID123',
    );
  });

  it('should return jobId on successful compute start', async () => {
    mockAquariusInstance.waitForAqua
      .mockResolvedValueOnce(aquariusAssetDetails)
      .mockResolvedValueOnce(aquariusAlgoDetails);

    (ProviderInstance.getComputeEnvironments as jest.Mock).mockResolvedValue(computeEnvsDetails);
    (ProviderInstance.getServiceEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getEndpointURL as jest.Mock).mockReturnValue({
      urlPath: 'http://endpoint.url',
    });

    (isOrderable as jest.Mock).mockReturnValue(true);

    (ProviderInstance.initializeCompute as jest.Mock).mockResolvedValue({
      algorithm: { providerFee: '0', transferTxId: '0xAlgoTransferTxId' },
      datasets: [{ providerFee: '0', transferTxId: '0xDatasetTransferTxId' }],
    });

    (handleComputeOrder as jest.Mock)
      .mockResolvedValueOnce('0xAlgoTransferTxId')
      .mockResolvedValueOnce('0xDatasetTransferTxId');

    (ProviderInstance.computeStart as jest.Mock).mockResolvedValue([
      { jobId: '0xJobId' },
    ]);

    const jobId = await startCompute(
      'datasetDID123',
      'algoDID123',
      owner,
      '1',
      config,
      'http://aquarius.uri',
      '',
      '',
      'mockSmartAccount'
    );

    expect(jobId).toBe('0xJobId');
  });
});
