import { Aquarius, ProviderInstance } from '@oceanprotocol/lib';
import { Signer } from 'ethers';
import { customComputeStatus } from '../asset-manager/get-job-status';
import util from 'util';

jest.mock('@oceanprotocol/lib', () => ({
  Aquarius: jest.fn(),
  ProviderInstance: {
    getEndpoints: jest.fn(),
    getServiceEndpoints: jest.fn(),
    getEndpointURL: jest.fn(),
  },
}));

global.fetch = jest.fn();

function setMockAssetValues(value) {
  (Aquarius as jest.Mock).mockImplementation(() => ({
    waitForAqua: jest.fn().mockResolvedValue(value),
  }));
}

describe('getJobStatus', () => {
  let owner: Signer;
  let consoleErrorSpy: jest.SpyInstance;
  let consoleLogSpy: jest.SpyInstance;

  beforeEach(() => {
    owner = {
      getAddress: jest.fn().mockResolvedValue('0x123'),
    } as unknown as Signer;
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
  });

  afterEach(() => {
    jest.clearAllMocks();
    consoleErrorSpy.mockRestore();
    consoleLogSpy.mockRestore();
  });

  it('should log an error if dataDdo is not found', async () => {
    setMockAssetValues(null);

    await customComputeStatus(
      'datasetDID123',
      'jobID123',
      owner,
      'http://aquarius.uri',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error fetching DDO datasetDID123.  Does this asset exists?',
    );
  });

  it('should handle missing endpointURL', async () => {
    setMockAssetValues({
      services: [{ serviceEndpoint: 'http://provider.uri' }],
    });

    (ProviderInstance.getEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getServiceEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getEndpointURL as jest.Mock).mockReturnValue(null);

    await customComputeStatus(
      'datasetDID123',
      'jobID123',
      owner,
      'http://aquarius.uri',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error while fetching the job status: ',
      new Error('Asset endpoint url not found!'),
    );
  });

  it('should handle fetch errors', async () => {
    setMockAssetValues({
      services: [{ serviceEndpoint: 'http://provider.uri' }],
    });

    (ProviderInstance.getEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getServiceEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getEndpointURL as jest.Mock).mockReturnValue({
      urlPath: 'http://endpoint.url',
    });

    (fetch as jest.Mock).mockRejectedValue(new Error('Fetch error'));

    await customComputeStatus(
      'datasetDID123',
      'jobID123',
      owner,
      'http://aquarius.uri',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith(
      'Error while fetching the job status: ',
      new Error('Fetch error'),
    );
  });

  it('should log error response when fetch is not ok', async () => {
    setMockAssetValues({
      services: [{ serviceEndpoint: 'http://provider.uri' }],
    });

    (ProviderInstance.getEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getServiceEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getEndpointURL as jest.Mock).mockReturnValue({
      urlPath: 'http://endpoint.url',
    });

    const mockErrorResponse = { error: 'Some error' };
    (fetch as jest.Mock).mockResolvedValue({
      ok: false,
      json: jest.fn().mockResolvedValue(mockErrorResponse),
    });

    await customComputeStatus(
      'datasetDID123',
      'jobID123',
      owner,
      'http://aquarius.uri',
      'mockSmartAccountAddress',
    );

    expect(consoleErrorSpy).toHaveBeenCalledWith('error=', mockErrorResponse);
  });

  it('should log job status result when fetch is successful', async () => {
    setMockAssetValues({
      services: [{ serviceEndpoint: 'http://provider.uri' }],
    });

    (ProviderInstance.getEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getServiceEndpoints as jest.Mock).mockResolvedValue({});
    (ProviderInstance.getEndpointURL as jest.Mock).mockReturnValue({
      urlPath: 'http://endpoint.url',
    });

    const jobStatusDetails = [{ status: 'Job status data' }];
    (fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue(jobStatusDetails),
    });

    await customComputeStatus(
      'datasetDID123',
      'jobID123',
      owner,
      'http://aquarius.uri',
      'mockSmartAccountAddress',
    );

    const result = util.inspect(jobStatusDetails[0], false, null, true);
    expect(consoleLogSpy).toHaveBeenCalledWith('Job Status Result: ', result);
  });
});
