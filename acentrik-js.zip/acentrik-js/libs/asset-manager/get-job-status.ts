import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
  ComputeJob,
} from '@oceanprotocol/lib';
import util from 'util';
import { Signer } from 'ethers';
import { JSON_CONTENT_TYPE, formatDIDAsHex, objectToQueryString } from '../utils/compute';

export async function customComputeStatus(
  datasetDID: string,
  jobId: string,
  owner: Signer,
  oceanAquariusUri: string,
  smartAccountId: string,
  guid?: string,
  isFederatedCompute = false
) {
  const aquarius = new Aquarius(oceanAquariusUri);
  const dataDdo = await aquarius.waitForAqua(datasetDID);
  try {
    if (!dataDdo) {
      console.error(
        'Error fetching DDO ' + datasetDID + '.  Does this asset exists?',
      );
      return;
    }

    const providerUri = dataDdo.services[0].serviceEndpoint;
    const endpoints = await ProviderInstance.getEndpoints(providerUri)
    const serviceEndpoints = await ProviderInstance.getServiceEndpoints(
      providerUri,
      endpoints
    )
    const endpointURL = ProviderInstance.getEndpointURL(
      serviceEndpoints,
      'computeStatus'
    )
    if(!endpointURL) {
      throw new  Error("Asset endpoint url not found!")
    }
    const consumerAddress = await owner.getAddress()
    
    const queryString = objectToQueryString(
      consumerAddress,
      jobId,
      isFederatedCompute,
      smartAccountId,
      datasetDID ? formatDIDAsHex(datasetDID) : undefined,
      guid
    )

      const response = await fetch(`${endpointURL.urlPath + queryString}`, {
        method: 'GET',
        headers: {
          'Content-Type': JSON_CONTENT_TYPE
        }
      })

      if (response != null && response.ok) {
        const results = await response.json()
        const result = util.inspect(results[0], false, null, true);
        console.log('Job Status Result: ', result);
      } else {
        const errorData = await response.json()
        console.error('error=', errorData)
      }
  } catch (e) {
    console.error('Error while fetching the job status: ', e);
  }
}
