import { Aquarius } from '@oceanprotocol/lib';

export async function getDdo(datasetDID: string, oceanAquariusUri: string): Promise<any> {
  const aquarius = new Aquarius(oceanAquariusUri);
  const resolvedDDO = await aquarius.waitForAqua(datasetDID);

  if (!resolvedDDO) {
    console.error(
      'Error fetching Asset with DID: ' +
        datasetDID +
        '.  Does this asset exists?',
    );
  } else {
    console.log('DDO: ', JSON.stringify(resolvedDDO));
    return null;
  }
}
