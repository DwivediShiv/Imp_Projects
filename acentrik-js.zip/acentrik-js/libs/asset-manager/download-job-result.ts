import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
} from '@oceanprotocol/lib';
import { Signer } from 'ethers';

export async function downloadJobResult(
  jobID: string,
  resultIndex: string,
  assetID: string,
  destinationFolderPath: string,
  owner: Signer,
  isBrowser: boolean,
  oceanProviderUri: string,
  oceanAquariusUri: string,
) {
  try {
    const aquarius = new Aquarius(oceanAquariusUri);
    const dataDdo = await aquarius.waitForAqua(assetID);

    if (!dataDdo) {
      console.error(
        'Error fetching DDO ' + assetID + '.  Does this asset exists?',
      );
      return;
    }

    const providerUri = dataDdo.services[0].serviceEndpoint;
    const jobResult = await ProviderInstance.getComputeResultUrl(
      providerUri,
      owner,
      jobID,
      parseInt(resultIndex),
    );
    return jobResult;
  } catch (e) {
    console.error('Error while downloading the job result: ', e);
  }
}
