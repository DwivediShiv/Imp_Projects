import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
  ComputeAsset,
  ComputeAlgorithm,
  Asset,
  DDO,
  Service,
  ComputeEnvironment,
  LoggerInstance,
  ProviderComputeInitializeResults,
  ComputeJob,
  ComputeOutput,
  ProviderFees,
  Config,
  ConfigHelper,
} from '@oceanprotocol/lib';

import {
  isOrderable,
  handleComputeOrder,
  handleAbstractWhitelistingFlow,
} from '../common/helper';
import { maxBy, cloneDeep } from 'lodash';
import axios, { CancelToken } from 'axios';

import { v4 as guidv4 } from 'uuid';
import { Signer } from 'ethers';
import { getAccessDetails, getAccessDetailsForAssets } from '../utils/accessDetailsAndPricing';

interface TokenInfo {
  address: string;
  name: string;
  symbol: string;
  decimals?: number;
}

interface AccessDetails {
  type:
    | 'fixed'
    | 'Premium'
    | 'premium'
    | 'free'
    | 'Free'
    | 'NOT_SUPPORTED'
    | 'Post-pay'
    | 'post-pay'
    | '';
  price: string;
  templateId: number;
  addressOrId: string;
  baseToken: TokenInfo;
  datatoken: TokenInfo;
  isPurchasable?: boolean;
  isOwned: boolean;
  validOrderTx: string;
  publisherMarketOrderFee: string;
  providerFee?: ProviderFees;
  validProviderFees?: ProviderFees;
  providerData?: ProviderData;
}

interface ProviderData {
  environment?: string;
  timestamp?: number;
  timeout?: number;
}

export interface AssetExtended extends Asset {
  accessDetails?: AccessDetails;
}

let validOrderTx = {};
export async function startMultipleCompute(
  datasetDIDs: string[],
  algorithmDIDs: string[],
  federatedAlgorithmDID: string,
  owner: Signer,
  oceanAquariusUri: string,
  config: Config,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string,
) {
  const aquarius_local = new Aquarius(oceanAquariusUri);
  const datasets = await getAssets(datasetDIDs, oceanAquariusUri);
  const algorithms = await getAssets(algorithmDIDs, oceanAquariusUri);
  const federatedAlgorithm = (await aquarius_local.waitForAqua(
    federatedAlgorithmDID,
  )) as AssetExtended;

  const batchGuid = guidv4(); // Use a more descriptive name

  const datasetsWithPrice = await getAccessDetailsForAssets(
    datasets,
    accountAddr || (await owner.getAddress()),
    config
  );
  federatedAlgorithm.accessDetails = await getAccessDetails(
    federatedAlgorithm?.services[0].datatokenAddress,
    config,
    federatedAlgorithm?.services[0].timeout,
    accountAddr || (await owner.getAddress()),
  );

  const res = await buyAndStartComputeOnMultipleDatasets(
    datasetsWithPrice,
    federatedAlgorithm,
    algorithms[0].id, // Assumed aggregate algorithm
    batchGuid,
    owner,
    oceanAquariusUri,
    biconomyDashboardAuthToken,
    smartAccountPaymasterKey,
    accountAddr,
  );

  console.log('Compute jobs started: Here is your guid -> ', batchGuid);
  console.log('Here is the jobId', res);
}

export function convertToExpiryTimestamp(timeInSeconds: number) {
  const currentDate = new Date();
  const expiryDate = new Date(currentDate.getTime() + timeInSeconds * 1000); // Convert seconds to milliseconds
  return Math.floor(expiryDate.getTime() / 1000); // Return epoch timestamp
}

export function getProviderNonceUrl(
  providerUri: string,
  address: string,
): string {
  if (providerUri.endsWith('/')) {
    return `${providerUri.slice(
      0,
      -1,
    )}/api/services/nonce?userAddress=${address}`;
  } else {
    return `${providerUri}/api/services/nonce?userAddress=${address}`;
  }
}
export function getProviderAuthTokenUrl(providerUri: string): string {
  if (providerUri.endsWith('/')) {
    return `${providerUri.slice(0, -1)}/api/services/createAuthToken`;
  } else {
    return `${providerUri}/api/services/createAuthToken`;
  }
}

export function getComputeStartUrl(providerUri: string): string {
  if (providerUri.endsWith('/')) {
    return `${providerUri.slice(0, -1)}/api/services/compute`;
  } else {
    return `${providerUri}/api/services/compute`;
  }
}

export async function getAuthToken(
  signer: Signer,
  providerUri: string,
  address: string,
  expirationTimeStamp: number,
) {
  const nonceResponse = await axios.get(
    getProviderNonceUrl(providerUri, address),
  );
  const nonce = nonceResponse.data.nonce ? nonceResponse.data.nonce + 1 : 1;

  const signature = await ProviderInstance.signProviderRequest(
    signer,
    address + nonce,
  );

  if (!expirationTimeStamp) {
    expirationTimeStamp = convertToExpiryTimestamp(86400);
  }

  const response = await axios.get(
    `${getProviderAuthTokenUrl(
      providerUri,
    )}?address=${address}&nonce=${nonce}&expiration=${expirationTimeStamp}&signature=${signature}`,
  );

  return response.data.token;
}

export async function buyDataset(
  dataset: AssetExtended,
  algorithm: AssetExtended,
  aggregateAlgoDID: string,
  uniqueC2dBatchGuid: string,
  owner: Signer,
  oceanAquariusUri: string,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string,
) {
  const computeEnv = await getComputeEnviroment(dataset);
  const computeService = getServiceByName(dataset, 'compute');
  const chainId = await owner.getChainId();
  const config = new ConfigHelper().getConfig(chainId);
  const datatoken = new Datatoken(owner, chainId);
  console.log('algo', algorithm);

  const minValue = Math.min(
    computeEnv?.maxJobDuration,
    dataset.services[0].timeout,
    algorithm.services[0].timeout,
  );
  const computeMinutes = minValue / 60;
  const mytime = new Date();
  mytime.setMinutes(mytime.getMinutes() + computeMinutes);
  const computeValidUntil = Math.floor(mytime.getTime() / 1000);

  const computeAlgorithm: ComputeAlgorithm = {
    documentId: algorithm.id,
    serviceId: algorithm.services[0].id,
    userdata: {
      ...(accountAddr ? { smartAccount: accountAddr } : {}),
    },
  };

  const aggregateAlgorithmDDO = (
    await getAssets([aggregateAlgoDID], oceanAquariusUri)
  )[0];
  const expiry = convertToExpiryTimestamp(
    aggregateAlgorithmDDO?.services[0]?.timeout,
  );
  const asset: ComputeAsset = {
    documentId: dataset.id,
    serviceId: dataset.services[0].id,
    userdata: {
      serviceEndpoint: dataset.services[0].serviceEndpoint,
      guid: uniqueC2dBatchGuid,
      aggregateAlgorithmId: aggregateAlgoDID,
      ...(accountAddr ? { smartAccount: accountAddr } : {}),
      providerAuthToken:
        (await getAuthToken(
          owner,
          dataset.services[0].serviceEndpoint,
          await owner.getAddress(),
          expiry,
        )) || '-',
    },
  };

  const allowed = isOrderable(
    dataset,
    computeService.id,
    computeAlgorithm,
    algorithm,
  );
  if (accountAddr && biconomyDashboardAuthToken && smartAccountPaymasterKey) {
    await handleAbstractWhitelistingFlow(
      algorithm.nft.address,
      algorithm.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
    await handleAbstractWhitelistingFlow(
      dataset.nft.address,
      dataset.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
  }

  LoggerInstance.log('[compute] Is data set orderable?', allowed);
  if (!allowed) {
    LoggerInstance.error(
      '[compute] Error starting compute job. Dataset is not orderable in combination with selected algorithm.',
    );
    return;
  }

  console.log(
    'Starting compute job using provider: ',
    dataset.services[0].serviceEndpoint,
  );
  const providerInitializeComputeJob = await ProviderInstance.initializeCompute(
    [asset],
    computeAlgorithm,
    computeEnv.id,
    computeValidUntil,
    dataset.services[0].serviceEndpoint,
    await owner.getAddress(),
  );
  if (
    !providerInitializeComputeJob ||
    'error' in providerInitializeComputeJob.algorithm
  ) {
    console.error(
      'Error initializing Provider for the compute job using dataset DID ' +
        dataset +
        ' and algorithm DID ' +
        algorithm,
    );
    return;
  }

  console.log('Ordering Algorithm');

  computeAlgorithm.transferTxId = await handleComputeOrder(
    providerInitializeComputeJob.algorithm,
    algorithm,
    owner,
    computeEnv.consumerAddress,
    0,
    datatoken,
    config,
    providerInitializeComputeJob?.algorithm?.providerFee,
    algorithm.services[0].serviceEndpoint,
    accountAddr,
  );
  if (!computeAlgorithm.transferTxId) {
    console.error(
      'Error ordering compute for algorithm with DID: ' +
        computeAlgorithm +
        '.  Do you have enought tokens?',
    );
    return;
  }
  console.log('Ordering dataset');
  asset.transferTxId = await handleComputeOrder(
    providerInitializeComputeJob.datasets[0],
    dataset,
    owner,
    computeEnv.consumerAddress,
    0,
    datatoken,
    config,
    providerInitializeComputeJob?.datasets[0].providerFee,
    dataset.services[0].serviceEndpoint,
    accountAddr,
  );
  if (!asset.transferTxId) {
    console.error(
      'Error ordering dataset with DID: ' +
        dataset +
        '.  Do you have enought tokens?',
    );
    return;
  }

  const output: ComputeOutput = {
    publishAlgorithmLog: true,
    publishOutput: true,
  };

  const payload = {
    consumerAddress: await owner.getAddress(),
    nonce: 1,
    environment: computeEnv?.id,
    dataset: asset,
    algorithm: computeAlgorithm,
    output,
  };

  const headers = {
    AuthToken: asset?.userdata?.providerAuthToken,
    'Content-Type': 'application/json',
  };
  const response = await axios.post(
    getComputeStartUrl(asset?.userdata?.serviceEndpoint),
    payload,
    { headers },
  );

  console.log('Compute start response', response.data);
  const { jobId } = response?.data?.[0];

  return {
    jobId: jobId,
    txnReceipt: computeAlgorithm.transferTxId,
  };
}

export async function buyDatasetNew(
  dataset: AssetExtended,
  algorithm: AssetExtended,
  Guid: string,
  owner: Signer,
  config: Config,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string,
) {
  const computeEnv = await getComputeEnviroment(dataset);
  const computeService = getServiceByName(dataset, 'compute');
  const chainId = await owner.getChainId();
  const datatoken = new Datatoken(owner, chainId);
  const minValue = Math.min(
    computeEnv?.maxJobDuration,
    dataset.services[0].timeout,
    algorithm.services[0].timeout,
  );
  const computeMinutes = Math.floor(minValue / 60);
  const mytime = new Date();
  mytime.setMinutes(mytime.getMinutes() + computeMinutes);
  const computeValidUntil = Math.floor(mytime.getTime() / 1000);

  const computeAlgorithm: ComputeAlgorithm = {
    documentId: algorithm.id,
    serviceId: algorithm.services[0].id,
    transferTxId: algorithm.accessDetails?.validOrderTx,
  };

  const asset: ComputeAsset = {
    documentId: dataset.id,
    serviceId: dataset.services[0].id,
    transferTxId: dataset.accessDetails?.validOrderTx,
  };

  const allowed = isOrderable(
    dataset,
    computeService.id,
    computeAlgorithm,
    algorithm,
  );
  if (accountAddr && biconomyDashboardAuthToken && smartAccountPaymasterKey) {
    await handleAbstractWhitelistingFlow(
      algorithm.nft.address,
      algorithm.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
    await handleAbstractWhitelistingFlow(
      dataset.nft.address,
      dataset.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
  }
  LoggerInstance.log('[compute] Is data set orderable?', allowed);
  if (!allowed) {
    LoggerInstance.error(
      '[compute] Error starting compute job. Dataset is not orderable in combination with selected algorithm.',
    );
    return;
  }

  const providerInitializeComputeJob = await ProviderInstance.initializeCompute(
    [asset],
    computeAlgorithm,
    computeEnv.id,
    computeValidUntil,
    dataset.services[0].serviceEndpoint,
    await owner.getAddress(),
  );
  if (
    !providerInitializeComputeJob ||
    'error' in providerInitializeComputeJob.algorithm
  ) {
    console.error(
      'Error initializing Provider for the compute job using dataset DID ' +
        dataset +
        ' and algorithm DID ' +
        algorithm,
    );
    return;
  }
  console.log('Ordering algorithm');
  computeAlgorithm.transferTxId = await handleComputeOrder(
    providerInitializeComputeJob.algorithm,
    algorithm,
    owner,
    computeEnv.consumerAddress,
    0,
    datatoken,
    config,
    providerInitializeComputeJob?.algorithm?.providerFee,
    algorithm.services[0].serviceEndpoint,
    accountAddr,
  );
  if (!computeAlgorithm.transferTxId) {
    console.error(
      'Error ordering compute for algorithm with DID: ' +
        computeAlgorithm +
        '.  Do you have enought tokens?',
    );
    return;
  }
  console.log('Ordering dataset');
  asset.transferTxId = await handleComputeOrder(
    providerInitializeComputeJob.datasets[0],
    dataset,
    owner,
    computeEnv.consumerAddress,
    0,
    datatoken,
    config,
    providerInitializeComputeJob?.datasets[0].providerFee,
    dataset.services[0].serviceEndpoint,
    accountAddr,
  );
  if (!asset.transferTxId) {
    console.error(
      'Error ordering dataset with DID: ' +
        dataset +
        '.  Do you have enought tokens?',
    );
    return;
  }

  return {
    algoTxReceipt: computeAlgorithm.transferTxId,
    datasetTxReceipt: asset.transferTxId,
  };
}

export async function getAssets(dids: string[], oceanAquariusUri: string) {
  const aquarius = new Aquarius(oceanAquariusUri);
  const assetsPromises = dids.map((did) => aquarius.waitForAqua(did));
  const assets = await Promise.all(assetsPromises);
  return assets;
}

export function getComputeDatasets(
  datasetList: AssetExtended[],
  smartAccountId: string,
  guid: string,
  aggregateAlgorithmId: string,
): ComputeAsset[] {
  return datasetList.map((dataset) => {
    const data: ComputeAsset = {
      documentId: dataset.id,
      serviceId: dataset.services[0].id,
      userdata: {
        serviceEndpoint: dataset.services[0].serviceEndpoint,
        guid,
        aggregateAlgorithmId,
        smartAccount: smartAccountId,
      },
    };

    // // Add smartAccount property only if smartAccountId is defined
    // if (smartAccountId !== undefined) {
    //   data.userdata.smartAccount = smartAccountId
    // }

    return data;
  });
}

export function getServiceByName(
  ddo: Asset | DDO,
  name: 'access' | 'compute' | 'metadata',
): any {
  if (!ddo) return;

  const service = ddo.services.filter((service) => service.type === name)[0];
  return service;
}

export async function getComputeEnviroment(asset: Asset): Promise<any> {
  if (asset?.services[0]?.type !== 'compute') return null;
  try {
    const computeEnvs = await ProviderInstance.getComputeEnvironments(
      asset.services[0].serviceEndpoint,
    );
    // TODO: temporary select the longest maxJobDuration
    let longestDurationEnv;
    const computeEnv = Array.isArray(computeEnvs)
      ? computeEnvs[0]
      : computeEnvs[asset.chainId][0];

    if (!computeEnv) return null;
    longestDurationEnv = maxBy(computeEnvs as [], 'maxJobDuration');
    return longestDurationEnv || computeEnv;
  } catch (e) {
    LoggerInstance.error('[compute] Fetch compute enviroment: ', e.message);
  }
}

export async function initializeProviderForCompute(
  dataset: AssetExtended,
  algorithm: AssetExtended,
  accountId: string,
  computeEnv: any = null,
): Promise<any> {
  const computeAsset: ComputeAsset = {
    documentId: dataset.id,
    serviceId: dataset.services[0].id,
    transferTxId: dataset.accessDetails?.validOrderTx,
  };
  const computeAlgo: ComputeAlgorithm = {
    documentId: algorithm.id,
    serviceId: algorithm.services[0].id,
    transferTxId: algorithm.accessDetails?.validOrderTx,
  };

  const mytime = new Date();
  const computeMinutes = 5;
  mytime.setMinutes(mytime.getMinutes() + computeMinutes);
  const validUntil = Math.floor(mytime.getTime() / 1000);

  try {
    return await ProviderInstance.initializeCompute(
      [computeAsset],
      computeAlgo,
      computeEnv?.id,
      validUntil,
      dataset.services[0].serviceEndpoint,
      accountId,
    );
  } catch (error) {
    LoggerInstance.error(`Error initializing provider for the compute job!`);
    return null;
  }
}
interface testDe {
  txnReceipt: string;
  jobId: string;
}
async function buyAndStartComputeOnMultipleDatasets(
  datasets: AssetExtended[],
  algorithm: AssetExtended,
  AggregateAlgorithmDid: string,
  guid: string,
  owner: Signer,
  oceanAquariusUri: string,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string,
): Promise<string[]> {
  const results = [];
  for (const dataset of datasets) {
    const { txnReceipt, jobId } = await buyDataset(
      dataset,
      algorithm,
      AggregateAlgorithmDid,
      guid,
      owner,
      oceanAquariusUri,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
      accountAddr,
    );
    validOrderTx[dataset.id] = txnReceipt;
    results.push(jobId);
  }
  return results;
}

// Aggregation

interface ComputeJobMetaData extends ComputeJob {
  assetName: string;
  assetDtSymbol: string;
  networkId: number;
  providerURL?: string;
  provider_session_auth_token?: string;
}

export interface UniqueJobs {
  [key: string]: {
    job: ComputeJobMetaData | any;
    dateCreated: string;
  };
}

async function getComputeJobs(
  providerURI: string,
  jobIDs: string[],
  consumerAddress: string,
) {
  let computeJobs = [];
  await Promise.all(
    jobIDs.map(async (jobId) => {
      const url = `${
        providerURI +
        'api/services/compute?consumerAddress=' +
        consumerAddress +
        '&jobId=' +
        jobId +
        '&federatedCompute=' +
        true
      }`;
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (response != null && response.ok) {
        const result = await response.json();
        result[0].providerURL = providerURI;
        computeJobs.push(result);
      } else {
        const errorData = await response.json();
      }
    }),
  );
  return computeJobs;
}

function objectToQueryString(
  consumerAddress: string,
  jobId: string,
  federatedCompute: boolean,
  guid: string,
  did: string,
  smartAccountId: string,
): string {
  let queryString = `?consumerAddress=${consumerAddress}`;

  if (did) {
    queryString += `&documentId=${did}`;
  }
  if (jobId) {
    queryString += `&jobId=${jobId}`;
  }
  if (federatedCompute) {
    queryString += `&federatedCompute=${federatedCompute}`;
  }
  if (guid) {
    queryString += `&guid=${guid}`;
  }
  if (smartAccountId) {
    queryString += `&smartAccount=${smartAccountId}`;
  }

  return queryString;
}

export function getComputeResultURLWithoutSignature(
  providerURL: string,
  jobId: string,
  address: string,
) {
  return `${providerURL}/api/services/computeResult?consumerAddress=${address}&jobId=${jobId}&index=0&nonce=1`;
}

export async function prepareResultURLsForAggregateAlgo(
  jobsToAggregate: ComputeJobMetaData[],
  signer: Signer,
  oceanProviderUri: string,
): Promise<
  { job_url: string; job_headers: { AuthToken: string } }[] | undefined
> {
  const resultData: any = [];
  for (const job of jobsToAggregate) {
    const downloadResultUrl = await ProviderInstance.getComputeResultUrl(
      job.providerURL || oceanProviderUri || '',
      signer,
      job.jobId,
      0, // fileIndex - may need to run a loop if multiple result files
    );
    const headResponse = await fetch(downloadResultUrl, { method: 'HEAD' });
    if (headResponse.status === 400) {
      console.error('File Url is unreachable');
      return;
    }
    // Remove signature param from the URL
    const urlWithoutSignature = downloadResultUrl.replace(
      /&?signature=[^&]+/,
      '',
    );

    resultData.push({
      job_url: urlWithoutSignature,
      job_headers: {
        AuthToken: job.provider_session_auth_token,
      },
    });
  }
  return resultData;
}

interface EsPaginationOptions {
  from?: number;
  size?: number;
}

interface BaseQueryParams {
  chainIds: number[];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  nestedQuery?: any;
  esPaginationOptions?: EsPaginationOptions;
  sortOptions?: SortOptions;
  aggs?: any;
  filters?: FilterTerm[];
  ignorePurgatory?: boolean;
  ignoreState?: boolean;
}
interface FilterTerm {
  [property: string]: {
    [property: string]: string | number | boolean | number[] | string[];
  };
}
interface SortOptions {
  sortBy: SortTermOptions;
  sortDirection?: SortDirectionOptions;
}

export enum SortTermOptions {
  Created = 'metadata.created', // or nft.created
  Relevance = '_score',
  Orders = 'stats.orders',
  Allocated = 'stats.allocated',
  Price = 'stats.price.value',
}
export enum SortDirectionOptions {
  Ascending = 'asc',
  Descending = 'desc',
}
// Fetch dummy dataset for aggregate algorithm
export async function fetchDummyDataset(
  aggregateAlgorithmDid: string,
  chainId: number,
  oceanAquariusUri: string,
) {
  const baseQueryParams = {
    chainIds: [chainId],
    nestedQuery: {
      must: {
        match_phrase: {
          'services.compute.publisherTrustedAlgorithms.did': {
            query: aggregateAlgorithmDid,
          },
        },
      },
    },
  } as BaseQueryParams;

  const query = generateBaseQuery(baseQueryParams);
  const dummyDatasets = await queryMetadata(query, oceanAquariusUri);
  return dummyDatasets?.results[0];
}

interface SearchQuery {
  from?: number;
  size?: number;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  query: any;
  sort?: { [jsonPath: string]: SortDirectionOptions };
  aggs?: any;
}

export function getFilterTerm(
  filterField: string,
  value: string | number | boolean | number[] | string[],
): FilterTerm {
  if (!filterField) return;
  const isArray = Array.isArray(value);
  return {
    [isArray ? 'terms' : 'term']: {
      [filterField]: value,
    },
  };
}

export function generateBaseQuery(
  baseQueryParams: BaseQueryParams,
  includeDelist = false,
): SearchQuery {
  const assetStates = cloneDeep([0, 4]);
  if (includeDelist) assetStates.push(1);

  const generatedQuery = {
    from: baseQueryParams.esPaginationOptions?.from || 0,
    size: baseQueryParams.esPaginationOptions?.size || 1000,
    query: {
      bool: {
        ...baseQueryParams.nestedQuery,
        filter: [
          ...(baseQueryParams.filters || []),
          getFilterTerm('chainId', baseQueryParams.chainIds),
          getFilterTerm('nft.state', assetStates),
          // getFilterTerm('_index', 'aquarius'),
          ...(baseQueryParams.ignorePurgatory
            ? []
            : [getFilterTerm('purgatory.state', false)]),
        ],
      },
    },
  } as SearchQuery;

  if (baseQueryParams.aggs !== undefined) {
    generatedQuery.aggs = baseQueryParams.aggs;
  }

  if (baseQueryParams.sortOptions !== undefined)
    generatedQuery.sort = {
      [baseQueryParams.sortOptions.sortBy]:
        baseQueryParams.sortOptions.sortDirection ||
        SortDirectionOptions.Descending,
    };

  return generatedQuery;
}

interface PagedAssets {
  results: Asset[];
  page: number;
  totalPages: number;
  totalResults: number | any;
  aggregations: any;
}

interface Explanation {
  value: number;
  description: string;
  details: Explanation[];
}

interface ShardsResponse {
  total: number;
  successful: number;
  failed: number;
  skipped: number;
}

interface SearchResponse {
  took: number;
  timed_out: boolean;
  _scroll_id?: string | undefined;
  _shards: ShardsResponse;
  hits: {
    total: {
      relation: string;
      value: number;
    };
    max_score: number;
    hits: Array<{
      _index: string;
      _type: string;
      _id: string;
      _score: number;
      _source: Asset;
      _version?: number | undefined;
      _explanation?: Explanation | undefined;
      fields?: any;
      highlight?: any;
      inner_hits?: any;
      matched_queries?: string[] | undefined;
      sort?: string[] | undefined;
    }>;
  };
  aggregations?: any;
}

export function transformQueryResult(
  queryResult: SearchResponse,
  from = 0,
  size = 21,
): PagedAssets | undefined {
  if (
    !queryResult ||
    !queryResult?.hits ||
    from < 0 ||
    size < 0 ||
    from % 1 !== 0 ||
    size % 1 !== 0
  )
    return;

  const result: PagedAssets = {
    results: [],
    page: 0,
    totalPages: 0,
    totalResults: 0,
    aggregations: [],
  };

  result.results = (queryResult.hits.hits || []).map(
    (hit) => hit._source as Asset,
  );

  result.aggregations = queryResult.aggregations;
  result.totalResults = queryResult.hits.total?.value || queryResult.hits.total;
  result.totalPages =
    result.totalResults / size < 1
      ? Math.floor(result.totalResults / size)
      : Math.ceil(result.totalResults / size);
  result.page = from ? from / size + 1 : 1;

  return result;
}

export async function queryMetadata(
  query: SearchQuery,
  oceanAquariusUri: string,
): Promise<PagedAssets | undefined> {
  try {
    if (!query) throw new Error('Invalid query');

    const fancyData = Object.assign({}, query);
    fancyData.size = fancyData?.size || 500;
    const response = await axios.post(
      `${oceanAquariusUri}/api/aquarius/assets/query`,
      fancyData,
    );
    if (!response || response.status !== 200 || !response.data) return;
    return transformQueryResult(
      response.data,
      query.from || 0,
      fancyData.size || 12,
    );
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message);
    } else {
      LoggerInstance.error(error.message);
    }
  }
}

// access detail
interface AccessDetails {
  type:
    | 'fixed'
    | 'Premium'
    | 'premium'
    | 'free'
    | 'Free'
    | 'NOT_SUPPORTED'
    | 'Post-pay'
    | 'post-pay'
    | '';
  price: string;
  templateId: number;
  addressOrId: string;
  baseToken: TokenInfo;
  datatoken: TokenInfo;
  isPurchasable?: boolean;
  isOwned: boolean;
  validOrderTx: string;
  publisherMarketOrderFee: string;
  providerFee?: ProviderFees;
  validProviderFees?: ProviderFees;
  providerData?: ProviderData;
}
