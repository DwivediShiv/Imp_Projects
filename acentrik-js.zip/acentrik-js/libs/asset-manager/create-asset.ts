import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  ProviderInstance,
  Nft,
  Config,
  ValidateMetadata,
  MetadataAndTokenURI,
  getHash,
  NftFactory,
} from '@oceanprotocol/lib';
import { createHash } from 'crypto';
import { isEmpty } from 'lodash';

// import { accountAbstractionProviders } from '../common';
import { createNft } from '../common/providers/nft';
import { ethers, Signer } from 'ethers';
import { SHA256 } from 'crypto-js';
import assert from 'assert';
import { handleAbstractWhitelistingFlow } from '../common/helper';
import { hexlify } from 'ethers/lib/utils';
import { FileEncrypt, FileEncryptRequestData } from '../common/constants';
// import { AccountAbstractionProviders} from '../cli';
// import { NonAccountAbstractionProviders } from '../common';

export interface CreateAssetOptions {
  nftCreateData: NftCreateData;
  datatokenCreateParams: DatatokenCreateParams;
  dispenserCreationParams: DispenserCreationParams;
  extraData: any;
}

export interface CreateAssetOptionspaid {
  nftCreateData: NftCreateData;
  datatokenCreateParams: DatatokenCreateParams;
  freCreationParams: FreCreationParams;
  extraData: any;
}

// export interface CreateAssetResponse {
//   nftAddress: string;
//   datatokenAddress: string;
// }
// async function getNftAndDataTokenAddress(result: any, assetUrl: any, ddo: any) {
//   const trxReceipt = await result.wait();

//   const nftCreatedEvent = getEventFromTx(trxReceipt, 'NFTCreated');
//   const tokenCreatedEvent = getEventFromTx(trxReceipt, 'TokenCreated');

//   const nftAddress = nftCreatedEvent.args.newTokenAddress;
//   const datatokenAddress = tokenCreatedEvent.args.newTokenAddress;
//   await handleAbstractWhitelistingFlow(nftAddress, datatokenAddress);

//   await setMetadataDispenser(nftAddress, datatokenAddress, ddo);

//   return {
//     nftAddress,
//     datatokenAddress,
//   };
// }

// export async function createFreeAsset1(
//   options: CreateAssetOptions,
// ): Promise<any> {
//   const result = await accountAbstractionProviders.nftFactory.createNftWithDatatokenWithDispenser(
//     options.nftCreateData,
//     options.datatokenCreateParams,
//     options.dispenserCreationParams,
//   );

//   return getNftAndDataTokenAddress(
//     result,
//     options.extraData.services[0].files,
//     options.extraData,
//   );
//   // return getNftAndDataTokenAddress(result);
//   // const trxReceipt = await result.wait();
//   // const nftCreatedEvent = getEventFromTx(trxReceipt, 'NFTCreated');
//   // const tokenCreatedEvent = getEventFromTx(trxReceipt, 'TokenCreated');
//   // const nftAddress = nftCreatedEvent.args.newTokenAddress;
//   // const datatokenAddress = tokenCreatedEvent.args.newTokenAddress;
//   // return {
//   //   nftAddress,
//   //   datatokenAddress,
//   // };
// }

// export async function createPaidAsset1(
//   options: CreateAssetOptionspaid,
// ): Promise<CreateAssetResponse> {
//   const result =
//     await accountAbstractionProviders.nftFactory.createNftWithDatatokenWithFixedRate(
//       options.nftCreateData,
//       options.datatokenCreateParams,
//       options.freCreationParams,
//     );
//   return getNftAndDataTokenAddress(
//     result,
//     options.extraData.services[0].files,
//     options.extraData,
//   );

// }

// export async function setMetadataDispenser(
//   nftAddress: string,
//   datatokenAddress: string,
//   ddo: any,
// ) {
//   let signerObj = {
//     signer: accountAbstractionProviders.signer,
//     chainId: accountAbstractionProviders.chainId,
//   };
//   const nft = createNft(signerObj);
//   ddo.chainId = accountAbstractionProviders.chainId;
//   ddo.id =
//     'did:op:' +
//     SHA256(ethers.utils.getAddress(nftAddress) + ddo.chainId.toString(10));
//   ddo.services[0].datatokenAddress = datatokenAddress;
//   ddo.services[0].serviceEndpoint = process.env.OCEAN_PROVIDER_URL;
//   ddo.nftAddress = nftAddress;
//   ddo.services[0].files.datatokenAddress = datatokenAddress;
//   ddo.services[0].files.nftAddress = nftAddress;
//   ddo.nftAddress = nftAddress;
//   ddo.services[0].files = await ProviderInstance.encrypt(
//     ddo.services[0].files,
//     ddo.chainId,
//     process.env.OCEAN_PROVIDER_URL,
//   );
//   const encryptedDDO = await ProviderInstance.encrypt(
//     ddo,
//     ddo.chainId,
//     process.env.OCEAN_PROVIDER_URL,
//   );

//   let Aq = new Aquarius(
//     process.env.OCEAN_AQUARIUS_URL || this.config.metadataCacheUri,
//   );

//   const isAssetValid: ValidateMetadata = await Aq.validate(ddo);
//   assert(isAssetValid.valid === true, 'Published asset is not valid');

//   const flags = ethers.utils.hexlify(2);
//   const metadataHash = getHash(JSON.stringify(ddo));
//   const tokenUriPrefix = 'data:application/json;base64,';
//   interface NftMetadata {
//     name: string;
//     symbol: string;
//     description: string;
//     image?: string;
//     /* eslint-disable camelcase */
//     external_url?: string;
//     image_data?: string;
//     background_color?: string;
//     /* eslint-enable camelcase */
//   }
//   const encodedMeta: NftMetadata = {
//     name: 'acentriktest',
//     symbol: 'AT',
//     description: 'test for acentrik',
//   };

//   const encodedMetadata = Buffer.from(
//     JSON.stringify({
//       ...encodedMeta,
//       description: `${encodedMeta.description}`,
//     }),
//   ).toString('base64');
//   const metadataAndTokenURI: MetadataAndTokenURI = {
//     metaDataState: 0,
//     metaDataDecryptorUrl: ddo.services[0].serviceEndpoint,
//     metaDataDecryptorAddress: '',
//     flags,
//     data: encryptedDDO,
//     metaDataHash: '0x' + metadataHash,
//     tokenId: 1,
//     tokenURI: `${tokenUriPrefix}${encodedMetadata}`,
//     metadataProofs: [],
//   };

//   await nft.setMetadataAndTokenURI(
//     nftAddress,
//     process.env.SMART_ACCOUNT_ADDRESS,
//     metadataAndTokenURI,
//   );
// }

export function getFileEncryptRequestData(
  files: any,
  nftAddress: string,
  datatokenAddress: string,
) {
  const fileEncrypt: FileEncrypt = {
    type: files?.[0]?.type,
    url: files?.length && files?.[0]?.url,
    method: files?.[0]?.method,
  };

  if (files?.[0]?.headers && !isEmpty(files?.[0]?.headers)) {
    fileEncrypt.headers = Object.assign(
      {},
      ...files?.[0]?.headers?.map((x) => ({ [x.key]: x.value })),
    );
  }

  const fileEncryptRequestData: FileEncryptRequestData = {
    nftAddress,
    datatokenAddress,
    files: [fileEncrypt],
  };

  return fileEncryptRequestData;
}

export async function publishAsset(
  name: string,
  symbol: string,
  owner: Signer,
  assetFiles: any,
  ddo: any,
  providerUrl: string,
  config: Config,
  aquariusInstance: Aquarius,
  encryptDDO: boolean = true,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  macOsProviderUrl?: string,
  smartAccount?: string,
  paymentCollector?: string,
  fileServiceEndpoint?: string,
) {
  const eoaAddress = await owner.getAddress();
  const chainId = await owner.getChainId();
  const nft = new Nft(owner, chainId);

  const nftFactory = new NftFactory(
    config.nftFactoryAddress,
    owner,
    chainId,
    config,
  );
  const nftParamsAsset: NftCreateData = {
    name,
    symbol,
    templateIndex: 1,
    tokenURI: '',
    transferable: true,
    owner: smartAccount || eoaAddress,
  };

  const datatokenParams: DatatokenCreateParams = {
    templateIndex: 2,
    cap: '100000',
    feeAmount: '0',
    paymentCollector: paymentCollector || smartAccount || eoaAddress,
    feeToken: config.oceanTokenAddress,
    minter: smartAccount || eoaAddress,
    mpFeeAddress: '0x903322C7E45A60d7c8C3EA236c5beA9Af86310c7',
    symbol: 'STRPUF-30',
  };
  let bundleNFT;
  if (!ddo.stats.price.value) {
    console.log('awaiting creation of nft and datatoken...');
    bundleNFT = await nftFactory.createNftWithDatatoken(
      nftParamsAsset,
      datatokenParams,
    );
    console.log('nft and datatoken created successfully...');
  } else if (ddo.stats.price.value === '0') {
    const dispenserParams: DispenserCreationParams = {
      dispenserAddress: config.dispenserAddress,
      maxTokens: '1000000000000000000',
      maxBalance: '1000000000000000000',
      withMint: true,
      allowedSwapper: '0x0000000000000000000000000000000000000000',
    };
    console.log('awaiting creation of nft and datatoken...');
    bundleNFT = await nftFactory.createNftWithDatatokenWithDispenser(
      nftParamsAsset,
      datatokenParams,
      dispenserParams,
    );
    console.log('nft and datatoken created successfully...');
  } else {
    const fixedPriceParams: FreCreationParams = {
      fixedRateAddress: config.fixedRateExchangeAddress,
      baseTokenAddress: config.oceanTokenAddress,
      owner: smartAccount || eoaAddress,
      marketFeeCollector: smartAccount || eoaAddress,
      baseTokenDecimals: (config as any)?.baseTokenDecimals || 18,
      datatokenDecimals: 18,
      fixedRate: ddo.stats.price.value,
      marketFee: '0',
      allowedConsumer: smartAccount || eoaAddress,
      withMint: true,
    };
    console.log('awaiting creation of nft and datatoken...');

    bundleNFT = await nftFactory.createNftWithDatatokenWithFixedRate(
      nftParamsAsset,
      datatokenParams,
      fixedPriceParams,
    );
    console.log('nft and datatoken created successfully...');
  }
  const trxReceipt = await bundleNFT.wait();
  const nftCreatedEvent = getEventFromTx(trxReceipt, 'NFTCreated');
  const tokenCreatedEvent = getEventFromTx(trxReceipt, 'TokenCreated');
  const nftAddress = nftCreatedEvent.args.newTokenAddress;
  const datatokenAddressAsset = tokenCreatedEvent.args.newTokenAddress;
  if (smartAccount && biconomyDashboardAuthToken && smartAccountPaymasterKey) {
    console.log('awaiting smart contract whitelisting in paymaster...');
    await handleAbstractWhitelistingFlow(
      nftAddress,
      datatokenAddressAsset,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
    console.log('whitelisting completed...');
  }

  assetFiles.datatokenAddress = datatokenAddressAsset;
  assetFiles.nftAddress = nftAddress;
  const filesEncrypted = await ProviderInstance.encrypt(
    getFileEncryptRequestData(
      assetFiles.files,
      nftAddress,
      assetFiles.datatokenAddress,
    ),
    chainId,
    fileServiceEndpoint,
  );
  ddo.services[0].files = filesEncrypted;
  ddo.services[0].id = getHash(datatokenAddressAsset + filesEncrypted);
  ddo.services[0].datatokenAddress = datatokenAddressAsset;
  ddo.services[0].serviceEndpoint = fileServiceEndpoint;
  ddo.nftAddress = nftAddress;
  ddo.id =
    'did:op:' +
    SHA256(ethers.utils.getAddress(nftAddress) + chainId.toString(10));

  let metadata;
  let metadataHash;
  if (encryptDDO) {
    metadata = await ProviderInstance.encrypt(ddo, chainId, providerUrl);
    const validateResult = await aquariusInstance.validate(ddo);
    metadataHash = validateResult.hash;
  } else {
    const stringDDO = JSON.stringify(ddo);
    const bytes = Buffer.from(stringDDO);
    metadata = hexlify(bytes);
    metadataHash = '0x' + createHash('sha256').update(metadata).digest('hex');
  }
  const encodedMeta = {
    name: ddo.nft.name,
    symbol: ddo.nft.symbol,
    image_data: ddo.nft.image_data,
  };

  const encodedMetadata = Buffer.from(
    JSON.stringify({
      ...encodedMeta,
    }),
  ).toString('base64');
  const tokenUriPrefix = 'data:application/json;base64,';
  const flags = ethers.utils.hexlify(2);
  const metadataAndTokenURI: MetadataAndTokenURI = {
    metaDataState: 0,
    metaDataDecryptorUrl: ddo.services[0].serviceEndpoint,
    metaDataDecryptorAddress: '',
    flags,
    data: metadata,
    metaDataHash: metadataHash,
    tokenId: 1,
    tokenURI: `${tokenUriPrefix}${encodedMetadata}`,
    metadataProofs: [],
  };
  console.log('nftAddress', nftAddress);
  console.log('datatokenAddress', datatokenAddressAsset);
  await nft.setMetadataAndTokenURI(
    nftAddress,
    smartAccount || eoaAddress,
    metadataAndTokenURI,
  );
  return ddo.id;
}
