import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
  ComputeAsset,
  ComputeAlgorithm,
  Config,
  ComputeEnvironment
} from '@oceanprotocol/lib';
import {maxBy} from 'lodash'

import {
  isOrderable,
  handleComputeOrder,
  handleAbstractWhitelistingFlow,
} from '../common/helper';
import { Signer } from 'ethers';

export async function startCompute(
  datasetDID: string,
  algoDID: string,
  owner: Signer,
  chainId: string | number,
  config: Config,
  oceanAquariusUri: string,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  smartAccount?: string
) {
  const aquarius = new Aquarius(oceanAquariusUri || '');
  const dataDdo = await aquarius.waitForAqua(datasetDID);
  const eoaAddress = await owner.getAddress();

  if (!dataDdo) {
    console.error(
      'Error fetching DDO ' + datasetDID + '.  Does this asset exists?',
    );
    return;
  }
  const providerURI = dataDdo.services[0].serviceEndpoint;

  const algoDdo = await aquarius.waitForAqua(algoDID);
  if (!algoDdo) {
    console.error(
      'Error fetching DDO ' + algoDID + '.  Does this asset exists?',
    );
    return;
  }
  const computeEnvs = await ProviderInstance.getComputeEnvironments(
    dataDdo.services[0].serviceEndpoint,
  );
  let longestDurationEnv: ComputeEnvironment = null
  let computeEnv = Array.isArray(computeEnvs)
  ? computeEnvs[0]
  : computeEnvs[dataDdo.chainId][0]

  if (!computeEnv || !computeEnv.id) {
    console.error(`Error getting compute environments!`)
    return
  }
  longestDurationEnv = maxBy(computeEnvs as [], 'maxJobDuration')
  computeEnv = longestDurationEnv || computeEnv

  const datatoken = new Datatoken(owner, chainId);

  const mytime = new Date();

  const minValue = Math.min(
    computeEnv?.maxJobDuration,
    dataDdo.services[0].timeout,
    algoDdo.services[0].timeout,
  );
  const computeMinutes = minValue / 60;

  mytime.setMinutes(mytime.getMinutes() + computeMinutes);
  const computeValidUntil = Math.floor(mytime.getTime() / 1000);

  let assets: ComputeAsset[];
  let algo: ComputeAlgorithm;
  if (smartAccount) {
    assets = [
      {
        documentId: dataDdo.id,
        serviceId: dataDdo.services[0].id,
        userdata: {
          smartAccount: smartAccount,
        },
      },
    ];
    algo = {
      documentId: algoDdo.id,
      serviceId: algoDdo.services[0].id,
      userdata: {
        smartAccount: smartAccount,
      },
    };
  } else {
    assets = [
      {
        documentId: dataDdo.id,
        serviceId: dataDdo.services[0].id,
        userdata: {},
      },
    ];
    algo = {
      documentId: algoDdo.id,
      serviceId: algoDdo.services[0].id,
      userdata: {},
    };
  }

  const dtAddressArray = [dataDdo.services[0].datatokenAddress];

  const canStartCompute = isOrderable(
    dataDdo,
    dataDdo.services[0].id,
    algo,
    algoDdo,
  );

  if (!canStartCompute) {
    console.error(
      'Error Cannot start compute job using the dataset DID & algorithm DID provided',
    );
    return;
  }

  const providerInitializeComputeJob = await ProviderInstance.initializeCompute(
    assets,
    algo,
    computeEnv?.id,
    computeValidUntil,
    providerURI,
    eoaAddress,
  );
  if (
    !providerInitializeComputeJob ||
    'error' in providerInitializeComputeJob.algorithm
  ) {
    console.error(
      'Error initializing Provider for the compute job using dataset DID ' +
        datasetDID +
        ' and algorithm DID ' +
        algoDID,
    );
    return;
  }
  if (smartAccount && biconomyDashboardAuthToken && smartAccountPaymasterKey) {
    await handleAbstractWhitelistingFlow(
      algoDdo.nft.address,
      algoDdo.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
    await handleAbstractWhitelistingFlow(
      dataDdo.nft.address,
      dataDdo.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
  }

  console.log(
    'Ordering algorithm: ',
    algoDID,
    'Calling handle compute for Algo',
  );
  algo.transferTxId = await handleComputeOrder(
    providerInitializeComputeJob.algorithm,
    algoDdo,
    owner,
    computeEnv.consumerAddress,
    0,
    datatoken,
    config,
    providerInitializeComputeJob?.algorithm?.providerFee,
    providerURI,
    smartAccount
  );
  console.log('algo.transferTxId:', algo.transferTxId);
  if (!algo.transferTxId) {
    console.error(
      'Error ordering compute for algorithm with DID: ' +
        algoDID +
        '.  Do you have enought tokens?',
    );
    return;
  }

  for (let i = 0; i < providerInitializeComputeJob.datasets.length; i++) {
    console.log(
      'Ordering dataset: ',
      datasetDID,
      'Calling handle compute for datasetDDO',
    );
    assets[i].transferTxId = await handleComputeOrder(
      providerInitializeComputeJob.datasets[i],
      dataDdo,
      owner,
      computeEnv.consumerAddress,
      0,
      datatoken,
      config,
      providerInitializeComputeJob?.datasets[i].providerFee,
      providerURI,
      smartAccount
    );
    console.log('assets[i].transferTxId:', assets[i].transferTxId);
    if (!assets[i].transferTxId) {
      console.error(
        'Error ordering dataset with DID: ' +
          datasetDID +
          '.  Do you have enought tokens?',
      );
      return;
    }
  }

  const computeJobs = await ProviderInstance.computeStart(
    providerURI,
    owner,
    computeEnv.id,
    assets[0],
    algo,
  );
  const { jobId } = computeJobs[0];
  console.log('jobId:', jobId);
  return jobId;
}
