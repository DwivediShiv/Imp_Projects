import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
} from '@oceanprotocol/lib';

import {
  handleAbstractWhitelistingFlow,
  updateAssetMetadata,
} from '../common/helper';
import { Signer } from 'ethers';

export async function disAllowAlgo(
  datasetDID: string,
  algoDID: string,
  owner: Signer,
  chainId: number,
  oceanAquariusUri: string,
  oceanProviderUri: string,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string,
) {
  const aquarius = new Aquarius(oceanAquariusUri);
  const asset = await aquarius.waitForAqua(datasetDID);
  const addr = accountAddr || (await owner.getAddress());
  if (!asset) {
    console.error(
      'Error fetching DDO ' + datasetDID + '.  Does this asset exists?',
    );
    return;
  }
  if (asset.nft.owner !== addr) {
    console.error(
      'You are not the owner of this asset, and there for you cannot update it.',
    );
    return;
  }
  if (asset.services[0].type !== 'compute') {
    console.error(
      'Error getting computeService for ' +
        datasetDID +
        '.  Does this asset has an computeService?',
    );
    return;
  }
  if (asset.services[0].compute.publisherTrustedAlgorithms.length <= 0) {
    console.error(
      ' ' + datasetDID + '.  Does this asset has an computeService?',
    );
    return;
  }

  const indexToDelete =
    asset.services[0].compute.publisherTrustedAlgorithms.findIndex(
      (item) => item.did === algoDID,
    );

  if (indexToDelete !== -1) {
    asset.services[0].compute.publisherTrustedAlgorithms.splice(
      indexToDelete,
      1,
    );
  } else {
    console.error(
      ' ' +
        datasetDID +
        '.  is not allowed by the publisher to run on ' +
        algoDID,
    );
    return;
  }
  if (accountAddr && biconomyDashboardAuthToken && smartAccountPaymasterKey) {
    console.log('Whitelisting required contracts..');
    await handleAbstractWhitelistingFlow(
      asset.nft.address,
      asset.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
    console.log('Whitelisting Done.');
  }

  const txid = await updateAssetMetadata(
    owner,
    asset,
    oceanProviderUri,
    aquarius,
    chainId,
    '',
    accountAddr,
  );
  const trxReceipt = await txid.wait();
  console.log('asset removed from trusted algos', trxReceipt);
  console.log('DisAllow Algo command completed');
}
