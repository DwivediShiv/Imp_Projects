import axios from 'axios';
import {
  AssetExtended,
  UniqueJobs,
  buyDatasetNew,
  fetchDummyDataset,
  getAssets,
  getComputeEnviroment,
  prepareResultURLsForAggregateAlgo,
} from './start-multiple-compute';
import {
  ComputeAsset,
  ComputeAlgorithm,
  ProviderInstance,
  Config,
} from '@oceanprotocol/lib';
import { Signer } from 'ethers';
import { getAccessDetails } from '../utils/accessDetailsAndPricing';
export interface ApiResponse<T> {
  data?: T;
  error?: string | { message: string };
}

export interface MswHandlerProps<T> {
  status?: number;
  response?: ApiResponse<T>;
  error?: Error;
}

export async function aggregation(guid: string, owner: Signer, config: Config, oceanProviderUri: string, oceanAquariusUri: string, smartAccount?: string) {
  const eoa = await owner.getAddress();
  const res = await axios.get<any>(
    `${oceanProviderUri}/api/services/compute?consumerAddress=${eoa}&guid=${guid}&federatedCompute=true`,
  );
  let computeJobs = res.data;
  const uniqueJobCombinations: UniqueJobs = {};
  computeJobs = computeJobs.filter((job) => job.aggregateAlgoDID !== '-');

  for (const job of computeJobs) {
    if (job.statusText === 'Job finished' && job?.results?.length > 3) {
      const key = job.inputDID[0] + job.algoDID;

      if (
        !uniqueJobCombinations[key] ||
        job.dateCreated > uniqueJobCombinations[key].dateCreated
      ) {
        uniqueJobCombinations[key] = { job, dateCreated: job.dateCreated };
      }
    }
  }

  const jobsToAggregate = Object.values(uniqueJobCombinations).map(
    (entry) => entry?.job,
  );
  console.log('jobsToAggregate: ', jobsToAggregate);
  const resultURLData = await prepareResultURLsForAggregateAlgo(
    jobsToAggregate,
    owner,
    oceanProviderUri,
  );
  if(!resultURLData || resultURLData?.length === 0) {
    console.error('Error occured in resultURLData')
    return
  }
  console.log('resultURLData', resultURLData);

  // Aggregation Process
  const { aggregateAlgoDID } = jobsToAggregate[0];

  const aggregateAlgoDDO = await getAssets([aggregateAlgoDID], oceanAquariusUri);
  console.log('aggregateAlgoDDO');

  // getAccessDetails = valid order trxn nikalta tha but yaha ham purchase hi kr rahe h direct
  const chainId = await owner.getChainId();

  const dummyDataset: AssetExtended | undefined = await fetchDummyDataset(
    aggregateAlgoDID,
    chainId,
    oceanAquariusUri,
  );
  console.log('ordering Aggregate Assets');

  dummyDataset.accessDetails = await getAccessDetails(
    dummyDataset?.services[0].datatokenAddress,
    config,
    dummyDataset?.services[0].timeout,
    smartAccount || (await owner.getAddress()),
  );

  aggregateAlgoDDO[0]['accessDetails'] =  await getAccessDetails(
    aggregateAlgoDDO[0]?.services[0].datatokenAddress,
    config,
    aggregateAlgoDDO[0]?.services[0].timeout,
    smartAccount || (await owner.getAddress()),
  );

  // Buy dummy dataset and aggregateAlgo
  const aggregateAssetsHash = await buyDatasetNew(
    dummyDataset as AssetExtended,
    aggregateAlgoDDO[0],
    guid,
    owner,
    config,
    '',
    '',
    smartAccount
  );

  console.log('Purchased Aggregate Assets');
  const computeAlgorithm: ComputeAlgorithm = {
    documentId: aggregateAlgoDDO[0].id,
    serviceId: aggregateAlgoDDO[0].services[0].id,
    transferTxId: aggregateAssetsHash?.algoTxReceipt,
    userdata: {},
    algocustomdata: {
      resultUrls: resultURLData,
    },
  };

  const computeAsset: ComputeAsset = {
    documentId: dummyDataset?.id as string,
    serviceId: dummyDataset?.services[0].id as string,
    transferTxId: aggregateAssetsHash?.datasetTxReceipt,
    userdata: {
      guid,
      aggregateAlgorithmId: '-',
      providerAuthToken: '-',
    },
  };
  if (smartAccount) {
    computeAlgorithm.userdata.smartAccount = smartAccount;
    computeAsset.userdata.smartAccount = smartAccount;
  }
  const computeEnv = await getComputeEnviroment(dummyDataset as AssetExtended);

  const output: any = {
    publishAlgorithmLog: true,
    publishOutput: true,
  };
  const response = await ProviderInstance.computeStart(
    dummyDataset?.services[0].serviceEndpoint as string,
    owner,
    computeEnv?.id,
    computeAsset,
    computeAlgorithm,
    undefined,
    [],
    output,
  );
  console.log('response', response);

  const { jobId } = response[0];
  console.log('jobIdAgregrated===>', jobId);
}
