import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
  Config,
} from '@oceanprotocol/lib';
import { handleAbstractWhitelistingFlow } from '../common/helper';
import { Signer } from 'ethers';
import { getAccessDetails } from '../utils/accessDetailsAndPricing';

export interface UserCustomParameters {
  [key: string]: any;
}
export async function download(
  datasetDID: string,
  destinationFolderPath: string,
  owner: Signer,
  config: Config,
  isBrowser: boolean,
  oceanAquariusUrl: string,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string,
) {
  const acc = new Aquarius(oceanAquariusUrl);
  let asset = await acc.waitForAqua(datasetDID);
  if (!asset) {
    console.error(
      'Error fetching DDO ' + datasetDID + '.  Does this asset exists?',
    );
    return;
  }

  let orderTx;
  const providerURI = asset.services[0].serviceEndpoint;
  const datatoken = new Datatoken(owner, await owner.getChainId(), config);
  if (accountAddr && biconomyDashboardAuthToken && smartAccountPaymasterKey) {
    console.log('whitelisting required contract..');
    await handleAbstractWhitelistingFlow(
      asset.nft.address,
      asset.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
    console.log('whitelisting done..');
  }

  const accessDetails = await getAccessDetails(
    asset.services[0].datatokenAddress,
    config,
    asset.services[0].timeout, //Describing how long the service can be used after consumption is initiated.
    accountAddr || (await owner.getAddress()),
  );

  if (
    accessDetails?.type === 'free' &&
    (asset?.metadata?.additionalInformation?.postpayType === 'setPrice' ||
      asset?.metadata?.additionalInformation?.postpayType === 'payPerByte')
  ) {
    const parsedJson = JSON.parse(asset?.metadata?.additionalInformation.price);
    const price = parsedJson?.value;
    const symbol = parsedJson?.tokenSymbol;
    accessDetails.baseToken = {
      symbol,
    };
    accessDetails.price = price;
  }
  let abstractDatasetParams: UserCustomParameters = {};
  if (accountAddr) {
    abstractDatasetParams = {
      smartAccount: accountAddr,
    };
  }
  const isOwned = accessDetails.isOwned;

  if (!isOwned) {
    const tx = await orderAsset(
      asset,
      owner,
      config,
      datatoken,
      providerURI,
      accountAddr,
    );
    if (!tx) {
      console.error(
        'Error ordering access for ' +
          datasetDID +
          '.  Do you have enought tokens?',
      );
      return;
    }
    orderTx = await tx.wait();
  }
  const urlDownloadUrl = await ProviderInstance.getDownloadUrl(
    asset.id,
    asset.services[0].id,
    0,
    accessDetails.validOrderTx || orderTx.transactionHash,
    providerURI,
    owner,
    abstractDatasetParams,
  );
  console.log('urlDownloadUrl', urlDownloadUrl);
  return urlDownloadUrl;
}
