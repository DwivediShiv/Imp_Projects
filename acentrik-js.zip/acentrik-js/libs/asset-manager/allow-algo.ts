import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
  getHash,
  Aquarius,
} from '@oceanprotocol/lib';

import {
  handleAbstractWhitelistingFlow,
  updateAssetMetadata,
} from '../common/helper';
import { Signer } from 'ethers';

export async function allowAlgo(
  datasetDID: string,
  algoDID: string,
  owner: Signer,
  chainId: number,
  oceanAquariusUri: string,
  oceanProviderUri: string,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string
) {
  let aquarius = new Aquarius(oceanAquariusUri);
  const asset = await aquarius.waitForAqua(datasetDID);
  const addr = accountAddr || (await owner.getAddress());

  if (!asset) {
    console.error(
      'Error fetching DDO ' + datasetDID + '.  Does this asset exists?',
    );
    return;
  }

  if (asset.nft.owner !== addr) {
    console.error(
      'You are not the owner of this asset, and there for you cannot update it.',
    );
    return;
  }

  if (asset.services[0].type !== 'compute') {
    console.error(
      'Error getting computeService for ' +
        datasetDID +
        '.  Does this asset has an computeService?',
    );
    return;
  }
  const algoAsset = await aquarius.waitForAqua(algoDID);
  if (!algoAsset) {
    console.error(
      'Error fetching DDO ' + algoDID + '.  Does this asset exists?',
    );
    return;
  }

  const filesChecksum = await ProviderInstance.checkDidFiles(
    algoAsset.id,
    algoAsset.services[0].id,
    algoAsset.services[0].serviceEndpoint,
    true,
  );

  const containerChecksum =
    algoAsset.metadata.algorithm.container.entrypoint +
    algoAsset.metadata.algorithm.container.checksum;
  const trustedAlgorithm = {
    did: algoAsset.id,
    containerSectionChecksum: getHash(containerChecksum),
    filesChecksum: filesChecksum?.[0]?.checksum,
  };
  asset.services[0].compute.publisherTrustedAlgorithms.push(trustedAlgorithm);

  if (accountAddr && biconomyDashboardAuthToken && smartAccountPaymasterKey) {
    console.log('Whitelisting required contracts..');
    await handleAbstractWhitelistingFlow(
      asset.nft.address,
      asset.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
    );
    console.log('Whitelisting Done.');
  }

  const txid = await updateAssetMetadata(
    owner,
    asset,
    oceanProviderUri,
    aquarius,
    chainId,
    '',
    accountAddr
  );
  const trxReceipt = await txid.wait();
  console.log('Asset updated. Asset added as a trusted algorithm: ', trxReceipt);
  console.log('Allow Algo command completed');
}
