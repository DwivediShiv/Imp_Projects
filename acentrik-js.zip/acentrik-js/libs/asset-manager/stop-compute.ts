import {
  NftCreateData,
  DatatokenCreateParams,
  DispenserCreationParams,
  getEventFromTx,
  FreCreationParams,
  Aquarius,
  Datatoken,
  orderAsset,
  ProviderInstance,
  DownloadResponse,
  LoggerInstance,
} from '@oceanprotocol/lib';
import { Signer } from 'ethers';


export async function stopCompute(
  datasetDID: string,
  jobID: string,
  owner: Signer,
  oceanAquariusUri: string,
) {
  const aquarius = new Aquarius(oceanAquariusUri);
  const dataDdo = await aquarius.waitForAqua(datasetDID);
  if (!dataDdo) {
    console.error(
      'Error fetching DDO ' + datasetDID + '.  Does this asset exists?',
    );
    return;
  }
  const providerURI = dataDdo.services[0].serviceEndpoint;
  const signerAddr = await owner.getAddress();
  const jobStatus = await ProviderInstance.computeStop(
    datasetDID,
    signerAddr,
    jobID,
    providerURI,
    owner,
  );
  console.log('stopped compute', jobStatus);
}
