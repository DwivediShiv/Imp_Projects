import { Aquarius, Config } from '@oceanprotocol/lib';
import {
  handleAbstractWhitelistingFlow,
  updateAssetMetadata,
  updateEditAssetMetadata,
} from '../common/helper';
import { Signer } from 'ethers';

export async function editAsset(
  options: any,
  existingDdo: any,
  paymentCollector: string,
  owner: Signer,
  chainId: number,
  config: Config,
  oceanAquariusUri: string,
  oceanProviderUri: string,
  biconomyDashboardAuthToken?: string,
  smartAccountPaymasterKey?: string,
  accountAddr?: string,
  paymentManagementUrl?: string,
): Promise<any> {
  let acc = new Aquarius(oceanAquariusUri);
  const asset = options;
  if (
    accountAddr &&
    biconomyDashboardAuthToken &&
    smartAccountPaymasterKey &&
    paymentManagementUrl
  ) {
    console.log('Whitelisting required contracts..');
    await handleAbstractWhitelistingFlow(
      asset.nft.address,
      asset.datatokens[0].address,
      biconomyDashboardAuthToken,
      smartAccountPaymasterKey,
      paymentManagementUrl,
    );
    console.log('Whitelisting done..');
  }

  const updateAssetTx = await updateEditAssetMetadata(
    owner,
    asset,
    existingDdo,
    paymentCollector,
    oceanProviderUri,
    acc,
    chainId,
    config,
    '',
    accountAddr,
  );
  return updateAssetTx;
}
