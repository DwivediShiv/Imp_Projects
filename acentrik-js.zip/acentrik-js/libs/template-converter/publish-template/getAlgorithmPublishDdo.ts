import { PublishAlgorithmDetails, SdkParamsValues } from '../../types/publishTemplate';
import { generateNftMetadata } from './generateNftMetadata';
import { generateMetadata } from './generateMetadata';
import { generateService } from './generateService';
import { generateCredential } from './generateCredential';
import { Credentials } from '../../common';

export function getAlgorithmPublishDdo(
  assetDetails: PublishAlgorithmDetails,
  sdkParams: SdkParamsValues,
) {
  const nftMetadata = generateNftMetadata(
    sdkParams?.assetManagementTokenName,
    sdkParams?.assetManagementTokenPrefix,
    sdkParams?.assetManagementTokenImageUrl,
  );
  const chain = Number(sdkParams?.chainId);
  let priceValue = assetDetails?.price || '0';
  let credentials: Credentials = { allow: [], deny: [] };

  const newMetadata = generateMetadata(assetDetails, sdkParams);

  if (assetDetails?.priceType === 'Post-pay') {
    newMetadata.additionalInformation.postpayType = assetDetails?.postPayType;
    newMetadata.additionalInformation.price = JSON.stringify({
      tokenAddress: sdkParams?.baseToken,
      tokenSymbol: assetDetails?.postPayTokenSymbol,
      value: assetDetails?.postPayPriceValue,
    });
    priceValue = '0';
  }

  if (assetDetails?.accessPermission === 'deny') {
    credentials = {
      allow: [
        generateCredential('address', [sdkParams?.signer?.toLowerCase() || '']),
      ],
      deny: [],
    };
  }
  const newService = generateService(assetDetails, sdkParams);

  const ddoResp = {
    '@context': ['https://w3id.org/did/v1'],
    id: '',
    nftAddress: '',
    version: '4.1.0',
    chainId: chain,
    metadata: newMetadata,
    services: [newService],
    credentials,
    event: {},
    nft: nftMetadata,
    stats: {
      allocated: 0,
      orders: 0,
      price: {
        value: priceValue,
      },
    },
    purgatory: {
      state: false,
    },
  };

  return ddoResp;
}
