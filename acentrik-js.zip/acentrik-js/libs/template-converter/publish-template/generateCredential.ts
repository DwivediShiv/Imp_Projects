import { Credential } from "../../common";

export function generateCredential(
  credentialType: string,
  values: string[],
): Credential {
  return {
    type: credentialType,
    values,
  };
}
