import { Metadata } from '@oceanprotocol/lib';
import { SdkParamsValues } from '../../types/publishTemplate';
import { dateToStringNoMS } from '../../utils/dateUtils';

export function generateMetadata(
  assetDetails: any,
  sdkParams: SdkParamsValues,
): Metadata {
  const currentTime = dateToStringNoMS(new Date());

  const newMetadata: Metadata = {
    created: currentTime,
    updated: currentTime,
    type: assetDetails?.type,
    name: assetDetails?.name,
    description: assetDetails?.overview,
    tags: assetDetails?.tags,
    author: assetDetails?.author,
    license: 'https://market.oceanprotocol.com/terms',
    categories: assetDetails?.categories,
    additionalInformation: {
      source: sdkParams?.source,
      accessPermission: assetDetails?.accessPermission,
      eula: assetDetails?.eulaUrl && [{ url: assetDetails?.eulaUrl }],
      organization: sdkParams.orgId,
      signer: sdkParams?.signer,
      ...(assetDetails?.type === 'algorithm' && {
        algorithmType: assetDetails?.algorithmType,
      }),
    },
    ...(assetDetails?.type === 'algorithm' && {
      algorithm: {
        language: 'custom',
        version: '0.1',
        container: {
          entrypoint: assetDetails?.algorithmEntrypoint || '',
          image: assetDetails?.algorithmImage || '',
          tag: assetDetails?.algorithmTag || '',
          checksum: assetDetails?.algorithmChecksum || '',
          referenceUrl: assetDetails?.algorithmReferenceUrl || '',
        } as any,
      },
    }),
  };

  return newMetadata;
}
