export function getCorrectServiceEndpointBasedOnName(
    listOfServiceEndpoints?: string,
    serviceEndpointName?: string,
  ): string | null {
    if (!listOfServiceEndpoints || !serviceEndpointName) {
      console.error(
        'Invalid input: list of service endpoints not found in env file and service endpoint must be provided in publish form',
      );
      return null;
    }
  
    let regex = new RegExp(`"${serviceEndpointName}":"([^"]*)"`, 'i');
    if (!regex.test(listOfServiceEndpoints)) {
      console.error(
        'Invalid input: service endpoint given is not present in the list of available service endpoints, please find the correct name of the service end point from env file',
      );
      return null;
    }
  
    const escapedKey = serviceEndpointName?.replace(
      /[.*+?^${}()|[\]\\]/g,
      '\\$&',
    );
    const pattern = new RegExp(`"${escapedKey}":"(https://[^"]+)"`);
    const match = listOfServiceEndpoints?.match(pattern);
    return match ? match[1] : null;
  }
  