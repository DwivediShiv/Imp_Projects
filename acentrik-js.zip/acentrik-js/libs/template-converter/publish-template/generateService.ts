import { SdkParamsValues } from '../../types/publishTemplate';
import {
  checkIsLocalPath,
  fancyConvertSecondsToTimeoutOfDurationType,
  validateConsumerParameters,
  validateHTTPHeaders,
} from '../../common/helper';
import { isAddress } from 'ethers/lib/utils';
import { UNLIMITED_TIMEOUT } from '../../common';
import { getCorrectServiceEndpointBasedOnName } from './getCorrectServiceEndpointBasedOnName';

export function generateService(assetDetails: any, sdkParams: SdkParamsValues) {
  const timeoutInSeconds = fancyConvertSecondsToTimeoutOfDurationType(
    assetDetails?.timeout,
    assetDetails?.timeoutDurationType,
  );
  if (timeoutInSeconds < 0) {
    throw new Error('Incorrect timeout duration type / value provided..');
  }
  const newService = {
    id: '',
    files: {
      datatokenAddress: '0x0',
      nftAddress: '0x0',
      files: [
        {
          type: checkIsLocalPath(assetDetails?.assetUrl)
            ? 'localstorage'
            : 'url',
          url: assetDetails?.assetUrl,
          method: 'GET',
          ...(validateHTTPHeaders(assetDetails?.httpHeaders) && {
            headers: assetDetails?.httpHeaders,
          }),
        },
      ],
    },
    ...(sdkParams?.isDisableParameterizeAsset === 'false' &&
      assetDetails?.type === 'dataset' &&
      validateConsumerParameters(assetDetails?.consumerParameters) && {
        consumerParameters: assetDetails?.consumerParameters,
      }),
    datatokenAddress: '',
    ...(sdkParams?.serviceEndpoints &&
      assetDetails?.serviceEndpoint && {
        serviceEndpoint: getCorrectServiceEndpointBasedOnName(
          sdkParams?.serviceEndpoints,
          assetDetails?.serviceEndpoint,
        ),
      }),
    timeout:
      assetDetails?.timeoutDurationType.toLowerCase() === UNLIMITED_TIMEOUT
        ? 0
        : Math.round(timeoutInSeconds),
    ...(assetDetails?.serviceType === 'private' ||
    assetDetails?.serviceType === 'compute'
      ? {
          type: 'compute',
          compute: {
            allowRawAlgorithm: false,
            allowNetworkAccess: true,
            publisherTrustedAlgorithmPublishers: [],
            publisherTrustedAlgorithms: [],
          },
        }
      : { type: 'access' }),

    description: assetDetails?.description,
    additionalInformation: {
      sampleType: 'URL',
      links: assetDetails?.sampleFileUrl
        ? [{ url: assetDetails?.sampleFileUrl }]
        : [],
      source: sdkParams?.source,
      ...(assetDetails?.type === 'algorithm' && {
        input: {
          fileType: assetDetails?.inputFileType || '',
        },
        output: {
          fileType: assetDetails?.outputFileType || '',
        },
      }),
      timeoutDurationType: assetDetails?.timeoutDurationType.toLowerCase(),
      isExperimental: assetDetails?.isExperimental,
      ...(assetDetails?.alternateWalletAddress && {
        alternateWalletAddress:
          assetDetails?.alternateWalletAddress?.length === 42 &&
          isAddress(assetDetails?.alternateWalletAddress)
            ? assetDetails?.alternateWalletAddress
            : '',
      }),
    },
  };

  return newService;
}
