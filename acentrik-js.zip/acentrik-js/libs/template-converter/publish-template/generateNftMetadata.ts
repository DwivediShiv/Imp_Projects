import * as randomstring from 'randomstring';

export function generateNftMetadata(
  name: string | undefined,
  prefix: string | undefined,
  imageUrl: string | undefined,
) {
  const newNft = {
    name: name,
    symbol: `${prefix}-${randomstring.generate({
      length: 8,
      charset: 'hex',
      capitalization: 'uppercase',
    })}`,
    image_data: imageUrl,
    address: '',
    state: 0,
    tokenURI: '',
    owner: '',
    created: '',
  };
  return newNft;
}
