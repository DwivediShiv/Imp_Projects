import { SdkParamsValues } from '../../types/publishTemplate';
import {
  checkIsLocalPath,
  fancyConvertSecondsToTimeoutOfDurationType,
  validateConsumerParameters,
  validateHTTPHeaders,
} from '../../common/helper';
import { UNLIMITED_TIMEOUT } from '../../common';
import { isAddress } from 'ethers/lib/utils';
import { getCorrectServiceEndpointBasedOnName } from '../publish-template';

export function generateService(
  existingDdo: any,
  assetDetails: any,
  sdkParams: SdkParamsValues,
) {
  let mergedConsumerParameters: any = [];
  if (
    sdkParams?.isDisableParameterizeAsset === 'false' &&
    existingDdo?.metadata?.type === 'dataset' &&
    validateConsumerParameters(assetDetails?.consumerParameters)
  ) {
    mergedConsumerParameters = [
      ...(existingDdo?.services[0]?.consumerParameters || []),
      ...(assetDetails?.consumerParameters || []),
    ];
  }
  let timeoutInSeconds = existingDdo?.services[0].timeout;
  let timeoutDurationType = existingDdo?.services[0]?.additionalInformation?.timeoutDurationType;
  if (assetDetails?.timeout || assetDetails?.timeoutDurationType) {
    timeoutInSeconds = fancyConvertSecondsToTimeoutOfDurationType(
      assetDetails?.timeout || timeoutInSeconds,
      assetDetails?.timeoutDurationType || timeoutDurationType,
    );
    if (timeoutInSeconds < 0) {
      throw new Error('Incorrect timeout duration type / value provided..');
    }
  }
  const newService = {
    ...existingDdo.services[0],
    ...(assetDetails?.assetUrl && {
      files: {
        datatokenAddress: existingDdo?.datatokens?.[0]?.address,
        nftAddress: existingDdo?.nftAddress,
        files: [
          {
            type: checkIsLocalPath(assetDetails?.assetUrl)
              ? 'localstorage'
              : 'url',
            url: assetDetails?.assetUrl,
            method: 'GET',
            ...(validateHTTPHeaders(assetDetails?.httpHeaders) && {
              headers: assetDetails?.httpHeaders,
            }),
          },
        ],
      },
    }),
    ...(mergedConsumerParameters.length > 0 && {
      consumerParameters: mergedConsumerParameters,
    }),
    ...(sdkParams?.serviceEndpoints &&
      assetDetails?.serviceEndpoint && {
        serviceEndpoint: getCorrectServiceEndpointBasedOnName(
          sdkParams?.serviceEndpoints,
          assetDetails?.serviceEndpoint,
        ),
      }),

    ...(timeoutInSeconds !== existingDdo.services[0]?.timeout && {
      timeout:
        assetDetails?.timeoutDurationType.toLowerCase() === UNLIMITED_TIMEOUT
          ? 0
          : Math.round(timeoutInSeconds),
    }),

    description:
      assetDetails?.description || existingDdo.services[0].description,
    additionalInformation: {
      ...existingDdo.services[0].additionalInformation,
      links: assetDetails?.sampleFileUrl
        ? [{ url: assetDetails?.sampleFileUrl }]
        : existingDdo.services[0].additionalInformation.links,
      ...(existingDdo?.metadata?.type === 'algorithm' && {
        input: {
          fileType:
            assetDetails?.inputFileType ||
            existingDdo.services[0].additionalInformation.input.fileType,
        },
        output: {
          fileType:
            assetDetails?.outputFileType ||
            existingDdo.services[0].additionalInformation.output.fileType,
        },
      }),
      ...(assetDetails?.timeoutDurationType && {
        timeoutDurationType: assetDetails?.timeoutDurationType?.toLowerCase() 
      }),     
      ...(assetDetails.hasOwnProperty('isExperimental') && {
        isExperimental: assetDetails.isExperimental,
      }),
      ...(assetDetails?.alternateWalletAddress && {
        alternateWalletAddress:
          assetDetails?.alternateWalletAddress?.length === 42 &&
          isAddress(assetDetails?.alternateWalletAddress)
            ? assetDetails?.alternateWalletAddress
            : '',
      }),
    },
  };

  return newService;
}
