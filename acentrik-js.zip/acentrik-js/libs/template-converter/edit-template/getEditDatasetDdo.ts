import { EditDatasetDetails } from '../../types/editTemplate';
import { SdkParamsValues } from '../../types/publishTemplate';
import { generateMetadata } from './generateMetadata';
import { generateService } from './generateService';
import { generateNftMetadata } from './generateNftMetadata';
import { populateCredentials } from './populateCredentials';
import { Credentials } from '../../common';
import { generateCredential } from '../publish-template';

export function getEditDatasetDdo(
  assetDetails: EditDatasetDetails,
  existingDdo: any,
  sdkParams: SdkParamsValues,
) {
  let priceValue = existingDdo?.stats?.price?.value;
  if (assetDetails?.price && existingDdo.stats.price.value !== 0) {
    priceValue = assetDetails.price || existingDdo.stats.price.value;
  }
  let credentials: Credentials = { allow: [], deny: [] };

  const newMetadata = generateMetadata(existingDdo, assetDetails);

  if (assetDetails?.priceType === 'Post-pay') {
    newMetadata.additionalInformation.postpayType =
      assetDetails?.postPayType ||
      existingDdo.metadata.additionalInformation.postpayType;
    newMetadata.additionalInformation.price = JSON.stringify({
      tokenAddress:
        sdkParams?.baseToken ||
        existingDdo.metadata.additionalInformation.tokenAddress,
      tokenSymbol:
        assetDetails?.postPayTokenSymbol ||
        existingDdo.metadata.additionalInformation.tokenSymbol,
      value:
        assetDetails?.postPayPriceValue ||
        existingDdo.metadata.additionalInformation.value,
    });
    priceValue = '0';
  }

  if (assetDetails?.accessPermission === 'deny') {
    credentials = {
      allow: [
        generateCredential('address', [sdkParams?.signer?.toLowerCase() || '']),
      ],
      deny: [],
    };
  }
  if (assetDetails?.accessPermission === 'custom') {
    credentials = populateCredentials(assetDetails);
  }

  const newService = generateService(existingDdo, assetDetails, sdkParams);

  const newNft = generateNftMetadata(existingDdo, assetDetails);

  const ddoResp = {
    ...existingDdo,
    metadata: newMetadata,
    nft: newNft,
    services: [newService],
    credentials,
    stats: {
      ...existingDdo.stats,
      price: {
        ...existingDdo.stats.price,
        value: Number(priceValue),
      },
    },
  };

  return ddoResp;
}
