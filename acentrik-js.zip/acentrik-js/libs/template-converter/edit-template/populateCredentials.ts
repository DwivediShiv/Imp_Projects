export function populateCredentials(assetDetails: any): any {
    let credentials: any = {
      allow: [],
      deny: [],
    };
    if (assetDetails?.accessPermission === 'custom') {
      for (const [key, values] of Object.entries(assetDetails?.allow || {})) {
        credentials.allow.push({
          type: key,
          values: Array.isArray(values) ? values : [values],
        });
      }
      for (const [key, values] of Object.entries(assetDetails?.deny || {})) {
        credentials.deny.push({
          type: key,
          values: Array.isArray(values) ? values : [values],
        });
      }
    }
    return credentials;
  }
  