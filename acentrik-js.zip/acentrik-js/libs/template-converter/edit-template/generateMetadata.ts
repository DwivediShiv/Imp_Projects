import { Metadata } from '@oceanprotocol/lib';
import { dateToStringNoMS } from '../../utils/dateUtils';

export function generateMetadata(existingDdo: any, assetDetails: any): Metadata {
  const currentTime = dateToStringNoMS(new Date());

  const newMetadata: Metadata = {
    ...existingDdo.metadata,
    updated: currentTime,
    name: assetDetails?.name || existingDdo.metadata.name,
    description: assetDetails?.overview || existingDdo.metadata.description,
    tags: assetDetails?.tags || existingDdo.metadata.tags,
    author: assetDetails?.author || existingDdo.metadata.author,
    categories: assetDetails?.categories || existingDdo.metadata.categories,
    additionalInformation: {
      ...existingDdo.metadata.additionalInformation,
      accessPermission:
        assetDetails?.accessPermission ||
        existingDdo.metadata.additionalInformation.accessPermission,
      eula: assetDetails?.eulaUrl
        ? [{ url: assetDetails?.eulaUrl }]
        : existingDdo.metadata.additionalInformation.eula,
    },
    ...(existingDdo.metadata.type === 'algorithm' && {
      algorithm: {
        language: existingDdo.metadata.algorithm?.language || 'custom',
        version: existingDdo.metadata.algorithm?.version || '0.1',
        container: {
          entrypoint: (assetDetails?.algorithmEntrypoint ||
            existingDdo.metadata.algorithm?.container.entrypoint) as string,
          image: (assetDetails?.algorithmImage ||
            existingDdo.metadata.algorithm?.container.image) as string,
          tag: (assetDetails?.algorithmTag ||
            existingDdo.metadata.algorithm?.container.tag) as string,
          checksum: (assetDetails?.algorithmChecksum ||
            existingDdo.metadata.algorithm?.container.checksum) as string,
          referenceUrl:
            assetDetails?.algorithmReferenceUrl ||
            existingDdo.metadata.algorithm?.container.referenceUrl,
        } as any,
      },
    }),
  };

  return newMetadata;
}
