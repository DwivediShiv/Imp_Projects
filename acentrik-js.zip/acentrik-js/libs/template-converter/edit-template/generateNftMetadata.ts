export function generateNftMetadata(existingDdo: any, assetDetails: any) {
  const nftStateMapping: { [key: string]: number } = {
    delist: 1,
    active: 0,
    inactive: 4,
  };
  const newNft = {
    ...existingDdo.nft,
    ...(assetDetails?.nftState &&
      nftStateMapping.hasOwnProperty(assetDetails.nftState) && {
        state: nftStateMapping[assetDetails.nftState],
      }),
    ...(assetDetails?.owner && { owner: assetDetails.owner }),
  };
  return newNft;
}
