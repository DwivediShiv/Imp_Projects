<h1 align="center">Acentrik SDK</h1>

> CLI tool to interact with the oceanprotocol's JavaScript library to privately & securely publish, consume and run compute on data using **Account Abstraction**.

With Acentrik SDK you can:

- **Publish** data services: downloadable files or compute-to-data.
- **Edit** existing assets.
- **Consume** data services, ordering datatokens and downloading data.
- **Compute to data** on public available datasets using a published algorithm.

## 📚 Prerequisites

- node.js ([Install from here](https://nodejs.org/en/download/))

## 🏗 Installation & Usage

Login to AWS CodeArtifact

```bash
aws codeartifact login --tool npm --domain acentrik --domain-owner 540306422608 --repository package-js
```

Set AUTH Token to ENV VAR for npm install authentication with AWS CodeArtifact Registry

```bash
export CODEARTIFACT_AUTH_TOKEN=`aws codeartifact get-authorization-token --domain acentrik --domain-owner 540306422608 --query authorizationToken --output text`
```

### Clone and install

```bash
$ git clone https://github.com/acentrik/acentrik-sdk.git
npm install
```

### Set up environment variables (in case of Account Abstraction flow)

- Copy the values of environment variables from Acentrik's `market` portal

```bash
export PRIVATE_KEY="..."
```

```bash
export RPC_URL="..."
```

```bash
export INFURA_PROJECT_ID="..."
```

```bash
export SMART_ACCOUNT_ADDRESS="..."
```

```bash
export SMART_ACCOUNT_SESSION_VALIDATION_MODULE_ADDRESS="..."
```

```bash
export SMART_ACCOUNT_PAYMASTER_URL="..."
```

```bash
export SMART_ACCOUNT_PAYMASTER_KEY="..."
```

```bash
export SMART_ACCOUNT_BUNDLER_URL="..."
```

```bash
export SMART_ACCOUNT_BUNDLER_KEY="..."
```

```bash
export OCEAN_AQUARIUS_URL="..."
```

```bash
export OCEAN_PROVIDER_URL="..."
```
```bash
export USER_ROLE="..."
```
```bash
export SESSION_KEYS="..."
```
```bash
export MERKLE_ROOT="..."
```
```bash
export CHAIN_ID="..."
```
```bash
export SUBGRAPH_URI="..."
```

### Set up environment variables (in case of Non Account Abstraction flow)

- Copy the values of environment variables from Acentrik's `market` portal 
### NOTE: Private key of the metamask wallet must be taken up from metamask only in case of non account abstract flow

```bash
export PRIVATE_KEY="..."
```

```bash
export RPC_URL="..."
```

```bash
export INFURA_PROJECT_ID="..."
```

```bash
export OCEAN_AQUARIUS_URL="..."
```

```bash
export OCEAN_PROVIDER_URL="..."
```

```bash
export CHAIN_ID="..."
```

```bash
export SUBGRAPH_URI="..."
```


### Execute transactions via CLI commands

List available commands

```bash
npm run cli help
```

E.g. run publish CLI command

```bash
npm run cli publish /Users/<username>/acentrik-js/data.json
```

### Execute transactions in a React application

```TypeScript
import { accountAbstractionProviders, createAsset, ProvidersBootstrapOptions } from '@acentrik-sdk/aa';

export default function App() {

    async function handlePurchase() {
        const options: ProvidersBootstrapOptions = {
            rpcUrl: '...',
            privateKey: '...',
            infuraProjectId: '...',
            smartAccountAddress: '...',
            smartAccountBundlerKey: '...',
            smartAccountBundlerUrl: '...',
            smartAccountPaymasterKey: '...',
            smartAccountPaymasterUrl: '...',
            smartAccountSessionValidationModuleAddress: '...',
        };
        await accountAbstractionProviders.bootstrap(options);

        const response = await createAsset({
            nftCreateData: {
                name: '...',
                symbol: '...',
                templateIndex: 1,
                tokenURI: '',
                transferable: true,
                owner: '0x68...',
            },
            datatokenCreateParams: {
                symbol: '...',
                templateIndex: 2,
                cap: '...',
                feeAmount: '0',
                feeToken: '0xd8..',
                minter: '0x68..',
                mpFeeAddress: '0x90..',
                paymentCollector: '0x68..',
            },
            dispenserCreationParams: {
                allowedSwapper: '0x00..',
                dispenserAddress: '0x21..',
                maxTokens: '...',
                maxBalance: '...',
                withMint: true,
            },
        });

        console.log('nftAddress: ', nftAddress);
        console.log('datatokenAddress: ', datatokenAddress);
    }

    return (
        <>
            <button onClick={handlePurchase}>Purchase</button>
        </>
    );
}
```

## 🏛 License

```bash
```
