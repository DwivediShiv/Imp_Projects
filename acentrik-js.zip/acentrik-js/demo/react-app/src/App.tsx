import './App.css'
import { AAAdapter, EOAdapter, AAProvidersBootstrapOptions } from '@acentrik-sdk/sdk'
import inputConfig from './inputConfig.json'
import { useEffect, useState } from 'react'

function App() {
  const [flow, setFlow] = useState<string | null>(null)
  const [adapter, setAdapter] = useState<any | null>(null)
  useEffect(() => {
    if (!flow) return
    const browserFlag = true
    if (flow === 'MM') {
      const { chain, metaMaskAdapterConfig } = inputConfig.metamaskConfig
      const adapter = new EOAdapter(chain, metaMaskAdapterConfig, browserFlag)
      setAdapter(adapter)
    } else {
      const options: AAProvidersBootstrapOptions = inputConfig.abstractAdapterConfig
      const adapter = new AAAdapter(options, browserFlag)
      setAdapter(adapter)
    }

  }, [flow])
  

  async function handlePublish() {

    const response = await adapter.publish(inputConfig.publishDDO)
    console.log(response)
  }

  async function downloadFileToBrowser(url: string): Promise<void> {
    const headResponse = await fetch(url, { method: 'HEAD' })
    const contentHeader = headResponse.headers.get('content-disposition')
    if (!headResponse.ok) {
      throw new Error('Invalid header')
    }
    let fileName = contentHeader?.split('=')[1]
    if (!fileName || fileName === '?') fileName = 'Download_File'
  
    const a = document.createElement('a')
    a.href = url
    a.setAttribute('download', fileName)
    document.body.appendChild(a)
    a.click()
    a.remove()
  }

  async function handleDownload() {
    const { datasetDID,
      destinationFilePath } = inputConfig.download
    const downloadUrl = await adapter.download(datasetDID,
      destinationFilePath)
    console.log('Download URL')
    await downloadFileToBrowser(downloadUrl)
  }

  async function handleCompute() {
    const { datasetDID, algoDid } = inputConfig.compute
    const response = await adapter.compute(datasetDID, algoDid)
    console.log(response)
  }

  async function handleAggregate() {
    const { guid } = inputConfig.aggregate
    const response = await adapter.aggregate(guid)
    console.log(response)
  }

  async function handleMultipleCompute() {
    const { datasetDIDs, algoDIDs, fedAlgoDid } = inputConfig.multipleCompute
    const response = await adapter.multipleCompute({datasetDIDs, algoDIDs}, fedAlgoDid)
    console.log(response)
  }

  async function handleGetJobStatus() {
    const { datasetDID, jobID } = inputConfig.getJobResults
    const response = await adapter.getJobStatus([datasetDID, jobID])
    console.log(response)
  }

  async function handleGetJobResults() {
    const { datasetDID, jobID } = inputConfig.getJobResults
    const response = await adapter.getJobResults([datasetDID, jobID])
    console.log(response)
  }

  async function handleDownloadJobResults() {
    const { jobID, resultIndex, datasetDid,destinationFolderPath } = inputConfig.downloadJobResults
    const response = await adapter.downloadJobResults([jobID, resultIndex,datasetDid, destinationFolderPath])
    console.log(response)
    await downloadFileToBrowser(response)
  }

  async function handleStopCompute() {
    const { datasetDID, jobID } = inputConfig.stopCompute
    const response = await adapter.stopCompute([datasetDID, jobID])
    console.log(response)
  }

  async function handleGetDDO() {
    const { datasetDID } = inputConfig.getDDO
    const response = await adapter.getDDO(datasetDID)
    console.log(response)
  }

  async function handleDisAllowAlgo() {
    const { datasetDID, algoDID } = inputConfig.disAllowAlgo
    const response = await adapter.disAllowAlgo([datasetDID, algoDID])
    console.log(response)
  }

  async function handleAllowAlgo() {
    const { datasetDID, algoDID } = inputConfig.allowAlgo
    const response = await adapter.allowAlgo([datasetDID, algoDID])
    console.log(response)
  }

  async function handleEditAsset() {
    const { datasetDID, updatedDDO } = inputConfig.editAsset
    const response = await adapter.editAsset([datasetDID, updatedDDO])
    console.log(response)
  }

  return (
    <div>
      {!adapter ? < div >
        <button onClick={function () {
          return setFlow('MM')
        }}>Metamask Flow</button>
        <button onClick={function () {
          return setFlow('AA')
        }}>Abstract Flow</button>
      </div> :
        <div>
          <>
            <button onClick={handlePublish}>Publish</button>
          </>
          <>
            <button onClick={handleDownload}>Purchase</button>
          </>
          <>
            <button onClick={handleCompute}>Compute</button>
          </>
          <>
            <button onClick={handleAggregate}>Aggregate</button>
          </>
          <>
            <button onClick={handleMultipleCompute}>Multiple-Compute</button>
          </>
          <>
            <button onClick={handleGetJobStatus}>Job-Status</button>
          </>
          <>
            <button onClick={handleGetJobResults}>Job-Results</button>
          </>
          <>
            <button onClick={handleDownloadJobResults}>DownloadJobResults</button>
          </>
          <>
            <button onClick={handleStopCompute}>StopCompute</button>
          </>
          <>
            <button onClick={handleGetDDO}>GetDDO</button>
          </>
          <>
            <button onClick={handleDisAllowAlgo}>Disallow Algo</button>
          </>
          <>
            <button onClick={handleAllowAlgo}>Allow Algo</button>
          </>
          <>
            <button onClick={handleEditAsset}>Edit dataset</button>
          </>
        </div>
      }
    </div >
  )
}

export default App
