// vite.config.js
import { defineConfig } from 'vite';
import fs from 'fs-extra';
import react from '@vitejs/plugin-react'
import { nodePolyfills } from 'vite-plugin-node-polyfills'


// Use the fs module from fs-extra in the browser environment
const browserFs = {
  ...fs,
  readFileSync: (path, encoding) => {
    // Implement a browser-compatible version of readFileSync if needed
    // For example, you can use fetch to read a file in the browser
    // Replace the following line with your implementation
    return fetch(path).then((response) => response.text());
  },
  // Add other fs methods as needed
};

export default defineConfig({
  // Your other Vite configuration options...

  // Alias fs to the browser-compatible fs module
  plugins: [react()],
  resolve: {
    alias: {
      fs: browserFs,
    },
  },
});