// Add any custom config to be passed to Jest
const config = {
  preset: 'ts-jest',
  verbose: true,
  testEnvironment: 'node',
  runner: 'jest-runner',
  rootDir: '../',
  // Add more setup options before each test is run
  setupFilesAfterEnv: ['<rootDir>/.jest/jest.setup.js'],
  // if using TypeScript with a baseUrl set to the root directory then you need the below for alias' to work
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'node'],
  collectCoverage: true,
  collectCoverageFrom: [
    'libs/**/*.{ts,tsx}',
  ],
  coveragePathIgnorePatterns: ['/node_modules/', '.index.tsx'],
  testPathIgnorePatterns: [
    'node_modules',
    '\\.cache',
    '.next',
    'coverage',
    // ignore the breaking big changes test fix
    'src/@context/Prices',
    '.storybook/storyshots.test.tsx',
    '.index.tsx'
  ],
  transform: {
    '^.+\\.ts$': 'ts-jest',
    '\\.[jt]sx?$': 'babel-jest'
  },
  transformIgnorePatterns: [
    'node_modules/(?!(is-url-superb|wagmi)/)',
    'node_modules/wagmi/dist/chains.js'
  ],
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/libs/$1', // This helps Jest resolve the modules correctly
  },
}
module.exports = config
