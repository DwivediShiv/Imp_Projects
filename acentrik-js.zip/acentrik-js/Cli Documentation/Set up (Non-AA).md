# Non-AA Account Set up

## 📚 Prerequisites

- node.js ([Install from here](https://nodejs.org/en/download/))

## 🏗 Installation & Usage

### Clone and install

```bash
$ git clone https://github.com/acentrik/acentrik-sdk.git
npm install
```

### Get SDK Paramters 
1. Log in to Acentrik Marketplace <br>
2. Visit sidebar <br>
3. Go to "Developer SDK" <br>
4. Copy SDK Paramters <br>
5. These will be your enviornment variables

### Set up environment variables
### NOTE: Private key of the metamask wallet must be taken up from metamask only in case of non account abstract flow

```bash
export PRIVATE_KEY="..."
```

```bash
export RPC_URL="..."
```

```bash
export INFURA_PROJECT_ID="..."
```

```bash
export OCEAN_AQUARIUS_URL="..."
```

```bash
export OCEAN_PROVIDER_URL="..."
```

```bash
export CHAIN_ID="..."
```

```bash
export SUBGRAPH_URI="..."
```
### Execute Cli Help Command 

List available commands

```bash
npm run cli help
```
