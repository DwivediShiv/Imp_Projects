# AA Account Set Up

## 📚 Prerequisites

- node.js ([Install from here](https://nodejs.org/en/download/))

## 🏗 Installation & Usage

### Clone and install

```bash
$ git clone https://github.com/acentrik/acentrik-sdk.git
npm install
```

### Get SDK Paramters 
1. Log in to Acentrik Marketplace <br>
2. Visit sidebar <br>
3. Go to "Developer SDK" <br>
4. Copy SDK Paramters <br>
5. These will be your enviornment variables

### Set up environment variables


```bash
export PRIVATE_KEY="..."
```

```bash
export RPC_URL="..."
```

```bash
export INFURA_PROJECT_ID="..."
```

```bash
export SMART_ACCOUNT_ADDRESS="..."
```
```bash
export OCEAN_AQUARIUS_URL="..."
```

```bash
export OCEAN_PROVIDER_URL="..."
```

```bash
export CHAIN_ID="..."
```
```bash
export SUBGRAPH_URI="..."
```
```bash
export API_KEY="..."
```
### Execute Cli Help Command 

List available commands

```bash
npm run cli help
```
