
# CLI References

This section contains:

1. [Methods](#methods) <br>
2. [Success Responses](#success-responses) <br>
3. [Error Responses](#error-responses) <br>

## Methods

> CLI tool to interact with the oceanprotocol's JavaScript library to privately & securely publish, consume, and run compute on data using **Account Abstraction**.

With Acentrik CLI, you can:

- **Publish** data services: downloadable files or compute-to-data.
- **Edit** existing assets.
- **Consume** data services, ordering datatokens, and downloading data.
- **Compute to data** on publicly available datasets using a published algorithm.

In this Ocean CLI, there are 13 methods to use to interact with the SDK as a provider or consumer.

1. ```bash
   npm run cli publish **metadataFilePath**
   ``` 
   Reads `metadataFilePath` and publishes a new asset with access service or compute service.

2. ```bash
   npm run cli getDDO **datasetDID**
   ``` 
   Gets DDO for an asset using the asset DID.

3. ```bash
   npm run cli editAsset **datasetDID metadataFilePath**
   ``` 
   Updates DDO using the metadata items in the file.

4. ```bash
   npm run cli download **datasetDID destinationFolderPath**
   ``` 
   Downloads an asset into the destination folder.

5. ```bash
   npm run cli allowAlgo **datasetDID algoDID**
   ``` 
   Approves an algorithm to run on a dataset.

6. ```bash
   npm run cli disallowAlgo **datasetDID algoDID**
   ``` 
   Removes an approved algorithm from the dataset's approved algorithms.

7. ```bash
   npm run cli getJobStatus **datasetDID jobDID**
   ``` 
   Displays the compute job status for the specified dataset and job.

8. ```bash
   npm run cli getJobResults **datasetDID jobDID**
   ``` 
   Displays the array containing compute results and log files for the specified dataset and job.

9. ```bash
   npm run cli downloadJobResults **jobID resultIndex datasetDid destinationFolderPath**
   ``` 
   Downloads compute job results for the specified datasets and algorithm.

10. ```bash
    npm run cli multipleCompute **federated-compute-inputFilePath AggAlgoDID**
    ``` 
    Starts multiple compute jobs on the mentioned datasets using the inputted algorithm's ID.

11. ```bash
    npm run cli stopCompute **datasetDID jobID**
    ``` 
    Stops the compute process for the mentioned dataset and job.

12. ```bash
    npm run cli aggregate **multipleC2D's guid**
    ``` 
    Starts aggregation of the multiple compute-to-data (C2D) results using the provided GUID when running multiple compute.

13. ```bash
    npm run cli compute **datasetDID algoDID** 
    ``` 
    Starts the compute process for the specified dataset and algorithm
    
## Success Responses

| Methods | Response (with examples) |
| --- | --- |
| npm run cli publish **metadataFilePath** | Asset published. ID: `did:op...` |
| npm run cli getDDO **datasetDID** | DDO: `{"@content"...}` |
| npm run cli editAsset **datasetDID metadataFilePath** | Result of edit asset: `{...}` <br> Edit Asset process completed |
| npm run cli download **datasetDID destinationFolderPath** | File downloaded successfully: `{destinationFolderPath}` |
| npm run cli allowAlgo **datasetDID algoDID** | Allow Algo command completed |
| npm run cli disallowAlgo **datasetDID algoDID** | Disallow Algo Command completed |
| npm run cli compute **datasetDID algoDID** | JobId: `job id` <br> result: `result` |
| npm run cli getJobStatus **datasetDID jobDID** | Job Status Result: <br> {} |
| npm run cli getJobResults **datasetDID jobDID**  | Job Results files: <br> {} |
| npm run cli downloadJobResults **jobID resultIndex datasetDid destinationFolderPath** | Job Result: {} <br> File downloaded successfully: `{datasetDIDsFilePath}` |
| npm run cli multipleCompute **datasetDIDsFilePath algoDID** | Compute jobs started: <br> Here is your guid -> `{guid}` <br> Here is the jobId: <br> `[ 'jobid1', 'jobid2' ]` |
| npm run cli aggregate **multipleC2D's guid** | jobIdAggregated ===> `job id` |
| npm run cli stopCompute **datasetDID jobID**|  stopped compute {} |

## Error Responses

| Error | Response Examples |
| --- | --- |
| Invalid environment variables  | errors: [{ validation: 'url', code: 'invalid_string', message: 'Please add valid RPC URL', path: [Array] }, { |
| Invalid JSON file input  | error while reading file: Syntax Error: Unexpected end of JSON input |
| Wrong file path input  | error while reading file: Error: ENOENT: no such file or directory, open  |
| Invalid dataset/algo DID  | Error fetching Asset with DID: 1234. Does this asset exist? |
| Invalid Job ID  | Error fetching Job with ID: 1234. Does this job exist? |
| Invalid result index e.g., 100 | Job results: undefined |
| Adding trusted algo for non-compute dataset  | Error getting computeService for datasetDID. Does this asset have a computeService? |
| Update another owner's asset  | You are not the owner of this asset, and therefore you cannot update it. |
| Insufficient funds to consume asset | Error ordering access for datasetDID. Do you have enough tokens? |
| Doing compute job with non-trusted algo | datasetDID is not allowed by the publisher to run on algoDID |
| Invalid DDO dataset did  | Error fetching DDO datasetDID.  Does this asset exists? |
| Invalid dataset did and algo did for compute job  |Error Cannot start compute job using the dataset DID & algorithm DID provided |
