# Cli Tutorials 

> Guided Tutorial on how to successfully execute Single Compute job and Multiple C2D aggregate

## Publish an Asset 

1. Create a json file with the following asset details for these assets. <br>
2. Add `organization` and `signer` details in asset details. <br>
3. Run this command to Publish the 5 assets provided below.
```baash 
npm run cli publish **metadataFilePath**
```
4.Note down the `did` for each asset. You will need it for later 
   

> 1-public-aggregate-algo-free.json

```bash
{
    "@context": [
      "https://w3id.org/did/v1"
    ],
    "id": "",
    "nftAddress": "",
    "version": "4.1.0",
    "chainId": 80002,
    "metadata": {
      "created": "",
      "updated": "",
      "type": "algorithm",
      "name": "[SDK] Free Public Aggregate Algorithm Sample",
      "description": "This description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
      "tags": ["SDK"],
      "author": "",
      "license": "https://market.oceanprotocol.com/terms",
      "categories": [
        "Blockchain"
      ],
      "additionalInformation": {
        "source": "ddmdevv3",
        "accessPermission": "allow",
        "organization": "",
        "signer": "",
        "algorithmType": "Aggregate"
      },
      "algorithm": {
        "language": "python3.7",
        "version": "0.1",
        "container": {
          "entrypoint": "python $ALGO",
          "image": "public.ecr.aws/acentrik/algo_dockers/python",
          "tag": "3.7-nonroot",
          "checksum": "sha256:bbdc482a459993f251c7d53841e19f30e37f941ae16d2d4b6127302c47363c95"
        }
      }
    },
    "services": [
      {
        "id": "3d3a67dec2355cb1b09fd902c265622ad063f6479218a82480a8b98fb111d2f9",
        "type": "access",
        "files": {
          "datatokenAddress": "0x0",
          "nftAddress": "0x0",
          "files": [
            {
              "type": "url",
              "url": "https://raw.githubusercontent.com/sd100596/randomDataset/main/aggregateAlgoCorrect.py",
              "method": "GET"
            }
          ]
        },
        "datatokenAddress": "",
        "serviceEndpoint": "https://provider.dev-v3.acentrik.io",
        "timeout": 86400,
        "description": "Long description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
        "additionalInformation": {
          "source": "ddmdevv3",
          "isExperimental": false,
          "sampleType": "URL",
          "links": [],
          "input": {
            "fileType": ""
        },
        "output": {
            "fileType": "",
            "screenshot": ""
        }
        }
      }
    ],
    "event": {
    },
    "nft": {
        "address": "",
        "name": "Acentrik Asset Management Token",
        "symbol": "AAMT-001",
        "state": 0,
        "tokenURI": "",
        "owner": "",
        "created": ""
    },
    "purgatory": {
      "state": false
    },
    "datatokens": [
    ],
    "stats": {
      "allocated": 0,
      "orders": 0,
      "price": {
        "value": "0"
      }
    }
  }
```
> 2-publish-free-aggregate-compute-dataset.json

```bash
{
    "@context": [
      "https://w3id.org/did/v1"
    ],
    "id": "",
    "nftAddress": "",
    "version": "4.1.0",
    "chainId": 80002,
    "metadata": {
      "created": "",
      "updated": "",
      "type": "dataset",
      "name": "[SDK] Free Aggregate Only Compute Sample",
      "description": "This description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
      "tags": ["SDK"],
      "author": "",
      "license": "https://market.oceanprotocol.com/terms",
      "categories": [
        "Blockchain"
      ],
      "additionalInformation": {
        "source": "ddmdevv3",
        "accessPermission": "allow",
        "organization": "",
        "signer": "",
        "aggregateC2D": true
      }
    },
    "services": [
      {
        "id": "fe5d100c9114573982cb89f637ba113a81447493ab16fdc0d8e0d11bc5bc7a07",
        "type": "compute",
        "files": {
          "datatokenAddress": "0x0",
          "nftAddress": "0x0",
          "files": [
            {
              "type": "url",
              "url": "https://raw.githubusercontent.com/sd100596/randomDataset/main/dataset1.csv",
              "method": "GET"
            }
          ]
        },
        "datatokenAddress": "0x6bdACb833094B83014dCaA6dEB53F7E9F75A8A7E",
        "serviceEndpoint": "https://provider.dev-v3.acentrik.io",
        "timeout": 86400,
        "compute": {
          "allowRawAlgorithm": false,
          "allowNetworkAccess": true,
          "publisherTrustedAlgorithmPublishers": [],
          "publisherTrustedAlgorithms": [
            {
              "did": "did:op:a133d5ebf602dcf573098e194042e562924e652c5de16a434f8e361205182115",
              "containerSectionChecksum": "159377d9e52a325d941bec267870285e16d849c5d0c75c2ed797ece12ef1021e",
              "filesChecksum": "7701d5d51e37aea4917692090995d9a2ac93e73b853492ae3f797efedc000d99"
            }
          ]
        },
        "description": "Long description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
        "additionalInformation": {
          "source": "ddmdevv3",
          "isExperimental": false,
          "sampleType": "URL",
          "links": [],
          "input": {
            "fileType": ""
          },
          "output": {
            "fileType": "",
            "screenshot": ""
          }
        }
      }
    ],
    "event": {
    },
    "nft": {
        "address": "",
        "name": "Acentrik Asset Management Token",
        "symbol": "AAMT-001",
        "state": 0,
        "tokenURI": "",
        "owner": "",
        "created": ""
    },
    "purgatory": {
      "state": false
    },
    "datatokens": [
    ],
    "stats": {
      "allocated": 0,
      "orders": 0,
      "price": {
        "value": "0"
      }
    }
}
```

>3-public-federated-algo-free.json

```bash
{
    "@context": [
      "https://w3id.org/did/v1"
    ],
    "id": "",
    "nftAddress": "",
    "version": "4.1.0",
    "chainId": 80002,
    "metadata": {
      "created": "",
      "updated": "",
      "type": "algorithm",
      "name": "[SDK] Free Public Federated Algorithm Sample",
      "description": "This description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
      "tags": ["SDK"],
      "author": "",
      "license": "https://market.oceanprotocol.com/terms",
      "categories": [
        "Blockchain"
      ],
      "additionalInformation": {
        "source": "ddmdevv3",
        "accessPermission": "allow",
        "organization": "",
        "signer": "",
        "relatedAggregateAlgorithms": [
          "did:op:a133d5ebf602dcf573098e194042e562924e652c5de16a434f8e361205182115"
        ],
        "algorithmType": "Federated"
      },
      "algorithm": {
        "language": "python3.7",
        "version": "0.1",
        "container": {
          "entrypoint": "python $ALGO",
          "image": "public.ecr.aws/acentrik/algo_dockers/python",
          "tag": "3.7-nonroot",
          "checksum": "sha256:bbdc482a459993f251c7d53841e19f30e37f941ae16d2d4b6127302c47363c95"
        }
      }
    },
    "services": [
      {
        "id": "1fbd28543fb30b33ebb917850a7bf75c110e529fbb9cd0e7c08c58e4dd82b163",
        "type": "access",
        "files": {
          "datatokenAddress": "0x0",
          "nftAddress": "0x0",
          "files": [
            {
              "type": "url",
              "url": "https://raw.githubusercontent.com/sd100596/randomDataset/main/fedAlgo1.py",
              "method": "GET"
            }
          ]
        },
        "datatokenAddress": "",
        "serviceEndpoint": "https://provider.dev-v3.acentrik.io",
        "timeout": 86400,
        "description": "Long description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
        "additionalInformation": {
          "source": "ddmdevv3",
          "isExperimental": true,
          "sampleType": "URL",
          "links": [],
          "input": {
            "fileType": ""
        },
        "output": {
            "fileType": "",
            "screenshot": ""
        }
        }
      }
    ],
    "event": {
    },
    "nft": {
      "address": "",
      "name": "Acentrik Asset Management Token",
      "symbol": "AAMT-001",
      "state": 0,
      "tokenURI": "",
      "owner": "",
      "created": ""
    },
    "purgatory": {
      "state": false
    },
    "datatokens": [
    ],
    "stats": {
      "allocated": 0,
      "orders": 0,
      "price": {
        "value": "0"
      }
    }
  }
```

> 4-free-compute-dataset.json
```bash
{
    "@context": [
      "https://w3id.org/did/v1"
    ],
    "id": "",
    "nftAddress": "",
    "version": "4.1.0",
    "chainId": 80002,
    "metadata": {
      "created": "",
      "updated": "",
      "type": "dataset",
      "name": "[SDK] Free Compute Sample 1",
      "description": "This description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
      "tags": ["SDK"],
      "author": "",
      "license": "https://market.oceanprotocol.com/terms",
      "categories": [
        "Blockchain"
      ],
      "additionalInformation": {
        "source": "ddmdevv3",
        "accessPermission": "allow",
        "organization": "",
        "signer": "",
        "aggregateC2D": false
      }
    },
    "services": [
      {
        "id": "4eeb9bcc6ec0d2116a869c3fd9bb70bc89f2de423b2d8247fa53db7a0696cfe7",
        "type": "compute",
        "files": {
          "datatokenAddress": "0x0",
          "nftAddress": "0x0",
          "files": [
            {
              "type": "url",
              "url": "https://raw.githubusercontent.com/sd100596/randomDataset/main/dataset1.csv",
              "method": "GET"
            }
          ]
        },
        "datatokenAddress": "",
        "serviceEndpoint": "https://provider.dev-v3.acentrik.io",
        "timeout": 86400,
        "compute": {
          "allowRawAlgorithm": false,
          "allowNetworkAccess": true,
          "publisherTrustedAlgorithmPublishers": [],
          "publisherTrustedAlgorithms": [
            {
              "did": "did:op:6d599f8237139292ccacd07227f46fb3801c480827f9a4446a1051f2e5bb0bc4",
              "containerSectionChecksum": "159377d9e52a325d941bec267870285e16d849c5d0c75c2ed797ece12ef1021e",
              "filesChecksum": "3a8043961f2fa2b585abbfd4fd2174a281bfa0b99b903628f7f0b5d81aa8bc3d"
            }
          ]
        },
        "description": "Long description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
        "additionalInformation": {
          "source": "ddmdevv3",
          "isExperimental": false,
          "sampleType": "URL",
          "links": [],
          "input": {
            "fileType": ""
          },
          "output": {
            "fileType": "",
            "screenshot": ""
          }
        }
      }
    ],
    "event": {
    },
    "nft": {
      "address": "",
      "name": "Acentrik Asset Management Token",
      "symbol": "AAMT-001",
      "state": 0,
      "tokenURI": "",
      "owner": "",
      "created": ""
    },
    "purgatory": {
      "state": false
    },
    "datatokens": [
    ],
    "stats": {
      "allocated": 0,
      "orders": 0,
      "price": {
        "value": "0"
      }
    }
  }
```
> 5-postpay-compute-dataset.json

```bash
{
  "@context": [
    "https://w3id.org/did/v1"
  ],
  "id": "",
  "nftAddress": "",
  "version": "4.1.0",
  "chainId": 80002,
  "metadata": {
    "created": "",
    "updated": "",
    "type": "dataset",
    "name": "[SDK] POSTPAY Set Price Compute Sample 1",
    "description": "This description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
    "tags": ["SDK"],
    "author": "",
    "license": "https://market.oceanprotocol.com/terms",
    "categories": [
      "Blockchain"
    ],
    "additionalInformation": {
      "source": "ddmdevv3",
      "accessPermission": "allow",
      "organization": "",
      "signer": "",
      "aggregateC2D": false,
      "postpayType": "setPrice",
      "price": "{\"tokenAddress\":\"0xD6E0EF71AECedA1d3c6A4a3BcfFCb2EB6bfaF469\",\"tokenSymbol\":\"KRISCOIN\",\"value\":\"10\"}"
    }
  },
  "services": [
    {
      "id": "4eeb9bcc6ec0d2116a869c3fd9bb70bc89f2de423b2d8247fa53db7a0696cfe7",
      "type": "compute",
      "files": {
        "datatokenAddress": "0x0",
        "nftAddress": "0x0",
        "files": [
          {
            "type": "url",
            "url": "https://raw.githubusercontent.com/sd100596/randomDataset/main/dataset1.csv",
            "method": "GET"
          }
        ]
      },
      "datatokenAddress": "",
      "serviceEndpoint": "https://provider.dev-v3.acentrik.io",
      "timeout": 86400,
      "compute": {
        "allowRawAlgorithm": false,
        "allowNetworkAccess": true,
        "publisherTrustedAlgorithmPublishers": [],
        "publisherTrustedAlgorithms": [
          {
            "did": "did:op:54b8acbd41ccf83679ebcfb21e23fed1ef3e6a185ecef1162f37f544464e0d09",
            "containerSectionChecksum": "159377d9e52a325d941bec267870285e16d849c5d0c75c2ed797ece12ef1021e",
            "filesChecksum": "3a8043961f2fa2b585abbfd4fd2174a281bfa0b99b903628f7f0b5d81aa8bc3d"
          }
        ]
      },
      "description": "Long description is written by SDK. Lorem ipsum is placeholder text commonly used for previewing layouts and visual mockups.",
      "additionalInformation": {
        "source": "ddmdevv3",
        "isExperimental": false,
        "sampleType": "URL",
        "links": [],
        "input": {
          "fileType": ""
        },
        "output": {
          "fileType": "",
          "screenshot": ""
        }
      }
    }
  ],
  "event": {
  },
  "nft": {
    "address": "",
    "name": "Acentrik Asset Management Token",
    "symbol": "AAMT-001",
    "state": 0,
    "tokenURI": "",
    "owner": "",
    "created": ""
  },
  "purgatory": {
    "state": false
  },
  "datatokens": [
  ],
  "stats": {
    "allocated": 0,
    "orders": 0,
    "price": {
      "value": "0"
    }
  }
}
```
## Add trusted algo
1. Add Federated algo did to `postpay-compute` asset and `free compute asset` using this commands.
``` bash
   npm run cli allowAlgo postpay-computeDID fedAlgoDID
```
``` bash
   npm run cli allowAlgo free-computeDID fedAlgoDID
```
2. Add Aggregate algo to aggregate compute asset(free-aggregate-compute). This is to add a placeholder asset for teh aggregate algorithm work to work.
``` bash
  npm run cli allowAlgo free-aggregate-computeDID AggAlgoDID
```
## Run single compute job

1. Run compute job of algoritm and compatible dataset. In this case we will be using Federate Algo and free--compute asset
2. Save the job id
```bash 
npm run cli compute **free-computeDID FedAlgoDID**
```

## Track Job Status 

1.Track Job status until its `Job Finished`.
```bash 
npm run cli getJobStatus **free-aggregate-computeDID jobDID**
```

## Get Job results

1.Get job results to see output files availble
2.Each result is and index starting from 0.

```bash
npm run cli getJobResults **free-aggregate-computeDID jobDID**

```
## Downlaod Job Results

1.Download an output file of finished compute job
```bash
npm run cli downloadJobResults jobID resultIndex datasetDid destinationFolderPath 
```
2.Check that output file has been downloaded 

## Run Multiple C2D and aggregate

1.Create `5-federated-compute-input.json` file with datasetsdid and fed algo did. The datasets in this case will be `postpay-compute` and `free compute`
>Json should look like this

```bash 
{
    "datasetDIDs": [
      "did:op:d49755ee238f2aafb0b195bbcd42da620af7cda6f6d1366db51dd6a879fc949f",
      "did:op:36b139eb23f7f9065a4f52cbc97232319213ff6aad5f8488e5415829cae21a46"
    ],
    "algoDIDs": [
      "did:op:558a990acf4d10094ed401bc6923864814936760c4c86550f5cc4d1f64d8bddd"
    ]
}
```
2.Run this command to start multiple c2d and aggregate.
3.Note when running command algorithm should be Aggregate Algo did.
```bash
npm run cli multipleCompute **federated-compute-inputFilePath AggAlgoDID** 
```
3.Note `guid id`.

## Aggregate Job

1.Once the multiple c2d jobs are completed. We can start the aggregate job.
```bash 
npm run cli aggregate multipleC2D's guid 
```

You have succesfully completed the tutorial! :)



