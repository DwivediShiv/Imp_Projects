# Set
node ./scripts/load-development-addresses.js