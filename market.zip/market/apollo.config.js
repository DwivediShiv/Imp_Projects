require('dotenv').config()

const appConfig = require('./app.config')
const subgraphUri =
  (!appConfig.network.includes('#(NEXT_PUBLIC_NETWORK)#') &&
    appConfig.networkConfig[appConfig.network].subgraphUri) ||
  'https://subgraph-amoy.ap-southeast-1-381948199601.acentrik.io'

module.exports = {
  client: {
    service: {
      name: 'ocean',
      url: `${subgraphUri}/subgraphs/name/oceanprotocol/ocean-subgraph`,
      // optional disable SSL validation check
      skipSSLValidation: true
    }
  }
}
