import useTransferOwnership, { OwnershipTransferErrors } from '..'
import { TransactionManager } from '@utils/biconomy/transactionManager'
import {
  CreateSessionDataParams,
  SessionKeyManagerModule
} from '@biconomy/modules'
import { BiconomySmartAccountV2 } from '@biconomy/account'
import { OrgSessionDataStorage } from '@utils/socialLogin/OrgSessionDataStorage'
import {
  getAbstractOrgDataHandler,
  getProfileRolesHandler
} from '../msw/apiHandler'
import { SessionLeafNode } from '@biconomy/modules/dist/src/interfaces/ISessionStorage'
import { waitFor, renderHook } from '@testing-library/react'
import { WagmiBiconomySocialLogin } from '@utils/socialLogin/WagmiBiconomySocialLogin'
import { defaultAbiCoder } from 'ethers/lib/utils.js'
import { orgDetails, walletRoles } from '../msw/dataHandler'
import appConfig from 'app.config'
import { useWagmiSocialLogin } from '@hooks/useWagmiSocialLogin'
import { useAccount } from 'wagmi'
import { getTechnicalNetworkName } from '@utils/network'

jest.mock('@utils/roles', () => ({
  getIsWalletHasRole: jest.fn(() => true)
}))

jest.mock('@utils/network', () => ({
  getTechnicalNetworkName: jest.fn(() => 'amoy'),
  getCustomConfig: jest.fn(() => null),
  findProviderUri: jest.fn(() => null),
  getOceanConfig: jest.fn(() => null)
}))

jest.mock('wagmi', () => ({
  useAccount: jest.fn().mockReturnValue({
    address: '0x0000000000000000000000000000000000000000'
  }),
  createClient: jest.fn()
}))

describe.skip('useEoaLinkageHook', () => {
  let mockBiconomySocialLogin: WagmiBiconomySocialLogin
  let mockSkMgrModule: SessionKeyManagerModule
  let mockTransactionManager: TransactionManager
  let mockSmartAccountV2: BiconomySmartAccountV2
  let newOwnerEoa: string
  let mockSessionStorage: OrgSessionDataStorage
  let storedSessionKeyData: SessionLeafNode[]
  let userId: string
  const chainId = 1234

  beforeEach(async () => {
    userId = 'userId'
    getAbstractOrgDataHandler()
    getProfileRolesHandler(userId)

    mockSessionStorage = new OrgSessionDataStorage('OrgId')
    jest.spyOn(mockSessionStorage, 'getAllSessionData')
    jest.spyOn(mockSessionStorage, 'addUserSessionKey')
    jest.spyOn(mockSessionStorage, 'removeUserSessionKey')
    mockSessionStorage.removeSessionData = jest.fn().mockReturnValue([])
    mockSessionStorage.initiateMerkleTransaction = jest
      .fn()
      .mockResolvedValue('mockedTransactionHash')
    mockSessionStorage.updateSessionKeysInDataStorage = jest
      .fn()
      .mockResolvedValue(undefined)

    storedSessionKeyData = orgDetails.sessionKey.sessionKeys
    newOwnerEoa = walletRoles.wallets[0].address
    mockSkMgrModule = {
      createSessionData: jest.fn().mockResolvedValue({ data: 'mockedData' }),
      getAddress: jest.fn().mockReturnValue('mockedAddress'),
      sessionStorageClient: mockSessionStorage
    } as unknown as SessionKeyManagerModule

    mockTransactionManager = {
      initiateBiconomyTransaction: jest
        .fn()
        .mockReturnValue('mockedTransactionHash')
    } as unknown as TransactionManager

    mockSmartAccountV2 = {
      getAccountAddress: jest.fn().mockReturnValue('smartAccountAddress')
    } as unknown as BiconomySmartAccountV2

    mockBiconomySocialLogin = {
      getSmartAccount: jest.fn().mockReturnValue(mockSmartAccountV2),
      getSessionKeyManagerModule: jest.fn().mockReturnValue(mockSkMgrModule),
      getTransactionManager: jest.fn().mockReturnValue(mockTransactionManager),
      getSigner: jest.fn().mockReturnValue({
        getChainId: jest.fn().mockResolvedValue(chainId)
      })
    } as unknown as WagmiBiconomySocialLogin
  })

  afterEach(() => {
    jest.clearAllMocks()
  })

  it('should add currentOwner and remove newOwner from session keys on successful execution', async () => {
    const { result: connectedAccount } = renderHook(() => useAccount())
    const superAdminEoa = connectedAccount.current.address

    const { result: wagmiResult } = renderHook(() => useWagmiSocialLogin())
    wagmiResult.current.biconomySocialLogin = mockBiconomySocialLogin

    const { result } = renderHook(() => useTransferOwnership())
    await waitFor(async () => {
      await result.current.transferSmartAccountOwnership(userId)
    })

    const validationModule =
      appConfig.validationSmartContracts[getTechnicalNetworkName(chainId)]
        ?.orgAdmin

    const newSessionParam: CreateSessionDataParams = {
      sessionPublicKey: superAdminEoa,
      validAfter: 0,
      validUntil: 0,
      sessionKeyData: defaultAbiCoder.encode(['address'], [superAdminEoa]),
      sessionValidationModule: validationModule
    }
    expect(
      (mockSkMgrModule.sessionStorageClient as OrgSessionDataStorage)
        .removeUserSessionKey
    ).toHaveBeenCalledWith(newOwnerEoa)

    expect(
      (mockSkMgrModule.sessionStorageClient as OrgSessionDataStorage)
        .addUserSessionKey
    ).toHaveBeenCalledWith(newSessionParam)

    const existingSessionParams = storedSessionKeyData.map(
      ({ sessionID, status, ...rest }) => rest
    )

    expect(mockSkMgrModule.createSessionData).toHaveBeenCalledWith([
      ...existingSessionParams,
      newSessionParam
    ])

    await waitFor(() => {
      expect(result.current.transactionHash).toBe('mockedTransactionHash')
    })

    await waitFor(() => {
      expect(result.current.transferOwnershipError).toBe(null)
    })
  })

  it('should handle errors in case smart account not initialized properly', async () => {
    mockBiconomySocialLogin.getSmartAccount = jest.fn().mockReturnValue(null)

    const { result: wagmiResult } = renderHook(() => useWagmiSocialLogin())
    wagmiResult.current.biconomySocialLogin = mockBiconomySocialLogin

    const { result } = renderHook(() => useTransferOwnership())

    await waitFor(async () => {
      await result.current.transferSmartAccountOwnership(userId)
    })

    const errorMessage = OwnershipTransferErrors.smartAccountError

    await waitFor(() => {
      expect(result.current.transferOwnershipError).toBe(errorMessage)
    })
  })

  it('should handle errors in case there is no active wallet', async () => {
    const { result: wagmiResult } = renderHook(() => useWagmiSocialLogin())
    wagmiResult.current.biconomySocialLogin = mockBiconomySocialLogin

    getProfileRolesHandler(userId, {
      response: { data: { roles: [], wallets: [] } }
    })

    const { result } = renderHook(() => useTransferOwnership())

    await waitFor(async () => {
      await result.current.transferSmartAccountOwnership(userId)
    })

    const errorMessage = OwnershipTransferErrors.walletError

    await waitFor(() => {
      expect(result.current.transferOwnershipError).toBe(errorMessage)
    })
  })

  it('should handle errors in case of error in Transfering ownership', async () => {
    mockTransactionManager.initiateBiconomyTransaction = jest
      .fn()
      .mockRejectedValue('Rejected Error')
    mockBiconomySocialLogin.getTransactionManager = jest
      .fn()
      .mockReturnValue(mockTransactionManager)

    const { result: wagmiResult } = renderHook(() => useWagmiSocialLogin())
    wagmiResult.current.biconomySocialLogin = mockBiconomySocialLogin

    const { result } = renderHook(() => useTransferOwnership())

    await waitFor(async () => {
      await result.current.transferSmartAccountOwnership(userId)
    })
    const errorMessage = OwnershipTransferErrors.transferError

    await waitFor(() => {
      expect(result.current.transferOwnershipError).toBe(errorMessage)
    })
  })

  it('should return active wallet', async () => {
    let activeWallet: string
    const { result } = renderHook(() => useTransferOwnership())

    await waitFor(async () => {
      activeWallet = await result.current.getActiveWallet(userId)
    })

    expect(activeWallet).toBe(walletRoles.wallets[0].address)
  })
})
