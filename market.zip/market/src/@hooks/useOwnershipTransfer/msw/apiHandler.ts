import { rest } from 'msw'
import { server } from '@utils/msw'
import { getAbstractOrgUrl, getProfileRoleUrl } from '@utils/api'
import { orgDetails, walletRoles } from './dataHandler'
import {
  AbstractDetails,
  ApiResponse,
  MswHandlerProps,
  UserProfileRoles
} from '../types'

export function getAbstractOrgDataHandler(
  props?: MswHandlerProps<AbstractDetails>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(getAbstractOrgUrl(), async (_, res, ctx) => {
    let json: ApiResponse<AbstractDetails>
    const data = orgDetails

    if (props?.response) {
      json = props.response
    } else {
      json = {
        data
      }
    }
    return res(ctx.status(statusCode), ctx.json(json))
  })
  server.use(handler)
}

export function getProfileRolesHandler(
  userId: string,
  props?: MswHandlerProps<UserProfileRoles>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(getProfileRoleUrl(userId), async (_, res, ctx) => {
    let json: ApiResponse<UserProfileRoles>
    const data = walletRoles
    if (props?.response) {
      json = props.response
    } else {
      json = {
        data
      }
    }
    return res(ctx.status(statusCode), ctx.json(json.data))
  })
  server.use(handler)
}
