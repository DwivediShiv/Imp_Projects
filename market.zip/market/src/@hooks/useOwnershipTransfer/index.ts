import {
  CreateSessionDataParams,
  DEFAULT_ECDSA_OWNERSHIP_MODULE
} from '@biconomy/modules'
import { OrgSessionDataStorage } from '@utils/socialLogin/OrgSessionDataStorage'
import { defaultAbiCoder, parseEther } from 'ethers/lib/utils.js'
import { useCallback, useState } from 'react'
import { getWalletAssignRoles } from '@utils/wallet'
import { UserProfileRoles } from '../../@types/User'
import { getIsWalletHasRole } from '@utils/roles'
import { WALLET_ACTIVE } from '@utils/authorization.constant'
import { Transaction } from '@biconomy/core-types'
import appConfig from 'app.config'
import { ethers } from 'ethers'
import { useWagmiSocialLogin } from '../useWagmiSocialLogin'
import { useAccount } from 'wagmi'
import { ECDSA_ABI } from '@utils/biconomy/abiCollection'
import { getTechnicalNetworkName } from '@utils/network'

export const OwnershipTransferErrors = {
  walletError: 'No active Wallet linked to the User',
  smartAccountError: 'Error occured while creating Smart Account',
  transferError: 'Error in transferring ownership for smart account',
  emptyValidationModule: 'No validation module found for given role'
}

export default function useTransferOwnership() {
  const [transferOwnershipError, setTransferOwnershipError] = useState<
    string | null
  >('')
  const [transactionHash, setTransactionHash] = useState<string | null>('')
  const { biconomySocialLogin, setAbortUpdate } = useWagmiSocialLogin()
  const { address } = useAccount()
  const smartAccount = biconomySocialLogin?.getSmartAccount()
  const skMgrModule = biconomySocialLogin?.getSessionKeyManagerModule()
  const transactionManager = biconomySocialLogin?.getTransactionManager()

  const initiateTransaction = useCallback(
    async (transactionsData: Transaction[]) => {
      const transactionHash =
        await transactionManager.initiateBiconomyTransaction(
          '',
          transactionsData
        )
      return transactionHash
    },
    [transactionManager]
  )

  const getActiveWallet = useCallback(async (userId: string) => {
    setTransferOwnershipError(null)
    const profileRole: UserProfileRoles = await getWalletAssignRoles(userId)
    if (!profileRole?.wallets || profileRole.wallets.length === 0) {
      return
    }
    for (const wallet of profileRole?.wallets || []) {
      if (
        getIsWalletHasRole(profileRole?.wallets, wallet.address, WALLET_ACTIVE)
      ) {
        return wallet.address
      }
    }
  }, [])

  const transferSmartAccountOwnership = useCallback(
    async (newOwnerId: string) => {
      setAbortUpdate(true)
      setTransferOwnershipError(null)
      setTransactionHash(null)
      const newOwnerEoa = await getActiveWallet(newOwnerId)
      const chainId = await biconomySocialLogin?.getSigner()?.getChainId()

      if (!newOwnerEoa) {
        setTransferOwnershipError(OwnershipTransferErrors.walletError)
        return
      }

      if (!skMgrModule || !smartAccount || !transactionManager || !chainId) {
        setTransferOwnershipError(OwnershipTransferErrors.smartAccountError)
        return
      }
      const smartAccountAddress = await smartAccount?.getAccountAddress()

      const ecdsaModuleRegistryInterface = new ethers.utils.Interface(ECDSA_ABI)

      const ecdsaOwnershipTransferData =
        ecdsaModuleRegistryInterface.encodeFunctionData('transferOwnership', [
          newOwnerEoa
        ])

      const ownershipTransferData: Transaction = {
        to: DEFAULT_ECDSA_OWNERSHIP_MODULE,
        value: parseEther('0'),
        data: ecdsaOwnershipTransferData
      }

      const OrgSessionStorage =
        skMgrModule.sessionStorageClient as OrgSessionDataStorage
      const validationModule =
        appConfig.validationSmartContracts[getTechnicalNetworkName(chainId)]
          ?.orgAdmin
      if (!validationModule) {
        setTransferOwnershipError(OwnershipTransferErrors.emptyValidationModule)
        return
      }

      const baseTokenAddress =
        appConfig?.stableCoin[getTechnicalNetworkName(chainId)]?.address

      // eslint-disable-next-line testing-library/no-await-sync-query
      const baseTokenBytecodeHash = await biconomySocialLogin.getBytecodeHash(
        baseTokenAddress
      )

      const superAdminEoa = address.toLowerCase()
      const sessionData = defaultAbiCoder.encode(
        ['address', 'address', 'bytes32'],
        [superAdminEoa, smartAccountAddress, baseTokenBytecodeHash]
      )

      try {
        const newSessionParam: CreateSessionDataParams = {
          sessionPublicKey: superAdminEoa,
          validAfter: 0,
          validUntil: 0,
          sessionKeyData: sessionData,
          sessionValidationModule: validationModule
        }

        const finalSessionKeys: CreateSessionDataParams[] =
          await OrgSessionStorage.replaceSessionKey(
            newSessionParam,
            newOwnerEoa
          )

        const merkleData = await biconomySocialLogin.getMerkleTransactionData(
          finalSessionKeys
        )

        const sessionTransactionData: Transaction = {
          to: skMgrModule.getAddress(),
          value: parseEther('0'),
          data: merkleData
        }

        const transactionsData: Transaction[] = []
        transactionsData.push(sessionTransactionData)
        transactionsData.push(ownershipTransferData)

        const transactionHash = await initiateTransaction(transactionsData)

        if (transactionHash) {
          skMgrModule.merkleTree.resetTree()
          OrgSessionStorage.resetStorageSessionKeys()
          await skMgrModule.createSessionData(finalSessionKeys)
        }

        if (!transactionHash) {
          setTransferOwnershipError(OwnershipTransferErrors.transferError)
        } else {
          await OrgSessionStorage.updateSessionKeysInDataStorage()
        }
        setTransactionHash(transactionHash)
        return transactionHash
      } catch (e) {
        console.error('OwnerShip Transfer Error: ', e)
        setTransferOwnershipError(OwnershipTransferErrors.transferError)
        setTransactionHash(null)
      } finally {
        setAbortUpdate(false)
      }
    },
    [smartAccount, skMgrModule, transactionManager]
  )

  return {
    getActiveWallet,
    transactionHash,
    setTransferOwnershipError,
    transferOwnershipError,
    transferSmartAccountOwnership
  }
}
