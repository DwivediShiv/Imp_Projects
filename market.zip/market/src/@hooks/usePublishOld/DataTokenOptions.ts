export interface DataTokenOptions {
  cap?: string
  name?: string
  symbol?: string
}
