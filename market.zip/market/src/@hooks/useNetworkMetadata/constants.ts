import { getOceanConfig } from '@utils/ocean'

function getConfig(id: number, label: string) {
  try {
    return getOceanConfig(id)
  } catch (error) {
    console.error(`Error getting Ocean config for ${label}:`, error)
  }
}

const configGaiaX = getConfig(2021000, 'GaiaX')
const configSupernetTestnet = getConfig(81001, 'Supernet Testnet')
const configGenXTestnet = getConfig(100, 'Gen-X Testnet')
const configAcentrikTestnet = getConfig(13520, 'acentrik-testnet')

export const networkDataGaiaX: EthereumListsChain = {
  name: 'GAIA-X Testnet',
  chainId: 2021000,
  shortName: 'GAIA-X',
  chain: 'GAIA-X',
  networkId: 2021000,
  nativeCurrency: { name: 'Gaia-X', symbol: 'GX', decimals: 18 },
  rpc: [configGaiaX.nodeUri],
  faucets: [
    'https://faucet.gaiaxtestnet.oceanprotocol.com/',
    'https://faucet.gx.gaiaxtestnet.oceanprotocol.com/'
  ],
  infoURL: 'https://www.gaia-x.eu',
  explorers: [{ name: '', url: '', standard: '' }]
}

export const networkDataSupernetTestnet: EthereumListsChain = {
  name: 'Supernet Testnet',
  chainId: 81001,
  shortName: 'EDGE',
  chain: 'EDGE',
  networkId: 81001,
  nativeCurrency: { name: 'Edge', symbol: 'EDGE', decimals: 18 },
  rpc: [configSupernetTestnet.nodeUri],
  faucets: ['https://faucet-edgenet.polygon.technology/'],
  infoURL: '',
  explorers: [
    {
      name: 'polygonedgenetscan',
      url: 'https://explorer-edgenet.polygon.technology',
      standard: 'EIP3091'
    }
  ]
}

export const networkDataGenXTestnet: EthereumListsChain = {
  name: 'Gen-X Testnet',
  chainId: 100,
  shortName: 'GX',
  chain: 'GX',
  networkId: 100,
  nativeCurrency: { name: 'GX', symbol: 'GX', decimals: 18 },
  rpc: [configGenXTestnet.nodeUri],
  faucets: [],
  infoURL: '',
  explorers: [
    {
      name: 'genxscan',
      url: 'https://logging.genx.minimal-gaia-x.eu',
      standard: 'EIP3091'
    }
  ]
}

export const networkDataAcentrikTestnet: EthereumListsChain = {
  name: 'Acentrik Testnet',
  chainId: 13520,
  shortName: 'AT',
  chain: 'AT',
  networkId: 13520,
  nativeCurrency: { name: 'Acentrik Matic', symbol: 'aMatic', decimals: 18 },
  rpc: [configAcentrikTestnet.nodeUri],
  faucets: [],
  infoURL: ''
  // explorers: [
  //   {
  //     name: 'blockscout',
  //     url: 'https://explorer-edgenet.polygon.technology',
  //     standard: 'EIP3091'
  //   }
  // ]
}

export function isSupernet(networkId: number) {
  return networkId === 81001
}
