import { getTechnicalNetworkName } from '@utils/network'
import { networkDataGaiaX } from './constants'
import networkdata from '../../../content/networks-metadata.json'
const networksList: EthereumListsChain[] = networkdata
export enum NetworkType {
  Mainnet = 'mainnet',
  Testnet = 'testnet'
}

export function getNetworkType(network: EthereumListsChain): string {
  // HEADS UP! Hack for getting network's type main/test, without using
  // .network field, which is innexistent on https://chainid.network/chains.json
  // We hack in mainnet detection for moonriver.
  if (
    network &&
    !network.name.includes('Testnet') &&
    !network.title?.includes('Testnet') &&
    network.name !== 'Moonbase Alpha'
  ) {
    return NetworkType.Mainnet
  } else {
    return NetworkType.Testnet
  }
}

export function getNetworkDisplayNames(networkIds: number[]): string {
  return networkIds.reduce((acc: string, networkId) => {
    const networkName = getTechnicalNetworkName(networkId)
      ? getTechnicalNetworkName(networkId)
      : ''
    return acc.length === 0 ? networkName : `${acc},${networkName}`
  }, '')
}

export function getNetworkDisplayName(
  data: EthereumListsChain,
  networkId?: number,
  isFancy?: boolean
): string {
  networkId = networkId || data?.chainId
  let displayName
  if (!networkId) return 'Unknown'
  switch (networkId) {
    case 137:
      displayName = isFancy ? 'mainnet' : 'Polygon mainnet'
      break
    case 10:
      displayName = 'OP mainnet'
      break
    case 1287:
      displayName = 'Moonbase alpha'
      break
    case 1285:
      displayName = 'Moonriver'
      break
    case 4:
      displayName = 'Rinkeby testnet'
      break
    case 5:
      displayName = isFancy ? 'goerli' : 'Goerli testnet'
      break
    case 11155111:
      displayName = isFancy ? 'sepolia' : 'Sepolia testnet'
      break
    case 80002:
      displayName = isFancy ? 'amoy' : 'Polygon Amoy'
      break
    case 81001:
      displayName = isFancy ? 'supernet' : 'Polygon supernet'
      break
    case 8996:
      displayName = isFancy ? 'development' : 'Development'
      break
    case 3:
      displayName = 'ETH ropsten'
      break
    case 2021000:
      displayName = 'GAIA-X testnet'
      break
    case 100:
      displayName = 'Gen-X testnet'
      break
    case 13520:
      displayName = 'Acentrik testnet'
      break
    default:
      displayName = data
        ? `${data.chain}${
            getNetworkType(data) === 'mainnet' ? '' : ` ${data.name}`
          }`
        : 'Unknown'
      break
  }

  return displayName
}

export function getNetworkDataById(
  data: EthereumListsChain[],
  networkId: number
): EthereumListsChain {
  if (!networkId) return
  const networkData = data.filter(
    (chain: EthereumListsChain) => chain.chainId === networkId
  )

  return networkId === 2021000 ? networkDataGaiaX : networkData[0]
}

export function filterNetworksByType(
  type: 'mainnet' | 'testnet',
  chainIds: number[],
  networksList: EthereumListsChain[]
): number[] {
  const finalNetworks = chainIds.filter((chainId: number) => {
    const networkData = getNetworkDataById(networksList, chainId)

    // HEADS UP! Only networkData.network === 'mainnet' is consistent
    // while not every test network in the network data has 'testnet'
    // in its place. So for the 'testnet' case filter for all non-'mainnet'.
    //
    // HEADS UP NO. 2! We hack in mainnet detection for moonriver as their
    // network data uses the `network` key wrong over in
    // https://github.com/ethereum-lists/chains/blob/master/_data/chains/eip155-1285.json
    //
    return type === getNetworkType(networkData)
  })
  return finalNetworks
}

export function fancyCheckIsTestnet(chainId: number): boolean {
  const networkData = getNetworkDataById(networksList, chainId)
  const isTestnet = getNetworkType(networkData) !== NetworkType.Mainnet
  return isTestnet
}
