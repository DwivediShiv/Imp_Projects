import { LoginParams } from '../../@types/SmartAccount'

export interface UseSiteMetadata {
  siteTitle: string
  siteTagline: string
  siteUrl: string
  siteIcon: string
  siteImage: any
  copyright: string
  menu: {
    name: string
    link?: string
    private?: boolean
    subMenu?: {
      name: string
      private?: boolean
      link?: string
    }[]
  }[]
  announcement: string
  warning: {
    ctd: string
  }
  appConfig: {
    network: string
    conversationContext: string
    idleLogoutTime: string
    walletConnectProjectId: string
    metadataCacheUri: string
    v3MetadataCacheUri: string
    v3MarketUri: string
    chainIds: any
    chainIdsSupported: any
    infuraProjectId: string
    testNetSymbol: string
    socialLogin: LoginParams
    defaultDatatokenTemplateIndex: number
    rbac: {
      url: string
      validateMechanism: string
      authService: string
    }
    marketFeeAddress: string
    publisherMarketOrderFee: string
    publisherMarketPoolSwapFee: string
    publisherMarketFixedSwapFee: string
    consumeMarketOrderFee: string
    consumeMarketPoolSwapFee: string
    consumeMarketFixedSwapFee: string
    currencies: string[]
    coingeckoTokenIds: string[]
    stableCoin: {
      goerli: {
        address: string
        ticker: string
        decimals: number
      }
      sepolia: {
        address: string
        ticker: string
        decimals: number
      }
      polygon: {
        address: string
        ticker: string
        decimals: number
      }
      amoy: {
        address: string
        ticker: string
        decimals: number
      }
      supernetTestnet: {
        address: string
        ticker: string
        decimals: number
      }
      'gen-x-testnet': {
        address: string
        ticker: string
        decimals: number
      }
      'acentrik-testnet'?: {
        address: string
        ticker: string
        decimals: number
      }
    }
    transaction: {
      goerli: {
        gasEstimateNftAddress: string
        gasEstimateNftOwnerAddress: string
        transactionBlockTimeout: number
        transactionConfirmationBlocks: number
        transactionPollingTimeout: number
        gasFeeMultiplier: number
        periodicCheckTransactionDuration: number
        periodicCheckTransactionCycle: number
      }
      sepolia: {
        gasEstimateNftAddress: string
        gasEstimateNftOwnerAddress: string
        transactionBlockTimeout: number
        transactionConfirmationBlocks: number
        transactionPollingTimeout: number
        gasFeeMultiplier: number
        periodicCheckTransactionDuration: number
        periodicCheckTransactionCycle: number
      }
      polygon: {
        gasEstimateNftAddress: string
        gasEstimateNftOwnerAddress: string
        transactionBlockTimeout: number
        transactionConfirmationBlocks: number
        transactionPollingTimeout: number
        gasFeeMultiplier: number
        periodicCheckTransactionDuration: number
        periodicCheckTransactionCycle: number
      }
      amoy: {
        gasEstimateNftAddress: string
        gasEstimateNftOwnerAddress: string
        transactionBlockTimeout: number
        transactionConfirmationBlocks: number
        transactionPollingTimeout: number
        gasFeeMultiplier: number
        periodicCheckTransactionDuration: number
        periodicCheckTransactionCycle: number
      }
      supernetTestnet: {
        transactionBlockTimeout: number
        transactionConfirmationBlocks: number
        transactionPollingTimeout: number
        gasFeeMultiplier: number
        periodicCheckTransactionDuration: number
        periodicCheckTransactionCycle: number
      }
      'gen-x-testnet': {
        transactionBlockTimeout: number
        transactionConfirmationBlocks: number
        transactionPollingTimeout: number
        gasFeeMultiplier: number
        periodicCheckTransactionDuration: number
        periodicCheckTransactionCycle: number
      }
      'acentrik-testnet'?: {
        gasEstimateNftAddress: string
        gasEstimateNftOwnerAddress: string
        transactionBlockTimeout: number
        transactionConfirmationBlocks: number
        transactionPollingTimeout: number
        gasFeeMultiplier: number
        periodicCheckTransactionDuration: number
        periodicCheckTransactionCycle: number
      }
      progressStepperAttentionCountdown: number
      retry: number
    }
    portisId: string
    analyticsId: string
    computeOutputExpiry: string
    allowFixedPricing: string
    allowDynamicPricing: string
    allowFreePricing: string
    allowHttpAssetEndpoint: string
    source: string
    networkConfig: {
      multiChainEncryptionProviderUri: string
      goerli: {
        providerUri: string
        subgraphUri: string
        marketFeeAddress: string
        encryptionProviderUri: string
        rpc: string
      }
      sepolia: {
        providerUri: string
        subgraphUri: string
        marketFeeAddress: string
        encryptionProviderUri: string
        rpc: string
      }
      polygon: {
        providerUri: string
        subgraphUri: string
        marketFeeAddress: string
        encryptionProviderUri: string
        rpc: string
      }
      amoy: {
        providerUri: string
        subgraphUri: string
        marketFeeAddress: string
        encryptionProviderUri: string
        rpc: string
      }
      supernetTestnet: {
        providerUri: string
        subgraphUri: string
        marketFeeAddress: string
        encryptionProviderUri: string
        rpc: string
      }
      'gen-x-testnet': {
        providerUri: string
        subgraphUri: string
        marketFeeAddress: string
        encryptionProviderUri: string
        rpc: string
      }
      'acentrik-testnet'?: {
        providerUri: string
        subgraphUri: string
        marketFeeAddress: string
        encryptionProviderUri: string
        rpc: string
      }
    }
    ipfs: {
      gatewayUri: string
      uploadLimit: string
      eulaUploadLimit: string
      imageUploadLimit: string
    }
    api: string
    site: {
      baseUrl: string
      termsAndConditionsUrl: string
      matomoBaseUrl: string
      matomoSiteId: number
      isEnableMatomo: string
      cookieSecure: string
      webPortalUrl: string
      assetManagementTokenSymbolPrefix: string
      assetManagementTokenName: string
      assetManagementTokenImageUrl: string
      assetManagementTokenImageBackground: string
    }
    allowAdvancedSettings: string
    allowAdvancedPublishSettings: string
    credentialType: string
    supportEmail: string
    requestTimeout: number
    defaultPrivacyPolicySlug: string
    privacyPreferenceCenter: string
    darkModeConfig: {
      classNameDark: string
      classNameLight: string
      storageKey: string
    }
    customization: {
      isDisableUnlimitedTimeout: string
      isDisableParameterizeAsset: string
      isDisableCustomDocker: string
      isDisableCustomDockerValidation: string
      isDisableRbacMultipleCredentialType: string
      isDisableDeveloperDetail: string
      isDisableCompanyNameChangeAcknowledgement: string
      companyNameChangeDate: string
      theme: string
      isDisableFilterByContract: string
      dateFormat: string
      bucketName: string
    }
  }
}
