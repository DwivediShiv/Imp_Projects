import { useContext } from 'react'
import { WagmiBiconomyLoginContext } from '@context/WagmiSocialLogin/context'

export const useWagmiSocialLogin = () => useContext(WagmiBiconomyLoginContext)
