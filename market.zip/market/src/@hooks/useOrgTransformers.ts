export const transformDataWithOrgName = (response, organisationMap) => {
  const dataList = response?.map((item) => {
    return { ...item, orgName: organisationMap[item?.orgId] }
  })
  return dataList
}

export const tranformedOrgFilters = (orgIdFilter, organisationMap) => {
  const orgFilterList = orgIdFilter?.reduce((acc, curr) => {
    acc.push({ orgId: curr, orgName: organisationMap[curr] })
    return acc
  }, [])
  return orgFilterList
}

export const getIdByName = (dataMap, name) => {
  return Object.keys(dataMap).find((key) => dataMap[key] === String(name))
}

export const getFilterIds = (dataMap, filterArray): string[] => {
  const orgIds = filterArray?.map((name) => getIdByName(dataMap, name))
  return orgIds
}
