import { useState, useEffect, useCallback } from 'react'
import { LoggerInstance } from '@oceanprotocol/lib'
import { useMarketMetadata } from '../@context/MarketMetadata'
import {
  ONE_SECOND_IN_MS,
  REFRESH_BALANCE_INTERVAL
} from '../components/Constants'
import { ethers } from 'ethers'
import { getTokenBalance } from '@utils/wallet'
import { useWagmiSocialLogin } from './useWagmiSocialLogin'
import { useAuthorize } from '@context/Authorize'
import { getTechnicalNetworkName } from '@utils/network'
import appConfig from 'app.config'
import {
  useAccount,
  useNetwork,
  useProvider,
  useBalance as useBalanceWagmi
} from 'wagmi'

interface BalanceProviderValue {
  balance: UserBalance
  metamaskNativeBalance: UserBalance
}

const refreshBalanceInterval = REFRESH_BALANCE_INTERVAL * ONE_SECOND_IN_MS

function useBalance(): BalanceProviderValue {
  const { isAccountAbstract } = useAuthorize()
  const { address } = useAccount()
  // Ani coming from Main : might take
  const { data: balanceNativeToken } = useBalanceWagmi({ address })
  const wagmiProvider = useProvider()
  const { approvedBaseTokens } = useMarketMetadata()
  const { chain } = useNetwork()
  const { biconomySocialLogin } = useWagmiSocialLogin()
  const [balance, setBalance] = useState<UserBalance>({
    eth: '0'
  })
  const [metamaskNativeBalance, setMetamaskNativeBalance] =
    useState<UserBalance>({
      eth: '0'
    })

  const getSmartAccountBalance = useCallback(async () => {
    if (wagmiProvider && biconomySocialLogin?.getSmartAccount() && chain) {
      const defaultBasecurrencyTicker =
        appConfig?.stableCoin[
          getTechnicalNetworkName(chain?.id)
        ]?.ticker.toLowerCase()

      const defaultBasecurrencyAddress =
        appConfig?.stableCoin[
          getTechnicalNetworkName(chain?.id)
        ]?.address.toLowerCase()

      const defaultBasecurrencyDecimals =
        appConfig?.stableCoin[getTechnicalNetworkName(chain?.id)]?.decimals

      const smartAccountAddress = biconomySocialLogin.getSmartAccountAddress()

      try {
        const newBalance: UserBalance = {}

        const tokenBalance = await getTokenBalance(
          smartAccountAddress,
          defaultBasecurrencyDecimals,
          defaultBasecurrencyAddress,
          wagmiProvider
        )

        newBalance[defaultBasecurrencyTicker] =
          tokenBalance !== undefined
            ? tokenBalance
            : balance[defaultBasecurrencyTicker] !== '0'
            ? balance[defaultBasecurrencyTicker]
            : '0'

        setBalance(newBalance)
      } catch (error) {
        LoggerInstance.error('[useBalance] Error: ', error.message)
      }
    }
  }, [biconomySocialLogin, chain, wagmiProvider])

  const getUserBalance = useCallback(async () => {
    if (
      !balanceNativeToken?.formatted ||
      !address ||
      !chain?.id ||
      !wagmiProvider
    )
      return

    try {
      // Ani coming from main : might take
      // const userBalance = balanceNativeToken?.formatted
      // const key = balanceNativeToken?.symbol.toLowerCase()
      // const newBalance: UserBalance = { eth: userBalance }
      const userBalance = ethers.utils.formatUnits(
        await wagmiProvider.getBalance(address),
        'ether'
      )
      const nativeBalance: UserBalance = {}
      nativeBalance[chain.nativeCurrency.symbol] = userBalance
      setMetamaskNativeBalance(nativeBalance)

      const newBalance: UserBalance = {}
      if (approvedBaseTokens?.length > 0) {
        await Promise.all(
          approvedBaseTokens.map(async (token) => {
            const { address: tokenAddress, decimals, symbol } = token
            const tokenBalance = await getTokenBalance(
              address,
              decimals,
              tokenAddress,
              wagmiProvider
            )
            if (
              symbol &&
              symbol ===
                appConfig?.stableCoin[getTechnicalNetworkName(chain?.id)]
                  ?.ticker
            ) {
              newBalance[symbol.toLowerCase()] =
                tokenBalance !== undefined
                  ? tokenBalance
                  : balance[symbol.toLowerCase()]
            }
          })
        ).then(() => {
          if (Object.keys(newBalance).length !== 0) {
            setBalance(newBalance)
          }
        })
      }

      LoggerInstance.log('[useBalance] Balance: ', newBalance)
    } catch (error) {
      LoggerInstance.error('[useBalance] Error: ', error.message)
    }
  }, [
    address,
    approvedBaseTokens,
    chain?.id,
    wagmiProvider,
    balanceNativeToken
  ])

  useEffect(() => {
    if (isAccountAbstract === false) {
      getUserBalance()

      const getBalanceInterval = setInterval(
        getUserBalance,
        refreshBalanceInterval
      )

      return () => clearInterval(getBalanceInterval)
    }
  }, [isAccountAbstract, getUserBalance])

  useEffect(() => {
    if (isAccountAbstract === true) {
      getSmartAccountBalance()
    }

    const getSmartAccountBalanceInterval = setInterval(
      getSmartAccountBalance,
      refreshBalanceInterval
    )

    return () => clearInterval(getSmartAccountBalanceInterval)
  }, [isAccountAbstract, getSmartAccountBalance])

  return { balance, metamaskNativeBalance }
}

export default useBalance
