import { Connector } from 'wagmi'
import { useCallback } from 'react'
import { WagmiClient } from '../@types/SmartAccount'

export default function useWagmiClient(wagmiClient: WagmiClient) {
  const setConnectors = useCallback(
    (connectors: Connector<any, any, any>[] | undefined) => {
      wagmiClient.setState((state) => {
        return {
          ...state,
          connectors: connectors as unknown as Connector
        } as any
      })
    },
    []
  )
  return { setConnectors }
}
