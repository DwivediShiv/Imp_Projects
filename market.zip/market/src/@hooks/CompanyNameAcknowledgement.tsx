import React, { useState, ReactElement, ReactNode, useEffect } from 'react'
import { useAuthorize } from '@context/Authorize'
import {
  getUserInfo,
  editAttribute,
  hasAcknowledgeCompanyNameChange,
  checkIsRegisterBeforeCompanyNameChange,
  IS_ACKNOWLEDGE_COMPANY_NAME_CHANGE
} from '@utils/userProfile'
import appConfig from 'app.config'
import { UpdateUserRequest } from '../components/pages/Users/utils'
import FancyCompanyNameAcknowledgementModal from '@shared/fancy/organisms/CompanyNameAcknowledgement/FancyCompanyNameAcknowledgementModal'

export default function CompanyNameAcknowledgement({
  children
}: {
  children: ReactNode
}): ReactElement {
  const [
    hasAcknowledgedCompanyNameChange,
    setHasAcknowledgedCompanyNameChange
  ] = useState<boolean>()
  const [
    isRegisterBeforeCompanyNameChange,
    setIsRegisterBeforeCompanyNameChange
  ] = useState<boolean>()
  const { isLogin } = useAuthorize()

  async function updateCompanyNameAcknowledgement() {
    const updateUserRequest: UpdateUserRequest = new UpdateUserRequest()
    updateUserRequest.attributes.push({
      name: IS_ACKNOWLEDGE_COMPANY_NAME_CHANGE,
      value: new Date().toISOString()
    })
    await editAttribute(updateUserRequest)
    setHasAcknowledgedCompanyNameChange(true)
  }

  useEffect(() => {
    isLogin &&
      getUserInfo().then((userInfo) => {
        const hasAcknowledged = hasAcknowledgeCompanyNameChange(userInfo)
        const isRegisterBeforeCompanyNameChange =
          checkIsRegisterBeforeCompanyNameChange(userInfo)
        setHasAcknowledgedCompanyNameChange(hasAcknowledged)
        setIsRegisterBeforeCompanyNameChange(isRegisterBeforeCompanyNameChange)
      })
  }, [isLogin])

  return (
    <>
      {appConfig?.customization?.isDisableCompanyNameChangeAcknowledgement ===
        'false' &&
        isLogin && (
          <FancyCompanyNameAcknowledgementModal
            isOpen={
              isRegisterBeforeCompanyNameChange &&
              !hasAcknowledgedCompanyNameChange
            }
            updateCompanyNameAcknowledgement={updateCompanyNameAcknowledgement}
          />
        )}

      {children}
    </>
  )
}
