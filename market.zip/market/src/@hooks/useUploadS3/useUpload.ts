import { useCallback, useState } from 'react'
import appConfig from 'app.config'
import axios from 'axios'
import { PresignedURL } from './types/PresignedURL'

export const uploadApiURL = `${appConfig.api}/user-management/api/v1/as/uploadurl`
export const updateAccessApiURL = `${appConfig.api}/user-management/api/v1/as/updateAccess`

function getQueryString(file: File, name: string, location: string) {
  const fileType = encodeURIComponent(file.type)
  const ext = (file.type as string).split('/')[1]
  const fileName = (name || file.name) + `.${ext}`
  return `?fileName=${fileName}&fileType=${fileType}&location=${location}`
}

export default function useUpload() {
  const [isLoading, setIsLoading] = useState(false)
  const [uploadFileError, setUploadFileError] = useState<string | null>('')
  const [isFileUploaded, setIsFileUploaded] = useState<boolean>(false)
  const [uploadedURL, setUploadedURL] = useState<string>('')
  const getUploadURL = useCallback(
    async (queryString: string): Promise<PresignedURL> => {
      const url = uploadApiURL + queryString
      const { data: response } = await axios.get<PresignedURL>(url)
      return response
    },
    []
  )

  const insertFile = useCallback(
    async (file: File, url: string): Promise<boolean> => {
      const options = {
        onUploadProgress: function (progressEvent) {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          )
          console.log(percentCompleted)
        }
      }
      const { data: uploadSuccess } = await axios.put(url, file, options)
      console.log(uploadSuccess)
      return uploadSuccess
    },
    []
  )

  const setReadPermissions = useCallback(
    async (key: string): Promise<boolean> => {
      const { data: accessSuccess } = await axios.put(updateAccessApiURL, {
        key
      })
      return accessSuccess
    },
    []
  )

  const updateFile = useCallback(
    async (file: File, name: string, location: string) => {
      try {
        setUploadFileError('')
        setIsLoading(true)
        const queryString = getQueryString(file, name, location)
        const uploadURL: PresignedURL = await getUploadURL(queryString)
        await insertFile(file, uploadURL.preSignedUrl)
        await setReadPermissions(uploadURL.key)
        setIsFileUploaded(true)
        setUploadedURL(uploadURL.publicUrl)
        setIsLoading(false)
        return uploadURL.publicUrl
      } catch (error) {
        setIsLoading(false)
        if (axios.isAxiosError(error)) {
          setUploadFileError(error.message)
        } else {
          setUploadFileError('unexpected error')
        }
        return ''
      }
    },
    [getUploadURL, insertFile, setReadPermissions]
  )

  return {
    isLoading,
    isFileUploaded,
    uploadedURL,
    updateFile,
    uploadFileError
  }
}
