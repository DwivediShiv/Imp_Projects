import { useFancyState } from '@context/FancyState'
import { useEffect, useState } from 'react'

export const useOrganisationName = () => {
  const { getOrganisationOptions } = useFancyState()
  const [organisationMap, setOrganisationMap] = useState(null)

  useEffect(() => {
    const getOrgName = async () => {
      const orgOptions = await getOrganisationOptions()
      if (orgOptions?.length) {
        const orgMap = orgOptions.reduce((acc, curr) => {
          return { ...acc, [curr.id]: curr.name }
        }, {})
        setOrganisationMap(orgMap)
      }
    }
    getOrgName()
  }, [])

  return { organisationMap }
}
