import React, {
  useContext,
  useState,
  useEffect,
  createContext,
  ReactElement,
  useCallback,
  ReactNode
} from 'react'
import { Config, LoggerInstance, Purgatory } from '@oceanprotocol/lib'
import { CancelToken } from 'axios'
import { getAsset } from '@utils/aquarius'
import { useMarketMetadata } from './MarketMetadata'
import { useCancelToken } from '@hooks/useCancelToken'
import { getOceanConfig, sanitizeDevelopmentConfig } from '@utils/ocean'
import { getAccessDetails } from '@utils/accessDetailsAndPricing'
import { useIsMounted } from '@hooks/useIsMounted'
import { assetStateToString } from '@utils/assetState'
import { useAccount, useNetwork } from 'wagmi'
import { STATE_DELIST } from '@utils/constants'
import { isValidDid } from '@utils/ddo'

export interface AssetProviderValue {
  isInPurgatory: boolean
  isDelisted: boolean
  purgatoryData: Purgatory
  asset: AssetExtended
  title: string
  owner: string
  setUserOrgAccount: React.Dispatch<React.SetStateAction<string>>
  setIsAbstract: React.Dispatch<React.SetStateAction<boolean>>
  nftSigner: string
  error?: string
  isAssetNetwork: boolean
  isV3Asset: boolean
  isOwner: boolean
  oceanConfig: Config
  loading: boolean
  assetState: string
  fetchAsset: (token?: CancelToken, isSilentFetch?: boolean) => Promise<void>
}

const AssetContext = createContext({} as AssetProviderValue)

function AssetProvider({
  did,
  children
}: {
  did: string
  children: ReactNode
}): ReactElement {
  const { appConfig } = useMarketMetadata()
  const { address } = useAccount()
  const { chain } = useNetwork()

  const [isInPurgatory, setIsInPurgatory] = useState(false)
  const [isDelisted, setIsDelisted] = useState(false)
  const [purgatoryData, setPurgatoryData] = useState<Purgatory>()
  const [asset, setAsset] = useState<AssetExtended>()
  const [title, setTitle] = useState<string>()
  const [owner, setOwner] = useState<string>()
  const [isOwner, setIsOwner] = useState<boolean>()
  const [error, setError] = useState<string>()
  const [loading, setLoading] = useState(false)
  const [isAssetNetwork, setIsAssetNetwork] = useState<boolean>()
  const [isV3Asset, setIsV3Asset] = useState<boolean>()
  const [oceanConfig, setOceanConfig] = useState<Config>()
  const [assetState, setAssetState] = useState<string>()
  const [nftSigner, setNftSigner] = useState<string>()
  const [userOrgAccount, setUserOrgAccount] = useState<string>()
  const [accountId, setAccountId] = useState<string>()
  const [isAbstract, setIsAbstract] = useState<boolean>(undefined)

  useEffect(() => {
    if (isAbstract === undefined) return
    if (isAbstract) {
      if (!userOrgAccount) return
      setAccountId(userOrgAccount)
    } else {
      if (!address) return
      setAccountId(address)
    }
  }, [userOrgAccount, address, isAbstract])

  const newCancelToken = useCancelToken()
  const isMounted = useIsMounted()

  // -----------------------------------
  // Helper: Get and set asset based on passed DID
  // isSilentFetch: will fetch without re-rendering any UI
  // -----------------------------------
  const fetchAsset = useCallback(
    async (token?: CancelToken, isSilentFetch?: boolean) => {
      if (!did) return
      const isDid = isValidDid(did)

      if (!isDid) {
        setError(`The url is not for a valid DID`)
        setLoading(false)
        LoggerInstance.error(`[asset] Not a valid DID`)
        return
      }

      setIsDelisted(false)
      setError(undefined)

      LoggerInstance.log('[asset] Fetching asset...')
      !isSilentFetch && setLoading(true)
      const asset = await getAsset(did, token)

      if (!asset) {
        // setIsV3Asset(await checkV3Asset(did, token))
        setError(
          `\`${did}\`` +
            '\n\nWe could not find an asset for this DID in the cache. If you just published a new asset, wait some seconds and refresh this page.'
        )
        setLoading(false)
        LoggerInstance.error(`[asset] Failed getting asset for ${did}`, asset)
        return
      }

      if (asset?.nft?.state === STATE_DELIST) {
        setIsDelisted(true)
        setLoading(false)
        return
      }

      if (asset.nft.state === (1 | 2 | 3)) {
        setTitle(
          `This asset has been set as "${assetStateToString(
            asset.nft.state
          )}" by the publisher`
        )
        setError(`\`${did}\`` + `\n\nPublisher Address: ${asset.nft.owner}`)
        setLoading(false)
        LoggerInstance.error(`[asset] Failed getting asset for ${did}`, asset)
        return
      }
      if (asset) {
        setAsset((prevState) => ({
          ...prevState,
          ...asset
        }))
        setTitle(asset.metadata?.name)
        setOwner(asset.nft?.owner)
        setNftSigner(asset.metadata?.additionalInformation.signer)
        setIsInPurgatory(asset.purgatory?.state)
        setPurgatoryData(asset.purgatory)
        setAssetState(assetStateToString(asset.nft.state))
        LoggerInstance.log('[asset] Got asset', asset)
      }

      !isSilentFetch && setLoading(false)
    },
    [did, accountId]
  )

  // -----------------------------------
  // Helper: Get and set asset access details
  // -----------------------------------
  const fetchAccessDetails = useCallback(async (): Promise<void> => {
    if (!asset?.chainId || !asset?.services?.length) return

    const accessDetails = await getAccessDetails(
      asset.chainId,
      asset.services[0].datatokenAddress,
      asset.services[0].timeout,
      accountId
    )
    if (
      accessDetails?.type === 'free' &&
      (asset?.metadata?.additionalInformation?.postpayType === 'setPrice' ||
        asset?.metadata?.additionalInformation?.postpayType === 'payPerByte')
    ) {
      const parsedJson = JSON.parse(
        asset?.metadata?.additionalInformation.price
      )
      const price = parsedJson?.value
      const symbol = parsedJson?.tokenSymbol
      accessDetails.baseToken = {
        symbol
      }
      accessDetails.price = price
    }
    setAsset((prevState) => ({
      ...prevState,
      accessDetails
    }))
    LoggerInstance.log(`[asset] Got access details for ${did}`, accessDetails)
  }, [asset?.chainId, asset?.services, accountId, did])

  // -----------------------------------
  // 1. Get and set asset based on passed DID
  // -----------------------------------
  useEffect(() => {
    if (!isMounted || !appConfig?.metadataCacheUri) return

    fetchAsset(newCancelToken())
  }, [appConfig?.metadataCacheUri, fetchAsset, newCancelToken, isMounted])

  // -----------------------------------
  // 2. Attach access details to asset
  // -----------------------------------
  useEffect(() => {
    if (!isMounted || isAbstract === undefined || !accountId) return

    fetchAccessDetails()
  }, [accountId, fetchAccessDetails, isMounted, isAbstract])

  // -----------------------------------
  // Check user network against asset network
  // -----------------------------------
  useEffect(() => {
    if (!chain?.id || !asset?.chainId) return

    const isAssetNetwork = chain?.id === asset?.chainId
    setIsAssetNetwork(isAssetNetwork)
  }, [chain?.id, asset?.chainId])

  // -----------------------------------
  // Asset owner check against wallet user
  // -----------------------------------
  useEffect(() => {
    if (!accountId || !owner) return

    const isOwner = accountId?.toLowerCase() === owner.toLowerCase()
    setIsOwner(isOwner)
  }, [accountId, owner])

  // -----------------------------------
  // Load ocean config based on asset network
  // -----------------------------------
  useEffect(() => {
    if (!asset?.chainId) return
    const config = getOceanConfig(asset?.chainId)
    const oceanConfig = {
      ...config,

      // add local dev values
      ...(asset?.chainId === 8996 && {
        ...sanitizeDevelopmentConfig(config)
      })
    }
    setOceanConfig(oceanConfig)
  }, [asset?.chainId])

  // -----------------------------------
  // Set Asset State as a string
  // -----------------------------------
  useEffect(() => {
    if (!asset?.nft) return
    setAssetState(assetStateToString(asset.nft.state))
  }, [asset])

  return (
    <AssetContext.Provider
      value={
        {
          asset,
          did,
          title,
          owner,
          setUserOrgAccount,
          setIsAbstract,
          nftSigner,
          error,
          isInPurgatory,
          purgatoryData,
          loading,
          fetchAsset,
          isAssetNetwork,
          isV3Asset,
          isOwner,
          oceanConfig,
          assetState,
          isDelisted
        } as AssetProviderValue
      }
    >
      {children}
    </AssetContext.Provider>
  )
}
// Helper hook to access the provider values
const useAsset = (): AssetProviderValue => useContext(AssetContext)

export { AssetProvider, useAsset, AssetContext }
export default AssetProvider
