import React, { createContext, useContext, useEffect, useState } from 'react'
import appConfig from '../../app.config'
import { MatomoProvider, createInstance } from '@datapunt/matomo-tracker-react'
import { getLocalStorage, setLocalStorage } from '@utils/cookie'

interface FancyMatomoProviderValue {
  isMatomoEnabled?: boolean
  toggleTracking?: (isTrack?: boolean) => void
}

const MatomoContext = createContext({} as FancyMatomoProviderValue)
let instance = null

const FancyMatomoProvider: React.FC<any> = ({ children, value }) => {
  const isMarketingConsentEnable =
    getLocalStorage('analyticTracking') === 'true'
  const [isEnable, setIsEnable] = useState(isMarketingConsentEnable)

  if (!isEnable) {
    instance = null
  } else {
    instance = createInstance({
      urlBase: appConfig.site.baseUrl,
      siteId: (appConfig.site.matomoSiteId || 1) as number,
      trackerUrl: `${appConfig.site.matomoBaseUrl}/piwik.php`, // optional, default value: `${urlBase}matomo.php`
      srcUrl: `${appConfig.site.matomoBaseUrl}/piwik.js`, // optional, default value: `${urlBase}matomo.js`
      disabled: false, // optional, false by default. Makes all tracking calls no-ops if set to true.
      heartBeat: {
        // optional, enabled by default
        active: false, // optional, default value: true
        seconds: 10 // optional, default value: `15
      },
      linkTracking: false, // optional, default value: true
      configurations: {
        // optional, default value: {}
        // any valid matomo configuration, all below are optional
        disableCookies: true,
        setSecureCookie: true
        // setRequestMethod: 'POST'
      }
    })
  }

  const toggleTrackingHandler = (trackingEnabled) => {
    setIsEnable((previousValue) => trackingEnabled || !previousValue)
  }

  useEffect(() => {
    setLocalStorage('analyticTracking', isEnable)
    return () => null
  }, [isEnable])

  const context = {
    toggleTracking: toggleTrackingHandler,
    isMatomoEnabled: isEnable
  }

  return (
    <MatomoContext.Provider value={context}>
      <MatomoProvider value={instance}>{children}</MatomoProvider>
    </MatomoContext.Provider>
  )
}

const useMatomoContext = (): FancyMatomoProviderValue =>
  useContext(MatomoContext)

export { FancyMatomoProvider, useMatomoContext }
