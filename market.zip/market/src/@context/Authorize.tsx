import React, {
  useContext,
  useState,
  createContext,
  ReactElement,
  ReactNode,
  useEffect
} from 'react'
import { getOceanConfig } from '@utils/ocean'
import { useAsset } from '@context/Asset'
import {
  hasAccess,
  isLoggedIn,
  isValidatedRole,
  isAdminRole,
  fetchRoles,
  getProfileAndWalletRoles,
  setTabSessionInactive,
  setActive,
  getProfileWallets,
  onKeycloakRefreshToken,
  checkIsAccountAbstract,
  getAbstractDetails,
  addSmartAccount,
  fetchInstanceDetails,
  getUserEmail,
  checkUserOrgInfo
} from '@utils/auth'
import { isSupportedNetwork } from '@utils/fancyNetworkSwitcher'
import { useOcean } from '@context/Ocean'
import { Asset, DDO, LoggerInstance, LogLevel } from '@oceanprotocol/lib'
import {
  ROLE_CONSUMER,
  ROLE_PUBLISHER,
  ROLE_VALIDATED,
  ROLE_ADMIN,
  ROLE_SUPERADMIN
} from '@shared/fancy/constants/RoleConstants'
import appConfig from 'app.config'
import { IDLE_TIMEOUT } from 'src/components/Constants'
import { useAccount, useNetwork } from 'wagmi'
import { AbstractDetails, InstanceDetails } from '../@types/SmartAccount'

export interface AuthorizeProviderValue {
  isLogin: boolean
  isSsoUser: boolean
  isValidated: boolean
  isAdmin: boolean
  isConnectedWallet: boolean
  isValidNetwork: boolean
  isAAOwner: (inputOwner?: string) => boolean
  canEdit: boolean
  canEditNetwork: boolean
  canConsume: boolean
  canConsumeNetwork: boolean
  canPublish: boolean
  canPublishNetwork: boolean
  canJustPreview: boolean
  profileAndWalletRoles: Set<string>
  canProfileConsume: boolean
  canProfilePublish: boolean
  canWalletConsume: boolean
  canWalletPublish: boolean
  canEditAsset: (chainId?: number, owner?: string, ddo?: DDO) => boolean
  canConsumeAsset: (chainId?: number, ddo?: DDO) => boolean
  reconnectOcean: (isForce?: boolean) => Promise<void>
  reconnectOceanWithWeb3: () => Promise<void>
  reconnectOceanWithoutWeb3: () => Promise<void>
  isAssetProfile: boolean
  isSuperAdmin: boolean
  isAccountAbstract: boolean
  orgSmartAccount: string
  showPaymasterDetails: boolean
  setUpdateWalletRoles: React.Dispatch<React.SetStateAction<boolean>>
  userOrganizationId: string
  shouldShowAutoLogoutBanner: boolean
  setShouldShowAutoLogoutBanner: React.Dispatch<React.SetStateAction<boolean>>
}

const AuthorizeContext = createContext({} as AuthorizeProviderValue)

function AuthorizeProvider({
  children
}: {
  children: ReactNode
}): ReactElement {
  let logoutTimeout: any
  const signoutTime = IDLE_TIMEOUT * 60 * 1000
  const { address: accountId } = useAccount()
  const { chain } = useNetwork()
  const {
    asset: ddo,
    isAssetNetwork,
    owner,
    setUserOrgAccount,
    setIsAbstract
  } = useAsset()
  const { ocean, connect, config } = useOcean()

  const [isConnectedWallet, setIsConnectedWallet] = useState<boolean>()
  const [canEdit, setCanEdit] = useState<boolean>()
  const [canEditNetwork, setCanEditNetwork] = useState<boolean>()
  const [canConsume, setCanConsume] = useState<boolean>()
  const [canConsumeNetwork, setCanConsumeNetwork] = useState<boolean>()
  const [canPublish, setCanPublish] = useState<boolean>()
  const [canPublishNetwork, setCanPublishNetwork] = useState<boolean>()
  const [isLogin, setIsLogin] = useState<boolean>()
  const [isSsoUser, setIsSsoUser] = useState<boolean>(false)
  const [isValidNetwork, setIsValidNetwork] = useState<boolean>()
  const [isValidAssetNetwork, setIsValidAssetNetwork] = useState<boolean>()
  const [canJustPreview, setCanJustPreview] = useState<boolean>()
  const [isValidated, setIsValidated] = useState<boolean>()
  const [isAdmin, setIsAdmin] = useState<boolean>()
  const [profileAndWalletRoles, setProfileAndWalletRoles] =
    useState<Set<string>>()
  const [canProfileConsume, setCanProfileConsume] = useState<boolean>()
  const [canProfilePublish, setCanProfilePublish] = useState<boolean>()
  const [canWalletConsume, setCanWalletConsume] = useState<boolean>()
  const [canWalletPublish, setCanWalletPublish] = useState<boolean>()
  const [isAssetProfile, setIsAssetProfile] = useState<boolean>()
  const [isSuperAdmin, setIsSuperAdmin] = useState<boolean>()
  const [isAccountAbstract, setIsAccountAbstract] = useState<boolean>()
  const [orgSmartAccount, setOrgSmartAccount] = useState<string>()
  const [showPaymasterDetails, setShowPaymasterDetails] =
    useState<boolean>(undefined)
  const [updateWalletRoles, setUpdateWalletRoles] = useState<boolean>(false)
  const [userOrganizationId, setUserOrganizationId] = useState<string>()
  const [shouldShowAutoLogoutBanner, setShouldShowAutoLogoutBanner] =
    useState<boolean>(false)

  async function reconnectOceanWithWeb3(isForce = false) {
    const oceanNetworkId = await ocean?.network?.getNetworkId()
    const newNetworkId = chain?.id || ddo?.chainId || 137
    if (!isForce && oceanNetworkId === newNetworkId) {
      return
    }
    const newConfig = config || getOceanConfig(newNetworkId)
    // await connect(newConfig)
  }

  async function reconnectOceanWithoutWeb3() {
    // const oceanNetworkId = await ocean?.network?.getNetworkId()
    // const newNetworkId = networkId || ddo?.chainId || 137
    // if (oceanNetworkId === newNetworkId) {
    //   return
    // }
    // const newConfig = config || getOceanConfig(newNetworkId)
    // await connectFancyOceanWithoutWeb3(newConfig)
  }

  async function reconnectOcean() {
    if (!ocean?.OceanDispenser?.web3 && chain?.id) {
      await reconnectOceanWithWeb3(true)
    } else if (!ocean && !chain?.id) {
      await reconnectOceanWithoutWeb3()
    }
  }

  function isAAOwner(inputOwner?: string): boolean {
    if (isAccountAbstract === undefined) {
      return false
    }
    if (isAccountAbstract) {
      if (!orgSmartAccount || (!inputOwner && !owner)) return false
      return (
        orgSmartAccount.toLowerCase() === (inputOwner || owner).toLowerCase()
      )
    } else {
      if (!accountId || (!inputOwner && !owner)) {
        return false
      }
      return accountId.toLowerCase() === (inputOwner || owner).toLowerCase()
    }
  }

  function checkIsAssetProfile(): boolean {
    const profileWallets = getProfileWallets()
    return profileWallets?.includes(owner?.toLowerCase())
  }

  function canConsumeAsset(chainId?: number, ddo?: DDO): boolean {
    const isCorrectChain = chain?.id && chain?.id === (chainId || ddo?.chainId)
    return isLogin && isValidated && isCorrectChain
  }

  function canEditAsset(
    chainId?: number,
    owner?: string,
    ddo?: Asset
  ): boolean {
    const isCorrectChain = canConsumeAsset(chainId, ddo)
    const hasPublishAccess = hasAccess(ROLE_PUBLISHER, accountId)
    return (
      isCorrectChain && hasPublishAccess && isAAOwner(owner || ddo?.nft?.owner)
    )
  }

  useEffect(() => {
    async function setupUserProfile() {
      await fetchRoles()
      const hasValidatedRole = isValidatedRole()
      setIsValidated(hasValidatedRole)
      const profileAndWalletRoles = getProfileAndWalletRoles()
      const accountType = await checkIsAccountAbstract()
      setIsAccountAbstract(accountType)
      setIsAbstract(accountType)
      setProfileAndWalletRoles(profileAndWalletRoles)
      setCanProfileConsume(
        hasValidatedRole && profileAndWalletRoles?.has(ROLE_CONSUMER)
      )
      setCanProfilePublish(
        hasValidatedRole && profileAndWalletRoles?.has(ROLE_PUBLISHER)
      )
      setIsAdmin(hasAccess(ROLE_ADMIN))
      setIsSuperAdmin(hasAccess(ROLE_SUPERADMIN))

      setIsLogin(isLoggedIn())
    }
    setupUserProfile()

    return () => null
  }, [isLoggedIn(), updateWalletRoles])

  useEffect(() => {
    if (!isValidated || !owner || isAccountAbstract === undefined) return
    setCanJustPreview(isLogin && isValidated && !accountId)
    const isLoginOwner = isLogin && isValidated && isAAOwner()
    const hasPublishAccess = hasAccess(ROLE_PUBLISHER, accountId)
    setCanEdit(isLoginOwner && hasPublishAccess)
    setCanEditNetwork(isLoginOwner && hasPublishAccess && isAssetNetwork)
    setIsAssetProfile(checkIsAssetProfile())
    !isValidated && setIsValidated(isValidatedRole())
    !isAdmin && setIsAdmin(isAdminRole())

    return () => null
  }, [
    accountId,
    isAssetNetwork,
    owner,
    isLogin,
    isValidated,
    isAdmin,
    isAccountAbstract,
    orgSmartAccount,
    updateWalletRoles
  ])

  useEffect(() => {
    async function updatedetails() {
      await fetchRoles()
      if (!isConnectedWallet) return
      const hasConsumeAccess = hasAccess(ROLE_CONSUMER, accountId)
      setCanConsume(isLogin && hasConsumeAccess && isConnectedWallet)
      setCanConsumeNetwork(
        isLogin && hasConsumeAccess && isConnectedWallet && isAssetNetwork
      )
    }
    updatedetails()

    return () => null
  }, [isConnectedWallet, isAssetNetwork, isLogin, accountId, updateWalletRoles])

  useEffect(() => {
    if (!isValidated) return
    setIsConnectedWallet(isValidated && !!accountId)
    !isValidated && setIsValidated(hasAccess(ROLE_VALIDATED, accountId))
    return () => null
  }, [accountId, isValidated, updateWalletRoles])

  useEffect(() => {
    async function updateRoles() {
      await fetchRoles()
      if (!isConnectedWallet) return
      setCanWalletConsume(hasAccess(ROLE_CONSUMER, accountId))
      setCanWalletPublish(hasAccess(ROLE_PUBLISHER, accountId))
    }
    updateRoles()
    return () => null
  }, [accountId, isConnectedWallet, updateWalletRoles])

  useEffect(() => {
    const isSupported = isSupportedNetwork(chain?.id)
    setIsValidNetwork(isSupported)
    setIsValidAssetNetwork(isAssetNetwork && isSupported)

    return () => null
  }, [isAssetNetwork, chain?.id])

  useEffect(() => {
    if (!isConnectedWallet) return
    const hasPublishAccess = hasAccess(ROLE_PUBLISHER, accountId)
    setCanPublish(isConnectedWallet && hasPublishAccess)
    setCanPublishNetwork(
      isConnectedWallet && isValidNetwork && hasPublishAccess
    )

    return () => null
  }, [isConnectedWallet, isValidNetwork, accountId, isLogin, updateWalletRoles])

  useEffect(() => {
    if (ocean || (!chain?.id && !ddo?.chainId) || !connect) {
      return () => null
    }
    reconnectOcean()

    return () => null
  }, [ddo?.chainId, chain?.id, connect, config, ocean])

  // Utility functions
  function logout() {
    if (isLogin) setTabSessionInactive()
  }

  function setLogoutTimeout() {
    if (isLogin) logoutTimeout = setTimeout(logout, signoutTime)
  }

  function clearLogoutTimeout() {
    if (isLogin && logoutTimeout) clearTimeout(logoutTimeout)
  }

  function handleUserActivity() {
    clearLogoutTimeout()
    setLogoutTimeout()
  }

  function addEventListeners(events, handler) {
    events.forEach((event) => window.addEventListener(event, handler))
  }

  function removeEventListeners(events, handler) {
    events.forEach((event) => window.removeEventListener(event, handler))
  }

  useEffect(() => {
    if (appConfig?.source === 'ddmdev') {
      LoggerInstance.setLevel(LogLevel.Log)
    }

    if (!isLogin) return
    setActive()
    onKeycloakRefreshToken()

    // Set initial logout timeout when the component mounts and user is logged in
    setLogoutTimeout()

    // Setup event listeners for user activity
    const events = ['mousemove', 'mousedown', 'click', 'scroll', 'keypress']
    addEventListeners(events, handleUserActivity)

    // Set user's sso status
    async function setUserSsoStatus(userEmail) {
      const response = await checkUserOrgInfo(userEmail)
      setIsSsoUser(response?.data?.ssoEnabled)
    }
    setUserSsoStatus(getUserEmail())

    // Cleanup function for removing event listeners and clearing the timeout
    return () => {
      removeEventListeners(events, handleUserActivity)
      clearLogoutTimeout()
    }
  }, [isLogin])

  useEffect(() => {
    async function setupSmartAccountInfo() {
      if (!isAccountAbstract || !isLogin) {
        setOrgSmartAccount(undefined)
        setUserOrgAccount(undefined)
        return
      }
      const { accountAddress } = await getAbstractDetails()

      setOrgSmartAccount(accountAddress)
      setUserOrgAccount(accountAddress)
    }
    async function checkInstancedetails() {
      if (isAccountAbstract === undefined || !isLogin) {
        showPaymasterDetails && setShowPaymasterDetails(false)
        return
      }
      const instanceDetails: InstanceDetails = await fetchInstanceDetails()
      const userMail = getUserEmail()
      const response = await checkUserOrgInfo(userMail)
      const { orgId: userOrgId } = response.data
      setUserOrganizationId(userOrgId)
      if (!isAccountAbstract) {
        const isInstanceOrg = instanceDetails?.orgId === userOrgId
        if (instanceDetails?.enablePaymaster && isInstanceOrg) {
          setShowPaymasterDetails(true)
          return
        }
      } else {
        const isInstanceOrg = instanceDetails?.orgId === userOrgId
        if (
          (instanceDetails?.enablePaymaster && isInstanceOrg) ||
          !instanceDetails?.enablePaymaster
        ) {
          setShowPaymasterDetails(true)
          return
        }
      }
      setShowPaymasterDetails(false)
    }
    checkInstancedetails()
    setupSmartAccountInfo()
  }, [isAccountAbstract, isLogin])

  useEffect(() => {
    async function addSmartAccountUser() {
      if (!isAccountAbstract || !isLogin || !isSuperAdmin || !orgSmartAccount)
        return
      await addSmartAccount(orgSmartAccount)
    }
    addSmartAccountUser()
  }, [isSuperAdmin, isAccountAbstract, isLogin, orgSmartAccount])

  return (
    <AuthorizeContext.Provider
      value={
        {
          isConnectedWallet,
          canEdit,
          canEditNetwork,
          canConsume,
          canConsumeNetwork,
          canPublish,
          canPublishNetwork,
          isLogin,
          isSsoUser,
          isValidated,
          isAdmin,
          isValidNetwork,
          isValidAssetNetwork,
          isAAOwner,
          canConsumeAsset,
          canEditAsset,
          reconnectOcean,
          reconnectOceanWithWeb3,
          reconnectOceanWithoutWeb3,
          canJustPreview,
          profileAndWalletRoles,
          canProfileConsume,
          canProfilePublish,
          canWalletConsume,
          canWalletPublish,
          isAssetProfile,
          isSuperAdmin,
          isAccountAbstract,
          orgSmartAccount,
          showPaymasterDetails,
          setUpdateWalletRoles,
          userOrganizationId,
          shouldShowAutoLogoutBanner,
          setShouldShowAutoLogoutBanner
        } as AuthorizeProviderValue
      }
    >
      {children}
    </AuthorizeContext.Provider>
  )
}

const useAuthorize = (): AuthorizeProviderValue => useContext(AuthorizeContext)

export { AuthorizeProvider, useAuthorize, AuthorizeContext }
export default AuthorizeProvider
