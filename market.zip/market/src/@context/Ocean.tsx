// Kris: TODO remove usage of useOcean() as ocean no use anymore, we may use getOceanConfig(chainId) instead
import React, {
  useContext,
  useState,
  createContext,
  ReactElement,
  useCallback,
  ReactNode,
  useEffect
} from 'react'
import { Config } from '@oceanprotocol/lib'
import appConfig from '../../app.config'
import { FancyConfig } from '../models/FancyConfig'

interface OceanProviderValue {
  ocean: any // Ocean
  account: any // Account
  config: Config | FancyConfig
  connect: (config: Config) => Promise<void>
  connectFancyOceanWithoutWeb3: (config: Config) => Promise<void>
}

const OceanContext = createContext({} as OceanProviderValue)

function OceanProvider({ children }: { children: ReactNode }): ReactElement {
  // const { web3, accountId } = useWeb3()
  // const { ddo } = useAsset()
  // const [ocean, setOcean] = useState<Ocean>()
  // const [account, setAccount] = useState<Account>()
  const [config, setConfig] = useState<Config | FancyConfig>()
  const { network } = appConfig

  // -----------------------------------
  // Helper: Create Ocean instance
  // -----------------------------------
  // const connect = useCallback(
  //   async (inputConfig: Config) => {
  //     if (!web3) return

  //     const currentConfig = inputConfig || config
  //     const newConfig: Config | any = {
  //       ...currentConfig,
  //       web3Provider: web3
  //     }

  //     try {
  //       LoggerInstance.log('[ocean] Connecting Ocean...', newConfig)
  //       const newOcean = await Ocean.getInstance(newConfig)
  //       setOcean(newOcean)
  //       setConfig(newConfig)
  //       LoggerInstance.log('[ocean] Ocean instance created.', newOcean)
  //     } catch (error) {
  //       LoggerInstance.error('[ocean] Error: ', error.message)
  //     }
  //   },
  //   [web3]
  // )

  // const connectFancyOceanWithoutWeb3 = useCallback(
  //   async (inputConfig: Config) => {
  //     const currentConfig = inputConfig || config
  //     const newConfig: Config | any = {
  //       ...currentConfig
  //     }

  //     try {
  //       LoggerInstance.log(
  //         '[ocean] Connecting Ocean without web3...',
  //         newConfig
  //       )
  //       const newOcean = await Ocean.getInstance(newConfig)
  //       setOcean(newOcean)
  //       setConfig(newConfig)
  //       LoggerInstance.log(
  //         '[ocean] Ocean instance created without web3.',
  //         newOcean
  //       )
  //     } catch (error) {
  //       LoggerInstance.error('[ocean] Error: ', error.message)
  //     }
  //   },
  //   [web3]
  // )

  // // -----------------------------------
  // // Initial asset details connection
  // // -----------------------------------
  // useEffect(() => {
  //   if (!ddo?.chainId) return

  //   const config = {
  //     // add local dev values
  //     ...((ddo?.chainId === 8996 || network) && {
  //       ...getDevelopmentConfig()
  //     }),
  //     ...getOceanConfig(ddo?.chainId || network)
  //   }

  //   async function init() {
  //     await connect(config)
  //   }
  //   init()
  // }, [connect, ddo])

  // // -----------------------------------
  // // Get user info, handle account change from web3
  // // -----------------------------------
  // useEffect(() => {
  //   if (!ocean || !accountId || !web3 || !ocean?.accounts?.list) return

  //   async function getInfo() {
  //     const account = (await ocean.accounts.list())?.[0]
  //     LoggerInstance.log('[ocean] Account: ', account)
  //     setAccount(account)
  //   }
  //   getInfo()
  // }, [ocean, accountId, web3])

  return (
    <OceanContext.Provider
      value={
        {
          // ocean,
          // account,
          // connect,
          config
          // connectFancyOceanWithoutWeb3
          // refreshBalance
        } as OceanProviderValue
      }
    >
      {children}
    </OceanContext.Provider>
  )
}

// Helper hook to access the provider values
const useOcean = (): OceanProviderValue => useContext(OceanContext)

export { OceanProvider, useOcean, OceanContext }
export default OceanProvider
