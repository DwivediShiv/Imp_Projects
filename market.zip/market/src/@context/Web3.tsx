import React, {
  useContext,
  useState,
  createContext,
  ReactElement,
  ReactNode
} from 'react'
// import Web3 from 'web3'
// import Web3Modal, {
//   getProviderInfo,
//   INJECTED_PROVIDER_ID,
//   IProviderInfo
// } from 'web3modal'
// import { infuraProjectId as infuraId, portisId } from '../../app.config'
// import WalletConnectProvider from '@walletconnect/web3-provider'
import { LoggerInstance } from '@oceanprotocol/lib'
// import { isBrowser } from '@utils/index'
// import { getEnsName } from '@utils/ens'
// import useNetworkMetadata from '../@hooks/useNetworkMetadata'
// import { getOpcsApprovedTokens } from '@utils/subgraph'
// import { isValidatedLogin } from '@utils/auth'
import fancyToast from '@shared/fancy/atoms/Toast/FancyToast'
import { getIsWalletCanConnect } from '@utils/wallet'
// import { log } from 'console'
import { keycloakLogout } from '@utils/auth'
// import { useMarketMetadata } from './MarketMetadata'

interface Web3ProviderValue {
  // web3: Web3
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  // web3Provider: any
  // web3Modal: Web3Modal
  // // web3ProviderInfo: IProviderInfo
  // accountId: string
  // accountEns: string
  // balance: UserBalance
  // networkId: number
  // chainId: number
  // networkDisplayName: string
  // networkData: EthereumListsChain
  // block: number
  // isTestnet: boolean
  // web3Loading: boolean
  // isSupportedOceanNetwork: boolean
  // approvedBaseTokens: TokenInfo[]
  showFancyMetamaskGuide: boolean
  // connect: (isShowFancySuccessMsg?: boolean) => Promise<void>
  // logout: () => Promise<void>
  // toFancyChecksumAddress: (tokenAddress: string) => string
  // fancyResetAccount: () => void
  // fancySetCachedProvider: () => Promise<void>
  fancyShowMetamaskGuide: (state: boolean) => Promise<void>
  fancyWalletValidation: (
    accountId: string,
    isShowFancySuccessMsg: boolean
  ) => Promise<boolean>
  updateWallet: boolean
  setUpdateWallet: React.Dispatch<React.SetStateAction<boolean>>
  // fancyHasMetamask: () => Promise<boolean>
}

// const web3ModalTheme = {
//   background: 'var(--background-body)',
//   main: 'var(--font-color-heading)',
//   secondary: 'var(--brand-grey-light)',
//   border: 'var(--border-color)',
//   hover: 'var(--background-highlight)'
// }

// const fancyWeb3ModalTheme = {
//   background: 'var(--surface-1-color)',
//   main: 'var(--light-text-1)',
//   secondary: 'var(--light-text-1)',
//   border: 'var(--surface-4-color)',
//   hover: 'var(--primary-color)'
// }

// HEADS UP! We inline-require some packages so the SSR build does not break.
// We only need them client-side.
// const providerOptions = isBrowser
// ? {
// walletconnect: {
//   package: WalletConnectProvider,
//   options: { infuraId }
// }
// portis: {
//   package: require('@portis/web3'),
//   options: {
//     id: portisId
//   }
// }
// torus: {
//   package: require('@toruslabs/torus-embed')
//   // options: {
//   //   networkParams: {
//   //     host: oceanConfig.url, // optional
//   //     chainId: 1337, // optional
//   //     networkId: 1337 // optional
//   //   }
//   // }
// }
// }
// : {}

// export const web3ModalOpts = {
//   cacheProvider: true,
//   providerOptions,
//   theme: fancyWeb3ModalTheme
// }

// const refreshInterval = 20000 // 20 sec.

const Web3Context = createContext({} as Web3ProviderValue)

function Web3Provider({ children }: { children: ReactNode }): ReactElement {
  // Kris: this hook should be deleted entirely, after we upgrade to using connect-kit or smtg similar
  const [showFancyMetamaskGuide, setShowFancyMetamaskGuide] =
    useState<boolean>()
  const [updateWallet, setUpdateWallet] = useState<boolean>()

  async function fancyShowMetamaskGuide(state: boolean) {
    setShowFancyMetamaskGuide(state)
  }
  // const { networksList } = useNetworkMetadata()
  // const { appConfig } = useMarketMetadata()

  // const [web3, setWeb3] = useState<Web3>()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  // const [web3Provider, setWeb3Provider] = useState<any>()
  // const [web3Modal, setWeb3Modal] = useState<Web3Modal>()
  // const [web3ProviderInfo, setWeb3ProviderInfo] = useState<IProviderInfo>()
  // const [networkId, setNetworkId] = useState<number>()
  // const [chainId, setChainId] = useState<number>()
  // const [networkDisplayName, setNetworkDisplayName] = useState<string>()
  // const [networkData, setNetworkData] = useState<EthereumListsChain>()
  // const [block, setBlock] = useState<number>()
  // const [isTestnet, setIsTestnet] = useState<boolean>()
  const [accountId, setAccountId] = useState<string>()
  // const [accountEns, setAccountEns] = useState<string>()
  // const [web3Loading, setWeb3Loading] = useState<boolean>(true)
  // const [balance, setBalance] = useState<UserBalance>({
  //   eth: '0',
  //   ocean: '0'
  //   // usdc: '0'
  // })
  // const [isSupportedOceanNetwork, setIsSupportedOceanNetwork] = useState(true)
  // const [approvedBaseTokens, setApprovedBaseTokens] = useState<TokenInfo[]>()
  // const isValidatedProfile = isValidatedLogin()

  // -----------------------------------
  // Logout helper
  // -----------------------------------
  // async function logout() {
  // if (web3 && web3.currentProvider && (web3.currentProvider as any).close) {
  //   await (web3.currentProvider as any).close()
  // }
  // await web3Modal.clearCachedProvider()
  // }

  // async function fancyResetAccount() {
  //   setAccountId(undefined)
  // }

  // -----------------------------------
  // Acentrik: disconnect wallet if wallet Id is associated with an exiting account
  // -----------------------------------
  async function fancyWalletValidation(
    accountId: string,
    isShowFancySuccessMsg = false
  ): Promise<boolean> {
    const walletAccountId = accountId?.toLowerCase()
    if (!localStorage.getItem('jwt-latest-expiry')) {
      keycloakLogout({ reason: 'timeout' })
      return false
    }
    const isWalletCanConnect = await getIsWalletCanConnect(walletAccountId)
    if (!isWalletCanConnect) {
      setAccountId(undefined)
      if (walletAccountId) {
        fancyToast(
          'error',
          'This wallet is associated with an existing account. Please connect to a different wallet.',
          walletAccountId
        )
        LoggerInstance.log(
          '[web3] kick out connection on account id ',
          walletAccountId
        )
      } else {
        fancyToast('error', 'MetaMask Wallet disconnected from platform.')
        LoggerInstance.log('[web3] disconnected MetaMask wallet ')
      }

      return false
    }
    isShowFancySuccessMsg &&
      fancyToast(
        'success',
        'Wallet has been connected successfully.',
        walletAccountId
      )
    return true
  }

  // -----------------------------------
  // Acentrik: set cached provider for auto connect
  // -----------------------------------
  // async function fancySetCachedProvider() {
  // web3Modal?.setCachedProvider(INJECTED_PROVIDER_ID)
  // }

  // -----------------------------------
  // Helper: connect to web3
  // -----------------------------------
  // const connect = useCallback(
  // async (isShowFancySuccessMsg?: boolean) => {
  // if (!web3Modal) {
  //   setWeb3Loading(false)
  //   return
  // }
  // try {
  //   setWeb3Loading(true)
  //   LoggerInstance.log('[web3] Connecting Web3...')

  // const provider = await web3Modal?.connect()
  // setWeb3Provider(provider)

  // const web3 = new Web3(provider)
  // setWeb3(web3)
  // LoggerInstance.log('[web3] Web3 created.', web3)

  // const networkId = await web3.eth.net.getId()
  // setNetworkId(networkId)
  // LoggerInstance.log('[web3] network id ', networkId)

  // const chainId = await web3.eth.getChainId()
  // setChainId(chainId)
  // LoggerInstance.log('[web3] chain id ', chainId)

  // const accountId = (await web3.eth.getAccounts())[0]
  // setAccountId(accountId)
  // LoggerInstance.log('[web3] account id', accountId)

  // await fancyWalletValidation(accountId, isShowFancySuccessMsg)
  //   } catch (error) {
  //     LoggerInstance.error('[web3] Error: ', error?.message)
  //   } finally {
  //     setWeb3Loading(false)
  //   }
  // },
  // [web3Modal]
  // )

  // -----------------------------------
  // Helper: Get approved base tokens list
  // -----------------------------------
  // const getApprovedBaseTokens = useCallback(async (chainId: number) => {
  //   try {
  //     const approvedTokensList = await getOpcsApprovedTokens(chainId)
  //     setApprovedBaseTokens(approvedTokensList)
  //     LoggerInstance.log('[web3] Approved baseTokens', approvedTokensList)
  //   } catch (error) {
  //     LoggerInstance.error('[web3] Error: ', error.message)
  //   }
  // }, [])

  // -----------------------------------
  // Helper: Get user balance
  // -----------------------------------
  // const getUserBalance = useCallback(
  //   async (_accountId?: string) => {
  //     _accountId = _accountId || accountId
  //     if (!_accountId || !networkId || !web3 || !networkData) return

  //     try {
  //       const balance = {
  //         eth: web3.utils.fromWei(
  //           await web3.eth.getBalance(_accountId, 'latest')
  //         ),
  //         ocean:
  //           (await fancyGetTokenBalance(_accountId, networkId, web3)) || '0'
  //         // usdc: await fancyGetTokenBalance(
  //         //   accountId,
  //         //   networkId,
  //         //   web3,
  //         //   TOKENLIST.usdc
  //         // )
  //       }
  //       setBalance(balance)
  //       LoggerInstance.log('[web3] Balance: ', balance)
  //     } catch (error) {
  //       LoggerInstance.error('[web3] Error: ', error.message)
  //     }
  //   },
  //   [accountId, approvedBaseTokens, networkId, web3, networkData]
  // )

  // -----------------------------------
  // Helper: Get user ENS name
  // -----------------------------------
  // const getUserEnsName = useCallback(async () => {
  //   if (!accountId) return

  //   try {
  // const accountEns = await getEnsNameWithWeb3(
  //   accountId,
  //   web3Provider,
  //   `${networkId}`
  // )
  //     const accountEns = await getEnsName(accountId)
  //     setAccountEns(accountEns)
  //     accountEns &&
  //       LoggerInstance.log(
  //         `[web3] ENS name found for ${accountId}:`,
  //         accountEns
  //       )
  //   } catch (error) {
  //     LoggerInstance.error('[web3] Error: ', error.message)
  //   }
  // }, [accountId])

  // -----------------------------------
  // Create initial Web3Modal instance
  // -----------------------------------
  // useEffect(() => {
  //   if (web3Modal) {
  //     setWeb3Loading(false)
  //     return
  //   }

  //   async function init() {
  //     // note: needs artificial await here so the log message is reached and output
  //     const web3ModalInstance = await new Web3Modal(web3ModalOpts)
  //     setWeb3Modal(web3ModalInstance)
  //     LoggerInstance.log(
  //       '[web3] Web3Modal instance created.',
  //       web3ModalInstance
  //     )
  //   }
  //   init()
  // }, [connect, web3Modal])

  // -----------------------------------
  // Reconnect automatically for returning users
  // -----------------------------------
  // useEffect(() => {
  //   if (!web3Modal?.cachedProvider) return

  //   async function connectCached() {
  //     if (isValidatedProfile) {
  //       LoggerInstance.log(
  //         '[web3] Connecting to cached provider: ',
  //         web3Modal.cachedProvider
  //       )
  //       await connect()
  //     }
  //   }
  //   connectCached()
  // }, [connect, web3Modal])

  // -----------------------------------
  // Get and set approved base tokens list
  // -----------------------------------
  // useEffect(() => {
  //   if (web3Loading) return
  //   getApprovedBaseTokens(chainId || 1)
  // }, [chainId, getApprovedBaseTokens, web3Loading])

  // -----------------------------------
  // Get and set user balance
  // -----------------------------------
  // useEffect(() => {
  //   getUserBalance()

  //   // init periodic refresh of wallet balance
  //   const balanceInterval = setInterval(() => getUserBalance(), refreshInterval)

  //   return () => {
  //     clearInterval(balanceInterval)
  //   }
  // }, [getUserBalance])

  // -----------------------------------
  // Get and set user ENS name
  // -----------------------------------
  // useEffect(() => {
  //   getUserEnsName()
  // }, [getUserEnsName])

  // -----------------------------------
  // Get and set network metadata
  // -----------------------------------
  // useEffect(() => {
  //   if (!networkId) return
  //   const networkData = getNetworkDataById(networksList, networkId)
  //   setNetworkData(networkData)
  //   LoggerInstance.log(
  //     networkData
  //       ? `[web3] Network metadata found.`
  //       : `[web3] No network metadata found.`,
  //     networkData
  //   )

  //   // Construct network display name
  //   const networkDisplayName = getNetworkDisplayName(networkData, networkId)
  //   setNetworkDisplayName(networkDisplayName)

  //   setIsTestnet(getNetworkType(networkData) !== NetworkType.Mainnet)

  //   LoggerInstance.log(
  //     `[web3] Network display name set to: ${networkDisplayName}`
  //   )
  // }, [networkId, networksList])

  // -----------------------------------
  // Get and set latest head block
  // -----------------------------------
  // useEffect(() => {
  //   if (!web3) return

  //   async function getBlock() {
  //     const block = await web3.eth.getBlockNumber()
  //     setBlock(block)
  //     LoggerInstance.log('[web3] Head block: ', block)
  //   }
  //   getBlock()
  // }, [web3, networkId])

  // -----------------------------------
  // Get and set web3 provider info
  // -----------------------------------
  // Workaround cause getInjectedProviderName() always returns `MetaMask`
  // https://github.com/oceanprotocol/market/issues/332
  // useEffect(() => {
  //   if (!web3Provider) return

  //   const providerInfo = getProviderInfo(web3Provider)
  //   if (isValidatedProfile) {
  //     setWeb3ProviderInfo(providerInfo)
  //   }
  // }, [web3Provider])

  // -----------------------------------
  // Get valid Networks and set isSupportedOceanNetwork
  // -----------------------------------
  // useEffect(() => {
  //   if (appConfig.chainIdsSupported.includes(networkId)) {
  //     setIsSupportedOceanNetwork(true)
  //   } else {
  //     setIsSupportedOceanNetwork(false)
  //   }
  // }, [networkId, appConfig.chainIdsSupported])

  // -----------------------------------
  // Handle change events
  // -----------------------------------
  // async function handleChainChanged(chainId: string) {
  //   LoggerInstance.log('[web3] Chain changed', chainId)
  //   // const networkId = await web3.eth.net.getId()
  //   setChainId(Number(chainId))
  //   // setNetworkId(Number(networkId))
  // }

  // async function handleNetworkChanged(networkId: string) {
  //   LoggerInstance.log('[web3] Network changed', networkId)
  //   // const chainId = await web3.eth.getChainId()
  //   setNetworkId(Number(networkId))
  //   // setChainId(Number(chainId))
  // }

  // async function handleAccountsChanged(accounts: string[]) {
  //   const isConnectionAllow = await fancyWalletValidation(accounts[0], true)
  //   if (!isConnectionAllow) return
  //   fancySetCachedProvider()
  //   // setWeb3Modal(await new Web3Modal(web3ModalOpts))
  //   LoggerInstance.log('[web3] Account changed', accounts[0])
  //   // setAccountId(accounts[0])
  //   // await getUserBalance(accounts[0])
  // }

  // function toFancyChecksumAddress(tokenAddress: string) {
  // let did = Web3?.utils?.toChecksumAddress(tokenAddress)
  // if (!did && tokenAddress) {
  //   did = tokenAddress.toLowerCase()
  // }
  // return did
  // }

  // useEffect(() => {
  //   if (!web3Provider || !web3) return

  //   web3Provider.on('chainChanged', handleChainChanged)
  //   web3Provider.on('networkChanged', handleNetworkChanged)
  //   web3Provider.on('accountsChanged', handleAccountsChanged)

  //   return () => {
  //     web3Provider.removeListener('chainChanged', handleChainChanged)
  //     web3Provider.removeListener('networkChanged', handleNetworkChanged)
  //     web3Provider.removeListener('accountsChanged', handleAccountsChanged)
  //   }
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [web3Provider, web3])

  // -----------------------------------
  // To check if metamask is installed
  // -----------------------------------
  // const fancyHasMetamask = async () => {
  //   return window?.ethereum?.isMetaMask
  // }

  return (
    <Web3Context.Provider
      value={{
        // web3,
        // web3Provider,
        // web3Modal,
        // web3ProviderInfo,
        // accountId,
        // accountEns,
        // balance,
        // networkId,
        // chainId,
        // networkDisplayName,
        // networkData,
        // block,
        // isTestnet,
        // web3Loading,
        // isSupportedOceanNetwork,
        // approvedBaseTokens,
        showFancyMetamaskGuide,
        // connect,
        // logout,
        // fancyResetAccount,
        // toFancyChecksumAddress,
        // fancySetCachedProvider,
        fancyShowMetamaskGuide,
        fancyWalletValidation,
        updateWallet,
        setUpdateWallet
        // fancyHasMetamask
      }}
    >
      {children}
    </Web3Context.Provider>
  )
}

// Helper hook to access the provider values
const useWeb3 = (): Web3ProviderValue => useContext(Web3Context)

export { Web3Provider, useWeb3, Web3Context }
export default Web3Provider
