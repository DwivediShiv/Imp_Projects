export interface OpcFee {
  chainId: number
  swapNotApprovedFee: string
  swapApprovedFee: string
  approvedTokens: string[]
}

export interface AppConfig {
  metadataCacheUri: string
  chainIds: number[]
  chainIdsSupported: number[]
  defaultDatatokenTemplateIndex: number
  marketFeeAddress: string
  publisherMarketOrderFee: string
  publisherMarketFixedSwapFee: string
  consumeMarketOrderFee: string
  consumeMarketFixedSwapFee: string
  currencies: string[]
  coingeckoTokenIds: string[]
  allowFixedPricing: string
  allowFreePricing: string
  defaultPrivacyPolicySlug: string
  privacyPreferenceCenter: string
  darkModeConfig: {
    classNameDark: string
    classNameLight: string
    storageKey: string
  }
  v3MetadataCacheUri: string
  v3MarketUri: string
}

export interface FancyAppConfig extends AppConfig {
  network: string
  metadataCacheUri: string
  chainIds: any
  chainIdsSupported: any
  rbac: {
    url: string
    validateMechanism: string
    authService: string
  }
  marketFeeAddress: string
  publisherMarketOrderFee: string
  publisherMarketPoolSwapFee: string
  publisherMarketFixedSwapFee: string
  consumeMarketOrderFee: string
  consumeMarketPoolSwapFee: string
  consumeMarketFixedSwapFee: string
  currencies: string[]
  coingeckoTokenIds: string[]
  stableCoin: {
    goerli: {
      address: string
      ticker: string
      decimals: number
    }
    sepolia: {
      address: string
      ticker: string
      decimals: number
    }
    polygon: {
      address: string
      ticker: string
      decimals: number
    }
    amoy: {
      address: string
      ticker: string
      decimals: number
    }
    supernetTestnet: {
      address: string
      ticker: string
      decimals: number
    }
    'gen-x-testnet': {
      address: string
      ticker: string
      decimals: number
    }
    'acentrik-testnet': {
      address: string
      ticker: string
      decimals: number
    }
  }
  transaction: {
    goerli: {
      gasEstimateNftAddress: string
      gasEstimateNftOwnerAddress: string
      transactionBlockTimeout: number
      transactionConfirmationBlocks: number
      transactionPollingTimeout: number
      gasFeeMultiplier: number
      periodicCheckTransactionDuration: number
      periodicCheckTransactionCycle: number
    }
    sepolia: {
      gasEstimateNftAddress: string
      gasEstimateNftOwnerAddress: string
      transactionBlockTimeout: number
      transactionConfirmationBlocks: number
      transactionPollingTimeout: number
      gasFeeMultiplier: number
      periodicCheckTransactionDuration: number
      periodicCheckTransactionCycle: number
    }
    polygon: {
      gasEstimateNftAddress: string
      gasEstimateNftOwnerAddress: string
      transactionBlockTimeout: number
      transactionConfirmationBlocks: number
      transactionPollingTimeout: number
      gasFeeMultiplier: number
      periodicCheckTransactionDuration: number
      periodicCheckTransactionCycle: number
    }
    amoy: {
      transactionBlockTimeout: number
      transactionConfirmationBlocks: number
      transactionPollingTimeout: number
      gasFeeMultiplier: number
      periodicCheckTransactionDuration: number
      periodicCheckTransactionCycle: number
    }
    supernetTestnet: {
      transactionBlockTimeout: number
      transactionConfirmationBlocks: number
      transactionPollingTimeout: number
      gasFeeMultiplier: number
      periodicCheckTransactionDuration: number
      periodicCheckTransactionCycle: number
    }
    'gen-x-testnet': {
      transactionBlockTimeout: number
      transactionConfirmationBlocks: number
      transactionPollingTimeout: number
      gasFeeMultiplier: number
      periodicCheckTransactionDuration: number
      periodicCheckTransactionCycle: number
    }
    'acentrik-testnet': {
      transactionBlockTimeout: number
      transactionConfirmationBlocks: number
      transactionPollingTimeout: number
      gasFeeMultiplier: number
      periodicCheckTransactionDuration: number
      periodicCheckTransactionCycle: number
    }
    progressStepperAttentionCountdown: number
    retry: number
  }
  portisId: string
  analyticsId: string
  computeOutputExpiry: string
  allowFixedPricing: string
  allowDynamicPricing: string
  allowFreePricing: string
  allowHttpAssetEndpoint: string
  source: string
  networkConfig: {
    multiChainEncryptionProviderUri: string
    goerli: {
      providerUri: string
      subgraphUri: string
      marketFeeAddress: string
      encryptionProviderUri: string
      rpc: string
    }
    sepolia: {
      providerUri: string
      subgraphUri: string
      marketFeeAddress: string
      encryptionProviderUri: string
      rpc: string
    }
    polygon: {
      providerUri: string
      subgraphUri: string
      marketFeeAddress: string
      encryptionProviderUri: string
      rpc: string
    }
    amoy: {
      providerUri: string
      subgraphUri: string
      marketFeeAddress: string
      encryptionProviderUri: string
      rpc: string
    }
    supernetTestnet: {
      providerUri: string
      subgraphUri: string
      marketFeeAddress: string
      encryptionProviderUri: string
      rpc: string
    }
    'gen-x-testnet': {
      providerUri: string
      subgraphUri: string
      marketFeeAddress: string
      encryptionProviderUri: string
      rpc: string
    }
    'acentrik-testnet': {
      providerUri: string
      subgraphUri: string
      marketFeeAddress: string
      encryptionProviderUri: string
      rpc: string
    }
  }
  ipfs: {
    gatewayUri: string
    uploadLimit: string
    eulaUploadLimit: string
    imageUploadLimit: string
  }
  api: string
  site: {
    baseUrl: string
    matomoBaseUrl: string
    matomoSiteId: number
    isEnableMatomo: string
    cookieSecure: string
    webPortalUrl: string
    assetManagementTokenSymbolPrefix: string
    assetManagementTokenName: string
  }
  allowAdvancedSettings: string
  allowAdvancedPublishSettings: string
  credentialType: string
  supportEmail: string
  requestTimeout: number
  defaultPrivacyPolicySlug: string
  privacyPreferenceCenter: string
  darkModeConfig: {
    classNameDark: string
    classNameLight: string
    storageKey: string
  }
  customization: {
    isDisableParameterizeAsset: string
    isDisableCustomDocker: string
    isDisableCustomDockerValidation: string
    isDisableRbacMultipleCredentialType: string
    isDisableDeveloperDetail: string
    isDisableCompanyNameChangeAcknowledgement: string
    companyNameChangeDate: string
    theme: string
    isDisableFilterByContract: string
    dateFormat: string
    bucketName: string
  }
}
export interface SiteContent {
  siteTitle: string
  siteTagline: string
  siteUrl: string
  siteIcon: string
  siteImage: string
  copyright: string
  menu: {
    name: string
    // fancy menu
    link?: string
    private?: boolean
    subMenu?: {
      name: string
      private?: boolean
      link?: string
    }[]
  }[]
  announcement: string
  warning: {
    ctd: string
  }
}

export interface MarketMetadataProviderValue {
  opcFees: OpcFee[]
  siteContent: SiteContent
  appConfig: FancyAppConfig
  getOpcFeeForToken: (tokenAddress: string, chainId: number) => string
  approvedBaseTokens: TokenInfo[]
}
