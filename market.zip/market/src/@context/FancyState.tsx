import React, {
  useEffect,
  useState,
  ReactElement,
  createContext,
  useContext,
  ReactNode
} from 'react'
import { SelectionOption } from '../@types/SelectionOption'
import {
  getSelectionOptions,
  getOrganisationOption
} from '@utils/fancySelectionOption'
import AssetFilters from 'src/@types/AssetFilters'
import { getAssetFilters as getAssetFiltersRequest } from '@utils/fancyAssetFilter'
import { OrganisationOption } from '../@types/OrganisationOption'

interface FancyStateValue {
  selectionOptions: any
  getSelectionOptionsByCategory: (category?: string) => SelectionOption[]
  assetFilters: AssetFilters
  getAssetFilters: () => Promise<void>
  organisationOptions: OrganisationOption[]
  getOrganisationOptions: () => Promise<OrganisationOption[]>
}

const FancyStateContext = createContext({} as FancyStateValue)

function FancyStateProvider({
  children
}: {
  children: ReactNode
}): ReactElement {
  const [selectionOptions, setSelectionOptions] = useState([])
  const [assetFilters, setAssetFilters] = useState<AssetFilters>(null)
  const [organisationOptions, setOrganisationOptions] = useState<
    OrganisationOption[]
  >([])
  function getSelectionOptionsByCategory(category?: string): SelectionOption[] {
    if (!category) return selectionOptions
    return (
      selectionOptions?.filter((option: any) => option.category === category) ??
      []
    )
  }

  async function getAssetFilters(): Promise<void> {
    try {
      const _assetFilters = await getAssetFiltersRequest()
      setAssetFilters(_assetFilters)
    } catch (err: any) {
      console.error('Unable to retrieve asset filter criteria')
    }
  }

  async function getOrganisationOptions(): Promise<OrganisationOption[]> {
    try {
      const organisationOptions = await getOrganisationOption()
      setOrganisationOptions(organisationOptions)
      return organisationOptions
    } catch (err: any) {
      console.error('Unable to retrieve organisations')
    }
  }

  useEffect(() => {
    let attempt = 0
    const maxAttempt = 3

    async function getSelectOptions() {
      try {
        const response = await getSelectionOptions()
        const organisationOptions = await getOrganisationOption()
        setSelectionOptions(response)
        setOrganisationOptions(organisationOptions)
      } catch (err: any) {
        if (attempt < maxAttempt) {
          attempt++
          getSelectOptions()
        }
      }
    }

    getAssetFilters()
    getSelectOptions()
    getOrganisationOptions()
  }, [])

  return (
    <FancyStateContext.Provider
      value={{
        selectionOptions,
        getSelectionOptionsByCategory,
        assetFilters,
        getAssetFilters,
        organisationOptions,
        getOrganisationOptions
      }}
    >
      {children}
    </FancyStateContext.Provider>
  )
}

function useFancyState(): FancyStateValue {
  return useContext(FancyStateContext)
}

export { useFancyState }
export default FancyStateProvider
