import React, { useCallback, useMemo, useEffect, useState } from 'react'
import { WagmiBiconomySocialLogin } from '@utils/socialLogin/WagmiBiconomySocialLogin'
import { WagmiBiconomyConnector } from '@utils/socialLogin/WagmiBiconomyConnector'
import {
  getUserEmail,
  getAbstractDetails,
  isAdminRole,
  isSuperAdminRole,
  isLoggedIn
} from '@utils/auth'
import { useAccount, useConnect } from 'wagmi'
import {
  WagmiBiconomyLoginContext,
  WagmiBiconomyLoginContextProps
} from './context'
import { useAuthorize } from '@context/Authorize'
import {
  AbstractRoleTypes,
  ISocialLoginProps,
  WagmiBiconomyLoginProviderOptions
} from '../../@types/SmartAccount'
import FancyToast from '@components/@shared/fancy/atoms/Toast/FancyToast'
import { getSocialLoginParams } from '@utils/wallet'
import {
  ROLE_SUPERADMIN,
  ROLE_ADMIN,
  ROLE_USER
} from '@components/@shared/fancy/constants/RoleConstants'
import {
  ONE_SECOND_IN_MS,
  REFRESH_SMARTACCOUNT_INTERVAL
} from '@components/Constants'

export default function WagmiBiconomyLoginProvider(
  options: WagmiBiconomyLoginProviderOptions
) {
  const { connectAsync } = useConnect()
  const { isConnected } = useAccount()
  const [biconomySocialLogin, setBiconomySocialLogin] =
    useState<ISocialLoginProps | null>(null)
  const [wagmiConnector, setWagmiConnector] =
    useState<WagmiBiconomyConnector | null>(null)
  const [updateSDK, setUpdateSDK] = useState<boolean>(false)
  const { isAccountAbstract, isLogin } = useAuthorize()
  const [updateSmartAccount, setUpdateSmartAccount] = useState<boolean>(false)
  const [abortUpdate, setAbortUpdate] = useState<boolean>(false)

  const refreshBalanceInterval =
    REFRESH_SMARTACCOUNT_INTERVAL * ONE_SECOND_IN_MS

  const initializeConnector = useCallback(async () => {
    if (!biconomySocialLogin) {
      const socialLogin = new WagmiBiconomySocialLogin({
        loginOptions: getSocialLoginParams()
      })
      const connector = new WagmiBiconomyConnector({
        options: {
          biconomySocialLogin: socialLogin
        }
      })
      setBiconomySocialLogin(socialLogin)
      setWagmiConnector(connector)
    }
  }, [biconomySocialLogin])

  initializeConnector()

  const updateBiconomyInstance = useCallback(
    (newInstance: ISocialLoginProps) => {
      setBiconomySocialLogin(newInstance)
    },
    []
  )

  const updateBiconomySmartAccount = useCallback(() => {
    setUpdateSmartAccount(true)
  }, [])

  useEffect(() => {
    async function connectorRefresh(): Promise<void> {
      const { pathname } = window.location
      const onLogin = pathname.indexOf('/login') !== -1
      if (
        isLogin &&
        isAccountAbstract &&
        !onLogin &&
        updateSmartAccount &&
        !abortUpdate
      ) {
        const isSuperAdmin = await isSuperAdminRole(ROLE_SUPERADMIN)
        const isAdmin = isAdminRole()
        const userRole: AbstractRoleTypes = isSuperAdmin
          ? ROLE_SUPERADMIN
          : isAdmin
          ? ROLE_ADMIN
          : ROLE_USER

        const {
          accountAddress: orgSmartAccount,
          orgId,
          paymasterSetupStatus,
          svmDetails,
          accountAbstractionProvider
        } = await getAbstractDetails()
        if (userRole !== ROLE_SUPERADMIN && !orgSmartAccount) {
          FancyToast('error', 'Error on fetching Organization SmartAccount')
          return
        }
        wagmiConnector?.setMetadata({
          enableSession: true,
          userMail: getUserEmail(),
          userRole,
          paymasterSetupStatus,
          orgSmartAccount,
          orgId,
          svmDetails,
          accountAbstractionProvider
        })

        if (!isConnected) {
          await connectAsync({
            connector: wagmiConnector
          })
        } else {
          await wagmiConnector.connect({
            connector: wagmiConnector
          })
        }
        setUpdateSDK(true)
      }
    }

    try {
      connectorRefresh()
    } catch {
      console.error('Error Occured while updating SmartAccount')
    } finally {
      setUpdateSmartAccount(false)
    }
  }, [isLogin, isAccountAbstract, updateSmartAccount, abortUpdate])

  useEffect(() => {
    let getSmartAccountBalanceInterval: NodeJS.Timer
    if (isAccountAbstract) {
      updateBiconomySmartAccount()
      getSmartAccountBalanceInterval = setInterval(
        updateBiconomySmartAccount,
        refreshBalanceInterval
      )
    } else if (!isLoggedIn() && biconomySocialLogin?.getSmartAccount()) {
      const newSocialLoginInstance = biconomySocialLogin?.newInstance(true)

      setBiconomySocialLogin(newSocialLoginInstance)
      const newConnectorInstance = new WagmiBiconomyConnector({
        options: {
          biconomySocialLogin: newSocialLoginInstance as any
        }
      })
      setWagmiConnector(newConnectorInstance)
    }
    return () => clearInterval(getSmartAccountBalanceInterval)
  }, [isAccountAbstract, updateBiconomySmartAccount])

  useEffect(() => {
    if (updateSDK && isLogin && isAccountAbstract) {
      const newInstance = biconomySocialLogin.newInstance()
      updateBiconomyInstance(newInstance)
      setUpdateSDK(false)
    }
  }, [updateSDK, isLogin, isAccountAbstract])

  const value = useMemo<WagmiBiconomyLoginContextProps>(
    () => ({
      biconomySocialLogin,
      wagmiConnector,
      updateBiconomyInstance,
      setAbortUpdate
    }),
    [biconomySocialLogin, wagmiConnector]
  )

  return (
    <WagmiBiconomyLoginContext.Provider value={value}>
      {options.children}
    </WagmiBiconomyLoginContext.Provider>
  )
}
