import { ISocialLoginProps } from '../../@types/SmartAccount'
import { WagmiBiconomyConnector } from '@utils/socialLogin/WagmiBiconomyConnector'
import { createContext } from 'react'

export interface WagmiBiconomyLoginContextProps {
  biconomySocialLogin: ISocialLoginProps | null
  wagmiConnector: WagmiBiconomyConnector | null
  updateBiconomyInstance: (newInstance: ISocialLoginProps) => void
  setAbortUpdate: React.Dispatch<React.SetStateAction<boolean>>
}

export const WagmiBiconomyLoginContext = createContext(
  {} as WagmiBiconomyLoginContextProps
)
