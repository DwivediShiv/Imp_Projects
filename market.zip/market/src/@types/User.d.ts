export interface UserProfileRoles {
  roles: string[]
  wallets: Wallet[]
}

export interface Wallet {
  address: string
  roles: string[]
}
export interface ManageWalletRole {
  address: string
  roles: string[]
  state: State
}

export interface AddUserFormSchema {
  email: string
  country: string
  remarks?: string
}

export interface AddUserModalProps {
  isOpen: boolean
  setIsModalOpen: (flag: boolean) => void
  handleToggleModal: () => void
}

export interface UserInfo {
  username: string
  isMarketingConsent: boolean
  isUserValidated: boolean
  isUserAdmin: boolean
  isEmailVerified: boolean
  isDomainVerified: boolean
  lastLoginDate?: string
  marketingConsentDate?: string
  userValidateDate?: string
}

export interface IUserAttributes {
  COUNTRY?: string[]
  CREATED_BY?: string[]
  CREATED_DATE?: string[]
  INVITATION_ACCEPTED_ON?: string[]
  LAST_LOGIN?: string[]
  USER_VALIDATE_DATE?: string[]
  LOGIN_COUNT?: string[]
  ORG_ID?: string[]
  ROLES_WALLET?: string[]
  STATE?: string[]
  UPDATE_DATE?: string[]
  REMARK?: string[]
}

export interface IUserDetailsResult {
  id: string
  createdTimestamp: Date
  username: string
  enabled: boolean
  emailVerified: boolean
  email: string
  attributes: IUserAttributes
}

export interface IUserInfo {
  id: string
  username: string
  isUserValidated?: boolean
  isUserAdmin: boolean
  isUserSuperAdmin: boolean
  isEmailVerified: boolean
  lastLoginDate: string
  userValidateDate: string
  attributes: IUserAttributes
  state: string
  remark: string
  email?: string
  isPublisherOrConsumer?: boolean
}

export interface SearchUser {
  page?: number = '1'
  email?: string = ''
  domain?: string = ''
  companyName?: string = ''
  country?: string = ''
  purpose?: string = ''
  isEmailVerified?: string = ''
  isValidated?: string = ''
  isMarketingConsent?: string = ''
  numberRecord?: number = 10
  sortBy?: string = ''
  sortOrder?: string = ''
}

export enum State {
  Add = 'add',
  Update = 'update',
  Delete = 'delete'
}
