interface PagedAssets {
  results: Asset[]
  page: number
  totalPages: number
  totalResults: number | any
  aggregations: any
}
