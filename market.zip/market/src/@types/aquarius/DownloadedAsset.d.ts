interface DownloadedAsset {
  dtSymbol: string
  timestamp: number
  networkId: number
  asset: Asset
}
