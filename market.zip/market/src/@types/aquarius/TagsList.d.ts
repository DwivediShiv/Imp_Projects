interface AggregatedTag {
  doc_count: number
  key: string
}
