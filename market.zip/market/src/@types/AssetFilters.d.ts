export default interface AssetFilters {
  owners: string[]
}
