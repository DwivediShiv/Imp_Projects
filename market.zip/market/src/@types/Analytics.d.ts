interface PageViews {
  count: number
  did: string
}
