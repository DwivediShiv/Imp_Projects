/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FancyOrderTransaction
// ====================================================

export interface FancyOrderTransaction_orders {
  __typename: 'Order'
  block: number
  tx: string
}

export interface FancyOrderTransaction {
  orders: FancyOrderTransaction_orders[]
}

export interface FancyOrderTransactionVariables {
  datatoken?: string | null
  payer?: string | null
  createdTimestamp?: number | null
}
