/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AssetsFreePrice
// ====================================================

export interface AssetsFreePrice_dispensers_token {
  __typename: "Token";
  id: string;
  address: string;
}

export interface AssetsFreePrice_dispensers {
  __typename: "Dispenser";
  token: AssetsFreePrice_dispensers_token;
  active: boolean;
  allowedSwapper: string | null;
  isMinter: boolean | null;
  /**
   * max tokens that can be dispensed
   */
  maxTokens: any;
  /**
   * max balance of requester. If the balance is higher, the dispense is rejected
   */
  maxBalance: any;
  /**
   * if using the enterprise template the owner will always be the erc721 factory, for normal template it will a user
   */
  owner: string | null;
}

export interface AssetsFreePrice {
  dispensers: AssetsFreePrice_dispensers[];
}

export interface AssetsFreePriceVariables {
  datatoken_in?: string[] | null;
}
