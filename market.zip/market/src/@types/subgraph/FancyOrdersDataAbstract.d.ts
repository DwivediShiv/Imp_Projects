/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FancyOrdersDataAbstract
// ====================================================

export interface FancyOrdersDataAbstract_orders_consumer {
  __typename: 'User'
  id: string
}

export interface FancyOrdersDataAbstract_orders_datatoken_nft {
  __typename: 'Nft'
  /**
   * same as id, it's just for easy discoverability
   */
  address: string
}

export interface FancyOrdersDataAbstract_orders_datatoken {
  __typename: 'Token'
  id: string
  address: string
  symbol: string | null
  /**
   * address of ERC721 that owns the token, valid only for datatokens
   */
  nft: FancyOrdersDataAbstract_orders_datatoken_nft | null
}

export interface FancyOrdersDataAbstract_orders {
  __typename: 'Order'
  consumer: FancyOrdersDataAbstract_orders_consumer
  datatoken: FancyOrdersDataAbstract_orders_datatoken
  providerFee: string | null
  createdTimestamp: number
  tx: string
}

export interface FancyOrdersDataAbstract {
  orders: FancyOrdersDataAbstract_orders[]
}

export interface FancyOrdersDataAbstractVariables {
  user_in?: string[] | null
}
