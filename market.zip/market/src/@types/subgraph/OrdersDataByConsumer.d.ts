/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: OrdersDataByConsumer
// ====================================================

export interface OrdersDataByConsumer_orders_consumer {
  __typename: "User";
  id: string;
}

export interface OrdersDataByConsumer_orders_datatoken {
  __typename: "Token";
  address: string;
  symbol: string | null;
}

export interface OrdersDataByConsumer_orders {
  __typename: "Order";
  consumer: OrdersDataByConsumer_orders_consumer;
  datatoken: OrdersDataByConsumer_orders_datatoken;
  createdTimestamp: number;
  tx: string;
}

export interface OrdersDataByConsumer {
  orders: OrdersDataByConsumer_orders[];
}

export interface OrdersDataByConsumerVariables {
  user_in?: string[] | null;
}
