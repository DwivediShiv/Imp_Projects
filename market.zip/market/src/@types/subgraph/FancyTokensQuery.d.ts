/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FancyTokensQuery
// ====================================================

export interface FancyTokensQuery_tokens_nft {
  __typename: 'Nft'
  /**
   * same as id, it's just for easy discoverability
   */
  address: string
}

export interface FancyTokensQuery_tokens {
  __typename: 'Token'
  /**
   * datatoken creation transaction id
   */
  tx: string
  address: string
  /**
   * address of ERC721 that owns the token, valid only for datatokens
   */
  nft: FancyTokensQuery_tokens_nft | null
}

export interface FancyTokensQuery {
  tokens: FancyTokensQuery_tokens[]
}

export interface FancyTokensQueryVariables {
  publisherAddress: string
  symbol?: string | null
  name?: string | null
  createdTimestamp?: number | null
}
