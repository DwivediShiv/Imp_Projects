/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FancyGetSalesOrders
// ====================================================

export interface FancyGetSalesOrders_orders_datatoken {
  __typename: 'Token'
  id: string
}

export interface FancyGetSalesOrders_orders_payer {
  __typename: 'User'
  id: string
}

export interface FancyGetSalesOrders_orders_consumer {
  __typename: 'User'
  id: string
}

export interface FancyGetSalesOrders_orders {
  __typename: 'Order'
  datatoken: FancyGetSalesOrders_orders_datatoken
  createdTimestamp: number
  tx: string
  payer: FancyGetSalesOrders_orders_payer
  consumer: FancyGetSalesOrders_orders_consumer
  lastPriceValue: any
}

export interface FancyGetSalesOrders {
  orders: FancyGetSalesOrders_orders[]
}

export interface FancyGetSalesOrdersVariables {
  nftOwner_in?: string[] | null
}
