/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AssetFrePrice
// ====================================================

export interface AssetFrePrice_fixedRateExchanges_baseToken {
  __typename: "Token";
  id: string;
  symbol: string | null;
  address: string;
}

export interface AssetFrePrice_fixedRateExchanges_datatoken {
  __typename: "Token";
  id: string;
  address: string;
  symbol: string | null;
}

export interface AssetFrePrice_fixedRateExchanges {
  __typename: "FixedRateExchange";
  /**
   * fixed rate exchange id
   */
  id: string;
  price: any;
  baseToken: AssetFrePrice_fixedRateExchanges_baseToken;
  datatoken: AssetFrePrice_fixedRateExchanges_datatoken;
}

export interface AssetFrePrice {
  fixedRateExchanges: AssetFrePrice_fixedRateExchanges[];
}

export interface AssetFrePriceVariables {
  datatoken?: string | null;
}
