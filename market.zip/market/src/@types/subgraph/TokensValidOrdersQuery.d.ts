/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: TokensValidOrdersQuery
// ====================================================

export interface TokensValidOrdersQuery_tokens_orders {
  __typename: 'Order'
  tx: string
  createdTimestamp: number
  providerFee: string | null
}

export interface TokensValidOrdersQuery_tokens {
  __typename: 'Token'
  id: string
  /**
   * orders created with the datatoken, only available for datatokens
   */
  orders: TokensValidOrdersQuery_tokens_orders[] | null
}

export interface TokensValidOrdersQuery {
  tokens: TokensValidOrdersQuery_tokens[]
}

export interface TokensValidOrdersQueryVariables {
  datatokenId: string
}
