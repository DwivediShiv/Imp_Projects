export interface SelectionOption {
  id: number
  name: string
  key: string
  category: string
  sortOrder: number
  source?: string
  sourceId?: string
}
