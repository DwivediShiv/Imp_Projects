import { JwtPayload } from 'jwt-decode'
export interface ResponseToken {
  token: string
  expiry: number
}
export interface JWTActionToken extends JwtPayload {
  email: string
}
