interface AccountTeaserVM {
  address: string
  nrSales: number
}
