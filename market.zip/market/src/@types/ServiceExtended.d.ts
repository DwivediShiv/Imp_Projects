import { Service } from '@oceanprotocol/lib'
import { AssetParameters } from 'src/components/Publish/_types'

export interface ServiceExtended extends Service {
  consumerParameters?: AssetParameters[]
}
