interface UserBalance {
  // eth: string
  // ocean: string
  [key: string]: string
  // usdc: string
}
