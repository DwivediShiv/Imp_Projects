export interface OrganisationOption {
  id: number
  name: string
}
