import { GridSize } from '@mui/material'
import { AssetSelectionAsset } from '@shared/FormInput/InputElement/AssetSelection'
import { PasswordPolicy } from '../components/molecules/FormFields/PasswordStrength'

export interface FormFieldProps {
  label?: string
  extraLabel?: string
  name: string
  value?: string
  decimal?: boolean
  type?: string
  options?: string[] | AssetSelectionAsset[]
  optionType?: string
  sortOptions?: boolean
  required?: boolean
  multiple?: boolean
  disabled?: boolean
  help?: string
  placeholder?: string
  pattern?: string
  min?: string
  step?: string
  passwordPolicies?: PasswordPolicy[]
  addonInput?: FormFieldProps
  combineWith?: string[]
  isPartOfCombination?: boolean
  gridSize?: GridSize
  optionCategory?: string
  optionKey?: string
  previewTitle?: string
  tooltip?: string
  infotip?: string
  isEditDisabled?: boolean
  disclaimer?: string
  disclaimerValues?: string[]
  advanced?: boolean
  state?: any
  stateMsg?: any
  additionalInformation?: string
  description?: string
  noBoundary?: boolean
}

export interface FormStepContent {
  title: string
  description?: string
  success: string
  asset?: 'dataset' | 'algorithm'
  data: FormFieldProps[]
  tips?: FormTipsProps[]
}

export interface LoginForm {
  email: string
  password: string
  otp?: string
}
export interface UserLogin {
  loginInputs: LoginForm
  setFieldError?: (field: string, errorMsg: string) => void
  otp?: string
  errorCallback?: (error: object) => void
}
export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

export interface MswHandlerProps<T> {
  status?: number
  response?: ApiResponse<T>
}

export interface userLoginRes {
  status?: string
  otpRequired?: string
  access_token?: string
  expires_in?: number
  refresh_expires_in?: number
  refresh_token?: string
  scope?: string
  token_type?: string
}
export interface SignupForm {
  email: string
  password: string
  passwordConfirmation: string
  companyName: string
  industry: string
  country: string
  otherCountry: string
  purpose: string
  isMarketingConsent: bool
}

export interface resetPassForm {
  password: string
  passwordConfirmation: string
}

export interface ChangePassForm {
  currentPassword: string
  password: string
  passwordConfirmation: string
}

export interface ForgetPasswordForm {
  email: string
}

export interface ResetSsoForm {
  email: string
}

export interface ResetFormFieldProps {
  name: string
  label: string
  placeholder: string
  help: string
  type: string
  required: boolean
}
export interface ResetSsoFormFieldProps {
  title: string
  description: string
  form: {
    title: string
    data: ResetFormFieldProps[]
    success: string
    postSuccess: string
  }
}

export interface DomainForm {
  domain: string
  status?: boolean
}

export interface AddDemandBoardForm {
  title: string
  description: string
  purpose: string
  category: string
  accessType: string
  region: string
  source: string
  createdByWallet: string
}

export interface FormTipsProps {
  title: string
  name: string
  content: string
  type: string
  label: string
  step: string
}

export interface ContactUsForm {
  email: string
  inquiryType: string
  message: string
  captcha: string
}

export interface ContactPublisherForm {
  inquiryType: string
  message: string
}

// Kris: Ocean usage merge v4 usage below
export interface FormFieldContent {
  label: string
  name: string
  type?: string
  options?: string[]
  sortOptions?: boolean
  required?: boolean
  multiple?: boolean
  disabled?: boolean
  help?: string
  placeholder?: string
  pattern?: string
  min?: string
  disclaimer?: string
  disclaimerValues?: string[]
  advanced?: boolean
}

interface FormStepContent {
  title: string
  description?: string
  fields: FormFieldContent[]
}
