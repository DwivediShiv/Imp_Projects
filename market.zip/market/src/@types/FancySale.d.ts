interface SalesAsset {
  did: string
  chainId: number
  assetName: string
  assetType: string
  accessType: string
  tokenSymbol?: string
  owner?: string
}

interface Sale extends SalesAsset {
  orderDate: Date
  tx: string
  payer: string
  consumerCompanyName: string
  priceValue: number
  subType?: string
}
