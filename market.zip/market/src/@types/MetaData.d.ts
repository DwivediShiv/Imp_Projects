import {
  Metadata,
  AdditionalInformation,
  ServiceMetadata,
  EditableMetadataLinks,
  ServiceComputeOptions
} from '@oceanprotocol/lib'
import { DataTokenOptions } from '../@hooks/usePublishOld/DataTokenOptions'
import { FileMetadata } from 'src/components/Publish/_types'

export interface DataDetail {
  fileType?: string
  screenshot?: string
}
export interface AdditionalInformationMarket extends AdditionalInformation {
  links?: FileMetadata[]
  source?: string
  isExperimental: boolean
  input?: DataDetail
  output?: DataDetail
  shortDescription?: string
  sampleType?: 'URL' | 'UPLOAD'
  eulaType?: 'URL' | 'UPLOAD'
  eula?: FileMetadata[]
  previousServiceEndpoints?: string[]
}

export interface MetadataMarket extends Metadata {
  // While required for this market, Aquarius/Plecos will keep this as optional
  // allowing external pushes of assets without `additionalInformation`.
  // Making it optional here helps safeguarding against those assets.
  additionalInformation?: AdditionalInformationMarket
}
export interface PriceOptionsMarket extends PriceOptions {
  weightOnOcean: string
  // easier to keep this as number for Yup input validation
  swapFee: number
}

export interface DropzoneFile extends FileMetadata {
  preview: string
}

export interface MetadataPublishForm {
  // ---- required fields ----
  nft: NftMetadata
  providerName: string
  name: string
  description: string
  files: FileMetadata[]
  author: string
  dataTokenOptions: DataTokenOptions
  asset: 'dataset' | 'algorithm'
  algo: string
  access: 'Download' | 'Compute' | string
  allowAllPublishedAlgorithms: boolean
  isExperimental: string | boolean
  timeout: string
  category: string
  chainId: number
  accountId: string

  // ---- optional fields ----
  tags?: string[]
  sampleType?: 'URL' | 'UPLOAD'
  links?: FileMetadata[]
  price?: number
  image?: string
  containerTag?: string
  entrypoint?: string
  sampleUpload?: DropzoneFile[] | string
  shortDescription?: string
  input?: string
  output?: string
  publisherTrustedAlgorithms?: string[]
  eulaType?: 'URL' | 'UPLOAD'
  eula?: FileMetadata[]
  pricing?: PriceOptions // Kris: temp copy ocean
  computeOptions?: ServiceComputeOptions // Kris: temp copy ocean
  providerUrl?: { url: string } // Kris: temp copy ocean. hacky hacky set value in `src/components/Publish/_utils.ts`
}

export interface MetadataPublishFormAlgorithm {
  // ---- required fields ----
  name: string
  description: string
  files: string | FileMetadata[]
  author: string
  dockerImage: string
  algorithmPrivacy: boolean
  timeout: string
  dataTokenOptions: DataTokenOptions
  termsAndConditions: boolean
  // ---- optional fields ----
  image: string
  containerTag: string
  entrypoint: string
  tags?: string
}

export interface MetadataEditForm {
  name: string
  description: string
  timeout: string
  price?: number
  links?: string | EditableMetadataLinks[]
  sampleType?: string
  eula?: string | EditableMetadataLinks[]
  eulaType?: string
}

export interface ServiceMetadataMarket extends ServiceMetadata {
  attributes: MetadataMarket
}
