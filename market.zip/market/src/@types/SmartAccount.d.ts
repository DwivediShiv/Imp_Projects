import { BiconomySmartAccountV2 } from '@biconomy/account'
import { Client } from 'wagmi'
import { Provider } from '@wagmi/core'
import { Signer } from 'ethers'
import { SessionKeyManagerModule } from '@biconomy/modules'
import { TransactionManager } from '@utils/biconomy/transactionManager'
import { SessionLeafNode } from '@biconomy/modules/dist/src/interfaces/ISessionStorage'

export interface AlchemyAccountCredentails {
  apiKey?: string
  policyId?: string
  accessKey?: string
}
export interface PayMasterData extends AlchemyAccountCredentails {
  paymasterKey?: string
  authToken?: string
  ownerEOA?: string
}

export interface PayMasterDetails {
  socialDetails: PayMasterData
  accountAbstractionProvider?: string
}
export interface WhitelistingData {
  [whitelistingKey: string]: boolean
}

export type SmartWalletBalanceForToken = Record<string, string>

export type PaymasterBalanceForChain = Record<string, string>

export interface LoginParams {
  whitelistUrl: string
  whiteLabelName?: string
  whiteLabelLogo?: string
  chainId: number
  network: string
  infuraProjectId: string
  clientId: string
  serverUrl: string
}

export type WagmiClient = Client<Provider, unknown>

export interface WagmiBiconomyLoginProviderOptions {
  children: React.ReactNode
}

export type AbstractRoleTypes = 'user' | 'admin' | 'super-admin'

export interface ConnectorMetadataArgs {
  enableSession: boolean
  userMail: string
  userRole: AbstractRoleTypes
  paymasterSetupStatus: boolean
  orgSmartAccount: string
  orgId: string
  svmDetails: SvmData
  accountAbstractionProvider: string
}

export interface SvmData {
  userSvmChains?: Array<string>
}
export interface BiconomySocialLoginImplOptions {
  loginOptions: LoginParams
}

export type ISocialLoginProps = ISocialLogin<BiconomySmartAccountV2>

export interface ISocialLogin<U> {
  initialize: () => Promise<void>
  login: (args: ConnectorMetadataArgs) => Promise<void>
  logout: () => Promise<void>
  newInstance: (getFreshInstance?: boolean) => ISocialLoginProps
  clearInstance: () => ISocialLoginProps
  getSmartAccount: () => U | null
  getBytecodeHash: (contractAddr: string) => Promise<string | null>
  getTransactionManager: () => TransactionManager | null
  getSessionKeyManagerModule: () => SessionKeyManagerModule | null
  getSigner: () => Signer | null
  getSmartAccountAddress: () => string | null
  getSmartAccountBalance: () => Promise<SmartWalletBalanceForToken | null>
  getSdkPayMasterBalance: () => Promise<PaymasterBalanceForChain | null>
  emailLogin: (
    email: string,
    enableExistingSession: boolean
  ) => Promise<IProvider | null>
  getWeb3auth: () => Web3AuthNoModal | null
  getMerkleTransactionData: (
    sessionKeys: CreateSessionDataParams[]
  ) => Promise<string | null>
  getPrivateKey: () => Promise<string | null>
  getAccountAbstractionProvider: () => string | null
}

export interface ApiResponse<T> {
  data?: T
  error?: string | { message: string }
}

export interface SmartAccountSessionProps {
  merkleRoot: string
  sessionKeys: SessionLeafNode[]
}

export interface AbstractDetails {
  orgId: string
  orgName: string
  accountAbstractionProvider: string
  sessionKey?: SmartAccountSessionProps
  accountAddress: string
  svmDetails?: SvmData
  whiteListingStatus?: any
  paymasterSetupStatus?: boolean
}

export interface AbstractLoginArgs {
  userMail: string
  abstractDetails: AbstractDetails
  userRole: AbstractRoleTypes
}

export interface InstanceDetails {
  orgId: string
  accountType: string
  enablePaymaster: boolean
  name: string
  ssoConfigured: boolean
  ssoEnabled: boolean
}
