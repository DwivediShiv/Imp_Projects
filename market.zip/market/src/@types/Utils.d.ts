import { FileMetadata } from '../@types/Utils'
interface CalcInGivenOutParams {
  tokenInLiquidity: string
  tokenOutLiquidity: string
  tokenOutAmount: string
  opcFee: string
  lpSwapFee: string
  publishMarketSwapFee: string
  consumeMarketSwapFee: string
}

interface FileInfo {
  isConnected: boolean
  checksum?: string
}
interface AssetsFileInfo {
  [did: string]: FileInfo
}
