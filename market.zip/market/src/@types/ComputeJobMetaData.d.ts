import { ComputeJob } from '@oceanprotocol/lib'
import { BaseAssets } from '@utils/fancyProfileData'

export interface ComputeStatus {
  started: boolean
  running: boolean
  failed: boolean
  completed: boolean
  incomplete: boolean
}

export interface ComputeJobMetaData extends ComputeJob, BaseAssets {
  payer: string
  assetDtSymbol: string
  networkId: number
  expiryInDays: string
  assetTimeout?: string
  algoName?: string
  algoTimeout?: string
  providerURL?: string
  isCurrentNetworkId?: boolean
  isAlgoChecksumValid?: boolean
  stopreq?: number
  computeStatus?: ComputeStatus
  guid?: string
  aggregateAlgoDID?: string
  aggregateAlgoName?: string
  federatedAlgoName?: string
  federatedAlgoDID?: string
  jobs?: ComputeJobMetaData[]
  jobsFinished?: number
  totalJobs?: numner
  aggregateJob?: ComputeJobMetaData
  aggregateAlgoTimeout?: string
  provider_session_auth_token?: string
}
