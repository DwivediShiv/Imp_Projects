import { SortOption } from '@components/pages/Profile/FancySortQuery'
import { ReactJSXElement } from '@emotion/react/types/jsx-namespace'
// import { IDataTableColumn } from 'react-data-table-component'
import { TableProps, TableColumn } from 'react-data-table-component'

export interface CustomTableListProps {
  data: any
  sortBy: string
  sortOrder: string
  sortValue?: string
  configuration: Configuration
  totalRecord: number
  paginationSize: number
  handleOnTabChange?: TabChangeHandler
  handleSortChange?: SortChangeHandler
  handleSortOption?: SortOptionHandler
  handlePageChange?: PageChangeHandler
  handleFilterDateChange?: HandleFilterDateHandler
  onSortChange?: (values: string) => void
  page: number
  tabIndex: number
  isLoading: boolean
  state?: string
  handleOnSearch?: SearchEventHandler
  filterCriterias: TransformedFilterCriterias
  filterDateCriterias?: any
  searchValue: string
  hasFilterApplied: FilterDataFunction
  noDataAction?: ReactJSXElement
  noDataText?: ReactJSXElement
  isSelectable?: boolean
  onSelectedRowsChange?: any
  selectedRows?: any
  clearSelectedRows?: any
  noDataIcons?: string
}

export interface Configuration {
  data?: any
  title: string
  columns: Column[]
  tabConfig: TabConfig
  filterCriterias?: {
    Country?: string[]
    Industry?: string[]
    ReferenceOrder?: string[]
    Consumer?: string[]
    Asset?: string[]
  }
  exportConfig?: ExportConfig
  searchConfig: SearchConfig
  sortConfig?: SortConfig
  filterConfig: FilterConfig
  refreshConfig?: any
  buttonConfig?: any
}
export interface FilterConfig {
  clearFilters: ClearFilterHandler
  filters: Filter[]
}

interface ClearFilterHandler {
  (): void
}

export interface Filter {
  id: string
  inputName: string
  type?: 'default' | 'date'
  label?: string
  dynamic?: boolean
  containerClass?: string
  customBackground?: string
  value: Record<string, boolean> | any
  deselectText?: string
  options?: any[] | any
  onValueChange?: SetStateFunction<Record<string, boolean>>
  selectType?: string
  onChange?: any
}

export interface SetStateFunction<T> {
  (newState: T | ((prevState: T) => T)): void
}
export interface ExportConfig {
  exportFn: ExportFn
  fileName: string
}

interface ExportFn {
  (): void
}

export interface SearchConfig {
  type: string
  name: string
  placeholder: string
  searchValue: string
}

export interface SortConfig {
  type: string
  sortOptions: SortOption[]
}

export interface TabConfig {
  name?: string
  defaultTab?: number
  tabList?: TabList[]
  button?: ButtonConfig
  showExport?: boolean
}

export interface TabList {
  title: string
  key: string
  value: string
  index: number
  icon?: 'default' | 'success' | 'danger' | 'warning' | 'disabled'
}

interface ButtonConfig {
  name: string
  color: 'primary' | 'secondary' | 'default'
  variant: 'contained' | 'outlined' | 'text'
  handleClick: () => void
  href: string
}
export interface Column {
  id: string
  title: string
  type: string
  sortable: boolean
  sortBy?: string
  class?: string
  rowConfig?: RowConfig
  grow?: number
  style?: any | string
  sortField?: string
  allowOverflow?: boolean
  cell?: any
}

export interface RowConfig {
  cellType: string
  clickable?: any
  value?: string
  class?: string
  href?: string
  param?: string
  format?: string
  editRoute?: EditRoute
  deleteRoute?: DeleteRoute
  truncate?: number
  newTabIcon?: boolean
}

export interface EditRoute {
  href: string
  param: string
}

export interface DeleteRoute {
  href: string
}

export interface TransformedFilterCriterias {
  [key: string]: { [key: string]: boolean }
}

interface TabChangeHandler {
  (event: React.ChangeEvent<unknown>, newValue: number): void
}

interface SortChangeHandler {
  (column: TableColumn<any>, sortDirection: string): Promise<void>
}

interface SortOptionHandler {
  (option: string): Promise<void>
}
interface PageChangeHandler {
  (page: number): void
}
interface HandleFilterDateHandler {
  (type: string, value: Date, key: string): void
}

interface FilterDataFunction {
  (): boolean
}
interface SearchEventHandler {
  (e: React.ChangeEvent<HTMLInputElement>): void
}
