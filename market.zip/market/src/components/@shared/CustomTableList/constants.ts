export const STATE_CONSTANTS = {
  ACCEPTED: 'Accepted',
  UNVERIFIED: 'Unverified',
  VERIFIED: 'Verified',
  PENDING: 'Pending',
  INVITED: 'Invited',
  INACTIVE: 'Inactive'
}
