import AssetTeaser from '@shared/AssetTeaser'
import React, { ReactElement, useEffect, useState } from 'react'
import Pagination from '@shared/Pagination'
import styles from './index.module.css'
import classNames from 'classnames/bind'
import Loader from '@shared/atoms/Loader'
import { useUserPreferences } from '@context/UserPreferences'
import {
  getUserProfileFromMap,
  getUserProfileMap,
  UserProfile
} from '@utils/keycloakProfile'
import FancyLoader from '@shared/fancy/atoms/Loader/FancyLoader'
import FancyIconicCard, {
  FancyIconicCardSize,
  FancyIconicCardState
} from '@shared/fancy/molecules/FancyIconicCard'
import { useIsMounted } from '@hooks/useIsMounted'
import { Asset } from '@oceanprotocol/lib'
import { getAccessDetailsForAssets } from '@utils/accessDetailsAndPricing'
import { getDataTokensOrderCountMapped } from '@utils/fancySubgraph'
import { useAccount } from 'wagmi'
const cx = classNames.bind(styles)

function LoaderArea() {
  return (
    <div className={styles.loaderWrap}>
      <Loader />
    </div>
  )
}

export declare type AssetListProps = {
  assets: AssetExtended[]
  showPagination: boolean
  page?: number
  totalPages?: number
  isLoading?: boolean
  onPageChange?: React.Dispatch<React.SetStateAction<number>>
  className?: string
  noPublisher?: boolean
  noDescription?: boolean
  noPrice?: boolean
  fancyViewMode?: string
}

export default function AssetList({
  assets,
  showPagination,
  page,
  totalPages,
  isLoading,
  onPageChange,
  className,
  noPublisher,
  fancyViewMode
}: AssetListProps): ReactElement {
  const { chainIds } = useUserPreferences()
  const { address: accountId } = useAccount()
  const [assetsWithPrices, setAssetsWithPrices] = useState<AssetExtended[]>()
  const [loading, setLoading] = useState<boolean>(isLoading)
  const isMounted = useIsMounted()
  const [assetOrderedDictionary, setAssetOrderedDictionary] = useState<{
    [did: string]: number
  }>()
  const [profileMap, setProfileMap] = useState<Map<string, UserProfile>>()
  const [isRequestingProfile, setIsRequestingProfile] = useState<boolean>(true)

  useEffect(() => {
    if (!assets || !isMounted()) return

    async function getUsersProfileMap() {
      setIsRequestingProfile(true)
      const owners = assets.map((asset: Asset) => {
        if (chainIds.indexOf(asset.chainId) === -1) {
          chainIds.push(asset.chainId)
        }
        return asset?.nft?.owner
      })
      const profileMap = await getUserProfileMap(owners)
      setProfileMap(profileMap)
      setIsRequestingProfile(false)
    }
    async function getAssetOrdered() {
      const dids = assets?.map((d) => d?.datatokens[0]?.address)
      const response = await getDataTokensOrderCountMapped(dids, chainIds)
      setAssetOrderedDictionary(response)
    }
    getUsersProfileMap()
    // fetchPrices()

    getAssetOrdered()
    // isLoading && setLoading(true)
    // getAssetsBestPrices(assets).then((asset) => {
    //   setAssetWithPrices(asset)
    // setLoading(false)
    // })
    return () => null
  }, [assets, isMounted, accountId])

  // // This changes the page field inside the query
  function handlePageChange(selected: number) {
    onPageChange(selected)
  }

  const styleClasses = cx({
    assetList: true,
    [className]: className
  })

  return !isLoading ? (
    <>
      {assets?.length > 0 ? (
        <div
          className={`${styleClasses} ${styles.smallGrid}
            ${styles[fancyViewMode]}
          `}
        >
          {assets.map((asset) => (
            <AssetTeaser
              asset={asset}
              key={asset.id}
              orderedCount={
                assetOrderedDictionary &&
                assetOrderedDictionary[asset?.datatokens[0]?.address]
              }
              fancyViewMode={fancyViewMode}
              profile={getUserProfileFromMap(asset.nft.owner, profileMap)}
              noPublisher={noPublisher}
              isRequestingProfile={isRequestingProfile}
            />
          ))}
        </div>
      ) : (
        <div className={`h-100 ${styles.wrapper}`}>
          <FancyIconicCard
            header="No Results Found"
            icon="not-found"
            state={FancyIconicCardState.Warning}
            size={FancyIconicCardSize.Big}
          >
            <div>
              Try adjusting your search by checking the spelling or removing
              some filters.
            </div>
          </FancyIconicCard>
        </div>
      )}
      {showPagination && (
        <Pagination
          totalPages={totalPages}
          currentPage={page}
          onChangePage={handlePageChange}
          showRowPerPage={false}
        />
      )}
    </>
  ) : (
    <div className={`h-100 d-flex center`}>
      <div className={styles.flex}>
        <FancyLoader isCenter />
      </div>
    </div>
  )
}
