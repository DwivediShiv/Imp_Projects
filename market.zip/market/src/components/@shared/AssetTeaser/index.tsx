import React, { ReactElement } from 'react'
import Dotdotdot from 'react-dotdotdot'
import styles from './index.module.css'
import FancyAssetBadge from '@shared/fancy/Teaser/FancyAssetBadge'
import FancyPublisher from '@shared/fancy/FancyPublisher'
import FancyTeaserAdditionalInfo from '@shared/fancy/Teaser/FancyTeaserAdditionalInfo'
import FancyTeaserFooter from '@shared/fancy/Teaser/FancyTeaserFooter'
import { UserProfile } from '@utils/keycloakProfile'
import { ExperimentalIcon } from '@shared/Icon/ExperimentalIcon'
import FancyTooltip from '@shared/fancy/atoms/Tooltip/FancyTooltip'
import NetworkName from '@shared/NetworkName'
import { getServiceByName } from '@utils/ddo'
import { Divider } from '@mui/material'
import { IconSize } from '@utils/constants'
import { formatString } from '@utils/index'

declare type AssetTeaserProps = {
  asset: AssetExtended
  noPublisher?: boolean
  fancyViewMode?: string
  orderedCount?: number
  profile?: UserProfile
  isFancyPreviewAsset?: boolean
  isEdit?: boolean
  isRequestingProfile?: boolean
}

export default function AssetTeaser({
  asset,
  noPublisher,
  fancyViewMode,
  orderedCount,
  profile,
  isEdit,
  isRequestingProfile
}: AssetTeaserProps): ReactElement {
  const {
    name,
    type,
    categories,
    description,
    additionalInformation: addInfo
  } = asset.metadata
  const { datatokens } = asset
  const isCompute = Boolean(getServiceByName(asset, 'compute'))
  const isDownload = Boolean(getServiceByName(asset, 'access'))

  const accessType = isCompute ? 'compute' : isDownload ? 'access' : ''
  const { owner } = asset.nft

  const fancyAttributes = asset.services[0]
  const isFancyPreviewAsset = fancyViewMode === 'fancyPreview'
  const isFancyAdditionalAssetView =
    fancyViewMode === 'fancyAdditionalAssetView'
  const fancyTitleLineCount = 2
  const fancyDescriptionLineCount = 3

  const { additionalInformation } = fancyAttributes as any

  const fancyDescrption = description || ''
  return (
    <article
      className={`${styles.teaser} ${styles[type]} ${styles[fancyViewMode]}`}
    >
      <div
        className={`${styles.link} ${styles.fancyLink} ${styles[fancyViewMode]}`}
      >
        <div
          className={`${styles.fancyBadgeContainer} ${styles[fancyViewMode]}`}
        >
          <div>
            <FancyAssetBadge title={type} />
            <FancyAssetBadge title={accessType} parentTitle={type} />
          </div>
          {additionalInformation?.isExperimental && (
            <div className={styles.fancyExperimental}>
              <FancyTooltip
                type="custom"
                icon={<ExperimentalIcon iconSize={IconSize.Large} />}
                title="This is an experimental asset. It does not contain real values."
              />
            </div>
          )}
        </div>
        <div className={`${styles.header} ${styles.fancyContainer}`}>
          <div className={styles.fancyHeader}>
            <div className={styles.fancyCategory}>
              <span>
                <span className={styles.categoryName}>
                  {formatString(categories?.[0]) || 'Uncategorized'}
                </span>
              </span>
            </div>
            <Dotdotdot
              clamp={fancyTitleLineCount}
              tagName="h5"
              useNativeClamp
              className={`${styles.title} ${styles.fancyTitle} bold`}
            >
              <span title={name}>{name}</span>
            </Dotdotdot>
          </div>
          <FancyPublisher
            profile={profile}
            className={styles.publisher}
            fancyViewMode={fancyViewMode}
            clamp={2}
            minimal
            hasPublishedBy
            showOrgPublisher={(addInfo && addInfo.organization) || null}
            isRequestingProfile={isRequestingProfile}
          />
        </div>

        <div className={styles.fancyParentContainer}>
          <div className={`${styles.content} ${styles.fancyContainer}`}>
            <Dotdotdot
              clamp={fancyDescriptionLineCount}
              useNativeClamp
              className={`${styles.fancyDescription}`}
            >
              {fancyDescrption}
            </Dotdotdot>
          </div>

          {!isFancyAdditionalAssetView && (
            <div className={styles.fancyContainer}>
              <FancyTeaserAdditionalInfo
                metadata={asset.metadata}
                serviceAccessAttributes={fancyAttributes}
                accessType={accessType}
                viewMode={fancyViewMode}
                orderedCount={orderedCount}
                chainId={asset.chainId}
                isEdit={isEdit}
              />
            </div>
          )}
        </div>

        <div className={styles.combined}>
          {!isFancyPreviewAsset && (
            <FancyTeaserFooter ddoId={asset.id} viewMode={fancyViewMode} />
          )}
        </div>
      </div>
    </article>
  )
}
