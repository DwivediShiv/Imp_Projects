import React, { ReactElement, ReactNode, useEffect } from 'react'
import classNames from 'classnames/bind'
import styles from './index.module.css'
import clsx from 'clsx'
import { isNewDesign } from '@utils/platformSetting'

const cx = classNames.bind(styles)
export interface ContainerProps {
  children: ReactNode
  narrow?: boolean
  className?: string
}

export default function Container({
  children,
  narrow,
  className
}: ContainerProps): ReactElement {
  if (isNewDesign()) {
    className = clsx(styles.fullWidth, className)
  }
  const styleClasses = cx({
    container: true,
    narrow,
    [className]: className
  })

  useEffect(() => {
    return () => null
  })

  return <div className={styleClasses}>{children}</div>
}
