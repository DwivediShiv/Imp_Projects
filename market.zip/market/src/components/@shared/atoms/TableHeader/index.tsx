import React, { ReactElement } from 'react'

import styles from './index.module.css'
import Sort from '@images/sort.svg'
import SortActive from '@images/sortingActive.svg'

export interface TableHeaderProps {
  title: string
  sortable?: boolean
  sortActive?: boolean
  sortDirection?: string
}

export default function TableHeader({
  title,
  sortable,
  sortActive,
  sortDirection
}: TableHeaderProps): ReactElement {
  return (
    <div className={`${styles.header} ${sortActive && styles.sorted}`}>
      {title}{' '}
      {sortable && (
        <span
          className={`${styles.headerSortIcon} ${
            sortActive && styles[sortDirection || '']
          }`}
        >
          {sortActive ? <SortActive /> : <Sort />}
        </span>
      )}
    </div>
  )
}
