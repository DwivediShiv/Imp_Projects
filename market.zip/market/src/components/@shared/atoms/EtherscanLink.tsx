import React, { ReactElement, ReactNode } from 'react'
import { getNetworkName } from '@utils/wallet'
import External from '@images/external.svg'
import styles from './EtherscanLink.module.css'
import { useMarketMetadata } from '@context/MarketMetadata'

export default function EtherscanLink({
  networkId,
  path,
  children
}: {
  networkId: number
  path: string
  children: ReactNode
}): ReactElement {
  const { appConfig } = useMarketMetadata()
  const url =
    (!networkId && appConfig.network === 'mainnet') || networkId === 1
      ? `https://etherscan.io`
      : `https://${
          networkId
            ? getNetworkName(networkId).toLowerCase()
            : appConfig.network
        }.etherscan.io`

  return (
    <a
      href={`${url}/${path}`}
      title="View on Etherscan"
      target="_blank"
      rel="noopener noreferrer"
      className={styles.link}
    >
      {children} <External />
    </a>
  )
}
