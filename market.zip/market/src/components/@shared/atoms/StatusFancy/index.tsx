import React from 'react'
import { Button as MuiButton } from '@mui/material'
import styles from './index.module.css'

export const statusClassMapping = {
  invited: styles.statusBoxPending,
  unverified: styles.statusBoxUnverified,
  verified: styles.statusBoxActive,
  accepted: styles.statusBoxActive,
  active: styles.statusBoxActive,
  inactive: styles.statusBoxDisabled,
  pending: styles.statusBoxPending,
  rejected: styles.statusBoxRejected,
  blocked: styles.statusBoxRejected
}
export interface StatusBoxProps {
  status: string
}

export default function FancyStatusBox({
  status
}: StatusBoxProps): React.ReactElement {
  const statusClass = statusClassMapping[status]
  return <span className={statusClass}>{status}</span>
}
