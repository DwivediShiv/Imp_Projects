import React from 'react'
import { format } from 'date-fns'

export default function WithCustomFormat(Component: any) {
  return function WithCustomFormatComponent({ customFormat, ...props }): any {
    if (!customFormat) return <Component {...props} />
    const dateNew = props.isUnix
      ? new Date(Number(props.date) * 1000)
      : new Date(props.date)
    return customFormat && format(dateNew, customFormat)
  }
}
