import React, { ReactElement } from 'react'
import LogoAsset from '@images/Templogo.svg'
import styles from './index.module.css'

export interface LogoProps {
  noWordmark?: boolean
}

export default function Logo({ noWordmark }: LogoProps): ReactElement {
  return noWordmark ? (
    <LogoAsset className={styles.logo} />
  ) : (
    <LogoAsset className={styles.logo} />
  )
}
