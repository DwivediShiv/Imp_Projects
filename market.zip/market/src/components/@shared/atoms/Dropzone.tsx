import React, { ReactElement, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import styles from './Dropzone.module.css'
import { formatBytes } from '@utils/index'
import Label from '@shared/FormInput/Label'

export default function Dropzone({
  label,
  name,
  handleOnDrop,
  disabled,
  multiple,
  error
}: {
  label?: string
  name?: string
  handleOnDrop(files: File[]): void
  disabled?: boolean
  multiple?: boolean
  error?: string
}): ReactElement {
  const onDrop = useCallback(
    (acceptedFiles) => handleOnDrop(acceptedFiles),
    [handleOnDrop]
  )

  const {
    getRootProps,
    getInputProps,
    isDragActive,
    isDragReject,
    acceptedFiles
  } = useDropzone({ disabled, onDrop })

  const files = acceptedFiles.map((file: any) => (
    <li key={file.path}>
      {file.path} - {formatBytes(file.size, 0)}
    </li>
  ))

  return (
    <>
      {name && label && (
        <Label htmlFor={name} required={false}>
          {label}
        </Label>
      )}
      <div
        {...getRootProps({
          className: isDragActive
            ? `${styles.dropzone} ${styles.dragover}`
            : disabled
            ? `${styles.dropzone} ${styles.disabled}`
            : styles.dropzone
        })}
      >
        <div>
          <input {...getInputProps({ multiple })} />

          {acceptedFiles.length > 0 ? (
            <aside>
              <ul>{files}</ul>
            </aside>
          ) : (
            <>
              {isDragActive && !isDragReject ? (
                `Drop it like it's hot!`
              ) : multiple ? (
                `Drag 'n' drop some files here, or click to select files`
              ) : error ? (
                <div className={styles.error}>{error}</div>
              ) : (
                `Drag 'n' drop a file here, or click to select a file`
              )}
            </>
          )}
        </div>
      </div>
    </>
  )
}
