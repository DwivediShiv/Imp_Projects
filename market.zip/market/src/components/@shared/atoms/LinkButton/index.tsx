import React, { ReactElement } from 'react'
import Link from 'next/link'

import styles from './index.module.css'
import IconNewTab from '@images/acentrik/new_tab.svg'
import { IconColor, IconSize } from '@utils/constants'
import classNames from 'classnames/bind'

const cx = classNames.bind(styles)

export default function LinkButton({
  title,
  href,
  onClick,
  target,
  className,
  iconSize = IconSize.Small,
  color = IconColor.Info,
  hideIcon = false
}: {
  title: string
  href?: string
  onClick?: (e) => void
  target?: string
  className?: string
  iconSize?: IconSize
  color?: IconColor
  hideIcon?: boolean
}): ReactElement {
  const styleClasses = cx({
    [iconSize]: iconSize,
    iconNewTab: styles.iconNewTab,
    [className]: className
  })

  return (
    <Link href={href || ''} legacyBehavior>
      <a
        className={`${styles.link} ${className} ${styles[color]}`}
        href={href}
        onClick={onClick}
        target={target}
        rel={(target === '_blank' && 'noopener noreferrer') || undefined}
        data-testid="link-button"
      >
        <span className={styles.title}>{title}</span>
        {!hideIcon && target === '_blank' && (
          <>
            <>&nbsp;</>
            <span className={styles.icon}>
              <IconNewTab className={styleClasses} data-testid="new-tab-icon" />
            </span>
          </>
        )}
      </a>
    </Link>
  )
}
