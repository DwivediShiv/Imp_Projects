import React, { ReactElement } from 'react'
import styles from './WalletAddress.module.css'
import { accountTruncate } from '@utils/conversion'
import Copy from '../Copy'

export default function WalletAddress({
  walletAddress,
  isEdit
}: {
  walletAddress: string
  isEdit?: boolean
}): ReactElement {
  return (
    <div className={styles.walletContainer}>
      <div className={styles.wallet}>
        {isEdit ? walletAddress : accountTruncate(walletAddress)}
      </div>
      {!isEdit && <Copy copyText={walletAddress} />}
    </div>
  )
}
