import React, { useEffect, useState } from 'react'
import styles from './index.module.css'
import IconCopy from '../../../../@images/acentrik/copy.svg'
import CheckCircleOutlinedIcon from '../../../../@images/acentrik/check_circle.svg'
import { ReactElement } from 'react-markdown'

export default function FancyCopy({
  copyText
}: {
  copyText: string
}): ReactElement {
  const [isCopied, setIsCopied] = useState(false)

  useEffect(() => {
    let timeout: NodeJS.Timeout
    if (isCopied) {
      timeout = setTimeout(() => setIsCopied(false), 1000)
    }
    return () => {
      clearTimeout(timeout)
    }
  }, [isCopied])

  function handleClick() {
    setIsCopied(true)
    navigator.clipboard.writeText(copyText)
  }

  return isCopied ? (
    <div className={styles.doneCopiedWrapper}>
      <CheckCircleOutlinedIcon
        className={`iconSizeSmall ${styles.tickIcon}`}
        fontSize="small"
      />
      <div className={styles.copyText}>Copied</div>
    </div>
  ) : (
    <IconCopy
      className={`iconSizeSmall ${styles.copyIcon}`}
      onClick={handleClick}
    />
  )
}
