import { Modal } from '@mui/material'
import classNames from 'classnames'
import React, { ReactElement, ReactNode } from 'react'
import ReactModal from 'react-modal'
import Button from './Button'
import styles from './NeoModal.module.css'

export interface NeoModalProps extends ReactModal.Props {
  header?: string
  title: string
  isOpen: boolean
  onToggleModal: () => void
  children: ReactNode
}

export default function NeoModal({
  header,
  title,
  isOpen,
  onToggleModal,
  children
}: NeoModalProps): ReactElement {
  return (
    <Modal
      open={isOpen}
      onClose={onToggleModal}
      aria-labelledby={'modal-' + title}
      className="acentrik acentrik-modal"
    >
      <div className={classNames(styles.paper, 'modal')}>
        {header && (
          <header className={styles.header}>
            <h2 className={styles.header}>{header}</h2>
          </header>
        )}
        {children}
        <Button className="btn-primary" onClick={onToggleModal}>
          Close
        </Button>
      </div>
    </Modal>
  )
}
