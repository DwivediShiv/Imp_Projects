import React, { ReactElement, useEffect, useState } from 'react'
import { computeOutputExpiry } from '../../../../app.config'
import styles from './TimeExpiry.module.css'

export default function TimeExpiry({
  date,
  isUnix
}: {
  date: string
  isUnix?: boolean
  className?: string
}): ReactElement {
  const [dateIso, setDateIso] = useState<string>()
  const [dateNew, setDateNew] = useState<Date>()
  const [days, setDays] = useState<string>()
  const [isExpired, setIsExpired] = useState<boolean>()

  useEffect(() => {
    if (!date) return
    const expiryInDays = parseInt(computeOutputExpiry)
    const dateNew = isUnix ? new Date(Number(date) * 1000) : new Date(date)
    const differentTime = Math.abs(new Date().getTime() - dateNew.getTime())
    const differentDays = Math.ceil(differentTime / (1000 * 3600 * 24))
    const expired = differentDays > expiryInDays
    const numberOfDays = expired ? '-' : '' + (expiryInDays - differentDays)

    setDateIso(dateNew.toISOString())
    setDateNew(dateNew)
    setDays(numberOfDays)
    setIsExpired(expired)
  }, [date, isUnix])

  return !dateIso || !dateNew ? (
    <></>
  ) : (
    <>
      {isExpired ? (
        <>
          <span className={styles.expired}>Expired</span>
        </>
      ) : (
        <>{days}</>
      )}
    </>
  )
}
