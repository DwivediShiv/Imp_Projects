import React from 'react'
import { render, screen } from '@testing-library/react'
import Time from './'
import { Default, IsUnix, Undefined, Relative } from './index.stories'
import { format } from 'date-fns'

describe('Time', () => {
  const { timeZone } = Intl.DateTimeFormat().resolvedOptions()
  const timeOne = new Date(
    new Date('May 2, 2022, 7:50:28 PM GMT+8').toLocaleString('en-US', {
      timeZone
    })
  )
  const titleOne = format(timeOne, 'PPppp')
  const timeTwo = new Date(
    new Date('May 13, 2022, 9:26:07 PM GMT+8').toLocaleString('en-US', {
      timeZone
    })
  )
  const titleTwo = format(timeTwo, 'PPppp')

  test('should render default component on undefined date', () => {
    render(<Time {...Undefined.args} />)
    const element = screen.getAllByText('')[0]
    expect(element).toContainHTML('<time')
  })

  test('should render absolute date', () => {
    render(<Time {...Default.args} />)
    const element = screen.getByText('May 2, 2022')
    expect(element).toContainHTML('<time')
    expect(element).toHaveAttribute('title', titleOne)
    expect(element).toHaveAttribute('datetime', '2022-05-02T11:50:28.000Z')
  })

  test('should render relative date', async () => {
    render(<Time {...Relative.args} />)
    const element = await screen.findAllByText('ago', { exact: false })
    expect(element[0]).toContainHTML('<time')
    expect(element[0]).toHaveAttribute('title', titleOne)
    expect(element[0]).toHaveAttribute('datetime', '2022-05-02T11:50:28.000Z')
  })

  test('should render unix date', () => {
    render(<Time {...IsUnix.args} />)
    const element = screen.getByText('May 13, 2022')
    expect(element).toContainHTML('<time')
    expect(element).toHaveAttribute('title', titleTwo)
    expect(element).toHaveAttribute('datetime', '2022-05-13T13:26:07.000Z')
  })
})
