import React, { ReactElement } from 'react'
import styles from './index.module.css'
import { LinearProgress } from '@mui/material'

export interface LoaderProps {
  progress?: number
  message?: string
  white?: boolean
}

export default function Loader({
  progress,
  message,
  white
}: LoaderProps): ReactElement {
  return (
    <>
      {progress ? (
        <div data-testid="loader-progress">
          {message && <span className={styles.message}>{message}</span>}
          <LinearProgress variant="determinate" value={progress} />
          {`${Math.round(progress)}%`}
        </div>
      ) : (
        <div data-testid="loader-wrap" className={styles.loaderWrap}>
          <span className={`${styles.loader} ${white ? styles.white : ''}`} />
          {message && <span className={styles.message}>{message}</span>}
        </div>
      )}
    </>
  )
}
