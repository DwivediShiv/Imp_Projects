import React from 'react'
import { render, screen } from '@testing-library/react'
import Loader from './'

describe('Loader', () => {
  test('able to render loader-progress', async () => {
    render(<Loader progress={1}></Loader>)

    const loader = screen.getByTestId('loader-progress')
    expect(loader).toBeVisible()
  })

  test('able to render loader-progress with message', async () => {
    render(<Loader progress={1} message={'hello'}></Loader>)

    const loader = screen.getByText('hello')
    expect(loader).toBeVisible()
  })

  test('able to render loader-wrap', async () => {
    render(<Loader></Loader>)

    const loader = screen.getByTestId('loader-wrap')
    expect(loader).toBeVisible()
  })
})
