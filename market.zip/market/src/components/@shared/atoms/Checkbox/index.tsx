import React, { ReactElement } from 'react'
import styles from './index.module.css'
import { Checkbox as MuiCheckbox, FormControlLabel } from '@mui/material'
import CheckboxCheckedDisabled from '@images/acentrik/checkbox_checked_disabled.svg'
import CheckboxChecked from '@images/acentrik/checkbox_checked.svg'
import CheckboxUncheckedDisabled from '@images/acentrik/checkbox_uncheck_disabled.svg'
import CheckboxUnchecked from '@images/acentrik/checkbox_uncheck.svg'

function Checkbox({ ...props }: any): ReactElement {
  const { defaultChecked, isIndeterminate, onChange, label, name, disabled } =
    props
  return (
    <FormControlLabel
      className={styles.checkboxControl}
      classes={{ label: styles.checkboxLabel }}
      control={
        <MuiCheckbox
          className={styles.checkbox}
          classes={{
            checked: styles.checkboxChecked,
            indeterminate: styles.checkboxIndeterminate,
            root: styles.checkboxRoot
          }}
          checkedIcon={
            disabled ? (
              <CheckboxCheckedDisabled
                className={`${styles.checkedIcon} ${styles.disabled}`}
              />
            ) : (
              <CheckboxChecked className={styles.checkedIcon} />
            )
          }
          icon={
            disabled ? (
              <CheckboxUncheckedDisabled
                className={`${styles.uncheckedIcon} ${styles.disabled}`}
              />
            ) : (
              <CheckboxUnchecked className={styles.uncheckedIcon} />
            )
          }
          checked={defaultChecked}
          indeterminate={isIndeterminate}
          onChange={onChange}
          onClick={(e) => e.stopPropagation()}
          disableRipple
        />
      }
      label={<>{label}</>}
      key={name}
      disabled={disabled}
    />
  )
}

export default Checkbox
