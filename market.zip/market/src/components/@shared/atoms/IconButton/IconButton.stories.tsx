import React from 'react'
import IconButton from './IconButton'
import LogoIcon from '@images/acentrik/market_icon.svg'

export default {
  title: 'Atoms/IconButton'
}
const onClick = () => console.log('Hello')
export const Default = () => <IconButton icon={LogoIcon} onClick={onClick} />

export const TextOnLeft = () => <IconButton icon={LogoIcon} textOnLeft />
