import React, { ReactElement } from 'react'
import { Box, Link as MuiLink, SvgIcon } from '@mui/material'
import Styles from './IconButton.module.css'

interface ButtonProps {
  alignStartingPoint?: boolean
  textOnLeft?: boolean
  title?: string
  icon?: any
  iconViewBox?: string
  isNav?: boolean
  extraTopMargin?: boolean
  onClick?: () => void
}

export default function IconButton({
  title,
  textOnLeft,
  icon,
  iconViewBox,
  isNav,
  extraTopMargin,
  onClick
}: ButtonProps): ReactElement {
  if (!title) {
    return (
      <SvgIcon
        component={icon}
        style={{ fontSize: isNav ? 24 : 32 }}
        viewBox={iconViewBox}
      />
    )
  }

  return (
    <MuiLink
      component="button"
      onClick={onClick}
      className={`${Styles.IconButton} ${
        extraTopMargin && Styles.extraTopMargin
      }`}
    >
      <a>
        {!textOnLeft ? (
          <>
            <SvgIcon
              component={icon}
              style={{ fontSize: isNav ? 24 : 32 }}
              viewBox={iconViewBox}
              className={Styles.displayIcon}
            />
            <Box className={`${Styles.displayText} ${isNav && Styles.subText}`}>
              {title}
            </Box>
          </>
        ) : (
          <>
            <Box className={Styles.displayTextOnLeft}>{title}</Box>
            <SvgIcon
              component={icon}
              style={{ fontSize: isNav ? 24 : 32 }}
              viewBox={iconViewBox}
              className={Styles.displayIconOnRight}
            />
          </>
        )}
      </a>
    </MuiLink>
  )
}
