import { Collapse } from '@mui/material'
import FancyButton from '@shared/fancy/atoms/Button/FancyButton'
import ExpandLessIcon from '@images/acentrik/expandLess.svg'
import ExpandMoreIcon from '@images/acentrik/expandMore.svg'
import React, { useRef, useState, useEffect } from 'react'
import styles from './MarkdownHOC.module.css'

export default function WithExpandable(Component: any) {
  return function WithExpandableComponent({
    expandable,
    maxHeight = 336,
    withIcon = false,
    ...props
  }): any {
    const [expanded, setExpanded] = useState(false)
    const [showButton, setShowButton] = useState(false)
    const refElem = useRef(null)
    const MAX_HEIGHT = `${maxHeight}px`

    useEffect(() => {
      if (refElem.current.clientHeight > maxHeight) {
        setShowButton(true)
      }
    }, [refElem?.current?.clientHeight])

    const renderDefault = () => {
      return (
        <div ref={refElem}>
          <Component {...props} />
        </div>
      )
    }

    if (!showButton) {
      return renderDefault()
    }

    return (
      expandable && (
        <div className={`${styles.wrapper} ${withIcon ? styles.withIcon : ''}`}>
          <Collapse in={expanded} timeout="auto" collapsedSize={MAX_HEIGHT}>
            {renderDefault()}
          </Collapse>
          {showButton && (
            <div className={styles.button}>
              <FancyButton
                variant="text"
                color="primary"
                className={styles.adornmentBtn}
                onClick={() => {
                  setExpanded(!expanded)
                }}
              >
                {expanded ? 'Collapse' : 'Show more'}
                {withIcon &&
                  (expanded ? (
                    <ExpandLessIcon className={styles.icon} />
                  ) : (
                    <ExpandMoreIcon className={styles.icon} />
                  ))}
              </FancyButton>
            </div>
          )}
        </div>
      )
    )
  }
}
