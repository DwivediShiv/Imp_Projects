const DepTheme = {
  ltr: 'ltr',
  rtl: 'rtl',
  placeholder: 'editorPlaceholder',
  paragraph: 'editorParagraph',
  quote: 'editorQuote',
  heading: {
    h1: 'editorHeadingH1',
    h2: 'editorHeadingH2',
    h3: 'editorHeadingH3',
    h4: 'editorHeadingH4',
    h5: 'editorHeadingH5',
    h6: 'editorHeadingH6'
  },
  list: {
    nested: {
      listitem: 'editor-nested-listitem'
    },
    ol: 'editorListOl',
    ul: 'editorListUl',
    listitem: 'editorListitem'
  },
  image: 'editor-image',
  link: 'editorLink',
  text: {
    bold: 'editorTextBold',
    italic: 'editorTextItalic',
    overflowed: 'editorTextOverflowed',
    hashtag: 'editor-text-hashtag',
    underline: 'editorTextUnderline',
    strikethrough: 'editorTextStrikethrough',
    underlineStrikethrough: 'editorTextUnderlineStrikethrough',
    code: 'editorTextCode'
  },
  code: 'editorCode',
  codeHighlight: {
    atrule: 'editor-tokenAttr',
    attr: 'editor-tokenAttr',
    boolean: 'editor-tokenProperty',
    builtin: 'editor-tokenSelector',
    cdata: 'editor-tokenComment',
    char: 'editor-tokenSelector',
    class: 'editor-tokenFunction',
    'class-name': 'editor-tokenFunction',
    comment: 'editor-tokenComment',
    constant: 'editor-tokenProperty',
    deleted: 'editor-tokenProperty',
    doctype: 'editor-tokenComment',
    entity: 'editor-tokenOperator',
    function: 'editor-tokenFunction',
    important: 'editor-tokenVariable',
    inserted: 'editor-tokenSelector',
    keyword: 'editor-tokenAttr',
    namespace: 'editor-tokenVariable',
    number: 'editor-tokenProperty',
    operator: 'editor-tokenOperator',
    prolog: 'editor-tokenComment',
    property: 'editor-tokenProperty',
    punctuation: 'editor-tokenPunctuation',
    regex: 'editor-tokenVariable',
    selector: 'editor-tokenSelector',
    string: 'editor-tokenSelector',
    symbol: 'editor-tokenProperty',
    tag: 'editor-tokenProperty',
    url: 'editor-tokenOperator',
    variable: 'editor-tokenVariable'
  }
}

export default DepTheme
