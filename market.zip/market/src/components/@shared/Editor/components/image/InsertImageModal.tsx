import React, { useRef, useEffect } from 'react'
import { CUSTOM_TYPE } from '@components/@shared/fancy/organisms/Modal/Constant'
import FancyModal from '@components/@shared/fancy/organisms/Modal/FancyModal'
import { LexicalEditor } from 'lexical'
import { INSERT_IMAGE_COMMAND } from '../../plugins/ImagesPlugin'
import InputField from '@components/@shared/fancy/organisms/InputField/InputField'
import FancyButton from '@components/@shared/fancy/atoms/Button/FancyButton'
import styles from './InsertImageModal.module.css'
import * as Yup from 'yup'
import { Field, Formik } from 'formik'

interface ImageDetail {
  src: string
  altText: string
}

export function InsertImageModal({
  activeEditor,
  open,
  handleClose
}: {
  activeEditor: LexicalEditor
  open: boolean
  handleClose: () => void
}): JSX.Element {
  const hasModifier = useRef(false)

  useEffect(() => {
    hasModifier.current = false
    const handler = (e: KeyboardEvent) => {
      hasModifier.current = e.altKey
    }
    document.addEventListener('keydown', handler)
    return () => {
      document.removeEventListener('keydown', handler)
    }
  }, [activeEditor])

  const initialValues: ImageDetail = {
    src: '',
    altText: ''
  }
  const formSchema = Yup.object().shape({
    src: Yup.string().required('Required field.'),
    altText: Yup.string().required('Required field.')
  })

  function handleSubmit(values: any) {
    const { altText, src } = values
    activeEditor.dispatchCommand(INSERT_IMAGE_COMMAND, {
      altText,
      src
    })
    handleClose()
  }

  return (
    <FancyModal
      title="Insert Image"
      titleSize="h3"
      type={CUSTOM_TYPE}
      isOpen={open}
      onToggleModal={() => {
        handleClose()
      }}
    >
      <Formik
        enableReinitialize
        initialValues={initialValues}
        initialStatus="empty"
        validationSchema={formSchema}
        onSubmit={async (values) => {
          handleSubmit(values)
        }}
      >
        {({ handleSubmit, isValid, dirty }) => {
          return (
            <>
              <Field
                mode="notchedOutline"
                label="Image URL"
                name="src"
                placeholder="i.e. https://source.unsplash.com/random"
                type="text"
                data-test-id="image-modal-url-input"
                component={InputField}
              />

              <Field
                mode="notchedOutline"
                label="Alt Text"
                name="altText"
                placeholder="Random unsplash image"
                type="text"
                data-test-id="image-modal-alt-text-input"
                component={InputField}
              />

              <div className={styles.submitButtonContainer}>
                <FancyButton
                  color="primary"
                  variant="contained"
                  disabled={!dirty || !isValid}
                  onClick={handleSubmit}
                >
                  Submit
                </FancyButton>
              </div>
            </>
          )
        }}
      </Formik>
    </FancyModal>
  )
}
