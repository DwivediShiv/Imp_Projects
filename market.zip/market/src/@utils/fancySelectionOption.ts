import axios, { AxiosResponse } from 'axios'
import { SelectionOption } from '../@types/SelectionOption'
import { getSelectionOptionUrl, getOrganisationListUrl } from '../@utils/api'
import { convertSnakeToCamel } from './conversion'
import { OrganisationOption } from '../@types/OrganisationOption'

let inMemorySelectionOptions: SelectionOption[] = []
let inMemoryOrganisationOptions: OrganisationOption[] = []

async function populateSelectionOptions(
  isForce?: boolean
): Promise<SelectionOption[]> {
  if (!isForce && inMemorySelectionOptions?.length) {
    return
  }
  const response: AxiosResponse = await axios({
    method: 'GET',
    url: getSelectionOptionUrl()
  })
  inMemorySelectionOptions = response?.data?.map((d) => {
    return convertSnakeToCamel(d)
  })
}

async function populateOrganisationOption(
  isForce?: boolean
): Promise<OrganisationOption[]> {
  if (!isForce && inMemoryOrganisationOptions?.length) {
    return
  }
  const response: AxiosResponse = await axios({
    method: 'GET',
    url: getOrganisationListUrl()
  })
  inMemoryOrganisationOptions = response?.data?.data?.map((d) => {
    return d
  })
}

export async function getSelectionOptions(
  category?: string
): Promise<SelectionOption[]> {
  await populateSelectionOptions()
  if (!category) {
    return inMemorySelectionOptions
  }
  const filteredOptions = inMemorySelectionOptions.filter((option) => {
    return option.category === category
  })
  return filteredOptions
}

export async function getOrganisationOption(): Promise<OrganisationOption[]> {
  await populateOrganisationOption()
  return inMemoryOrganisationOptions
}
