import { CancelTokenSource } from 'axios'
import { PublisherTrustedAlgorithm } from '@oceanprotocol/lib'
import { AssetSelectionAsset } from '@shared/FormInput/InputElement/AssetSelection'
import {
  getFilterTerm,
  queryMetadata,
  transformDDOToAssetSelection
} from './aquarius'
import { getInMemoryValue } from './fancyAppData'
import { ComputeStatus } from 'src/@types/ComputeJobMetaData'
import { STATE_ACTIVE } from './constants'
import { getOrganisationOption } from './fancySelectionOption'

export async function getValidAlgorithms(
  metadataCacheUri: string,
  cancelTokenSource: CancelTokenSource,
  chainId: number,
  publisherTrustedAlgorithms: PublisherTrustedAlgorithm[],
  providerEndpoint?: string
): Promise<AssetSelectionAsset[]> {
  if (!metadataCacheUri) {
    return []
  }

  providerEndpoint = providerEndpoint || getInMemoryValue('provider')

  const query: any = {
    size: 500,
    query: {
      bool: {
        filter: [
          getFilterTerm('metadata.type', 'algorithm'),
          getFilterTerm('chainId', chainId),
          getFilterTerm('purgatory.state', false),
          getFilterTerm('nft.state', STATE_ACTIVE)
        ]
      }
    },
    sort: { 'metadata.created': 'desc' }
  }

  const [queryResult, orgOptions] = await Promise.all([
    queryMetadata(query, cancelTokenSource.token),
    getOrganisationOption()
  ])

  // Create a Set of instance organization IDs
  const orgIdSet = new Set(orgOptions?.map((item) => item.id))

  // Filter results to only include assets published by currently supported organizations
  const filteredResults = queryResult?.results?.filter((item) =>
    orgIdSet.has(item.metadata?.additionalInformation?.organization)
  )

  const algorithmSelectionList = await transformDDOToAssetSelection(
    providerEndpoint,
    filteredResults || [],
    publisherTrustedAlgorithms
  )
  return algorithmSelectionList
}

const StatusCodeStarted = new Set([1, 10, 20])
const StatusCodeRunning = new Set([30, 40, 50, 60])
const StatusCodeFailed = new Set([31, 32, 80])
const StatusCodeCompleted = new Set([70])

// Refer to: https://github.com/oceanprotocol/operator-service/blob/2b3e80ad9e137424324859c7db80cc2aa1024de4/API.md#status-object
// stopreq: 0 - None, 1 - API Enpoint Stop called, 2 - Job exceeded allocated time
enum RequestCodes {
  NOT_REQUESTED = 0,
  REQUESTED = 1,
  INCOMPLETE = 2
}

export function isStatusStarted(status: number): boolean {
  return StatusCodeStarted.has(status)
}

export function isStatusRunning(status: number): boolean {
  return StatusCodeRunning.has(status)
}

export function isStatusFailed(status: number): boolean {
  return StatusCodeFailed.has(status)
}

export function isStatusCompleted(status: number): boolean {
  return StatusCodeCompleted.has(status)
}

export function isStatusIncomplete(stopReq: number): boolean {
  return stopReq === RequestCodes.INCOMPLETE
}

export function getComputeStatus(
  status: number,
  stopReq: number
): ComputeStatus {
  return {
    started: stopReq === RequestCodes.NOT_REQUESTED && isStatusStarted(status),
    running: stopReq === RequestCodes.NOT_REQUESTED && isStatusRunning(status),
    failed: isStatusFailed(status),
    completed:
      stopReq === RequestCodes.NOT_REQUESTED && isStatusCompleted(status),
    incomplete: !isStatusFailed(status) && isStatusIncomplete(stopReq) // Failed have highest priority > Incomplete in scenario of stopreq=2 + failed
  }
}
