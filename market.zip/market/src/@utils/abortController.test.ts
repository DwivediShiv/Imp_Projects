import { abortRequests } from './abortController'

describe('abortRequests()', () => {
  it('should return an instance of abort controller', () => {
    const result = new AbortController()
    expect(result).toBeInstanceOf(AbortController)
  })

  it('should aborts all AbortControllers in the provided array', () => {
    const abortController = new AbortController()
    const eventAbortControllers = [abortController]

    abortRequests(eventAbortControllers)

    expect(abortController.signal.aborted).toBe(true)
  })

  it('should aborts all AbortControllers in an array of multiple arrays', () => {
    const abortController1 = new AbortController()
    const abortController2 = new AbortController()
    const abortController3 = new AbortController()
    const abortController4 = new AbortController()
    const eventAbortControllers = [
      abortController1,
      abortController2,
      abortController3,
      abortController4
    ]

    abortRequests(eventAbortControllers)

    expect(abortController1.signal.aborted).toBe(true)
    expect(abortController2.signal.aborted).toBe(true)
    expect(abortController3.signal.aborted).toBe(true)
    expect(abortController4.signal.aborted).toBe(true)
  })

  it('should aborts all AbortControllers in an array', () => {
    const eventAbortControllers = [
      new AbortController(),
      new AbortController(),
      new AbortController()
    ]

    abortRequests(eventAbortControllers)

    eventAbortControllers.flat().forEach((controller) => {
      expect(controller.signal.aborted).toBe(true)
    })
  })

  it('should does nothing when provided an empty array', () => {
    const eventAbortControllers: AbortController[] = []

    abortRequests(eventAbortControllers)

    expect(eventAbortControllers).toEqual([])
  })
})
