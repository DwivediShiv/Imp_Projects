import {
  deleteAllInMemoryDockerImage,
  getInMemoryDockerImage,
  getInMemoryValue,
  getInMemoryWalletAccess,
  removeInMemory,
  setInMemoryDockerImage,
  setInMemoryValue,
  setInMemoryWalletAccess
} from './fancyAppData'

const walletAddress = '0x7B97450975E89Ce1dB2EC1FEa1F82E234a5d4A02'
const walletAddress2 = '0xd1CdD6182f86456712e49Eea0C03aF5A1375E8Ec'
const sampleURL = 'https://acentrik.io/'
const image = 'python-panda'
const tag = 'python @ ALGO'

describe('In-memory for wallet access tests', () => {
  test('Should get role correctly', async () => {
    setInMemoryWalletAccess(walletAddress, 'purchase', true)
    const testData = getInMemoryWalletAccess(walletAddress, 'purchase')
    expect(testData).toBeTruthy()

    setInMemoryWalletAccess(walletAddress, 'purchase', false)
    const testData1 = getInMemoryWalletAccess(walletAddress, 'purchase')
    expect(testData1).toBe(false)
  })

  test('Should get undefined role with assignment of different role', async () => {
    setInMemoryWalletAccess(walletAddress2, 'publish', true)
    const testData = getInMemoryWalletAccess(walletAddress2, 'purchase')
    expect(testData).toBe(undefined)
  })

  test('Should get false value with one of argus is undefined', async () => {
    setInMemoryWalletAccess(undefined, 'publish', true)
    const testData = getInMemoryWalletAccess(undefined, 'publish')
    expect(testData).toBe(false)

    const testData2 = getInMemoryWalletAccess(walletAddress, undefined)
    expect(testData2).toBe(false)
  })
})

describe('In-memory tests', () => {
  test('Should set and get the value to in-memory correctly', async () => {
    setInMemoryValue('acentrikURL', sampleURL)
    getInMemoryValue('acentrikURL')
  })

  test('Should remove in-memory', async () => {
    removeInMemory('acentrikURL')
    expect(getInMemoryValue('acentrikURL')).toBeUndefined()
  })

  test('Should set and get in-memory for docker image correctly', async () => {
    const requestBody = {
      image,
      tag
    }
    setInMemoryDockerImage(`${image}_${tag}`, requestBody)
    const inMemoryDockerImage = getInMemoryDockerImage(`${image}_${tag}`)
    expect(inMemoryDockerImage).toStrictEqual({
      image,
      tag
    })
  })

  test('Should delete all in-memory docker images', async () => {
    deleteAllInMemoryDockerImage()
    expect(getInMemoryValue(`${image}_${tag}`)).toBeUndefined()
  })
})
