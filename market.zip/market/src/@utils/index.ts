import { getNetworkDataById } from '@hooks/useNetworkMetadata'
import { Asset } from '@oceanprotocol/lib'
import axios, { AxiosResponse } from 'axios'
import { isString, isEmpty, isArray } from 'lodash'
import {
  ERROR_GOOGLE_DRIVE_LINK,
  ERROR_GOOGLE_DRIVE_LINK_FULL
} from '../components/Publish/Constants'
import moment from 'moment'
import appConfig from '../../app.config'

export function updateQueryStringParameter(
  uri: string,
  key: string,
  newValue: string
): string {
  const regex = new RegExp('([?&])' + key + '=.*?(&|$)', 'i')
  const separator = uri.indexOf('?') !== -1 ? '&' : '?'

  if (uri.match(regex)) {
    return uri.replace(regex, '$1' + key + '=' + newValue + '$2')
  } else {
    return uri + separator + key + '=' + newValue
  }
}

export function isToken(str) {
  // Define a regular expression pattern to match the token format
  const pattern = /^#\(.+\)#$/
  // Test if the string matches the pattern
  return pattern.test(str)
}

export function prettySize(
  bytes: number,
  separator = ' ',
  postFix = ''
): string {
  if (bytes) {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.min(
      Math.floor(Math.log(bytes) / Math.log(1024)),
      sizes.length - 1
    )
    return `${(bytes / 1024 ** i).toFixed(i ? 1 : 0)}${separator}${
      sizes[i]
    }${postFix}`
  }
  return 'n/a'
}

// Boolean value that will be true if we are inside a browser, false otherwise
export const isBrowser = typeof window !== 'undefined'

export function toStringNoMS(date: Date): string {
  return date.toISOString().replace(/\.[0-9]{3}Z/, 'Z')
}

export async function fetchData(url: string): Promise<AxiosResponse['data']> {
  try {
    const response = await axios(url)

    if (response.status !== 200) {
      return console.error('Non-200 response: ' + response.status)
    }

    return response.data
  } catch (error) {
    console.error('Error parsing json: ' + error.message)
  }
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
}

export function removeItemFromArray<T>(arr: Array<T>, value: T): Array<T> {
  const index = arr.indexOf(value)
  if (index > -1) {
    arr.splice(index, 1)
  }
  return arr
}

export function isDid(did: string | undefined): boolean {
  const didMatch = (did as string).match(/^did:op:([a-f0-9]{64})$/i)
  return !!didMatch
}

export function formatBytes(a: number, b: number): string {
  if (a === 0) return '0 Bytes'
  const c = 1024
  const d = b || 2
  const e = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
  const f = Math.floor(Math.log(a) / Math.log(c))
  return parseFloat((a / Math.pow(c, f)).toFixed(d)) + ' ' + e[f]
}

export function writeCookie(name: string, content: string, seconds: number) {
  const secureFlag =
    appConfig.site.cookieSecure === 'true' &&
    window.location.protocol === 'https:'
      ? 'secure;'
      : ''
  // To handle firefox cookie behavior, slow network might take up to 8 seconds to load js scripts, hence round up 10 sec
  const delay = 10
  const expires = seconds
    ? `expires=${moment()
        .add(seconds + delay, 'seconds')
        .utc()
        .format('ddd, DD MMM YYYY HH:mm:ss')} GMT;`
    : ''
  const cookieStr = `${encodeURIComponent(name)}=${encodeURIComponent(
    content
  )};path=/;SameSite=strict;${secureFlag}${expires}`
  document.cookie = cookieStr
}

export function readCookie(name: string): string {
  if (typeof window === 'undefined' || !window?.document) {
    // fix server side rendering fail build because document doesnt exist
    return
  }
  const nameEQ = name + '='
  const ca = document.cookie.split(';')
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === ' ') c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

export function deleteCookie(name: string) {
  document.cookie = `${encodeURIComponent(
    name
  )}=; path=/; SameSite=strict; expires=${moment
    .utc(0)
    .format('ddd, DD MMM YYYY HH:mm:ss')} GMT;`
}

export function isSameJSON(values: any, initialValue: any) {
  return Boolean(
    JSON.stringify(initialValue, Object.keys(initialValue).sort()) ===
      JSON.stringify(values, Object.keys(values).sort())
  )
}

export function isDeepDifferent(
  currentValues: any,
  initialValue: any
): boolean {
  return Boolean(JSON.stringify(initialValue) !== JSON.stringify(currentValues))
}

export function convertStringToBoolean(value: string): boolean | any {
  if (isString(value)) {
    return value.toLowerCase() === 'true'
  } else {
    return value
  }
}

// TODO : this getFancyNestedValue unable to support N-tier and dynamic structure
export function getArrayUrlOrString(value) {
  if (!value?.[0]) {
    return value
  }
  return value?.[0]?.url || value?.[0]
}

export function getFancyNestedValue(key, value, isFileBased = true) {
  if (!value || isEmpty(value)) return null

  if (
    ['eula', 'links'].includes(key) &&
    value[key]?.toLowerCase() === ERROR_GOOGLE_DRIVE_LINK_FULL.toLowerCase()
  ) {
    return ERROR_GOOGLE_DRIVE_LINK
  }

  if (!key.includes('.')) {
    return isArray(value[key]) && isFileBased
      ? getArrayUrlOrString(value[key])
      : value[key]
  }

  const fields = key.substring(0, key.indexOf('.'))
  if (fields.includes('|')) {
    const valueAndIndex = fields.split('|')
    if (!value[valueAndIndex[0]]) return null

    const nestedValue = getFancyNestedValue(
      key.substring(key.indexOf('.') + 1),
      value[valueAndIndex[0]][valueAndIndex[1]],
      isFileBased
    )

    return typeof nestedValue === 'string' &&
      nestedValue.toLowerCase() === ERROR_GOOGLE_DRIVE_LINK_FULL.toLowerCase()
      ? ERROR_GOOGLE_DRIVE_LINK
      : nestedValue
  } else {
    return getFancyNestedValue(
      key.substring(key.indexOf('.') + 1),
      value[fields],
      isFileBased
    )
  }
}

export function getDatatokenAddress(assets: Asset[]): string[] {
  return assets?.map((asset) => {
    return asset.services[0].datatokenAddress
  })
}

export function getTxHashExplorer(
  chainId: number,
  txHash: string,
  networksList: EthereumListsChain[]
) {
  if (!chainId || !txHash || !networksList) return
  return `${
    getNetworkDataById(networksList, chainId)?.explorers?.[0]?.url
  }/tx/${txHash}`
}

// Saransh Note: New Ocean util functions
export function sortAssets(items: Asset[], sorted: string[]) {
  items.sort(function (a, b) {
    return sorted?.indexOf(a.id) - sorted?.indexOf(b.id)
  })
  return items
}

export const isPlainObject = (object: any) => {
  return object !== null && typeof object === 'object' && !Array.isArray(object)
}

export const getObjectPropertyByPath = (object: any, path = '') => {
  if (!isPlainObject(object)) return undefined
  path = path.replace(/\[(\w+)\]/g, '.$1') // convert indexes to properties
  path = path.replace(/^\./, '') // strip a leading dot
  const pathArray = path.split('.')
  for (let i = 0, n = pathArray.length; i < n; ++i) {
    const key = pathArray[i]
    try {
      if (key in object) {
        object = object[key]
      } else {
        return undefined
      }
    } catch {
      return undefined
    }
  }
  return object
}

// Convert string characters to lowercase, keep first letter of first word capital
export function formatString(str: string): string {
  if (!str || !str.length) {
    return str
  }
  let words = str.split(' ')
  words = words.map((word, index) => (index !== 0 ? word.toLowerCase() : word))
  return words.join(' ')
}

export function getMatchingOrgName(orgId: string, organisationOptions): string {
  const org =
    organisationOptions &&
    organisationOptions.find((element) => element.id.toString() === orgId)
  return (org && org.name) || '-'
}

export function isUUID(value: string): boolean {
  const uuidPattern =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
  return uuidPattern.test(value)
}

export function convertUsdcSymbolToUsd(symbol: string): string {
  if (!symbol) return
  return symbol?.toLowerCase() === 'usdc' ? 'USD' : symbol
}
