import { cloneDeep, isEqual } from 'lodash'
import { FormFieldContent } from 'src/@types/Form'
import { FormPublishData } from 'src/components/Publish/_types'

export function getFieldContent(
  fieldName: string,
  fields: FormFieldContent[]
): FormFieldContent {
  return fields.filter((field: FormFieldContent) => field.name === fieldName)[0]
}

const exclusionProperties = {
  PUBLISH: ['user'],
  EDIT: [
    'user',
    'isEulaGoogleDriveUrl',
    'isLinksValid',
    'isEulaValid',
    'isLinksGoogleDriveUrl',
    'sampleType'
  ],
  EDIT_METADATA: [
    'user',
    'pricing',
    'isEulaGoogleDriveUrl',
    'isLinksValid',
    'isEulaValid',
    'isLinksGoogleDriveUrl',
    'sampleType'
  ],
  MANAGE_ASSET: [],
  MANAGE_PERMISSION: [],
  MANAGE_REVENUE: []
}

export function isFormValuesChanged(
  initialValues: AccessDetails | FormPublishData | any,
  values: PriceOptions | FormPublishData | any,
  action:
    | 'PUBLISH'
    | 'EDIT'
    | 'EDIT_METADATA'
    | 'EDIT_PRICE'
    | 'MANAGE_ASSET'
    | 'MANAGE_PERMISSION'
    | 'MANAGE_REVENUE'
) {
  if (
    values?.updatedPublisherTrustedAlgorithms?.length > 0 &&
    ['EDIT', 'EDIT_METADATA'].includes(action)
  )
    return true

  const valuesCopy = cloneDeep(values)
  const initialValuesCopy = cloneDeep(initialValues)

  const properties = exclusionProperties[action] || []
  for (const property of properties) {
    if (valuesCopy?.pricing?.type === 'Post-pay' && property === 'pricing') {
      continue
    }
    delete valuesCopy[property]
    delete initialValuesCopy[property]
  }

  if (action === 'EDIT_PRICE') {
    return (
      initialValues?.type === 'fixed' &&
      values?.price?.toString() !== initialValues?.price?.toString()
    )
  }

  return !isEqual(
    JSON.parse(JSON.stringify(valuesCopy)),
    JSON.parse(JSON.stringify(initialValuesCopy))
  )
}
