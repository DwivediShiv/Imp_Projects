import {
  Asset,
  LoggerInstance,
  PublisherTrustedAlgorithm,
  Service
} from '@oceanprotocol/lib'
import { AssetSelectionAsset } from '@components/@shared/fancy/molecules/AssetSelection/FancyAssetSelection'
import { getAssetsPriceList, PriceList } from '../subgraph'
import axios, { CancelToken, AxiosResponse } from 'axios'
import { OrdersData_orders as OrdersData } from '../../@types/subgraph/OrdersData'
import { metadataCacheUri, v3MetadataCacheUri } from '../../../app.config'
// import { DownloadedAsset } from '../models/aquarius/DownloadedAsset'
// import { SearchQuery } from '../models/aquarius/SearchQuery'
// import { SearchResponse } from '../models/aquarius/SearchResponse'
import {
  SortDirectionOptions,
  SortTermOptions
} from '../../@types/aquarius/SearchQuery'
import {
  isCustomComputeOption,
  transformAssetToAssetSelection
} from '../assetConvertor'
import { HISTORY_INDEX, STATE_ACTIVE, STATE_DELIST } from '../constants'
import { cloneDeep } from 'lodash'
import {
  getUserProfileFromMap,
  getUserProfileMap
} from '@utils/keycloakProfile'
import { getOrganisationOption } from '@utils/fancySelectionOption'

// import { FilterTerm } from '../models/aquarius/FilterTerm'
// import { BaseQueryParams } from '../models/aquarius/BaseQueryParams'

export interface UserSales {
  id: string
  totalSales: number
}

// export const MAXIMUM_NUMBER_OF_PAGES_WITH_RESULTS = 476 // Moved to @utils/constants.ts due to broken test cases in aquarius

export function escapeEsReservedCharacters(value: string): string {
  // eslint-disable-next-line no-useless-escape
  const pattern = /([\!\*\+\-\=\<\>\&\|\(\)\[\]\{\}\^\~\?\:\\/"])/g
  return value.replace(pattern, '\\$1')
}

/**
 * @param filterField the name of the actual field from the ddo schema e.g. 'id','service.attributes.main.type'
 * @param value the value of the filter
 * @returns json structure of the es filter
 */
export function getFilterTerm(
  filterField: string,
  value: string | number | boolean | number[] | string[]
): FilterTerm {
  if (!filterField) return
  const isArray = Array.isArray(value)
  return {
    [isArray ? 'terms' : 'term']: {
      [filterField]: value
    }
  }
}

export function generateBaseQuery(
  baseQueryParams: BaseQueryParams,
  includeDelist = false
): SearchQuery {
  const assetStates = cloneDeep(STATE_ACTIVE)
  if (includeDelist) assetStates.push(STATE_DELIST)

  const generatedQuery = {
    from: baseQueryParams.esPaginationOptions?.from || 0,
    size: baseQueryParams.esPaginationOptions?.size || 1000,
    query: {
      bool: {
        ...baseQueryParams.nestedQuery,
        filter: [
          ...(baseQueryParams.filters || []),
          getFilterTerm('chainId', baseQueryParams.chainIds),
          getFilterTerm('nft.state', assetStates),
          // getFilterTerm('_index', 'aquarius'),
          ...(baseQueryParams.ignorePurgatory
            ? []
            : [getFilterTerm('purgatory.state', false)])
        ]
      }
    }
  } as SearchQuery

  if (baseQueryParams.aggs !== undefined) {
    generatedQuery.aggs = baseQueryParams.aggs
  }

  if (baseQueryParams.sortOptions !== undefined)
    generatedQuery.sort = {
      [baseQueryParams.sortOptions.sortBy]:
        baseQueryParams.sortOptions.sortDirection ||
        SortDirectionOptions.Descending
    }

  return generatedQuery
}

export function transformQueryResult(
  queryResult: SearchResponse,
  from = 0,
  size = 21
): PagedAssets {
  if (
    !queryResult ||
    !queryResult?.hits ||
    from < 0 ||
    size < 0 ||
    from % 1 !== 0 ||
    size % 1 !== 0
  )
    return

  const result: PagedAssets = {
    results: [],
    page: 0,
    totalPages: 0,
    totalResults: 0,
    aggregations: []
  }

  result.results = (queryResult.hits.hits || []).map(
    (hit) => hit._source as Asset
  )

  result.aggregations = queryResult.aggregations
  result.totalResults = queryResult.hits.total?.value || queryResult.hits.total
  result.totalPages =
    result.totalResults / size < 1
      ? Math.floor(result.totalResults / size)
      : Math.ceil(result.totalResults / size)
  result.page = from ? from / size + 1 : 1

  return result
}

export function transformChainIdsListToQuery(chainIds: number[]): string {
  let chainQuery = ''
  try {
    if (!chainIds) throw new Error('Invalid chain ids')

    chainIds?.forEach((chainId) => {
      if (!chainId) throw new Error('Invalid chain id')
      chainQuery += `chainId:${chainId} OR `
    })
    chainQuery = chainQuery.slice(0, chainQuery.length - 4)
    return chainQuery
  } catch (err) {
    LoggerInstance.error(err.message)
    return chainQuery
  }
}

export async function queryMetadata(
  query: SearchQuery,
  cancelToken?: CancelToken
): Promise<PagedAssets> {
  try {
    if (!query) throw new Error('Invalid query')
    const fancyData = Object.assign({}, query)
    fancyData.size = fancyData?.size || 500
    fancyData.query.bool.must_not = [
      {
        wildcard: {
          _index: `*${HISTORY_INDEX}`
        }
      }
    ]
    const config = cancelToken ? { cancelToken } : {}
    const response: AxiosResponse<SearchResponse> = await axios.post(
      `${metadataCacheUri}/api/aquarius/assets/query`,
      fancyData,
      config
    )
    if (!response || response.status !== 200 || !response.data) return
    return transformQueryResult(
      response.data,
      query.from || 0,
      fancyData.size || 12
    )
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
    throw error
  }
}

export async function getAsset(
  did: string,
  cancelToken: CancelToken
): Promise<Asset> {
  try {
    const response: AxiosResponse<Asset> = await axios.get(
      `${metadataCacheUri}/api/aquarius/assets/ddo/${did}`,
      { cancelToken }
    )
    if (!response || response.status !== 200 || !response.data) return

    const data = { ...response.data }
    return data
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
  }
}

export async function checkV3Asset(
  did: string,
  cancelToken: CancelToken
): Promise<boolean> {
  try {
    const response: AxiosResponse<Asset> = await axios.get(
      `${v3MetadataCacheUri}/api/v1/aquarius/assets/ddo/${did}`,
      { cancelToken }
    )
    if (!response || response.status !== 200 || !response.data) return false

    return true
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
    return false
  }
}

export async function getAssetsNames(
  didList: string[],
  cancelToken: CancelToken
): Promise<Record<string, string>> {
  try {
    const response: AxiosResponse<Record<string, string>> = await axios.post(
      `${metadataCacheUri}/api/aquarius/assets/names`,
      { didList },
      { cancelToken }
    )
    if (!response || response.status !== 200 || !response.data) return
    return response.data
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
  }
}

export async function getAssetsFromDidList(
  didList: string[],
  chainIds: number[],
  cancelToken: CancelToken
): Promise<PagedAssets> {
  try {
    if (!(didList.length > 0)) return

    const baseParams = {
      chainIds,
      filters: [getFilterTerm('_id', didList)],
      ignorePurgatory: true
    } as BaseQueryParams
    const query = generateBaseQuery(baseParams, true)

    const queryResult = await queryMetadata(query, cancelToken)
    return queryResult
  } catch (error) {
    LoggerInstance.error(error.message)
  }
}

export async function getAssetsFromDtList(
  dtList: string[],
  chainIds: number[],
  cancelToken: CancelToken
): Promise<Asset[]> {
  try {
    if (!(dtList.length > 0)) return

    const baseParams = {
      chainIds,
      filters: [getFilterTerm('services.datatokenAddress', dtList)],
      ignorePurgatory: true
    } as BaseQueryParams
    const query = generateBaseQuery(baseParams)

    const queryResult = await queryMetadata(query, cancelToken)
    return queryResult?.results
  } catch (error) {
    LoggerInstance.error(error.message)
  }
}

export async function getAssetsFromDids(
  didList: string[],
  chainIds: number[],
  cancelToken?: CancelToken,
  ignorePurgatory = true
): Promise<Asset[]> {
  if (didList?.length === 0 || chainIds?.length === 0) return []

  try {
    const orderedDDOListByDIDList: Asset[] = []
    const baseQueryparams = {
      chainIds,
      filters: [getFilterTerm('_id', didList)],
      ignorePurgatory
    } as BaseQueryParams
    const query = generateBaseQuery(baseQueryparams)
    const result = await queryMetadata(query, cancelToken)

    didList?.forEach((did: string) => {
      const ddo = result.results.find((ddo: Asset) => ddo.id === did)
      if (ddo) orderedDDOListByDIDList.push(ddo)
    })
    return orderedDDOListByDIDList
  } catch (error) {
    LoggerInstance.error(error.message)
  }
}

export async function transformDDOToAssetSelection(
  datasetProviderEndpoint: string,
  ddoList: Asset[],
  selectedAlgorithms?: PublisherTrustedAlgorithm[],
  cancelToken?: CancelToken
): Promise<AssetSelectionAsset[]> {
  const didList: string[] = []
  const priceList: PriceList = await getAssetsPriceList(ddoList)
  const symbolList: any = {}
  const serviceEndpointList: any = {}
  const didProviderEndpointMap: any = {}
  for (const ddo of ddoList) {
    let algoServiceEndpoint
    const accessType = ddo?.services?.[0]?.type
    if (
      accessType === 'compute' &&
      ddo.services[0]?.serviceEndpoint !== datasetProviderEndpoint
    ) {
      continue
    } else {
      algoServiceEndpoint = ddo?.services?.[0]?.serviceEndpoint
    }
    didList.push(ddo.id)
    symbolList[ddo.id] = ddo.datatokens[0].symbol
    const algoComputeService = ddo?.services?.[0] as Service
    algoComputeService?.serviceEndpoint &&
      (didProviderEndpointMap[ddo.id] = algoComputeService?.serviceEndpoint)
    serviceEndpointList[ddo.id] = algoServiceEndpoint
  }

  const profileMap = await getUserProfileMap(
    ddoList.map((ddo) => ddo.nft.owner)
  )

  const ddoNames = await getAssetsNames(didList, cancelToken)
  const algorithmList: AssetSelectionAsset[] = []

  const orgOptions = await getOrganisationOption()
  didList?.forEach((did: string) => {
    if (priceList?.[did]) {
      let selected = false
      selectedAlgorithms?.forEach((algorithm: PublisherTrustedAlgorithm) => {
        if (algorithm.did === did) {
          selected = true
        }
      })
      const ddo = ddoList?.find((ddo) => {
        return ddo.id === did
      })
      // TODO fix
      const { metadata } = ddo
      const isExperimental =
        ddo?.services?.[0]?.additionalInformation?.isExperimental
      const isCustomDocker = isCustomComputeOption(
        ddo?.metadata?.algorithm?.container?.image,
        ddo?.metadata?.algorithm?.container?.tag
      )

      const matchedOrg = orgOptions.find(
        (org) => org.id === ddo?.metadata?.additionalInformation?.organization
      )
      // TODO v4 services additional information
      selected
        ? algorithmList.unshift({
            did,
            name: ddoNames[did],
            price: priceList[did],
            checked: selected,
            symbol: symbolList[did],
            serviceEndpoint: serviceEndpointList[did],
            shortDescription: metadata.description,
            isExperimental,
            isCustomDocker,
            datatoken: ddo.datatokens[0]?.symbol,
            accessType: ddo.services[0]?.type,
            dataProvider: matchedOrg ? matchedOrg.name : '-',
            ownerAddress: ddo.nft?.owner,
            ...(metadata.type === 'algorithm' && {
              algoType: metadata.additionalInformation?.algorithmType
            })
          })
        : algorithmList.push({
            did,
            name: ddoNames[did],
            price: priceList[did],
            checked: selected,
            symbol: symbolList[did],
            serviceEndpoint: serviceEndpointList[did],
            shortDescription: metadata.description,
            isExperimental,
            isCustomDocker,
            datatoken: ddo.datatokens[0]?.symbol,
            accessType: ddo.services[0]?.type,
            dataProvider: matchedOrg ? matchedOrg.name : '-',
            ownerAddress: ddo.nft?.owner,
            ...(metadata.type === 'algorithm' && {
              algoType: metadata.additionalInformation?.algorithmType
            })
          })
    }
  })
  return algorithmList
}

export async function getAlgorithmDatasetsForCompute(
  algorithmId: string,
  datasetProviderUri: string,
  datasetChainId?: number,
  isSkipTransform?: boolean,
  cancelToken?: CancelToken
): Promise<AssetSelectionAsset[] | Asset[]> {
  const baseQueryParams = {
    chainIds: [datasetChainId],
    nestedQuery: {
      must: {
        match_phrase: {
          'services.compute.publisherTrustedAlgorithms.did': {
            query: algorithmId
          }
        }
      }
    },
    sortOptions: {
      sortBy: SortTermOptions.Created,
      sortDirection: SortDirectionOptions.Descending
    }
  } as BaseQueryParams

  const query = generateBaseQuery(baseQueryParams)
  const computeDatasets = await queryMetadata(query, cancelToken)

  if (computeDatasets?.totalResults === 0) return []
  if (isSkipTransform) return computeDatasets.results

  const datasets = await transformAssetToAssetSelection(
    datasetProviderUri,
    computeDatasets.results,
    []
  )
  return datasets
}

export async function getPublishedAssets(
  accountId: string,
  chainIds: number[],
  cancelToken: CancelToken,
  ignoreState = false,
  page?: number,
  type?: string,
  accesType?: string
): Promise<PagedAssets> {
  if (!accountId) return

  const filters: FilterTerm[] = []

  filters.push(getFilterTerm('nft.state', [0, 4, 5]))
  filters.push(getFilterTerm('nft.owner', accountId.toLowerCase()))
  accesType !== undefined &&
    filters.push(getFilterTerm('services.type', accesType))
  type !== undefined && filters.push(getFilterTerm('metadata.type', type))

  const baseQueryParams = {
    chainIds,
    filters,
    sortOptions: {
      sortBy: SortTermOptions.Created,
      sortDirection: SortDirectionOptions.Descending
    },
    aggs: {
      totalOrders: {
        sum: {
          field: SortTermOptions.Orders
        }
      }
    },
    ignorePurgatory: true,
    ignoreState,
    esPaginationOptions: {
      from: (Number(page) - 1 || 0) * 9,
      size: 9
    }
  } as BaseQueryParams

  const query = generateBaseQuery(baseQueryParams)

  try {
    const result = await queryMetadata(query, cancelToken)
    return result
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
  }
}

export async function getTopPublishers(
  chainIds: number[],
  cancelToken: CancelToken,
  page?: number,
  type?: string,
  accesType?: string
): Promise<PagedAssets> {
  const filters: FilterTerm[] = []

  accesType !== undefined &&
    filters.push(getFilterTerm('services.type', accesType))
  type !== undefined && filters.push(getFilterTerm('metadata.type', type))

  const baseQueryParams = {
    chainIds,
    filters,
    sortOptions: {
      sortBy: SortTermOptions.Created,
      sortDirection: SortDirectionOptions.Descending
    },
    aggs: {
      topPublishers: {
        terms: {
          field: 'nft.owner.keyword',
          order: { totalSales: 'desc' }
        },
        aggs: {
          totalSales: {
            sum: {
              field: SortTermOptions.Orders
            }
          }
        }
      }
    },
    esPaginationOptions: {
      from: (Number(page) - 1 || 0) * 9,
      size: 9
    }
  } as BaseQueryParams

  const query = generateBaseQuery(baseQueryParams)

  try {
    const result = await queryMetadata(query, cancelToken)
    return result
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
  }
}

export async function getTopAssetsPublishers(
  chainIds: number[],
  nrItems = 9
): Promise<UserSales[]> {
  const publishers: UserSales[] = []

  const result = await getTopPublishers(chainIds, null)
  const { topPublishers } = result.aggregations

  for (let i = 0; i < topPublishers.buckets.length; i++) {
    publishers.push({
      id: topPublishers.buckets[i].key,
      totalSales: parseInt(topPublishers.buckets[i].totalSales.value)
    })
  }

  publishers.sort((a, b) => b.totalSales - a.totalSales)

  return publishers.slice(0, nrItems)
}

export async function getUserSales(
  accountId: string,
  chainIds: number[]
): Promise<number> {
  try {
    const result = await getPublishedAssets(accountId, chainIds, null)
    const { totalOrders } = result.aggregations
    return totalOrders.value
  } catch (error) {
    LoggerInstance.error('Error getUserSales', error.message)
  }
}

export async function getDownloadAssets(
  dtList: string[],
  tokenOrders: OrdersData[],
  chainIds: number[],
  cancelToken: CancelToken,
  ignoreState = false
): Promise<DownloadedAsset[]> {
  const baseQueryparams = {
    chainIds,
    filters: [
      getFilterTerm('services.datatokenAddress', dtList),
      getFilterTerm('services.type', 'access')
    ],
    ignorePurgatory: true,
    ignoreState
  } as BaseQueryParams
  const query = generateBaseQuery(baseQueryparams)
  try {
    const result = await queryMetadata(query, cancelToken)
    const downloadedAssets: DownloadedAsset[] = result.results
      .map((asset) => {
        const order = tokenOrders.find(
          ({ datatoken }) =>
            datatoken?.address.toLowerCase() ===
            asset.services[0].datatokenAddress.toLowerCase()
        )

        return {
          asset,
          networkId: asset.chainId,
          dtSymbol: order?.datatoken?.symbol,
          timestamp: order?.createdTimestamp
        }
      })
      .sort((a, b) => b.timestamp - a.timestamp)

    return downloadedAssets
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
  }
}

export async function getTagsList(
  chainIds: number[],
  cancelToken: CancelToken
): Promise<string[]> {
  const baseQueryParams = {
    chainIds,
    esPaginationOptions: { from: 0, size: 0 }
  } as BaseQueryParams
  const query = {
    ...generateBaseQuery(baseQueryParams),
    aggs: {
      tags: {
        terms: {
          field: 'metadata.tags.keyword',
          size: 1000
        }
      }
    }
  }

  try {
    const response: AxiosResponse<SearchResponse> = await axios.post(
      `${metadataCacheUri}/api/aquarius/assets/query`,
      { ...query },
      { cancelToken }
    )
    if (response?.status !== 200 || !response?.data) return
    const { buckets }: { buckets: AggregatedTag[] } =
      response.data.aggregations.tags

    const tagsList = buckets
      .filter((tag) => tag.key !== '')
      .map((tag) => tag.key)

    return tagsList.sort()
  } catch (error) {
    if (axios.isCancel(error)) {
      LoggerInstance.log(error.message)
    } else {
      LoggerInstance.error(error.message)
    }
  }
}
