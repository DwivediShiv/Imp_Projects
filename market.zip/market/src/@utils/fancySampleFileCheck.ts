import { FileInfo, LoggerInstance } from '@oceanprotocol/lib'
import axios from 'axios'
import mime from 'mime-types'
import { getDefaultProviderUri } from './network'
import { getFileInfo } from './provider'
import cleanupContentType from '@utils/cleanupContentType'
import { filesize } from 'filesize'

export async function sampleFileInfo(
  url: string | any,
  providerUri?: string
): Promise<any> {
  if (!url) return
  if (typeof url !== 'string')
    return {
      contentLength: url[0]?.contentLength || '',
      contentType: url[0]?.contentType || '',
      url: url[0]?.url
    }

  try {
    if (url.indexOf('http://') === 0 || url.indexOf('https://') === 0) {
      const defaultProvider = providerUri || getDefaultProviderUri()
      const responses = await getFileInfo(url, defaultProvider)
      const response = responses?.[0]
      if (response?.valid) {
        return {
          contentLength: response?.contentLength || '',
          contentType: response?.contentType || '',
          url
        }
      }
    } else {
      throw new Error('Url does not contain http or https.')
    }
  } catch (error) {
    LoggerInstance.error(error.message)
  }
}

export function isEncryptUrl(url: string): boolean {
  if (typeof url !== 'string') return false

  return Boolean(url.match(/^0x[0-9a-f]+$/i))
}

export async function handleDownloadSample(links) {
  if (links?.url) {
    axios({
      url: links.url,
      method: 'GET',
      responseType: 'blob'
    }).then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      let fileExtension = 'txt'
      const fileName = links?.path || links?.name || 'sampleFile'
      if (links.contentType) {
        fileExtension = mime.extension(links.contentType)
      } else if (links.type) {
        fileExtension = mime.extension(links.type)
      }
      const urlLastDotIndex = fileName.lastIndexOf('.')
      const hasUrlFileExtension =
        urlLastDotIndex === -1 ? '' : fileName.substr(urlLastDotIndex + 1)

      link.setAttribute(
        'download',
        hasUrlFileExtension ? fileName : fileName + '.' + fileExtension
      )
      document.body.appendChild(link)
      link.click()

      setTimeout(function () {
        document.body.removeChild(link)
        window.URL.revokeObjectURL(url)
      }, 200)
    })
  }
}

export function getFileContentMessage(fileInfo: FileInfo): string {
  if (!fileInfo?.contentLength && !fileInfo?.contentType) return
  const fileInfoContentLength =
    fileInfo?.contentLength.length > 0 && fileInfo?.contentLength !== '0'
      ? filesize(Number(fileInfo?.contentLength))
      : ''
  const fileInfoContentType =
    fileInfo?.contentType &&
    cleanupContentType(fileInfo?.contentType).toUpperCase()

  const fileInfoMessage =
    !fileInfoContentType || !fileInfoContentLength
      ? 'Undefined'
      : `${fileInfoContentType && `.${fileInfoContentType}`}${
          fileInfoContentLength && `, ${fileInfoContentLength}`
        }`
  return fileInfoMessage
}
