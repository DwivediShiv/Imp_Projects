export function convertSecondToNearestTimeUnit(
  timeInSecond: number,
  isAbbreviate?: boolean
): string {
  const timeUnitMap: Map<string, number> = new Map([
    ['month', -1],
    ['week', -1],
    ['day', -1],
    ['hour', -1],
    ['minute', -1],
    ['second', -1]
  ])
  let result
  let previousValue = 1
  let tempTime = timeInSecond

  // calculate (and subtract) whole days
  timeUnitMap.set('month', Math.floor(tempTime / 2630000))
  tempTime -= timeUnitMap.get('month') * 2630000

  timeUnitMap.set('week', Math.floor(tempTime / 604800))
  tempTime -= timeUnitMap.get('week') * 604800

  timeUnitMap.set('day', Math.floor(tempTime / 86400))
  tempTime -= timeUnitMap.get('day') * 86400

  timeUnitMap.set('hour', Math.floor(tempTime / 3600) % 24)
  tempTime -= timeUnitMap.get('hour') * 3600

  timeUnitMap.set('minute', Math.floor(tempTime / 60) % 60)
  tempTime -= timeUnitMap.get('minute') * 60

  timeUnitMap.set('second', Math.floor(tempTime))

  for (const [key, value] of timeUnitMap.entries()) {
    if ((!previousValue || key === 'month') && value > 0) {
      result =
        `${value} ` +
        (isAbbreviate && (key === 'minute' || key === 'second')
          ? key.substring(0, 3)
          : key) +
        (value > 1 ? 's' : '')
      break
    }
    previousValue = value
  }

  return result
}
