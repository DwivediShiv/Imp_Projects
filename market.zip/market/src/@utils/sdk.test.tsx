import axios from 'axios'
import {
  formatListsOfServiceEndpoints,
  getListOfProviders,
  trimValue
} from './sdk'
import * as api from './api'
import * as network from './network'

jest.mock('axios')
jest.mock('./api')
jest.mock('./network')

describe('trimValue', () => {
  test('should return the input string unchanged if there is no equals sign', () => {
    const input = 'someValueWithoutEqualsSign'
    const result = trimValue(input)
    expect(result).toBe(input)
  })

  test('should return the input string unchanged if the value part is shorter than the trimming threshold', () => {
    const input = 'key=shortValue'
    const result = trimValue(input)
    expect(result).toBe('key=shortValue')
  })

  test('should trim the value part and append "..." if the value part is longer than the trimming threshold', () => {
    const input = 'key=' + 'a'.repeat(60)
    const expected = `key=${'a'.repeat(50)}...'`
    const result = trimValue(input)
    expect(result).toBe(expected)
  })

  test('should handle the case where value part is exactly equal to the trimming threshold', () => {
    const input = 'key=' + 'b'.repeat(50)
    const expected = `key=${'b'.repeat(50)}`
    const result = trimValue(input)
    expect(result).toBe(expected)
  })

  test('should handle the case where value part is exactly one character longer than the trimming threshold', () => {
    const input = 'key=' + 'c'.repeat(51)
    const expected = `key=${'c'.repeat(50)}...'`
    const result = trimValue(input)
    expect(result).toBe(expected)
  })
})

describe('getListOfProviders', () => {
  let localStorageMock: {
    getItem: jest.Mock
    setItem: jest.Mock
    removeItem: jest.Mock
    clear: jest.Mock
  }

  beforeEach(() => {
    localStorageMock = {
      getItem: jest.fn(),
      setItem: jest.fn(),
      removeItem: jest.fn(),
      clear: jest.fn()
    }

    Object.defineProperty(global, 'localStorage', {
      value: localStorageMock,
      writable: true
    })

    jest.clearAllMocks()
  })

  test('should return empty object if localStorage is invalid', async () => {
    ;(localStorageMock.getItem as jest.Mock).mockReturnValue(null)

    const result = await getListOfProviders()

    expect(result).toEqual({})
  })

  test('should handle API error gracefully', async () => {
    ;(localStorageMock.getItem as jest.Mock).mockReturnValue(null)
    ;(axios.get as jest.Mock).mockRejectedValue(new Error('API Error'))
    ;(api.getOrgProviderListUrl as jest.Mock).mockReturnValue(
      'https://api.example.com/providers'
    )
    ;(network.getTechnicalNetworkName as jest.Mock).mockReturnValue(
      'test-network'
    )

    const result = await getListOfProviders()

    expect(result).toEqual({})
  })

  test('should handle API cancellation gracefully', async () => {
    ;(localStorageMock.getItem as jest.Mock).mockReturnValue(null)
    ;(axios.get as jest.Mock).mockRejectedValue({ isCancel: true })
    ;(api.getOrgProviderListUrl as jest.Mock).mockReturnValue(
      'https://api.example.com/providers'
    )
    ;(network.getTechnicalNetworkName as jest.Mock).mockReturnValue(
      'test-network'
    )

    const result = await getListOfProviders()

    expect(result).toEqual({})
  })

  test('should return undefined if no chainId is provided and localStorage is empty', async () => {
    ;(localStorageMock.getItem as jest.Mock).mockReturnValue(null)

    const result = await getListOfProviders()

    expect(result).toEqual({})
  })
})

describe('formatListsOfServiceEndpoints', () => {
  test('should format provider lists into an object', () => {
    const input = [
      { name: 'Provider1', url: 'https://provider1.com' },
      { name: 'Provider2', url: 'https://provider2.com' }
    ]

    const expectedOutput = {
      Provider1: 'https://provider1.com',
      Provider2: 'https://provider2.com'
    }

    const result = formatListsOfServiceEndpoints(input)

    expect(result).toEqual(expectedOutput)
  })

  test('should return an empty object for an empty input list', () => {
    const input: { name?: string; url?: string }[] = []
    const expectedOutput: Record<string, string> = {}

    const result = formatListsOfServiceEndpoints(input)

    expect(result).toEqual(expectedOutput)
  })

  test('should ignore items with missing name or url', () => {
    const input = [
      { name: 'Provider1', url: 'https://provider1.com' },
      { name: 'Provider2' }, // Missing url
      { url: 'https://provider3.com' }, // Missing name
      { name: 'Provider4', url: 'https://provider4.com' }
    ]

    const expectedOutput = {
      Provider1: 'https://provider1.com',
      Provider4: 'https://provider4.com'
    }

    const result = formatListsOfServiceEndpoints(input)

    expect(result).toEqual(expectedOutput)
  })
})
