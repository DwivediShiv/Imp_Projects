import { LoggerInstance, ZERO_ADDRESS } from '@oceanprotocol/lib'
import {
  Address,
  Chain,
  Connector,
  ConnectorData,
  configureChains,
  createClient,
  erc20ABI
} from 'wagmi'
import { ethers, Contract, Signer, providers } from 'ethers'
import { formatEther, formatUnits, isAddress } from 'ethers/lib/utils'
import { getDefaultClient } from 'connectkit'
import { getInfuraKey, getSupportedChains } from './chains'
import { getNetworkDisplayName } from '@hooks/useNetworkMetadata'
import { getOceanConfig } from '../ocean'
import appConfig, { network } from '../../../app.config'
import axios, { AxiosResponse } from 'axios'
import {
  fetchPaymasterData,
  getC2DWalletsUrl,
  getCanWalletConnectUrl,
  getProfileRoleUrl,
  getUserWalletInfoUrl,
  getWalletCanConnect,
  putAddUserWalletUrl,
  putOrgAddUserWalletUrl
} from 'src/@utils/api'
import { getAccessToken } from '../auth'
import fancyToast from '@shared/fancy/atoms/Toast/FancyToast'
import { WalletAccess } from '@components/pages/Admin/UserDetails/components/wallet/WalletRole'
import { ManageWalletRole } from 'src/@types/User'
import { ROLE_CONSUMER, ROLE_PUBLISHER } from '@utils/authorization.constant'
import { getAsync } from '@utils/utils.api'
import { LoginParams } from '../../@types/SmartAccount'
import { ApiResponse } from 'src/@types/Form'

export async function getDummySigner(chainId: number): Promise<Signer> {
  if (typeof chainId !== 'number') {
    throw new Error('Chain ID must be a number')
  }

  // Get config from ocean lib
  const config = getOceanConfig(chainId)
  try {
    const privateKey =
      '0x0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'
    const provider = new ethers.providers.JsonRpcProvider(config.nodeUri)
    return new ethers.Wallet(privateKey, provider)
  } catch (error) {
    throw new Error(`Failed to create dummy signer: ${error.message}`)
  }
}

export function getSocialLoginParams() {
  const socialLoginParams: LoginParams = appConfig.socialLogin
  return socialLoginParams
}

// Wagmi client
export function getDefaultClientConfig() {
  const client = getDefaultClient({
    appName: 'Ocean Market',
    infuraId: getInfuraKey(),
    // TODO: mapping between appConfig.chainIdsSupported and wagmi chainId
    chains: getSupportedChains(appConfig.chainIdsSupported),
    walletConnectProjectId: appConfig.walletConnectProjectId
  })
  return client
}

export const wagmiClient = createClient(getDefaultClientConfig())

// ConnectKit CSS overrides
// https://docs.family.co/connectkit/theming#theme-variables
export const connectKitTheme = {
  '--ck-font-family': 'var(--font-family-base)',
  '--ck-border-radius': 'var(--border-radius)',
  // '--ck-overlay-background': 'var(--background-body-transparent)',
  '--ck-modal-box-shadow': '0 0 20px 20px var(--box-shadow-color)',
  // '--ck-body-background': 'var(--background-body)',
  // '--ck-body-color': 'var(--font-color-text)',
  '--ck-primary-button-border-radius': 'var(--border-radius)',
  '--ck-primary-button-color': 'var(--font-color-heading)',
  '--ck-primary-button-background': 'var(--background-content)',
  '--ck-secondary-button-border-radius': 'var(--border-radius)'
}

export function accountTruncate(account: string): string {
  if (!account || account === '') return
  const middle = account.substring(6, 38)
  const truncated = account.replace(middle, '…')
  return truncated
}

export async function addTokenToWallet(
  address: string,
  symbol: string,
  logo?: string
): Promise<void> {
  const image =
    logo ||
    'https://raw.githubusercontent.com/oceanprotocol/art/main/logo/token.png'

  const tokenMetadata = {
    type: 'ERC20',
    options: { address, symbol, image, decimals: 18 }
  }

  ;(window?.ethereum.request as any)(
    {
      method: 'wallet_watchAsset',
      params: tokenMetadata,
      id: Math.round(Math.random() * 100000)
    },
    (err: { code: number; message: string }, added: any) => {
      if (err || 'error' in added) {
        LoggerInstance.error(
          `Couldn't add ${tokenMetadata.options.symbol} (${
            tokenMetadata.options.address
          }) to MetaMask, error: ${err.message || added.error}`
        )
      } else {
        LoggerInstance.log(
          `Added ${tokenMetadata.options.symbol} (${tokenMetadata.options.address}) to MetaMask`
        )
      }
    }
  )
}

export async function addCustomNetwork(
  web3Provider: any,
  network: EthereumListsChain
): Promise<void> {
  // Always add explorer URL from ocean.js first, as it's null sometimes
  // in network data
  const blockExplorerUrls = [
    getOceanConfig(network.networkId).explorerUri,
    network.explorers && network.explorers[0].url
  ]

  const newNetworkData = {
    chainId: `0x${network.chainId.toString(16)}`,
    chainName: getNetworkDisplayName(network),
    nativeCurrency: network.nativeCurrency,
    rpcUrls: network.rpc,
    blockExplorerUrls
  }
  try {
    await web3Provider.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: newNetworkData.chainId }]
    })
  } catch (switchError) {
    if (switchError.code === 4902) {
      await web3Provider.request(
        {
          method: 'wallet_addEthereumChain',
          params: [newNetworkData]
        },
        (err: string, added: any) => {
          if (err || 'error' in added) {
            LoggerInstance.error(
              `Couldn't add ${network.name} (0x${
                network.chainId
              }) network to MetaMask, error: ${err || added.error}`
            )
          } else {
            LoggerInstance.log(
              `Added ${network.name} (0x${network.chainId}) network to MetaMask`
            )
          }
        }
      )
    } else {
      LoggerInstance.error(
        `Couldn't add ${network.name} (0x${network.chainId}) network to MetaMask, error: ${switchError}`
      )
    }
  }
  LoggerInstance.log(
    `Added ${network.name} (0x${network.chainId}) network to MetaMask`
  )
}

export async function getTokenBalance(
  accountId: string,
  decimals: number,
  tokenAddress: string,
  web3Provider: ethers.providers.Provider
): Promise<string> {
  if (!web3Provider || !accountId || !tokenAddress) return

  try {
    const token = new Contract(tokenAddress, erc20ABI, web3Provider)
    const balance = await token.balanceOf(accountId)
    const adjustedDecimalsBalance = `${balance}` // ${'0'.repeat(18 - decimals)}` // Kris: This commented is redundant, will push ocean PR for them when free
    return formatUnits(adjustedDecimalsBalance, decimals)
  } catch (e) {
    LoggerInstance.error(`ERROR: Failed to get the balance: ${e.message}`)
  }
}

export function getTokenBalanceFromSymbol(
  balance: UserBalance,
  symbol: string
): string {
  if (!symbol) return

  const baseTokenBalance = balance?.[symbol.toLocaleLowerCase()]
  return baseTokenBalance || '0'
}

export function getNetworkId(network: string): number {
  switch (network) {
    case 'mainnet':
      return 1
    case 'ropsten':
      return 3
    case 'rinkeby':
    case 'rinkeby testnet':
      return 4
    case 'goerli':
    case 'goerli testnet':
      return 5
    case 'sepolia':
    case 'sepolia testnet':
      return 11155111
    case 'polygon mainnet':
    case 'polygon':
      return 137
    case 'polygon amoy':
    case 'amoy':
      return 80002
    case 'kovan':
      return 42
    case 'development':
      return 8996
    case 'polygon supernet':
      return 81001
    case 'gen-x testnet':
      return 100
    case 'acentrik-testnet':
    case 'acentrik testnet':
      return 13520
    default:
      return 0
  }
}

export function isDefaultNetwork(networkId: number): boolean {
  const configuredNetwork = getNetworkId(network)
  return configuredNetwork === networkId
}

export function getNetworkName(networkId: number, isFancy?: boolean): string {
  switch (networkId) {
    case 1:
      return 'Main'
    case 3:
      return 'Ropsten'
    case 4:
      return isFancy ? 'Rinkeby testnet' : 'Rinkeby'
    case 5:
      return isFancy ? 'Goerli testnet' : 'Goerli'
    case 137:
      return isFancy ? 'Polygon mainnet' : 'Polygon'
    case 42:
      return 'Kovan'
    case 8996:
      return 'Development'
    case 80002:
      return isFancy ? 'Polygon amoy' : 'Amoy'
    case 81001:
      return isFancy ? 'Polygon supernet' : 'Polygonedge'
    case 11155111:
      return isFancy ? 'Sepolia testnet' : 'Sepolia'
    case 100:
      return isFancy ? 'Gen-X testnet' : 'Gen-x-testnet'
    case 13520:
      return 'Acentrik testnet'
    default:
      return 'Unknown'
  }
}

export async function getUserWalletInfoList(): Promise<any> {
  await getAccessToken()
  const response: AxiosResponse = await axios({
    method: 'GET',
    url: getUserWalletInfoUrl()
  })
  if (response.status !== 200) {
    fancyToast('error', 'Non-200 response: ' + response.status)
    return
  }
  return response.data
}

export async function addUserWallet(accountId: string): Promise<any> {
  await getAccessToken()
  const response: AxiosResponse = await axios({
    method: 'PUT',
    url: appConfig.isOrgEnabled
      ? putOrgAddUserWalletUrl(accountId)
      : putAddUserWalletUrl(accountId)
  })
  if (response.status !== 200) {
    fancyToast('error', 'Non-200 response: ' + response.status)
    return
  }
  return response.data
}

export async function getIsWalletCanConnect(
  accountId: string
): Promise<boolean> {
  if (!accountId) {
    return false
  }
  try {
    const response: AxiosResponse = await axios({
      method: 'GET',
      url: getWalletCanConnect(accountId)
    })
    return response.data.status
  } catch (error) {
    if (error.response.status !== 200) {
      console.log('Non-200 response: ' + error.response.data?.error?.message)
    }
  }
}

export function transformChainIdsToNetworkList(chainIds: number[]): string[] {
  const list = []
  for (let i = 0; i < chainIds.length; i++) {
    const element = chainIds[i]
    list.push(getNetworkName(element, true))
  }
  return list
}

export function sanitizeAddress(address: string) {
  return address === ZERO_ADDRESS ? null : address
}

function getRoles(walletAccess: WalletAccess): string[] {
  const roles: string[] = []
  if (walletAccess.hasConsumerRole) {
    roles.push(ROLE_CONSUMER)
  }
  if (walletAccess.hasPublisherRole) {
    roles.push(ROLE_PUBLISHER)
  }
  return roles
}

export function convertToManageWalletRoles(
  walletAccess: WalletAccess[]
): ManageWalletRole[] {
  if (!walletAccess) return []
  const roles: ManageWalletRole[] = []
  walletAccess.forEach((wallet) => {
    roles.push({
      address: wallet.walletAddress,
      roles: getRoles(wallet),
      state: wallet.state
    })
  })
  return roles
}

export const ErrorMessage = {
  associated:
    'The wallet address is taken, please enter a different wallet address.',
  noRole: 'For non admin user the wallet should have atleast one role.',
  invalid: 'Invalid wallet address.',
  exist: 'This wallet address has already been entered, please enter another.',
  required: 'Required Field.'
}

export function isInList(
  inputWallet: string,
  profileWallets: WalletAccess[]
): boolean {
  if (!profileWallets?.length) return false
  const profileWallet = profileWallets?.find(
    (wallet) => wallet.walletAddress === inputWallet
  )
  return !!profileWallet
}

// export function isValidAddress(value: string): boolean {
//   if (value?.length !== 42) {
//     return false
//   }
//   return isAddress(value)
// }

export async function getCanWalletConnect(accountId: string): Promise<boolean> {
  if (!accountId) {
    return false
  }
  try {
    const response: AxiosResponse = await axios({
      method: 'GET',
      url: getCanWalletConnectUrl(accountId)
    })
    return response?.data?.status
  } catch (error) {
    if (error?.response?.status !== 200) {
      console.error('Non-200 response: ' + error.response.data?.error?.message)
      return false
    }
  }
}

export async function getWalletAssignRoles(userId: string): Promise<any> {
  try {
    const response: AxiosResponse = await getAsync(getProfileRoleUrl(userId))
    return response?.data
  } catch (error) {
    if (error?.response?.status !== 200) {
      console.error('Non-200 response: ' + error.response.data?.error?.message)
      return false
    }
  }
}

export async function validateAddress(
  wallet: string,
  existingWallet: string[],
  isSkipAssociationCheck = false
): Promise<string> {
  if (!wallet || !existingWallet) return
  const isValid = isAddress(wallet)

  if (!isValid) {
    return ErrorMessage.invalid
  }

  if (existingWallet.includes(wallet.toLowerCase())) {
    return ErrorMessage.exist
  }

  if (!isSkipAssociationCheck) {
    const isAssociated = await getCanWalletConnect(wallet)
    if (!isAssociated) {
      return ErrorMessage.associated
    }
  }

  return ''
}

export function copyAddressToClipboard(text: string) {
  navigator.clipboard.writeText(text)
  const copiedMessage = 'Smart account address copied to clipboard.'
  fancyToast('success', copiedMessage, copiedMessage)
}
export async function getc2dWalletList(): Promise<any> {
  try {
    const { data: response, status } = await axios.get<ApiResponse<any>>(
      getC2DWalletsUrl()
    )
    if (status !== 200) {
      console.error('Unable to get c2dUser')
    }
    return response
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error(error.message)
    } else {
      console.error('Error Occured while getting c2dUser', error.message)
    }
  }
}
