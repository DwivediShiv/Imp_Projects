import { getTechnicalNetworkName } from '@utils/network'
import appConfig from 'app.config'
import { Chain } from 'wagmi'
import * as wagmiChains from 'wagmi/chains'

export const getInfuraKey = () => {
  if (appConfig.infuraProjectId) {
    return appConfig.infuraProjectId
  }
  const keys = appConfig.infuraProjectKeys
  return keys?.length > 0 && keys[Math.floor(Math.random() * keys.length)]
}

const getRpcFallback = (wagmiConfig) => {
  const chainId = wagmiConfig.id
  const networkName = getTechnicalNetworkName(chainId)

  const defaultRpcEndpoint = appConfig?.networkConfig?.[networkName]?.rpc
  if (defaultRpcEndpoint) {
    return {
      public: { http: [defaultRpcEndpoint] },
      default: { http: [defaultRpcEndpoint] }
    }
  }

  const infuraRpcEndpoint = wagmiConfig?.rpcUrls?.infura?.http
  const infuraKey = getInfuraKey()
  if (infuraKey && infuraRpcEndpoint?.length) {
    return {
      ...wagmiConfig?.rpcUrls,
      public: {
        http: [`${infuraRpcEndpoint}/${infuraKey}`]
      },
      default: {
        http: [`${infuraRpcEndpoint}/${infuraKey}`]
      }
    }
  }

  return wagmiConfig?.rpcUrls
}

const fancyGetWagmiConfig = (wagmiConfig: Chain) => {
  const rpcUrls = getRpcFallback(wagmiConfig)
  return { ...wagmiConfig, ...{ rpcUrls } }
}

const SUPERNET_WAGMI_CONFIG: Chain = {
  id: 81001,
  name: 'EDGE',
  network: 'supernetTestnet',
  nativeCurrency: { name: 'Edge', symbol: 'EDGE', decimals: 18 },
  rpcUrls: {
    public: { http: ['https://rpc-edgenet.polygon.technology'] },
    default: { http: ['https://rpc-edgenet.polygon.technology'] }
  },
  blockExplorers: {
    etherscan: {
      name: 'EdgeNet',
      url: 'https://explorer-edgenet.polygon.technology/'
    },
    default: {
      name: 'EdgeNet',
      url: 'https://explorer-edgenet.polygon.technology/'
    }
  },
  testnet: true
} as const

const ACENTRIK_TESTNET_WAGMI_CONFIG: Chain = {
  id: 13520,
  name: 'Acentrik Testnet',
  network: 'acentrik-testnet',
  nativeCurrency: { name: 'Acentrik Matic', symbol: 'aMatic', decimals: 18 },
  rpcUrls: {
    public: {
      http: [appConfig?.networkConfig?.['acentrik-testnet']?.rpc]
    },
    default: {
      http: [appConfig?.networkConfig?.['acentrik-testnet']?.rpc]
    }
  },
  // blockExplorers: {
  //   default: {
  //     name: 'Blockscout',
  //     url: 'https://explorer-edgenet.polygon.technology/'
  //   }
  // },
  testnet: true
} as const

// can remove when Wagmi have amoy chain config by default:
const AMOY_TESTNET_WAGMI_CONFIG: Chain = {
  id: 80002,
  name: 'Polygon Amoy',
  network: 'amoy',
  nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
  rpcUrls: {
    public: {
      http: [appConfig?.networkConfig?.amoy?.rpc]
    },
    default: {
      http: [appConfig?.networkConfig?.amoy?.rpc]
    }
  },
  blockExplorers: {
    default: {
      name: 'Blockscout',
      url: 'https://www.oklink.com/amoy/'
    }
  },
  testnet: true
} as const

// Kris: Declare all custom chain that do not exist in wagmi/chains here:
// Refer: https://wagmi.sh/react/chains#build-your-own
const fancyWagmiChains = [
  {
    SUPERNET_WAGMI_CONFIG,
    ACENTRIK_TESTNET_WAGMI_CONFIG,
    AMOY_TESTNET_WAGMI_CONFIG
  }
]
const privateNetworks = [
  SUPERNET_WAGMI_CONFIG.id,
  ACENTRIK_TESTNET_WAGMI_CONFIG.id,
  AMOY_TESTNET_WAGMI_CONFIG.id
]

export const getSupportedChains = (chainIdsSupported: number[]): Chain[] => {
  const supportedChains: Chain[] = []

  chainIdsSupported.forEach((chainId) => {
    for (const chain of [...fancyWagmiChains, wagmiChains]) {
      let supportedChain = Object.values(chain).find(
        (c: Chain) => c.id === chainId
      ) as Chain

      if (supportedChain) {
        if (!privateNetworks.includes(chainId)) {
          supportedChain = fancyGetWagmiConfig(supportedChain)
        }
        supportedChains.push(supportedChain)
        break
      }
    }
  })
  return supportedChains
}
