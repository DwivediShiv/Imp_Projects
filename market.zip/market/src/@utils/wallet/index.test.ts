import axios from 'axios'
import { getAccessToken } from '@utils/auth'
import { accountTruncate, getUserWalletInfoList } from './index'
import fancyToast from '@shared/fancy/atoms/Toast/FancyToast'
import { falsyValues } from '../../../.jest/__fixtures__/mockUtils'
import { copyAddressToClipboard } from '@utils/wallet'

jest.mock('axios')
const mockedAxios = axios as jest.MockedFunction<typeof axios>

jest.mock('@utils/auth', () => {
  const actualTracker = jest.requireActual('@utils/auth')
  return {
    ...actualTracker,
    getAccessToken: jest.fn()
  }
})
jest.mock('@shared/fancy/atoms/Toast/FancyToast', () => ({
  __esModule: true,
  default: jest.fn()
}))

const mockedWallets = [
  ['0x9984…84e0', '0x99840df5cb42fabe0feb8811aaa4bc99ca6c84e0'],
  ['0x7B97…4A02', '0x7B97450975E89Ce1dB2EC1FEa1F82E234a5d4A02'],
  ['0xd1Cd…E8Ec', '0xd1CdD6182f86456712e49Eea0C03aF5A1375E8Ec']
]

describe('accountTruncate', () => {
  it.each(mockedWallets)('should return %p if given %p', (expected, input) => {
    expect(accountTruncate(input)).toEqual(expected)
  })

  it('should return undefined if given falsy value', () => {
    falsyValues.forEach((value: any) => {
      expect(accountTruncate(value)).toBeUndefined()
    })
  })

  it('should return undefined if invalid wallet address is given', () => {
    expect(accountTruncate('0x123')).toBe('…0x123')
  })
})

describe('getUserWalletInfoList', () => {
  it('should able to get user wallet info list', async () => {
    const successfulResponse = {
      data: { text: 'Successful' },
      status: 200,
      statusText: 'Ok',
      headers: {},
      config: {}
    }
    mockedAxios.mockResolvedValue(successfulResponse)
    await getUserWalletInfoList()

    expect(getAccessToken).toBeCalled()
  })

  it('should be able to call toast a message when there is failure in calling get user wallet info API.', async () => {
    const errorCode = 404
    const successfulResponse = {
      data: { text: '' },
      status: errorCode,
      statusText: '',
      headers: {},
      config: {}
    }
    mockedAxios.mockResolvedValue(successfulResponse)
    await getUserWalletInfoList()

    expect(getAccessToken).toBeCalled()
    expect(fancyToast).toHaveBeenCalledWith(
      'error',
      `Non-200 response: ${errorCode}`
    )
  })
})

describe('copyAddressToClipboard', () => {
  const clipboardWriteTextMock = jest.fn()
  Object.defineProperty(navigator, 'clipboard', {
    value: {
      writeText: clipboardWriteTextMock
    }
  })

  afterEach(() => {
    jest.clearAllMocks()
  })

  it('should call clipboard.writeText with Smart Account Address', () => {
    const textToCopy = 'Address to copy'
    copyAddressToClipboard(textToCopy)
    expect(clipboardWriteTextMock).toHaveBeenCalledWith(textToCopy)
  })

  it('should call fancyToast with success message', () => {
    const textToCopy = 'Address to copy'
    copyAddressToClipboard(textToCopy)
    const successMessage = 'Smart account address copied to clipboard.'
    expect(fancyToast).toHaveBeenCalledWith(
      'success',
      successMessage,
      successMessage
    )
  })
})
