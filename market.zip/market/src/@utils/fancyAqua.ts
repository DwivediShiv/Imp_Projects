import { Asset } from '@oceanprotocol/lib'
import { CancelToken } from 'axios'
import { queryMetadata, transformChainIdsListToQuery } from './aquarius'

export async function getAssetMetadataByDids(
  dids: string[],
  cancelToken: CancelToken,
  chainIds: number[]
): Promise<Asset[]> {
  const searchDids = JSON.stringify(dids)
    .replace(/,/g, ' ')
    .replace(/"/g, '')
    .replace(/(\[|\])/g, '')
  const didQueury = searchDids ? `(${searchDids}) AND ` : ''
  const queryDid = {
    from: 0,
    query: {
      query_string: {
        query: `${didQueury}(${transformChainIdsListToQuery(chainIds)})`,
        fields: ['dataToken']
      }
    }
  }

  const result = await queryMetadata(queryDid, cancelToken)
  return result.results
}

export function getDidListQuerryString(did: string[], chainId?: number): any {
  let algoQuerry = ''
  did.forEach((id) => {
    algoQuerry += `id:"${id}" OR `
  })
  if (did.length >= 1) {
    algoQuerry = algoQuerry.substring(0, algoQuerry.length - 3)
  }
  const algorithmQuery = did.length > 0 ? `(${algoQuerry})` : ``
  const query = {
    size: 500,
    query: {
      query_string: {
        query: `${algorithmQuery} AND chainId:${chainId} AND services.type:"compute"` // return algo private only with type `compute`
      }
    },
    sort: { 'metadata.created': 'desc' }
  }
  return query
}
