import appConfig from '../../app.config'

export function isSupportedNetwork(networkId: number): boolean {
  return Boolean(appConfig.chainIdsSupported.indexOf(networkId) !== -1)
}
