import axios from 'axios'
import {
  changePassword,
  login,
  requestResetPassword,
  resetPassword,
  signup,
  validateDomain
} from './auth'

jest.mock('axios')
const mockedAxios = axios as jest.MockedFunction<typeof axios>

jest.mock('./api', () => ({
  getEmailDomainUrl: jest.fn(),
  postSignupUrl: jest.fn(),
  postResetPasswordUrl: jest.fn(),
  putLoginUrl: jest.fn(),
  postRequestResetPasswordUrl: jest.fn(),
  putChangePasswordUrl: jest.fn()
}))

const email = 'admin@google.com'

describe('Authentication', () => {
  it('should request reset password successful', async () => {
    mockedAxios.mockResolvedValue({
      data: {
        email
      },
      status: 200,
      statusText: 'Ok',
      headers: {},
      config: {}
    })
    const response = await requestResetPassword(email)
    expect(response).toStrictEqual({ email })
  })

  it('should login successful', async () => {
    const password = 'fakePassword!123'
    mockedAxios.mockResolvedValue({
      data: {
        email,
        password
      },
      status: 200,
      statusText: 'Ok',
      headers: {},
      config: {}
    })
    const response = await login(email, password)
    expect(response).toStrictEqual({
      email,
      password
    })
  })

  it('should reset password successful', async () => {
    const actionToken = 'YTHJHTXKSSXTPLARALRH'
    const password = 'fakePassword123!'
    mockedAxios.mockResolvedValue({
      data: {
        actionToken,
        password
      },
      status: 200,
      statusText: 'Ok',
      headers: {},
      config: {}
    })
    const response = await resetPassword(actionToken, password)
    expect(response).toStrictEqual({
      actionToken,
      password
    })
  })

  it('should validate domain successful', async () => {
    const email = 'kianjun@mercedes-benz.com'
    const cancelToken = mockedAxios.CancelToken
    mockedAxios.mockResolvedValue({
      data: { cancelToken },
      status: 200,
      statusText: 'Ok',
      headers: {},
      config: {}
    })
    const response = await validateDomain(email, cancelToken)
    expect(response).toStrictEqual({
      cancelToken
    })
  })

  it('should change current password successful', async () => {
    const currentPassword = 'fakePassword123!'
    const password = 'newPassword123!'
    mockedAxios.mockResolvedValue({
      data: {
        currentPassword,
        password
      },
      status: 200,
      statusText: 'Ok',
      headers: {},
      config: {}
    })
    const response = await changePassword(currentPassword, password)
    expect(response).toStrictEqual({
      currentPassword,
      password
    })
  })

  it('should sign up successful', async () => {
    const companyName = 'Mercedes-Benz Tech Innovation'
    const country = 'Malaysia'
    const otherCountry = 'Singapore'
    const industry = 'Automotive'
    const email = 'kianjun@mercedes-benz.com'
    const password = 'fakePassword123!'
    const purpose = 'consume'
    const isMarketingConsent = 'false'
    const actionToken = 'YTHJHTXKSSXTPLARALRH'
    const value = {
      companyName,
      country,
      otherCountry,
      industry,
      email,
      password,
      purpose,
      isMarketingConsent,
      actionToken
    }
    mockedAxios.mockResolvedValue({
      data: {
        value
      },
      status: 200,
      statusText: 'Ok',
      headers: {},
      config: {}
    })

    const response = await signup(value)
    expect(response).toStrictEqual({
      value: {
        companyName,
        country,
        otherCountry,
        industry,
        email,
        password,
        purpose,
        isMarketingConsent,
        actionToken
      }
    })
  })

  it('should fail validating domain', async () => {
    const email = null
    const cancelToken = mockedAxios.CancelToken
    mockedAxios.mockRejectedValue(new Error('Async error message'))
    const response = await validateDomain(email, cancelToken)
    expect(response).toMatchObject(new Error('Async error message'))
  })
})
