import { AssetListPrices } from './subgraph'
import { capitalize, uniq } from 'lodash'
import {
  PRICE_TYPE_FREE_LABEL,
  PRICE_TYPE_POSTPAY_LABEL
} from 'src/components/Constants'
import moment from 'moment'
import { format } from 'date-fns'
import { FILE_NAME_EXPORT_SALE_HISTORY } from 'src/components/pages/dashboard/sales/Constants'
import { strongTypeTitle } from '@shared/fancy/Teaser/FancyAssetBadge'
import { convertUsdcSymbolToUsd } from '.'

// Kris TODO: future expand usecase add switch case based on type of interface passed in and do require implementation
export function formatToExportJson(data: Sale[]) {
  return data?.map((row) => {
    return {
      Date: format(row.orderDate, 'dd MMM yyyy'),
      Consumer: row.consumerCompanyName,
      Asset: row.assetName,
      'Asset Type': capitalize(row.assetType),
      'Access Type': row.assetType
        ? strongTypeTitle[row.assetType]?.[row.accessType]
        : '',
      Revenue:
        row.priceValue > 0
          ? `${row.priceValue} ${convertUsdcSymbolToUsd(row.tokenSymbol)}`
          : `Free`
    }
  })
}

export function generateSalesReportName() {
  const current = format(new Date(), 'ddMMyyyy')
  return `${FILE_NAME_EXPORT_SALE_HISTORY}_${current}`
}

export function getSalesAssetMap(
  assets: AssetListPrices[]
): Map<string, SalesAsset> {
  const assetMap = new Map<string, SalesAsset>()
  assets?.forEach((asset) => {
    const datatoken = asset.ddo.services[0].datatokenAddress.toLocaleLowerCase()
    assetMap.set(datatoken, {
      did: asset.ddo.id,
      chainId: asset.ddo.chainId,
      assetName: asset.ddo.metadata.name,
      assetType: asset.ddo.metadata.type,
      accessType: asset.ddo.services[0].type,
      owner: asset.ddo.nft.owner,
      tokenSymbol: asset.price?.symbol
    })
  })
  return assetMap
}

export function getPayers(orders: TokenOrder[] | Sale[]): string[] {
  const wallets = orders?.map((order) => {
    return order?.payer?.id || order?.payer
  })
  return uniq(wallets)
}
export function getAbstractPayers(orders: TokenOrder[] | Sale[]): string[] {
  const wallets = orders?.map((order) => {
    return order?.consumer?.id || order?.consumer
  })
  return uniq(wallets)
}

export function getConsumerCompanyNames(sales: Sale[]): string[] {
  const consumerCompanyName = sales?.map((sale) => {
    return sale.consumerCompanyName
  })
  return uniq(consumerCompanyName)
}

export function getAssetNames(sales: Sale[]): string[] {
  const assetNames = sales?.map((sale) => {
    return sale.assetName
  })
  return uniq(assetNames)
}

export function filterByConsumerCompanyName(
  sales: Sale[],
  companyNames: string[]
): Sale[] {
  let originalAsset = sales
  if (sales && companyNames?.length > 0) {
    originalAsset = sales.filter(
      (sale) => companyNames.indexOf(sale.consumerCompanyName) !== -1
    )
  }
  return originalAsset
}

export function filterByAssetName(sales: Sale[], assetName: string[]): Sale[] {
  let originalAsset = sales
  if (sales && assetName?.length > 0) {
    originalAsset = sales.filter(
      (sale) => assetName.indexOf(sale.assetName) !== -1
    )
  }
  return originalAsset
}

export function filterByWallet(sales: Sale[], wallets: string[]): Sale[] {
  let originalAsset = sales
  if (sales && wallets?.length > 0) {
    originalAsset = sales.filter(
      (sale) => wallets.indexOf(sale.payer.toLowerCase()) !== -1
    )
  }
  return originalAsset
}

export function searchData(search: string, sales?: Sale[]): Sale[] {
  if (!search || !sales) return sales

  return sales.filter((sale) =>
    sale.assetName.toLowerCase().includes(search.toLowerCase())
  )
}

export function filterByPricing(sales: Sale[], pricing: string[]): Sale[] {
  if (!sales || !pricing || pricing.length === 3) return sales
  const isNoPriceCreated = pricing.indexOf('No Price Set') !== -1
  const isFreePrice = pricing.indexOf(PRICE_TYPE_FREE_LABEL) !== -1
  const isPostPay = pricing.indexOf(PRICE_TYPE_POSTPAY_LABEL) !== -1
  let filteredAssets = sales
  if (isNoPriceCreated && isFreePrice) {
    filteredAssets = filteredAssets.filter(
      (filteredAsset) => filteredAsset.priceValue <= 0
    )
  } else if (isPostPay && isFreePrice) {
    filteredAssets = filteredAssets.filter(
      (filteredAsset) =>
        (filteredAsset.priceValue > 0 && filteredAsset.subType) ||
        filteredAsset.priceValue === 0
    )
  } else if (isNoPriceCreated) {
    filteredAssets = filteredAssets.filter(
      (filteredAsset) => filteredAsset.priceValue === -1
    )
  } else if (isFreePrice) {
    filteredAssets = filteredAssets.filter(
      (filteredAsset) => filteredAsset.priceValue === 0
    )
  } else if (isPostPay) {
    filteredAssets = filteredAssets.filter(
      (filteredAsset) => filteredAsset.priceValue > 0 && filteredAsset.subType
    )
  }
  return filteredAssets
}

export function filterByDataType(sales: Sale[], dataType: string[]): Sale[] {
  if (!dataType?.length || !sales) {
    return sales
  }

  const isDataset = dataType.indexOf('dataset') !== -1
  const isAlgo = dataType.indexOf('algorithm') !== -1
  if (isDataset && isAlgo) return sales
  if (isDataset || isAlgo) {
    return sales.filter((sale) => {
      return (
        (isDataset && sale.assetType === 'dataset') ||
        (isAlgo && sale.assetType === 'algorithm')
      )
    })
  }

  const isPrivate = dataType.indexOf('private') !== -1
  const isPublic = dataType.indexOf('public') !== -1
  const isCompute = dataType.indexOf('compute') !== -1
  const isAccess = dataType.indexOf('access') !== -1
  const isAllSelected = isPrivate && isPublic && isCompute && isAccess
  const isAllDeselected = !isPrivate && !isPublic && !isCompute && !isAccess
  if (isAllSelected || isAllDeselected) return sales

  const isDatasetWithAcessType =
    (isCompute || isAccess) && !(isCompute && isAccess)
  const isAlgoWithAcessType =
    (isPrivate || isPublic) && !(isPrivate && isPublic)

  const datasetAccessType = isCompute ? 'compute' : 'access'
  const algoAccessType = isPrivate ? 'compute' : 'access'

  const filtered = sales.filter((sale) => {
    return (
      (isDatasetWithAcessType &&
        sale.assetType === 'dataset' &&
        sale.accessType === datasetAccessType) ||
      (isAlgoWithAcessType &&
        sale.assetType === 'algorithm' &&
        sale.accessType === algoAccessType)
    )
  })
  return filtered || sales
}

export function filterByDate(
  sales: Sale[],
  startDate?: Date,
  endDate?: Date
): Sale[] {
  if (!sales) return

  let filteredAssets = sales
  if (startDate)
    filteredAssets = filteredAssets.filter((filteredAsset) => {
      const orderedDate = moment(
        filteredAsset.orderDate.toISOString(),
        'YYYY-MM-DD'
      ).toDate()
      return moment(startDate.toISOString())
        .startOf('day')
        .isSameOrBefore(orderedDate)
    })
  if (endDate)
    filteredAssets = filteredAssets.filter((filteredAsset) => {
      const orderedDate = moment(
        filteredAsset.orderDate.toISOString(),
        'YYYY-MM-DD'
      ).toDate()
      return moment(endDate.toISOString())
        .endOf('day')
        .isSameOrAfter(orderedDate)
    })
  return filteredAssets || sales
}

export function isValidDate(date: Date): boolean {
  if (!date) return false
  try {
    return moment(date.toISOString(), 'YYYY-MM-DD').isValid()
  } catch (error) {
    return false
  }
}
