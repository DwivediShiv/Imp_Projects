import { FormPublishData } from 'src/components/Publish/_types'
import { values as initialEditValues } from '../../.jest/__fixtures__/formPublishData'
import { isFormValuesChanged } from './form'
import { initialValues as initialPublishValues } from '../components/Publish/_constants'

describe('isFormValuesChanged', () => {
  let publishValues: FormPublishData
  let editValues: FormPublishData

  beforeEach(() => {
    publishValues = {
      ...initialPublishValues
    }
    editValues = {
      ...initialEditValues
    }
  })

  it('should return true when values have changed [PUBLISH FLOW]', () => {
    publishValues.isExperimental = true
    const action = 'PUBLISH'
    const isEdited = isFormValuesChanged(
      initialPublishValues,
      publishValues,
      action
    )
    expect(isEdited).toBe(true)
  })

  it('should return false when values have not changed [PUBLISH FLOW]', () => {
    const action = 'PUBLISH'
    const isEdited = isFormValuesChanged(
      initialPublishValues,
      publishValues,
      action
    )
    expect(isEdited).toBe(false)
  })

  it('should return false when only excluded properties were changed [PUBLISH FLOW]', () => {
    publishValues.user = {
      stepCurrent: 2,
      accountId: '0x123',
      chainId: 137
    }
    const action = 'PUBLISH'
    const isEdited = isFormValuesChanged(
      initialPublishValues,
      publishValues,
      action
    )
    expect(isEdited).toBe(false)
  })

  it('should return true when values have changed [EDIT FLOW]', () => {
    const editValues = {
      ...initialEditValues,
      metadata: {
        ...initialEditValues.metadata,
        name: 'edited name'
      }
    }
    const action = 'EDIT'
    const isEdited = isFormValuesChanged(initialEditValues, editValues, action)
    expect(isEdited).toBe(true)
  })

  it('should return true when pricing values have changed [EDIT FLOW]', () => {
    const editValues = {
      ...initialEditValues,
      pricing: {
        ...initialEditValues.pricing,
        price: '88'
      }
    }
    const action = 'EDIT'
    const isEdited = isFormValuesChanged(initialEditValues, editValues, action)
    expect(isEdited).toBe(true)
  })

  it('should return false when values have not changed [EDIT FLOW]', () => {
    const action = 'EDIT'
    const isEdited = isFormValuesChanged(initialEditValues, editValues, action)
    expect(isEdited).toBe(false)
  })

  it('should return false when only excluded properties were changed [EDIT FLOW]', () => {
    editValues.isLinksValid = true
    const action = 'EDIT'
    const isEdited = isFormValuesChanged(initialEditValues, editValues, action)
    expect(isEdited).toBe(false)
  })

  it('should return true when values have changed [EDIT_METADATA FLOW]', () => {
    editValues.metadata = {
      ...initialEditValues.metadata,
      name: 'edited name'
    }
    const action = 'EDIT_METADATA'
    const isEdited = isFormValuesChanged(initialEditValues, editValues, action)
    expect(isEdited).toBe(true)
  })

  it('should return false when values have not changed [EDIT_METADATA FLOW]', () => {
    const action = 'EDIT_METADATA'
    const isEdited = isFormValuesChanged(initialEditValues, editValues, action)
    expect(isEdited).toBe(false)
  })

  it('should return false when only excluded properties were changed [EDIT_METADATA FLOW]', () => {
    editValues.pricing = {
      ...initialEditValues.pricing,
      price: 8888
    }
    const action = 'EDIT_METADATA'
    const isEdited = isFormValuesChanged(initialEditValues, editValues, action)
    expect(isEdited).toBe(false)
  })

  it('should return true when price has changed [EDIT_PRICE FLOW]', () => {
    const initialValuesPrice = {
      type: 'fixed',
      price: '1'
    }
    const values = {
      price: '2'
    }
    const action = 'EDIT_PRICE'
    const isEdited = isFormValuesChanged(initialValuesPrice, values, action)
    expect(isEdited).toBe(true)
  })
})
