export const MAX_DECIMALS = 6
export const USDC_DECIMAL = 6
export const WEI_DECIMAL = 18
export const SAMPLE_TYPE_UPLOAD = 'UPLOAD'
export const SAMPLE_TYPE_URL = 'URL'
export const SMALL_DESKTOP_BREAKPOINT = 1280
export const DEFAULT_DOWNLOAD_FILE_NAME = 'download'
export const OCEAN_DECIMAL = 18
export enum IconSize {
  ExtraLarge = 'iconSizeExtraLarge',
  Large = 'iconSizeLarge',
  Medium = 'iconSizeMedium',
  Small = 'iconSizeSmall'
}
export enum IconColor {
  Primary = 'iconColorPrimary',
  Secondary = 'iconColorSecondary',
  Info = 'iconColorInfo'
}
export enum ImageSize {
  Large = 'imageSizeLarge',
  Small = 'imageSizeSmall'
}
export const MAXIMUM_NUMBER_OF_PAGES_WITH_RESULTS = 476
export const STATE_DELIST = 1
export const STATE_ACTIVE = [0, 4]
export const START_TRUNCATE = 36
export const END_TRUNCATE = 14
export const DOT = '...'
export const MINIMUM_URL_LENGTH = 20

export const USER_MESSAGES = {
  USER_INVITED: 'The invitation email has been resent successfully.',
  USER_INFO_UPDATED: 'User information updated sucessfully',
  ERROR_COMMON: 'Unexpected error ocurred'
}

export const STATUS_CODE_INCORRECT_OTP = 'INSTANCE_ADMIN_OTP_INCORRECT'
export const STATUS_CODE_EXPIRED_OTP = 'INSTANCE_ADMIN_OTP_EXPIRED'
export const INVALID_OTP_ERR_MSG = 'Invalid OTP. Please try again.'
export const EXPIRED_OTP_ERR_MSG =
  'OTP has expired. Please resend another OTP and try again.'
export const USER_UNAUTHORISED_ACTION = 'Error_UnAuthorizedUserAction'
export const HISTORY_INDEX = '_histories'
export const SDK_MESSAGE = {
  SUCCESS: 'Successful. Copied SDK Parameters to clipboard'
}
export const ABORT_TIMEOUT = 5000
export const ACCOUNT_ABSTRACTION_PROVIDERS = {
  BICONOMY: 'biconomy',
  ALCHEMY: 'alchemy'
}
export const PRICE_CALCULATION_BASE = 1e18
