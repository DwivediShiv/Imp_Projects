import { Asset, Config } from '@oceanprotocol/lib'
import { CancelToken, CancelTokenSource } from 'axios'
import { generateBaseQuery, getAssetsFromDids, queryMetadata } from './aquarius'
import { simpleTransform } from './fancyAssetConvertor'
import { fetchDummyDataset } from '@components/FederatedLearning/info/utils'
import { AssetSelectionAsset } from '@components/@shared/FormInput/InputElement/AssetSelection'

export async function getValidAggregateAlgorithms(
  asset: Asset,
  cancelTokenSource: CancelTokenSource,
  config?: Config
): Promise<AssetSelectionAsset[]> {
  const aggregateAlgorithmList =
    asset.metadata.additionalInformation.relatedAggregateAlgorithms

  let results = []
  results = await getAssetsFromDids(
    aggregateAlgorithmList,
    [asset?.chainId],
    cancelTokenSource.token,
    false
  )

  // Filter out aggregate algorithms that are not connected with a dummy dataset
  const filteredResults = []
  for (const algo of results) {
    const dummyDataset = await fetchDummyDataset(algo?.id, algo?.chainId)
    if (dummyDataset !== undefined) {
      filteredResults.push(algo)
    }
  }

  results = filteredResults

  const algorithmSelectionList = await simpleTransform(results, config)

  return algorithmSelectionList
}

export async function getValidFederatedDatasets(
  algorithmId: string,
  datasetProviderUri: string,
  datasetChainId?: number,
  isSkipTransform?: boolean,
  cancelToken?: CancelToken,
  config?: Config
): Promise<AssetSelectionAsset[] | Asset[]> {
  const baseQueryParams = {
    chainIds: [datasetChainId],
    nestedQuery: {
      must: {
        match_phrase: {
          'services.compute.publisherTrustedAlgorithms.did': {
            query: algorithmId
          }
        }
      }
    }
  } as BaseQueryParams

  const query = generateBaseQuery(baseQueryParams)
  const computeDatasets = await queryMetadata(query, cancelToken)
  if (computeDatasets?.totalResults === 0) {
    return []
  }
  if (isSkipTransform) {
    return computeDatasets?.results
  }
  const datasets = simpleTransform(computeDatasets?.results, config)
  return datasets
}
