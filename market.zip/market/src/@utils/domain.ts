import { asyncRequest } from '@utils/requestHelper'
import {
  getDomainListAllUrl,
  postDomainCreationUrl,
  putDomainEditUrl,
  deleteDomainUrl,
  postDomainActionUrl
} from '../@utils/api'
import { DOMAIN_STATUS_CODE } from '../components/Constants'

interface domainProps {
  id: string
  domainName: string
  status: string
  lastUpdate?: string
  lastUpdateBy?: string
}

const ERROR_MESSAGE_DOMAIN_GET_ALL = 'Failed to get all domains'
const ERROR_MESSAGE_DOMAIN_ADD_NEW = 'Failed to add new domain'
const ERROR_MESSAGE_DOMAIN_EDIT = 'Failed to edit domain'
const ERROR_MESSAGE_DOMAIN_STATUS_CHANGE = 'Failed to change domain status'
const ERROR_MESSAGE_DOMAIN_DELETE = 'Failed to delete domain'

export async function getDomainListAll(
  domainName?: string,
  type?: string
): Promise<unknown> {
  return asyncRequest(
    'GET',
    getDomainListAllUrl(domainName, type),
    {},
    ERROR_MESSAGE_DOMAIN_GET_ALL
  )
}

export async function postDomainCreation(
  data: Partial<domainProps>
): Promise<unknown> {
  return asyncRequest(
    'POST',
    postDomainCreationUrl(),
    data,
    ERROR_MESSAGE_DOMAIN_ADD_NEW
  )
}

export async function putDomainEdit(
  data: Partial<domainProps>
): Promise<unknown> {
  return asyncRequest(
    'PUT',
    putDomainEditUrl(),
    data,
    ERROR_MESSAGE_DOMAIN_EDIT
  )
}

export async function putDomainAction(
  data: Pick<domainProps, 'id' | 'status'>
): Promise<unknown> {
  const action = data.status && DOMAIN_STATUS_CODE[data.status].toLowerCase()
  return asyncRequest(
    'POST',
    postDomainActionUrl(data.id, action),
    {},
    ERROR_MESSAGE_DOMAIN_STATUS_CHANGE
  )
}

export async function deleteDomain(id: string): Promise<unknown> {
  return asyncRequest(
    'DELETE',
    deleteDomainUrl(id),
    {},
    ERROR_MESSAGE_DOMAIN_DELETE
  )
}
