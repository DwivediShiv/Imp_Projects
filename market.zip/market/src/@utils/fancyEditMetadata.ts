import { computeOptionsPresets } from '@components/Publish/_constants'
import { Datatoken, LoggerInstance } from '@oceanprotocol/lib'
import {
  FormPublishData,
  FormPublishService
} from 'src/components/Publish/_types'
import {
  fancyConvertSecondsToTimeoutOfDurationType,
  fancyEstimateOldAssetDurationType,
  getServiceByName
} from './ddo'
import { decodeTokenURI, NftMetadata } from './nft'
import { ServiceExtended } from 'src/@types/ServiceExtended'
import { sampleFileInfo } from './fancySampleFileCheck'
import { getOceanConfig } from './ocean'
import { SAMPLE_TYPE_UPLOAD, SAMPLE_TYPE_URL } from './constants'
import { checkIsGoogleDriveUrl } from './fancyValidation'
import { Signer } from 'ethers'
import { UNLIMITED_TIMEOUT_TYPE } from '@components/@shared/fancy/FancyAssetValidityInput/constant'

function getAccess(isAlgorithm: boolean, isCompute: boolean) {
  if (isAlgorithm) {
    return isCompute ? 'Private' : 'Public'
  }
  return isCompute ? 'Compute' : 'Download'
}

function fancyMapAlgoComputeOption(language: string) {
  if (language === '') return

  const dockerImage = computeOptionsPresets.find(
    (option) => option.name === language
  )
  return dockerImage?.name || 'custom'
}

export function getPriceType(type: string) {
  switch (type?.toLowerCase()) {
    case 'free':
      return 'Free'
    case 'payperbyte':
    case 'setprice':
      return 'Post-pay'
    default:
      return ''
  }
}

export function mapPriceValues(accessDetails: AccessDetails) {
  return {
    type: getPriceType(accessDetails?.type),
    price: parseInt(accessDetails?.price),
    baseToken: accessDetails.baseToken
  } as PriceOptions
}

export async function fancyTransformDDOToPublishForm(
  asset: AssetExtended,
  signer: Signer
): Promise<FormPublishData> {
  LoggerInstance.log('Transforming this DDO=>', asset)
  const theService =
    getServiceByName(asset, 'access') || getServiceByName(asset, 'compute')
  const assetService = asset.services[0] as unknown as ServiceExtended
  let access
  switch (asset.services[0].type) {
    case 'access':
      access = asset.metadata.type === 'dataset' ? 'Download' : 'Public'
      break
    case 'compute':
      access = asset.metadata.type === 'dataset' ? 'Compute' : 'Private'
      break
  }

  const didsOfPublisherTrustedAlgorithms =
    asset.services[0]?.compute?.publisherTrustedAlgorithms?.map(
      (values) => values.did
    )

  const user = {
    accountId: asset.nft.owner,
    chainId: asset.chainId,
    stepCurrent: 5
  }

  const setNftMetadata = decodeTokenURI(asset.nft.tokenURI)
  const config = getOceanConfig(asset.chainId)
  const referenceUrlResponse =
    asset.metadata.algorithm?.container?.referenceUrl &&
    (await sampleFileInfo(
      asset.metadata.algorithm?.container?.referenceUrl,
      config?.encryptionProviderUri
    ))

  const metadata: any = {
    nft: {
      name: asset.nft.name,
      symbol: asset.nft.symbol,
      description: setNftMetadata.description,
      external_url: null,
      background_color: null,
      image_data: setNftMetadata.image_data
    } as NftMetadata,
    type: asset.metadata.type,
    name: asset.metadata.name,
    description: asset.metadata.description,
    author: asset.metadata.author, // not using
    tags: asset.metadata.tags || [],
    category: asset.metadata.categories[0],
    additionalInformation: {
      source: asset.metadata.additionalInformation?.source
    },
    ...(asset.metadata.type === 'algorithm' && {
      dockerImage: fancyMapAlgoComputeOption(
        asset.metadata.algorithm?.language
      ),
      dockerImageCustom:
        asset.metadata.algorithm?.container?.image +
        `${
          asset.metadata.algorithm?.container?.tag &&
          `:${asset.metadata.algorithm?.container?.tag}`
        }`,
      dockerImageCustomTag: asset.metadata.algorithm?.container?.tag,
      dockerImageCustomEntrypoint:
        asset.metadata.algorithm?.container?.entrypoint,
      dockerImageCustomChecksum: asset.metadata.algorithm?.container?.checksum,
      dockerImageCustomReferenceUrl:
        asset.metadata.algorithm?.container?.referenceUrl,
      isDockerImageCustomReferenceUrlValid: asset.metadata.algorithm?.container
        ?.referenceUrl
        ? !!referenceUrlResponse
        : true
    })
  }
  const timeoutDurationType =
    theService?.additionalInformation?.timeoutDurationType ||
    fancyEstimateOldAssetDurationType(theService?.timeout)

  const services: FormPublishService[] = [
    {
      files: [
        {
          url: theService?.files as any,
          valid: true
        }
      ],
      // links: null, // Acentrik sample file is stored in `services.additionalInformation`
      timeout:
        timeoutDurationType === UNLIMITED_TIMEOUT_TYPE
          ? ''
          : fancyConvertSecondsToTimeoutOfDurationType(
              theService?.timeout,
              timeoutDurationType
            ),
      description: theService.description,
      dataTokenOptions: {
        name: asset.datatokens[0]?.name || asset.accessDetails?.datatoken?.name,
        symbol:
          asset.datatokens[0]?.symbol || asset.accessDetails?.datatoken?.symbol
      },
      access,
      providerUrl: {
        url: theService.serviceEndpoint,
        valid: true
      },
      ...(access.toLowerCase() === 'compute' && {
        computeOptions: {
          ...asset.services[0]?.compute,
          publisherTrustedAlgorithms: didsOfPublisherTrustedAlgorithms as any
        }
      }),
      ...(asset.metadata.type === 'dataset'
        ? {
            aggregateOnly: asset.metadata.additionalInformation?.aggregateC2D
              ? 'Enable'
              : 'Disable'
          }
        : {
            algorithmType: asset.metadata.additionalInformation?.algorithmType
          }),
      consumerParameters: assetService?.consumerParameters
    }
  ]

  const datatokenInstance = new Datatoken(signer)
  const dtAddress = asset?.datatokens[0]?.address
  const paymentCollector = await datatokenInstance.getPaymentCollector(
    dtAddress
  )
  // Pricing is for display only
  const pricing: PriceOptions = {
    price: Number(asset.accessDetails?.price),
    baseToken: asset.accessDetails?.baseToken,
    type: getPriceType(asset.accessDetails?.type),
    freeAgreement: false
  }

  const linksResponse =
    assetService.additionalInformation?.links?.[0]?.url &&
    !checkIsGoogleDriveUrl(
      asset.metadata.additionalInformation?.links?.[0]?.url
    ) &&
    (await sampleFileInfo(
      assetService.additionalInformation?.links?.[0]?.url,
      config?.encryptionProviderUri
    ))

  const eulaResponse =
    asset.metadata.additionalInformation?.eula?.[0]?.url &&
    !checkIsGoogleDriveUrl(
      asset.metadata.additionalInformation?.eula?.[0].url
    ) &&
    (await sampleFileInfo(
      asset.metadata.additionalInformation?.eula?.[0]?.url,
      config?.encryptionProviderUri
    ))

  const publishForm = {
    user,
    metadata,
    services,
    pricing,
    timeoutDurationType: timeoutDurationType,
    sampleType: assetService.additionalInformation?.sampleType,
    links:
      assetService.additionalInformation?.sampleType === SAMPLE_TYPE_URL
        ? assetService.additionalInformation?.links?.[0]?.url
        : '',
    isLinksValid:
      assetService.additionalInformation?.sampleType !== SAMPLE_TYPE_UPLOAD
        ? assetService.additionalInformation?.links?.[0]?.url
          ? !!linksResponse
          : true
        : true,
    isExperimental: assetService.additionalInformation?.isExperimental
      ? 'Experimental'
      : 'Production',
    input:
      asset.metadata.type === 'algorithm'
        ? assetService.additionalInformation?.input?.fileType
        : '',
    output:
      asset.metadata.type === 'algorithm'
        ? assetService.additionalInformation?.output?.fileType
        : '',
    ...(assetService.additionalInformation?.output?.screenshot && {
      sampleUpload: [
        {
          preview: assetService.additionalInformation?.output?.screenshot,
          contentType: 'ipfs',
          url: null
        }
      ]
    }),
    eula: asset.metadata.additionalInformation?.eula?.[0]?.url || '',
    isEulaValid: asset.metadata.additionalInformation?.eula?.[0]?.url
      ? !!eulaResponse
      : true,
    baseToken: asset.accessDetails?.baseToken?.symbol,
    paymentCollector: paymentCollector || undefined,
    ...(assetService.additionalInformation?.sampleType === SAMPLE_TYPE_UPLOAD &&
      assetService.additionalInformation?.links?.length > 0 && {
        linksUpload: assetService.additionalInformation?.links
      }),
    ...(access.toLowerCase() === 'compute' && {
      pendingAcknowledgeTrustedAlgorithms: [],
      acknowledgedTrustedAlgorithms: []
    })
  } as FormPublishData
  LoggerInstance.log('Transformed DDO => FormPublishData', publishForm)
  return publishForm
}

// export function transformDDOToMetadataPublishForm(
//   ddo: DDO,
//   fileMetadata?: FileMetadata // Optional: sneak in value from provider, preview on `Edit Details` side preview
// ): MetadataPublishForm {
//   const { metadata: metadataService } = ddo
//   const service = ddo.services[0]
//   const isCompute = getServiceByName(ddo, 'compute')
//   const isAlgorithm = metadataService.type === 'algorithm'
//   const { additionalInformation } = metadataService

// const data: MetadataPublishForm = {
//   providerName: isCompute
//     ? getServiceByName(ddo, 'compute').serviceEndpoint
//     : getServiceByName(ddo, 'access').serviceEndpoint,
//   name: metadataService.name,
//   description: additionalInformation.description,
//   files: [
//     {
//       url: metadataService.attributes.encryptedFiles,
//       contentType: fileMetadata?.contentType || service.files[0].contentType,
//       contentLength:
//         fileMetadata?.contentLength ||
//         metadataService.attributes.main.files[0].contentLength
//     }
//   ],
//   author: metadataService.attributes.main.author,
//   dataTokenOptions: {
//     cap: ddo.dataTokenInfo.cap.toString(),
//     name: ddo.dataTokenInfo.name,
//     symbol: ddo.dataTokenInfo.symbol
//   },
//   asset: isAlgorithm ? 'Algorithm' : 'Dataset',
//   algo: metadataService.attributes.main?.algorithm?.language,
//   access: getAccess(isAlgorithm, Boolean(isCompute)),
//   allowAllPublishedAlgorithms: false,
//   isExperimental: additionalInformation?.isExperimental
//     ? 'Experimental'
//     : 'Production',
//   termsAndConditions: additionalInformation.termsAndConditions,
//   timeout: isCompute
//     ? secondsToString(
//         getServiceByName(ddo, 'compute').attributes.main.timeout,
//         true
//       )
//     : secondsToString(
//         getServiceByName(ddo, 'access').attributes.main.timeout,
//         true
//       ),
//   category:
//     additionalInformation?.categories && additionalInformation?.categories[0],
//   tags: additionalInformation?.tags || [],
//   links: additionalInformation?.links || '',
//   image: isAlgorithm
//     ? metadataService.attributes.main?.algorithm?.container?.image
//     : '',
//   containerTag: isAlgorithm
//     ? metadataService.attributes.main?.algorithm?.container?.tag
//     : '',
//   entrypoint: isAlgorithm
//     ? metadataService.attributes.main?.algorithm?.container?.entrypoint
//     : '',
//   sampleType: additionalInformation?.sampleType || 'URL',
//   sampleUpload: additionalInformation?.output?.screenshot
//     ? [
//         {
//           preview: additionalInformation?.output?.screenshot,
//           contentType: 'ipfs'
//         }
//       ]
//     : [],
//   shortDescription: additionalInformation?.shortDescription,
//   input: additionalInformation?.input?.fileType || '',
//   output: additionalInformation?.output?.fileType || '',
//   publisherTrustedAlgorithms:
//     getServiceByName(
//       ddo,
//       'compute'
//     )?.attributes?.main?.privacy?.publisherTrustedAlgorithms.map(
//       (algo) => algo.did
//     ) || [],
//   eulaType: additionalInformation?.eulaType || 'URL',
//   eula: additionalInformation?.eula || ''
// }
//   return null // data
// }

// export function transformFancyEditFormToDDO(
//   {
//     asset,
//     tags,
//     isExperimental,
//     category,
//     shortDescription,
//     sampleType,
//     input,
//     output,
//     sampleUpload,
//     eulaType,
//     eula
//   }: Partial<MetadataPublishForm>,
//   ddo?: DDO,
//   fileMetadata?: FileMetadata // Optional: sneak in value from provider to updateDDO (Edit Details)
// ): DDO {
// const additionalInformation = ddo.metadata
//   .additionalInformation as unknown as AdditionalInformationMarket
// const newAdditionalInformation = {
//   ...additionalInformation,
//   tags,
//   isExperimental: isExperimental === 'Experimental',
//   categories: [category],
//   shortDescription,
//   sampleType,
//   input: {
//     fileType: asset === 'algorithm' ? input : '',
//     screenshot: ''
//   },
//   output: {
//     fileType: asset === 'algorithm' ? output : '',
//     screenshot: convertSampleUpload(sampleUpload)
//   },
//   eulaType,
//   eula
// }

// for (let i = 0; i < ddo.service.length; i++) {
//   if (ddo.service[i].type === 'metadata') {
//     ddo.service[i].attributes.additionalInformation = newAdditionalInformation
//     if (fileMetadata) {
//       ddo.service[i].attributes.main.files[0].contentLength =
//         fileMetadata.contentLength
//       ddo.service[i].attributes.main.files[0].contentType =
//         fileMetadata.contentType
//     }
//   }
// }
//   return ddo
// }
