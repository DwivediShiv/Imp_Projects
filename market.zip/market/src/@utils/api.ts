/* eslint-disable @typescript-eslint/no-explicit-any */
import appConfig from '../../app.config'
const usrMngApiDomain = (appConfig.isOrgEnabled && 'org') || 'admin'
function appendSortByAndOrder(url: string, sortBy: string, sortOrder: string) {
  const sortExpression = []
  if (sortBy) {
    sortExpression.push(`&sortBy=${sortBy}`)
  }
  if (sortOrder) {
    sortExpression.push(`&sortOrder=${sortOrder}`)
  }
  return url + sortExpression.join('')
}

function appendCountryFilter(url: string, country: string) {
  let expression = ''
  if (country) {
    expression = `&country=${country}`
  }
  return url + expression
}

// provider-management url
export function getProviderListUrl(networkName: any): string {
  return `${appConfig.api}/provider-management/api/v1/providers?network=${networkName}&active=1`
}
export function getOrgProviderListUrl(networkName: any): string {
  return `${appConfig.api}/provider-management/api/v1/org-providers?network=${networkName}&active=true`
}

export function getOrganisationListUrl(): string {
  return `${appConfig.api}/user-management/api/v1/org/list`
}

// account-management url
export function getDecentralizedStorageHistoryUrl(
  accountAddress: string
): string {
  return `${appConfig.api}/account-management/api/v1/accounts/${accountAddress}/ipfs-uploads`
}

export function postIPFSUploadUrl(accountId: string): string {
  return `${appConfig.api}/account-management/api/v1/accounts/${accountId}/ipfs-uploads`
}

// user-management service URL
export function putLoginUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/login`
}

// user-management service URL
export function getUserOrgInfo(email): string {
  return `${appConfig.api}/user-management/api/v1/org/info/${email}`
}

// resend otp URL
export function resendOtpUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/resendOtp`
}

// Check Abstract Account
export function checkAbstract() {
  return `${appConfig.api}/user-management/api/v1/org/isAbstract`
}

// Check Abstract Account
export function getInstanceDetailsURL() {
  return `${appConfig.api}/user-management/api/v1/as/instance-details`
}

// Paymaster API pending from Backend
export function fetchPaymasterData() {
  return true
  // return `${appConfig.api}/user-management/api/v1/org/paymaster`
}

export function postRequestResetPasswordUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/send-reset-email`
}

export function postResetPasswordUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/reset-password`
}

export function postSignupUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/register`
}

export function getEmailDomainUrl(email: string): any {
  return `${appConfig.api}/user-management/api/v1/as/domains/email/${email}`
}

export function getCanWalletConnectUrl(accountId: string): string {
  return `${appConfig.api}/user-management/api/v1/${usrMngApiDomain}/wallets/${accountId}/can-connect`
}

export function postAuthenticationUrl(): string {
  return `${appConfig.api}/user-management/api/v1/auth/access-token`
}

export function getUserWalletInfoUrl(): string {
  return `${appConfig.api}/user-management/api/v1/users/wallets`
}

export function putAddUserWalletUrl(accountId: string): string {
  return `${appConfig.api}/user-management/api/v1/users/wallets/${accountId}`
}

export function putOrgAddUserWalletUrl(accountId: string): string {
  return `${appConfig.api}/user-management/api/v1/org/wallets/${accountId}`
}

export function putChangePasswordUrl(): string {
  return `${appConfig.api}/user-management/api/v1/users/change-password`
}

export function getUserProfileUrl(): string {
  return `${appConfig.api}/user-management/api/v1/users/company`
}

export function getWalletCanConnect(accountId: string): string {
  return `${appConfig.api}/user-management/api/v1/users/wallets/can-connect/${accountId}`
}

export function postContactProviderUrl() {
  return `${appConfig.api}/user-management/api/v1/as/contacts/provider`
}

// Get invited user current state stored in db
export function getInvitedUserStateUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/invited/user-state`
}

// Get invited user current state stored in db
export function putSsoUserDetailsUrl(): string {
  return `${appConfig.api}/user-management/api/v1/sso/user/update-details`
}

// User accept invitation, user entry in keycloak
export function postAcceptUserInvitationUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/accept-invitation`
}

/** start domain api */
export function getUserListUrl(
  page?: number,
  email?: string,
  sortBy?: string,
  sortOrder?: string,
  filterCountry?: string,
  state?: string,
  role?: string
): string {
  let url = `${appConfig.api}/user-management/api/v1/as/user-list?page=${
    page || '1'
  }&email=${email || ''}&state=${state || ''}&roles=${role || ''}`

  url = appendSortByAndOrder(url, sortBy, sortOrder)
  url = appendCountryFilter(url, filterCountry)

  return url
}

export function getExportUserUrl(
  email?: string,
  roles?: string,
  country?: string,
  status?: string,
  sortBy?: string,
  sortOrder?: string
): string {
  let url = `${appConfig.api}/user-management/api/v1/as/user-list/export?email=${email}&roles=${roles}&status=${status}`
  url = appendCountryFilter(url, country)
  url = appendSortByAndOrder(url, sortBy, sortOrder)

  return url
}

export function getAllRolesUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/roles`
}

// remove after generic api to assign role by type pass
// export function getAllOrgRolesUrl(): string {
//   return `${appConfig.api}/user-management/api/v1/org/roles`
// }

export function getUserRolesUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/users/profile/${id}/roles`
}

// remove after assign role to wallet matching getProfileRoleUrl
// export function getOrgProfileUserUrl(id: string): string {
//   return `${appConfig.api}/user-management/api/v1/org/profile/${id}/roles`
// }

export function getOrgUserRolesUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/as/users/${id}/roles`
}

export function getProfileRoleUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/${usrMngApiDomain}/profile/${id}/roles`
}

export function postUserRolesUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/admin/users/${id}/roles`
}

export function postOrgUserRolesUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/as/users/${id}/roles`
}

export function deleteUserRolesUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/as/users/${id}/roles`
}

export function updateActiveStateUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/as/users/update-state/${id}`
}

export function getDeleteUserUrl(email: string) {
  return `${appConfig.api}/user-management/api/v1/as/user-list/delete-user/${email}`
}

export function getUserInfoUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/users/${id}`
}

export function getOrgUserInfoUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/as/users/${id}`
}
export function roleToggleApI(role: string, profileId: string): string {
  return `${appConfig.api}/user-management/api/v1/as/users/${role}/${profileId}`
}

// Edit org user details
export function putOrgUserInfoUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/org/users/${id}`
}

export function putUserInfoUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/users/${id}`
}

export function getDomainListAllUrl(
  domainName?: string,
  type?: string
): string {
  return `${appConfig.api}/user-management/api/v1/admin/domains?name=${
    domainName || ''
  }&type=${type || ''}`
}

export function postDomainCreationUrl(): string {
  return `${appConfig.api}/user-management/api/v1/admin/domains`
}

export function putDomainEditUrl(): string {
  return `${appConfig.api}/user-management/api/v1/admin/domains`
}

export function deleteDomainUrl(id: string): string {
  return `${appConfig.api}/user-management/api/v1/admin/domains/${id}`
}

export function postDomainActionUrl(id: string, action: string): string {
  return `${appConfig.api}/user-management/api/v1/admin/domains/${id}/${action}`
}

export function getAssetFilterCriteria(): string {
  return `${appConfig.api}/user-management/api/v1/filter/asset`
}

/** end domain api */
// assets-management service URL
export function getDemandBoardListUrl(searchValue?: string): string {
  return `${appConfig.api}/asset-management/api/v1/demands?search=${
    searchValue || ''
  }`
}

export function getDemandProfileUrl(id: string): string {
  return `${appConfig.api}/asset-management/api/v1/demands/${id}`
}

export function postDemandUrl(): string {
  return `${appConfig.api}/asset-management/api/v1/demands`
}

export function getPurgatoryAssetUrl(): string {
  return `${appConfig.api}/asset-management/api/v1/purgatory/`
}

export function getPurgatoryAccountUrl(): string {
  return `${appConfig.api}/user-management/api/v1/purgatory/`
}

export function getSelectionOptionUrl(): string {
  return `${appConfig.api}/asset-management/api/v1/general/selection-option`
}

export function postFileCheckUrl(): string {
  return `${appConfig.api}/asset-management/api/v1/file/check-connectivity`
}

/** start IPFS api */
export function getIpfsFileDownloadUrl(): string {
  return `${appConfig.ipfs.gatewayUri}/custom/ipfs/`
}

export function postCustomIpfsUploadUrl(address: string): string {
  return `${appConfig.ipfs.gatewayUri}/custom/add?address=${address}`
}

export function postCustomIpfsUploadScreenshotUrl(address: string): string {
  return `${appConfig.ipfs.gatewayUri}/custom/add/screenshot?address=${address}`
}

export function postCustomIpfsUploadSampleFileAlgoUrl(address: string): string {
  return `${appConfig.ipfs.gatewayUri}/custom/add/sample-file/algorithm?address=${address}`
}

export function postCustomIpfsUploadSampleFileDatasetUrl(
  address: string
): string {
  return `${appConfig.ipfs.gatewayUri}/custom/add/sample-file/dataset?address=${address}`
}

export function postCustomIpfsUploadEulaFileUrl(): string {
  return `${appConfig.ipfs.gatewayUri}/custom/add/eula`
}

export function postUnpinFile(hash: string): string {
  return `${appConfig.ipfs.gatewayUri}/custom/unpin/${hash}`
}

export function postContactUsUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/contact-us`
}

export function inviteUsersUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/invite-user`
}
export function getOrgProfileUrl(): string {
  return `${appConfig.api}/user-management/api/v1/org/profile`
}

export function getAbstractOrgUrl(): string {
  return `${appConfig.api}/user-management/api/v1/org/abstract-profile`
}

export function getOrgListUrl(): string {
  return `${appConfig.api}/user-management/api/v1/org/list`
}

export function editOrgProfileUrl(orgID): string {
  return `${appConfig.api}/user-management/api/v1/org/profile/${orgID}`
}

export function editPaymasterDetailsUrl(orgID: string): string {
  return `${appConfig.api}/user-management/api/v1/org/${orgID}/social-details`
}

export function getPayMasterDetailsUrl(): string {
  return `${appConfig.paymentManager.url}/abstract/paymaster/details`
}

export function addSmartAccountUrl(smartAccountId): string {
  return `${appConfig.api}/user-management/api/v1/org/smartaccount/${smartAccountId}`
}
export function getC2DWalletsUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/c2d/`
}
// Paymaster Auth Token Check url
export function checkPayMasterKey(): string {
  return 'https://paymaster-dashboard-backend.prod.biconomy.io/api/v2/public/sdk/paymaster'
}

// Payment-manager API's
export function getPaymasterOwnerUrl(): string {
  return `${appConfig.paymentManager.url}/abstract/ownereoa`
}

export function getPaymasterWhitelistingUrl(): string {
  return `${appConfig.paymentManager.url}/abstract/whitelisting`
}

export function getSponsorTransactionUrl(): string {
  return `${appConfig.paymentManager.url}/abstract/sponsor/transaction`
}

export function getPaymasterValidatedUrl(): string {
  return `${appConfig.paymentManager.url}/abstract/validate`
}

export function getRequestResetSsoUrl(): string {
  return `${appConfig.api}/user-management/api/v1/as/sso/reset`
}

export function getTotalPostPaySalesRecordsUrl(): string {
  return `${appConfig.api}/provider-management/api/v1/post-pay/downloads`
}

export function postPayPerByteDownloadUrl(): string {
  return `${appConfig.api}/provider-management/api/v1/post-pay/downloads`
}

export function postPayPerByteDownloadExport(): string {
  return `${appConfig.api}/provider-management/api/v1/post-pay/export`
}
