import {
  mapDockerDetailsUrl,
  getImageAndTagFromRegistryLink
} from './fancyDocker'
import { ComputeOption } from '@components/Publish/_constants'

describe('fancyMapDockerDetailsUrl', () => {
  it('should return the correct docker image URL when found', () => {
    const computeOptions: ComputeOption[] = [
      {
        name: 'runtime1',
        value: {
          registry: 'https://registry1.com/',
          imageName: 'image1',
          entrypoint: '',
          image: 'image1',
          tag: 'latest',
          checksum: 'defaultChecksum'
        }
      },
      {
        name: 'runtime2',
        value: {
          registry: 'https://registry2.com/',
          imageName: 'image2',
          entrypoint: '',
          image: 'image2',
          tag: 'latest',
          checksum: 'defaultChecksum'
        }
      }
    ]
    const metadata = {
      image: '',
      tag: '',
      checksum: '',
      referenceUrl: ''
    }
    const runtimeEnvironment = 'runtime1'
    const result = mapDockerDetailsUrl(
      computeOptions,
      metadata,
      runtimeEnvironment
    )
    expect(result).toBe('https://registry1.com/image1')
  })

  it('should return the default docker URL when not found', () => {
    const computeOptions: ComputeOption[] = [
      {
        name: 'runtime1',
        value: {
          registry: 'https://registry1.com/',
          imageName: 'image1',
          entrypoint: '',
          image: 'image1',
          tag: 'latest',
          checksum: 'defaultChecksum'
        }
      }
    ]
    const metadata = {
      image: 'defaultImage',
      tag: 'defaultTag',
      checksum: 'defaultChecksum',
      referenceUrl: ''
    }
    const runtimeEnvironment = 'runtime2'
    const result = mapDockerDetailsUrl(
      computeOptions,
      metadata,
      runtimeEnvironment
    )
    expect(result).toBe(
      'https://hub.docker.com/layers/defaultImage/defaultTag/images/defaultChecksum'
    )
  })

  it('should return the referenceUrl docker URL when found', () => {
    const computeOptions: ComputeOption[] = [
      {
        name: 'runtime1',
        value: {
          registry: 'https://registry1.com/',
          imageName: 'image1',
          entrypoint: '',
          image: 'image1',
          tag: 'latest',
          checksum: 'defaultChecksum'
        }
      }
    ]
    const metadata = {
      image: 'defaultImage',
      tag: 'defaultTag',
      checksum: 'defaultChecksum',
      referenceUrl: 'https://defaultLink.io'
    }
    const runtimeEnvironment = 'runtime2'
    const result = mapDockerDetailsUrl(
      computeOptions,
      metadata,
      runtimeEnvironment
    )
    expect(result).toBe('https://defaultLink.io')
  })

  it('should handle missing metadata values gracefully', () => {
    const computeOptions: ComputeOption[] = [
      {
        name: 'runtime1',
        value: {
          registry: 'https://registry1.com/',
          imageName: 'image1',
          entrypoint: '',
          image: '',
          tag: '',
          checksum: ''
        }
      }
    ]
    const metadata = undefined
    const runtimeEnvironment = 'runtime2'
    const result = mapDockerDetailsUrl(
      computeOptions,
      metadata,
      runtimeEnvironment
    )
    expect(result).toBe('')
  })
})

describe('getImageAndTagFromRegistryLink function', () => {
  it('should correctly split image and tag for input with single colon', () => {
    const input = 'docker.io/library/nginx:latest'
    const result = getImageAndTagFromRegistryLink(input)
    expect(result.image).toBe('docker.io/library/nginx')
    expect(result.tag).toBe('latest')
  })

  it('should correctly split image and tag for input with multiple colons and segments', () => {
    const input =
      'public.ecr.aws/acentrik/protocol/test/path/so_many_path/algo_dockers/python:3.x-project-xxx'
    const result = getImageAndTagFromRegistryLink(input)
    expect(result.image).toBe(
      'public.ecr.aws/acentrik/protocol/test/path/so_many_path/algo_dockers/python'
    )
    expect(result.tag).toBe('3.x-project-xxx')
  })

  it('should return input as image and empty string as tag for input without colon', () => {
    const input = 'docker.io/library/nginx'
    const result = getImageAndTagFromRegistryLink(input)
    expect(result.image).toBe('docker.io/library/nginx')
    expect(result.tag).toBe('')
  })

  it('should return empty string as tag if input is an empty string', () => {
    const input = ''
    const result = getImageAndTagFromRegistryLink(input)
    expect(result.image).toBe('')
    expect(result.tag).toBe('')
  })

  it('should correctly split image and tag even if input ends with colon', () => {
    const input = 'docker.io/library/nginx:'
    const result = getImageAndTagFromRegistryLink(input)
    expect(result.image).toBe('docker.io/library/nginx')
    expect(result.tag).toBe('')
  })

  it('should correctly split image and tag for input with a single segment and tag', () => {
    const input = 'quay.io/coreos/etcd:v3.4.13'
    const result = getImageAndTagFromRegistryLink(input)
    expect(result.image).toBe('quay.io/coreos/etcd')
    expect(result.tag).toBe('v3.4.13')
  })

  it('should correctly split image and tag for input with multiple colons and segments, including multiple tags', () => {
    const input = 'docker.io/library/nginx:latest/weird:edgecase'
    const result = getImageAndTagFromRegistryLink(input)
    expect(result.image).toBe('docker.io/library/nginx:latest/weird')
    expect(result.tag).toBe('edgecase')
  })
})
