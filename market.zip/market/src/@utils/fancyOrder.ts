import { gql } from 'urql'
import { ethers } from 'ethers'

export const fancyGetValidOrderTransaction = gql`
  query FancyOrderTransaction(
    $datatoken: String
    $payer: String
    $createdTimestamp: Int
  ) {
    orders(
      orderBy: createdTimestamp
      orderDirection: desc
      where: {
        datatoken: $datatoken
        payer: $payer
        createdTimestamp_gte: $createdTimestamp
      }
    ) {
      block
      tx
    }
  }
`

export function fancyGetMockTransactionReceipt(
  transactionHash: string,
  blockNumber: number
): ethers.providers.TransactionReceipt {
  return {
    to: '',
    from: '',
    contractAddress: '',
    transactionIndex: 0,
    gasUsed: ethers.BigNumber.from('0'),
    logsBloom: '',
    blockHash: '',
    transactionHash,
    logs: [],
    blockNumber,
    confirmations: 1,
    cumulativeGasUsed: ethers.BigNumber.from('0'),
    effectiveGasPrice: ethers.BigNumber.from('0'),
    byzantium: true,
    type: null,
    status: 1 // 1 = successful, 0 = reverted/errpr
  }
}

export function fancyGenerateQueryOrderVariable(
  asset: AssetExtended,
  accountId: string,
  createdTimestamp: number
) {
  return {
    payer: accountId?.toLowerCase(),
    datatoken: asset?.accessDetails?.datatoken?.address?.toLowerCase(),
    createdTimestamp
  }
}
