import {
  fancyBroadcastMessage,
  fancyAddBroadcastListener,
  fancyRemoveBroadcastListener,
  MESSAGE_TYPES
} from './fancyBroadcastChannel'

let eventListenerAdded = false

jest.mock('./fancyBroadcastChannel', () => {
  const actual = jest.requireActual('./fancyBroadcastChannel')
  return {
    ...actual,
    fancyBroadcastMessage: jest.fn(),
    fancyAddBroadcastListener: jest.fn().mockImplementation(() => {
      eventListenerAdded = true
    }),
    fancyRemoveBroadcastListener: jest.fn().mockImplementation(() => {
      return !!eventListenerAdded
    })
  }
})

describe('fancyBroadcastMessage function', () => {
  afterEach(() => {
    jest.clearAllMocks()
  })

  it('sends a message to the channel with correct arguments', () => {
    const messageType = MESSAGE_TYPES.LOGOUT
    const data = { random: '123' }

    fancyBroadcastMessage(messageType, data)

    expect(fancyBroadcastMessage).toHaveBeenCalledWith(messageType, data)
  })

  it('sends a message to the channel with default data when no additional data provided', () => {
    const messageType = MESSAGE_TYPES.LOGOUT

    fancyBroadcastMessage(messageType)

    expect(fancyBroadcastMessage).toHaveBeenCalledWith(messageType)
  })
})

describe('fancyAddBroadcastListener and fancyRemoveBroadcastListener functions', () => {
  afterEach(() => {
    eventListenerAdded = false
    jest.clearAllMocks()
  })

  it('adds and removes event listeners from the channel with correct arguments', () => {
    const handler = jest.fn()

    fancyAddBroadcastListener('message', handler)
    expect(fancyAddBroadcastListener).toHaveBeenCalledWith('message', handler)

    fancyRemoveBroadcastListener('message', handler)

    // Verifies that fancyRemoveBroadcastListener was called with the correct arguments and returned true
    expect(fancyRemoveBroadcastListener).toHaveBeenCalledWith(
      'message',
      handler
    )
    expect(fancyRemoveBroadcastListener).toHaveReturnedWith(true)
  })

  it('does not remove event listener if not added before', () => {
    const handler = jest.fn()

    // Attempt to remove the event listener
    fancyRemoveBroadcastListener('message', handler)

    // Verifies that fancyRemoveBroadcastListener was called with the correct arguments and returned false
    expect(fancyRemoveBroadcastListener).toHaveBeenCalledWith(
      'message',
      handler
    )
    expect(fancyRemoveBroadcastListener).toHaveReturnedWith(false)
  })
})
