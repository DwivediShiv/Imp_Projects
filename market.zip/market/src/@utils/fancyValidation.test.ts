import {
  checkIsGoogleDriveUrl,
  checkIsHttpUrl,
  checkIsLocalPath,
  getPathType,
  isValidUrlSchemes
} from './fancyValidation'

// to mock on the constants since test file exsecuse before const being initialize
jest.mock('../../src/components/Publish/Constants', () => ({
  GOOGLE_DRIVE_URL_PATTERN: ['docs.google']
}))

describe('To test on validation utils', () => {
  it('should return whether the URL contain google domain', async () => {
    expect(checkIsGoogleDriveUrl('')).toBeFalsy()
    expect(checkIsGoogleDriveUrl('something.com')).toBeFalsy()
    expect(checkIsGoogleDriveUrl('docs.google')).toBeTruthy()
  })
})

describe('To test checkIsHttpUrl()', () => {
  test('should return true for valid HTTP URLs', () => {
    expect(checkIsHttpUrl('http://www.example.com')).toBe(true)
    expect(checkIsHttpUrl('http://subdomain.example.com/path')).toBe(true)
  })

  test('should return false for non-HTTP URLs', () => {
    expect(checkIsHttpUrl('https://www.example.com')).toBe(false)
    expect(checkIsHttpUrl('ftp://ftp.example.com')).toBe(false)
    expect(checkIsHttpUrl('www.example.com')).toBe(false)
  })

  test('should be case insensitive', () => {
    expect(checkIsHttpUrl('HTTP://www.example.com')).toBe(true)
    expect(checkIsHttpUrl('HtTP://www.example.com')).toBe(true)
    expect(checkIsHttpUrl('hTtP://www.example.com')).toBe(true)
  })
})

describe('To test checkIsLocalPath', () => {
  it('should return true for a local path in Unix format', () => {
    expect(checkIsLocalPath('/folder/path/file')).toBe(true)
  })

  it('should return false for an empty string', () => {
    expect(checkIsLocalPath('')).toBe(false)
  })

  it('should return false for non-string values', () => {
    expect(checkIsLocalPath(null)).toBe(false)
    expect(checkIsLocalPath(undefined)).toBe(false)
  })

  it('should return false for S3 path', () => {
    expect(checkIsLocalPath('s3://bucket/path/file')).toBe(false)
  })

  it('should return false for HTTP URL', () => {
    expect(checkIsLocalPath('https://url.com/path/file')).toBe(false)
  })

  it('should return false for a relative path', () => {
    expect(checkIsLocalPath('folder/path/file')).toBe(false)
  })
})

describe('To test checkPathType', () => {
  it('should return "localstorage" for a local path in Unix format', () => {
    expect(getPathType('/folder/path/file')).toBe('localstorage')
  })

  it('should return "s3" for an S3 path', () => {
    expect(getPathType('s3://bucket/path/file')).toBe('s3')
  })

  it('should return `url` string for HTTP URL', () => {
    expect(getPathType('https://url.com/path/file')).toBe('url')
  })

  it('should return an empty string for an empty input', () => {
    expect(getPathType('')).toBe('')
  })

  it('should return an empty string for non-string values', () => {
    expect(getPathType(null)).toBe('')
    expect(getPathType(undefined)).toBe('')
  })

  it('should return an empty string for a relative path', () => {
    expect(getPathType('folder/path/file')).toBe('')
  })
})

describe('To test isPathValid', () => {
  it('should return true for a local path in Unix format', () => {
    expect(isValidUrlSchemes('/folder/path/file')).toBe(true)
  })

  it('should return true for an S3 path', () => {
    expect(isValidUrlSchemes('s3://bucket/path/file')).toBe(true)
  })

  it('should return true for an HTTP URL', () => {
    expect(isValidUrlSchemes('https://url.com/path/file')).toBe(true)
  })

  it('should return false for an empty input', () => {
    expect(isValidUrlSchemes('')).toBe(false)
  })

  it('should return false for non-string values', () => {
    expect(isValidUrlSchemes(null)).toBe(false)
    expect(isValidUrlSchemes(undefined)).toBe(false)
    expect(isValidUrlSchemes(123 as any)).toBe(false)
    expect(isValidUrlSchemes({} as any)).toBe(false)
    expect(isValidUrlSchemes([] as any)).toBe(false)
  })

  it('should return false for a relative path', () => {
    expect(isValidUrlSchemes('folder/path/file')).toBe(false)
  })
})
