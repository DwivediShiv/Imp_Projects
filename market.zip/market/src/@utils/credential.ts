import { Credential } from '@oceanprotocol/lib'
import { cloneDeep } from 'lodash'
import { credentialTypeMap } from '@shared/FormInput/InputElement/Credential/Constant'

export interface CredentialTable {
  type: string
  value: string
  label?: string
}

export function getCredentialLabel(value: any, type: string, options: any[]) {
  if (type === 'organization') {
    if (options?.length) {
      const foundOption = options.find(
        (c) => c.name.toLowerCase() === value?.name?.toLowerCase()
      )
      return foundOption ? foundOption.name : value?.name?.toLowerCase()
    } else {
      return value?.name ? value.name.toLowerCase() : value?.toLowerCase()
    }
  }
  if (!options?.length || type !== 'country') return value.toLowerCase()
  return options.find((c) => c.key.toLowerCase() === value?.toLowerCase())?.name
}

export function getCredentialTable(
  credentials: Credential[],
  options?: any[]
): CredentialTable[] {
  if (!credentials) return []
  const credentialTable: CredentialTable[] = []
  credentials?.forEach((credential) => {
    credential?.values?.forEach((value) => {
      credentialTable.unshift({
        type: credential.type,
        value,
        label: getCredentialLabel(value, credential.type, options)
      })
    })
  })
  return credentialTable
}

export function getCredentialList(
  credential: Credential[],
  credentialType: string
): string[] {
  if (!credentialType || !credential) return []
  const credentialByType = credential.find(
    (credential) => credential.type === credentialType
  )
  return credentialByType?.values || []
}

export function generateCredential(
  credentialType: string,
  values: string[]
): Credential {
  return {
    type: credentialType,
    values
  }
}

function getCredentialIndex(
  credentials: Credential[],
  credentialType: string
): number {
  const credentialTypes = credentials
    ? credentials.map((credential) => credential.type)
    : []
  return credentialTypes.indexOf(credentialType)
}

export function removeCredential(
  credentials: Credential[],
  credentialType: string,
  removeValue: string
): Credential[] {
  if (!credentials) return []
  credentials.forEach((credential, index) => {
    if (credential.type === credentialType) {
      const values: string[] = credential?.values.filter(
        (value) => value !== removeValue
      )
      if (values?.length) {
        // this is to prevent value change side effect propagate to initialValues/ddo by address referencing
        credentials[index] = cloneDeep(credential)
        credentials[index].values = values
      } else {
        credentials.splice(index, 1)
      }
    }
  })
  return credentials
}

export function updateCredential(
  credentials: Credential[],
  credentialType: string,
  values: string[]
): Credential[] {
  const credentialIndex = getCredentialIndex(credentials, credentialType)
  if (!credentials) {
    credentials = [generateCredential(credentialType, values)]
    return credentials
  }
  if (credentialIndex === -1) {
    credentials.push(generateCredential(credentialType, values))
    return credentials
  }
  credentials[credentialIndex] = generateCredential(credentialType, values)
  return credentials
}

export function getCredentialKey(optionValue: string): string {
  let opetionKey
  for (const [key, value] of credentialTypeMap) {
    if (value === optionValue) {
      opetionKey = key
      break
    }
  }
  return opetionKey
}

export function convertToCredentialKeyArray(
  credentialValue: string[]
): string[] {
  const creddentialKeys: string[] = []
  credentialValue.forEach((value) => {
    creddentialKeys.push(getCredentialKey(value))
  })
  return creddentialKeys
}

export function isValidDomain(domain: string): boolean {
  if (!domain) return false
  const re =
    // eslint-disable-next-line security/detect-unsafe-regex
    /^(?!:\/\/)([a-zA-Z0-9-]+\.){0,5}[a-zA-Z0-9-][a-zA-Z0-9-]+\.[a-zA-Z]{2,64}?$/gi
  return re.test(domain)
}

export function filterByCredentialType(
  credentialTable: CredentialTable[],
  credentialType: string[]
): CredentialTable[] {
  if (
    !credentialTable ||
    credentialType?.length === 0 ||
    credentialType?.length === 2
  )
    return credentialTable
  let filteredData: CredentialTable[] = []
  credentialType.forEach((type) => {
    const credential = credentialTable.filter((table) => table.type === type)
    filteredData = filteredData.concat(credential)
  })
  return filteredData
}

export function search(
  credentialTable: CredentialTable[],
  searchValue: string
): CredentialTable[] {
  if (!credentialTable || !searchValue) return credentialTable
  return credentialTable.filter((table) =>
    table?.label?.toLowerCase().includes(searchValue.toLowerCase())
  )
}

export function getCredentialPlaceholder(credentialType: string): string {
  const selectedCredentialType = getCredentialKey(credentialType)
  let placeholder: string
  switch (selectedCredentialType) {
    case 'domain':
      placeholder = 'e.g. companyA.com'
      break
    default:
      break
  }
  return placeholder
}
