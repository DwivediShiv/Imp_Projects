export function getQueryStringValue(key: string) {
  const url = new URL(window.location.href)
  const value = url.searchParams.get(key)
  return value
}

export function getUrlWithoutQuery(url: string) {
  return url.split('?')[0]
}

export function removeQueryFromUrl(queryKeyList?: Array<string>): void {
  const noQueryUrl = getUrlWithoutQuery(window.location.href)
  if (!queryKeyList?.length) {
    window.history.replaceState(null, document.title, noQueryUrl)
    return
  }

  const params = new URLSearchParams(location.search)
  for (let i = 0; i < queryKeyList.length; i++) {
    if (params.has(queryKeyList[i])) params.delete(queryKeyList[i])
  }
  const paramString = params.toString()
  window.history.replaceState(
    null,
    document.title,
    paramString ? '?' + paramString : noQueryUrl
  )
}
