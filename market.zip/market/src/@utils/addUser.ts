import axios, { AxiosResponse } from 'axios'
import { inviteUsersUrl } from './api'

export async function addUser(values: object): Promise<{ status?: string }> {
  const response: AxiosResponse = await axios({
    method: 'POST',
    url: inviteUsersUrl(),
    data: {
      ...values
    }
  })
  return response.data
}
