export function pushIfNotExist(list: any[], item: any, key?: string) {
  const data = key ? item[key] : item
  list.indexOf(data) === -1 && list.push(data)
}
