import axios from 'axios'
import isUrl from 'is-url-superb'
import {
  MetadataMarket,
  MetadataPublishForm,
  MetadataPublishFormAlgorithm
} from 'src/@types/MetaData'
import { toStringNoMS } from '.'
import slugify from '@sindresorhus/slugify'
import { computeOptionsPresets } from '@components/Publish/_constants'
import { DDO, MetadataAlgorithm, LoggerInstance } from '@oceanprotocol/lib'
import { FormFieldProps } from 'src/@types/Form'
import BigNumber from 'bignumber.js'
import fancyToast from '@shared/fancy/atoms/Toast/FancyToast'
import { getInMemoryDockerImage, setInMemoryDockerImage } from './fancyAppData'

import { customization } from '../../app.config'
import { CUSTOM_IMAGE_NAME } from '../components/Publish/Constants'
interface DockerImage {
  image: string
  tag: string
}

export function transformTags(value: string | string[]): string[] {
  if (typeof value !== 'string') {
    return value
  }
  const originalTags = value?.split(',')
  const transformedTags = originalTags?.map((tag) => slugify(tag).toLowerCase())
  return transformedTags
}

export function generateAlgoForm(
  algoType: string,
  access: string,
  asset: string,
  image?: string,
  containerTag?: string,
  entrypoint?: string
): MetadataAlgorithm {
  const isCustom = algoType === CUSTOM_IMAGE_NAME
  const emptyCustomAlgo: MetadataAlgorithm = {
    language: algoType,
    container: {
      entrypoint: '',
      image: '',
      tag: '',
      checksum: ''
    }
  }

  if (asset !== 'Algorithm') {
    return undefined
  }
  const selectedComputeOption = computeOptionsPresets.find(
    (option) => option.name === algoType
  )
  if (
    selectedComputeOption === undefined &&
    (!image || !containerTag || !entrypoint)
  ) {
    return isCustom ? emptyCustomAlgo : undefined
  }
  const selectedAlgoName = isCustom ? algoType : selectedComputeOption?.name
  const metadataAlgorithm: MetadataAlgorithm = {
    language: selectedAlgoName,
    // format: 'docker-image', // Kris: TODO not found in ocean.js interface ? need double checky if important
    version: '0.1',
    container: {
      entrypoint: isCustom
        ? entrypoint
        : selectedComputeOption.value.entrypoint,
      image: isCustom ? image : selectedComputeOption.value.image,
      tag: isCustom ? containerTag : selectedComputeOption.value.tag,
      checksum: ''
    }
  }
  return metadataAlgorithm
}

function numberEnding(number: number): string {
  return number > 1 ? 's' : ''
}

export function convertSecondsToUnit(numberOfSeconds: number) {
  if (!numberOfSeconds || numberOfSeconds === 0) return [0, 'Unlimited Period']

  const years = Math.floor(numberOfSeconds / 31536000)
  const months = Math.floor((numberOfSeconds %= 31536000) / 2630000)
  const weeks = Math.floor((numberOfSeconds %= 2630000) / 604800)
  const days = Math.floor((numberOfSeconds %= 604800) / 86400)
  const hours = Math.floor((numberOfSeconds %= 86400) / 3600)
  const minutes = Math.floor((numberOfSeconds %= 3600) / 60)
  const seconds = numberOfSeconds % 60
  const result = years
    ? [years, `year(s)`]
    : months
    ? [months, `month(s)`]
    : weeks
    ? [weeks, `week(s)`]
    : days
    ? [days, `day(s)`]
    : hours
    ? [hours, `hour(s)`]
    : minutes
    ? [minutes, `minute(s)`]
    : seconds >= 1
    ? [seconds, `second(s)`]
    : [numberOfSeconds, 'less than a second']
  return result
}

export function secondsToString(
  numberOfSeconds: number,
  isEdit?: boolean
): string {
  if (!numberOfSeconds && numberOfSeconds !== 0) return ''
  const [value, unit] = convertSecondsToUnit(numberOfSeconds)

  if (value === 0) return `${unit}`

  return unit === 'less than a second'
    ? unit
    : isEdit
    ? `${value} ${unit[0] + unit.toString().substring(1)}`
    : `${value} ${unit}`
}

export function checkIfTimeoutInPredefinedValues(
  timeout: string,
  timeoutOptions: string[]
): boolean {
  if (timeoutOptions.indexOf(timeout) > -1) {
    return true
  }
  return false
}

function getAlgorithmComponent(
  image: string,
  containerTag: string,
  entrypoint: string,
  algorithmLanguace: string
): MetadataAlgorithm {
  return {
    language: algorithmLanguace,
    // format: 'docker-image', // Kris: TODO not found in ocean.js interface ? need double checky if important
    version: '0.1',
    container: {
      entrypoint,
      image,
      tag: containerTag,
      checksum: ''
    }
  }
}

function getAlgorithmFileExtension(fileUrl: string): string {
  const splitedFileUrl = fileUrl.split('.')
  return splitedFileUrl[splitedFileUrl.length - 1]
}

export function getServiceType(access: string) {
  switch (access) {
    case 'Download':
      return 'access'
    case 'Compute':
      return 'compute'
    case 'Public':
      return 'access'
    case 'Private':
      return 'compute'
  }
}

export function convertSampleUpload(sampleScreenshot) {
  return Array.isArray(sampleScreenshot) ? '' : sampleScreenshot
}

export function transformPublishFormToMetadata(
  {
    name,
    author,
    description,
    tags,
    sampleType,
    links,
    files,
    timeout,
    access,
    asset,
    algo,
    isExperimental,
    image,
    containerTag,
    entrypoint,
    category,
    shortDescription,
    input,
    output,
    sampleUpload,
    eula
  }: Partial<MetadataPublishForm>,
  ddo?: DDO
): MetadataMarket {
  const currentTime = toStringNoMS(new Date())

  const algorithm = generateAlgoForm(
    algo,
    access,
    asset,
    image,
    containerTag,
    entrypoint
  )
  // const metadata: MetadataMarket = {
  // main: {
  //   ...AssetModel.main,
  //   type: asset === 'Algorithm' ? 'algorithm' : 'dataset',
  //   name,
  //   author,
  //   dateCreated: ddo ? ddo?.proof?.created : currentTime,
  //   datePublished: ddo ? ddo.created : currentTime,
  //   files: typeof files !== 'string' && files,
  //   license: 'https://acentrik.io/terms',
  //   algorithm: algorithm
  // },
  // additionalInformation: {
  //   ...AssetModel.additionalInformation,
  //   description,
  //   categories: [category],
  //   tags,
  //   sampleType,
  //   links: typeof links !== 'string' ? links : [],
  //   termsAndConditions,
  //   isExperimental: isExperimental === 'Experimental',
  //   shortDescription,
  //   input: {
  //     fileType: asset === 'Algorithm' ? input : ''
  //   },
  //   output: {
  //     fileType: asset === 'Algorithm' ? output : '',
  //     screenshot: convertSampleUpload(sampleUpload)
  //   },
  //   eulaType,
  //   eula: typeof eula !== 'string' ? eula : []
  // }
  // }

  // return metadata
  return null
}

async function isDockerHubImageValid(
  image: string,
  tag: string
): Promise<string> {
  try {
    const inMemoryValue: DockerImage = getInMemoryDockerImage(`${image}_${tag}`)
    if (inMemoryValue) {
      return image
    } else {
      const reqeustBody: DockerImage = {
        image,
        tag
      }

      const response = await axios.post(
        `https://dockerhub-proxy.oceanprotocol.com`,
        reqeustBody
      )

      if (
        !response ||
        response.status !== 200 ||
        response.data.status !== 'success'
      ) {
        return
      }
      setInMemoryDockerImage(`${image}_${tag}`, reqeustBody)
      return image
    }
  } catch (error) {
    LoggerInstance.error(error.message)
  }
}

export function generateComputePrivacy() {
  // Kris: TODO bring back `ServiceComputePrivacy` type inferface
  const computePrivacy: any = {
    // ServiceComputePrivacy = {
    allowRawAlgorithm: false,
    allowAllPublishedAlgorithms: false,
    allowNetworkAccess: false,
    publisherTrustedAlgorithms: []
  }
  return computePrivacy
}

export function filterFormContent(
  formField: FormFieldProps[],
  excludeFields: string[]
): FormFieldProps[] {
  return formField.filter((data) => excludeFields.indexOf(data.name) === -1)
}

export function replaceJSONContentVariable(
  JSONString: string,
  replacementVariable: any
): string {
  const result = JSONString.replace(/\{\{(.*?)\}\}/g, () => {
    return replacementVariable
  })

  return result
}

export const timeoutMap: Map<string, number> = new Map([
  ['Unlimited Period', 0],
  ['15 Minutes', 900],
  ['1 Day', 86400],
  ['1 Week', 604800],
  ['1 Month', 2630000],
  ['1 Year', 31556952]
])

async function is3rdPartyImageValid(imageURL: string): Promise<string> {
  try {
    const response = await axios.head(imageURL)
    if (!response || response.status !== 200) {
      return
    }
    return imageURL
  } catch (error) {
    LoggerInstance.error(error.message)
  }
}

export async function validateDockerImage(
  dockerImage: string,
  tag: string,
  entrypoint: string
): Promise<string> {
  let isValid
  if (customization?.isDisableCustomDockerValidation === 'true') {
    return isUrl(dockerImage) ? dockerImage : undefined
  } else {
    isValid =
      tag && entrypoint
        ? isUrl(dockerImage)
          ? await is3rdPartyImageValid(dockerImage)
          : await isDockerHubImageValid(dockerImage, tag)
        : undefined
    return isValid
  }
}

export function transformPublishAlgorithmFormToMetadata(
  {
    name,
    author,
    description,
    tags,
    dockerImage,
    image,
    containerTag,
    entrypoint,
    termsAndConditions,
    files
  }: Partial<MetadataPublishFormAlgorithm>,
  ddo?: DDO
): MetadataMarket {
  const currentTime = toStringNoMS(new Date())
  const fileUrl = typeof files !== 'string' && files[0].url
  const algorithmLanguage = getAlgorithmFileExtension(fileUrl)
  const algorithm = getAlgorithmComponent(
    image,
    containerTag,
    entrypoint,
    algorithmLanguage
  )
  // const metadata: MetadataMarket = {
  //   main: {
  //     ...AssetModel.main,
  //     name,
  //     type: 'algorithm',
  //     author,
  //     dateCreated: ddo ? ddo.created : currentTime,
  //     files: typeof files !== 'string' && files,
  //     license: 'https://acentrik.io/terms',
  //     algorithm: algorithm
  //   },
  //   additionalInformation: {
  //     ...AssetModel.additionalInformation,
  //     description,
  //     tags: transformTags(tags),
  //     termsAndConditions
  //   }
  // }

  // return metadata
  return null
}

function idToName(id: number): string {
  switch (id) {
    case 1:
      return 'eth'
    case 137:
      return 'polygon'
    case 3:
      return 'ropsten'
    case 4:
      return 'rinkeby'
    case 5:
      return 'goerli'
    case 11155111:
      return 'sepolia'
    case 1287:
      return 'moonbase'
    default:
      return 'eth'
  }
}

export function mapChainIdsToNetworkNames(chainIds: number[]): string[] {
  const networkNames: string[] = []
  for (let i = 0; i < chainIds.length; i++) {
    const networkName = idToName(chainIds[i])
    networkNames.push(networkName)
  }
  return networkNames
}

export function getRemainingTimeout(timeout: number, datePurchase): number {
  if (secondsToString(timeout) === 'Unlimited Period') {
    return 9999999999
  }
  const expiry = new BigNumber(datePurchase).plus(timeout)
  const unixTime = new BigNumber(Math.floor(Date.now() / 1000))
  const remaining = expiry.minus(unixTime).toNumber()
  return remaining
}

export function checkIsExpired(timeout: number, datePurchase) {
  if (!timeout) {
    return false
  }
  const expiry = new BigNumber(datePurchase).plus(timeout)
  const unixTime = new BigNumber(Math.floor(Date.now() / 1000))
  const isExpired = unixTime.isGreaterThan(expiry)
  return isExpired
}
