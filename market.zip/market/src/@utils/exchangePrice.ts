import { ProfileAssets } from './fancyProfileData'

export function sortFreErrorAbove(
  assets?: ProfileAssets[],
  assetFre?: any
): any {
  return [
    ...assets.filter((asset) => {
      return assetFre[asset.id]
    }),
    ...assets.filter((asset) => {
      return !assetFre[asset.id]
    })
  ]
}
