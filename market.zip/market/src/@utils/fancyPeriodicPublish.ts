import { Aquarius } from '@oceanprotocol/lib'
import { FormPublishData } from 'src/components/Publish/_types'
import { FancyConfig } from 'src/models/FancyConfig'
import { gql } from 'urql'
import { sleep } from '.'
import { fetchDataForMultipleChains } from './subgraph'

export const fancyTokensTransactionQuery = gql`
  query FancyTokensQuery(
    $publisherAddress: String!
    $symbol: String
    $name: String
    $createdTimestamp: Int
  ) {
    tokens(
      where: {
        minter_contains: [$publisherAddress]
        symbol: $symbol
        name: $name
        createdTimestamp_gte: $createdTimestamp
      }
    ) {
      tx
      address
      nft {
        address
      }
    }
  }
`

export function fancyGenerateQueryTokenVariable(
  accountId: string,
  dataTokenOptions: { name: string; symbol: string },
  createdTimestamp: number
) {
  return {
    publisherAddress: accountId.toLowerCase(),
    symbol: dataTokenOptions.symbol,
    name: dataTokenOptions.name,
    createdTimestamp
  }
}

export async function querySubgraphTransaction(
  values: FormPublishData,
  accountId: string,
  chainIds: number[],
  currentTimestamp: number
): Promise<{
  erc721Address: string
  datatokenAddress: string
  txHash: string
}> {
  const variables = fancyGenerateQueryTokenVariable(
    accountId,
    values.services[0]?.dataTokenOptions,
    currentTimestamp
  )
  const response = await fetchDataForMultipleChains(
    fancyTokensTransactionQuery,
    variables,
    chainIds
  )

  const token = response[0]?.tokens?.[0]
  if (token) {
    return {
      erc721Address: token?.nft?.address,
      datatokenAddress: token?.address,
      txHash: token?.tx
    }
  }

  return null
}

// query aquarius if DID exist else expecting createToken tx
export async function fancyPeriodicQuery(
  accountId: string,
  config: FancyConfig,
  setIsTransactionExpired: (boolean) => void,
  values?: FormPublishData,
  did?: string,
  signal?: AbortSignal
) {
  const cycle = config?.periodicCheckTransactionCycle
  const duration = config?.periodicCheckTransactionDuration
  const currentTime = Math.round(new Date().getTime() / 1000)

  for (let index = 1; index <= cycle; index++) {
    await sleep(duration)

    if (signal?.aborted) return null

    let response
    if (did) {
      try {
        const aquarius = new Aquarius(config.metadataCacheUri)
        response = await aquarius.resolve(did, signal)
      } catch (error) {
        console.log('[Aquarius]', error)
      }
    } else {
      response = await querySubgraphTransaction(
        values,
        accountId,
        [values.user.chainId],
        currentTime
      )
    }

    if (response) return response
  }
  setIsTransactionExpired(true)
  return null
}
