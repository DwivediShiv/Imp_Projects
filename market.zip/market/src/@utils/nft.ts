import {
  LoggerInstance,
  Asset,
  getHash,
  Nft,
  ProviderInstance,
  DDO,
  MetadataAndTokenURI,
  NftCreateData,
  Config
} from '@oceanprotocol/lib'
import { Signer, ethers } from 'ethers'
import * as randomstring from 'randomstring'
import { FancyConfig } from 'src/models/FancyConfig'
import appConfig from 'app.config'

// https://docs.opensea.io/docs/metadata-standards
export interface NftMetadata {
  name: string
  symbol: string
  description: string
  image?: string
  /* eslint-disable camelcase */
  external_url?: string
  image_data?: string
  background_color?: string
  /* eslint-enable camelcase */
}

// Saransh Note: Commenting un-used function
// function encodeSvg(svgString: string): string {
//   return svgString
//     .replace(
//       '<svg',
//       ~svgString.indexOf('xmlns')
//         ? '<svg'
//         : '<svg xmlns="http://www.w3.org/2000/svg"'
//     )
//     .replace('></path>', '/>')
//     .replace(/"/g, "'")
//     .replace(/%/g, '%25')
//     .replace(/#/g, '%23')
//     .replace(/{/g, '%7B')
//     .replace(/}/g, '%7D')
//     .replace(/</g, '%3C')
//     .replace(/>/g, '%3E')
//     .replace(/\s+/g, ' ')
// }

export function generateNftMetadata(): NftMetadata {
  const newNft: NftMetadata = {
    name: appConfig?.site?.assetManagementTokenName,
    symbol: `${
      appConfig?.site?.assetManagementTokenSymbolPrefix
    }-${randomstring.generate({
      length: 8,
      charset: 'hex',
      capitalization: 'uppercase'
    })}`,
    description: `This token represents the holder’s ability to manage the corresponding Data Asset on Acentrik Data Marketplace.`,
    // TODO: ideally this includes the final DID
    external_url: appConfig.site.baseUrl,
    background_color: appConfig.site.assetManagementTokenImageBackground,
    image_data: appConfig.site.assetManagementTokenImageUrl
  }
  return newNft
}

const tokenUriPrefix = 'data:application/json;base64,'

export function fancyGenerateNftMetadata(
  asset: Asset | DDO,
  nftMetadata: NftMetadata,
  encryptedDdo?: string,
  config?: FancyConfig,
  encryptProviderUrl?: string
): MetadataAndTokenURI {
  const metadataHash = getHash(JSON.stringify(asset))

  // add final did to external_url and asset link to description in nftMetadata before encoding
  const externalUrl = `${nftMetadata.external_url}asset/${asset.id}`
  const encodedMetadata = Buffer.from(
    JSON.stringify({
      ...nftMetadata,
      description: `${nftMetadata.description}\n\nView on Acentrik Market: ${externalUrl}`,
      external_url: externalUrl
    })
  ).toString('base64')

  // theoretically used by aquarius or provider, not implemented yet, will remain hardcoded
  const flags = ethers.utils.hexlify(2)

  const metadataAndTokenURI: MetadataAndTokenURI = {
    metaDataState: 0,
    metaDataDecryptorUrl:
      config?.encryptionProviderUri ||
      encryptProviderUrl ||
      asset.services[0].serviceEndpoint,
    metaDataDecryptorAddress: '',
    flags,
    data: encryptedDdo,
    metaDataHash: '0x' + metadataHash,
    tokenId: 1,
    tokenURI: `${tokenUriPrefix}${encodedMetadata}`,
    metadataProofs: []
  }
  return metadataAndTokenURI
}

export function generateNftCreateData(
  nftMetadata: NftMetadata,
  accountId: string,
  transferable = true
): NftCreateData {
  const encodedMetadata = Buffer.from(JSON.stringify(nftMetadata)).toString(
    'base64'
  )
  const nftCreateData: NftCreateData = {
    name: nftMetadata.name,
    symbol: nftMetadata.symbol,
    templateIndex: 1,
    tokenURI: `data:application/json;base64,${encodedMetadata}`,
    transferable,
    owner: accountId
  }

  return nftCreateData
}

export function decodeTokenURI(tokenURI: string): NftMetadata {
  if (!tokenURI) return undefined
  try {
    const nftMeta = tokenURI.includes('data:application/json')
      ? (JSON.parse(
          Buffer.from(tokenURI.replace(tokenUriPrefix, ''), 'base64').toString()
        ) as NftMetadata)
      : ({ image: tokenURI } as NftMetadata)

    return nftMeta
  } catch (error) {
    LoggerInstance.error(`[NFT] ${error.message}`)
  }
}

export async function setNftMetadata(
  asset: Asset | DDO,
  accountId: string,
  signer: Signer,
  signal: AbortSignal,
  fancyConfigEncryptionProviderUri?: string,
  metadataState = 0
): Promise<ethers.providers.TransactionReceipt> {
  const fancyEncryptionProviderUri =
    fancyConfigEncryptionProviderUri || asset.services[0].serviceEndpoint
  const encryptedDdo = await ProviderInstance.encrypt(
    asset,
    asset.chainId,
    fancyEncryptionProviderUri,
    signal
  )
  LoggerInstance.log('[setNftMetadata] Got encrypted DDO', encryptedDdo)

  const metadataHash = getHash(JSON.stringify(asset))
  const nft = new Nft(signer)

  // theoretically used by aquarius or provider, not implemented yet, will remain hardcoded
  const flags = ethers.utils.hexlify(2)

  const setMetadataTx = await nft.setMetadata(
    asset.nftAddress,
    accountId,
    metadataState,
    fancyEncryptionProviderUri,
    '',
    flags,
    encryptedDdo,
    '0x' + metadataHash
  )

  const setMetadataTxReceipt = setMetadataTx.wait()

  return setMetadataTxReceipt
}

export async function setNFTMetadataAndTokenURI(
  asset: Asset | DDO,
  accountId: string,
  signer: Signer,
  nftMetadata: NftMetadata,
  signal: AbortSignal,
  encryptedDdo?: string,
  config?: FancyConfig
): Promise<ethers.providers.TransactionReceipt> {
  encryptedDdo =
    encryptedDdo ||
    (await ProviderInstance.encrypt(
      asset,
      asset.chainId,
      config?.encryptionProviderUri || asset.services[0].serviceEndpoint,
      signal
    ))
  LoggerInstance.log(
    '[setNFTMetadataAndTokenURI] Got encrypted DDO',
    encryptedDdo
  )

  // const metadataHash = getHash(JSON.stringify(asset))

  // // add final did to external_url and asset link to description in nftMetadata before encoding
  // const externalUrl = `${nftMetadata.external_url}asset/${asset.id}`
  // const encodedMetadata = Buffer.from(
  //   JSON.stringify({
  //     ...nftMetadata,
  //     description: `${nftMetadata.description}\n\nView on Acentrik Market: ${externalUrl}`,
  //     external_url: externalUrl
  //   })
  // ).toString('base64')
  const nft = new Nft(signer, config?.chainId, config)

  // theoretically used by aquarius or provider, not implemented yet, will remain hardcoded
  // const flags = '0x02'

  // const metadataAndTokenURI: MetadataAndTokenURI = {
  //   metaDataState: 0,
  //   metaDataDecryptorUrl:
  //     config?.encryptionProviderUri || asset.services[0].serviceEndpoint,
  //   metaDataDecryptorAddress: '',
  //   flags,
  //   data: encryptedDdo,
  //   metaDataHash: '0x' + metadataHash,
  //   tokenId: 1,
  //   tokenURI: `data:application/json;base64,${encodedMetadata}`,
  //   metadataProofs: []
  // }
  const metadataAndTokenURI = fancyGenerateNftMetadata(
    asset,
    nftMetadata,
    encryptedDdo,
    config
  )

  const setMetadataAndTokenURITx = await nft.setMetadataAndTokenURI(
    asset.nftAddress,
    accountId,
    metadataAndTokenURI
  )

  const fancySetMetadataAndTokenURITxReceipt =
    await setMetadataAndTokenURITx.wait()

  return fancySetMetadataAndTokenURITxReceipt
}

export async function setNftMetadataState(
  signer: Signer,
  nftAddress: string,
  address: string,
  metadataState: number,
  config?: Config
): Promise<ethers.providers.TransactionReceipt> {
  const nft = new Nft(signer, config?.chainId, config)
  const setMetadataStateTxResponse = await nft.setMetadataState(
    nftAddress,
    address,
    metadataState
  )
  const setMetadataStateTxReceipt = setMetadataStateTxResponse.wait()
  return setMetadataStateTxReceipt
}

export async function nftSafeTransferFrom(
  signer: Signer,
  config: Config,
  nftAddress: string,
  nftOwner: string,
  nftReceiver: string
) {
  const nft = new Nft(signer, config?.chainId, config)
  const result = await nft.safeTransferNft(nftAddress, nftOwner, nftReceiver)
  return result
}
