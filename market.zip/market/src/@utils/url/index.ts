import { ABORT_TIMEOUT } from '@utils/constants'
import { asyncRequest } from '@utils/requestHelper'
import appConfig from 'app.config'
import { AxiosResponse } from 'axios'
import isUrl from 'is-url-superb'

export function sanitizeUrl(url: string) {
  const u = decodeURI(url).trim().toLowerCase()
  const isAllowedUrlScheme = u.startsWith('http://') || u.startsWith('https://')
  return isAllowedUrlScheme ? url : 'about:blank'
}

// check if the url is a google domain
export const isGoogleUrl = (url: string): boolean => {
  if (!url || !isUrl(url)) return

  const urlString = new URL(url)
  const googleUrl = urlString.hostname.endsWith('google.com')
  const isGoogleStorage = urlString.hostname.endsWith(
    'storage.cloud.google.com'
  )
  return isGoogleStorage ? false : googleUrl
}

export function getFancyWebPortalUri(path: string): string {
  if (!path) return
  switch (path) {
    case '/terms':
      return appConfig?.site?.termsAndConditionsUrl
    default:
      return appConfig?.site?.webPortalUrl
  }
}

export function isQueryParamDefined(downloadUrl: string): boolean {
  const parsedUrl = new URL(downloadUrl)
  const params = new URLSearchParams(parsedUrl.searchParams)
  const queryParams = Object.fromEntries(params.entries())
  const allDefined: boolean = Object.values(queryParams).every(
    (param) => param !== 'undefined' && param !== ''
  )
  return allDefined
}

export async function checkEndpointAvailability(
  url: string,
  signal?: AbortSignal
): Promise<boolean> {
  try {
    const response = (await asyncRequest(
      'HEAD',
      url,
      undefined,
      'Error occurred while checking endpoint availability.',
      200,
      false,
      undefined,
      undefined,
      signal,
      false,
      ABORT_TIMEOUT
    )) as AxiosResponse

    if (response?.status === 200) {
      return true
    }
  } catch (error) {
    console.error('Error occurred while checking endpoint availability:', error)
  }
  return false
}
