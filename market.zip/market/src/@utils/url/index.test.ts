import { sanitizeUrl, isGoogleUrl, isQueryParamDefined } from '.'

describe('@utils/url', () => {
  test('sanitizeUrl', () => {
    expect(sanitizeUrl('http://example.com')).toBe('http://example.com')
    expect(sanitizeUrl('https://example.com')).toBe('https://example.com')
    expect(sanitizeUrl('ftp://example.com')).toBe('about:blank')
  })
})

describe('isGoogleUrl', () => {
  it('should return true if the url is a google domain', () => {
    expect(isGoogleUrl('https://google.com')).toBe(true)
    expect(isGoogleUrl('https://drive.google.com')).toBe(true)
    expect(isGoogleUrl('https://docs.google.com')).toBe(true)
    expect(isGoogleUrl('https://sheets.google.com')).toBe(true)
    expect(isGoogleUrl('https://meet.google.com')).toBe(true)
    expect(isGoogleUrl('https://calendar.google.com')).toBe(true)
  })
  it('should return false if the url is not a google domain', () => {
    expect(isGoogleUrl('https://google.test.com')).toBe(false)
    expect(isGoogleUrl('https://drive.gloogle.com')).toBe(false)
    expect(isGoogleUrl('https://drive.google.test.com')).toBe(false)
    expect(isGoogleUrl('https://google.com.test.com')).toBe(false)
  })
})

describe('isQueryParamDefined', () => {
  it('should return true if all query parameters are defined', () => {
    const url =
      'https://v1.provider.dev.acentrik.io/api/services/download?param1=value1&param2=value2'
    expect(isQueryParamDefined(url)).toBe(true)
  })

  it('should return false if any query parameter is undefined', () => {
    const urlWithUndefined =
      'https://v1.provider.dev.acentrik.io/api/services/download?param1=value1&param2=undefined'
    expect(isQueryParamDefined(urlWithUndefined)).toBe(false)
  })

  it('should return true if there are no query parameters', () => {
    const urlWithoutParams =
      'https://v1.provider.dev.acentrik.io/api/services/download'
    expect(isQueryParamDefined(urlWithoutParams)).toBe(true)
  })

  it('should return false if any query parameter is empty', () => {
    const urlWithEmptyParam =
      'https://v1.provider.dev.acentrik.io/api/services/download?param1=&param2=value2'
    expect(isQueryParamDefined(urlWithEmptyParam)).toBe(false)
  })
})
