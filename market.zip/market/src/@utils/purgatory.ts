import { Purgatory } from '@oceanprotocol/lib'
import { fetchData } from './fetch'
import { getPurgatoryAssetUrl, getPurgatoryAccountUrl } from '../@utils/api'

const purgatoryAssetUrl = getPurgatoryAssetUrl()
const purgatoryAccountUrl = getPurgatoryAccountUrl()
// const purgatoryUrl = 'https://market-purgatory.oceanprotocol.com/api/'
export interface PurgatoryDataAccount {
  address: string
  reason: string
}

export default async function getAssetPurgatoryData(
  did: string
): Promise<Purgatory> {
  const data = await fetchData(`${purgatoryAssetUrl}asset?did=${did}`)
  return { state: data[0]?.state, reason: data[0]?.reason }
}

export async function getAccountPurgatoryData(
  address: string
): Promise<PurgatoryDataAccount> {
  const data = (await fetchData(
    `${purgatoryAccountUrl}account?address=${address}`
  )) as PurgatoryDataAccount[]
  return { address: data[0]?.address, reason: data[0]?.reason }
}
