import {
  PERMISSION_BROWSE,
  PERMISSION_CONSUME
} from '@shared/fancy/constants/PermissionConstants'
import {
  getInMemoryValue,
  removeInMemory,
  setInMemoryValue
} from './fancyAppData'

const marketplaceTitle = [
  'publish',
  'search',
  'asset',
  'published',
  'purchased'
]

const newDesignPages = [
  '404',
  'login',
  'forget-password',
  'reset',
  'search',
  'asset',
  'changepassword',
  'publish',
  'published',
  'purchased',
  'activation-success',
  'validation-success',
  'resendToken',
  'sales',
  'manage-users',
  'accept-invite',
  'login-success',
  'userdetails',
  'org-profile',
  'org-signup',
  'add-edge-node',
  'edgenode',
  'manage-edge-node',
  'sso-login',
  'multiple-c2d',
  'batch-jobs',
  'reset-sso',
  'sdk'
]

const newDesignWithoutHeaderFooter = [
  'login',
  'forget-password',
  'reset',
  'activation-success',
  'validation-success',
  'resendToken',
  'accept-invite',
  'sso-login',
  'login-success',
  'reset-sso',
  'org-signup'
]

const staticPages = [
  'computetodata',
  'contact',
  'faq',
  'terms',
  'privacy',
  'cookie'
]

const isShowBackToTop = [
  'asset/did:op:',
  'search',
  'terms',
  'cookie',
  'privacy',
  'computetodata',
  'faq'
]

const shouldDisplayHeaderBanner = [
  'search',
  'asset',
  'publish',
  'published',
  'purchased'
]

const freeToAccessRole = {
  asset: PERMISSION_BROWSE,
  search: PERMISSION_BROWSE
}

const allowWithoutLogin = {
  asset: PERMISSION_CONSUME
}

const iconicBigBoardPath = ['search']

export function isNewDesign(): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return newDesignPages.includes(currentLocation)
}

export function isNewDesignWithoutHeaderFooter(): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return newDesignWithoutHeaderFooter.includes(currentLocation)
}

export function isStaticPages(): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return staticPages.includes(currentLocation)
}

export function isDisplayBanner(): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return shouldDisplayHeaderBanner.includes(currentLocation)
}

export function isIconicBigBoard(): boolean {
  const currentLocation = location.pathname
  return iconicBigBoardPath.some((i) => currentLocation.indexOf(i) !== -1)
}

export function isBackToTop(): boolean {
  const currentLocation = location.pathname
  return isShowBackToTop.some((i) => currentLocation.indexOf(i) !== -1)
}

export function isMarketplaceTitle(): boolean {
  const currentLocation = location.pathname
  return marketplaceTitle.some((i) => currentLocation.indexOf(i) !== -1)
}

export function setAsLastVisitUrl(): void {
  setInMemoryValue('lastVisitPath', window.location.href)
}

export function removeLastVisitUrl() {
  removeInMemory('lastVisitPath')
}

export function getLastVisitUrl(clearCache?: boolean): string {
  const url = getInMemoryValue('lastVisitPath')
  if (clearCache) {
    removeLastVisitUrl()
  }
  return url
}

export function isFreeToAccessPage(event: string): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return freeToAccessRole[currentLocation] === event
}

export function isAllowWithoutLogin(event: string): boolean {
  const currentLocation = location.pathname.split('/')[1]
  return allowWithoutLogin[currentLocation] === event
}

export function isDefaultSearchUrl(query?: string): boolean {
  query = query || location.search
  return query === '' || query === '?text='
}
