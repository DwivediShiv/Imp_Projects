import { RoleInfo } from '@components/pages/Roles/utils'
import {
  ROLE_ADMIN,
  ROLE_SUPER_ADMIN,
  ROLE_VALIDATED
} from './authorization.constant'

export function hasValidatedRole(roles: string | any[]): boolean {
  for (let i = 0; i < roles?.length; i++) {
    const roleName = roles[i].name
    if (roleName === ROLE_VALIDATED) {
      return true
    }
  }
  return false
}

export function hasAdminRole(roles: RoleInfo[]): boolean {
  for (let i = 0; i < roles?.length; i++) {
    const roleName = roles[i].name
    if (roleName === ROLE_ADMIN) {
      return true
    }
  }
  return false
}

export function hasSuperAdminRole(roles: RoleInfo[]): boolean {
  for (let i = 0; i < roles?.length; i++) {
    const roleName = roles[i].name
    if (roleName === ROLE_SUPER_ADMIN) {
      return true
    }
  }
  return false
}

export function getAttribute(attributes: string | any[], key: string): string {
  for (let i = 0; i < attributes?.length; i++) {
    const attribute = attributes[i]
    if (attribute.name === key) {
      return attribute.value
    }
  }
  return ''
}
