import axios, { AxiosResponse } from 'axios'
import { getUserProfileUrl } from '../@utils/api'
export interface UserProfile {
  walletId?: string
  companyName?: string
  email?: string
  orgId?: string
  organizationName?: string
}

export async function getUserProfileList(
  accountId: string[]
): Promise<UserProfile[]> {
  const postBody = {
    walletList: accountId
  }
  try {
    const response: AxiosResponse = await axios({
      method: 'POST',
      url: getUserProfileUrl(),
      data: postBody
    })
    if (response.status !== 200 || !response.data || !response?.data.data)
      return []
    const responseData = response.data.data
    return responseData as UserProfile[]
  } catch (error) {
    return []
  }
}

export async function getUserProfile(accountId: string): Promise<UserProfile> {
  const accountIds = [accountId]
  const keyCloakProfiles = await getUserProfileList(accountIds)
  if (keyCloakProfiles.length === 0) {
    return {
      walletId: accountId,
      orgId: '',
      organizationName: ''
    }
  }
  return {
    walletId: accountId,
    companyName: keyCloakProfiles[0].companyName,
    email: keyCloakProfiles[0].email,
    orgId: keyCloakProfiles[0].orgId,
    organizationName: keyCloakProfiles[0].organizationName
  }
}

export async function getUserProfileMap(
  accountId: string[]
): Promise<Map<string, UserProfile>> {
  const keyCloakProfileMap = new Map<string, UserProfile>()
  if (!accountId) return keyCloakProfileMap
  const accountIdSet = new Set<string>(accountId)
  const keyCloakProfiles = await getUserProfileList(Array.from(accountIdSet))
  keyCloakProfiles?.forEach((profile) => {
    keyCloakProfileMap?.set(profile.walletId, profile)
  })
  return keyCloakProfileMap
}

export function getUserProfileFromMap(
  accountId: string,
  keyCloakProfileMap: Map<string, UserProfile>
): UserProfile {
  if (!keyCloakProfileMap || !accountId || keyCloakProfileMap?.size === 0)
    return
  const profile =
    keyCloakProfileMap?.get(accountId) ??
    keyCloakProfileMap?.get(accountId.toLowerCase())
  if (!profile) {
    return {
      walletId: accountId
    }
  }
  return profile
}
