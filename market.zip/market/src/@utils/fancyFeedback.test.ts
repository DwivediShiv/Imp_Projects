import { fancyComputeSteps } from './fancyFeedback'

describe('Feedback stepper fancyFeedback free asset', () => {
  const dtSymbol = 'USDC'
  const algoSymbol = 'USDC'
  const dtPriceType = 'free'
  const algoPriceType = 'free'
  const providerFeeApproval = 'Approve compute duration'

  it('should not contain providerFeeApproval stepper as free asset without provider fee', () => {
    const stepper = fancyComputeSteps(
      dtSymbol,
      dtPriceType,
      algoSymbol,
      algoPriceType,
      '0'
    )
    expect(stepper.some((step) => step.label === providerFeeApproval)).toBe(
      false
    )
  })

  it('should contain providerFeeApproval stepper as free asset with provider fee', () => {
    const stepper = fancyComputeSteps(
      dtSymbol,
      dtPriceType,
      algoSymbol,
      algoPriceType,
      '1'
    )
    expect(stepper.some((step) => step.label === providerFeeApproval)).toBe(
      true
    )
  })
})
