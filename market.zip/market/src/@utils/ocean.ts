import { ConfigHelper, Config } from '@oceanprotocol/lib'
// import contractAddresses from '@oceanprotocol/contracts/artifacts/address.json'
import { getOceanConfig as getFancyOceanConfig } from './network'
import { FancyConfig } from 'src/models/FancyConfig'
import { getInfuraKey } from './wallet/chains'

// let currentFancyConfig: Config = null

// export function getFancyCurrentConfig() {
//   return currentFancyConfig ||
// }

/**
  This function takes a Config object as an input and returns a new sanitized Config object
  The new Config object has the same properties as the input object, but with some values replaced by environment variables if they exist
  Also adds missing contract addresses deployed when running barge locally
  @param {Config} config - The input Config object
  @returns {Config} A new Config object
*/
export function sanitizeDevelopmentConfig(config: Config): Config {
  return {
    subgraphUri: process.env.NEXT_PUBLIC_SUBGRAPH_URI || config.subgraphUri,
    metadataCacheUri:
      process.env.NEXT_PUBLIC_METADATACACHE_URI || config.metadataCacheUri,
    providerUri: process.env.NEXT_PUBLIC_PROVIDER_URL || config.providerUri,
    nodeUri: process.env.NEXT_PUBLIC_RPC_URL || config.nodeUri
    // Saransh: Commenting these values not used right now
    // fixedRateExchangeAddress:'#(NEXT_PUBLIC_FIXED_RATE_EXCHANGE_ADDRESS)#',
    // dispenserAddress: '#(NEXT_PUBLIC_DISPENSER_ADDRESS)#',
    // oceanTokenAddress: '#(NEXT_PUBLIC_OCEAN_TOKEN_ADDRESS)#',
    // nftFactoryAddress: '#(NEXT_PUBLIC_NFT_FACTORY_ADDRESS)#'
  } as Config
}

export function getOceanConfig(network: string | number): FancyConfig {
  const fancyConfig = getFancyOceanConfig(network)
  const config = new ConfigHelper().getConfig(
    network || 137,
    network === 'polygon' ||
      network === 137 ||
      network === 'moonbeamalpha' ||
      network === 1287 ||
      network === 'bsc' ||
      network === 56 ||
      network === 'gaiaxtestnet' ||
      network === 2021000 ||
      network === 'supernetTestnet' ||
      network === 81001 ||
      network === 'gen-x-testnet' ||
      network === 100 ||
      network === 'acentrik-testnet' ||
      network === 13520 ||
      network === 'amoy' ||
      network === 80002
      ? undefined
      : getInfuraKey()
  )

  const combinedConfig = { ...config, ...fancyConfig } as FancyConfig
  return combinedConfig
}
