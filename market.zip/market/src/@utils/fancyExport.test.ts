import { FILE_NAME_EXPORT_SALE_HISTORY } from 'src/components/pages/dashboard/sales/Constants'
import { utils, WorkSheet } from 'xlsx'
import { exportToCsv } from './fancyExport'

describe('fancyExport', () => {
  const fileName = 'test_csv'
  const mockUrl = 'http://url.com'
  const mockCsvData = [
    {
      id: 1,
      name: 'Calvyn',
      hobby: 'Swim'
    }
  ]

  it('should create a download link and remove it after click', () => {
    const mockAnchor = {
      href: '',
      setAttribute: jest.fn(),
      click: jest.fn(),
      remove: jest.fn()
    }
    URL.createObjectURL = jest.fn(() => mockUrl)
    document.createElement = jest.fn(() => mockAnchor as any)

    jest.spyOn(utils, 'json_to_sheet').mockReturnValue({} as WorkSheet)
    jest.spyOn(utils, 'sheet_to_csv').mockReturnValue('' as string)

    exportToCsv(mockCsvData, fileName)
    expect(document.createElement).toHaveBeenCalledWith('a')
    expect(mockAnchor.setAttribute).toHaveBeenCalledWith(
      'download',
      `${fileName}.csv`
    )
    expect(mockAnchor.click).toHaveBeenCalled()
    expect(mockAnchor.remove).toHaveBeenCalled()
    expect(mockAnchor.href).toEqual(mockUrl)
  })

  it('should not do anything when input is empty array', () => {
    const mockAnchor = {
      href: '',
      setAttribute: jest.fn(),
      click: jest.fn(),
      remove: jest.fn()
    }

    URL.createObjectURL = jest.fn(() => mockUrl)
    document.createElement = jest.fn(() => mockAnchor as any)

    exportToCsv([], FILE_NAME_EXPORT_SALE_HISTORY)

    expect(document.createElement).toBeCalledTimes(0)
    expect(mockAnchor.setAttribute).toBeCalledTimes(0)
    expect(mockAnchor.click).toBeCalledTimes(0)
    expect(mockAnchor.remove).toBeCalledTimes(0)
    expect(mockAnchor.href).toEqual('')
  })

  it('should not do anything when input is undefined', () => {
    expect(
      exportToCsv(undefined, FILE_NAME_EXPORT_SALE_HISTORY)
    ).toBeUndefined()
  })

  it('should not do anything when input is null', () => {
    expect(exportToCsv(null, FILE_NAME_EXPORT_SALE_HISTORY)).toBeUndefined()
  })

  it('should not do anything when fileName is empty string', () => {
    const mockAnchor = {
      href: '',
      setAttribute: jest.fn(),
      click: jest.fn(),
      remove: jest.fn()
    }
    URL.createObjectURL = jest.fn(() => mockUrl)
    document.createElement = jest.fn(() => mockAnchor as any)

    exportToCsv(mockCsvData, '')

    expect(document.createElement).toBeCalledTimes(0)
    expect(mockAnchor.setAttribute).toBeCalledTimes(0)
    expect(mockAnchor.click).toBeCalledTimes(0)
    expect(mockAnchor.remove).toBeCalledTimes(0)
    expect(mockAnchor.href).toEqual('')
  })

  it('should not do anything when fileName is undefined', () => {
    const mockAnchor = {
      href: '',
      setAttribute: jest.fn(),
      click: jest.fn(),
      remove: jest.fn()
    }
    URL.createObjectURL = jest.fn(() => mockUrl)
    document.createElement = jest.fn(() => mockAnchor as any)

    exportToCsv(mockCsvData, undefined)

    expect(document.createElement).toBeCalledTimes(0)
    expect(mockAnchor.setAttribute).toBeCalledTimes(0)
    expect(mockAnchor.click).toBeCalledTimes(0)
    expect(mockAnchor.remove).toBeCalledTimes(0)
    expect(mockAnchor.href).toEqual('')
  })

  it('should not do anything when fileName is null', () => {
    const mockAnchor = {
      href: '',
      setAttribute: jest.fn(),
      click: jest.fn(),
      remove: jest.fn()
    }
    URL.createObjectURL = jest.fn(() => mockUrl)
    document.createElement = jest.fn(() => mockAnchor as any)

    exportToCsv(mockCsvData, null)

    expect(document.createElement).toBeCalledTimes(0)
    expect(mockAnchor.setAttribute).toBeCalledTimes(0)
    expect(mockAnchor.click).toBeCalledTimes(0)
    expect(mockAnchor.remove).toBeCalledTimes(0)
    expect(mockAnchor.href).toEqual('')
  })
})
