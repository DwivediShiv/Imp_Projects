import {
  WalletClientSigner,
  type SmartAccountAuthenticator
} from '@alchemy/aa-core'
import { UserInfo } from '@web3auth/base'
import { Web3Auth, type Web3AuthOptions } from '@web3auth/modal'
import {
  createWalletClient,
  custom,
  type Hash,
  type SignableMessage,
  type TypedData,
  type TypedDataDefinition
} from 'viem'

interface Web3AuthAuthenticationParams {
  init: () => Promise<void>
  connect: () => Promise<void>
}

export class Web3AuthWalletClientSigner
  implements
    SmartAccountAuthenticator<
      Web3AuthAuthenticationParams,
      Partial<UserInfo>,
      Web3Auth
    >
{
  inner: Web3Auth
  private signer: WalletClientSigner | undefined

  constructor(params: Web3AuthOptions | { inner: Web3Auth }) {
    if ('inner' in params) {
      this.inner = params.inner
      return
    }

    this.inner = new Web3Auth(params)
  }

  readonly signerType = 'aa-signers:web3auth'

  getAddress = async () => {
    if (!this.signer) throw new Error('Not authenticated')

    const address = await this.signer.getAddress()
    if (address == null) throw new Error('No address found')

    return address as Hash
  }

  signMessage = async (msg: SignableMessage) => {
    if (!this.signer) throw new Error('Not authenticated')

    return this.signer.signMessage(msg)
  }

  signTypedData = async <
    TTypedData extends TypedData | { [key: string]: unknown },
    TPrimaryType extends string = string
  >(
    params: TypedDataDefinition<TTypedData, TPrimaryType>
  ) => {
    if (!this.signer) throw new Error('Not authenticated')

    return this.signer.signTypedData(params)
  }

  authenticate = async (
    params: Web3AuthAuthenticationParams = {
      init: async () => {
        await this.inner.initModal()
      },
      connect: async () => {
        await this.inner.connect()
      }
    }
  ) => {
    await params.init()
    await params.connect()

    if (this.inner.provider == null) throw new Error('No provider found')

    this.signer = new WalletClientSigner(
      createWalletClient({
        transport: custom(this.inner.provider)
      }),
      this.signerType
    )

    return this.inner.getUserInfo()
  }

  getAuthDetails = async () => {
    if (!this.signer) throw new Error('Not authenticated')

    return this.inner.getUserInfo()
  }
}
