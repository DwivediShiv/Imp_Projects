import { WalletClientSigner } from '@alchemy/aa-core'
import { Web3Auth } from '@web3auth/modal'
import { createWalletClient, custom } from 'viem'
import { Web3AuthWalletClientSigner } from './Web3AuthWalletClientSigner'

jest.mock('@alchemy/aa-core', () => ({
  WalletClientSigner: jest.fn()
}))

jest.mock('@web3auth/modal', () => ({
  Web3Auth: jest.fn().mockImplementation(() => ({
    initModal: jest.fn(),
    connect: jest.fn(),
    getUserInfo: jest.fn().mockResolvedValue({ name: 'Test User' }),
    provider: {}
  }))
}))

jest.mock('viem', () => ({
  createWalletClient: jest.fn(),
  custom: jest.fn()
}))

describe('Web3AuthWalletClientSigner', () => {
  let mockWeb3Auth: Web3Auth
  let instance: Web3AuthWalletClientSigner

  beforeEach(() => {
    mockWeb3Auth = new Web3Auth({
      clientId: 'test-client-id',
      chainConfig: null
    })
    instance = new Web3AuthWalletClientSigner({ inner: mockWeb3Auth })
  })

  it('should set the correct signerType', () => {
    expect(instance.signerType).toBe('aa-signers:web3auth')
  })

  describe('getAddress', () => {
    it('should throw an error if not authenticated', async () => {
      await expect(instance.getAddress()).rejects.toThrow('Not authenticated')
    })

    it('should return the address if authenticated', async () => {
      const mockSigner = {
        getAddress: jest.fn().mockResolvedValue('0x123')
      }
      // eslint-disable-next-line dot-notation
      instance['signer'] = mockSigner as unknown as WalletClientSigner

      const address = await instance.getAddress()
      expect(address).toBe('0x123')
      expect(mockSigner.getAddress).toHaveBeenCalled()
    })

    it('should throw an error if the address is null or undefined', async () => {
      const mockSigner = {
        getAddress: jest.fn().mockResolvedValue(null)
      }
      // eslint-disable-next-line dot-notation
      instance['signer'] = mockSigner as unknown as WalletClientSigner

      await expect(instance.getAddress()).rejects.toThrow('No address found')
    })
  })

  describe('signMessage', () => {
    it('should throw an error if not authenticated', async () => {
      await expect(instance.signMessage('message')).rejects.toThrow(
        'Not authenticated'
      )
    })

    it('should call signMessage if authenticated', async () => {
      const mockSigner = {
        signMessage: jest.fn().mockResolvedValue('signed-message')
      }
      // eslint-disable-next-line dot-notation
      instance['signer'] = mockSigner as unknown as WalletClientSigner

      const result = await instance.signMessage('message')
      expect(result).toBe('signed-message')
      expect(mockSigner.signMessage).toHaveBeenCalledWith('message')
    })
  })

  describe('signTypedData', () => {
    it('should throw an error if not authenticated', async () => {
      await expect(instance.signTypedData({} as any)).rejects.toThrow(
        'Not authenticated'
      )
    })

    it('should call signTypedData if authenticated', async () => {
      const mockSigner = {
        signTypedData: jest.fn().mockResolvedValue('signed-typed-data')
      }
      // eslint-disable-next-line dot-notation
      instance['signer'] = mockSigner as unknown as WalletClientSigner

      const result = await instance.signTypedData({} as any)
      expect(result).toBe('signed-typed-data')
      expect(mockSigner.signTypedData).toHaveBeenCalledWith({})
    })
  })

  describe('authenticate', () => {
    it('should initialize and connect successfully', async () => {
      await instance.authenticate()

      expect(mockWeb3Auth.initModal).toHaveBeenCalled()
      expect(mockWeb3Auth.connect).toHaveBeenCalled()
      expect(createWalletClient).toHaveBeenCalledWith({
        transport: undefined
      })
      expect(WalletClientSigner).toHaveBeenCalledWith(
        undefined,
        'aa-signers:web3auth'
      )
      expect(instance.getAuthDetails()).resolves.toEqual({ name: 'Test User' })
    })

    it('should throw an error if no provider is found', async () => {
      mockWeb3Auth.provider = null

      await expect(instance.authenticate()).rejects.toThrow('No provider found')
    })
  })

  describe('getAuthDetails', () => {
    it('should throw an error if not authenticated', async () => {
      await expect(instance.getAuthDetails()).rejects.toThrow(
        'Not authenticated'
      )
    })

    it('should return user info if authenticated', async () => {
      const mockSigner = new WalletClientSigner(null, null)
      // eslint-disable-next-line dot-notation
      instance['signer'] = mockSigner

      const userInfo = await instance.getAuthDetails()
      expect(userInfo).toEqual({ name: 'Test User' })
      expect(mockWeb3Auth.getUserInfo).toHaveBeenCalled()
    })
  })
})
