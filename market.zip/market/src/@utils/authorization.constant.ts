export const ROLE_USER = 'user'
export const ROLE_CONSUMER = 'consumer'
export const ROLE_PUBLISHER = 'publisher'
export const ROLE_ADMIN = 'admin'
export const ROLE_SUPER_ADMIN = 'super-admin'
export const ROLE_VALIDATED = 'validated'
export const IDLE_TIMEOUT = 60
export const JWT_LATEST_EXPIRY = 'jwt-latest-expiry'

export const STATUS_CODE_ACCOUNT_LOCK = 'USER_ACCOUNT_LOCK'
export const STATUS_CODE_INCORRECT_OTP = 'ADMIN_OTP_INCORRECT'
export const STATUS_CODE_EXPIRED_OTP = 'ADMIN_OTP_EXPIRED'

export const WALLET_ACTIVE = 'active'
