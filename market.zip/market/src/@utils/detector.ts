import { browserName, isMobile } from 'react-device-detect'

const BROWSERNAME_FIREFOX = 'Firefox'
const BROWSERNAME_CHROME = 'Chrome'
// const BROWSERNAME_BRAVE = 'Brave'
const BROWSERNAME_EDGE = 'Edge'

const supportedBrowsers = new Set([
  BROWSERNAME_FIREFOX,
  BROWSERNAME_CHROME,
  BROWSERNAME_EDGE
])

export const getBrowserName = (): string => {
  // Kris: Kept for future additional browser support may add same implementation
  // if ((navigator as any).brave) {
  //   return BROWSERNAME_BRAVE
  // }

  return browserName
}

export const getIsSupportedBrowser = (): boolean => {
  const thisBrowserName = getBrowserName()

  if (isMobile) {
    return false
  }
  return supportedBrowsers.has(thisBrowserName)
}
