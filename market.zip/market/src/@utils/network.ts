import { ConfigHelper, Config, LoggerInstance } from '@oceanprotocol/lib'
import axios from 'axios'
import appConfig from '../../app.config'
import { Provider } from '../components/Publish/Provider'
import { getOrgProviderListUrl } from '../@utils/api'
import { setInMemoryValue } from './fancyAppData'
import { getInfuraKey } from './wallet/chains'

// Overwriting oceanTokenSymbol, oceanTokenAddress (baseToken for FRE) to StableCoin as we only supporting USDC at here:
// - Market should use oceanTokenSymbol here as the Ticker to display everywhere
// - Until future (ocean V4) when we are adding more stablecoin (as baseToken) we should be getting it from DDO else ask Ocean Team
function getCustomConfig(
  network: string | number,
  defaultSubgraphUri: string
): Record<string, string | number> {
  const networkKey =
    network === 5 || network === 'goerli'
      ? 'goerli'
      : network === 11155111 || network === 'sepolia'
      ? 'sepolia'
      : network === 137 || network === 'polygon'
      ? 'polygon'
      : network === 80002 || network === 'amoy'
      ? 'amoy'
      : network === 81001 || network === 'edge' || network === 'supernetTestnet'
      ? 'supernetTestnet'
      : network === 100 || network === 'gen-x-testnet'
      ? 'gen-x-testnet'
      : network === 13520 || network === 'acentrik-testnet'
      ? 'acentrik-testnet'
      : null

  if (!networkKey) {
    return
  }
  return {
    subgraphUri:
      appConfig.networkConfig?.[networkKey]?.subgraphUri || defaultSubgraphUri,
    oceanTokenAddress: appConfig.stableCoin?.[networkKey]?.address,
    oceanTokenSymbol: appConfig.stableCoin?.[networkKey]?.ticker,
    // fixedRateExchangeAddress:
    //   appConfig.stableCoin?.[networkKey]?.customFREAddress,
    transactionBlockTimeout:
      appConfig?.transaction?.[networkKey]?.transactionBlockTimeout,
    transactionConfirmationBlocks:
      appConfig?.transaction?.[networkKey]?.transactionConfirmationBlocks,
    transactionPollingTimeout:
      appConfig?.transaction?.[networkKey]?.transactionPollingTimeout,
    gasFeeMultiplier: appConfig?.transaction?.[networkKey]?.gasFeeMultiplier,
    marketFeeAddress:
      appConfig?.networkConfig?.[networkKey]?.marketFeeAddress ||
      appConfig.marketFeeAddress,
    encryptionProviderUri:
      appConfig?.networkConfig?.multiChainEncryptionProviderUri ||
      appConfig?.networkConfig?.[networkKey]?.encryptionProviderUri,
    ...(appConfig?.networkConfig?.[networkKey]?.rpc !== undefined && {
      nodeUri: appConfig?.networkConfig?.[networkKey]?.rpc
    }),
    periodicCheckTransactionDuration:
      appConfig?.transaction?.[networkKey]?.periodicCheckTransactionDuration,
    periodicCheckTransactionCycle:
      appConfig?.transaction?.[networkKey]?.periodicCheckTransactionCycle,
    gasEstimateNftAddress:
      appConfig?.transaction?.[networkKey]?.gasEstimateNftAddress,
    gasEstimateNftOwnerAddress:
      appConfig?.transaction?.[networkKey]?.gasEstimateNftOwnerAddress
  }
}

export function findProviderUri(providers: Provider[], name: string): string {
  if (providers?.length > 0)
    return providers.find((provider) => provider?.name === name)?.url
  else return ''
}

export function getDefaultProviderUri(): string {
  const providerList = JSON.parse(
    typeof window !== 'undefined' &&
      window.localStorage.getItem('providerServices')
  )
  if (providerList)
    return providerList.find(
      (provider: { type: string }) => provider.type === 'default'
    )?.url
}

export function getOceanConfig(network: string | number): Config {
  const oceanInitialConfig = new ConfigHelper().getConfig(
    network || 137,
    getInfuraKey()
  ) as Config

  const oceanCustomConfig = {
    ...oceanInitialConfig,
    metadataCacheUri:
      appConfig?.metadataCacheUri || oceanInitialConfig?.metadataCacheUri,
    providerUri: getDefaultProviderUri() || oceanInitialConfig?.providerUri,
    ...getCustomConfig(network, oceanInitialConfig?.subgraphUri),
    rbacUri: appConfig.rbac?.url,
    requestTimeout: appConfig.requestTimeout as number
  }

  return oceanCustomConfig
}

export function getTechnicalNetworkName(networkId: number) {
  switch (networkId) {
    case 1:
      return 'mainnet'
    case 3:
      return 'ropsten'
    case 5:
      return 'goerli'
    case 11155111:
      return 'sepolia'
    case 137:
      return 'polygon'
    case 80002:
      return 'amoy'
    case 81001:
      return 'supernetTestnet'
    case 100:
      return 'gen-x-testnet'
    case 13520:
      return 'acentrik-testnet'
    default:
      return ''
  }
}

export async function setCurrentProviders(
  networkId: number
): Promise<Provider[]> {
  let serviceURL
  typeof window !== 'undefined' &&
    window.localStorage.setItem('networkId', String(networkId))

  networkId
    ? (serviceURL = getOrgProviderListUrl(getTechnicalNetworkName(networkId)))
    : (serviceURL = '')

  if (serviceURL) {
    const providerList = await axios
      .get(serviceURL)
      .then((results) => {
        return results.data.map(
          (result: { name: string; url: string; type: string }) => {
            return {
              name: result.name,
              url: result.url,
              type: result.type
            }
          }
        )
      })
      .catch((err) => {
        if (axios.isCancel(err)) {
          LoggerInstance.log(`provider.ts fail fetch from api log:\n${err}`)
        } else {
          LoggerInstance.error(err.message)
        }
      })

    if (Array.isArray(providerList) && providerList.length > 0) {
      typeof window !== 'undefined' &&
        window.localStorage.setItem(
          'providerServices',
          JSON.stringify(providerList)
        )
      setInMemoryValue('providers', providerList)
    }
    return providerList
  }
}

export async function getCurrentProviders(
  chainId?: string
): Promise<Provider[]> {
  const provider = JSON.parse(
    typeof window !== 'undefined' &&
      window.localStorage.getItem('providerServices')
  )
  if (provider) return provider
  else
    return await setCurrentProviders(
      parseInt(
        typeof window !== 'undefined' &&
          (window.localStorage.getItem('networkId') || chainId)
      )
    )
}

export function getBiconomyBundlerKey(isTestnet: boolean): string {
  return (
    isTestnet
      ? appConfig.biconomyTestnetBundlerKey
      : appConfig.biconomyMainnetBundlerKey
  ) as string
}
