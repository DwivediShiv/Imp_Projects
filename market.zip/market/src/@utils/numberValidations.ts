/* eslint-disable security/detect-non-literal-regexp */
export function isValidNumber(value: any): boolean {
  const isUndefinedValue = typeof value === 'undefined'
  const isNullValue = value === null
  const isNaNValue = isNaN(Number(value))
  const isEmptyString = value === ''

  return !isUndefinedValue && !isNullValue && !isNaNValue && !isEmptyString
}

export function sanitiseNumber(
  value: string,
  checkDecimal = false,
  decimal?: number
): string {
  if (!checkDecimal) {
    return value.replace(/[^0-9]/g, '')
  }

  const regex = new RegExp(`(\\.\\d{${decimal ?? 15}})\\d+`, 'g')
  return value
    .replace(/(?!^)-/g, '')
    .replace(/[^0-9.-]/g, '')
    .replace(/\.+/g, (m) => (m.length > 1 ? m.slice(1) : m))
    .replace(/(\..*)\./g, '$1')
    .replace(regex, '$1')
}
