import {
  approve,
  approveWei,
  Config,
  Datatoken,
  FreOrderParams,
  LoggerInstance,
  OrderParams,
  ProviderComputeInitialize,
  ProviderFees,
  ProviderInstance,
  ProviderInitialize
} from '@oceanprotocol/lib'
import { Signer, ethers } from 'ethers'
import { getOceanConfig } from './ocean'
import { getSiteMetadata } from './siteConfig'
import { fetchDataForMultipleChains } from './subgraph'
import { sleep } from '@utils/index'
import { FancyConfig } from 'src/models/FancyConfig'
import {
  fancyGenerateQueryOrderVariable,
  fancyGetMockTransactionReceipt,
  fancyGetValidOrderTransaction
} from './fancyOrder'
import { getStablecoinDecimal } from 'src/components/Publish/fancyPublishUtils'

// Kris: To check/add in stepper abort + retry, throw error handling etc in
export async function approveProviderFee(
  asset: AssetExtended,
  accountId: string,
  signer: Signer,
  providerFeeAmount: string,
  config?: FancyConfig
): Promise<ethers.providers.TransactionResponse> {
  config = config || getOceanConfig(asset.chainId)
  const baseToken =
    asset?.accessDetails?.type === 'free'
      ? getOceanConfig(asset.chainId).oceanTokenAddress
      : asset?.accessDetails?.baseToken?.address
  const txApproveWei = await approveWei(
    signer,
    config,
    accountId,
    baseToken,
    asset?.accessDetails?.datatoken?.address,
    providerFeeAmount
  )
  return txApproveWei
}

async function queryValidOrderTransaction(
  asset: AssetExtended,
  accountId: string,
  chainIds: number[],
  currentTimestamp: number
): Promise<ethers.providers.TransactionReceipt> {
  const variables = fancyGenerateQueryOrderVariable(
    asset,
    accountId,
    currentTimestamp
  )
  const response = await fetchDataForMultipleChains(
    fancyGetValidOrderTransaction,
    variables,
    chainIds
  )

  const latestOrder = response[0]?.orders?.[0]
  if (latestOrder) {
    return fancyGetMockTransactionReceipt(latestOrder?.tx, latestOrder?.block)
  }

  return null
}

async function fancyPeriodicQueryOrder(
  asset: AssetExtended,
  accountId: string,
  config: FancyConfig,
  signal?: AbortSignal
) {
  const cycle = config?.periodicCheckTransactionCycle
  const duration = config?.periodicCheckTransactionDuration
  const currentTime = Math.round(new Date().getTime() / 1000)

  for (let index = 1; index <= cycle; index++) {
    await sleep(duration)

    if (signal?.aborted) return null

    const response = await queryValidOrderTransaction(
      asset,
      accountId,
      [asset.chainId],
      currentTime
    )
    if (response) return response
  }
  return null
}

async function initializeProvider(
  asset: AssetExtended,
  accountId: string,
  providerFees?: ProviderFees,
  signal?: AbortSignal
): Promise<ProviderInitialize> {
  if (providerFees) return
  try {
    const provider = await ProviderInstance.initialize(
      asset.id,
      asset.services[0].id,
      0,
      accountId,
      asset.services[0].serviceEndpoint,
      signal
    )
    return provider
  } catch (error) {
    LoggerInstance.log('[Initialize Provider] Error:', error)
  }
}

/**
 * @param signer
 * @param asset
 * @param orderPriceAndFees
 * @param accountId
 * @param providerFees
 * @param computeConsumerAddress
 * @returns {ethers.providers.TransactionReceipt | BigNumber} receipt of the order
 */
export async function order(
  signer: Signer,
  asset: AssetExtended,
  orderPriceAndFees: OrderPriceAndFees,
  accountId: string,
  hasDatatoken: boolean,
  providerFees?: ProviderFees,
  computeConsumerAddress?: string,
  setIndex?: any,
  setError?: (string) => void,
  retryStep?: number,
  config?: Config,
  setIsTransactionExpired?: (isTransactionExpired: boolean) => void,
  signal?: AbortSignal
): Promise<ethers.providers.TransactionReceipt> {
  config = config || getOceanConfig(asset.chainId)
  const datatoken = new Datatoken(signer, config?.chainId, config)
  const { appConfig } = getSiteMetadata()
  const currentTime = Math.round(new Date().getTime() / 1000)
  const stableCoinDecimal = getStablecoinDecimal(
    asset?.chainId,
    asset?.accessDetails?.baseToken?.symbol
  )
  if (asset?.services[0]?.type === 'compute') {
    orderPriceAndFees.price = (
      Number(orderPriceAndFees.price) + Number(orderPriceAndFees.computationFee)
    ).toFixed(stableCoinDecimal)
  }

  try {
    const initializeData = await initializeProvider(
      asset,
      accountId,
      providerFees,
      signal
    )
    if (signal?.aborted) return // Kris: Abort safeguard
    const fancyBaseToken =
      asset.accessDetails?.baseToken?.address || config.oceanTokenAddress

    const orderParams = {
      consumer: computeConsumerAddress || accountId,
      serviceIndex: 0,
      _providerFee: providerFees || initializeData.providerFee,
      _consumeMarketFee: {
        consumeMarketFeeAddress: appConfig.marketFeeAddress,
        consumeMarketFeeAmount: appConfig.consumeMarketOrderFee,
        consumeMarketFeeToken: fancyBaseToken
      }
    } as OrderParams

    // TODO: we need to approve provider fee separately using aproveWei
    switch (asset.accessDetails?.type) {
      case 'free': {
        try {
          // Kris ocean code merge: We don't use this templateId, below keeping here for tracking purpose:
          // if (asset.accessDetails.templateId === 1) {
          //   const dispenser = new Dispenser(config.dispenserAddress, signer)
          //   const dispenserTx = await dispenser.dispense(
          //     asset.accessDetails?.datatoken.address,
          //     '1',
          //     accountId
          //   )
          //   return await datatoken.startOrder(
          //     asset.accessDetails.datatoken.address,
          //     orderParams.consumer,
          //     orderParams.serviceIndex,
          //     orderParams._providerFee,
          //     orderParams._consumeMarketFee
          //   )
          // }

          // Approving provider fee for FREE assets
          if (!retryStep || retryStep < 3) {
            if (orderParams._providerFee.providerFeeAmount !== '0') {
              setIndex(0, retryStep)
              const txApproveProvider = await approveProviderFee(
                asset,
                accountId,
                signer,
                orderParams._providerFee.providerFeeAmount
              )
              // if return type is `BigNumber` means spending allowance were approved (from ocean.js)
              if (txApproveProvider.constructor.name !== 'BigNumber') {
                const txApproveReceipt = await txApproveProvider.wait()
                if (signal?.aborted) return
                if (!txApproveReceipt?.transactionHash) {
                  setError('Failed to approve')
                  return null
                }
              }
            }
          }
          if (orderParams._providerFee.providerFeeAmount !== '0') {
            setIndex(3, retryStep)
          }
          const fancyBuyFromDispenserAndOrderRequests = [
            (
              await datatoken.buyFromDispenserAndOrder(
                asset.services[0].datatokenAddress,
                orderParams,
                config.dispenserAddress
              )
            ).wait(),
            fancyPeriodicQueryOrder(
              asset,
              accountId,
              config as FancyConfig,
              signal
            )
          ]

          const txReceipt = await Promise.race(
            fancyBuyFromDispenserAndOrderRequests
          )
          if (signal?.aborted) return
          if (!txReceipt) {
            const response = await queryValidOrderTransaction(
              asset,
              accountId,
              [asset.chainId],
              currentTime
            )
            if (signal?.aborted) return
            if (response) return response

            setIsTransactionExpired && setIsTransactionExpired(true)
            setError('Failed to buyFromDispenserAndOrder')
            return null
          }
          setIndex(3, retryStep)
          return txReceipt
        } catch (e) {
          if (signal?.aborted) return
          setError('Failed to buyFromDispenserAndOrder')
          LoggerInstance.error(e)
          return null
        }
      }
    }
  } catch (e) {
    if (signal?.aborted) return
    setError('Failed at order')
    return null
  }
}

/**
 * called when having a valid order, but with expired provider access, requires approval of the provider fee
 * @param signer
 * @param asset
 * @param accountId
 * @param validOrderTx
 * @param providerFees
 * @returns {TransactionReceipt} receipt of the order
 */
export async function reuseOrder(
  signer: Signer,
  asset: AssetExtended,
  accountId: string,
  validOrderTx: string,
  providerFees?: ProviderFees,
  setIndex?: any,
  setError?: (string) => void,
  retryStep?: number,
  config?: Config
): Promise<ethers.providers.TransactionResponse> {
  setIndex(3, retryStep)
  const datatoken = new Datatoken(signer, config?.chainId, config)
  const initializeData = await initializeProvider(
    asset,
    accountId,
    providerFees
  )

  const tx = await datatoken.reuseOrder(
    asset.accessDetails.datatoken.address,
    validOrderTx,
    providerFees || initializeData.providerFee
  )

  return tx
}

/**
 * Handles order for compute assets for the following scenarios:
 * - have validOrder and no providerFees -> then order is valid, providerFees are valid, it returns the valid order value
 * - have validOrder and providerFees -> then order is valid but providerFees are not valid, we need to call reuseOrder and pay only providerFees
 * - no validOrder -> we need to call order, to pay 1 DT & providerFees
 * @param signer
 * @param asset
 * @param orderPriceAndFees
 * @param accountId
 * @param hasDatatoken
 * @param initializeData
 * @param computeConsumerAddress
 * @returns {Promise<string>} tx id
 */
export async function handleComputeOrder(
  signer: Signer,
  asset: AssetExtended,
  orderPriceAndFees: OrderPriceAndFees,
  accountId: string,
  hasDatatoken: boolean,
  initializeData: ProviderComputeInitialize,
  computeConsumerAddress?: string,
  setIndex?: any,
  setError?: (string) => void,
  retryStep?: number,
  config?: FancyConfig,
  isSkipProviderFee?: boolean,
  signal?: AbortSignal
): Promise<string> {
  LoggerInstance.log(
    '[compute] Handle compute order for asset type: ',
    asset.metadata.type
  )
  LoggerInstance.log('[compute] Using initializeData: ', initializeData)
  const currentTimestamp = Date.now() / 1000
  // try {
  // Return early when valid order is found, and no provider fees
  // are to be paid
  if (
    initializeData?.validOrder &&
    // !initializeData.providerFee &&
    ~~asset?.accessDetails?.providerFee?.validUntil > currentTimestamp
  ) {
    LoggerInstance.log('[compute] Has valid order: ', initializeData.validOrder)
    return asset?.accessDetails?.validOrderTx
  }

  if (initializeData.validOrder) {
    // } else if (initializeData.validOrder || asset?.accessDetails?.isOwned) {
    if (isSkipProviderFee) {
      return initializeData.validOrder
    }
    // Approve potential Provider fee amount first
    if (initializeData?.providerFee?.providerFeeAmount !== '0') {
      const txApproveProvider = await approveProviderFee(
        asset,
        accountId,
        signer,
        initializeData.providerFee.providerFeeAmount,
        config
      )

      if (txApproveProvider.constructor.name !== 'BigNumber') {
        const txApproveReceipt = await txApproveProvider.wait()
        if (!txApproveReceipt?.transactionHash) {
          setError('Failed to approve provider fees!')
          return
        }
      }

      if (signal?.aborted) return

      LoggerInstance.log('[compute] Approved provider fees:', txApproveProvider)
    }
    LoggerInstance.log('[compute] Calling reuseOrder ...', initializeData)
    const txReuseOrder = await reuseOrder(
      signer,
      asset,
      accountId,
      initializeData.validOrder,
      initializeData.providerFee,
      setIndex,
      setError,
      retryStep,
      config
    )
    if (signal?.aborted) return
    if (!txReuseOrder) throw new Error('Failed to reuse order!')
    const txReceipt = await txReuseOrder.wait()
    LoggerInstance.log('[compute] Reused order:', txReceipt)
    return txReceipt?.transactionHash
  }
  LoggerInstance.log('[compute] Calling order ...', initializeData)
  const txStartOrderReceipt = await order(
    signer,
    asset,
    orderPriceAndFees,
    accountId,
    hasDatatoken,
    initializeData.providerFee,
    computeConsumerAddress,
    setIndex,
    setError,
    retryStep,
    config,
    undefined,
    signal
  )
  if (signal?.aborted) return
  // const txStartOrderReceipt = await txStartOrder.wait()
  LoggerInstance.log('[compute] Order succeeded', txStartOrderReceipt)
  return txStartOrderReceipt?.transactionHash
  // } catch (error) {
  //   LoggerInstance.error(`[compute] ${error.message}`)
  // }
}
