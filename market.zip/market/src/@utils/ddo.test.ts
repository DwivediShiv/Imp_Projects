import { UNLIMITED_TIMEOUT_TYPE } from '@components/@shared/fancy/FancyAssetValidityInput/constant'
import {
  fancyConvertTimeoutToSeconds,
  fancyEstimateOldAssetDurationType,
  fancyConvertSecondsToTimeoutOfDurationType
} from './ddo'

describe('fancyConvertTimeoutToSeconds', () => {
  test('should convert hours to seconds', () => {
    expect(fancyConvertTimeoutToSeconds('1', 'hour(s)')).toBe(3600)
    expect(fancyConvertTimeoutToSeconds('2', 'hour(s)')).toBe(7200)
  })

  test('should convert days to seconds', () => {
    expect(fancyConvertTimeoutToSeconds('1', 'day(s)')).toBe(86400)
    expect(fancyConvertTimeoutToSeconds('2', 'day(s)')).toBe(172800)
  })

  test('should convert months to seconds (30 days assumption)', () => {
    expect(fancyConvertTimeoutToSeconds('1', 'month(s)')).toBe(2592000)
    expect(fancyConvertTimeoutToSeconds('2', 'month(s)')).toBe(5184000)
  })

  test('should convert years to seconds (365 days assumption)', () => {
    expect(fancyConvertTimeoutToSeconds('1', 'year(s)')).toBe(31536000)
    expect(fancyConvertTimeoutToSeconds('2', 'year(s)')).toBe(63072000)
  })

  test('should return 0 for unlimited timeout', () => {
    expect(fancyConvertTimeoutToSeconds('0', UNLIMITED_TIMEOUT_TYPE)).toBe(0)
  })

  test('should return undefined for invalid input', () => {
    expect(fancyConvertTimeoutToSeconds('invalid', 'hour(s)')).toBeUndefined()
    expect(fancyConvertTimeoutToSeconds('-1', 'day(s)')).toBeUndefined()
  })
})

describe('fancyEstimateOldAssetDurationType', () => {
  test('should return correct duration type for given seconds', () => {
    expect(fancyEstimateOldAssetDurationType(0)).toBe(UNLIMITED_TIMEOUT_TYPE)
    expect(fancyEstimateOldAssetDurationType(3600)).toBe('hour(s)')
    expect(fancyEstimateOldAssetDurationType(86400)).toBe('day(s)')
    expect(fancyEstimateOldAssetDurationType(604800)).toBe('day(s)')
    expect(fancyEstimateOldAssetDurationType(2630000)).toBe('month(s)')
    expect(fancyEstimateOldAssetDurationType(31556952)).toBe('year(s)')
  })
})

describe('fancyConvertSecondsToTimeoutOfDurationType', () => {
  test('should convert seconds to hours', () => {
    expect(fancyConvertSecondsToTimeoutOfDurationType(3600, 'hour(s)')).toBe(
      '1'
    )
    expect(fancyConvertSecondsToTimeoutOfDurationType(7200, 'hour(s)')).toBe(
      '2'
    )
  })

  test('should convert seconds to days', () => {
    expect(fancyConvertSecondsToTimeoutOfDurationType(86400, 'day(s)')).toBe(
      '1'
    )
    expect(fancyConvertSecondsToTimeoutOfDurationType(172800, 'day(s)')).toBe(
      '2'
    )
  })

  test('should convert seconds to months (30 days assumption)', () => {
    expect(
      fancyConvertSecondsToTimeoutOfDurationType(2592000, 'month(s)')
    ).toBe('1')
    expect(
      fancyConvertSecondsToTimeoutOfDurationType(5184000, 'month(s)')
    ).toBe('2')
  })

  test('should convert seconds to years (365 days assumption)', () => {
    expect(
      fancyConvertSecondsToTimeoutOfDurationType(31536000, 'year(s)')
    ).toBe('1')
    expect(
      fancyConvertSecondsToTimeoutOfDurationType(63072000, 'year(s)')
    ).toBe('2')
  })

  test('should return "0" for unlimited timeout', () => {
    expect(
      fancyConvertSecondsToTimeoutOfDurationType(0, UNLIMITED_TIMEOUT_TYPE)
    ).toBe('0')
  })

  test('should return undefined for invalid input', () => {
    expect(
      fancyConvertSecondsToTimeoutOfDurationType(NaN, 'hour(s)')
    ).toBeUndefined()
    expect(
      fancyConvertSecondsToTimeoutOfDurationType(-1, 'day(s)')
    ).toBeUndefined()
  })

  test('should handle old asset edit without duration type', () => {
    expect(fancyConvertSecondsToTimeoutOfDurationType(3600, '')).toBe('1')
    expect(fancyConvertSecondsToTimeoutOfDurationType(86400, '')).toBe('1')
    expect(fancyConvertSecondsToTimeoutOfDurationType(2630000, '')).toBe('1')
    expect(fancyConvertSecondsToTimeoutOfDurationType(31556952, '')).toBe('1')
  })
})
