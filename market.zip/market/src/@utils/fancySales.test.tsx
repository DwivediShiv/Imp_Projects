import moment from 'moment'
import { format } from 'date-fns'
import {
  generateSalesReportName,
  formatToExportJson,
  filterByDate,
  isValidDate,
  filterByWallet,
  filterByConsumerCompanyName,
  filterByAssetName,
  filterByPricing,
  searchData,
  filterByDataType,
  getPayers,
  getConsumerCompanyNames,
  getAssetNames,
  getSalesAssetMap
} from './fancySales'
import { PRICING_OPTIONS } from '@shared/fancy/organisms/CreatePricing/Constants'
import { PRICE_TYPE_FREE_LABEL } from 'src/components/Constants'
import {
  mockAssetBestPrice as assetListPrices,
  mockSalesData as salesData,
  mockOrders,
  mockPayers
} from '../../.jest/__fixtures__/sales'
import { falsyValues } from '../../.jest/__fixtures__/mockUtils'

const expectedOutput = [
  // Expected output for earlier than 31 Oct
  {
    did: 'did:op:87184033561bde06eae305c44dba9a02daeac31bda92fba37960b6359dd77212',
    chainId: 5,
    orderDate: moment('2022-10-27T08:57:12.000Z').toDate(),
    tx: '0x8c980cce06df686df1fded14d86312825256a8e5573ac12813348e0591d7d6fb',
    payer: '0x500db43ee6966e6213ba58eaf152da593eb7432e',
    consumerCompanyName:
      "\"Kris\" DAO ♡ ♥💕 `Dank` 'Danky' Sharding ❤😘 EIP4844 Shanghai Upgrade Withdrawal From Beacon Chain 'OwO'",
    assetName: '20221025 Heart For 1 hour 1 minute',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 1,
    tokenSymbol: 'USDC'
  },
  {
    did: 'did:op:87184033561bde06eae305c44dba9a02daeac31bda92fba37960b6359dd77212',
    chainId: 5,
    orderDate: moment('2022-10-27T06:30:36.000Z').toDate(),
    tx: '0x45e55b1e897d959c4f32f346578f88fbef4302425272bb09d5481bd80d5af432',
    payer: '0x500db43ee6966e6213ba58eaf152da593eb7432e',
    consumerCompanyName:
      "\"Kris\" DAO ♡ ♥💕 `Dank` 'Danky' Sharding ❤😘 EIP4844 Shanghai Upgrade Withdrawal From Beacon Chain 'OwO'",
    assetName: '20221025 Heart For 1 hour 1 minute',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 1,
    tokenSymbol: 'USDC'
  },
  {
    did: 'did:op:87184033561bde06eae305c44dba9a02daeac31bda92fba37960b6359dd77212',
    chainId: 5,
    orderDate: moment('2022-10-25T07:13:36.000Z').toDate(),
    tx: '0x3dd9e4228984b3242e217e3b58137f5ff0edb97b1296c276644ab3ef848568bc',
    payer: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
    consumerCompanyName: 'Kian Jun Sdn. Bhd.',
    assetName: '20221025 Heart For 1 hour 1 minute',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 1,
    tokenSymbol: 'USDC'
  },
  {
    did: 'did:op:893c26b09a04cbd95bcdf3bef4fbdf81b4d72d187542fc818831a9ad31dac314',
    chainId: 5,
    orderDate: moment('2022-10-25T07:12:24.000Z').toDate(),
    tx: '0xc1cd9dd20c856997d12c6517120e3eaf20c0377b303702ad79597be06c1c7438',
    payer: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
    consumerCompanyName: 'Kian Jun Sdn. Bhd.',
    assetName: '221007 MoH Malaysia Covid 19 Public',
    assetType: 'dataset',
    accessType: 'compute',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:5245e6941b656462f0104af9884796a161120422be9759332f64a3df7878c8da',
    chainId: 5,
    orderDate: moment('2022-10-19T01:28:48.000Z').toDate(),
    tx: '0x63b0bfa3719d7f65bfc018c799048a48532e43da90a41b463ddb619211c23562',
    payer: '0x500db43ee6966e6213ba58eaf152da593eb7432e',
    consumerCompanyName:
      "\"Kris\" DAO ♡ ♥💕 `Dank` 'Danky' Sharding ❤😘 EIP4844 Shanghai Upgrade Withdrawal From Beacon Chain 'OwO'",
    assetName: '221019 Vehicle Break Failure Data test',
    assetType: 'dataset',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:45705eb28d1bbeb51b957ff4c6a98d827d6726ee993a8a364783075057bb2440',
    chainId: 5,
    orderDate: moment('2022-10-19T00:59:48.000Z').toDate(),
    tx: '0x3892b3982a8fdbb8d59d7e4c589134b4984d215b61d2e08df4d58bbb8f6d855d',
    payer: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
    consumerCompanyName: 'Kian Jun Sdn. Bhd.',
    assetName: '221019 Vehicle Registration Data',
    assetType: 'dataset',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: 'USD'
  },
  {
    did: 'did:op:d9fbd4f36c746199035d95f5f46bd8d52a92e81fe658bf85ed4285a454f7097b',
    chainId: 5,
    orderDate: moment('2022-10-11T04:17:00.000Z').toDate(),
    tx: '0xbc94e0c15b3f77fa4bc51983bd0a3d2e7b2c9aa114bed2e365f07c097fabf299',
    payer: '0x09262b812a05678a81778e60ee0154efcb7acfc7',
    consumerCompanyName: 'Mercedes-Benz Group AG',
    assetName: '221011 Vehicle Break Failure Algorithm for Download only',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:d9fbd4f36c746199035d95f5f46bd8d52a92e81fe658bf85ed4285a454f7097b',
    chainId: 5,
    orderDate: moment('2022-10-11T03:49:12.000Z').toDate(),
    tx: '0xf34faac1dd0a2de421ca6aec0a7d699becfec5be5a16f69337737f3d5a74b6bd',
    payer: '0x500db43ee6966e6213ba58eaf152da593eb7432e',
    consumerCompanyName:
      "\"Kris\" DAO ♡ ♥💕 `Dank` 'Danky' Sharding ❤😘 EIP4844 Shanghai Upgrade Withdrawal From Beacon Chain 'OwO'",
    assetName: '221011 Vehicle Break Failure Algorithm for Download only',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:d9fbd4f36c746199035d95f5f46bd8d52a92e81fe658bf85ed4285a454f7097b',
    chainId: 5,
    orderDate: moment('2022-10-11T03:11:36.000Z').toDate(),
    tx: '0xe78a05c9fc3b6b96a87751986fb97e462fc54a8a2f6128c15585750594a024dd',
    payer: '0x09262b812a05678a81778e60ee0154efcb7acfc7',
    consumerCompanyName: 'Mercedes-Benz Group AG',
    assetName: '221011 Vehicle Break Failure Algorithm for Download only',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:d9fbd4f36c746199035d95f5f46bd8d52a92e81fe658bf85ed4285a454f7097b',
    chainId: 5,
    orderDate: moment('2022-10-11T03:02:48.000Z').toDate(),
    tx: '0xbe174ee39767d8aeb84ef2d4377a971d2d0df6a7e61afe5ec8e398a97ae71e95',
    payer: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
    consumerCompanyName: 'Kian Jun Sdn. Bhd.',
    assetName: '221011 Vehicle Break Failure Algorithm for Download only',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:d9fbd4f36c746199035d95f5f46bd8d52a92e81fe658bf85ed4285a454f7097b',
    chainId: 5,
    orderDate: moment('2022-10-07T07:40:12.000Z').toDate(),
    tx: '0xb040dce14b84b21408394c44344173b3a5c5d993cd63f2818e9dcfd8764d1886',
    payer: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
    consumerCompanyName: 'Kian Jun Sdn. Bhd.',
    assetName: '221011 Vehicle Break Failure Algorithm for Download only',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:893c26b09a04cbd95bcdf3bef4fbdf81b4d72d187542fc818831a9ad31dac314',
    chainId: 5,
    orderDate: moment('2022-10-07T07:39:48.000Z').toDate(),
    tx: '0x637b9ee5220a1f938e2ff52347c228d8bdbf377a773816246bf97d621ec2f92a',
    payer: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
    consumerCompanyName: 'Kian Jun Sdn. Bhd.',
    assetName: '221007 MoH Malaysia Covid 19 Public',
    assetType: 'dataset',
    accessType: 'compute',
    priceValue: 0,
    tokenSymbol: ''
  }
]

const expectedOutput2 = [
  {
    did: 'did:op:9471ff5027bef1b66496c865901975a77289c1e87f8cfd6c10abd3c9d8784f3f',
    chainId: 5,
    orderDate: moment('2023-01-31T02:25:36.000Z').toDate(),
    tx: '0x16971e983471cfcdfc62955441a4c275b77a63dcff564a0211aadcfc7b1c72c3',
    payer: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
    consumerCompanyName: 'Kian Jun Sdn. Bhd.',
    assetName:
      '20230119 Compute Dataset for Testing - Non usable dataset for testing',
    assetType: 'dataset',
    accessType: 'compute',
    priceValue: 0,
    tokenSymbol: ''
  },
  {
    did: 'did:op:87184033561bde06eae305c44dba9a02daeac31bda92fba37960b6359dd77212',
    chainId: 5,
    orderDate: moment('2023-01-19T07:10:12.000Z').toDate(),
    tx: '0x9e683f2338d835c855fce74bde81160459e2decfe1196bc99ef781bafdb49398',
    payer: '0x002d6f48a56e864b910bc219b63440c6f6508fe4',
    consumerCompanyName: 'Bello Innovation',
    assetName: '20221025 Heart For 1 hour 1 minute',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 1,
    tokenSymbol: 'USDC'
  },
  {
    did: 'did:op:87184033561bde06eae305c44dba9a02daeac31bda92fba37960b6359dd77212',
    chainId: 5,
    orderDate: moment('2023-01-18T06:44:36.000Z').toDate(),
    tx: '0x00c49ec5dc2afa7a8500f19a7e183e051c02844ef114d8d15ad7e9784ad361fe',
    payer: '0x002d6f48a56e864b910bc219b63440c6f6508fe4',
    consumerCompanyName: 'Bello Innovation',
    assetName: '20221025 Heart For 1 hour 1 minute',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 1,
    tokenSymbol: 'USDC'
  },
  {
    did: 'did:op:b590d7fe1d63b4bd3013cb794d5bf1a8481095de267996ad7caccbeb171fc31b',
    chainId: 5,
    orderDate: moment('2023-01-16T07:37:48.000Z').toDate(),
    tx: '0x410547950c1fde78d9098f9281fddd531a767774cc2286d0aa8da4b9b73d5061',
    payer: '0x500db43ee6966e6213ba58eaf152da593eb7432e',
    consumerCompanyName:
      "\"Kris\" DAO ♡ ♥💕 `Dank` 'Danky' Sharding ❤😘 EIP4844 Shanghai Upgrade Withdrawal From Beacon Chain 'OwO'",
    assetName: '20230113 HTTP Header Testing',
    assetType: 'algorithm',
    accessType: 'access',
    priceValue: 0,
    tokenSymbol: ''
  }
]

const mockSaleHistoryData = [
  {
    did: 'did:op:7d3182114be773b6622f3ce276baa877c4887a66dd779362c5cbe86298e32142',
    chainId: 5,
    orderDate: new Date(),
    tx: '0x1c2147bc9e30a1f96fb795b3a7d11cac696fdff72b1472f20c1c93a098ea3de1',
    payer: '0x500db43ee6966e6213ba58eaf152da593eb7432e',
    consumerCompanyName:
      'Kris DAO Dank Danky Sharding EIP4844 Shanghai Upgrade',
    assetName: 'Heart.csv',
    assetType: 'dataset',
    accessType: 'compute',
    priceValue: 0,
    tokenSymbol: ''
  }
]
const mockFormattedSaleHistory = [
  {
    Date: format(mockSaleHistoryData[0].orderDate, 'dd MMM yyyy'),
    Consumer: 'Kris DAO Dank Danky Sharding EIP4844 Shanghai Upgrade',
    Asset: 'Heart.csv',
    'Asset Type': 'Dataset',
    'Access Type': 'Compute',
    Revenue: 'Free'
  }
]

const expectedAssetListPrices: Map<string, SalesAsset> = new Map(
  Object.entries({
    '0x6a470688f84223229ca34f43773fdc972a50c9fc': {
      did: 'did:op:9a9bae28bb6c4907b9872ab2dcaefe8b2dc520f3eb677512a30ca1c032d1dc58',
      chainId: 5,
      assetName: '[Phyllice] Compute Dataset with Param - 16/2/23',
      assetType: 'dataset',
      accessType: 'compute',
      owner: '0xB33A83EF0b99288F1ced3a0220F454143c4A008b',
      tokenSymbol: ''
    },
    '0xbc18446d527f90e086ee6d3b19cfc8ebecaaa2f3': {
      did: 'did:op:829cafe1de2ddd5c4bc80dbc28e8c15f5f0c204e503e38ba9cd8b3be2ec58d25',
      chainId: 5,
      assetName: '[Phyllice] Dataset B - 17/11/22',
      assetType: 'dataset',
      accessType: 'compute',
      owner: '0xB33A83EF0b99288F1ced3a0220F454143c4A008b',
      tokenSymbol: ''
    },
    '0xf66f365f2499d098bac8ee96cc0e3541bc3c43aa': {
      did: 'did:op:d01d0e1e3f1de1015475dd33e31052896c868c8e7b63f8f23dc15a139acd7c35',
      chainId: 5,
      assetName: '[Phyllice] Algorithm B - 16/11/22',
      assetType: 'algorithm',
      accessType: 'compute',
      owner: '0xB33A83EF0b99288F1ced3a0220F454143c4A008b',
      tokenSymbol: ''
    },
    '0x82d4c1993d958066a0c2cb0360db2f311a7d97b8': {
      did: 'did:op:91225f0c7662326081c6aacd34327768f323f02e87585ae8a8b81f1eedd0df50',
      chainId: 5,
      assetName: '[Phyllice] Algorithm A - 16/11/22',
      assetType: 'algorithm',
      accessType: 'access',
      owner: '0xB33A83EF0b99288F1ced3a0220F454143c4A008b',
      tokenSymbol: 'USDC'
    },
    '0xc94015b11ddf31d40b9ee96205a56b170429dc77': {
      did: 'did:op:25903c631a67dfcc2715004e17db882ab98ec064d31b42b21f4e33e4e6e4be09',
      chainId: 5,
      assetName: 'Mintology',
      assetType: 'dataset',
      accessType: 'access',
      owner: '0xB33A83EF0b99288F1ced3a0220F454143c4A008b',
      tokenSymbol: ''
    }
  })
)

describe('fancySales', () => {
  it('should return the date that started from the start date', () => {
    expect(filterByDate(salesData, moment('2023-03-27').toDate())).toEqual([
      {
        accessType: 'access',
        assetName: '20221025 Heart For 1 hour 1 minute',
        assetType: 'algorithm',
        chainId: 5,
        consumerCompanyName:
          "\"Kris\" DAO ♡ ♥💕 `Dank` 'Danky' Sharding ❤😘 EIP4844 Shanghai Upgrade Withdrawal From Beacon Chain 'OwO'",
        did: 'did:op:87184033561bde06eae305c44dba9a02daeac31bda92fba37960b6359dd77212',
        orderDate: new Date(
          'Mon Mar 27 2023 12:17:24 GMT+0800 (Malaysia Time)'
        ),
        payer: '0x500db43ee6966e6213ba58eaf152da593eb7432e',
        priceValue: 1,
        tokenSymbol: 'USDC',
        tx: '0x67ac0a94030a78c4d61a6a2047ecddc2252fb81e8831c45e0f4d57004fa1d3a9'
      }
    ])
  })

  it('should return empty records when date range is valid but out of boundary', () => {
    expect(
      filterByDate(
        salesData,
        moment('2021-03-27').toDate(),
        moment('2022-03-27').toDate()
      )
    ).toEqual([])
  })

  it('should return the sales records within January 2023', () => {
    expect(
      filterByDate(
        salesData,
        moment('2023-01-01').toDate(),
        moment('2023-01-31').toDate()
      )
    ).toEqual(expectedOutput2)
  })

  it('should return the sales records before 31 Oct 2022', () => {
    expect(
      filterByDate(salesData, undefined, moment('2022-10-31').toDate())
    ).toEqual(expectedOutput)
  })

  it('should return false when falsy value is passed', () => {
    falsyValues.forEach((value: any) =>
      expect(
        filterByDate(
          value,
          moment('2023-01-01').toDate(),
          moment('2023-01-31').toDate()
        )
      ).toBeUndefined()
    )
  })

  it('should return original sales records when both start and end dates are not passed', () => {
    expect(filterByDate(salesData, undefined, undefined)).toEqual(salesData)
  })

  it('should return true when correct date is entered', () => {
    expect(isValidDate(moment('2023-01-01').toDate())).toBeTruthy()
  })

  it('should return false when invalid date is entered', () => {
    falsyValues.forEach((value: any) => {
      expect(isValidDate(value)).toBe(false)
    })
  })

  it('should return false when invalid date format is entered', () => {
    expect(isValidDate(new Date('2023-02-MM'))).toBe(false)
  })

  it('should format sales data properly', () => {
    expect(formatToExportJson(mockSaleHistoryData)).toEqual(
      mockFormattedSaleHistory
    )
  })

  it('should returns empty array if data parameter is empty array', () => {
    const result = formatToExportJson([])
    expect(result).toEqual([])
  })

  it('should returns undefined if data parameter is null', () => {
    const result = formatToExportJson(null)
    expect(result).toBeUndefined()
  })

  it('should returns undefined if data parameter is undefined', () => {
    const result = formatToExportJson(undefined)
    expect(result).toBeUndefined()
  })

  it('should return a filename which consists of today date', () => {
    const expectedFileName = `sales_${format(new Date(), 'ddMMyyyy')}`
    expect(generateSalesReportName()).toEqual(expectedFileName)
  })
})

describe('filterByWallet', () => {
  it('should able to filter sales by wallet addresses', () => {
    const wallets = ['0x09262b812a05678a81778e60ee0154efcb7acfc7']
    const filteredSales = filterByWallet(salesData, wallets)
    expect(filteredSales.length).toBe(2)
    filteredSales.forEach((sale) => {
      expect(sale.payer).toBe(wallets[0])
    })
  })

  it('should be able to return empty sales array if some non-relevant wallets are passed', () => {
    const wallets = ['0x94750381bE1AbA0504C666ee1DB118F68f0780D4']
    const filteredSales = filterByWallet(salesData, wallets)
    expect(filteredSales.length).toEqual(0)
  })

  it('should get back the original assets if falsy sales are passed', () => {
    const wallets = ['0x09262b812a05678a81778e60ee0154efcb7acfc7']
    const falsyAssets = [undefined, null]
    falsyAssets.forEach((falsyAsset) => {
      const filteredSales = filterByWallet(falsyAsset, wallets)
      expect(filteredSales).toEqual(falsyAsset)
    })
  })

  it('should get back the falsy wallet value if empty wallets are passed', () => {
    const falsyWallets = [undefined, null]
    falsyWallets.forEach((falsyWallet) => {
      const filteredSales = filterByWallet(salesData, falsyWallet)
      expect(JSON.stringify(filteredSales)).toEqual(JSON.stringify(salesData))
    })
  })
})

describe('filterByConsumerCompanyName', () => {
  it('should be able to filter sales if company names are passed', () => {
    const companyNames = ['Mercedes-Benz Group AG', 'Kian Jun Sdn. Bhd.']
    const filteredSales = filterByConsumerCompanyName(salesData, companyNames)
    expect(filteredSales.length).toEqual(18)
    filteredSales.forEach((sale) => {
      expect(companyNames.includes(sale.consumerCompanyName)).toBeTruthy()
    })
  })

  it('should be able to return empty sales array if some non-relevant company names are passed', () => {
    const companyNames = ['DAOventures', 'iFAST']
    const filteredSales = filterByConsumerCompanyName(salesData, companyNames)
    expect(filteredSales.length).toEqual(0)
  })

  it('should get back the original sales if falsy assets are passed', () => {
    const companyNames = ['Mercedes-Benz Group AG']
    const falsyAssets = [undefined, null]
    falsyAssets.forEach((falsyAsset) => {
      const filteredSales = filterByConsumerCompanyName(
        falsyAsset,
        companyNames
      )
      expect(filteredSales).toEqual(falsyAsset)
    })
  })

  it('should get back the original sales if falsy company names or empty company names array are passed', () => {
    const falsyCompanyNames = [undefined, null, []]
    falsyCompanyNames.forEach((falsyCompanyName) => {
      const filteredSales = filterByConsumerCompanyName(
        salesData,
        falsyCompanyName
      )
      expect(JSON.stringify(filteredSales)).toEqual(JSON.stringify(salesData))
    })
  })
})

describe('filterByAssetName', () => {
  it('should be able to filter sales if asset names are passed', () => {
    const assetNames = [
      '221019 Vehicle Break Failure Data test',
      '20230113 HTTP Header Testing'
    ]
    const filteredSales = filterByAssetName(salesData, assetNames)
    expect(filteredSales.length).toEqual(3)
    filteredSales.forEach((sale) => {
      expect(assetNames.includes(sale.assetName)).toBeTruthy()
    })
  })

  it('should be able to return empty sales array if some non-relevant asset names are passed', () => {
    const assetNames = [
      'Bitcoin Prices (from start to 2023)',
      'Online Shop Customer Sales Data'
    ]
    const filteredSales = filterByAssetName(salesData, assetNames)
    expect(filteredSales.length).toEqual(0)
  })

  it('should get back the original sales if falsy assets are passed', () => {
    const assetNames = [
      '221019 Vehicle Break Failure Data test',
      '20230113 HTTP Header Testing'
    ]
    const falsyAssets = [undefined, null]
    falsyAssets.forEach((falsyAsset) => {
      const filteredSales = filterByAssetName(falsyAsset, assetNames)
      expect(filteredSales).toEqual(falsyAsset)
    })
  })

  it('should get back the original sales if falsy asset names or empty asset names array are passed', () => {
    const falsyAssetNames = [undefined, null, []]
    falsyAssetNames.forEach((falsyAssetName) => {
      const filteredSales = filterByAssetName(salesData, falsyAssetName)
      expect(JSON.stringify(filteredSales)).toEqual(JSON.stringify(salesData))
    })
  })
})

describe('filterByPricing', () => {
  const pricingOptions = PRICING_OPTIONS
  const NO_PRICE_SET = 'No Price Set'

  // it('should get back the orginal set of assets if asset or pricing is undefined, or pricing filter are all selected', () => {
  //   const falsySales = [undefined, null]
  //   let chosenPricing = pricingOptions
  //   falsySales.forEach((sales) => {
  //     expect(filterByPricing(sales, chosenPricing)).toEqual(sales)
  //   })

  //   const falsyChosenPrice = [undefined, null]
  //   falsyChosenPrice.forEach((chosenPrice) => {
  //     expect(filterByPricing(salesData, chosenPrice)).toEqual(salesData)
  //   })

  //   chosenPricing = [...pricingOptions, ...[NO_PRICE_SET]]
  //   expect(filterByPricing(salesData, chosenPricing)).toEqual(salesData)
  // })

  it("should get correct sales if 'free' and 'no price set' price type are applied", () => {
    const chosenPricing = [PRICE_TYPE_FREE_LABEL, NO_PRICE_SET]
    const filteredSales = filterByPricing(salesData, chosenPricing)
    filteredSales.forEach((sale) => {
      expect(sale.priceValue).toBeLessThanOrEqual(0)
    })
  })

  it("should get correct sales if 'no price set' price type is applied", () => {
    const chosenPricing = [NO_PRICE_SET]
    const filteredSales = filterByPricing(salesData, chosenPricing)
    filteredSales.forEach((sale) => {
      expect(sale.priceValue).toEqual(-1)
    })
  })

  it("should get correct sales if 'free' price type is applied", () => {
    const chosenPricing = [PRICE_TYPE_FREE_LABEL]
    const filteredSales = filterByPricing(salesData, chosenPricing)
    filteredSales.forEach((sale) => {
      expect(sale.priceValue).toEqual(0)
    })
  })
})

describe('searchData', () => {
  it('should return original sales if falsy search text is passed', () => {
    const falsySearchString = [undefined, null, '']
    falsySearchString.forEach((searchString) => {
      expect(searchData(searchString, salesData)).toEqual(salesData)
    })
  })

  it('should return the falsy sales if falsy assets is passed', () => {
    const falsySales = [undefined, null]
    const searchString = 'Vehicle'
    falsySales.forEach((falsySale) => {
      expect(searchData(searchString, falsySale)).toEqual(falsySale)
    })
  })

  it('should return the empty sales if irrelevant string is passed', () => {
    const searchString = 'Mercedes-Benz Group AG' // Set company name
    expect(searchData(searchString, salesData)).toEqual([])
  })

  it('should return the correct sales based on the search string passed', () => {
    const searchString = 'Vehicle'
    const filteredSales = searchData(searchString, salesData)
    filteredSales.forEach((sale) => {
      expect(sale.assetName).toContain(searchString)
    })
  })
})

describe('filterByDataType', () => {
  it('should return falsy sales if falsy asset is passed', () => {
    const falsySales = [undefined, null]
    const dataTypes = ['private', 'algorithm', 'compute']

    falsySales.forEach((falsySale) => {
      expect(filterByDataType(falsySale, dataTypes)).toBe(falsySale)
    })
  })

  it('should return original sales if falsy datatype is passed', () => {
    const falsyDataTypes = [[], undefined, null]
    falsyDataTypes.forEach((datatype) => {
      expect(filterByDataType(salesData, datatype)).toBe(salesData)
    })
  })

  it('should return original sales if all datatypes or all irrelevant datatypes are passed', () => {
    const datatypes = [
      'private',
      'public',
      'compute',
      'access',
      'dataset',
      'algorithm'
    ]
    expect(filterByDataType(salesData, datatypes)).toBe(salesData)

    const irrelevantDatatypes = ['test', 'test1', 'test2', 'test3']
    expect(filterByDataType(salesData, irrelevantDatatypes)).toBe(salesData)
  })

  it('should return correct algorithm sales when data type filter applied', () => {
    // Filter public algorithm
    let dataTypes: string[] = ['public']
    let filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(21)
    filteredSales.forEach((sale) => {
      expect(sale.accessType).toEqual('access')
      expect(sale.assetType).toEqual('algorithm')
    })

    // Filter private algorithm
    dataTypes = ['private']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(1)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('algorithm')
      expect(sale.accessType).toEqual('compute')
    })

    // Filter algorithm, regardless of access type
    dataTypes = ['public', 'private', 'algorithm']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(22)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('algorithm')
    })

    // Algorithm
    dataTypes = ['algorithm']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(22)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('algorithm')
    })

    // Algorithm with random text
    // TODO: should restrict the string passed into the function
    dataTypes = ['private', 'random']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(1)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('algorithm')
      expect(sale.accessType).toEqual('compute')
    })
  })

  it('should return correct datasets sales when data type filter applied', () => {
    // Filter public dataset
    let dataTypes: string[] = ['access']
    let filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(4)
    filteredSales.forEach((sale) => {
      expect(sale.accessType).toEqual('access')
      expect(sale.assetType).toEqual('dataset')
    })

    // Filter private algorithm
    dataTypes = ['compute']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(4)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('dataset')
      expect(sale.accessType).toEqual('compute')
    })

    // Filter algorithm, regardless of access type
    dataTypes = ['compute', 'access', 'dataset']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(8)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('dataset')
    })

    // Algorithm
    dataTypes = ['dataset']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(8)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('dataset')
    })

    // Algorithm with random text
    // TODO: should restrict the string passed into the function
    dataTypes = ['access', 'random', '1']
    filteredSales = filterByDataType(salesData, dataTypes)
    expect(filteredSales.length).toEqual(4)
    filteredSales.forEach((sale) => {
      expect(sale.assetType).toEqual('dataset')
      expect(sale.accessType).toEqual('access')
    })
  })
})

describe('getPayers', () => {
  const expectedPayers = Object.values(mockPayers)

  it('should list of unique payer address when valid orders are passed', () => {
    const payers = getPayers(mockOrders)
    expect(payers.length).toEqual(expectedPayers.length)
    expect(payers.sort()).toEqual(expectedPayers.sort())
  })

  it('should return empty array when falsy orders are passed', () => {
    const falsyOrder1 = mockOrders.map((mockOrder) => {
      delete mockOrder?.payer?.id
      return mockOrder
    })
    const falsyOrder2 = mockOrders.map((mockOrder) => {
      delete mockOrder?.payer
      return mockOrder
    })
    const falsyOrders = [falsyOrder1, falsyOrder2, undefined, null]
    falsyOrders.forEach((falsyOrder) => {
      expect(getPayers(falsyOrder)).toEqual([])
    })
  })
})

describe('getConsumerCompanyNamess', () => {
  it('should return list of unique consumer company name when valid sales passed', () => {
    const companyNames = getConsumerCompanyNames(salesData)
    expect(companyNames.length).toEqual(7)
    const expectedCompanyNames = salesData.map((s) => s.consumerCompanyName)
    companyNames.forEach((name) => {
      expect(expectedCompanyNames.includes(name)).toBeTruthy()
    })
  })

  it('should return empty list when falsy sales passed', () => {
    const falsySale1 = JSON.parse(JSON.stringify(salesData)).map((s: any) => {
      delete s.consumerCompanyName
      return s
    })
    const falsySales = [undefined, null, falsySale1]
    falsySales.forEach((falsySale) => {
      expect(getConsumerCompanyNames(falsySale)).toEqual([])
    })
  })
})

describe('getAssetNames', () => {
  it('should return list of unique asset name when valid sales passed', () => {
    const assetNames = getAssetNames(salesData)
    expect(assetNames.length).toEqual(11)
    const expectedAssetNames = salesData.map((s) => s.assetName)
    assetNames.forEach((name) => {
      expect(expectedAssetNames.includes(name)).toBeTruthy()
    })
  })

  it('should return empty list when falsy sales passed', () => {
    const falsySale1 = JSON.parse(JSON.stringify(salesData)).map((s: any) => {
      delete s.assetName
      return s
    })
    const falsySales = [undefined, null, falsySale1]
    falsySales.forEach((falsySale) => {
      expect(getAssetNames(falsySale)).toEqual([])
    })
  })

  it('should get a list map of sales assets', () => {
    expect(getSalesAssetMap(assetListPrices)).toEqual(expectedAssetListPrices)
  })
})
