import { isBoolean } from 'lodash'
import { GOOGLE_DRIVE_URL_PATTERN } from '@components/Publish/Constants'
import * as Path from 'path-browserify'

export function isTrue(input: boolean | string): boolean {
  if (isBoolean(input)) {
    return input === true
  }
  return input === 'true'
}

export function checkIsHttpUrl(value: string) {
  return /^http:/.test(value.toLowerCase())
}

export function checkIsLocalPath(value: string): boolean {
  try {
    if (value === '' || typeof value !== 'string') {
      return false
    }

    const normalizedPath = Path?.normalize(value)

    if (Path?.isAbsolute(normalizedPath)) {
      if (Path?.sep === '\\') {
        return (
          /^[A-Za-z]:\\/.test(normalizedPath) ||
          normalizedPath?.startsWith('\\\\')
        )
      } else {
        return normalizedPath?.startsWith('/')
      }
    }
    return false
  } catch (error) {
    return false
  }
}

export function getPathType(path: string): string {
  if (checkIsLocalPath(path)) {
    return 'localstorage'
  }

  // Kris: Added Azure, Google commented code for future extension
  const pathTypes = {
    '^s3://': 's3'
    // '^gs://': 'gs',
    // '^az://': 'azure'
  }

  for (const regex in pathTypes) {
    if (new RegExp(regex).test(path)) {
      return pathTypes[regex]
    }
  }

  if (/^[a-z][a-z0-9+.-]*:/.test(path)) {
    return 'url'
  }

  return ''
}

export function isValidUrlSchemes(path: string): boolean {
  return getPathType(path)?.length > 0
}

export function isFileBasedField(fieldName: string) {
  return ['services|0.files', 'eula', 'links'].includes(fieldName)
}

export function checkHasSampleFile(additionalInformation: any): boolean {
  return additionalInformation?.links?.[0]?.url
}

export function checkIsGoogleDriveUrl(value?: string): boolean {
  if (!value) return false
  for (const p of GOOGLE_DRIVE_URL_PATTERN) if (value?.includes(p)) return true
  return false
}

export function hasValue(item: any): boolean {
  return item !== null
}
