import { FormPublishData } from 'src/components/Publish/_types'
import { downloadAsset } from '../../.jest/__fixtures__/downloadDatasetWithAccessDetails'
import { values } from '../../.jest/__fixtures__/formPublishData'
import { AdvancedSettingsForm } from '../models/FormEditCredential'
import {
  fancyGetFilesEncrypted,
  fancyPrepareEditAsset,
  transformAdvancedSettingFormToAsset,
  fancyPrepareUpdatedMetadata
} from './fancyAssetConvertor'

// mock the isEncryptUrl, getFileEncryptRequestData function
jest.mock('src/components/Publish/_utils', () => ({
  isEncryptUrl: jest.fn(),
  getFileEncryptRequestData: jest.fn()
}))
// mock the getEncryptedFiles function
jest.mock('./provider', () => ({
  getEncryptedFiles: jest
    .fn()
    .mockReturnValue(Promise.resolve('encrypted file'))
}))

describe('fancyGetFilesEncrypted', () => {
  it('should return Undefined when files is string', async () => {
    values.services[0].files = 'A string' as any
    const filesEncrypted = await fancyGetFilesEncrypted(
      values,
      downloadAsset.nftAddress,
      downloadAsset.datatokens[0].address
    )
    expect(filesEncrypted).toBeUndefined()
  })

  it('should return Undefined when files undefined', async () => {
    values.services[0].files = undefined
    const nftAddress = 'nftAddress'
    const datatokenAddress = 'datatokenAddress'
    const result = await fancyGetFilesEncrypted(
      values,
      nftAddress,
      datatokenAddress
    )
    expect(result).toBeUndefined()
  })

  it('should return false when files is not valid', async () => {
    values.services[0].files = [
      {
        url: 'Not-an-encrypted-URL.com',
        valid: false
      }
    ]
    const nftAddress = 'nftAddress'
    const datatokenAddress = 'datatokenAddress'
    const result = await fancyGetFilesEncrypted(
      values,
      nftAddress,
      datatokenAddress
    )
    expect(result).toBe(false)
  })

  it('should return encrypted files', async () => {
    const nftAddress = 'nftAddress'
    const datatokenAddress = 'datatokenAddress'
    values.services[0].files = [
      {
        url: 'some-test-link.com/encrypted.enc',
        valid: true
      }
    ]

    const result = await fancyGetFilesEncrypted(
      values,
      nftAddress,
      datatokenAddress
    )
    expect(result).toEqual('encrypted file')
  })
})

describe('fancyPrepareEditAsset', () => {
  it('should return same value for name description metadata etc', async () => {
    const edittedValues = { ...values }
    edittedValues.metadata.name = '      new nAme    '
    edittedValues.metadata.description = 'description without whitespace'
    edittedValues.services[0].description = '  description with white spaces '
    const theValues = fancyPrepareEditAsset(
      downloadAsset,
      edittedValues,
      values
    )

    expect(theValues.metadata.description).toEqual(
      edittedValues.metadata.description
    )
    expect(theValues.services[0].description).toEqual(
      edittedValues.services[0].description
    )
    expect(theValues.metadata.name).toEqual(edittedValues.metadata.name)
  })

  it('should return undefined previousServiceEndpoint when provider never updated before', async () => {
    const edittedValues = { ...values }
    const theValues = fancyPrepareEditAsset(
      downloadAsset,
      edittedValues,
      values
    )
    expect(theValues.services[0].providerUrl.url).toEqual(
      downloadAsset.services[0].serviceEndpoint
    )
    expect(
      theValues.services[0].additionalInformation?.previousServiceEndpoints
    ).toEqual(undefined)
  })

  it('should return history of previousServiceEndpoint in array string', async () => {
    const edittedValues = { ...values }
    edittedValues.providerName = 'This is new providerName' // provider update
    const theValues = fancyPrepareEditAsset(
      downloadAsset,
      edittedValues,
      values
    )
    expect(theValues.services[0].providerUrl.url).toEqual(undefined) // expected undefined as no inMemoryProviderUrl exist
    expect(
      theValues.services[0].additionalInformation?.previousServiceEndpoints
    ).toEqual([downloadAsset.services[0].serviceEndpoint])
  })
})

describe('fancyPrepareUpdatedMetadata', () => {
  it('should return updated asset Metadata name and description', async () => {
    values.metadata.name = 'New Updated name'
    values.metadata.description = 'New Updated description'
    const updatedMetadata = await fancyPrepareUpdatedMetadata(
      downloadAsset,
      values
    )
    expect(updatedMetadata.name).toEqual(values.metadata.name)
    expect(updatedMetadata.description).toEqual(values.metadata.description)
  })

  it('should return updated asset Metadata tags', async () => {
    values.metadata.tags = ['tag1', 'tag2', 'tag3', 'updated with 4 tag!']
    const updatedMetadata = await fancyPrepareUpdatedMetadata(
      downloadAsset,
      values
    )
    expect(updatedMetadata.tags).toEqual(values.metadata.tags)
  })

  it('should return updated asset Metadata all empty', async () => {
    values.metadata.name = ''
    values.metadata.description = ''
    values.metadata.tags = []
    const updatedMetadata = await fancyPrepareUpdatedMetadata(
      downloadAsset,
      values
    )
    expect(updatedMetadata.name).toEqual(values.metadata.name)
    expect(updatedMetadata.description).toEqual(values.metadata.description)
    expect(updatedMetadata.tags).toEqual(values.metadata.tags)
  })
})

describe('transformAdvancedSettingFormToAsset', () => {
  it('should custom accessPermission with allow deny list', async () => {
    const mockValues: Partial<AdvancedSettingsForm> = {
      allow: [
        {
          type: 'address',
          values: ['0xae28aa182bf02021914f192eabe3a036520c9273']
        },
        {
          type: 'domain',
          values: ['daimler.com']
        }
      ],
      deny: [
        {
          type: 'domain',
          values: ['magic.com']
        }
      ],
      accessPermission: 'Custom'
    }
    const transformedAsset = transformAdvancedSettingFormToAsset(
      mockValues,
      downloadAsset
    )
    expect((transformedAsset.credentials.allow = mockValues.allow))
    expect((transformedAsset.credentials.deny = mockValues.deny))
    expect(
      (transformedAsset.metadata.additionalInformation.accessPermission =
        mockValues.accessPermission)
    )
  })

  it('should allow all accessPermission', async () => {
    const mockValues: Partial<AdvancedSettingsForm> = {
      allow: [],
      deny: [],
      accessPermission: 'allow'
    }
    const transformedAsset = transformAdvancedSettingFormToAsset(
      mockValues,
      downloadAsset
    )
    expect(transformedAsset.credentials.allow).toEqual(mockValues.allow)
    expect(transformedAsset.credentials.deny).toEqual(mockValues.deny)
    expect(
      (transformedAsset.metadata.additionalInformation.accessPermission =
        mockValues.accessPermission)
    )
  })

  it('should deny all accessPermission', async () => {
    const mockValues: Partial<AdvancedSettingsForm> = {
      allow: [
        {
          type: 'address',
          // Owner address:
          values: [downloadAsset.nft.owner]
        }
      ],
      deny: [],
      accessPermission: 'deny'
    }
    const transformedAsset = transformAdvancedSettingFormToAsset(
      mockValues,
      downloadAsset
    )
    expect(transformedAsset.credentials.allow).toEqual(mockValues.allow)
    expect(transformedAsset.credentials.deny).toEqual(mockValues.deny)
    expect(
      transformedAsset.metadata.additionalInformation.accessPermission
    ).toEqual(mockValues.accessPermission)
  })
})
