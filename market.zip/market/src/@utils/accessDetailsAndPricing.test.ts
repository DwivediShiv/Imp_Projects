import { mockAssetMetadata } from '../../.jest/__fixtures__/sales'
import { mockSampleValidOrders } from '../../.jest/__fixtures__/accessDetailsAndPricing'
import {
  getProviderData,
  getValidOrdersForAssets
} from './accessDetailsAndPricing'
import { ProviderFees, Asset, Service } from '@oceanprotocol/lib'

const sampleProviderFees: ProviderFees = {
  providerFeeAddress: '0xa2006fc838e3101b82078157f83bb03b13160036',
  providerFeeToken: '0x07865c6e87b9f70255377e024ace6630c1eaa37f',
  providerFeeAmount: '0',
  providerData:
    '0x7b22656e7669726f6e6d656e74223a6e756c6c2c2274696d657374616d70223a313638323439333433312e3939313234312c2274696d656f7574223a38363430307d',
  v: '27',
  r: '0x5fc9ec3a46c8fcb822e99722567e14056501031c844b5203de853034eede5e0e',
  s: '0x364be966d67685fed8900e274d74b55f880f46f1a1bcf0ec4fdda203efce910a',
  validUntil: '0'
}

const providerFeesWithProviderDataUndefined: ProviderFees = {
  providerFeeAddress: '0xa2006fc838e3101b82078157f83bb03b13160036',
  providerFeeToken: '0x07865c6e87b9f70255377e024ace6630c1eaa37f',
  providerFeeAmount: '0',
  providerData: undefined,
  v: '28',
  r: '0x9b4eaa8340bfce083c5c4d6966f4746d8d7b59729bff7bb98454d87273d72d70',
  s: '0x76af0831a6612085b1f00af59f1dfe3e33ff2158012ee39b3d3500bca14a14f5',
  validUntil: '0'
}

const sampleOutput: ProviderData = {
  environment: null,
  timestamp: 1682493431.991241,
  timeout: 86400
}

jest.mock('./subgraph', () => {
  const actual = jest.requireActual('./subgraph')
  return {
    ...actual,
    fetchData: jest
      .fn()
      .mockResolvedValueOnce(mockSampleValidOrders)
      .mockResolvedValueOnce(mockSampleValidOrders)
      .mockRejectedValueOnce(new Error(`Error encountered`))
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(undefined)
  }
})

describe('getProviderData', () => {
  it('should return provider data', () => {
    expect(getProviderData(sampleProviderFees)).toEqual(sampleOutput)
  })

  it('should return null when provider data is undefined', () => {
    expect(getProviderData(undefined)).toBe(null)
    expect(getProviderData(providerFeesWithProviderDataUndefined)).toEqual(null)
  })
})

describe('getValidOrdersForAssets', () => {
  const mockedAsset = mockAssetMetadata.results[0] as Asset

  it('should able to get number of valid orders', async () => {
    /**
     * note that
     * 1st order timeout = 1688964844
     * 2nd order timeout = 1688972025
     * timestamp in setSystemTime multiply by 1000 to make it in milliseconds
     */

    jest.useFakeTimers().setSystemTime(1688965144 * 1000)
    let numberOfValidOrders = await getValidOrdersForAssets(mockedAsset)
    expect(numberOfValidOrders).toEqual(1)

    jest.useFakeTimers().setSystemTime(1688964744 * 1000)
    numberOfValidOrders = await getValidOrdersForAssets(mockedAsset)
    expect(numberOfValidOrders).toEqual(2)
  })

  it('should return 0 if subgraph query is failed', async () => {
    const numberOfValidOrders = await getValidOrdersForAssets(mockedAsset)
    expect(numberOfValidOrders).toEqual(0)
  })

  it('should return 0 if subgraph query returns null or undefined', async () => {
    let numberOfValidOrders = await getValidOrdersForAssets(mockedAsset)
    expect(numberOfValidOrders).toEqual(0)

    numberOfValidOrders = await getValidOrdersForAssets(mockedAsset)
    expect(numberOfValidOrders).toEqual(0)
  })

  it('should return 0 if invalid asset is passed as parameter', async () => {
    const falsyAssets = [undefined, null]
    falsyAssets.forEach(async (asset) => {
      const numberOfValidOrders = await getValidOrdersForAssets(asset)
      expect(numberOfValidOrders).toEqual(0)
    })
  })
})
