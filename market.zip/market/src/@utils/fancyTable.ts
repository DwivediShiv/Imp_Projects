export function mergeFilterSelection(
  prev: { [key: string]: boolean },
  current: { [key: string]: boolean }
): { [key: string]: boolean } {
  if (Object.keys(current).length === 0) return prev

  return { ...current, ...prev }
}
