import { mergeFilterSelection } from './fancyTable'

describe('tables column filter`s mergeFilterSelection', () => {
  it('should return prevColumn when current is empty', () => {
    const prevColumn = { a: true, b: false }
    const current = {}
    const result = mergeFilterSelection(prevColumn, current)
    expect(result).toEqual(prevColumn)
  })

  it('should merge current with prevColumn', () => {
    const prevColumn = { a: true, b: false }
    const current = { c: true, d: false }
    const result = mergeFilterSelection(prevColumn, current)
    expect(result).toEqual({ a: true, b: false, c: true, d: false })
  })

  it('should retain values from prevColumn for keys that exist in both', () => {
    const prevColumn = { a: true, b: true, c: true }
    const current = { a: false, c: false }
    const result = mergeFilterSelection(prevColumn, current)
    expect(result).toEqual({ a: true, b: true, c: true })
  })

  it('should not modify prevColumn', () => {
    const prevColumn = { a: true, b: false }
    const current = { b: true, c: true, d: false }
    const result = mergeFilterSelection(prevColumn, current)
    expect(prevColumn).toEqual({ a: true, b: false })
  })

  it('should handle negative scenario', () => {
    const prevColumn = { a: true, b: false }
    const current = { a: true, b: true }
    const result = mergeFilterSelection(prevColumn, current)
    expect(result).toEqual({ a: true, b: false })
  })
})
