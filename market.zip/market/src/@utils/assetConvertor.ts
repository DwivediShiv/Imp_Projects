import { getAccessDetailsForAssets } from './accessDetailsAndPricing'
import { PublisherTrustedAlgorithm, Asset, getHash } from '@oceanprotocol/lib'
import { AssetSelectionAsset } from '@components/@shared/fancy/molecules/AssetSelection/FancyAssetSelection'
import { getServiceByName } from './ddo'
import { getAssetsFileInfo } from './fancyConnectivity'
import { getFancyDockerHubCheckSum } from './docker'
import appConfig from '../../app.config'
import _ from 'lodash'
import { ComputeOption } from '@components/Publish/_constants'
import normalizeUrl from 'normalize-url'

export async function transformAssetToAssetSelection(
  datasetProviderEndpoint: string,
  assets: Asset[],
  selectedAlgorithms?: PublisherTrustedAlgorithm[]
): Promise<AssetSelectionAsset[]> {
  const extendedAssets: AssetExtended[] = await getAccessDetailsForAssets(
    assets
  )
  const algorithmList: AssetSelectionAsset[] = []

  for (const asset of extendedAssets) {
    const algoComputeService = getServiceByName(asset, 'compute')

    if (
      asset?.accessDetails?.type === 'free' &&
      normalizeUrl(algoComputeService?.serviceEndpoint) ===
        normalizeUrl(datasetProviderEndpoint)
    ) {
      let selected = false
      selectedAlgorithms?.forEach((algorithm: PublisherTrustedAlgorithm) => {
        if (algorithm.did === asset.id) {
          selected = true
        }
      })
      const isExperimental =
        algoComputeService?.additionalInformation?.isExperimental
      const algorithmAsset: AssetSelectionAsset = {
        did: asset.id,
        name: asset.metadata.name,
        price: asset.accessDetails?.price,
        checked: selected,
        // Fancy
        symbol: asset.datatokens[0].symbol,
        serviceEndpoint: algoComputeService?.serviceEndpoint,
        shortDescription: asset.metadata.description,
        isExperimental,
        datatoken: asset.datatokens[0]?.symbol,
        accessType: algoComputeService?.type,
        dataProvider: asset.nft?.owner
      }
      selected
        ? algorithmList.unshift(algorithmAsset)
        : algorithmList.push(algorithmAsset)
    }
  }
  return algorithmList
}

export function isCustomComputeOption(image: string, tag: string): boolean {
  const option = appConfig.computeOptions.find(
    (option: ComputeOption) =>
      option.value.image === image && option.value.tag === tag
  )
  return !option
}

export async function getAlgorithmContainerChecksum(container: {
  entrypoint: string
  image: string
  tag: string
  checksum: string
}): Promise<string> {
  if (isCustomComputeOption(container.image, container.tag)) {
    const responses = await getFancyDockerHubCheckSum(
      container.image,
      container.tag
    )
    const digest = responses?.result?.digest
    const customChecksum = digest || ''
    return customChecksum
  }
  return container.checksum
}

export function getStringifiedAlgorithmContainer(container: {
  entrypoint: string
  image: string
  tag: string
  checksum: string
}): string {
  const algorithmContainer = container.entrypoint + container.checksum
  return algorithmContainer
}

export function getPublisherTrustedAlgorithm(
  computeAsset: Asset | AssetExtended,
  algoDID: string
): PublisherTrustedAlgorithm {
  const { publisherTrustedAlgorithms } = getServiceByName(
    computeAsset,
    'compute'
  ).compute
  const result = _.find(publisherTrustedAlgorithms, function (algo) {
    if (algo.did === algoDID) {
      return algo
    }
  }) as PublisherTrustedAlgorithm
  return result
}

// TOOD : temporary solution until provider is correct, 3rd asset input
export function getIsFileChecksumValid(
  fileInfoChecksum: string,
  publisherTrustedAlgorithm: PublisherTrustedAlgorithm,
  asset?: AssetExtended
): boolean {
  // return (
  //   publisherTrustedAlgorithm.filesChecksum ===
  //   getHash(asset?.services?.[0]?.files)
  // )
  // TOOD : temporary solution until provider is correct, getHash of asset.files
  return publisherTrustedAlgorithm.filesChecksum === fileInfoChecksum
}

export function getIsAlgoContainerChecksumValid(
  algoAsset: AssetExtended,
  publisherTrustedAlgorithm: PublisherTrustedAlgorithm
): boolean {
  const algorithmContainer = getStringifiedAlgorithmContainer(
    algoAsset.metadata?.algorithm?.container
  )
  return (
    publisherTrustedAlgorithm?.containerSectionChecksum ===
    getHash(algorithmContainer)
  )
}

export function getIsAssetChecksumValid(
  algoAsset: AssetExtended,
  publisherTrustedAlgorithm: PublisherTrustedAlgorithm,
  fileInfoChecksum: string
): boolean {
  if (!publisherTrustedAlgorithm || !fileInfoChecksum) {
    return false
  }
  const isAlgoContainerChecksumValid = getIsAlgoContainerChecksumValid(
    algoAsset,
    publisherTrustedAlgorithm
  )

  return (
    isAlgoContainerChecksumValid &&
    getIsFileChecksumValid(
      fileInfoChecksum,
      publisherTrustedAlgorithm,
      algoAsset
    )
  )
}

export async function fancyTransformAssetToAssetSelection(
  datasetProviderEndpoint: string,
  assets: Asset[] | AssetExtended[],
  computeAsset: Asset,
  selectedAlgorithms?: PublisherTrustedAlgorithm[]
): Promise<AssetSelectionAsset[]> {
  const extendedAssets: AssetExtended[] = await getAccessDetailsForAssets(
    assets
  )
  const algorithmList: AssetSelectionAsset[] = []

  if (!extendedAssets?.length) return []

  const assetsFileInfoMap = await getAssetsFileInfo(assets)

  for (const asset of extendedAssets) {
    const algoComputeService = getServiceByName(asset, 'compute')
    const algoAccessService = getServiceByName(asset, 'access')
    const algoService = algoComputeService || algoAccessService
    const isCustomDocker = isCustomComputeOption(
      asset?.metadata?.algorithm?.container?.image,
      asset?.metadata?.algorithm?.container?.tag
    )
    if (
      ((asset?.accessDetails?.price || asset?.accessDetails?.type === 'free') &&
        algoService?.serviceEndpoint === datasetProviderEndpoint) ||
      algoService?.type === 'access'
    ) {
      let selected = false
      selectedAlgorithms?.forEach((algorithm: PublisherTrustedAlgorithm) => {
        if (algorithm.did === asset.id) {
          selected = true
        }
      })
      const algorithmAsset: AssetSelectionAsset = {
        did: asset.id,
        name: asset.metadata.name,
        price: asset.accessDetails?.price,
        checked: selected,
        symbol: asset.datatokens[0].symbol,
        serviceEndpoint: algoService?.serviceEndpoint,
        shortDescription: asset.metadata.description,
        isExperimental: algoService?.additionalInformation?.isExperimental,
        isCustomDocker,
        datatoken: asset.datatokens[0]?.symbol,
        accessType: algoService?.type,
        dataProvider: asset.nft?.owner,
        isValid: assetsFileInfoMap?.[asset.id]?.isConnected
      }
      const publisherTrustedAlgorithm = getPublisherTrustedAlgorithm(
        computeAsset,
        asset.id
      )
      const isValidChecksum = getIsAssetChecksumValid(
        asset,
        publisherTrustedAlgorithm,
        assetsFileInfoMap[asset.id]?.checksum
      )
      if (isValidChecksum) {
        selected
          ? algorithmList.unshift(algorithmAsset)
          : algorithmList.push(algorithmAsset)
      }
    }
  }
  return algorithmList
}
