import {
  Arweave,
  GraphqlQuery,
  ComputeAlgorithm,
  ComputeAsset,
  ComputeEnvironment,
  FileInfo as FileInfoData,
  Ipfs,
  LoggerInstance,
  ProviderComputeInitializeResults,
  ProviderInstance,
  UrlFile,
  AbiItem,
  UserCustomParameters,
  getErrorMessage,
  downloadFileBrowser,
  DDO,
  Smartcontract,
  LocalStorage,
  CloudStorageFile
} from '@oceanprotocol/lib'
import { Signer } from 'ethers'
import { getValidUntilTime } from './compute'
import { DEFAULT_DOWNLOAD_FILE_NAME } from './constants'
import { ERROR_UNREACHABLE_ENDPOINT } from 'src/components/pages/Constants'
import { getAccessDetails } from './accessDetailsAndPricing'

import { checkEndpointAvailability, isQueryParamDefined } from './url'
import { asyncRequest } from './requestHelper'

export interface FancyFilesInfoResult {
  did: string
  result: FileInfoData
}

export interface FancyFilesInfoBody {
  did: string
  serviceId: string
  providerUri: string
  checksum?: boolean
}

export const PROVIDER_URL_KEY = 'providerUrl'

export async function initializeProviderForCompute(
  dataset: AssetExtended,
  algorithm: AssetExtended,
  accountId: string,
  computeEnv: ComputeEnvironment = null
): Promise<ProviderComputeInitializeResults> {
  const computeAsset: ComputeAsset = {
    documentId: dataset.id,
    serviceId: dataset.services[0].id,
    transferTxId: dataset.accessDetails?.validOrderTx
  }
  const computeAlgo: ComputeAlgorithm = {
    documentId: algorithm.id,
    serviceId: algorithm.services[0].id,
    transferTxId: algorithm.accessDetails?.validOrderTx
  }

  const validUntil = getValidUntilTime(
    computeEnv?.maxJobDuration,
    dataset.services[0].timeout,
    algorithm.services[0].timeout
  )

  try {
    return await ProviderInstance.initializeCompute(
      [computeAsset],
      computeAlgo,
      computeEnv?.id,
      validUntil,
      dataset.services[0].serviceEndpoint,
      accountId
    )
  } catch (error) {
    const message = getErrorMessage(error.message)
    LoggerInstance.error('[Initialize Provider] Error:', message)
    return null
  }
}

// TODO: Why do we have these one line functions ?!?!?!
export async function getEncryptedFiles(
  files: any,
  chainId: number,
  providerUrl: string
): Promise<string> {
  try {
    // https://github.com/oceanprotocol/provider/blob/v4main/API.md#encrypt-endpoint
    const response = await ProviderInstance.encrypt(files, chainId, providerUrl)
    return response
  } catch (error) {
    const message = getErrorMessage(error.message)
    LoggerInstance.error('[Provider Encrypt] Error:', message)
  }
}

function fancyKeyMapUriToBatch(assetList: DDO[], checksum: boolean) {
  const result: Record<string, FancyFilesInfoBody[]> = {}

  for (const asset of assetList) {
    if (!asset?.id) {
      continue
    }

    const item: FancyFilesInfoBody = {
      did: asset.id,
      serviceId: asset?.services[0]?.id,
      providerUri: asset.services?.[0]?.serviceEndpoint,
      checksum
    }
    const key = item.providerUri
    if (!result[key]) {
      result[key] = [item]
      continue
    }
    result[key].push(item)
  }
  return result
}

export async function fancyCheckDidFilesBatch(
  assetList: DDO[],
  signal?: AbortSignal,
  checksum = false
): Promise<FancyFilesInfoResult[]> {
  const setOfRequest = fancyKeyMapUriToBatch(assetList, checksum)
  const path = '/api/services/filesinfo'
  const filesPromises: Promise<FancyFilesInfoResult | null>[] = []

  // Check endpoint availability for all provider URIs simultaneously
  const availabilityPromises = Object.keys(setOfRequest).map((providerUri) => {
    return checkEndpointAvailability(providerUri, signal)
  })
  const availableProviders = await Promise.all(availabilityPromises)

  // Loop each providerUri and create promise only for available endpoints (fires simultaneously)
  for (const [providerUri, args] of Object.entries(setOfRequest)) {
    const index = Object.keys(setOfRequest).indexOf(providerUri)
    if (availableProviders[index]) {
      const fetchPromise = new Promise<FancyFilesInfoResult | null>(
        (resolve, reject) => {
          try {
            const responseData = asyncRequest(
              'POST',
              `${providerUri}/${path}`,
              { files: args },
              'Error occurred while making request.',
              200,
              false,
              { 'Content-Type': 'application/json' },
              undefined,
              signal,
              false
            )
            resolve(responseData as unknown as FancyFilesInfoResult)
          } catch (error) {
            console.error('Error occurred while making request:', error.message)
            reject(error)
          }
        }
      )
      filesPromises.push(fetchPromise)
    } else {
      console.error('Endpoint is not available:', providerUri)
    }
  }

  // Wait for all promises to resolve or timeout
  const filesResults = await Promise.all(
    filesPromises.map((p) => p.catch((e) => null))
  )

  // Filter out null results for failed requests
  const files = filesResults.filter(
    (result) => result !== null
  ) as FancyFilesInfoResult[]

  return files.flat()
}

export async function getFileDidInfo(
  did: string,
  serviceId: string,
  providerUrl: string,
  signal?: AbortSignal,
  withChecksum = false
): Promise<FileInfoData[]> {
  try {
    const response = await ProviderInstance.checkDidFiles(
      did,
      serviceId,
      providerUrl,
      withChecksum,
      signal
    )
    return response
  } catch (error) {
    LoggerInstance.error(error.message)
  }
}

export async function getFileInfo(
  file: string,
  providerUrl: string,
  signal?: AbortSignal,
  headers?: { [key: string]: string },
  withChecksum = false,
  query?: string,
  abi?: string,
  chainId?: number,
  method?: string,
  storageType = 'url'
): Promise<FileInfoData[]> {
  let response
  const headersProvider = headers
  // if (headers?.length > 0) {
  //   headers.map((el) => {
  //     headersProvider[el.key] = el.value
  //     return el
  //   })
  // }

  switch (storageType) {
    case 'ipfs': {
      const fileIPFS: Ipfs = {
        type: storageType,
        hash: file
      }
      try {
        response = await ProviderInstance.getFileInfo(fileIPFS, providerUrl)
      } catch (error) {
        const message = getErrorMessage(error.message)
        LoggerInstance.error('[Provider Get File info] Error:', message)
      }
      break
    }
    case 'arweave': {
      const fileArweave: Arweave = {
        type: storageType,
        transactionId: file
      }
      try {
        response = await ProviderInstance.getFileInfo(fileArweave, providerUrl)
      } catch (error) {
        const message = getErrorMessage(error.message)
        LoggerInstance.error('[Provider Get File info] Error:', message)
      }
      break
    }
    case 'graphql': {
      const fileGraphql: GraphqlQuery = {
        type: storageType,
        url: file,
        headers: headersProvider,
        query
      }
      try {
        response = await ProviderInstance.getFileInfo(fileGraphql, providerUrl)
      } catch (error) {
        const message = getErrorMessage(error.message)
        LoggerInstance.error('[Provider Get File info] Error:', message)
      }
      break
    }
    case 'smartcontract': {
      // clean obj
      const fileSmartContract: Smartcontract = {
        chainId,
        type: storageType,
        address: file,
        abi: JSON.parse(abi) as AbiItem
      }
      try {
        response = await ProviderInstance.getFileInfo(
          fileSmartContract,
          providerUrl
        )
      } catch (error) {
        const message = getErrorMessage(error.message)
        LoggerInstance.error('[Provider Get File info] Error:', message)
      }
      break
    }
    case 'localstorage': {
      const localFile: LocalStorage = {
        type: 'localstorage',
        index: 0,
        url: file,
        headers: headersProvider,
        method
      }
      try {
        response = await ProviderInstance.getFileInfo(
          localFile,
          providerUrl,
          withChecksum,
          signal
        )
      } catch (error) {
        const message = getErrorMessage(error.message)
        LoggerInstance.error('[Provider Get File info] Error:', message)
      }
      break
    }
    case 's3': {
      const localFile: CloudStorageFile = {
        type: 's3',
        index: 0,
        url: file,
        headers: headersProvider,
        method
      }
      try {
        response = await ProviderInstance.getFileInfo(
          localFile,
          providerUrl,
          withChecksum,
          signal
        )
      } catch (error) {
        const message = getErrorMessage(error.message)
        LoggerInstance.error('[Provider Get File info] Error:', message)
      }
      break
    }
    default: {
      const fileUrl: UrlFile = {
        type: 'url',
        index: 0,
        url: file,
        headers: headersProvider,
        method
      }
      try {
        response = await ProviderInstance.getFileInfo(
          fileUrl,
          providerUrl,
          withChecksum,
          signal
        )
      } catch (error) {
        const message = getErrorMessage(error.message)
        LoggerInstance.error('[Provider Get File info] Error:', message)
      }
      break
    }
  }
  return response
}
// Kris: copied from Ocean.js `downloadFileBrowser` to add default fileName - src/utils/FetchHelper.ts
// Saransh: improved function to handle large file download upto 10GB, as xhr doesn't support that.
export async function fancyDownloadFileBrowser(url: string): Promise<void> {
  const headResponse = await fetch(url, { method: 'HEAD' })
  const contentHeader = headResponse.headers.get('content-disposition')
  if (!headResponse.ok) {
    throw new Error(ERROR_UNREACHABLE_ENDPOINT)
  }
  let fileName = contentHeader.split('=')[1]
  if (!fileName || fileName === '?') fileName = DEFAULT_DOWNLOAD_FILE_NAME

  // const xhr = new XMLHttpRequest()
  // xhr.responseType = 'blob'
  // xhr.open('GET', url)
  // xhr.onload = () => {
  //   const blobURL = window.URL.createObjectURL(xhr.response)
  //   const a = document.createElement('a')
  //   a.href = blobURL
  //   a.setAttribute('download', fileName)
  //   document.body.appendChild(a)
  //   a.click()
  //   a.remove()
  //   window.URL.revokeObjectURL(blobURL)
  // }
  // xhr.send(null)

  const a = document.createElement('a')
  a.href = url
  a.setAttribute('download', fileName)
  document.body.appendChild(a)
  a.click()
  a.remove()
}
export async function downloadFile(
  signer: Signer,
  asset: AssetExtended,
  accountId: string,
  validOrderTx?: string,
  userCustomParameters?: UserCustomParameters,
  signal?: AbortSignal
): Promise<any> {
  let downloadUrl
  try {
    downloadUrl = await ProviderInstance.getDownloadUrl(
      asset.id,
      asset.services[0].id,
      0,
      validOrderTx || asset.accessDetails.validOrderTx,
      asset.services[0].serviceEndpoint,
      signer,
      userCustomParameters
    )
    if (signal?.aborted) return
    if (isQueryParamDefined(downloadUrl)) {
      await downloadFileBrowser(downloadUrl)
    } else {
      throw new Error(ERROR_UNREACHABLE_ENDPOINT)
    }
  } catch (error) {
    const message = getErrorMessage(error.message)
    LoggerInstance.error('[Provider Get download url] Error:', message)
    return error
  }
}

export async function checkValidProvider(
  providerUrl: string
): Promise<boolean> {
  try {
    const response = await ProviderInstance.isValidProvider(providerUrl)
    return response
  } catch (error) {
    const message = getErrorMessage(error.message)
    LoggerInstance.error('[Provider Check] Error:', message)
  }
}
