import { utils } from 'xlsx'

export function exportToCsv(formattedData: any[], fileName) {
  if (!formattedData || formattedData?.length < 1 || !fileName) return
  const worksheet = utils.json_to_sheet(formattedData)
  const csv = utils.sheet_to_csv(worksheet, { forceQuotes: true })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(
    new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  )
  link.setAttribute('download', `${fileName}.csv`)
  link.click()
  link.remove()
}
