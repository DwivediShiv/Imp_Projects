import { mockConnectivityDdo } from '../../.jest/__fixtures__/fancyConnectivity'
import { getAssetsConnectivity } from './fancyConnectivity'
import { fancyCheckDidFilesBatch, FancyFilesInfoResult } from './provider'

jest.mock('./provider')

describe('getAssetsConnectivity', () => {
  it('should return an empty object when given an empty array', async () => {
    const ddos = []
    const abortController = new AbortController()
    const result = await getAssetsConnectivity(ddos, abortController.signal)
    expect(result).toEqual({})
  })

  it('should return an object with boolean values for each DDO', async () => {
    const expectedOutput = [
      {
        did: 'did:op:25903c631a67dfcc2715004e17db882ab98ec064d31b42b21f4e33e4e6e4be09',
        result: {
          contentLength: '463044',
          contentType: 'text/plain',
          index: 0,
          type: 'url',
          valid: true
        }
      },
      {
        did: 'did:op:bf097bec4b15c60f7a92e8566706aca8785089a9c8a6b2d9f52f2ebd80a1b0d1',
        result: {
          index: 0,
          type: 'url',
          valid: false
        }
      },
      {
        did: 'did:op:76dace005ac6af72f6f634a7e2190f3d17b3587fd306bd5d09e3ca49d896462b',
        result: {
          contentLength: '424369',
          contentType: 'text/plain',
          index: 0,
          type: 'url',
          valid: true
        }
      }
    ] as FancyFilesInfoResult[]
    const abortController = new AbortController()
    jest
      .spyOn({ fancyCheckDidFilesBatch }, 'fancyCheckDidFilesBatch')
      .mockResolvedValue(expectedOutput)
    const result = await getAssetsConnectivity(
      mockConnectivityDdo,
      abortController.signal
    )
    expect(result).toEqual({
      'did:op:25903c631a67dfcc2715004e17db882ab98ec064d31b42b21f4e33e4e6e4be09':
        true,
      'did:op:bf097bec4b15c60f7a92e8566706aca8785089a9c8a6b2d9f52f2ebd80a1b0d1':
        false,
      'did:op:76dace005ac6af72f6f634a7e2190f3d17b3587fd306bd5d09e3ca49d896462b':
        true
    })
  })
})
