export function abortRequests(eventAbortControllers: AbortController[]) {
  for (const abortControllers of Object.values(
    eventAbortControllers
  ) as AbortController[]) {
    abortControllers.abort()
  }
}
