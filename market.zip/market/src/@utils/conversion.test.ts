import {
  megaByteToByte,
  byteToMegaByte,
  megaByteIndication,
  getMegaByte,
  durationToNowInTimestamp,
  durationToNow,
  getFileTypeWithoutCharset,
  convertSnakeToCamel,
  convertObjectToType,
  convertToThreeNonZeroDecimal,
  truncateEnding,
  safeConvertToNumber,
  convertArrayToLowerCase,
  formatPriceUnit,
  formatBytes,
  formatCurrency
} from './conversion'
import { secondsToString } from './metadata'
import { falsyValues } from '../../.jest/__fixtures__/mockUtils'

const sampleObject = { name: 'John', age: 30, email: 'john@example.com' }

describe('conversion', () => {
  it('should convert mega bytes to bytes', () => {
    const bytes = megaByteToByte('2')
    expect(bytes).toEqual(2097152)
  })

  it('should convert byte to mega bytes', () => {
    const megaByte = byteToMegaByte('2097152')
    expect(megaByte).toEqual(2)
  })

  it('should convert byte to mega byte with empty string', () => {
    const megaByte = byteToMegaByte('')
    expect(megaByte).toEqual('')
  })

  it('should return the input string when given a non-numeric string', () => {
    const result = byteToMegaByte('not a number')
    expect(result).toBeNaN()
  })

  it('should get mega byte indication', () => {
    const mbSize = megaByteIndication('2097152')
    expect(mbSize).toEqual('<25')
  })

  it('should get mega byte indication with parameter of float string value', () => {
    const testData = 27.565 * Math.pow(1024, 2)
    const mbSize = megaByteIndication(testData.toString())
    expect(mbSize).toEqual('27.56')
  })

  it('should get mega byte', () => {
    const testData = 27.565 * Math.pow(1024, 2)
    const megabyte = getMegaByte(testData.toString())
    expect(megabyte).toEqual('27.56')
  })

  it('should return the input if byteToMegaByte returns non-number', () => {
    const result = getMegaByte('not a valid size')
    expect(result).toBe('NaN')
  })

  it('should get the duration to now in timestamp format', () => {
    const timestamp = durationToNowInTimestamp(new Date().toString())
    expect(timestamp).toBeGreaterThanOrEqual(0)
  })

  it('should return the number of seconds between the input date and now', () => {
    const result = durationToNowInTimestamp('2023-01-01T00:00:00.000Z')
    const expected = Math.round(
      (new Date().getTime() - new Date('2023-01-01T00:00:00.000Z').getTime()) /
        1000
    )
    expect(result).toBe(expected)
  })

  it('should return NaN when given an invalid date string', () => {
    const input = 'not a date'
    const result = durationToNowInTimestamp(input)
    expect(result).toBeNaN()
  })

  it('should return the duration to now in human readable format', () => {
    const currentTimestamp = new Date().getTime()
    const pastDate = new Date(currentTimestamp - 7 * 60 * 1000).toISOString() // 7 minutes ago
    expect(durationToNow(pastDate)).toEqual('7 minute(s)')
  })

  it('should get the duration differ from the date provided', () => {
    const currentTimestamp = new Date().getTime()
    const pastDate = new Date(currentTimestamp - 60 * 60 * 1000).toISOString() // an hour ago
    expect(secondsToString(durationToNowInTimestamp(pastDate))).toEqual(
      '1 hour(s)'
    )
  })

  it('should return a file type without charset', () => {
    const fileTypeResult = getFileTypeWithoutCharset('text/plain;')
    expect(fileTypeResult).toEqual('text/plain')
  })

  it('should return undefined when no value provided', () => {
    const fileTypeResult = getFileTypeWithoutCharset(null)
    expect(fileTypeResult).toBeUndefined()
  })

  it('should convert snake_case keys to camelCase keys', () => {
    const input = { user_id: 1, first_name: 'John', last_name: 'Doe' }
    const result = convertSnakeToCamel(input)
    expect(result).toEqual({ userId: 1, firstName: 'John', lastName: 'Doe' })
  })

  it('should return an object with the same values when given an object with no snake_case keys', () => {
    const input = { userId: 1, firstName: 'John', lastName: 'Doe' }
    const result = convertSnakeToCamel(input)
    expect(result).toEqual(input)
  })

  it('should return an empty object when given an empty object', () => {
    const input = {}
    const result = convertSnakeToCamel(input)
    expect(result).toEqual({})
  })

  it('should convert an object to the specified type', () => {
    interface MyType {
      name: string
      age: number
      email: string
    }
    const result = convertObjectToType<MyType>(sampleObject)
    expect(result).toEqual(sampleObject)
  })

  it('should not modify the original object', () => {
    const result = convertObjectToType<any>(sampleObject)
    expect(result).toEqual(sampleObject)
    expect(result).not.toBe(sampleObject)
  })

  it('should return a string with up to 3 non-zero decimals', () => {
    const input = 1.23456789
    const result = convertToThreeNonZeroDecimal(input)
    expect(result).toEqual('1.234')
  })

  it('should return "0" when given a falsy value', () => {
    falsyValues.forEach((value: number) => {
      const result = convertToThreeNonZeroDecimal(value)
      expect(result).toEqual('0')
    })
  })

  it('should return the text if it is shorter than the length argument', () => {
    const input = 'Hello, world!'
    const result = truncateEnding(input, input.length + 1)
    expect(result).toEqual(input)
  })

  it('should truncate the text if it is longer than the length argument', () => {
    const result = truncateEnding('Hello, world!', 5)
    expect(result).toEqual('Hello...')
  })

  it('should add ellipsis to the end of truncated text', () => {
    const result = truncateEnding('Hello, world!', 5)
    expect(result).toMatch(/\.{3}$/)
  })

  it('should return undefined if the length argument is falsy', () => {
    falsyValues.forEach((value: number) => {
      const result = truncateEnding('Hello, world!', value)
      expect(result).toBeUndefined()
    })
  })

  it('should return 0 for falsy input', () => {
    falsyValues.forEach((value: any) => {
      const result = safeConvertToNumber(value)
      expect(result).toEqual(0)
    })
  })

  it('should convert string input to number', () => {
    const result = safeConvertToNumber('123.45')
    expect(result).toEqual(123.45)
  })

  it('should return 0 for invalid string input', () => {
    const result = safeConvertToNumber('not a number')
    expect(result).toBeNaN()
  })

  it('should return an empty array for empty input', () => {
    const input: string[] = []
    const result = convertArrayToLowerCase(input)
    expect(result).toEqual([])
  })

  it('should convert array of strings to lower case', () => {
    const result = convertArrayToLowerCase(['APPLE', 'BANANA', 'CHERRY'])
    expect(result).toEqual(['apple', 'banana', 'cherry'])
  })

  it('should return the same array if none of elements is empty or undefined', () => {
    const result = convertArrayToLowerCase(['apple', 'Banana', 'CHERry'])
    expect(result).toEqual(['apple', 'banana', 'cherry'])
  })

  it('should handle null and undefined elements in the input array', () => {
    const result = convertArrayToLowerCase([
      'aPple',
      null,
      'banana',
      undefined,
      'Cherry'
    ])
    expect(result).toEqual(
      ['apple', null, 'banana', undefined, 'cherry'].map((s) =>
        s?.toLowerCase()
      )
    )
  })

  it('should format numbers less than a billion without suffix', () => {
    expect(formatPriceUnit(500000)).toBe('500,000')
    expect(formatPriceUnit(999999999)).toBe('999,999,999')
  })

  it('should format numbers between a billion and a trillion with "billion" suffix', () => {
    expect(formatPriceUnit(1000000000)).toBe('1 billion')
    expect(formatPriceUnit(1500000000)).toBe('1.5 billion')
  })

  it('should format numbers equal to or greater than a trillion with "trillion" suffix', () => {
    expect(formatPriceUnit(1000000000000)).toBe('1 trillion')
    expect(formatPriceUnit(2500000000000)).toBe('2.5 trillion')
  })

  it('should correctly handle string inputs that can be converted to numbers', () => {
    expect(formatPriceUnit('1000000')).toBe('1,000,000')
    expect(formatPriceUnit('2000000000')).toBe('2 billion')
  })

  it('should correctly format decimal numbers less than a billion and remove trailing zeros', () => {
    expect(formatPriceUnit(123456.78)).toBe('123,456.78')
    expect(formatPriceUnit(987654.0)).toBe('987,654')
  })

  it('should limit decimal places to a maximum of 6 for numbers less than a billion', () => {
    expect(formatPriceUnit(123.456789123)).toBe('123.456789')
    expect(formatPriceUnit(0.123456789)).toBe('0.123457')
  })

  // eslint complain, increase precision by parseFloat @typescript-eslint/no-loss-of-precision
  it('should limit decimal places to a maximum of 6 for numbers between a billion and a trillion', () => {
    expect(formatPriceUnit(parseFloat('1234567890.123456789'))).toBe(
      '1.234568 billion'
    )
    expect(formatPriceUnit(parseFloat('1500000000.123456789'))).toBe(
      '1.5 billion'
    )
  })

  it('should limit decimal places to a maximum of 6 for numbers equal to or greater than a trillion', () => {
    expect(formatPriceUnit(parseFloat('1000000000000.123456789'))).toBe(
      '1 trillion'
    )
    expect(formatPriceUnit(parseFloat('2500000000000.987654321'))).toBe(
      '2.5 trillion'
    )
  })

  it('should format billions correctly', () => {
    expect(formatPriceUnit('2500000000.123456789')).toBe('2.5 billion')
    expect(formatPriceUnit('4800000000.987654321')).toBe('4.8 billion')
    expect(formatPriceUnit('6000000000.000001')).toBe('6 billion')
    expect(formatPriceUnit('15750000000.987654321')).toBe('15.75 billion')
    expect(formatPriceUnit('999999999.999999999')).toBe('1 billion')
    expect(formatPriceUnit('1000000000.000000000')).toBe('1 billion')
  })

  it('should format trillions correctly', () => {
    expect(formatPriceUnit('2500000000000.123456789')).toBe('2.5 trillion')
    expect(formatPriceUnit('4800000000000.987654321')).toBe('4.8 trillion')
    expect(formatPriceUnit('6000000000000.000001')).toBe('6 trillion')
    expect(formatPriceUnit('15750000000000.987654321')).toBe('15.75 trillion')
    expect(formatPriceUnit('1000000000000.000000000')).toBe('1 trillion')
    expect(formatPriceUnit('999999999999.999999999')).toBe('1 trillion')
  })

  it('should handle values less than a billion', () => {
    expect(formatPriceUnit('0')).toBe('0')
    expect(formatPriceUnit('0.000000001')).toBe('0')
    expect(formatPriceUnit('999999999')).toBe('999,999,999')
    expect(formatPriceUnit('999999999.000000001')).toBe('999,999,999')
    expect(formatPriceUnit('799999999.000000001')).toBe('799,999,999')
    expect(formatPriceUnit('799999999.123456789')).toBe('799,999,999.123457')
    expect(formatPriceUnit('1.1234567')).toBe('1.123457')
    expect(formatPriceUnit('1.1234563')).toBe('1.123456')
    expect(formatPriceUnit('1.120000')).toBe('1.12')
  })

  it('should format smaller values (0 to 10)', () => {
    expect(formatPriceUnit('0.001234567')).toBe('0.001235')
    expect(formatPriceUnit('0.012345678')).toBe('0.012346')
    expect(formatPriceUnit('0.123456789')).toBe('0.123457')
    expect(formatPriceUnit('1')).toBe('1')
    expect(formatPriceUnit('2.345')).toBe('2.345')
    expect(formatPriceUnit('5.67890')).toBe('5.6789')
    expect(formatPriceUnit('7.123456')).toBe('7.123456')
    expect(formatPriceUnit('10')).toBe('10')
  })

  it('should handle numbers and formatted strings', () => {
    expect(formatPriceUnit(0)).toBe('0')
    expect(formatPriceUnit(0.000000001)).toBe('0')
    expect(formatPriceUnit('999,999,999')).toBe('999,999,999')
  })
})

describe('formatBytes', () => {
  it('should return "0 B" for 0 bytes', () => {
    expect(formatBytes(0)).toBe('0 B')
  })

  it('should format bytes correctly', () => {
    expect(formatBytes(1023)).toBe('1,023 B')
    expect(formatBytes(1024)).toBe('1 KB')
    expect(formatBytes(1048576)).toBe('1 MB')
    expect(formatBytes(1073741824)).toBe('1 GB')
    expect(formatBytes(1099511627776)).toBe('1 TB')
    expect(formatBytes(1125899906842624)).toBe('1 PB')
    expect(formatBytes(1152921504606846976)).toBe('1 EB')
    expect(formatBytes(1180591620717411303424)).toBe('1 ZB')
    expect(formatBytes(1208925819614629174706176)).toBe('1 YB')
  })

  it('should handle non-integer values', () => {
    expect(formatBytes(1536)).toBe('1.5 KB')
    expect(formatBytes(1572864)).toBe('1.5 MB')
    expect(formatBytes(1610612736)).toBe('1.5 GB')
  })

  it('should round and format correctly', () => {
    expect(formatBytes(123456789)).toBe('117.7 MB')
    expect(formatBytes(9876543210)).toBe('9.2 GB')
  })

  it('should handle edge cases near boundaries', () => {
    expect(formatBytes(1023)).toBe('1,023 B')
    expect(formatBytes(1024)).toBe('1 KB')
    expect(formatBytes(1025)).toBe('1 KB')
  })
})

describe('formatCurrency', () => {
  it('should format values in the trillions correctly', () => {
    expect(formatCurrency(1500000000000)).toBe('1.5 Trillion')
    expect(formatCurrency(1000000000000)).toBe('1 Trillion')
    expect(formatCurrency(1234567890123)).toBe('1.2 Trillion')
  })

  it('should format values in the billions correctly', () => {
    expect(formatCurrency(2500000000)).toBe('2.5 Billion')
    expect(formatCurrency(1000000000)).toBe('1 Billion')
    expect(formatCurrency(9876543210)).toBe('9.9 Billion')
  })

  it('should format values in the millions correctly', () => {
    expect(formatCurrency(7500000)).toBe('7,500,000')
    expect(formatCurrency(1000000)).toBe('1,000,000')
    expect(formatCurrency(1234567)).toBe('1,234,567')
  })

  it('should format values in the thousands correctly', () => {
    expect(formatCurrency(2500)).toBe('2,500')
    expect(formatCurrency(1000)).toBe('1,000')
    expect(formatCurrency(9876)).toBe('9,876')
  })

  it('should format values less than a thousand correctly', () => {
    expect(formatCurrency(123.45)).toBe('123.5')
    expect(formatCurrency(50)).toBe('50')
    expect(formatCurrency(999.99)).toBe('1,000')
  })

  it('should handle edge cases correctly', () => {
    expect(formatCurrency(999999999999.9)).toBe('1 Trillion')
    expect(formatCurrency(999999999.9)).toBe('999,999,999.9')
    expect(formatCurrency(999999.9)).toBe('999,999.9')
    expect(formatCurrency(999.9)).toBe('999.9')
  })
})
