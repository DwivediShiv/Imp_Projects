import { getUserProfileFromMap, getUserProfileMap } from './keycloakProfile'
import axios from 'axios'
import {
  mockProfiles,
  mockPayers,
  mockProfileMap,
  mercedesGroup
} from '../../.jest/__fixtures__/sales'

jest.mock('axios')
const mockedAxios = axios as jest.MockedFunction<typeof axios>

const sampleResponse = {
  data: mockProfiles
}
const payerList = Object.values(mockPayers)
const targetPayer = mockPayers[mercedesGroup]

describe('getUserProfileMap', () => {
  it('should get empty map if falsy account ids or empty account ids is passed', async () => {
    const falsyAccountIds = [undefined, null, []]
    for (let i = 0; i < falsyAccountIds.length; i++) {
      const result = await getUserProfileMap(falsyAccountIds[i])
      expect(result).toEqual(new Map())
    }
  })

  it('should get empty map if api call is failed', async () => {
    mockedAxios.mockRejectedValueOnce(new Error('Request failed.'))
    let result = await getUserProfileMap(payerList)
    expect.hasAssertions()
    expect(result).toEqual(new Map())

    // Error code: 400
    let mockProblematicResponse = {
      data: {},
      status: 400,
      statusText: '',
      config: {},
      headers: {}
    }
    mockedAxios.mockResolvedValueOnce(mockProblematicResponse)
    result = await getUserProfileMap(payerList)
    expect(result).toEqual(new Map())

    // Problematic response in data
    mockProblematicResponse = {
      data: {},
      status: 200,
      statusText: 'OK',
      config: {},
      headers: { 'content-type': 'application/json' }
    }
    mockedAxios.mockResolvedValueOnce(mockProblematicResponse)
    result = await getUserProfileMap(payerList)
    expect(result).toEqual(new Map())
  })

  it('should get wallets map if account ids are passed', async () => {
    const mockResponse = {
      data: sampleResponse,
      status: 200,
      statusText: 'OK',
      headers: {
        'content-type': 'application/json'
      },
      config: {}
    }
    mockedAxios.mockResolvedValue(mockResponse)
    const result = await getUserProfileMap(payerList)
    expect(result).toEqual(mockProfileMap)
  })
})

describe('getUserProfileFromMap', () => {
  it('should not be able to get a profile if falsy account id is passed', () => {
    const falsyAccounts = [undefined, null, '']
    falsyAccounts.forEach((account) => {
      const result = getUserProfileFromMap(account, mockProfileMap)
      expect(result).toBeUndefined()
    })

    const invalidWallet = '0xb33a83ef0b99288f1ced3a0220f454143c4a008c'
    expect(getUserProfileFromMap(invalidWallet, mockProfileMap)).toEqual({
      walletId: invalidWallet
    })
  })

  it('should not be able to get a profile if falsy profile map is passed', () => {
    const falsyProfileMaps = [undefined, null, new Map()]
    falsyProfileMaps.forEach((profileMap) => {
      const result = getUserProfileFromMap(targetPayer, profileMap)
      expect(result).toBeUndefined()
    })
  })

  it('should be able to get a profile if correct param is passed', () => {
    const result = getUserProfileFromMap(targetPayer, mockProfileMap)
    expect(result).toEqual(mockProfileMap.get(targetPayer))
  })
})
