import { DDO, FileInfo } from '@oceanprotocol/lib'
import { fancyCheckDidFilesBatch } from './provider'
import { AssetsFileInfo } from '../@types/Utils'

function convertToDidKeyMapResult(inputArray): { [key: string]: FileInfo } {
  const keyResultObject = {}

  inputArray.forEach((item) => {
    const { did, result } = item
    keyResultObject[did] = result
  })

  return keyResultObject
}

export function splitListToChunk(inputs: DDO[] | AssetExtended[], chunk = 100) {
  const length = inputs?.length
  let index = 0
  let arrayIndex = 0
  const result = []
  for (index = 0; index < length; index += chunk) {
    result[arrayIndex] = inputs.slice(index, index + chunk)
    arrayIndex++
  }
  return result
}

async function mapChunkAssetConnectivity(
  results: { [key: string]: boolean },
  assetList: DDO[],
  signal: AbortSignal
): Promise<{ [key: string]: boolean }> {
  const result = convertToDidKeyMapResult(
    await fancyCheckDidFilesBatch(assetList, signal)
  )

  assetList?.forEach((asset) => {
    results[asset.id] = Boolean(result[asset.id]?.valid || false)
  })
  return results
}

export async function getAssetsConnectivity(
  ddos: DDO[],
  AbortController: AbortSignal
): Promise<{ [key: string]: boolean }> {
  if (!ddos || !ddos.length) {
    return {}
  }

  const ddoChunk = splitListToChunk(ddos)
  const results: { [key: string]: boolean } = {}
  await Promise.all(
    ddoChunk?.map(async (chunks) => {
      await mapChunkAssetConnectivity(results, chunks, AbortController)
    })
  )
  return results
}

async function mapChunkAssetsFileInfo(
  assetsFileInfo: AssetsFileInfo,
  assetList: DDO[],
  signal: AbortSignal
): Promise<AssetsFileInfo> {
  const result = convertToDidKeyMapResult(
    await fancyCheckDidFilesBatch(assetList, signal, true)
  )

  assetList?.forEach((asset) => {
    assetsFileInfo[asset.id] = {
      isConnected: Boolean(result[asset.id]?.valid || false),
      checksum: result[asset.id]?.checksum
    }
  })
  return assetsFileInfo
}

export async function getAssetsFileInfo(
  ddos: DDO[] | AssetExtended[],
  AbortController?: AbortSignal
): Promise<AssetsFileInfo> {
  if (!ddos || !ddos.length) {
    return {}
  }

  const ddoChunk = splitListToChunk(ddos)
  const results: AssetsFileInfo = {}
  await Promise.all(
    ddoChunk?.map(async (chunks) => {
      await mapChunkAssetsFileInfo(results, chunks, AbortController)
    })
  )
  return results
}

async function checkAllowance(
  ddo: DDO,
  ocean: any,
  config: any,
  networkId: number
): Promise<boolean> {
  // if (ddo?.chainId !== networkId || ddo?.price?.type !== 'fixed' || !ocean)
  //   return false

  // const allowance = await ocean.datatokens.allowance(
  //   ddo.dataToken,
  //   ddo.proof.creator,
  //   config.fixedRateExchangeAddress
  // )
  // return allowance === '0'
  return true
}

// TODO v4 just simply make it no error
export async function mapChunkAssetFre(
  results: { [key: string]: boolean },
  chunks: DDO[],
  ocean: any,
  config: any,
  networkId: number
): Promise<{ [key: string]: boolean }> {
  const requests = []
  chunks?.map(async (ddoList: any) => {
    requests.push(
      checkAllowance(
        { ...ddoList.ddo, price: ddoList?.price },
        ocean,
        config,
        networkId
      )
    )
  })
  const result = await Promise.all(requests)
  result?.map((r, index) => {
    // TODO v4 just simply make it no error
    // const did = chunks?.[index]?.ddo.id
    const did = chunks?.[index]?.id
    if (did) {
      results[did] = Boolean(r)
    }
  })
  return Promise.resolve(results)
}

// TODO v4 just simply make it no error
export async function getFresApproval(
  ddos: DDO[],
  ocean: any,
  config: any,
  networkId: number
): Promise<{ [key: string]: boolean }> {
  const ddoChunk = splitListToChunk(ddos)
  const results: { [key: string]: boolean } = {}
  for (let i = 0; i < ddoChunk.length; i++) {
    const chunks = ddoChunk[i]
    await mapChunkAssetFre(results, chunks, ocean, config, networkId)
  }
  return results
}
