import { downloadAsset } from '../../.jest/__fixtures__/downloadDatasetWithAccessDetails'
import {
  fancyGenerateQueryOrderVariable,
  fancyGetMockTransactionReceipt
} from './fancyOrder'

describe('fancyGenerateQueryOrderVariable', () => {
  const accountId = '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266'
  it('should return createdTimestamp only', async () => {
    const returnedValue = fancyGenerateQueryOrderVariable(
      undefined,
      undefined,
      1
    )
    expect(returnedValue).toEqual({
      payer: undefined,
      datatoken: undefined,
      createdTimestamp: 1
    })
  })

  it('should return payer only', async () => {
    const returnedValue = fancyGenerateQueryOrderVariable(
      undefined,
      accountId,
      undefined
    )
    expect(returnedValue).toEqual({
      payer: accountId.toLowerCase(),
      datatoken: undefined,
      createdTimestamp: undefined
    })
  })

  it('should return datatoken and timestamp', async () => {
    const returnedValue = fancyGenerateQueryOrderVariable(
      downloadAsset,
      undefined,
      10000
    )
    expect(returnedValue).toEqual({
      payer: undefined,
      datatoken:
        downloadAsset?.accessDetails?.datatoken?.address?.toLowerCase(),
      createdTimestamp: 10000
    })
  })

  it('should return payer, datatoken and createdTimestamp', async () => {
    const returnedValue = fancyGenerateQueryOrderVariable(
      downloadAsset,
      accountId,
      50000
    )
    expect(returnedValue).toEqual({
      payer: accountId.toLowerCase(),
      datatoken:
        downloadAsset?.accessDetails?.datatoken?.address?.toLowerCase(),
      createdTimestamp: 50000
    })
  })
})

describe('fancyGetMockTransactionReceipt', () => {
  it('should return object without txHash and blockNumber', async () => {
    const returnedValue = fancyGetMockTransactionReceipt('', null)
    expect(returnedValue.transactionHash).toEqual('')
    expect(returnedValue.blockNumber).toEqual(null)
  })

  it('should return object with txHash and blockNumber', async () => {
    const transactionHash =
      '0xca8f8c315c8b6c48cee0675677b786d1babe726773829a588efa500b71cbdb65'
    const blockNumber = 10237208
    const returnedValue = fancyGetMockTransactionReceipt(
      transactionHash,
      blockNumber
    )
    expect(returnedValue.transactionHash).toEqual(transactionHash)
    expect(returnedValue.blockNumber).toEqual(blockNumber)
  })
})
