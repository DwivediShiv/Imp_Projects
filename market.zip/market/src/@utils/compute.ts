import {
  Asset,
  ServiceComputeOptions,
  PublisherTrustedAlgorithm,
  getHash,
  LoggerInstance,
  ComputeAlgorithm,
  DDO,
  Service,
  ProviderInstance,
  ComputeEnvironment,
  ComputeJob,
  getErrorMessage
} from '@oceanprotocol/lib'
import { CancelToken } from 'axios'
import { ComputeJobMetaData } from 'src/@types/ComputeJobMetaData'
import {
  queryMetadata,
  getFilterTerm,
  generateBaseQuery,
  getAssetsFromDids
} from './aquarius'
import { getServiceById, getServiceByName } from './ddo'
import { SortTermOptions } from '../@types/aquarius/SearchQuery'
import { AssetSelectionAsset } from '@shared/FormInput/InputElement/AssetSelection'
import { fancyTransformAssetToAssetSelection } from './assetConvertor'
// import { BaseQueryParams } from '../models/aquarius/BaseQueryParams'
import { computeOutputExpiry } from '../../app.config'
import { keys, pick, pickBy, maxBy, uniq } from 'lodash'
import { getFileDidInfo } from './provider'
import { OrdersDataWithDDO } from '@components/pages/Profile/Purchased/FancyPurchased'

// Saransh Note: Commenting un-used code
// import { FancyOrdersData } from '../../src/@types/subgraph/FancyOrdersData'
// import { fetchDataForMultipleChains } from './subgraph'
// import { gql } from 'urql'

// const getComputeOrders = gql`
//   query ComputeOrders($user: String!) {
//     orders(
//       orderBy: createdTimestamp
//       orderDirection: desc
//       where: { payer: $user }
//     ) {
//       payer {
//         id
//       }
//       id
//       serviceIndex
//       datatoken {
//         address
//       }
//       tx
//       createdTimestamp
//     }
//   }
// `

// const getComputeOrdersByDatatokenAddress = gql`
//   query ComputeOrdersByDatatokenAddress(
//     $user: String!
//     $datatokenAddress: String!
//   ) {
//     orders(
//       orderBy: createdTimestamp
//       orderDirection: desc
//       where: { payer: $user, datatoken: $datatokenAddress }
//     ) {
//       id
//       serviceIndex
//       datatoken {
//         address
//       }
//       tx
//       createdTimestamp
//     }
//   }
// `

export function getDayLeftToExpiry(date: string, isUnix: boolean): string {
  const expiryInDays = parseInt(computeOutputExpiry)
  const dateNew = isUnix ? new Date(Number(date) * 1000) : new Date(date)
  const differentTime = Math.abs(new Date().getTime() - dateNew.getTime())
  const differentDays = Math.ceil(differentTime / (1000 * 3600 * 24))
  const expired = differentDays > expiryInDays
  const numberOfDays = expired ? '-' : '' + (expiryInDays - differentDays)

  return numberOfDays
}

export async function isOrderable(
  asset: Asset | DDO | AssetExtended,
  serviceId: string,
  algorithm: ComputeAlgorithm,
  algorithmDDO: Asset | DDO | AssetExtended
): Promise<boolean> {
  const datasetService: Service = getServiceById(asset, serviceId)
  if (!datasetService) return false
  if (datasetService.type === 'compute') {
    if (algorithm.meta) {
      // check if raw algo is allowed
      if (datasetService.compute.allowRawAlgorithm) return true
      LoggerInstance.error('ERROR: This service does not allow raw algorithm')
      return false
    }
    if (algorithm.documentId) {
      const algoService: Service = getServiceById(
        algorithmDDO,
        algorithm.serviceId
      )
      if (algoService && algoService.type === 'compute') {
        if (algoService.serviceEndpoint !== datasetService.serviceEndpoint) {
          this.logger.error(
            'ERROR: Both assets with compute service are not served by the same provider'
          )
          return false
        }
      }
    }
  }
  return true
}

export function getValidUntilTime(
  computeEnvMaxJobDuration: number,
  datasetTimeout?: number,
  algorithmTimeout?: number
) {
  const inputValues = []
  computeEnvMaxJobDuration && inputValues.push(computeEnvMaxJobDuration)
  datasetTimeout && inputValues.push(datasetTimeout)
  algorithmTimeout && inputValues.push(algorithmTimeout)

  const minValue = Math.min(...inputValues)
  const mytime = new Date()
  mytime.setMinutes(mytime.getMinutes() + Math.floor(minValue / 60))
  return Math.floor(mytime.getTime() / 1000)
}

export async function getComputeEnviroment(
  asset: Asset | AssetExtended
): Promise<ComputeEnvironment> {
  if (asset?.services[0]?.type !== 'compute') return null
  try {
    const computeEnvs = await ProviderInstance.getComputeEnvironments(
      asset.services[0].serviceEndpoint
    )
    // TODO: temporary select the longest maxJobDuration
    let longestDurationEnv: ComputeEnvironment = null
    const computeEnv = Array.isArray(computeEnvs)
      ? computeEnvs[0]
      : computeEnvs[asset.chainId][0]

    if (!computeEnv) return null
    longestDurationEnv = maxBy(computeEnvs as [], 'maxJobDuration')
    return longestDurationEnv || computeEnv
  } catch (e) {
    LoggerInstance.error('[compute] Fetch compute enviroment: ', e.message)
  }
}

export function getQueryString(
  trustedAlgorithmList: PublisherTrustedAlgorithm[],
  trustedPublishersList: string[],
  chainId?: number
): SearchQuery {
  const algorithmDidList = trustedAlgorithmList.map((x) => x.did)

  const baseParams = {
    chainIds: [chainId],
    sort: { sortBy: SortTermOptions.Created },
    filters: [getFilterTerm('metadata.type', 'algorithm')]
  } as BaseQueryParams
  algorithmDidList?.length > 0 &&
    baseParams.filters.push(getFilterTerm('_id', algorithmDidList))
  trustedPublishersList?.length > 0 &&
    baseParams.filters.push(getFilterTerm('nft.owner', trustedPublishersList))
  const query = generateBaseQuery(baseParams)

  return query
}

export async function getAlgorithmsForAsset(
  asset: Asset | AssetExtended,
  token: CancelToken
): Promise<Asset[]> {
  const computeService: Service = getServiceByName(asset, 'compute')
  const publisherTrustedAlgorithms =
    computeService?.compute?.publisherTrustedAlgorithms || []

  if (
    !computeService.compute ||
    (!publisherTrustedAlgorithms.length &&
      computeService.compute.publisherTrustedAlgorithmPublishers?.length === 0)
  ) {
    return []
  }

  const gueryResults = await queryMetadata(
    getQueryString(
      computeService.compute.publisherTrustedAlgorithms,
      computeService.compute.publisherTrustedAlgorithmPublishers,
      asset.chainId
    ),
    token
  )

  const algorithms: Asset[] = gueryResults?.results
  return algorithms
}

export async function getAlgorithmAssetSelectionList(
  asset: Asset | AssetExtended,
  algorithms: Asset[] | AssetExtended[]
): Promise<AssetSelectionAsset[]> {
  const computeService: Service = getServiceByName(asset, 'compute')
  let algorithmSelectionList: AssetSelectionAsset[]
  if (!computeService.compute) {
    algorithmSelectionList = []
  } else {
    // algorithmSelectionList = await transformAssetToAssetSelection(
    //   computeService?.serviceEndpoint,
    //   algorithms,
    //   []
    // )
    algorithmSelectionList = await fancyTransformAssetToAssetSelection(
      computeService?.serviceEndpoint,
      algorithms,
      asset as Asset,
      []
    )
  }
  return algorithmSelectionList
}

export async function getFancyJob(
  providerUrl: string,
  accountId: string,
  asset: Asset | AssetExtended
): Promise<ComputeJobMetaData[]> {
  if (!providerUrl || !asset?.id) {
    return []
  }
  const computeJobs: ComputeJobMetaData[] = []
  try {
    const providerComputeJobs = (await ProviderInstance.computeStatus(
      providerUrl,
      accountId,
      null,
      asset?.id,
      null
    )) as ComputeJob[]

    if (!providerComputeJobs) {
      providerComputeJobs.sort((a, b) => {
        if (a.dateCreated > b.dateCreated) {
          return -1
        }
        if (a.dateCreated < b.dateCreated) {
          return 1
        }
        return 0
      })
      providerComputeJobs.forEach((job) => {
        const compJob: ComputeJobMetaData = {
          ...job,
          assetName: asset.metadata.name,
          assetDtSymbol: asset.datatokens[0].symbol,
          networkId: asset.chainId,
          payer: '',
          expiryInDays: getDayLeftToExpiry(job.dateFinished, true)
        }
        computeJobs.push(compJob)
      })
    }
  } catch (err) {
    const message = getErrorMessage(err.message)
    LoggerInstance.error('[Compute to Data] Error:', message)
  }
  return computeJobs
}

export async function createTrustedAlgorithmList(
  selectedAlgorithms: string[], // list of DIDs,
  assetChainId: number,
  cancelToken: CancelToken
): Promise<PublisherTrustedAlgorithm[]> {
  const trustedAlgorithms: PublisherTrustedAlgorithm[] = []

  // Condition to prevent app from hitting Aquarius with empty DID list
  // when nothing is selected in the UI.
  if (!selectedAlgorithms || selectedAlgorithms.length === 0)
    return trustedAlgorithms

  const selectedAssets = await getAssetsFromDids(
    selectedAlgorithms,
    [assetChainId],
    cancelToken
  )

  // TOOD : temporary solution until provider is correct
  // const assetsFileInfoMap: AssetsFileInfo = await getAssetsFileInfo(
  //   selectedAssets
  // )

  for (const selectedAlgorithm of selectedAssets) {
    const filesChecksum = await getFileDidInfo(
      selectedAlgorithm?.id,
      selectedAlgorithm?.services?.[0].id,
      selectedAlgorithm?.services?.[0]?.serviceEndpoint,
      null,
      true
    )
    const containerChecksum =
      selectedAlgorithm.metadata.algorithm.container.entrypoint +
      selectedAlgorithm.metadata.algorithm.container.checksum
    const trustedAlgorithm = {
      did: selectedAlgorithm.id,
      containerSectionChecksum: getHash(containerChecksum),
      filesChecksum: filesChecksum?.[0]?.checksum || 'checksumFallback'
    }
    // const sanitizedAlgorithmContainer = {
    //   // fancy temporary hack until ocean fixed provider
    //   entrypoint: selectedAlgorithm.metadata.algorithm.container.entrypoint,
    //   image: selectedAlgorithm.metadata.algorithm.container.image,
    //   tag: selectedAlgorithm.metadata.algorithm.container.tag,
    //   checksum: selectedAlgorithm.metadata.algorithm.container.checksum
    // }

    // // fancy temporary hack until ocean fixed provider
    // const stringifiedAlgorithmContainer = JSON.stringify(
    //   sanitizedAlgorithmContainer
    // )
    // const hashedAlgorithmContainer = getHash(stringifiedAlgorithmContainer)
    // const trustedAlgorithm = {
    //   did: selectedAlgorithm.id,
    //   containerSectionChecksum: hashedAlgorithmContainer,
    //   // TOOD : temporary solution until provider is correct, provider now check wrong checksum, we have to follow it wrong
    //   // filesChecksum: assetsFileInfoMap[selectedAlgorithm.id]?.checksum
    //   filesChecksum: getHash(selectedAlgorithm.services[0].files)
    // }
    trustedAlgorithms.push(trustedAlgorithm)
  }

  return trustedAlgorithms
}

export async function transformComputeFormToServiceComputeOptions(
  values: ComputePrivacyForm,
  currentOptions: ServiceComputeOptions,
  assetChainId: number,
  cancelToken: CancelToken
): Promise<ServiceComputeOptions> {
  const publisherTrustedAlgorithms = values.publisherTrustedAlgorithms
    ? await createTrustedAlgorithmList(
        values.publisherTrustedAlgorithms,
        assetChainId,
        cancelToken
      )
    : []

  // TODO: add support for selecting trusted publishers and transforming here.
  // This only deals with basics so we don't accidentially allow all accounts
  // to be trusted.
  const publisherTrustedAlgorithmPublishers: string[] = []

  const privacy: ServiceComputeOptions = {
    ...currentOptions,
    publisherTrustedAlgorithms,
    publisherTrustedAlgorithmPublishers
  }

  return privacy
}

export function getUserProfileDetailOfOrders(
  orders: OrdersDataWithDDO[]
): string[] {
  if (!orders) return []
  const wallets = orders?.map((order) => {
    return order?.ddo?.nft?.owner
  })
  return uniq(wallets)
}

// Saransh Note: Commenting un-used functions
// function getServiceEndpoints(data: TokenOrder[], assets: Asset[]): string[] {
//   const serviceEndpoints: string[] = []

//   // for (let i = 0; i < data.length; i++) {
//   //   try {
//   //     const did = web3.utils
//   //       .toChecksumAddress(data[i].datatokenId.address)
//   //       .replace('0x', 'did:op:')
//   //     const ddo = assets.filter((x) => x.id === did)[0]
//   //     if (ddo === undefined) continue

//   //     const service = ddo.services.filter(
//   //       (x: Service) => x.index === data[i].serviceId
//   //     )[0]

//   //     if (!service || service.type !== 'compute') continue
//   //     const { providerEndpoint } = service

//   //     const wasProviderQueried =
//   //       serviceEndpoints?.filter((x) => x === providerEndpoint).length > 0

//   //     if (wasProviderQueried) continue
//   //     serviceEndpoints.push(providerEndpoint)
//   //   } catch (err) {
//   //     LoggerInstance.error(err.message)
//   //   }
//   // }

//   // return serviceEndpoints
//   return ['dummy']
// }

// async function getProviders(
//   serviceEndpoints: string[],
//   config: Config,
//   ocean: any
// ): Promise<Provider[]> {
//   const providers: Provider[] = []

//   // try {
//   //   for (let i = 0; i < serviceEndpoints?.length; i++) {
//   //     const instanceConfig = {
//   //       config,
//   //       web3: config.web3Provider,
//   //       logger: Logger,
//   //       ocean
//   //     }
//   //     const provider = await Provider.getInstance(instanceConfig)
//   //     await provider.setBaseUrl(serviceEndpoints[i])
//   //     const hasSameCompute =
//   //       providers.filter((x) => x.computeAddress === provider.computeAddress)
//   //         .length > 0
//   //     if (!hasSameCompute) providers.push(provider)
//   //   }
//   // } catch (err) {
//   //   LoggerInstance.error(err.message)
//   // }

//   return providers
// }

// async function getJobs(
//   providerUrls: string[],
//   accountId: string,
//   assets: Asset[]
// ): Promise<ComputeJobMetaData[]> {
//   const computeJobs: ComputeJobMetaData[] = []
//   providerUrls.forEach(async (providerUrl) => {
//     try {
//       const providerComputeJobs = (await ProviderInstance.computeStatus(
//         providerUrl,
//         accountId,
//         null,
//         null,
//         null
//       )) as ComputeJob[]

//       if (!providerComputeJobs) {
//         providerComputeJobs.sort((a, b) => {
//           if (a.dateCreated > b.dateCreated) {
//             return -1
//           }
//           if (a.dateCreated < b.dateCreated) {
//             return 1
//           }
//           return 0
//         })
//         providerComputeJobs.forEach((job) => {
//           const did = job.inputDID[0]
//           const asset = assets.filter((x) => x.id === did)[0]

//           if (!asset) {
//             const compJob: ComputeJobMetaData = {
//               ...job,
//               assetName: asset.metadata.name,
//               assetDtSymbol: asset.datatokens[0].symbol,
//               networkId: asset.chainId,
//               payer: '',
//               expiryInDays: getDayLeftToExpiry(job.dateFinished, true)
//             }
//             computeJobs.push(compJob)
//           }
//         })
//       }
//     } catch (err) {
//       LoggerInstance.error(err.message)
//     }
//   })
//   return computeJobs
// }

// function getDtList(data: TokenOrder[]): string[] {
//   const dtList = []

//   for (let i = 0; i < data.length; i++) {
//     dtList.push(data[i].datatoken.address)
//   }

//   return dtList
// }

// Saransh Note: Commenting un-used function
// export async function getComputeJobs(
//   chainIds: number[],
//   accountId: string,
//   asset?: AssetExtended,
//   cancelToken?: CancelToken
// ): Promise<ComputeResults> {
//   if (!accountId) return
//   const assetDTAddress = asset?.datatokens[0]?.address
//   const computeResult: ComputeResults = {
//     computeJobs: [],
//     isLoaded: false
//   }
//   const variables = assetDTAddress
//     ? {
//         user: accountId.toLowerCase(),
//         datatokenAddress: assetDTAddress.toLowerCase()
//       }
//     : {
//         user: accountId.toLowerCase()
//       }

//   const results = await fetchDataForMultipleChains(
//     assetDTAddress ? getComputeOrdersByDatatokenAddress : getComputeOrders,
//     variables,
//     assetDTAddress ? [asset?.chainId] : chainIds
//   )

//   let tokenOrders: TokenOrder[] = []
//   results.map((result) => {
//     result.orders.forEach((tokenOrder: TokenOrder) =>
//       tokenOrders.push(tokenOrder)
//     )
//   })

//   if (tokenOrders.length === 0) {
//     computeResult.isLoaded = true
//     return computeResult
//   }

//   tokenOrders = tokenOrders.sort(
//     (a, b) => b.createdTimestamp - a.createdTimestamp
//   )
//   const datatokenAddressList = tokenOrders.map(
//     (tokenOrder: TokenOrder) => tokenOrder.datatoken.address
//   )
//   if (!datatokenAddressList) return

//   const assets = await getAssetMetadata(
//     datatokenAddressList,
//     cancelToken,
//     chainIds
//   )

//   const providerUrls: string[] = []
//   assets.forEach((asset: Asset) =>
//     providerUrls.push(asset.services[0].serviceEndpoint)
//   )
//   computeResult.computeJobs = await getJobs(providerUrls, accountId, assets)
//   computeResult.isLoaded = true

//   return computeResult
// }

// test code temporary keep before replacing ocean
// function sortObjectAttr(obj: any) {
//   if (!obj) {
//     return
//   }
//   const valuedAttr = pickBy(obj, (value) => {
//     return value
//   })
//   const nullAttr = pickBy(obj, (value) => {
//     return !value
//   })
//   const valuedKeys = keys(valuedAttr)?.sort()
//   const nullKeys = keys(nullAttr)?.sort()
//   const objKeys = [...valuedKeys, ...nullKeys]
//   const result = pick(obj, objKeys)
//   return result
// }

// Saransh Note: Not using this function, commenting out for now
// export async function checkComputeResourcesValidity(
//   asset: Asset,
//   accountId: string,
//   computeEnvMaxJobDuration: number,
//   datasetTimeout?: number,
//   algorithmTimeout?: number,
//   cancelToken?: CancelToken
// ): Promise<boolean> {
//   const jobs = await getComputeJobs(
//     [asset?.chainId],
//     accountId,
//     asset,
//     cancelToken
//   )
//   if (jobs.computeJobs.length <= 0) return false
//   const inputValues = []
//   computeEnvMaxJobDuration && inputValues.push(computeEnvMaxJobDuration * 60)
//   datasetTimeout && inputValues.push(datasetTimeout)
//   algorithmTimeout && inputValues.push(algorithmTimeout)
//   const minValue = Math.min(...inputValues)
//   const jobStartDate = new Date(
//     parseInt(jobs.computeJobs[0].dateCreated) * 1000
//   )
//   jobStartDate.setMinutes(jobStartDate.getMinutes() + Math.floor(minValue / 60))
//   const currentTime = new Date().getTime() / 1000
//   return Math.floor(jobStartDate.getTime() / 1000) > currentTime
// }

// async function getAssetMetadata(
//   queryDtList: string[],
//   cancelToken: CancelToken,
//   chainIds: number[]
// ): Promise<Asset[]> {
//   const baseQueryparams = {
//     chainIds,
//     filters: [
//       getFilterTerm('services.datatokenAddress', queryDtList),
//       getFilterTerm('services.type', 'compute'),
//       getFilterTerm('metadata.type', 'dataset')
//     ],
//     ignorePurgatory: true
//   } as BaseQueryParams
//   const query = generateBaseQuery(baseQueryparams)
//   const result = await queryMetadata(query, cancelToken)

//   return result?.results
// }
