import { Asset, Config, FileInfo, Metadata } from '@oceanprotocol/lib'
import { AdditionalInformationMarket } from 'src/@types/MetaData'
import {
  FormPublishData,
  FileHeaders,
  FileEncryptRequestData
} from 'src/components/Publish/_types'
import {
  fancyGetAlgorithmContainerPreset,
  getFileEncryptRequestData
} from 'src/components/Publish/_utils'
import { AdvancedSettingsForm } from 'src/models/FormEditCredential'
import { getFancyDockerHubCheckSum } from './docker'
import { isEncryptUrl } from './fancySampleFileCheck'
import { getEncryptedFiles, PROVIDER_URL_KEY } from './provider'
import { getInMemoryValue } from './fancyAppData'
import { isCustomComputeOption } from './assetConvertor'
import {
  ALGORITHM_TYPES,
  DATA_ASSET_TYPES
} from '@components/Publish/Constants'
import { getOrganisationOption } from './fancySelectionOption'
import { POST_PAY_TYPES } from '../components/FederatedLearning/compute/Constants'
import { PriceList, getAssetsPriceList } from './subgraph'
import appConfig from 'app.config'
import { getTechnicalNetworkName } from './network'
import { getImageAndTagFromRegistryLink } from './fancyDocker'
import { convertUsdcSymbolToUsd } from '.'

export async function fancyGetFilesEncrypted(
  values: FormPublishData,
  nftAddress: string,
  datatokenAddress: string
): Promise<string> {
  const files = values.services[0]?.files as FileInfo[]
  const headers = values.services[0]?.headers as FileHeaders[]
  const editUrl: FileInfo = files && files[0]
  if (
    typeof values.services[0]?.files !== 'string' &&
    !isEncryptUrl(editUrl?.url)
  ) {
    const fileEncryptRequestData: FileEncryptRequestData =
      getFileEncryptRequestData(files, nftAddress, datatokenAddress, headers)

    return (
      files?.length &&
      files[0].valid &&
      (await getEncryptedFiles(
        fileEncryptRequestData,
        values.user.chainId,
        values.services[0].providerUrl.url
      ))
    )
  }
}

export function fancyPrepareEditAsset(
  asset: AssetExtended,
  values: FormPublishData,
  initialValues: FormPublishData
): FormPublishData {
  values.metadata.description = values.metadata.description?.trim()
  values.services[0].description = values.services[0].description?.trim()
  values.metadata.name = values.metadata.name?.trim()
  const isProviderEdited = values.providerName !== initialValues.providerName
  if (isProviderEdited) {
    const additionalInformation = asset.services[0]
      .additionalInformation as AdditionalInformationMarket
    const serviceEndpointSet = new Set<string>(
      additionalInformation?.previousServiceEndpoints || []
    )
    const inMemoryProviderUrl = getInMemoryValue(PROVIDER_URL_KEY)
    const service = values.services[0]

    serviceEndpointSet.add(asset.services[0].serviceEndpoint)
    service.providerUrl = { url: inMemoryProviderUrl, valid: true }
    service.additionalInformation = service.additionalInformation || {}
    service.additionalInformation.previousServiceEndpoints =
      Array.from(serviceEndpointSet)
  }
  return values
}

export async function fancyPrepareUpdatedMetadata(
  asset: AssetExtended,
  values: FormPublishData
): Promise<Metadata> {
  const algoPreset = values.metadata?.dockerImage
    ? fancyGetAlgorithmContainerPreset(values.metadata.dockerImage)
    : null

  // let customDockerChecksum
  // if (values.metadata?.dockerImage === 'custom') {
  //   const responses = await getFancyDockerHubCheckSum(
  //     values.metadata.dockerImageCustom.trim(),
  //     values.metadata.dockerImageCustomTag.trim()
  //   )
  //   const digest = responses?.result?.digest
  //   customDockerChecksum = digest || ''
  // }

  const newMetadata = {
    ...asset.metadata,
    name: values.metadata.name,
    description: values.metadata.description,
    categories: [values.metadata.category],
    tags: values.metadata.tags,
    additionalInformation: {
      ...asset.metadata.additionalInformation,
      eula: values?.eula ? [{ url: values.eula }] : [],
      eulaType: values.eulaType
    },
    ...(asset.metadata.type === 'algorithm' &&
      values.metadata.dockerImage !== '' && {
        algorithm: {
          ...asset.metadata.algorithm,
          language:
            values.metadata.dockerImage === 'custom'
              ? values.metadata.dockerImage
              : algoPreset?.name,
          version: '0.1',
          container: {
            entrypoint:
              values.metadata.dockerImage === 'custom'
                ? values.metadata.dockerImageCustomEntrypoint
                : algoPreset?.value.entrypoint,
            image:
              values.metadata.dockerImage === 'custom'
                ? getImageAndTagFromRegistryLink(
                    values.metadata.dockerImageCustom
                  )?.image
                : algoPreset?.value.image,
            tag:
              values.metadata.dockerImage === 'custom'
                ? getImageAndTagFromRegistryLink(
                    values.metadata.dockerImageCustom
                  )?.tag
                : algoPreset?.value?.tag,
            checksum:
              values.metadata.dockerImage === 'custom'
                ? values?.metadata?.dockerImageCustomChecksum
                : algoPreset?.value.checksum,
            referenceUrl:
              values.metadata.dockerImage === 'custom'
                ? values?.metadata?.dockerImageCustomReferenceUrl
                : `${algoPreset?.value.registry}${algoPreset?.value.imageName}`
          }
        }
      })
  }

  if (
    asset.metadata.type === DATA_ASSET_TYPES.ALGORITHM &&
    asset.metadata.additionalInformation.algorithmType ===
      ALGORITHM_TYPES.FEDERATED
  ) {
    newMetadata.additionalInformation.relatedAggregateAlgorithms =
      values.metadata.additionalInformation.publisherTrustedAlgorithms
  }

  if (values?.pricing?.type === 'Post-pay') {
    newMetadata.additionalInformation.price = JSON.stringify({
      tokenAddress:
        appConfig?.stableCoin[getTechnicalNetworkName(asset?.chainId)]?.address,
      tokenSymbol:
        values?.baseToken ||
        appConfig?.stableCoin[getTechnicalNetworkName(asset?.chainId)]?.ticker,
      value: values?.pricing?.price.toString()
    })
  }
  return newMetadata
}

export function transformAdvancedSettingFormToAsset(
  values: Partial<AdvancedSettingsForm>,
  asset: Asset | AssetExtended
): Asset {
  return {
    ...asset,
    credentials: {
      allow: values?.allow,
      deny: values?.deny
    },
    metadata: {
      ...asset.metadata,
      additionalInformation: {
        ...asset.metadata.additionalInformation,
        accessPermission: values.accessPermission
      }
    }
  } as Asset
}

export async function simpleTransform(assetList: Asset[], config?: Config) {
  const orgOptions = await getOrganisationOption()
  const priceList: PriceList = await getAssetsPriceList(assetList)

  const output = assetList.map((asset) => {
    const matchedOrg = orgOptions.find(
      (org) => org.id === asset?.metadata?.additionalInformation?.organization
    )
    let currType: string = config?.oceanTokenSymbol
    let assetPrice: string
    if (asset?.metadata?.additionalInformation?.postpayType) {
      const priceData = JSON.parse(
        asset?.metadata?.additionalInformation?.price
      )
      currType = convertUsdcSymbolToUsd(priceData?.tokenSymbol)
      if (
        asset?.metadata?.additionalInformation?.postpayType ===
        POST_PAY_TYPES.PAY_PER_BYTE
      ) {
        assetPrice = `${priceData.value} ${currType}/byte`
      } else {
        assetPrice = `${priceData.value} ${currType}`
      }
    }
    return {
      did: asset?.id,
      name: asset?.metadata?.name,
      price: assetPrice || `${priceList[asset?.id]} ${currType}`,
      currencyType: currType,
      symbol: asset?.datatokens[0].symbol,
      checked: false,
      serviceEndpoint: asset?.services[0]?.serviceEndpoint,
      shortDescription: asset?.metadata.description,
      isExperimental: asset?.services[0]?.additionalInformation?.isExperimental,
      ...(asset?.metadata.type === DATA_ASSET_TYPES.ALGORITHM && {
        isCustomDocker: isCustomComputeOption(
          asset?.metadata?.algorithm?.container?.image,
          asset?.metadata?.algorithm?.container?.tag
        )
      }),
      datatoken: asset?.datatokens[0].symbol,
      accessType: asset?.services[0]?.type,
      dataProvider: matchedOrg ? matchedOrg.name : '-',
      ownerAddress: asset?.nft?.owner,
      ...(asset?.metadata.type === DATA_ASSET_TYPES.ALGORITHM && {
        algoType: asset?.metadata.additionalInformation?.algorithmType
      })
    }
  })

  return output
}
