import axios, { AxiosRequestConfig, AxiosResponse } from 'axios'

const defaultConfig: AxiosRequestConfig = {}

interface ErrorDetails {
  message?: string
}

interface ErrorResponse {
  response: {
    data: {
      errorDetails?: ErrorDetails
      code?: string
    }
  }
}

function getConfig(additionalConfig?: AxiosRequestConfig) {
  const config = additionalConfig
    ? Object.assign(defaultConfig, additionalConfig)
    : defaultConfig
  return config
}

export function printErrorStack(errorResponse: ErrorResponse): void {
  console.error(errorResponse, errorResponse?.response?.data)
}

export async function getAsync(
  url: string,
  additionalConfig?: AxiosRequestConfig,
  successCallback?: any,
  errorCallback?: any
): Promise<any> {
  try {
    const config = getConfig(additionalConfig)
    const response: AxiosResponse = await axios.get(url, config)
    if (!response || (response.status !== 201 && response.status !== 200)) {
      return null
    }
    successCallback && successCallback()

    return response
  } catch (error) {
    printErrorStack(error)
    errorCallback && errorCallback(error)
    return null
  }
}

export async function postAsync(
  url: string,
  data?: any,
  additionalConfig?: AxiosRequestConfig,
  successCallback?: any,
  errorCallback?: any
): Promise<any> {
  try {
    const config = getConfig(additionalConfig)
    const response: AxiosResponse = await axios.post(url, data, config)

    if (!response || (response.status !== 201 && response.status !== 200)) {
      throw Error
    }

    successCallback && successCallback()
    return response
  } catch (error) {
    printErrorStack(error)
    errorCallback && errorCallback(error)
    return error?.response
  }
}

export async function putAsync(
  url: string,
  data?: any,
  additionalConfig?: AxiosRequestConfig,
  successCallback?: any,
  errorCallback?: any
): Promise<any> {
  try {
    const config = getConfig(additionalConfig)
    const response: AxiosResponse = await axios.put(url, data, config)
    if (!response || (response.status !== 201 && response.status !== 200)) {
      return null
    }

    successCallback && successCallback()
    return response
  } catch (error) {
    printErrorStack(error)
    errorCallback && errorCallback(error)
    return null
  }
}

export const buildUrlWithQueryParams = (
  baseUrl: string,

  query: Record<string, string> = {}
) => {
  if (!baseUrl) {
    return ''
  }

  const urlQueryParams = []

  for (const key in query) {
    urlQueryParams.push(`${key}=${query[key]}`)
  }

  return [baseUrl, urlQueryParams.join('&')].join('?')
}

export async function deleteAsync(
  url: string,
  data?: any,
  additionalConfig?: AxiosRequestConfig,
  successCallback?: any,
  errorCallback?: any
): Promise<any> {
  try {
    const config = getConfig(additionalConfig)
    config.data = data
    const response: AxiosResponse = await axios.delete(url, config)
    if (!response || (response.status !== 201 && response.status !== 200)) {
      return null
    }

    successCallback && successCallback()
    return response
  } catch (error) {
    printErrorStack(error)
    errorCallback && errorCallback(error)
    return null
  }
}
