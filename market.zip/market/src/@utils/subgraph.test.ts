import { Client, TypedDocumentNode } from 'urql'
import { fetchDataForMultipleChains, fetchData } from './subgraph'
import { LoggerInstance } from '@oceanprotocol/lib'
import { getUrqlClientInstance } from '@context/UrqlProvider'

const wallets = [
  '0xb33a83ef0b99288f1ced3a0220f454143c4a008b',
  '0xea3607e8c3908011060a5d4e1052484cd3cb0b07'
]
const variables = { nftOwner_in: wallets }

const orderQuery: TypedDocumentNode = {} as TypedDocumentNode

const chainIds = [5]

const errorResponse = {
  data: { orders: [] },
  error: 'error'
}

const successfulResponseA = {
  data: { orders: ['a', 'b'] },
  error: undefined
}

const successfulResponseB = {
  data: { orders: ['c', 'd'] },
  error: undefined
}

jest.mock('@context/UrqlProvider', () => {
  const actual = jest.requireActual('@context/UrqlProvider')
  return {
    ...actual,
    getUrqlClientInstance: jest.fn()
  }
})

const mockGetUrqlClientInstance = getUrqlClientInstance as jest.MockedFunction<
  typeof getUrqlClientInstance
>

describe('fetchData', () => {
  afterEach(() => {
    mockGetUrqlClientInstance.mockReset()
  })

  const variables = undefined // optional items in client.query
  const context = undefined // optional items in client.query

  it('should return correct response Urql query is successful', async () => {
    const successfulResponse = `example of successful response`
    mockGetUrqlClientInstance.mockImplementationOnce(() => {
      return {
        query: jest.fn(() => ({
          toPromise: jest.fn().mockResolvedValue(successfulResponse)
        }))
      } as unknown as Client
    })
    const result = await fetchData(orderQuery, variables, context)
    expect(result).toEqual(successfulResponse)
  })

  it('should throw error if network error occur or falsy query passed', async () => {
    mockGetUrqlClientInstance.mockImplementationOnce(() => {
      return {
        query: jest.fn(() => ({
          toPromise: jest.fn().mockRejectedValueOnce({ message: 'Test Error' })
        }))
      } as unknown as Client
    })
    const loggerInstanceSpy = jest.spyOn(LoggerInstance, 'error')

    let result = await fetchData(orderQuery, variables, context)
    expect.hasAssertions()
    expect(result).toBe(null)
    expect(loggerInstanceSpy).toHaveBeenCalled()

    mockGetUrqlClientInstance.mockClear()

    // falsy query test
    mockGetUrqlClientInstance.mockImplementationOnce(() => {
      return {
        query: jest.fn(() => ({
          toPromise: jest.fn().mockResolvedValue(`successful`)
        }))
      } as unknown as Client
    })
    const falsyQueries = [undefined, null]
    falsyQueries.forEach(async (query) => {
      result = await fetchData(query, variables, context)
      expect.hasAssertions()
      expect(result).toBe(null)
      expect(loggerInstanceSpy).toHaveBeenCalled()
    })
  })
})

describe('fetchDataForMultipleChains', () => {
  afterEach(() => {
    mockGetUrqlClientInstance.mockReset()
  })

  it('should get empty array if error response obtained', async () => {
    mockGetUrqlClientInstance.mockImplementationOnce(() => {
      return {
        query: jest.fn(() => ({
          toPromise: jest.fn().mockReturnValueOnce(errorResponse)
        }))
      } as unknown as Client
    })
    const response = await fetchDataForMultipleChains(
      orderQuery,
      variables,
      chainIds
    )
    expect(response).toEqual([])
  })

  it('should get empty array if undefined response obtained', async () => {
    mockGetUrqlClientInstance.mockImplementationOnce(() => {
      return {
        query: jest.fn(() => ({
          toPromise: jest.fn().mockReturnValueOnce(undefined)
        }))
      } as unknown as Client
    })

    const response = await fetchDataForMultipleChains(
      orderQuery,
      variables,
      chainIds
    )
    expect(response).toEqual([])
  })

  it('should throw error when falsy chain ids is passed', async () => {
    const loggerSpy = jest.spyOn(LoggerInstance, 'error')
    const falsyChains = [undefined, null]
    jest.spyOn(console, 'error').mockReturnValue(null)
    await fetchDataForMultipleChains(orderQuery, variables, falsyChains)
    expect(loggerSpy).toHaveBeenCalledWith(
      'Error fetchDataForMultipleChains: ',
      'Invalid Chain ID'
    )
  })

  it('should get combined result when fetch data from multiple chain', async () => {
    mockGetUrqlClientInstance
      .mockImplementationOnce(() => {
        return {
          query: jest.fn(() => ({
            toPromise: jest.fn().mockReturnValueOnce(successfulResponseA)
          }))
        } as unknown as Client
      })
      .mockImplementationOnce(() => {
        return {
          query: jest.fn(() => ({
            toPromise: jest.fn().mockReturnValueOnce(successfulResponseB)
          }))
        } as unknown as Client
      })

    const response = await fetchDataForMultipleChains(
      orderQuery,
      variables,
      chainIds.concat([80001])
    )

    let responseOrders = []
    response.forEach((r) => {
      responseOrders = responseOrders.concat(r.orders)
    })

    expect(responseOrders).toEqual(['a', 'b', 'c', 'd'])
  })
})
