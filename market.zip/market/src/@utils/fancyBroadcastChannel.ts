// Need to use this package to make sure jest test doesn't break. Since this only available in Browser WEB API
// https://developer.mozilla.org/en-US/docs/Web/API/BroadcastChannel , remove if node.js jest env exist in future
import { BroadcastChannel, EventContext } from 'broadcast-channel'

// Creating a new Broadcast Channel
const channel = new BroadcastChannel('authWalletChannel')

// Message types
export const MESSAGE_TYPES = {
  LOGOUT: 'LOGOUT',
  WALLET_CONNECTED: 'WALLET_CONNECTED',
  WALLET_DISCONNECTED: 'WALLET_DISCONNECTED'
}

export function fancyBroadcastMessage(
  type: string,
  data?: { [key: string]: any }
) {
  channel.postMessage({ type, ...data })
}

export function fancyAddBroadcastListener(
  fancyType: EventContext,
  fancyHandler: any
) {
  channel.addEventListener(fancyType, fancyHandler)
}

export function fancyRemoveBroadcastListener(
  fancyType: EventContext,
  fancyHandler: any
) {
  channel.removeEventListener(fancyType, fancyHandler)
}
