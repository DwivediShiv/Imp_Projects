import axios, { AxiosResponse } from 'axios'
import { writeCookie, deleteCookie, readCookie } from '.'
import { ResponseToken, JWTActionToken } from 'src/@types/Auth'
import Router from 'next/router'
import {
  postAuthenticationUrl,
  postRequestResetPasswordUrl,
  postResetPasswordUrl,
  postSignupUrl,
  putChangePasswordUrl,
  getEmailDomainUrl,
  putLoginUrl,
  getUserRolesUrl,
  postAcceptUserInvitationUrl,
  checkAbstract,
  getAbstractOrgUrl,
  resendOtpUrl,
  getUserOrgInfo,
  getInstanceDetailsURL,
  addSmartAccountUrl,
  getPayMasterDetailsUrl,
  getPaymasterValidatedUrl,
  getRequestResetSsoUrl
} from './api'
import jwt, { JwtPayload } from 'jwt-decode' // import dependency
import fancyToast from '@shared/fancy/atoms/Toast/FancyToast'
import {
  ROLE_ADMIN,
  ROLE_VALIDATED
} from '@shared/fancy/constants/RoleConstants'
import { removeLastVisitUrl } from './platformSetting'
import { getLocalStorage, setLocalStorage } from './cookie'
import {
  JWT_LATEST_EXPIRY,
  ONE_MINUTE_IN_MS,
  ONE_SECOND_IN_MS,
  USER_LOGIN_CHECK,
  REFRESH_TOKEN,
  HttpStatusCode
} from '../components/Constants'
import { UserProfileRoles, Wallet } from '../@types/User'
// Ani coming from Main : look into its use
import { MESSAGE_TYPES, fancyBroadcastMessage } from './fancyBroadcastChannel'

import { postAsync, printErrorStack } from './utils.api'
import {
  ApiResponse,
  AbstractDetails,
  PayMasterDetails
} from '../@types/SmartAccount'
import { WALLET_ACTIVE } from './authorization.constant'

let inMemoryToken: ResponseToken = null
let interval: NodeJS.Timeout | null
let inMemoryJwtActionToken: JWTActionToken = null
let isActive = false
let inMemoryRole: UserProfileRoles = null
export function setActive() {
  isActive = true
}

export function isLatestActiveSession(jwtLatestExpiry?: string) {
  jwtLatestExpiry = jwtLatestExpiry || getLocalStorage(JWT_LATEST_EXPIRY)

  if (!inMemoryToken?.token) {
    isActive = false
    return false
  }

  const jwtObj = jwt<JwtPayload>(inMemoryToken.token)

  if (jwtLatestExpiry && jwtObj?.exp) {
    isActive = jwtLatestExpiry === jwtObj.exp.toString()
    return isActive
  }

  isActive = false
  return false
}

// Ani coming from main : have a look
// export const keycloakLogout = (pageProp?: any): void => {
//   const isLogin = isLoggedIn()
//   inMemoryRole = null
//   inMemoryToken = null
//   inMemoryJwtActionToken = null
//   clearInterval(interval)
//   removeLastVisitUrl()
//   setLocalStorage(JWT_LATEST_EXPIRY, '')
//   deleteCookie('refresh_token')
//   !pageProp && fancyToast('success', 'You have successfully logged out.')

//   // Broadcast logout message
//   if (isLogin) {
//     if (pageProp?.reason === 'timeout') {
//       // Logout by Timeout
//       fancyBroadcastMessage(MESSAGE_TYPES.LOGOUT, { reason: 'timeout' })
//     } else {
//       // Normal logout
//       fancyBroadcastMessage(MESSAGE_TYPES.LOGOUT)
//     }
//   }

//   Router.push(
//     {
//       pathname: '/login',
//       query: pageProp
//     },
//     '/login'
//   )
// }

export function clearWalletCache() {
  localStorage.removeItem(`openlogin_store`)
  Object.keys(localStorage).forEach(function (key) {
    if (key.substring(0, 5) === 'wagmi') {
      localStorage.removeItem(key)
    }
  })
}

export function clearInMemoryStorage() {
  inMemoryRole = null
  inMemoryToken = null
  inMemoryJwtActionToken = null
  clearInterval(interval)
  interval = null
  removeLastVisitUrl()
  setLocalStorage(JWT_LATEST_EXPIRY, '')
  setLocalStorage(USER_LOGIN_CHECK, '')
  deleteCookie(REFRESH_TOKEN)
  clearWalletCache()
}

export const isLoggedIn = (): boolean => {
  return !!readCookie(REFRESH_TOKEN) && !!getLocalStorage(USER_LOGIN_CHECK)
}

export const keycloakLogout = (pageProp?: any): void => {
  const isLogin = isLoggedIn()
  clearInMemoryStorage()
  !pageProp && fancyToast('success', 'You have successfully logged out.')

  // Broadcast logout message
  if (isLogin) {
    if (pageProp?.reason === 'timeout') {
      // Logout by Timeout
      fancyBroadcastMessage(MESSAGE_TYPES.LOGOUT, { reason: 'timeout' })
    } else {
      // Normal logout
      fancyBroadcastMessage(MESSAGE_TYPES.LOGOUT)
    }
  }

  Router.push(
    {
      pathname: '/login',
      query: pageProp
    },
    '/login'
  )
}

export function setTabSessionInactive(): void {
  isLatestActiveSession() && isActive && keycloakLogout({ reason: 'timeout' })
}

export const goToKeycloakLogin = (): void => {
  // Router.push('/login')
}

export const goToKeycloakRegister = (): void => {
  // Router.push('/signup')
}

export async function login(
  username: string,
  password: string,
  otp?: string
): Promise<any> {
  const response: AxiosResponse = await axios({
    method: 'PUT',
    url: putLoginUrl(),
    data: {
      email: username,
      password,
      ...(otp && otp !== '' ? { otp } : {})
    }
  })

  if (response.status !== 200) {
    fancyToast('error', 'Non-200 response: ' + response.status)
    return
  }
  return response.data
}

export async function checkUserOrgInfo(email: string): Promise<any> {
  try {
    const response: AxiosResponse = await axios({
      method: 'GET',
      url: getUserOrgInfo(email)
    })
    return response.data
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw Error(error.message)
    } else {
      throw Error('User details not found')
    }
  }
}

export async function resendOTP(formvalues): Promise<any> {
  try {
    const response = await axios.put(resendOtpUrl(), {
      email: formvalues.email,
      password: formvalues.password
    })
    if (response?.status !== 200) {
      fancyToast('error', 'Non-200 response: ' + response.status)
      return
    }
    return response.data
  } catch (error) {
    throw error.response?.data || error
  }
}

export async function requestResetPassword(email: string): Promise<any> {
  const response: AxiosResponse = await axios({
    method: 'POST',
    url: postRequestResetPasswordUrl(),
    data: {
      email
    }
  })
  if (response.status !== 200) {
    fancyToast('error', 'Non-200 response: ' + response.status)
    return
  }
  return response.data
}

export async function resetPassword(
  actionToken: string,
  password: string
): Promise<any> {
  const response: AxiosResponse = await axios({
    method: 'POST',
    url: postResetPasswordUrl(),
    data: {
      actionToken,
      password
    }
  })
  if (response.status !== 200) {
    fancyToast('error', 'Non-200 response: ' + response.status)
    return
  }
  return response.data
}

export async function signup(value: any): Promise<any> {
  const response: AxiosResponse = await axios({
    method: 'POST',
    url: postSignupUrl(),
    data: {
      companyName: value.companyName,
      country: value.country,
      otherCountry: value.otherCountry,
      industry: value.industry,
      email: value.email,
      password: value.password,
      purpose: value.purpose,
      isMarketingConsent: value.isMarketingConsent,
      actionToken: value.actionToken
    }
  })

  if (response.status !== 200) {
    fancyToast('error', 'Non-200 response: ' + response.status)
    return
  }
  return response.data
}

export async function validateDomain(
  email: string,
  cancelToken?: any
): Promise<any> {
  const ONE_SECONDS = 1000
  const delayFunc = (time) =>
    new Promise((resolve) => {
      setTimeout(resolve, time)
    })
  try {
    await delayFunc(ONE_SECONDS)

    const response: AxiosResponse = await axios({
      method: 'GET',
      url: getEmailDomainUrl(email),
      cancelToken: cancelToken.tokenp
    })

    return response.data
  } catch (error) {
    return error
  }
}

async function authentication(isGetTokenOnly?: boolean): Promise<any> {
  const refreshToken = readCookie(REFRESH_TOKEN)
  const jwtLatestExpiry = getLocalStorage(JWT_LATEST_EXPIRY)
  if (!isGetTokenOnly && !isActive && !jwtLatestExpiry && !refreshToken) {
    keycloakLogout({ reason: 'timeout' })
    return
  }
  if (refreshToken && (isActive || jwtLatestExpiry)) {
    try {
      const response: AxiosResponse = await axios({
        method: 'POST',
        url: postAuthenticationUrl(),
        data: {
          refresh_token: refreshToken
        }
      })
      writeCookie(
        REFRESH_TOKEN,
        response.data.refresh_token,
        response.data.refresh_expires_in
      )
      !isGetTokenOnly && isLatestActiveSession()
      inMemoryJwtActionToken = jwt(response.data.access_token)
      isActive &&
        setLocalStorage(JWT_LATEST_EXPIRY, inMemoryJwtActionToken?.exp)
      return {
        token: response.data.access_token,
        expiry: response.data.expires_in
      }
    } catch (error) {
      keycloakLogout()
      console.log(error)
    }
  }
}

export const onKeycloakRefreshToken = () => {
  // Get from backend keycloack instead hardcode and subtract one minute grace period
  const calculatedInterval = (inMemoryToken?.expiry - 60) * ONE_SECOND_IN_MS

  // If calculated interval is less than a minute, default to 4 minutes
  const refreshInterval =
    calculatedInterval >= ONE_MINUTE_IN_MS
      ? calculatedInterval
      : 4 * ONE_MINUTE_IN_MS

  if (!interval) {
    interval = setInterval(async () => {
      const nowInGMT =
        Date.now() - new Date().getTimezoneOffset() * ONE_MINUTE_IN_MS

      if (
        !inMemoryToken ||
        nowInGMT >= inMemoryToken.expiry * ONE_SECOND_IN_MS
      ) {
        inMemoryToken = await authentication()
      }
    }, refreshInterval)
  }
}

export const setUserLoginCheck = (response: any) => {
  if (response) {
    setLocalStorage(USER_LOGIN_CHECK, 'success')
    return true
  } else {
    clearInMemoryStorage()
  }
}

export const onKeycloakToken = (response: any) => {
  if (response) {
    inMemoryToken = {
      token: response.access_token,
      expiry: response.expires_in
    }
    inMemoryJwtActionToken = jwt(response.access_token)
    setLocalStorage(JWT_LATEST_EXPIRY, inMemoryJwtActionToken?.exp)
    writeCookie(
      REFRESH_TOKEN,
      response.refresh_token,
      response.refresh_expires_in
    )
    return true
  } else {
    fancyToast('error', 'Unable to write to cookies.')
    return false
  }
}

export const getCurrentAccessToken = (): string => {
  if (!readCookie(REFRESH_TOKEN) || !inMemoryToken) {
    return null
  }
  return inMemoryToken.token
}

export const getAccessToken = async (): Promise<any> => {
  setActive()
  if (inMemoryToken?.token) {
    return inMemoryToken.token
  } else {
    const token = await authentication(true)
    if (!token) {
      return null
    }
    inMemoryToken = token
    return inMemoryToken.token
  }
}

export async function getRoles(): Promise<any> {
  if (!inMemoryJwtActionToken) {
    await getAccessToken()
  }

  const userId = inMemoryJwtActionToken?.sub

  const response: AxiosResponse = await axios({
    method: 'GET',
    url: getUserRolesUrl(userId)
  })

  return response.data
}

export async function fetchRoles() {
  if (!isLoggedIn()) return
  inMemoryRole = await getRoles()
}

export async function isSuperAdminRole(role: string) {
  if (!inMemoryRole) {
    inMemoryRole = await getRoles()
  }
  const result = inMemoryRole?.roles.includes(role)
  return result
}

export async function checkIsAccountAbstract() {
  const token = await getAccessToken()
  try {
    if (!token) {
      return
    }
    const response: AxiosResponse = await axios({
      method: 'GET',
      url: checkAbstract(),
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
    return response.data.isAbstract
  } catch (error) {
    console.error(error.message)
  }
}

export async function fetchInstanceDetails() {
  const token = await getAccessToken()
  try {
    if (!token) {
      return
    }
    const response: AxiosResponse = await axios({
      method: 'GET',
      url: getInstanceDetailsURL(),
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
    return response.data.data
  } catch (error) {
    console.error(error.message)
  }
}

export function getProfileAndWalletRoles(): Set<string> {
  const roles = new Set<string>()
  if (inMemoryRole?.roles) {
    inMemoryRole.roles.forEach((role) => roles.add(role))
  }
  if (inMemoryRole?.wallets) {
    inMemoryRole.wallets.forEach((wallet) => {
      if (wallet.roles.includes(WALLET_ACTIVE)) {
        wallet.roles.forEach((role) => roles.add(role))
      }
    })
  }
  return roles
}

export function getProfileWallets(): string[] {
  return inMemoryRole?.wallets?.map((w: Wallet) => w.address?.toLowerCase())
}

export function hasAccess(role: string, address?: string): boolean {
  const wallets = inMemoryRole?.wallets

  if (address) {
    for (let index = 0; index < wallets?.length; index++) {
      if (wallets[index].address.toLowerCase() === address.toLowerCase()) {
        const result = wallets[index].roles.includes(role)
        if (result) return result
      }
    }
    return false
  }

  const result = inMemoryRole?.roles.includes(role)
  return result
}

export function isValidatedRole() {
  return hasAccess(ROLE_VALIDATED)
}

export function isAdminRole() {
  return hasAccess(ROLE_ADMIN)
}

export function isValidatedLogin() {
  return isLoggedIn() && isValidatedRole()
}

export const getUserEmail = (): string => {
  if (
    inMemoryToken &&
    inMemoryToken.token &&
    inMemoryJwtActionToken &&
    inMemoryJwtActionToken.email
  ) {
    return inMemoryJwtActionToken.email
  }

  return ''
}

export async function changePassword(
  currentPassword: string,
  password: string
): Promise<any> {
  const response: AxiosResponse = await axios({
    method: 'PUT',
    url: putChangePasswordUrl(),
    data: {
      currentPassword,
      password
    }
  })

  return response.data
}

/**
 * Method to accept the invitation with keycloak entry
 * @param data - object containig actionToken, password
 * @param successCallback - function to execute after sucessful response
 * @param errorCallback - function to execute if error occurs
 * @returns invitation process done
 */
export async function acceptUserInvitation(
  actionToken: string,
  data: { password: string },
  successCallback: any,
  errorCallback: any
): Promise<any> {
  const response = await postAsync(
    postAcceptUserInvitationUrl(),
    data,
    {
      headers: {
        Authorization: `Bearer ${actionToken}`
      }
    },
    successCallback,
    errorCallback
  )
  return response?.data
}

export async function getAbstractDetails(): Promise<AbstractDetails> {
  try {
    const { data: response, status } = await axios.get<
      ApiResponse<AbstractDetails>
    >(getAbstractOrgUrl())

    if (status !== HttpStatusCode.Ok) {
      throw Error('Unable to fetch Abstract Organization Details')
    }
    return response.data
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw Error(error.message)
    } else {
      throw Error('Error Occured while fetching Organization Details')
    }
  }
}

export async function addSmartAccount(smartAccountId: string): Promise<any> {
  try {
    const { data: response, status } = await axios.put<ApiResponse<any>>(
      addSmartAccountUrl(smartAccountId)
    )

    if (status !== HttpStatusCode.Ok) {
      throw Error('Unable to add SmartAccountUser')
    }
    return response.data
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error(error.message)
    } else {
      console.error('Error Occured while adding SmartAccountUser')
    }
  }
}

export async function getPaymasterDetails(): Promise<PayMasterDetails> {
  try {
    const { data: response, status } = await axios.get<
      ApiResponse<PayMasterDetails>
    >(getPayMasterDetailsUrl())

    if (status !== HttpStatusCode.Ok) {
      console.error('Unable to fetch Abstract Organization Details')
    }
    return response.data
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error(error.message)
    } else {
      console.error('Error Occured while fetching Paymaster Details')
    }
  }
}

export async function checkPaymasterValidity(): Promise<any> {
  const token = await getAccessToken()
  try {
    if (!token) return
    const payload = { authService: 'jwt' }
    const apiResponse: AxiosResponse = await axios.post<ApiResponse<any>>(
      getPaymasterValidatedUrl(),
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      }
    )
    const { data } = apiResponse

    return data.paymasterConfigured
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error(error.message)
    } else {
      console.error('Error Occured while fetching Paymaster Details')
    }
  }
}

export async function requestResetSso(data: { email: string }): Promise<any> {
  try {
    const response: AxiosResponse = await postAsync(
      getRequestResetSsoUrl(),
      data
    )
    return response?.data
  } catch (error) {
    printErrorStack(error)
  }
}
