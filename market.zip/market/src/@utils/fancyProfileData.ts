import { Asset } from '@oceanprotocol/lib'
import appConfig from '../../app.config'
import { ComputeJobMetaData } from 'src/@types/ComputeJobMetaData'
import {
  PRICE_TYPE_FREE_LABEL,
  PRICE_TYPE_POSTPAY_LABEL
} from '../components/Constants'
import { getNetworkId, getNetworkName } from './wallet'

export interface BaseAssets {
  assetName: string
}

export interface SearchAssets extends BaseAssets {
  algoName?: string
}

export interface ProfileAssets extends BaseAssets {
  id: string
  networkId: number
  publisher: string
  owner?: string
  datePublished?: string
  assetType: string
  accessType: string
  price?: any
  priceValue?: number
  ddo: Asset
  isConnected?: boolean
  isOrderDisabled?: boolean
  minterApproved?: boolean
  isAlgoChecksumValid?: boolean
  subType?: string
}

export interface DownloadedAsset extends ProfileAssets {
  networkId: number
  datePurchase: number
  timeout: number
  orderIdAccount: string
  previousOrderId: string
  isExpired: boolean
  remainingTimeout: number
}

export type FederatedSortTypes =
  | 'asset_asc'
  | 'asset_desc'
  | 'job_asc'
  | 'job_desc'

export function hasSelection(filterItems: any): boolean {
  if (!filterItems) return false

  return Object.values(filterItems).some(
    (value) => typeof value === 'boolean' && value
  )
}

export function getSelectedItems(filterItems): string[] {
  if (!filterItems) return []
  const values = []
  const selectedItems = Object.keys(filterItems)
  selectedItems.forEach((item) => {
    if (filterItems[item]) {
      values.push(item)
    }
  })
  return values
}

export function getSelectedNetworkItems(filterItems: any): number[] {
  if (!filterItems) return []
  const values = []
  const selectedItems = Object.keys(filterItems)
  selectedItems.forEach((item) => {
    if (filterItems[item]) {
      values.push(getNetworkId(item.toLowerCase()))
    }
  })
  return values
}

export function filterByNetwork(
  asset: ProfileAssets[] | DownloadedAsset[],
  network: number[]
): ProfileAssets[] | DownloadedAsset[] {
  let originalAsset = asset
  if (asset && network.length > 0) {
    originalAsset = asset.filter(
      (asset) => network.indexOf(asset.networkId) !== -1
    )
  }
  return originalAsset
}

export function filterByWallet(
  asset: ProfileAssets[] | DownloadedAsset[],
  wallets: string[]
): ProfileAssets[] | DownloadedAsset[] {
  let originalAsset = asset
  if (asset && wallets.length > 0) {
    originalAsset = asset.filter(
      (asset) => wallets.indexOf(asset.publisher.toLowerCase()) !== -1
    )
  }
  return originalAsset
}

export function filterByComputeJobNetwork(
  asset: ComputeJobMetaData[],
  network: number[]
): ComputeJobMetaData[] {
  let originalAsset = asset
  if (asset && network.length > 0) {
    originalAsset = asset.filter(
      (asset) => network.indexOf(asset.networkId) !== -1
    )
  }
  return originalAsset
}

export function filterByOrderWallet(
  asset: DownloadedAsset[],
  wallets: string[]
): DownloadedAsset[] {
  let originalAsset = asset
  if (asset && wallets.length > 0) {
    originalAsset = asset.filter(
      (asset) => wallets.indexOf(asset.orderIdAccount.toLowerCase()) !== -1
    )
  }
  return originalAsset
}

export function filterComputeJobPayer(
  asset: ComputeJobMetaData[],
  wallets: string[]
): ComputeJobMetaData[] {
  let originalAsset = asset
  if (asset && wallets.length > 0) {
    originalAsset = asset.filter(
      (asset) => wallets.indexOf(asset.payer.toLowerCase()) !== -1
    )
  }
  return originalAsset
}

export function filterByDataType(
  asset: ProfileAssets[] | DownloadedAsset[],
  dataType: string[]
): ProfileAssets[] | DownloadedAsset[] {
  if (!dataType?.length || !asset) {
    return asset
  }
  const isPrivate = dataType.indexOf('private') !== -1
  const isPublic = dataType.indexOf('public') !== -1
  const isCompute = dataType.indexOf('compute') !== -1
  const isAccess = dataType.indexOf('access') !== -1
  const isAllSelected = isPrivate && isPublic && isCompute && isAccess
  const isAllDeselected = !isPrivate && !isPublic && !isCompute && !isAccess
  const isDataset =
    !(isCompute || isAccess) && dataType.indexOf('dataset') !== -1
  const isAlgo =
    !(isPrivate || isPublic) && dataType.indexOf('algorithm') !== -1
  if (isAllSelected || (isAllDeselected && !isDataset && !isAlgo)) {
    return asset
  }

  const isDatasetWithAcessType =
    (isCompute || isAccess) && !(isCompute && isAccess)
  const isAlgoWithAcessType =
    (isPrivate || isPublic) && !(isPrivate && isPublic)
  const isAnyDataset =
    isDataset || ((isCompute || isAccess) && !isDatasetWithAcessType)
  const isAnyAlgo = isAlgo || ((isPrivate || isPublic) && !isAlgoWithAcessType)
  const datasetAccessType = isCompute ? 'compute' : 'access'
  const algoAccessType = isPrivate ? 'compute' : 'access'
  const filtered = asset.filter((asset) => {
    return (
      (isAnyDataset && asset.assetType === 'dataset') ||
      (isAnyAlgo && asset.assetType === 'algorithm') ||
      (isDatasetWithAcessType &&
        asset.assetType === 'dataset' &&
        asset.accessType === datasetAccessType) ||
      (isAlgoWithAcessType &&
        asset.assetType === 'algorithm' &&
        asset.accessType === algoAccessType)
    )
  })
  return filtered || asset
}

export function filterByConnectivity(
  asset: ProfileAssets[] | DownloadedAsset[],
  connectivity: string[],
  assetsConnectivity?: { [key: string]: boolean }
): ProfileAssets[] | DownloadedAsset[] {
  const isConnected = connectivity.indexOf('Connected') !== -1
  const isDisconnected = connectivity.indexOf('Disconnected') !== -1
  if (
    (isConnected && isDisconnected) ||
    (!isConnected && !isDisconnected) ||
    !asset
  ) {
    return asset
  }
  const filtered = asset.filter((asset) => {
    return assetsConnectivity
      ? assetsConnectivity[asset?.ddo?.id] === isConnected
      : asset.isConnected === isConnected
  })
  return filtered || asset
}

export function filterByPricing(
  asset: ProfileAssets[],
  pricing: string[]
): ProfileAssets[] {
  if (!asset || !pricing || pricing.length === 3) return asset
  const isNoPriceCreated = pricing.indexOf('No Price Set') !== -1
  const isFreePrice = pricing.indexOf(PRICE_TYPE_FREE_LABEL) !== -1
  const isPostPay = pricing.indexOf(PRICE_TYPE_POSTPAY_LABEL) !== -1
  let filteredAsset = asset
  if (isNoPriceCreated && isFreePrice) {
    filteredAsset = filteredAsset.filter((asset) => asset.priceValue <= 0)
  } else if (isPostPay && isFreePrice) {
    filteredAsset = filteredAsset.filter(
      (asset) =>
        (asset.priceValue > 0 &&
          asset?.ddo?.metadata.additionalInformation?.postpayType) ||
        asset.priceValue === 0
    )
  } else if (isNoPriceCreated) {
    filteredAsset = filteredAsset.filter((asset) => asset.priceValue === -1)
  } else if (isFreePrice) {
    filteredAsset = filteredAsset.filter((asset) => asset.priceValue === 0)
  } else if (isPostPay) {
    filteredAsset = filteredAsset.filter(
      (asset) =>
        asset.priceValue > 0 &&
        asset?.ddo?.metadata.additionalInformation?.postpayType
    )
  }
  return filteredAsset
}

export function filterByAvailablitity(
  asset: ProfileAssets[],
  availability: string[]
): ProfileAssets[] {
  const available = availability.indexOf('Available') !== -1
  const unavailable = availability.indexOf('Unavailable') !== -1

  let filteredAsset = asset
  if (!asset || !availability || availability.length === 2) {
    return asset
  }
  if (available) {
    filteredAsset = asset.filter((asset) => !asset.isOrderDisabled)
  }
  if (unavailable) {
    filteredAsset = asset.filter((asset) => asset.isOrderDisabled)
  }
  return filteredAsset
}

export function searchData(search: string, assets?: SearchAssets[] | any): any {
  if (!search || !assets) return assets
  return assets.filter(
    (asset) =>
      asset.assetName?.toLowerCase().includes(search.toLowerCase()) ||
      asset.algoName?.toLowerCase().includes(search.toLowerCase()) ||
      asset?.guid?.toLowerCase().includes(search.toLowerCase())
  )
}

export function sortData(
  sort: string,
  asset?: ProfileAssets[] | DownloadedAsset[] | Sale[]
): any {
  try {
    if (!sort || !asset) {
      return asset
    }
    switch (sort) {
      case 'asset_asc':
        return asset.sort((a, b) =>
          a.assetName.toLowerCase() < b.assetName.toLowerCase() ? -1 : 1
        )
      case 'asset_desc':
        return asset.sort((a, b) =>
          a.assetName.toLowerCase() > b.assetName.toLowerCase() ? -1 : 1
        )
      case 'date_asc':
        return asset.sort((a, b) =>
          new Date(a.datePublished) > new Date(b.datePublished) ? -1 : 1
        )
      case 'date_desc':
        return asset.sort((a, b) =>
          new Date(a.datePublished) < new Date(b.datePublished) ? -1 : 1
        )
      case 'price_asc':
        return asset.sort((a, b) => a.priceValue - b.priceValue)
      case 'price_desc':
        return asset.sort((a, b) => b.priceValue - a.priceValue)
      case 'expiry_asc':
        return (asset as DownloadedAsset[]).sort((a, b) =>
          a.remainingTimeout < b.remainingTimeout ? -1 : 1
        )
      case 'expiry_desc':
        return (asset as DownloadedAsset[]).sort((a, b) =>
          a.remainingTimeout > b.remainingTimeout ? -1 : 1
        )
      case 'purchased_desc':
        return (asset as DownloadedAsset[]).sort((a, b) =>
          new Date(a.datePurchase) > new Date(b.datePurchase) ? -1 : 1
        )
      case 'order_date_asc':
        return (asset as Sale[]).sort((a, b) =>
          new Date(a.orderDate) > new Date(b.orderDate) ? -1 : 1
        )
      case 'order_date_desc':
        return (asset as Sale[]).sort((a, b) =>
          new Date(a.orderDate) < new Date(b.orderDate) ? -1 : 1
        )
      case 'consumer_asc':
        return (asset as Sale[]).sort((a, b) =>
          a.consumerCompanyName.toLowerCase() <
          b.consumerCompanyName.toLowerCase()
            ? -1
            : 1
        )
      case 'consumer_desc':
        return (asset as Sale[]).sort((a, b) =>
          a.consumerCompanyName.toLowerCase() >
          b.consumerCompanyName.toLowerCase()
            ? -1
            : 1
        )
      default:
        return asset
    }
  } catch (err) {
    return asset
  }
}

export function sortComputeJob(sort: string, jobs?: ComputeJobMetaData[]): any {
  if (!sort || !jobs) {
    return jobs
  }
  switch (sort) {
    case 'asset_asc':
      return jobs.sort((a, b) =>
        a.assetName?.toLowerCase() < b.assetName?.toLowerCase() ? -1 : 1
      )
    case 'asset_desc':
      return jobs.sort((a, b) =>
        a.assetName?.toLowerCase() > b.assetName?.toLowerCase() ? -1 : 1
      )
    case 'job_asc':
      return jobs.sort((a, b) =>
        new Date(Number(a.dateCreated) * 1000) <
        new Date(Number(b.dateCreated) * 1000)
          ? -1
          : 1
      )
    case 'job_desc':
      return jobs.sort((a, b) =>
        new Date(Number(a.dateCreated) * 1000) >
        new Date(Number(b.dateCreated) * 1000)
          ? -1
          : 1
      )
    default:
      return jobs
  }
}

export function sortFederatedComputeBatch(
  sort: FederatedSortTypes,
  jobs?: ComputeJobMetaData[]
): ComputeJobMetaData[] {
  if (!sort || !jobs) {
    return jobs
  }
  switch (sort) {
    case 'asset_asc':
      return jobs.sort((a, b) =>
        a.federatedAlgoName?.toLowerCase() < b.federatedAlgoName?.toLowerCase()
          ? -1
          : 1
      )
    case 'asset_desc':
      return jobs.sort((a, b) =>
        a.federatedAlgoName?.toLowerCase() > b.federatedAlgoName?.toLowerCase()
          ? -1
          : 1
      )
    case 'job_asc':
      return jobs.sort((a, b) =>
        new Date(Number(a.dateCreated) * 1000) <
        new Date(Number(b.dateCreated) * 1000)
          ? -1
          : 1
      )
    case 'job_desc':
      return jobs.sort((a, b) =>
        new Date(Number(a.dateCreated) * 1000) >
        new Date(Number(b.dateCreated) * 1000)
          ? -1
          : 1
      )
    default:
      return jobs
  }
}

export function getSupportedNetworkSelection(): any {
  const selection = {}
  for (let i = 0; i < appConfig.chainIdsSupported.length; i++) {
    const networkName = getNetworkName(appConfig.chainIdsSupported[i], true)
    if (networkName !== 'Unknown') selection[networkName] = false
  }
  return Object.keys(selection)
    .sort()
    .reduce((obj, key) => {
      obj[key] = selection[key]
      return obj
    }, {})
}

export function convertArrayToDefaultSelection(values: string[]) {
  const filterObject = {}
  values.forEach((value) => {
    if (!value) return
    filterObject[value] = false
  })
  return filterObject
}
