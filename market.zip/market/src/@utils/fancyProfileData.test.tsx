import {
  filterByConnectivity,
  filterByNetwork,
  filterByOrderWallet,
  getSelectedItems,
  filterByDataType,
  getSelectedNetworkItems,
  hasSelection,
  searchData,
  convertArrayToDefaultSelection,
  sortData,
  sortComputeJob
} from './fancyProfileData'
import moment from 'moment'
import { mockSales as salesData } from '../../.jest/__fixtures__/sales'
import {
  mockDownloadedAssets,
  mockAssetsConnectivity,
  mockAssetsFilteredByConnectivity,
  mockAssetsFilteredByDataType,
  mockAssetsFilteredByNetworks,
  mockAssetsFilteredByWallets,
  mockAssetsSearchedByTerm,
  mockComputeJobsAssets as computeJobs
} from '../../.jest/__fixtures__/fancyProfileData'
import { cloneDeep } from 'lodash'
import { falsyValues } from '../../.jest/__fixtures__/mockUtils'

function generateFalsyDatas(array: any, key: string) {
  const clonedArray = cloneDeep(array)
  return clonedArray.map((a) => {
    delete a[key]
    return a
  })
}

describe('hasSelection', () => {
  const publicState = 'Public'
  const privateState = 'Private'

  it('should be able return boolean value of false if selections are falsy value', () => {
    const filterItems = [undefined, null]
    filterItems.forEach((filterItem) => {
      const isContainSelected = hasSelection(filterItem)
      expect(typeof isContainSelected).toBe('boolean')
      expect(isContainSelected).toBeFalsy()
    })
  })

  it('should be able return boolean value of false if items of selections are all false', () => {
    const filterItems = {
      [publicState]: false,
      [privateState]: false
    }
    const isContainSelected = hasSelection(filterItems)
    expect(typeof isContainSelected).toBe('boolean')
    expect(isContainSelected).toBeFalsy()
  })

  it('should be able return boolean value of false if some items of selections is not a boolean value', () => {
    let falsyFilterItems: any = {
      Public: 'Test',
      Private: false
    }
    let isContainSelected = hasSelection(falsyFilterItems)
    expect(typeof isContainSelected).toBe('boolean')
    expect(isContainSelected).toBeFalsy()

    falsyFilterItems = {
      Public: 'Test',
      Private: 'Test2'
    }
    isContainSelected = hasSelection(falsyFilterItems)
    expect(typeof isContainSelected).toBe('boolean')
    expect(isContainSelected).toBeFalsy()

    falsyFilterItems = [{}, undefined, null]
    falsyFilterItems.forEach((falsyItem) => {
      isContainSelected = hasSelection(falsyItem)
      expect(typeof isContainSelected).toBe('boolean')
      expect(isContainSelected).toBeFalsy()
    })
  })

  it('should be able return boolean value of true if one of the selections is being chosen', () => {
    const filterItems = {
      [publicState]: false,
      [privateState]: true
    }
    const isContainSelected = hasSelection(filterItems)
    expect(typeof isContainSelected).toBe('boolean')
    expect(isContainSelected).toBeTruthy()
  })
})

describe('getSelectedItems', () => {
  it('should return empty array if falsy filterItems is passed', () => {
    const falsyFilterItems = [undefined, null, {}, []]
    falsyFilterItems.forEach((item) => {
      const result = getSelectedItems(item)
      expect(result).toEqual([])
    })
  })

  it('should return appropriate array if filterItems is passed', () => {
    let filterItems: any = {
      Public: false,
      Private: false
    }
    let result = getSelectedItems(filterItems)
    expect(result).toEqual([])

    filterItems = {
      Public: false,
      Private: true
    }
    result = getSelectedItems(filterItems)
    expect(result).toEqual(['Private'])
  })
})

describe('sortData', () => {
  it('should return falsy asset when falsy asset is passed', () => {
    const falsyAssets = [undefined, null]
    falsyAssets.forEach((falsyAsset) => {
      expect(sortData('asset_asc', falsyAsset)).toBe(falsyAsset)
    })
  })

  it('should return original asset when falsy sort key is passed', () => {
    const randomSortKey = 'asset_test'
    const falsySortKeys = [undefined, null, randomSortKey]
    falsySortKeys.forEach((falsySortKey) => {
      expect(sortData(falsySortKey, salesData)).toBe(salesData)
    })
  })

  // asset name
  it('should return correct list of asset when sort with asset name', () => {
    let sortedList = sortData('asset_asc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].assetName
      const currentData = sortedList[i].assetName
      // Zero means both value are same
      expect(previousData.localeCompare(currentData)).toBeLessThanOrEqual(0)
    }

    sortedList = sortData('asset_desc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].assetName
      const currentData = sortedList[i].assetName
      // Zero means both value are same
      expect(previousData.localeCompare(currentData)).toBeGreaterThanOrEqual(0)
    }

    const falsySales = generateFalsyDatas(salesData, 'assetName')
    sortedList = sortData('asset_desc', falsySales)
    expect(sortedList).toEqual(falsySales)
  })

  // order date
  it('should return correct list of asset when sort with order date', () => {
    let sortedList = sortData('order_date_asc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = moment(sortedList[i - 1].orderDate)
      const currentData = moment(sortedList[i].orderDate)
      expect(previousData.isSameOrAfter(currentData)).toBeTruthy()
    }

    sortedList = sortData('order_date_desc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = moment(sortedList[i - 1].orderDate)
      const currentData = moment(sortedList[i].orderDate)
      expect(previousData.isSameOrBefore(currentData)).toBeTruthy()
    }

    const falsySales = generateFalsyDatas(salesData, 'orderDate')
    sortedList = sortData('order_date_desc', falsySales)
    expect(sortedList).toEqual(falsySales)
  })

  // consumer company name
  it('should return correct list of asset when sort with comsumer company name', () => {
    let sortedList = sortData('consumer_asc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].consumerCompanyName.toLowerCase()
      const currentData = sortedList[i].consumerCompanyName.toLowerCase()
      expect(previousData.localeCompare(currentData)).toBeLessThanOrEqual(0)
    }

    sortedList = sortData('consumer_desc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].consumerCompanyName.toLowerCase()
      const currentData = sortedList[i].consumerCompanyName.toLowerCase()
      expect(previousData.localeCompare(currentData)).toBeGreaterThanOrEqual(0)
    }

    const falsySales = generateFalsyDatas(salesData, 'consumerCompanyName')
    sortedList = sortData('consumer_desc', falsySales)
    expect(sortedList).toEqual(falsySales)
  })

  // price
  it('should return correct list of asset when sort with price', () => {
    let sortedList = sortData('price_asc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].priceValue
      const currentData = sortedList[i].priceValue
      expect(previousData <= currentData).toBeTruthy()
    }

    sortedList = sortData('price_desc', salesData)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].priceValue
      const currentData = sortedList[i].priceValue
      expect(previousData >= currentData).toBeTruthy()
    }

    const falsySales = generateFalsyDatas(salesData, 'priceValue')
    sortedList = sortData('price_desc', falsySales)
    expect(sortedList).toEqual(falsySales)
  })

  // expiry date
  it('should return correct list of asset when sort with expiry date', () => {
    let sortedList = sortData('expiry_asc', mockDownloadedAssets)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].remainingTimeout
      const currentData = sortedList[i].remainingTimeout
      expect(previousData <= currentData).toBeTruthy()
    }

    sortedList = sortData('expiry_desc', mockDownloadedAssets)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].remainingTimeout
      const currentData = sortedList[i].remainingTimeout
      expect(previousData >= currentData).toBeTruthy()
    }

    const falsyDownloads = generateFalsyDatas(
      mockDownloadedAssets,
      'remainingTimeout'
    )
    sortedList = sortData('expiry_desc', falsyDownloads)
    expect(sortedList).toEqual(falsyDownloads)
  })

  // purchased date
  it('should return correct list of asset when sort with recent purchased date', () => {
    let sortedList = sortData('purchased_desc', mockDownloadedAssets)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].datePurchase
      const currentData = sortedList[i].datePurchase
      expect(previousData >= currentData).toBeTruthy()
    }

    const falsyDownloads = generateFalsyDatas(
      mockDownloadedAssets,
      'datePurchase'
    )
    sortedList = sortData('expiry_desc', falsyDownloads)
    expect(sortedList).toEqual(falsyDownloads)
  })

  it('should convert array to default selection except falsy values', () => {
    const testData: any = [
      '0x500db43ee6966e6213ba58eaf152da593eb7432e',
      '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
      'Bello Innovation',
      0,
      NaN,
      null,
      undefined,
      false,
      '',
      '20221025 Heart For 1 hour 1 minute'
    ]
    expect(convertArrayToDefaultSelection(testData)).toEqual({
      '0x500db43ee6966e6213ba58eaf152da593eb7432e': false,
      '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02': false,
      'Bello Innovation': false,
      '20221025 Heart For 1 hour 1 minute': false
    })
  })
})

describe('fancyProfileData', () => {
  it('should return lists of assets that is filtered by the selected connectivity', () => {
    expect(
      filterByConnectivity(
        mockDownloadedAssets,
        ['Connected'],
        mockAssetsConnectivity
      )
    ).toEqual(mockAssetsFilteredByConnectivity)

    expect(
      filterByConnectivity(
        mockDownloadedAssets,
        ['Disconnected'],
        mockAssetsConnectivity
      )
    ).toEqual([
      {
        id: 'did:op:bf097bec4b15c60f7a92e8566706aca8785089a9c8a6b2d9f52f2ebd80a1b0d1',
        assetName: 'Google Drive Test',
        publisher: '0x002D6F48A56E864b910Bc219B63440C6F6508Fe4',
        networkId: 5,
        datePurchase: 1665469236,
        assetType: 'dataset',
        accessType: 'access',
        timeout: 900,
        orderIdAccount: '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02',
        previousOrderId:
          '0x86089341969f64ef803169e8edac8a42efd406c0c99ec9dc77ec525d87816849',
        isExpired: true,
        ddo: {
          '@context': ['https://w3id.org/did/v1'],
          chainId: 5,
          datatokens: [
            {
              address: '0xA7D03e5c08671933695f510F1f5225040A4A9C2F',
              name: 'Caustic Seahorse Token',
              serviceId:
                '79078039ab19b0c3be1f562b94ecb81ec3a3e57f98f780e32962dbbe36eef1ff',
              symbol: 'CAUSEA-10'
            }
          ],
          event: {
            block: 7725351,
            contract: '0x5cdDcD1bb3d52498Cd1F7B8c7739082daAF72EA7',
            datetime: '2022-10-07T02:37:36',
            from: '0x002D6F48A56E864b910Bc219B63440C6F6508Fe4',
            tx: '0x342e5510144db475aa1ae844a42d14518166ad173175a7c1e42d73838ec46976'
          },
          id: 'did:op:bf097bec4b15c60f7a92e8566706aca8785089a9c8a6b2d9f52f2ebd80a1b0d1',
          metadata: {
            additionalInformation: {
              accessPermission: 'allow',
              eula: [
                {
                  url: 'https://drive.google.com/file/d/1s_zpxLQVLaEtKz1TxSf5z2k3Z7PrYJ0k/view?usp=sharing'
                }
              ],
              source: 'ddmdev'
            },
            author: '',
            categories: ['Aerospace'],
            created: '2022-10-07T02:37:14Z',
            description:
              "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.",
            license: 'https://market.oceanprotocol.com/terms',
            name: 'Google Drive Test',
            tags: [],
            type: 'dataset',
            updated: '2022-10-07T02:37:14Z'
          },
          nft: {
            address: '0x5cdDcD1bb3d52498Cd1F7B8c7739082daAF72EA7',
            created: '2022-10-07T02:37:36',
            name: 'Acentrik Test Token',
            owner: '0x002D6F48A56E864b910Bc219B63440C6F6508Fe4',
            state: 0,
            symbol: 'ATT-TEST-8B38C431',
            tokenURI:
              'data:application/json;base64,eyJuYW1lIjoiQWNlbnRyaWsgVGVzdCBUb2tlbiIsInN5bWJvbCI6IkFUVC1URVNULThCMzhDNDMxIiwiZGVzY3JpcHRpb24iOiJUaGlzIHRva2VuIHJlcHJlc2VudHMgdGhlIGhvbGRlcuKAmXMgYWJpbGl0eSB0byBtYW5hZ2UgdGhlIGNvcnJlc3BvbmRpbmcgRGF0YSBBc3NldCBvbiBBY2VudHJpayBEYXRhIE1hcmtldHBsYWNlLlxuXG5WaWV3IG9uIEFjZW50cmlrIE1hcmtldDogaHR0cHM6Ly9tYXJrZXQuYWNlbnRyaWsuaW8vYXNzZXQvZGlkOm9wOmJmMDk3YmVjNGIxNWM2MGY3YTkyZTg1NjY3MDZhY2E4Nzg1MDg5YTljOGE2YjJkOWY1MmYyZWJkODBhMWIwZDEiLCJleHRlcm5hbF91cmwiOiJodHRwczovL21hcmtldC5hY2VudHJpay5pby9hc3NldC9kaWQ6b3A6YmYwOTdiZWM0YjE1YzYwZjdhOTJlODU2NjcwNmFjYTg3ODUwODlhOWM4YTZiMmQ5ZjUyZjJlYmQ4MGExYjBkMSIsImJhY2tncm91bmRfY29sb3IiOiIxNDE0MTQiLCJpbWFnZV9kYXRhIjoiaHR0cHM6Ly9hY2VudHJpay1hc3NldHMuczMuYXAtc291dGhlYXN0LTEuYW1hem9uYXdzLmNvbS9zdGF0aWMvYWNlbnRyaWtfbG9nb19zaG9ydC5zdmcifQ=='
          },
          nftAddress: '0x5cdDcD1bb3d52498Cd1F7B8c7739082daAF72EA7',
          purgatory: {
            state: false,
            reason: ''
          },
          services: [
            {
              additionalInformation: {
                eula: [],
                input: {
                  fileType: ''
                },
                isExperimental: true,
                links: [],
                output: {
                  fileType: '',
                  screenshot: ''
                },
                sampleType: 'URL',
                source: 'ddmdev'
              },
              datatokenAddress: '0xA7D03e5c08671933695f510F1f5225040A4A9C2F',
              description:
                "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.",
              files:
                '0x04851021992876de27f901617cdea9ac2e4d36c1c95977eb1eb4ec5fe2667bb45e7cacd0f6d363756eeae32dc697be4b27661314f37017590d9ab7b40db57bb3f939eed10cbc2b5b582d0dfa8abd532f88e336161508cb3f0113a5f06f422b07d2413eaf4a2850a37d42c8f9409755ca698eba26fee0bcbb18a21d4d0ae13cadd64f87d4b3a02904fd8c548e987f1505d050c019b61d01085de7ad93f39b8007aa1fa469b91e4c3eed61c9e9f9cd435ece67b6f25e9b37cce777a63d9641306052f601e264ac46975f3b08842b78f1d8a7f6b418509298616974c92d8df658f4e6eac57073a837acd6ee4fbaeb0b1edca1015796997e4365785f3f1c7bb0447703b45378a23c8fb394288f548587f11142af5d5b63e5f75547ea1b3036fb054984a8458b70245e014fd1233a4e03ebe6688317877a72dea50fe7fc4edc0e38d43974c168dae8a1d1d3fff46769e9118a69afb4072a01d641e259385fb8a242',
              id: '79078039ab19b0c3be1f562b94ecb81ec3a3e57f98f780e32962dbbe36eef1ff',
              serviceEndpoint: 'https://v1.provider.goerli.dev.acentrik.io',
              timeout: 900,
              type: 'access'
            }
          ],
          stats: {
            orders: 2,
            price: {
              tokenAddress: '0x07865c6E87B9F70255377e024ace6630C1Eaa37F',
              tokenSymbol: 'USDC',
              value: 1
            }
          },
          version: '4.1.0'
        },
        isOrderDisabled: false,
        remainingTimeout: -17539801
      }
    ])
  })

  it('should return original lists of assets if none of connectivity is provided', () => {
    expect(
      filterByConnectivity(mockDownloadedAssets, [], mockAssetsConnectivity)
    ).toEqual(mockDownloadedAssets)
  })

  it('should return lists of assets that is filtered by the selected network', () => {
    expect(filterByNetwork(mockDownloadedAssets, [5])).toEqual(
      mockAssetsFilteredByNetworks
    )
    expect(filterByNetwork(mockDownloadedAssets, [137])).toEqual([])
  })

  it('should return original list of assets if the network is not provided', () => {
    expect(filterByNetwork(mockDownloadedAssets, [])).toEqual(
      mockDownloadedAssets
    )
  })

  it('should return lists of assets that is associated with selected wallet', () => {
    expect(
      filterByOrderWallet(mockDownloadedAssets, [
        '0x7b97450975e89ce1db2ec1fea1f82e234a5d4a02'
      ])
    ).toEqual(mockAssetsFilteredByWallets)
  })

  it('should return lists of assets that is under the selected data type', () => {
    expect(
      filterByDataType(mockDownloadedAssets, ['algorithm', 'public'])
    ).toEqual(mockAssetsFilteredByDataType)

    expect(
      filterByDataType(mockDownloadedAssets, [
        'algorithm',
        'public',
        'private',
        'compute',
        'access'
      ])
    ).toEqual(mockDownloadedAssets)
  })

  it('should return original list of assets if data type is not provided', () => {
    expect(filterByDataType(mockDownloadedAssets, [])).toEqual(
      mockDownloadedAssets
    )
  })

  it('should return lists of networks id based on the selected network items', () => {
    let sampleNetworkItems = {
      'Goerli Testnet': false,
      'Polygon Mainnet': true
    }
    expect(getSelectedNetworkItems(sampleNetworkItems)).toEqual([137])

    sampleNetworkItems = {
      'Goerli Testnet': true,
      'Polygon Mainnet': false
    }
    expect(getSelectedNetworkItems(sampleNetworkItems)).toEqual([5])

    sampleNetworkItems = {
      'Goerli Testnet': true,
      'Polygon Mainnet': true
    }
    expect(getSelectedNetworkItems(sampleNetworkItems)).toEqual([5, 137])
  })

  it('should return empty array lists if network items are not provided', () => {
    falsyValues.forEach((falsyValue) => {
      expect(getSelectedNetworkItems(falsyValue)).toEqual([])
    })
  })

  it('should return filtered list of assets based on the search term', () => {
    expect(
      searchData(
        '20230321 Public Algorithm for nothing - Demo',
        mockDownloadedAssets
      )
    ).toEqual(mockAssetsSearchedByTerm)

    expect(searchData('Expecting no results', mockDownloadedAssets)).toEqual([])
  })

  it('should return original list of assets if the search term is not provided', () => {
    falsyValues.forEach((falsyValue: any) => {
      expect(searchData(falsyValue, mockDownloadedAssets)).toEqual(
        mockDownloadedAssets
      )
    })
  })
})

describe('sortComputeJob', () => {
  it('should return falsy compute assets when falsy compute assets is passed', () => {
    const falsyAssets = [undefined, null]
    falsyAssets.forEach((falsyAsset) => {
      expect(sortComputeJob('asset_asc', falsyAsset)).toBe(falsyAsset)
    })
  })

  it('should return original set of compute assets when falsy sort key is passed', () => {
    const falsyKeys = [undefined, null]
    falsyKeys.forEach((falsyKey) => {
      expect(sortComputeJob(falsyKey, computeJobs)).toBe(computeJobs)
    })
  })

  // asset name
  it('should return correct list of compute jobs when sort with asset name', () => {
    let sortedList = sortComputeJob('asset_asc', computeJobs)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].assetName
      const currentData = sortedList[i].assetName
      expect(previousData.localeCompare(currentData)).toBeLessThanOrEqual(0)
    }

    sortedList = sortComputeJob('asset_desc', computeJobs)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = sortedList[i - 1].assetName
      const currentData = sortedList[i].assetName
      expect(previousData.localeCompare(currentData)).toBeGreaterThanOrEqual(0)
    }

    const falsyComputeJobs = generateFalsyDatas(computeJobs, 'assetName')
    sortedList = sortComputeJob('asset_desc', falsyComputeJobs)
    expect(sortedList).toEqual(falsyComputeJobs)
  })

  // compute job
  it('should return correct list of compute jobs when sort with job created date', () => {
    let sortedList = sortComputeJob('job_asc', computeJobs)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = moment(
        new Date(Number(sortedList[i - 1].dateCreated) * 1000)
      )
      const currentData = moment(
        new Date(Number(sortedList[i].dateCreated) * 1000)
      )
      expect(previousData.isSameOrBefore(currentData)).toBeTruthy()
    }

    sortedList = sortComputeJob('job_desc', computeJobs)
    for (let i = 1; i < sortedList.length; i++) {
      const previousData = moment(
        new Date(Number(sortedList[i - 1].dateCreated) * 1000)
      )
      const currentData = moment(
        new Date(Number(sortedList[i].dateCreated) * 1000)
      )
      expect(previousData.isSameOrAfter(currentData)).toBeTruthy()
    }

    const falsyComputeJobs = generateFalsyDatas(computeJobs, 'dateCreated')
    sortedList = sortComputeJob('job_desc', falsyComputeJobs)
    expect(sortedList).toEqual(falsyComputeJobs)
  })
})
