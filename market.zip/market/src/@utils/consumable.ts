// Kris: This file is RBAC temporary solution
import { Asset, Config } from '@oceanprotocol/lib'
import axios, { AxiosResponse } from 'axios'
import {
  ALLOWED_CONSUME,
  DENY_CONSUME,
  ORDER_DISABLED
} from 'src/components/Constants'
import { getOceanConfig } from './network'
interface ConfigExtended extends Config {
  rbacUri: string
}
interface Consumable {
  status: number
  message: string
  result: boolean
}

function getIsPermitArgs(
  component: string,
  eventType: string,
  authService: string,
  credentials: string,
  credentialsType: string,
  did?: string
) {
  if (eventType === 'consume') {
    return {
      component,
      eventType,
      authService,
      did,
      credentials: {
        type: credentialsType,
        value: credentials
      }
    }
  }
  return {
    component,
    eventType,
    authService,
    credentials: {
      type: credentialsType,
      value: credentials
    }
  }
}

async function fancyPostData(url: string, data?: any): Promise<AxiosResponse> {
  if (data) {
    return axios.post(url, data, {
      headers: {
        'Content-type': 'application/json'
      }
    })
  } else {
    return axios.post(url)
  }
}

async function checkPermit(
  config: ConfigExtended,
  component: string,
  eventType: string,
  authService: string,
  credentials: string,
  credentialsType: string,
  did?: string
): Promise<boolean> {
  if (!config.rbacUri) return true
  const args = getIsPermitArgs(
    component,
    eventType,
    authService,
    credentials,
    credentialsType,
    did
  )

  try {
    const response = await fancyPostData(config.rbacUri, args)
    return response?.data === true
  } catch (e) {
    console.error(e)
    throw new Error('ERROR: Asset URL not found or not available.')
  }
}

/**
 *
 * @param {Asset} asset
 * @param {consumer} string
 * @return {Promise<Consumable>}
 */
export async function checkConsumable(
  asset: Asset | AssetExtended,
  consumer?: string,
  credentialsType?: string,
  authService?: string
): Promise<Consumable> {
  if (!asset) throw new Error('ERROR: Asset does not exist')
  if (asset.nft.state === 4) return ORDER_DISABLED

  const config = getOceanConfig(asset?.chainId) as ConfigExtended
  if (consumer && config?.rbacUri) {
    const isPermit = await checkPermit(
      config,
      'market',
      'consume',
      authService,
      consumer.toLowerCase(),
      credentialsType,
      asset.id
    )

    if (!isPermit) return DENY_CONSUME
  }
  return ALLOWED_CONSUME
}

/**
 *
 * @param {Asset} asset
 * @param {publisher} string
 * @return {Promise<Publishable>}
 */
export async function checkPublishable(
  publisher: string,
  chainId: number,
  authService?: string
): Promise<boolean> {
  const config = getOceanConfig(chainId) as ConfigExtended
  if (publisher && config?.rbacUri) {
    const isPermit = await checkPermit(
      config,
      'market',
      'publish',
      authService,
      publisher.toLowerCase(),
      'address'
    )

    if (!isPermit) return false
  }
  return true
}
