import { postContactProviderUrl } from './api'
import { asyncRequest } from './requestHelper'

export async function contactPublisher(
  did: string,
  inquiryType: string,
  message: string
): Promise<any> {
  const data = {
    did,
    inquiryType,
    message
  }
  return asyncRequest(
    'POST',
    postContactProviderUrl(),
    data,
    'Something went wrong. Please try again.',
    undefined,
    true
  )
}
