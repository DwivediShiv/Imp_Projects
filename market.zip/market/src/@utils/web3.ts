import { getNetworkDisplayName } from '@hooks/useNetworkMetadata'
import { LoggerInstance } from '@oceanprotocol/lib'
import appConfig from '../../app.config'
import { getOceanConfig } from './ocean'

const configGaiaX = getOceanConfig(2021000)

export const networkDataGaiaX: EthereumListsChain = {
  name: 'GAIA-X Testnet',
  chainId: 2021000,
  shortName: 'GAIA-X',
  chain: 'GAIA-X',
  networkId: 2021000,
  nativeCurrency: { name: 'Gaia-X', symbol: 'GX', decimals: 18 },
  rpc: [configGaiaX.nodeUri],
  faucets: [
    'https://faucet.gaiaxtestnet.oceanprotocol.com/',
    'https://faucet.gx.gaiaxtestnet.oceanprotocol.com/'
  ],
  infoURL: 'https://www.gaia-x.eu',
  explorers: [{ name: '', url: '', standard: '' }]
}

export const networkPolygonAcentrik: EthereumListsChain = {
  name: 'Polygon Mainnet',
  chainId: 137,
  rpc: [appConfig?.networkConfig?.polygon?.rpc],
  shortName: 'Polygon Mainnet',
  chain: '137',
  networkId: 137,
  nativeCurrency: {
    name: 'Matic',
    symbol: 'MATIC',
    decimals: 18
  },
  faucets: [],
  infoURL: '',
  explorers: [
    { name: 'polygonscan', url: 'https://polygonscan.com', standard: 'EIP3091' }
  ]
}

export async function addCustomNetwork(
  web3Provider: any,
  network: EthereumListsChain,
  callbackOnSuccess?: () => void
): Promise<void> {
  // Always add explorer URL from ocean.js first, as it's null sometimes
  // in network data
  const blockExplorerUrls = [
    getOceanConfig(network.networkId).explorerUri,
    network.explorers && network.explorers[0].url
  ]

  const newNetworkData = {
    chainId: `0x${network.chainId.toString(16)}`,
    chainName: network.name || getNetworkDisplayName(network, network.chainId),
    nativeCurrency: network.nativeCurrency,
    rpcUrls: network.rpc,
    blockExplorerUrls
  }
  try {
    await web3Provider.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: newNetworkData.chainId }]
    })
    callbackOnSuccess && callbackOnSuccess()
  } catch (switchError) {
    if (switchError.code === 4902) {
      await web3Provider.request(
        {
          method: 'wallet_addEthereumChain',
          params: [newNetworkData]
        },
        (err: string, added: any) => {
          if (err || 'error' in added) {
            LoggerInstance.error(
              `Couldn't add ${network.name} (0x${
                network.chainId
              }) network to MetaMask, error: ${err || added.error}`
            )
          } else {
            LoggerInstance.log(
              `Added ${network.name} (0x${network.chainId}) network to MetaMask`
            )
          }
        }
      )
    } else {
      LoggerInstance.error(
        `Couldn't add ${network.name} (0x${network.chainId}) network to MetaMask, error: ${switchError}`
      )
    }
  }
  LoggerInstance.log(
    `Added ${network.name} (0x${network.chainId}) network to MetaMask`
  )
}
