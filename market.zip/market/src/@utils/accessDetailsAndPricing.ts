import { gql, OperationContext, OperationResult } from 'urql'
import {
  fetchData,
  getOpcFees,
  getQueryContext,
  getSubgraphUri
} from './subgraph'
import {
  TokenPriceQuery,
  TokenPriceQuery_token as TokenPrice,
  TokenPriceQuery_token_orders as TokenOrder
} from '../@types/subgraph/TokenPriceQuery'
import { TokensPriceQuery } from '../@types/subgraph/TokensPriceQuery'
import {
  Asset,
  LoggerInstance,
  ProviderFees,
  ProviderInstance,
  unitsToAmount
} from '@oceanprotocol/lib'
import {
  fancyGetFixedBuyPrice,
  getFixedBuyPrice
} from './ocean/fixedRateExchange'
import Decimal from 'decimal.js'
import appConfig, {
  consumeMarketOrderFee,
  publisherMarketOrderFee
} from '../../app.config'
import { ethers, Signer } from 'ethers'
import { getServiceByName } from './ddo'
import { getTechnicalNetworkName } from './network'

const tokensPriceQuery = gql`
  query TokensPriceQuery($datatokenIds: [ID!], $account: String) {
    tokens(where: { id_in: $datatokenIds }) {
      id
      symbol
      name
      publishMarketFeeAddress
      publishMarketFeeToken
      publishMarketFeeAmount
      orders(
        where: { payer: $account }
        orderBy: createdTimestamp
        orderDirection: desc
      ) {
        tx
        serviceIndex
        createdTimestamp
        providerFee
        providerFeeValidUntil
        reuses(orderBy: createdTimestamp, orderDirection: desc) {
          id
          caller
          createdTimestamp
          tx
          block
          providerFee
          providerFeeValidUntil
        }
      }
      dispensers {
        id
        active
        isMinter
        maxBalance
        token {
          id
          name
          symbol
        }
      }
      fixedRateExchanges {
        id
        exchangeId
        price
        publishMarketSwapFee
        baseToken {
          symbol
          name
          address
          decimals
        }
        datatoken {
          symbol
          name
          address
          decimals
        }
        active
      }
    }
  }
`
const tokenPriceQuery = gql`
  query TokenPriceQuery($datatokenId: ID!, $account: String) {
    token(id: $datatokenId) {
      id
      symbol
      name
      publishMarketFeeAddress
      publishMarketFeeToken
      publishMarketFeeAmount
      orders(
        where: { payer: $account }
        orderBy: createdTimestamp
        orderDirection: desc
      ) {
        tx
        serviceIndex
        createdTimestamp
        providerFee
        providerFeeValidUntil
        reuses(orderBy: createdTimestamp, orderDirection: desc) {
          id
          caller
          createdTimestamp
          tx
          block
          providerFee
          providerFeeValidUntil
        }
      }
      dispensers {
        id
        active
        isMinter
        maxBalance
        token {
          id
          name
          symbol
        }
      }
      fixedRateExchanges {
        id
        exchangeId
        price
        publishMarketSwapFee
        baseToken {
          symbol
          name
          address
          decimals
        }
        datatoken {
          symbol
          name
          address
          decimals
        }
        active
      }
    }
  }
`

const tokensValidOrdersQuery = gql`
  query TokensValidOrdersQuery($datatokenId: ID!) {
    tokens(where: { address: $datatokenId }) {
      id
      orders {
        tx
        createdTimestamp
        providerFee
      }
    }
  }
`

export function getProviderData(providerFee: ProviderFees): ProviderData {
  if (!providerFee?.providerData) {
    return null
  }
  const providerDataBytes = ethers.utils.arrayify(providerFee?.providerData)
  const stringProviderData = String.fromCharCode(...providerDataBytes)
  const providerData: ProviderData = JSON.parse(stringProviderData)
  return providerData
}

function getAccessDetailsFromTokenPrice(
  tokenPrice: TokenPrice,
  timeout?: number
): AccessDetails {
  const accessDetails = {} as AccessDetails

  // Return early when no supported pricing schema found.
  if (
    tokenPrice?.dispensers?.length === 0 &&
    tokenPrice?.fixedRateExchanges?.length === 0
  ) {
    accessDetails.type = 'NOT_SUPPORTED'
    return accessDetails
  }

  if (tokenPrice?.orders?.length > 0) {
    const order = tokenPrice.orders[0] as TokenOrder
    const currentTimestamp = Date.now() / 1000
    const reusedOrder = order?.reuses?.length > 0 ? order.reuses[0] : null
    // the last valid order should be the last reuse order tx id if there is one
    const isFancyReused = reusedOrder?.providerFeeValidUntil > currentTimestamp

    accessDetails.providerFee = JSON.parse(
      isFancyReused ? reusedOrder.providerFee : order.providerFee
    )
    accessDetails.providerData = getProviderData(accessDetails.providerFee)
    const hasProviderData = !!accessDetails.providerData
    // asset is owned if there is an order and asset has timeout 0 (forever) or if the condition is valid
    const isProviderDataTimeoutValid =
      hasProviderData &&
      (accessDetails.providerData?.timeout === 0 ||
        currentTimestamp - accessDetails.providerData?.timestamp <
          accessDetails.providerData?.timeout)
    const isAssetTimeoutValid =
      !hasProviderData &&
      (timeout === 0 || currentTimestamp - order.createdTimestamp < timeout)

    accessDetails.isOwned = isProviderDataTimeoutValid || isAssetTimeoutValid
    if (accessDetails.isOwned) {
      accessDetails.validOrderTx = isFancyReused ? reusedOrder.tx : order.tx
    }
  }

  // TODO: fetch order fee from sub query
  accessDetails.publisherMarketOrderFee =
    tokenPrice?.publishMarketFeeAmount || '0'

  // free is always the best price
  if (tokenPrice?.dispensers?.length > 0) {
    const dispenser = tokenPrice.dispensers[0]
    accessDetails.type = 'free'
    accessDetails.addressOrId = dispenser.token.id
    accessDetails.price = '0'
    accessDetails.isPurchasable = dispenser.active
    accessDetails.datatoken = {
      address: dispenser.token.id,
      name: dispenser.token.name,
      symbol: dispenser.token.symbol
    }
    return accessDetails
  }

  return accessDetails
}

export interface Options {
  isAbstractFlow?: boolean
  opcFee?: string
}
/**
 * This will be used to get price including fees before ordering
 * @param {AssetExtended} asset
 * @return {Promise<OrdePriceAndFee>}
 */
export async function getOrderPriceAndFees(
  asset: AssetExtended,
  accountId: string,
  signer?: Signer,
  providerFees?: ProviderFees,
  options?: Options
): Promise<OrderPriceAndFees> {
  const orderPriceAndFee = {
    price: '0',
    publisherMarketOrderFee:
      asset?.accessDetails?.publisherMarketOrderFee ||
      publisherMarketOrderFee ||
      '0',
    publisherMarketFixedSwapFee: '0',
    consumeMarketOrderFee: consumeMarketOrderFee || '0',
    consumeMarketFixedSwapFee: '0',
    providerFee: {
      providerFeeAmount: '0'
    },
    opcFee: '0',
    computationFee: '0'
  } as OrderPriceAndFees

  // fetch provider fee

  // Fixed: ProviderInstance.initialize here is prevented from calling for Compute, Compute uses InitializeCompute
  const initializeData =
    !providerFees &&
    !getServiceByName(asset, 'compute') &&
    (await ProviderInstance.initialize(
      asset?.id,
      asset?.services[0].id,
      0,
      accountId,
      asset?.services[0].serviceEndpoint
    ))
  orderPriceAndFee.providerFee = providerFees || initializeData?.providerFee
  // fetch price and swap fees
  if (
    asset?.accessDetails?.type === 'free' &&
    (asset?.metadata?.additionalInformation?.postpayType === 'setPrice' ||
      asset?.metadata?.additionalInformation?.postpayType === 'payPerByte')
  ) {
    const price = JSON.parse(
      asset?.metadata?.additionalInformation?.price || {}
    )?.value

    orderPriceAndFee.price = price
  }
  // calculate full price, we assume that all the values are in ocean, otherwise this will be incorrect
  orderPriceAndFee.price = new Decimal(+orderPriceAndFee.price || 0)
    .add(new Decimal(+orderPriceAndFee?.consumeMarketOrderFee || 0))
    .add(new Decimal(+orderPriceAndFee?.publisherMarketOrderFee || 0))
    .toString()
  // Compute fee calculation
  const providerFeeTokenDecimal =
    appConfig?.stableCoin[getTechnicalNetworkName(asset?.chainId)]?.decimals
  orderPriceAndFee.computationFee =
    orderPriceAndFee?.providerFee?.providerFeeAmount &&
    new Decimal(
      await unitsToAmount(
        signer,
        orderPriceAndFee?.providerFee?.providerFeeToken,
        orderPriceAndFee?.providerFee?.providerFeeAmount?.toString(),
        providerFeeTokenDecimal
      )
    ).toString()
  return orderPriceAndFee
}

/**
 * @param {number} chainId
 * @param {string} datatokenAddress
 * @param {number} timeout timout of the service, this is needed to return order details
 * @param {string} account account that wants to buy, is needed to return order details
 * @returns {Promise<AccessDetails>}
 */
export async function getAccessDetails(
  chainId: number,
  datatokenAddress: string,
  timeout?: number,
  account = ''
): Promise<AccessDetails> {
  try {
    const queryContext = getQueryContext(Number(chainId))
    const tokenQueryResult: OperationResult<
      TokenPriceQuery,
      { datatokenId: string; account: string }
    > = await fetchData(
      tokenPriceQuery,
      {
        datatokenId: datatokenAddress?.toLowerCase(),
        account: account?.toLowerCase()
      },
      queryContext
    )

    const tokenPrice: TokenPrice = tokenQueryResult?.data?.token
    const accessDetails = getAccessDetailsFromTokenPrice(tokenPrice, timeout)
    return accessDetails
  } catch (error) {
    LoggerInstance.error('Error getting access details: ', error.message)
  }
}

export async function getAccessDetailsForAssets(
  assets: Asset[] | AssetExtended[],
  account = ''
): Promise<AssetExtended[]> {
  const assetsExtended: AssetExtended[] = assets
  const chainAssetLists: { [key: number]: string[] } = {}

  try {
    for (const asset of assets) {
      if (chainAssetLists[asset.chainId]) {
        chainAssetLists[asset.chainId].push(
          asset.services[0].datatokenAddress.toLowerCase()
        )
      } else {
        chainAssetLists[asset.chainId] = []
        chainAssetLists[asset.chainId].push(
          asset.services[0].datatokenAddress.toLowerCase()
        )
      }
    }

    for (const chainKey in chainAssetLists) {
      const queryContext = getQueryContext(Number(chainKey))
      const tokenQueryResult: OperationResult<
        TokensPriceQuery,
        { datatokenIds: [string]; account: string }
      > = await fetchData(
        tokensPriceQuery,
        {
          datatokenIds: chainAssetLists[chainKey],
          account: account?.toLowerCase()
        },
        queryContext
      )
      tokenQueryResult.data?.tokens.forEach((token) => {
        const currentAsset = assetsExtended.find(
          (asset) =>
            asset.services[0].datatokenAddress.toLowerCase() === token.id
        )
        const accessDetails = getAccessDetailsFromTokenPrice(
          token,
          currentAsset?.services[0]?.timeout
        )

        currentAsset.accessDetails = accessDetails
      })
    }
    return assetsExtended
  } catch (error) {
    LoggerInstance.error('Error getting access details: ', error.message)
  }
}

export async function getValidOrdersForAssets(
  asset: AssetExtended
): Promise<number> {
  try {
    const context: OperationContext = {
      url: `${getSubgraphUri(
        asset?.chainId
      )}/subgraphs/name/oceanprotocol/ocean-subgraph`,
      requestPolicy: 'network-only'
    }

    const result = await fetchData(
      tokensValidOrdersQuery,
      {
        datatokenId: asset?.datatokens?.[0]?.address.toLowerCase()
      },
      context
    )

    const currentTimestamp = Date.now() / 1000
    let validOrders = 0
    const accessDetails = {} as AccessDetails

    result?.data?.tokens?.forEach((token) => {
      token?.orders?.forEach((order) => {
        accessDetails.providerFee = JSON.parse(order.providerFee)
        accessDetails.providerData = getProviderData(accessDetails.providerFee)
        if (
          currentTimestamp <
          accessDetails.providerData?.timestamp +
            accessDetails.providerData?.timeout
        ) {
          validOrders++
        }
      })
    })
    return validOrders || 0
  } catch (error) {
    LoggerInstance.error(
      'Error in retrieving valid orders for assets: ',
      error.message
    )
  }
  return 0
}

// Saransh Note: New ocean function
// export function getAvailablePrice(asset: AssetExtended): AssetPrice {
//   const price: AssetPrice = asset?.stats?.price?.value
//     ? asset?.stats?.price
//     : {
//         value: Number(asset?.accessDetails?.price),
//         tokenSymbol: asset?.accessDetails?.baseToken?.symbol,
//         tokenAddress: asset?.accessDetails?.baseToken?.address
//       }
//   return price
// }
