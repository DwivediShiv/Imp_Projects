import axios, { Method, AxiosResponse, CancelToken } from 'axios'
import fancyToast from '@shared/fancy/atoms/Toast/FancyToast'
import { LoggerInstance } from '@oceanprotocol/lib'

export async function asyncRequest(
  method: Method,
  url: string,
  data?: unknown,
  errorMessage = 'Error occurred.',
  successCode = 200,
  isUseCustomErrorMessage = false,
  headers?: Record<string, string>,
  cancelToken?: CancelToken,
  abortSignal?: AbortSignal,
  isShowToast = true,
  timeout?: number
): Promise<unknown> {
  try {
    const config: any = {
      method,
      url,
      ...(data && { data }),
      headers,
      cancelToken,
      abortSignal
    }

    if (timeout) {
      config.timeout = timeout
    }

    const response: AxiosResponse = await axios(config)

    if (method === 'HEAD') return response

    if (response.status !== successCode) {
      throw new Error('Non-success status code returned.')
    }

    return response.data.data || response.data
  } catch (error) {
    LoggerInstance.error(error)

    const responseErrorMessage = isUseCustomErrorMessage
      ? errorMessage
      : error.response
      ? `${error.response.status}: ${
          error.response.data?.error?.message || error.response.data
        }`
      : errorMessage

    isShowToast && fancyToast('error', responseErrorMessage)
    throw new Error(responseErrorMessage)
  }
}
