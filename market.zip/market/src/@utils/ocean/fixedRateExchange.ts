import {
  amountToUnits,
  FixedRateExchange,
  LoggerInstance,
  PriceAndFees,
  unitsToAmount
} from '@oceanprotocol/lib'
import { ethers, Signer } from 'ethers'
import { getOceanConfig } from '.'
import { consumeMarketFixedSwapFee } from '../../../app.config'
import { getDummySigner } from '@utils/wallet'
import { PRICE_CALCULATION_BASE as BASE } from '@utils/constants'
import {
  TokenPriceQuery_token as TokenPrice,
  TokenPriceQuery_token_fixedRateExchanges as TokenPriceFixedRate
} from '../../@types/subgraph/TokenPriceQuery'

// Conversion of number to uInt256 and then to string
function toUint256String(value) {
  const roundedValue = Math.round(value)
  return BigInt(roundedValue).toString()
}
// Calculate baseToken amount and all other fees
async function calculateTokenAmountPriceFee(
  signer: ethers.Signer,
  fixedRateExchange: any,
  publishMarketFeeAmount?: string,
  oceanFee?: string
): Promise<PriceAndFees> {
  const datatokenAmount = await amountToUnits(
    signer,
    fixedRateExchange?.datatoken?.address,
    '1',
    +fixedRateExchange?.datatoken?.decimals
  )

  const fixedRatePrice = await amountToUnits(
    signer,
    fixedRateExchange?.datatoken?.address,
    fixedRateExchange?.price,
    +fixedRateExchange?.datatoken?.decimals
  )

  const opcFee = await amountToUnits(
    signer,
    fixedRateExchange?.datatoken?.address,
    oceanFee,
    +fixedRateExchange?.datatoken?.decimals
  )

  const baseTokenBefore =
    (+datatokenAmount *
      +fixedRatePrice *
      Math.pow(10, +fixedRateExchange.baseToken.decimals)) /
    Math.pow(10, +fixedRateExchange.datatoken.decimals) /
    BASE

  const priceFee = {
    baseTokenAmount: 0,
    oceanFeeAmount: 0,
    publishMarketFeeAmount: 0,
    consumeMarketFeeAmount: 0
  }

  if (+oceanFee !== 0) {
    priceFee.oceanFeeAmount = (baseTokenBefore * +opcFee) / BASE
  }

  if (+publishMarketFeeAmount !== 0) {
    priceFee.publishMarketFeeAmount =
      (baseTokenBefore * +publishMarketFeeAmount) / BASE
  }

  if (+consumeMarketFixedSwapFee !== 0) {
    priceFee.consumeMarketFeeAmount =
      (baseTokenBefore * +consumeMarketFixedSwapFee) / BASE
  }

  priceFee.baseTokenAmount =
    baseTokenBefore +
    priceFee.publishMarketFeeAmount +
    priceFee.oceanFeeAmount +
    priceFee.consumeMarketFeeAmount

  return {
    baseTokenAmount: toUint256String(priceFee.baseTokenAmount),
    oceanFeeAmount: toUint256String(priceFee.oceanFeeAmount),
    marketFeeAmount: toUint256String(priceFee.publishMarketFeeAmount),
    consumeMarketFeeAmount: toUint256String(priceFee.consumeMarketFeeAmount)
  }
}

// Calculate estimated price from subgraph values
async function fancyCalcBaseInGivenDatatokensOut(
  signer: ethers.Signer,
  fixedRateExchange: TokenPriceFixedRate | null,
  publishMarketFeeAmount?: string,
  oceanFee?: string
): Promise<PriceAndFees> {
  const fee = await calculateTokenAmountPriceFee(
    signer,
    fixedRateExchange,
    publishMarketFeeAmount,
    oceanFee
  )
  const priceAndFees = {
    baseTokenAmount: await unitsToAmount(
      signer,
      fixedRateExchange?.baseToken?.address,
      fee?.baseTokenAmount,
      +fixedRateExchange?.baseToken?.decimals
    ),
    marketFeeAmount: await unitsToAmount(
      signer,
      fixedRateExchange?.baseToken?.address,
      fee?.marketFeeAmount,
      +fixedRateExchange?.baseToken?.decimals
    ),
    oceanFeeAmount: await unitsToAmount(
      signer,
      fixedRateExchange?.baseToken?.address,
      fee?.oceanFeeAmount,
      +fixedRateExchange?.baseToken?.decimals
    ),
    consumeMarketFeeAmount: await unitsToAmount(
      signer,
      fixedRateExchange?.baseToken?.address,
      fee?.consumeMarketFeeAmount,
      +fixedRateExchange?.baseToken?.decimals
    )
  } as PriceAndFees

  return priceAndFees
}

export async function fancyGetFixedBuyPrice(
  chainId?: number,
  signer?: Signer,
  tokeQueryResult?: TokenPrice,
  oceanFee?: any
): Promise<PriceAndFees> {
  try {
    if (!signer && !chainId)
      throw new Error("web3 and chainId can't be undefined at the same time!")

    if (!signer) {
      signer = await getDummySigner(chainId)
    }
    const estimatedPrice = await fancyCalcBaseInGivenDatatokensOut(
      signer,
      tokeQueryResult?.fixedRateExchanges?.[0],
      tokeQueryResult?.publishMarketFeeAmount,
      oceanFee.toString()
    )

    return estimatedPrice
  } catch (e) {
    LoggerInstance.error('[fancyGetFixedBuyPrice] error =', e)
  }
}

/**
 * This is used to calculate the price to buy one datatoken from a fixed rate exchange. You need to pass either a web3 object or a chainId. If you pass a chainId a dummy web3 object will be created
 */
export async function getFixedBuyPrice(
  accessDetails: AccessDetails,
  chainId?: number,
  signer?: Signer
): Promise<PriceAndFees> {
  try {
    const config = getOceanConfig(chainId)

    if (!signer && !chainId)
      throw new Error("web3 and chainId can't be undefined at the same time!")

    if (!signer) {
      signer = await getDummySigner(chainId)
    }

    const fixed = new FixedRateExchange(config.fixedRateExchangeAddress, signer)
    const estimatedPrice = await fixed.calcBaseInGivenDatatokensOut(
      accessDetails.addressOrId,
      '1',
      consumeMarketFixedSwapFee
    )

    return estimatedPrice
  } catch (e) {
    // Temp solution for Private Network (13520): Account with 0 balance will have issue on Reading from RPC
    LoggerInstance.error('[getFixedBuyPrice] error =', e)
    return {
      baseTokenAmount: accessDetails?.price,
      oceanFeeAmount: '0',
      marketFeeAmount: '0',
      consumeMarketFeeAmount: '0'
    }
  }
}
