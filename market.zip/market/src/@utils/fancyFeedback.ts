import { PublishFeedback } from 'src/components/Publish/_types'

export function fancyRetryStep(
  oceanStep: number,
  retryStep: number // undefined will return false
): number {
  if (retryStep > oceanStep) return retryStep
  return oceanStep
}

export function isErrorExist(feedback: PublishFeedback): boolean {
  for (const step in feedback) {
    if (feedback[step].status === 'error') {
      return true
    }
  }
  return false
}

// Map ocean step to our publish step: `99` = confirmed success stepper
export function oceanToFancyPublishStep(oceanStepper: number): number {
  switch (oceanStepper) {
    case 1:
    case 2:
      return 0
    case 3:
      return 1
  }
}

export function getCurrentPublishStep(feedback: PublishFeedback): number {
  for (const step in feedback) {
    if (
      feedback[step].status === 'active' ||
      feedback[step].status === 'pending' ||
      feedback[step].status === 'error'
    )
      return oceanToFancyPublishStep(parseInt(step))
  }
  return 99 // no found 'pending' or 'error' === 'success'
}

export function getFancyPublishSteps() {
  return [
    {
      index: 0,
      label: 'Create your asset',
      description: ''
    },
    {
      index: 1,
      label: `Publish asset`,
      description: ''
    },
    {
      index: 2,
      label: 'Success',
      description: ''
    }
  ]
}

export function oceanToFancyCreatePriceStep(oceanStepper: number): number {
  switch (oceanStepper) {
    case 99:
      return 0
    case 0:
      return 1
    case 1:
      return 2
    case 2:
      return 99
  }
}

export const fancyEditSteps = [
  {
    index: 0,
    label: 'Update metadata',
    description: ''
  },
  {
    index: 1,
    label: 'Success',
    description: ''
  }
]

export const fancyEditPermissionsSteps = [
  {
    index: 0,
    label: 'Update purchase permission',
    description: ''
  },
  {
    index: 1,
    label: 'Success',
    description: ''
  }
]

export const fancyEditRevenueSteps = [
  {
    index: 0,
    label: 'Update revenue account',
    description: ''
  },
  {
    index: 1,
    label: 'Success',
    description: ''
  }
]

export const fancyTransferOwnershipSteps = [
  {
    index: 0,
    label: 'Transfer asset management token',
    description: ''
  },
  {
    index: 1,
    label: 'Success',
    description: ''
  }
]

export const fancyEditFreeSteps = [
  {
    index: 0,
    label: 'Propose removal of minter role from dispenser',
    description: ''
  },
  {
    index: 1,
    label: 'Approve removal of minter role from dispenser',
    description: ''
  },
  {
    index: 2,
    label: 'Update metadata',
    description: ''
  },
  {
    index: 3,
    label: 'Propose new minter role for dispenser',
    description: ''
  },
  {
    index: 4,
    label: 'Approve dispenser as minter',
    description: ''
  },
  {
    index: 5,
    label: 'Success',
    description: ''
  }
]

export function oceanToFancyConsumeStep(
  oceanStepper: number,
  priceType: string
): number {
  switch (oceanStepper) {
    case 0:
      return 0
    case 1:
      return priceType === 'fixed' ? 99 : 0
    case 2:
      return priceType === 'fixed' ? 0 : 2
    case 3:
      return priceType === 'fixed' ? 1 : 2
    case 4:
      return priceType === 'fixed' ? 2 : 99
    case 5:
      return 99
  }
}

export function fancyCreatePriceSteps(priceType: string) {
  switch (priceType) {
    case 'free':
      return [
        {
          index: 0,
          label: 'Activate datatoken dispenser',
          description: ''
        },
        {
          index: 1,
          label: 'Configure datatoken dispenser',
          description: ''
        },
        {
          index: 2,
          label: 'Approve datatoken',
          description: ''
        },
        {
          index: 3,
          label: 'Success',
          description: ''
        }
      ]
  }
}

export const fancyEditPriceSteps = [
  {
    index: 0,
    label: 'Set new price',
    description: ''
  },
  {
    index: 1,
    label: 'Success',
    description: ''
  }
]

export const fancyConsumeOrderSteps: any = [
  {
    index: 2,
    label: 'Sign and download',
    description: ''
  },
  {
    index: 3,
    label: 'Success',
    description: ''
  }
]

export const fancyRepairDispenserSteps = [
  {
    index: 0,
    label: 'Propose new minter role for dispenser',
    description: ''
  },
  {
    index: 1,
    label: 'Approve dispenser as minter',
    description: ''
  },
  {
    index: 2,
    label: 'Success',
    description: ''
  }
]

export const fancyRepairFreSteps = [
  {
    index: 0,
    label: 'Permission to spend datatoken',
    description: ''
  },
  {
    index: 1,
    label: 'Success',
    description: ''
  }
]

export function fancyConsumeSteps(dtSymbol: string, priceType: string) {
  switch (priceType) {
    case 'free':
      return [
        {
          index: 0,
          label: `Order asset`,
          description: ''
        }
      ].concat(fancyConsumeOrderSteps)
  }
}

export function oceanToFancyComputeStep(
  oceanStepper: number,
  priceType: string,
  action: string,
  providerFee?: string
): number {
  const datasetDtStep = action === 'buyAlgo' ? 2 : 0
  switch (oceanStepper) {
    case undefined:
      return 0
    case 0:
    case 1:
    case 2:
      return (
        (priceType === 'free' && providerFee === '0' ? 1 : 0) + datasetDtStep
      )
    case 3:
      return 1 + datasetDtStep
    case 4:
      return 2 + datasetDtStep
    case 5:
      return 99
  }
}

function fancyComputeAlgoSteps(dtSymbol: string, priceType: string) {
  switch (priceType) {
    case 'free':
      return [
        {
          index: 3,
          label: 'Order algorithm',
          description: ''
        }
      ]
    default: {
      return []
    }
  }
}

const fancyComputeOrderSteps: any = [
  {
    index: 4,
    label: 'Sign transaction',
    description: ''
  },
  {
    index: 5,
    label: 'Success',
    description: ''
  }
]

export function fancyComputeSteps(
  dtSymbol: string,
  dtPriceType: string,
  algoSymbol: string,
  algoPriceType: string,
  providerFee?: string
) {
  switch (dtPriceType) {
    case 'free':
      return (
        providerFee !== '0'
          ? [
              {
                index: 0,
                label: 'Approve compute duration',
                description: ''
              },
              {
                index: 1,
                label: 'Order dataset and compute duration',
                description: ''
              }
            ]
          : [
              {
                index: 1,
                label: 'Order dataset',
                description: ''
              }
            ]
      ).concat(
        fancyComputeAlgoSteps(algoSymbol, algoPriceType),
        fancyComputeOrderSteps
      )
  }
}

export function fancyFederatedComputeSteps() {
  return [
    {
      index: 0,
      label: `Order compute datasets`,
      description: ''
    },
    {
      index: 1,
      label: `Order compute algorithms`,
      description: ''
    },
    {
      index: 2,
      label: 'Sign and start compute jobs',
      description: ''
    },
    {
      index: 3,
      label: 'Success',
      description: ''
    }
  ]
}

export function fancyAggregateComputeSteps(isNonZero) {
  switch (isNonZero) {
    case true:
      return [
        {
          index: 0,
          label: `Sign federated compute results`,
          description: ''
        },
        {
          index: 1,
          label: `Approve compute duration`,
          description: ''
        },
        {
          index: 2,
          label: 'Use existing aggregate assets',
          description: ''
        },
        {
          index: 3,
          label: 'Sign transaction',
          description: ''
        },
        {
          index: 4,
          label: 'Success',
          description: ''
        }
      ]
    default:
      return [
        {
          index: 0,
          label: `Sign federated compute results`,
          description: ''
        },
        {
          index: 2,
          label: 'Use existing aggregate assets',
          description: ''
        },
        {
          index: 3,
          label: 'Signing transaction',
          description: ''
        },
        {
          index: 4,
          label: 'Success',
          description: ''
        }
      ]
  }
}

export const fancyDelistAssetSteps = [
  {
    index: 0,
    label: 'Delisting your asset',
    description: ''
  },
  {
    index: 1,
    label: 'Success',
    description: ''
  }
]
