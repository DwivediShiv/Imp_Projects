import { LoggerInstance } from '@oceanprotocol/lib'
import { ProfileAssets } from './fancyProfileData'

export async function setMinterToPublisher(
  ocean: any,
  dataTokenAddress: string,
  accountId: string,
  setIsProcessModal?: (boolean) => void,
  setIsFailModal?: (boolean) => void,
  setModalTemplate?: (string) => void,
  setShowCloseButton?: (boolean) => void,
  setStep?: (number) => void
): Promise<any> {
  // free pricing v3 workaround part1
  const status = await ocean.OceanDispenser.status(dataTokenAddress)
  if (status.minterApproved) {
    const response = await ocean.OceanDispenser.cancelMinter(
      dataTokenAddress,
      accountId
    ).next((value) => {
      setStep && setStep(value)
    })
    if (!response) {
      LoggerInstance.error('Failed at cancelMinter')
      // For /asset edit:
      setIsProcessModal && setIsProcessModal(false)
      setIsFailModal && setIsFailModal(true)
      // For published board:
      setModalTemplate && setModalTemplate('failedUpdatePublicBoard')
      setShowCloseButton && setShowCloseButton(true)
    }
    return response
  }
  return true
}

// convert observer's value in Ocean.js's SubscribablePromise of <DispenserMakeMinterProgressStep>
function oceanToMakeMinterStepper(observerValue: number) {
  if (observerValue === 0) return 3
  else if (observerValue === 1) return 4
}

export async function setMinterToDispenser(
  ocean: any,
  dataTokenAddress: string,
  accountId: string,
  setIsProcessModal?: (boolean) => void,
  setIsFailModal?: (boolean) => void,
  setModalTemplate?: (string) => void,
  setShowCloseButton?: (boolean) => void,
  setStep?: (number) => void,
  isRepair?: boolean
): Promise<any> {
  // free pricing v3 workaround part2
  const response = await ocean.OceanDispenser.makeMinter(
    dataTokenAddress,
    accountId
  ).next((value) => {
    setStep && setStep(isRepair ? value : oceanToMakeMinterStepper(value))
  })
  if (!response) {
    LoggerInstance.error('Failed at makeMinter')
    // For /asset edit:
    setIsProcessModal && setIsProcessModal(false)
    setIsFailModal && setIsFailModal(true)
    // For published board:
    setModalTemplate && setModalTemplate('failedUpdatePublicBoard')
    setShowCloseButton && setShowCloseButton(true)
  }
  return response
}

export function sortFreeErrorAbove(assets?: ProfileAssets[]): ProfileAssets[] {
  // error free price will be placed on top without affecting previous sort condition
  return [
    ...assets.filter((asset) => !asset.minterApproved),
    ...assets.filter((asset) => asset.minterApproved)
  ]
}
