import { ComputeEditForm } from '@components/Asset/Edit/_types'
import { FormPublishData } from '@components/Publish/_types'
import {
  Arweave,
  Asset,
  DDO,
  FileInfo,
  GraphqlQuery,
  Ipfs,
  LocalStorage,
  Service,
  Smartcontract,
  UrlFile,
  CloudStorageFile
} from '@oceanprotocol/lib'
import { checkJson } from './codemirror'
import {
  UNLIMITED_TIMEOUT_TYPE,
  UNLIMITED_TIMEOUT_VALUE
} from '@components/@shared/fancy/FancyAssetValidityInput/constant'

interface Consumable {
  status: number
  message: string
  result: boolean
}

export function isValidDid(did: string): boolean {
  const regex = /did:op:[A-Za-z0-9]{64}/
  return regex.test(did)
}

export function getServiceByName(
  ddo: Asset | AssetExtended | DDO,
  name: 'access' | 'compute' | 'metadata'
): Service {
  if (!ddo) return

  const service = ddo.services.filter((service) => service.type === name)[0]
  return service
}

export function getServiceById(
  ddo: Asset | DDO | AssetExtended,
  serviceId: string
): Service {
  if (!ddo) return

  const service = ddo.services.find((s) => s.id === serviceId)
  return service
}

export function fancyConvertTimeoutToSeconds(
  timeoutInput: string,
  timeoutDurationType: string
): number {
  const timeoutValue = parseInt(timeoutInput, 10)
  if (
    (isNaN(timeoutValue) || timeoutValue < 0) &&
    timeoutDurationType !== UNLIMITED_TIMEOUT_TYPE
  )
    return

  switch (timeoutDurationType) {
    case 'hour(s)':
      return timeoutValue * 3600
    case 'day(s)':
      return timeoutValue * 86400
    case 'month(s)':
      // Assume 1 month duration of 30 days for conversion
      return timeoutValue * 30 * 86400
    case 'year(s)':
      // Assume a year duration of 365 days for conversion
      return timeoutValue * 365 * 86400
    case UNLIMITED_TIMEOUT_TYPE:
      return 0
  }
}

// Backward Compatible Handling for Edit Case: (Release v3.1.0 and below assets)
export function fancyEstimateOldAssetDurationType(
  timeoutInSeconds: number
): string {
  switch (timeoutInSeconds) {
    case 0:
      return UNLIMITED_TIMEOUT_TYPE
    case 3600:
      return 'hour(s)'
    case 86400:
    case 604800:
      return 'day(s)'
    case 2630000:
      return 'month(s)'
    case 31556952:
      return 'year(s)'
  }
}

export function fancyConvertSecondsToTimeoutOfDurationType(
  timeoutInSeconds: number,
  timeoutDurationType: string
): string {
  const timeoutValue = timeoutInSeconds
  if (isNaN(timeoutValue) || timeoutValue < 0) return

  // This handle old asset's Edit
  if (!timeoutDurationType) {
    timeoutDurationType = fancyEstimateOldAssetDurationType(timeoutInSeconds)
  }

  switch (timeoutDurationType) {
    case 'hour(s)':
      return Math.round(timeoutValue / 3600).toString()
    case 'day(s)':
      return Math.round(timeoutValue / 86400).toString()
    case 'month(s)':
      // Assume 1 month duration of 30 days for conversion
      return Math.round(timeoutValue / (30 * 86400)).toString()
    case 'year(s)':
      // Assume a year duration of 365 days for conversion
      return Math.round(timeoutValue / (365 * 86400)).toString()
    case UNLIMITED_TIMEOUT_TYPE:
      return UNLIMITED_TIMEOUT_VALUE.toString()
  }
}

export function mapTimeoutStringToSeconds(timeout: string): number {
  switch (timeout) {
    case 'Unlimited Period':
      return 0
    case '15 Minutes':
      return 900
    case '1 Hour':
      return 3600
    case '1 Day':
      return 86400
    case '1 Week':
      return 604800
    case '1 Month':
      return 2630000
    case '1 Year':
      return 31556952
    default:
      return 0
  }
}

function numberEnding(number: number): string {
  return number > 1 ? 's' : ''
}

export function secondsToString(numberOfSeconds: number): string {
  if (numberOfSeconds === 0) return 'Forever'

  const years = Math.floor(numberOfSeconds / 31536000)
  const months = Math.floor((numberOfSeconds %= 31536000) / 2630000)
  const weeks = Math.floor((numberOfSeconds %= 31536000) / 604800)
  const days = Math.floor((numberOfSeconds %= 604800) / 86400)
  const hours = Math.floor((numberOfSeconds %= 86400) / 3600)
  const minutes = Math.floor((numberOfSeconds %= 3600) / 60)
  const seconds = numberOfSeconds % 60

  return years
    ? `${years} year${numberEnding(years)}`
    : months
    ? `${months} month${numberEnding(months)}`
    : weeks
    ? `${weeks} week${numberEnding(weeks)}`
    : days
    ? `${days} day${numberEnding(days)}`
    : hours
    ? `${hours} hour${numberEnding(hours)}`
    : minutes
    ? `${minutes} minute${numberEnding(minutes)}`
    : seconds
    ? `${seconds} second${numberEnding(seconds)}`
    : 'less than a second'
}

// this is required to make it work properly for preview/publish/edit/debug.
// TODO: find a way to only have FileInfo interface instead of FileExtended
interface FileExtended extends FileInfo {
  url?: string
  query?: string
  transactionId?: string
  address?: string
  abi?: string
  headers?: { key: string; value: string }[]
}

export function normalizeFile(
  storageType: string,
  file: FileExtended,
  chainId: number
) {
  let fileObj
  const headersProvider = {}
  const headers = file[0]?.headers || file?.headers
  if (headers && headers.length > 0) {
    headers.map((el) => {
      headersProvider[el.key] = el.value
      return el
    })
  }
  switch (storageType) {
    case 'ipfs': {
      fileObj = {
        type: storageType,
        hash: file[0]?.url || file?.url
      } as Ipfs
      break
    }
    case 'arweave': {
      fileObj = {
        type: storageType,
        transactionId:
          file[0]?.url ||
          file?.url ||
          file[0]?.transactionId ||
          file?.transactionId
      } as Arweave
      break
    }
    case 'graphql': {
      fileObj = {
        type: storageType,
        url: file[0]?.url || file?.url,
        query: file[0]?.query || file?.query,
        headers: headersProvider
      } as GraphqlQuery
      break
    }
    case 'smartcontract': {
      // clean obj
      fileObj = {
        chainId,
        type: storageType,
        address: file[0]?.address || file?.address || file[0]?.url || file?.url,
        abi: checkJson(file[0]?.abi || file?.abi)
          ? JSON.parse(file[0]?.abi || file?.abi)
          : file[0]?.abi || file?.abi
      } as Smartcontract
      break
    }
    case 'localstorage': {
      fileObj = {
        type: 'localstorage',
        index: 0,
        url: file?.[0]?.url || file?.url,
        headers: headersProvider,
        method: file.method
      } as LocalStorage
      break
    }
    case 's3': {
      fileObj = {
        type: 's3',
        index: 0,
        url: file?.[0]?.url || file?.url,
        headers: headersProvider,
        method: file.method
      } as CloudStorageFile
      break
    }
    default: {
      fileObj = {
        type: 'url',
        index: 0,
        url: file ? file[0]?.url || file?.url : null,
        headers: headersProvider,
        method: file.method
      } as UrlFile
      break
    }
  }
  return fileObj
}

export function previewDebugPatch(
  values: FormPublishData | Partial<MetadataEditForm> | ComputeEditForm,
  chainId: number
) {
  // handle file's object property dynamically
  // without braking Yup and type validation
  const buildValuesPreview = JSON.parse(JSON.stringify(values))

  // fallback for edit mode under "edit compute settings"
  if (!buildValuesPreview.services) return buildValuesPreview

  const valuesService = buildValuesPreview.services
    ? buildValuesPreview.services[0]
    : buildValuesPreview
  valuesService.files[0] = normalizeFile(
    valuesService?.files[0]?.type,
    valuesService?.files[0],
    chainId
  )

  return buildValuesPreview
}

// Saransh Note: new market function
// export function parseConsumerParameters(
//   consumerParameters: ConsumerParameter[]
// ): FormConsumerParameter[] {
//   if (!consumerParameters?.length) return []

//   return consumerParameters.map((param) => ({
//     ...param,
//     required: param.required ? 'required' : 'optional',
//     options:
//       param.type === 'select'
//         ? JSON.parse(param.options)?.map((option) => {
//             const key = Object.keys(option)[0]
//             return {
//               key,
//               value: option[key]
//             }
//           })
//         : [],
//     default:
//       param.type === 'boolean'
//         ? param.default === 'true'
//         : param.type === 'number'
//         ? Number(param.default)
//         : param.default
//   }))
// }
