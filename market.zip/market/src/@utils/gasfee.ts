import {
  allowance,
  approve,
  Asset,
  Datatoken,
  DatatokenCreateParams,
  FixedRateExchange,
  FreCreationParams,
  FreOrderParams,
  GASLIMIT_DEFAULT,
  getFairGasPrice,
  getHash,
  Metadata,
  Nft,
  NftCreateData,
  NftFactory,
  OrderParams,
  ProviderComputeInitialize,
  ProviderFees,
  ProviderInstance,
  Service,
  ServiceComputeOptions,
  ZERO_ADDRESS
} from '@oceanprotocol/lib'
import { CancelToken } from 'axios'
import {
  getBaseTokenAddress,
  getBaseTokenDecimals,
  getStablecoinDecimal
} from 'src/components/Publish/fancyPublishUtils'
import { FormPublishData } from 'src/components/Publish/_types'
import { fancyTransformPublishFormToDdo } from 'src/components/Publish/_utils'
import { FancyConfig } from 'src/models/FancyConfig'
import { transformComputeFormToServiceComputeOptions } from './compute'
import { fancyGenerateNftMetadata, generateNftCreateData } from './nft'
import { getSiteMetadata } from './siteConfig'
import { mapTimeoutStringToSeconds } from './ddo'
import {
  fancyGetFilesEncrypted,
  fancyPrepareEditAsset,
  fancyPrepareUpdatedMetadata
} from './fancyAssetConvertor'
import Decimal from 'decimal.js'
import { isFormValuesChanged } from './form'
import { Signer } from '@wagmi/core'
import { ethers } from 'ethers'
import { parseEther } from 'ethers/lib/utils'
import { networkDataAcentrikTestnet } from '@hooks/useNetworkMetadata/constants'

const FANCY_GASLIMIT_DEFAULT = 500000
const GAS_PRICE_WEI = 1000 // same as ocean.js 0.00001 gwei hardcode

async function getGasPriceInEther( // Return unit Ether(Buterin) 18 decimal
  signer: Signer,
  config: FancyConfig
): Promise<number> {
  const chainId = await signer.getChainId()
  const weiGasPrice =
    chainId === networkDataAcentrikTestnet?.chainId
      ? GAS_PRICE_WEI
      : await getFairGasPrice(signer, config?.gasFeeMultiplier)
  const etherGasPrice = parseFloat(ethers.utils.formatEther(weiGasPrice))
  return etherGasPrice
}

export async function estimatePublishFee(
  values: FormPublishData,
  accountId: string,
  config: FancyConfig,
  nftFactory: NftFactory,
  signer: Signer,
  newCancelToken: CancelToken,
  newAbortController: AbortSignal
): Promise<number> {
  const { gasEstimateNftAddress, gasEstimateNftOwnerAddress } = config
  let createNFTAndPricingGasLimit = 0
  let publishDdoGasLimit = 0

  const nftCreateData: NftCreateData = generateNftCreateData(
    values.metadata.nft,
    accountId,
    values.metadata.transferable
  )
  const { appConfig } = getSiteMetadata()

  // TODO: cap is hardcoded for now to 1000, this needs to be discussed at some point
  const ercParams: DatatokenCreateParams = {
    templateIndex: 2,
    minter: accountId,
    paymentCollector: values.paymentCollector
      ? values.paymentCollector
      : accountId, // set paymentCollector address with this attr first, later might rename after oceanJs changed
    mpFeeAddress: appConfig.marketFeeAddress,
    feeToken: config.oceanTokenAddress,
    feeAmount: appConfig.publisherMarketOrderFee,
    cap: '1000',
    name: values.services[0].dataTokenOptions.name,
    symbol: values.services[0].dataTokenOptions.symbol
  }

  const baseTokenAddress =
    getBaseTokenAddress(config.chainId, values.baseToken) ||
    config.oceanTokenAddress
  const baseTokenDecimals =
    (await getBaseTokenDecimals(baseTokenAddress, config)) || 18

  // Dynamic price estGas excluded
  switch (values.pricing.type.toLowerCase()) {
    case 'free': {
      // maxTokens -  how many tokens cand be dispensed when someone requests . If maxTokens=2 then someone can't request 3 in one tx
      // maxBalance - how many dt the user has in it's wallet before the dispenser will not dispense dt
      // both will be just 1 for the market
      const dispenserParams = {
        dispenserAddress: config.dispenserAddress,
        maxTokens: parseEther('1').toString(),
        maxBalance: parseEther('1').toString(),
        withMint: true,
        allowedSwapper: ZERO_ADDRESS
      }

      const gasLimit = await nftFactory.createNftWithDatatokenWithDispenser(
        nftCreateData,
        ercParams,
        dispenserParams,
        true
      )

      createNFTAndPricingGasLimit = gasLimit.toNumber()
      break
    }
  }
  const computeValues = values.services[0]
    .computeOptions as ServiceComputeOptions
  const computePrivacy = await transformComputeFormToServiceComputeOptions(
    {
      publisherTrustedAlgorithms:
        computeValues?.publisherTrustedAlgorithms as unknown as string[],
      allowAllPublishedAlgorithms: false
    },
    values.services[0].computeOptions,
    values.user.chainId,
    newCancelToken
  )
  const ddo = await fancyTransformPublishFormToDdo(
    {
      ...values,
      services: [
        {
          ...values.services[0],
          computeOptions: { ...computePrivacy }
        }
      ]
    },
    ZERO_ADDRESS,
    gasEstimateNftAddress || ZERO_ADDRESS
  )

  const encryptedDdo = await ProviderInstance.encrypt(
    ddo,
    values.user.chainId,
    config?.encryptionProviderUri || values.services[0].providerUrl.url,
    newAbortController
  )

  const nft = new Nft(signer, config?.chainId, config)
  const nftMetadata = values?.metadata?.nft
  const encryptProviderUrl = values.services[0].providerUrl.url
  const metadataAndTokenURI = fancyGenerateNftMetadata(
    ddo,
    nftMetadata,
    encryptedDdo,
    config,
    encryptProviderUrl
  )

  try {
    publishDdoGasLimit = (
      await nft.setMetadataAndTokenURI(
        gasEstimateNftAddress || ZERO_ADDRESS,
        gasEstimateNftOwnerAddress || accountId,
        metadataAndTokenURI,
        true
      )
    ).toNumber()
  } catch (error) {
    // unable to stimulate for estimate gas due to smart contract validation check `not metadata role`
    // Cause: ocean.js removed `caller's address` input, now default to wagmi signer address as caller
    // How to fix: Raise ocean issue/PR for setMetadataAndTokenURI enhancement
    publishDdoGasLimit = GASLIMIT_DEFAULT || FANCY_GASLIMIT_DEFAULT
  }

  const totalGasLimit = createNFTAndPricingGasLimit + publishDdoGasLimit
  const gasPrice = await getGasPriceInEther(signer, config)
  return totalGasLimit * gasPrice
}

export async function estimateSetNftMetadataFee(
  initialValues: FormPublishData,
  values: FormPublishData,
  accountId: string,
  config: FancyConfig,
  signer: Signer,
  asset: AssetExtended,
  newCancelToken: CancelToken,
  newAbortController: AbortSignal,
  updatedAsset?: Asset
): Promise<number> {
  const { accessDetails, ...assetWithoutPrice } = asset
  let isMetadataEdited
  const editPriceGasLimit = 0
  let editDdoGasLimit = 0

  if (!updatedAsset) {
    const isPriceEdited = isFormValuesChanged(
      accessDetails,
      values?.pricing,
      'EDIT_PRICE'
    )
    isMetadataEdited = isFormValuesChanged(
      initialValues,
      values,
      'EDIT_METADATA'
    )

    if (isMetadataEdited) {
      // Ignoring IPFS Screenshot, links, eula bytes in gas limit size (non-critical)
      values = fancyPrepareEditAsset(assetWithoutPrice, values, initialValues)
      const filesEncrypted = await fancyGetFilesEncrypted(
        values,
        assetWithoutPrice.nftAddress,
        assetWithoutPrice.datatokens?.[0]?.address
      )

      const computeValues = values.services[0]
        .computeOptions as ServiceComputeOptions
      const computePrivacy = await transformComputeFormToServiceComputeOptions(
        {
          publisherTrustedAlgorithms:
            computeValues?.publisherTrustedAlgorithms as unknown as string[],
          allowAllPublishedAlgorithms: false
        },
        values.services[0].computeOptions,
        values.user.chainId,
        newCancelToken
      )
      const updatedMetadata: Metadata = await fancyPrepareUpdatedMetadata(
        assetWithoutPrice,
        values
      )

      const updatedService: Service = {
        ...assetWithoutPrice.services[0],
        description: values.services[0].description,
        timeout: mapTimeoutStringToSeconds(values.services[0].timeout),
        files: filesEncrypted || assetWithoutPrice.services[0].files,
        serviceEndpoint: filesEncrypted
          ? values.services[0].providerUrl.url
          : assetWithoutPrice.services[0].serviceEndpoint,
        additionalInformation: {
          ...assetWithoutPrice.services[0].additionalInformation,
          previousServiceEndpoints:
            values.services[0].additionalInformation?.previousServiceEndpoints,
          isExperimental: values?.isExperimental === 'Experimental',
          eula: values.eula,
          sampleType: values.sampleType,
          links: values?.links,
          input: {
            ...assetWithoutPrice.services[0].additionalInformation?.input,
            fileType:
              assetWithoutPrice.metadata.type === 'algorithm'
                ? values?.input
                : ''
          },
          output: {
            ...assetWithoutPrice.services[0].additionalInformation?.output,
            fileType:
              assetWithoutPrice.metadata.type === 'algorithm'
                ? values?.output
                : '',
            screenshot:
              assetWithoutPrice.services[0].additionalInformation?.output
                ?.screenshot || ''
          }
        },
        ...(assetWithoutPrice.services[0].type === 'compute' && {
          compute: { ...computePrivacy }
        })
      }

      updatedAsset = {
        ...assetWithoutPrice,
        metadata: updatedMetadata,
        services: [updatedService]
      }
    }
  }

  if (isMetadataEdited || updatedAsset) {
    const fancyEncryptionProviderUri =
      config?.encryptionProviderUri ||
      assetWithoutPrice.services[0].serviceEndpoint
    const encryptedDdo = await ProviderInstance.encrypt(
      assetWithoutPrice,
      assetWithoutPrice?.chainId || values?.user?.chainId,
      fancyEncryptionProviderUri,
      newAbortController
    )

    const metadataHash = getHash(JSON.stringify(updatedAsset))
    const nft = new Nft(signer, config?.chainId, config)
    // theoretically used by aquarius or provider, not implemented yet, will remain hardcoded
    const flags = ethers.utils.hexlify(2)

    editDdoGasLimit = (
      await nft.setMetadata(
        updatedAsset?.nftAddress,
        accountId,
        updatedAsset?.nft?.state || 0,
        fancyEncryptionProviderUri,
        '',
        flags,
        encryptedDdo,
        '0x' + metadataHash,
        [],
        true
      )
    ).toNumber()
  }

  const totalGasLimit = editDdoGasLimit + editPriceGasLimit
  const gasPrice = await getGasPriceInEther(signer, config)
  return totalGasLimit * gasPrice
}

export async function estimateSetNftMetadataStateFee(
  signer: Signer,
  config: FancyConfig,
  nftAddress: string,
  address: string,
  metadataState: number
) {
  const nft = new Nft(signer, config?.chainId, config)
  const setMetadataStateGasLimit = (
    await nft.setMetadataState(nftAddress, address, metadataState, true)
  ).toNumber()

  const gasPrice = await getGasPriceInEther(signer, config)
  return setMetadataStateGasLimit * gasPrice
}

export async function estimateSetPaymentCollectorFee(
  config: FancyConfig,
  signer: Signer,
  dtAddress: string,
  accountId: string,
  paymentCollector: string,
  datatokenInstance?: Datatoken
) {
  const setPaymentCollectorGasLimit = (
    await datatokenInstance.setPaymentCollector(
      dtAddress,
      accountId,
      paymentCollector,
      true
    )
  ).toNumber()

  const gasPrice = await getGasPriceInEther(signer, config)
  return setPaymentCollectorGasLimit * gasPrice
}

export async function estimateTransferOwnershipGas(
  config: FancyConfig,
  signer: Signer,
  nftAddress: string,
  nftOwner: string,
  nftReceiver: string,
  tokenId: number
) {
  const nft = new Nft(signer, config?.chainId, config)
  const gasLimit = (
    await nft.safeTransferNft(nftAddress, nftOwner, nftReceiver, tokenId, true)
  ).toNumber()
  const gasPrice = await getGasPriceInEther(signer, config)
  return gasLimit * gasPrice
}

async function estimateApproveGas(
  config: FancyConfig,
  signer: Signer,
  accountId: string,
  tokenAddress: string,
  spender: string,
  amount: string
): Promise<number> {
  const currentAllowance = await allowance(
    signer,
    tokenAddress,
    accountId,
    spender
  )
  if (new Decimal(currentAllowance).greaterThanOrEqualTo(new Decimal(amount)))
    return 0

  const approveGasLimit = await approve(
    signer,
    config,
    accountId,
    tokenAddress,
    spender,
    amount,
    null,
    getStablecoinDecimal(config.chainId),
    true
  )
  return approveGasLimit
}

// Kris: always throw error with default 1million gas limit when not approved spending
export async function estimateOrderFee(
  config: FancyConfig,
  signer: Signer,
  accountId: string,
  orderPriceAndFees: OrderPriceAndFees,
  asset: AssetExtended,
  initializeData: ProviderComputeInitialize,
  computeConsumerAddress?: string,
  providerFees?: ProviderFees
): Promise<number> {
  if (initializeData?.validOrder && !initializeData?.providerFee) {
    return 0
  }
  const datatoken = new Datatoken(signer, config?.chainId, config)
  const { appConfig } = getSiteMetadata()
  const approvalGasLimit = 0
  let buyAndOrderGasLimit = 0

  const orderParams = {
    consumer: computeConsumerAddress || accountId,
    serviceIndex: 0,
    _providerFee: providerFees || initializeData?.providerFee,
    _consumeMarketFee: {
      consumeMarketFeeAddress: appConfig.marketFeeAddress,
      consumeMarketFeeAmount: appConfig.consumeMarketOrderFee,
      consumeMarketFeeToken: config.oceanTokenAddress
    }
  } as OrderParams

  switch (asset.accessDetails?.type) {
    case 'free': {
      try {
        buyAndOrderGasLimit =
          initializeData?.validOrder || asset?.accessDetails?.isOwned
            ? (
                await datatoken.reuseOrder(
                  asset.accessDetails.datatoken.address,
                  initializeData?.validOrder ||
                    asset?.accessDetails?.validOrderTx,
                  providerFees || initializeData?.providerFee,
                  true
                )
              ).toNumber()
            : (
                await datatoken.buyFromDispenserAndOrder(
                  asset.services[0].datatokenAddress,
                  orderParams,
                  config.dispenserAddress,
                  true
                )
              ).toNumber()
        // Kris: Keep this default limit in case of ocean.js library have fallback gaslimit_default
        if (buyAndOrderGasLimit === GASLIMIT_DEFAULT)
          buyAndOrderGasLimit = FANCY_GASLIMIT_DEFAULT
      } catch (error) {
        buyAndOrderGasLimit = FANCY_GASLIMIT_DEFAULT
      }
      break
    }
  }

  const totalGasLimit = +approvalGasLimit + +buyAndOrderGasLimit
  const gasPrice = await getGasPriceInEther(signer, config)
  return totalGasLimit * gasPrice
}
