import { Wallet } from '../@types/User'

export function getIsWalletHasRole(
  wallets: Wallet[],
  address: string,
  role: string
): boolean {
  const wallet: Wallet = wallets?.find((wallet) => wallet.address === address)
  const filteredRole = wallet?.roles?.find((walletRole) => walletRole === role)
  return !!filteredRole
}
