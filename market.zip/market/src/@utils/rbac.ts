import appConfig from '../../app.config'
import axios, { AxiosResponse } from 'axios'

const eventRoleMappper = {
  consume: 'consumer',
  publish: 'publisher',
  browse: 'user',
  admin: 'admin'
}

export default async function rbacRequest(
  eventType: string,
  address: string,
  signal?: AbortSignal
): Promise<boolean | 'ERROR'> {
  const url = appConfig.appConfig.rbac?.url
  if (url === undefined) {
    return true
  } else {
    const data = {
      component: 'market',
      eventType,
      authService: 'address',
      credentials: {
        address
      }
    }
    const config = {
      headers: {
        'Content-Type': 'application/json'
      },
      ...(signal && { signal })
    }
    try {
      const response: AxiosResponse = await axios.post(url, data, config)
      return response?.data
    } catch (error) {
      console.error('Error parsing json: ' + error.message)
      return 'ERROR'
    }
  }
}

export function getRoleByEvent(event: string): string {
  return eventRoleMappper[event] || event
}
