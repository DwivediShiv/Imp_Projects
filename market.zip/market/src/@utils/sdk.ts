import FancyToast from '@components/@shared/fancy/atoms/Toast/FancyToast'
import { ACCOUNT_ABSTRACTION_PROVIDERS, SDK_MESSAGE } from '@utils/constants'
import {
  checkUserOrgInfo,
  fetchInstanceDetails,
  getAbstractDetails,
  getPaymasterDetails,
  getUserEmail,
  hasAccess
} from '@utils/auth'
import appConfig, {
  networkConfig,
  infuraProjectId,
  metadataCacheUri
} from 'app.config'
import {
  ROLE_ADMIN,
  ROLE_SUPERADMIN,
  ROLE_USER
} from '@components/@shared/fancy/constants/RoleConstants'
import {
  getBiconomyBundlerKey,
  getCurrentProviders,
  getTechnicalNetworkName
} from './network'
import { getPaymasterUrl } from './biconomy/api'
import { InstanceDetails } from '../@types/SmartAccount'
import { fancyCheckIsTestnet } from '@hooks/useNetworkMetadata'
import { useAuthorize } from '@context/Authorize'
import { getOrgProviderListUrl } from './api'
import axios from 'axios'
import { LoggerInstance, Provider } from '@oceanprotocol/lib'

export async function getUserRoles() {
  const isSuperAdmin = hasAccess(ROLE_SUPERADMIN)
  const isAdmin = hasAccess(ROLE_ADMIN)
  const role: string = isSuperAdmin
    ? ROLE_SUPERADMIN
    : isAdmin
    ? ROLE_ADMIN
    : ROLE_USER
  return role
}

export async function getPaymasterDetailsForUser(): Promise<boolean> {
  const instanceDetails: InstanceDetails = await fetchInstanceDetails()
  const userMail = getUserEmail()
  const response = await checkUserOrgInfo(userMail)
  const { orgId: userOrgId } = response.data
  const isInstanceOrg = instanceDetails?.orgId === userOrgId
  if (instanceDetails?.enablePaymaster) {
    return true
  } else {
    if (isInstanceOrg) {
      return true
    }
  }
  return false
}

export function formatListsOfServiceEndpoints(providerLists) {
  return providerLists.reduce((collection, item) => {
    if (item.name && item.url) {
      collection[item.name] = item.url
    }
    return collection
  }, {})
}

export async function getListOfProviders(chainId?: number) {
  const providerServices = await getCurrentProviders(chainId?.toString())
  if (providerServices) return formatListsOfServiceEndpoints(providerServices)
  return {}
}

export async function getSDKParameters(
  orgSmartAccount: string,
  privateKey: string,
  chainId: number,
  userOrganizationId?: string,
  signerAddress?: string
) {
  const {
    sessionKey: { merkleRoot, sessionKeys },
    accountAbstractionProvider
  } = await getAbstractDetails()

  const userRole = await getUserRoles()

  const providerslist = await getListOfProviders(chainId)

  const roleName = userRole === 'admin' ? 'orgAdmin' : 'orgUser'
  const validationModule =
    appConfig.validationSmartContracts[getTechnicalNetworkName(chainId)]?.[
      roleName
    ]

  const sdkParameters: Record<string, string> = {
    PRIVATE_KEY: `PRIVATE_KEY='${privateKey}'`,
    CHAIN_ID: `CHAIN_ID='${chainId}'`,
    RPC_URL: `RPC_URL='${
      networkConfig[getTechnicalNetworkName(chainId)]?.rpc
    }'`,
    INFURA_PROJECT_ID: `INFURA_PROJECT_ID='${infuraProjectId}'`,
    OCEAN_AQUARIUS_URL: `OCEAN_AQUARIUS_URL='${metadataCacheUri}'`,
    OCEAN_PROVIDER_URL: `OCEAN_PROVIDER_URL='${appConfig?.networkConfig?.multiChainEncryptionProviderUri}'`,
    SERVICE_ENDPOINTS: `SERVICE_ENDPOINTS='${JSON.stringify(providerslist)}'`,
    SOURCE: `SOURCE='${appConfig?.source}'`,
    ORG_ID: `ORG_ID='${userOrganizationId}'`,
    BASE_TOKEN_: `BASE_TOKEN='${
      appConfig?.stableCoin?.[getTechnicalNetworkName(chainId)]?.address
    }'`,
    BASE_TOKEN_DECIMAL: `BASE_TOKEN_DECIMAL='${
      appConfig?.stableCoin?.[getTechnicalNetworkName(chainId)]?.decimals
    }'`,
    SIGNER_ADDRESS: `SIGNER_ADDRESS='${signerAddress}'`,
    IS_DISABLE_PARAMETERIZE_ASSET: `IS_DISABLE_PARAMETERIZE_ASSET='${appConfig?.customization?.isDisableParameterizeAsset}'`,
    IS_DISABLE_UNLIMITED_TIMEOUT: `IS_DISABLE_UNLIMITED_TIMEOUT='${appConfig?.customization?.isDisableUnlimitedTimeout}'`,
    ASSET_MANAGEMENT_TOKEN_NAME: `ASSET_MANAGEMENT_TOKEN_NAME='${appConfig?.site?.assetManagementTokenName}'`,
    ASSET_MANAGEMENT_TOKEN_SYMBOL_PREFIX: `ASSET_MANAGEMENT_TOKEN_SYMBOL_PREFIX='${appConfig?.site?.assetManagementTokenSymbolPrefix}'`,
    ASSET_MANAGEMENT_TOKEN_IMAGE_URL: `ASSET_MANAGEMENT_TOKEN_IMAGE_URL='${appConfig?.site?.assetManagementTokenImageUrl}'`,
    SUBGRAPH_URI: `SUBGRAPH_URI='${
      networkConfig[getTechnicalNetworkName(chainId)]?.subgraphUri
    }'`,
    USER_ROLE: `USER_ROLE='${userRole}'`
  }

  if (orgSmartAccount) {
    let paymasterAuthToken: string
    let paymasterApiKey: string
    let biconomyDashboardUrl: string

    const getPaymaster = await getPaymasterDetailsForUser()
    let socialDetails
    if (getPaymaster) {
      socialDetails = (await getPaymasterDetails())?.socialDetails
    }
    if (accountAbstractionProvider === ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY) {
      sdkParameters.SMART_ACCOUNT_SESSION_VALIDATION_MODULE_ADDRESS = `SMART_ACCOUNT_SESSION_VALIDATION_MODULE_ADDRESS='${validationModule}'`
      sdkParameters.SMART_ACCOUNT_PAYMASTER_URL = `SMART_ACCOUNT_PAYMASTER_URL='https://paymaster.biconomy.io/api/v1'`
      sdkParameters.SMART_ACCOUNT_BUNDLER_URL = `SMART_ACCOUNT_BUNDLER_URL='https://bundler.biconomy.io/api/v2'`
      sdkParameters.SMART_ACCOUNT_BUNDLER_KEY = `SMART_ACCOUNT_BUNDLER_KEY='${getBiconomyBundlerKey(
        fancyCheckIsTestnet(chainId)
      )}'`
      sdkParameters.MERKLE_ROOT = `MERKLE_ROOT='${merkleRoot}'`
      sdkParameters.SESSION_KEYS = `SESSION_KEYS='${JSON.stringify(
        sessionKeys
      )}'`

      if (socialDetails) {
        paymasterAuthToken = socialDetails.authToken
        paymasterApiKey = socialDetails.paymasterKey
        biconomyDashboardUrl = getPaymasterUrl(chainId, paymasterApiKey)

        sdkParameters.SMART_ACCOUNT_PAYMASTER_KEY = `SMART_ACCOUNT_PAYMASTER_KEY='${paymasterApiKey}'`
        sdkParameters.BICONOMY_DASHBOARD_AUTH_TOKEN = `BICONOMY_DASHBOARD_AUTH_TOKEN='${paymasterAuthToken}'`
        sdkParameters.BICONOMY_DASHBOARD_URL = `BICONOMY_DASHBOARD_URL='${biconomyDashboardUrl}'`
      }
    }

    if (
      accountAbstractionProvider === ACCOUNT_ABSTRACTION_PROVIDERS.ALCHEMY &&
      socialDetails
    ) {
      sdkParameters.API_KEY = `API_KEY='${socialDetails?.apiKey}'`
    }
    sdkParameters.PAYMENT_MANAGEMENT_URL = `PAYMENT_MANAGEMENT_URL='${appConfig?.paymentManager?.url}'`
    sdkParameters.SMART_ACCOUNT_ADDRESS = `SMART_ACCOUNT_ADDRESS='${orgSmartAccount}'`
  }
  return sdkParameters
}
export const copyText = (text: string) => {
  navigator.clipboard.writeText(text)
  FancyToast('success', SDK_MESSAGE.SUCCESS)
}

export const trimValue = (text: string): string => {
  const index = text.indexOf('=')
  const TRIMMED_INDEX = 50
  if (index === -1) {
    return text
  }
  const key = text.slice(0, index + 1)
  const value = text.slice(index + 1)

  const trimmed =
    value.length > TRIMMED_INDEX ? value.substring(0, TRIMMED_INDEX) : value
  return `${key}${trimmed}${value.length > TRIMMED_INDEX ? "...'" : ''}`
}
