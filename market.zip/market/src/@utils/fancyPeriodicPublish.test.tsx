import { values } from '../../.jest/__fixtures__/formPublishData'
import { config } from '../../.jest/__fixtures__/fancyConfig'
import {
  fancyGenerateQueryTokenVariable,
  querySubgraphTransaction,
  fancyPeriodicQuery
} from './fancyPeriodicPublish'
import { Aquarius } from '@oceanprotocol/lib'

// querySubgraphTransaction's fetchDataForMultipleChains expectedOutput sample
const expectedOutput = {
  erc721Address: '0x0000000000000000000000000000000000000000',
  datatokenAddress: '0x1234567890abcdef',
  txHash: '0xca8f8c315c8b6c48cee0675677b786d1babe726773829a588efa500b71cbdb65'
}

// querySubgraphTransaction's Mock fetchDataForMultipleChains to return the expected response
jest.mock('./subgraph', () => ({
  fetchDataForMultipleChains: () => [
    {
      tokens: [
        {
          address: expectedOutput.datatokenAddress,
          nft: { address: expectedOutput.erc721Address },
          tx: expectedOutput.txHash
        }
      ]
    }
  ]
}))

describe('fancyGenerateQueryTokenVariable', () => {
  it('should generate the correct query token variable', () => {
    const accountId = '0x1234567890abcdef'
    const dataTokenOptions = { name: 'DataToken', symbol: 'DT' }
    const createdTimestamp = Date.now()

    const expectedOutput = {
      publisherAddress: accountId.toLowerCase(),
      symbol: dataTokenOptions.symbol,
      name: dataTokenOptions.name,
      createdTimestamp
    }

    const result = fancyGenerateQueryTokenVariable(
      accountId,
      dataTokenOptions,
      createdTimestamp
    )

    expect(result).toEqual(expectedOutput)
  })
})

describe('querySubgraphTransaction', () => {
  it('should return token details if token is found', async () => {
    const accountId = '0x1234567890abcdef'
    const chainIds = [5, 137]
    const currentTimestamp = Date.now()

    const result = await querySubgraphTransaction(
      values,
      accountId,
      chainIds,
      currentTimestamp
    )

    expect(result).toEqual(expectedOutput)
  })
})

describe('fancyPeriodicQuery', () => {
  const setIsTransactionExpired = jest.fn()
  const accountId = '0x1234567890abcdef'
  it('should resolve DID using Aquarius', async () => {
    const did = 'did:op:123'
    const { signal } = new AbortController()

    // Mock Aquarius resolve
    const resolveSpy = jest
      .spyOn(Aquarius.prototype, 'resolve')
      .mockResolvedValue('asset' as any) // mock type 'Asset' as string for test purpose only
    const result = await fancyPeriodicQuery(
      accountId,
      config,
      setIsTransactionExpired,
      values,
      did,
      signal
    )

    expect(resolveSpy).toHaveBeenCalledTimes(1)
    expect(resolveSpy).toHaveBeenCalledWith(did, signal)
    expect(result).toEqual('asset')
  })

  it('should return null as failed resolves DID', async () => {
    const did = 'did:op:1234'

    // Mock Aquarius.resolve return nothing so periodic loop will continue till end
    const resolveSpy = jest
      .spyOn(Aquarius.prototype, 'resolve')
      .mockResolvedValue(null)
    const response = await fancyPeriodicQuery(
      accountId,
      config,
      setIsTransactionExpired,
      undefined,
      did
    )

    expect(resolveSpy).toHaveBeenCalledTimes(
      config.periodicCheckTransactionCycle + 1
    )
    expect(resolveSpy).toHaveBeenCalledWith(did, undefined)
    expect(response).toBeNull()
  })

  it('should query subgraph transaction when did is not provided', async () => {
    const result = await fancyPeriodicQuery(
      accountId,
      config,
      setIsTransactionExpired,
      values
    )

    expect(result).toEqual(expectedOutput) // same as mocked above
    expect(result).toBeDefined()
    expect(result.erc721Address).toBeDefined()
    expect(result.datatokenAddress).toBeDefined()
    expect(result.txHash).toBeDefined()
  })
})
