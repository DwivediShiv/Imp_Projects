import AssetFilters from 'src/@types/AssetFilters'
import axios, { AxiosResponse } from 'axios'
import { getAssetFilterCriteria } from '../@utils/api'

export async function getAssetFilters(): Promise<AssetFilters> {
  const response: AxiosResponse = await axios({
    method: 'GET',
    url: getAssetFilterCriteria()
  })
  return response?.data
}
