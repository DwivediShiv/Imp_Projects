import axios, { CancelTokenSource } from 'axios'
import { computeAsset } from '../../.jest/__fixtures__/computeDatasetWithAccessDetails'
import { getComputeStatus, getValidAlgorithms } from './fancyCompute'
import { queryMetadata, transformDDOToAssetSelection } from './aquarius'
import { getInMemoryValue } from './fancyAppData'
import { getOrganisationOption } from './fancySelectionOption'

const { chainId } = computeAsset
const { publisherTrustedAlgorithms } = computeAsset.services[0].compute
const cancelTokenSource = axios.CancelToken.source()
const metadataCacheUri = 'https://v1.aquarius.acentrik.io'
const mockTransformedDDO = {
  containerSectionChecksum:
    '54eb02210bad8a5fbe229e1d131a68e80fe32709a196c6ce49f33e5d378b1195',
  did: 'did:op:f86dedf3c872f79f788627025685a680eaac9f8bd7b6e622164fd8563e21e836',
  filesChecksum:
    '2f8afee0a35fbeb72a447c7d1437b6c83f937e6d65a6c7d1990548cc21ff254c'
}

jest.mock('./fancySelectionOption')

jest.mock('@utils/aquarius', () => {
  const actual = jest.requireActual('@utils/aquarius')
  return {
    ...actual,
    queryMetadata: () => ({}),
    transformDDOToAssetSelection: () => [mockTransformedDDO]
  }
})

jest.mock('./fancyAppData', () => ({
  getInMemoryValue: jest.fn().mockReturnValue('mockProviderEndpoint')
}))

describe('getValidAlgorithms', () => {
  beforeEach(() => {
    jest.clearAllMocks()
    jest.resetAllMocks()
  })

  it('should fetch valid algorithms and return filtered results', async () => {
    const mockOrgOptions = [
      { id: 1, name: 'Org1' },
      { id: 2, name: 'Org2' }
    ]
    const mockPublisherTrustedAlgorithms = []

    ;(getOrganisationOption as jest.Mock).mockResolvedValue(mockOrgOptions)
    const result = await getValidAlgorithms(
      'mockMetadataCacheUri',
      { token: 'mockCancelToken' } as unknown as CancelTokenSource,
      1,
      mockPublisherTrustedAlgorithms,
      'mockProviderEndpoint'
    )
    expect(result).toEqual([mockTransformedDDO])
  })

  test('should returns an empty array when metadataCacheUri is falsy', async () => {
    const result = await getValidAlgorithms(
      null,
      cancelTokenSource,
      chainId,
      publisherTrustedAlgorithms
    )
    expect(result).toEqual([])
  })

  test('should returns a list of algorithmSelectionList if metadataCacheUri is truthy', async () => {
    const result = await getValidAlgorithms(
      metadataCacheUri,
      cancelTokenSource,
      chainId,
      publisherTrustedAlgorithms
    )
    expect(result).toEqual([mockTransformedDDO])
  })

  test('calls getInMemoryValue to get providerEndpoint when it is not provided', async () => {
    jest
      .spyOn({ getInMemoryValue }, 'getInMemoryValue')
      .mockReturnValueOnce('http://provider-endpoint')
    jest.spyOn({ queryMetadata }, 'queryMetadata').mockResolvedValueOnce({
      results: [],
      page: 1,
      totalPages: 1,
      totalResults: 1,
      aggregations: 1
    })
    jest
      .spyOn({ transformDDOToAssetSelection }, 'transformDDOToAssetSelection')
      .mockResolvedValueOnce([])
    const algorithms = await getValidAlgorithms(
      metadataCacheUri,
      cancelTokenSource,
      chainId,
      publisherTrustedAlgorithms
    )
    expect(getInMemoryValue).toHaveBeenCalledWith('provider')
    expect(algorithms).toEqual([mockTransformedDDO])
  })

  test('returns the result of transformDDOToAssetSelection', async () => {
    const result = await getValidAlgorithms(
      metadataCacheUri,
      cancelTokenSource,
      chainId,
      publisherTrustedAlgorithms
    )
    expect(result).toEqual([mockTransformedDDO])
  })
})

describe('started', () => {
  test('should return true for status 1', () => {
    expect(getComputeStatus(1, 0)?.started).toBe(true)
  })

  test('should return true for status 10', () => {
    expect(getComputeStatus(10, 0)?.started).toBe(true)
  })

  test('should return true for status 20', () => {
    expect(getComputeStatus(20, 0)?.started).toBe(true)
  })

  test('should return false for other status values', () => {
    expect(getComputeStatus(30, 0)?.started).toBe(false)
    expect(getComputeStatus(0, 0)?.started).toBe(false)
    expect(getComputeStatus(-1, 0)?.started).toBe(false)
  })
})

describe('running', () => {
  test('should return true for status 30', () => {
    expect(getComputeStatus(30, 0)?.running).toBe(true)
  })

  test('should return true for status 40', () => {
    expect(getComputeStatus(40, 0)?.running).toBe(true)
  })

  test('should return true for status 50', () => {
    expect(getComputeStatus(50, 0)?.running).toBe(true)
  })

  test('should return true for status 60', () => {
    expect(getComputeStatus(60, 0)?.running).toBe(true)
  })

  test('should return false for other status values', () => {
    expect(getComputeStatus(0, 0)?.running).toBe(false)
    expect(getComputeStatus(-1, 0)?.running).toBe(false)
    expect(getComputeStatus(1, 0)?.running).toBe(false)
    expect(getComputeStatus(70, 0)?.running).toBe(false)
  })
})

describe('failed', () => {
  test('should return true for status 31', () => {
    expect(getComputeStatus(31, 0)?.failed).toBe(true)
  })

  test('should return true for status 32', () => {
    expect(getComputeStatus(32, 0)?.failed).toBe(true)
  })

  test('should return true for status 80', () => {
    expect(getComputeStatus(80, 0)?.failed).toBe(true)
  })

  test('should return false for other status values', () => {
    expect(getComputeStatus(0, 0)?.failed).toBe(false)
    expect(getComputeStatus(-1, 0)?.failed).toBe(false)
    expect(getComputeStatus(1, 0)?.failed).toBe(false)
    expect(getComputeStatus(70, 0)?.failed).toBe(false)
  })
})

describe('completed', () => {
  test('should return true for status 70', () => {
    expect(getComputeStatus(70, 0)?.completed).toBe(true)
  })

  test('should return false for other status values', () => {
    expect(getComputeStatus(0, 1)?.completed).toBe(false)
    expect(getComputeStatus(-1, 2)?.completed).toBe(false)
    expect(getComputeStatus(1, 0)?.completed).toBe(false)
    expect(getComputeStatus(30, 6)?.completed).toBe(false)
  })
})

describe('incomplete', () => {
  test('should return true for stopreq 2', () => {
    expect(getComputeStatus(70, 2)?.incomplete).toBe(true)
    expect(getComputeStatus(null, 2)?.incomplete).toBe(true)
    expect(getComputeStatus(undefined, 2)?.incomplete).toBe(true)
  })

  test('should return false for other status values', () => {
    expect(getComputeStatus(0, 1)?.incomplete).toBe(false)
    expect(getComputeStatus(null, 1)?.incomplete).toBe(false)
    expect(getComputeStatus(undefined, 1)?.incomplete).toBe(false)
    expect(getComputeStatus(-1, -1)?.incomplete).toBe(false)
    expect(getComputeStatus(1, 0)?.incomplete).toBe(false)
    expect(getComputeStatus(30, 3)?.incomplete).toBe(false)
  })
})
