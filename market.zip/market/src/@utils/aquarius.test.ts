import axios, { CancelToken } from 'axios'

import {
  queryMetadata,
  transformQueryResult,
  transformChainIdsListToQuery,
  getFilterTerm,
  getAssetsFromDidList,
  generateBaseQuery
} from './aquarius'
import { LoggerInstance } from '@oceanprotocol/lib'
import {
  SortDirectionOptions,
  SortTermOptions
} from '../../src/@types/aquarius/SearchQuery'
import { mockRawAssetMetadata as sampleQueryResult } from '../../.jest/__fixtures__/sales'
import {
  mockDid,
  didField,
  chainIdLists,
  sampleSearchQuery
} from '../../.jest/__fixtures__/aquarius'
import { HISTORY_INDEX } from './constants'

jest.mock('axios')

const queryDatatokenAddress = `(datatokens.address:0xbc18446d527f90e086ee6d3b19cfc8ebecaaa2f3) OR (datatokens.address:0x10b412719799113f5a4ba6a03d86a2194b1cff21) OR (datatokens.address:0xc94015b11ddf31d40b9ee96205a56b170429dc77) OR (datatokens.address:0xc94015b11ddf31d40b9ee96205a56b170429dc77)`
const chainIds = `chainId:5`

const queryPublishedAssets: SearchQuery = {
  from: 0,
  query: {
    bool: {
      must: [
        {
          query_string: {
            query: `(${queryDatatokenAddress}) AND (${chainIds})`
          }
        }
      ]
    }
  },
  sort: {
    'metadata.created': SortDirectionOptions.Descending
  }
}

describe('transformChainIdsListToQuery', () => {
  it('should return appropriate string when chain ids are passed', async () => {
    const chainIds = [5, 1, 80001, 43114, 43115, 56, 97, 1313161554]
    const result = transformChainIdsListToQuery(chainIds)
    expect(typeof result).toBe('string')
    chainIds.forEach((chain) => {
      expect(result.includes(chain.toString())).toBeTruthy()
    })
  })

  it('should return appropriate string when chain ids are passed', async () => {
    const falsyChains = [[undefined, null], undefined, null, []]
    falsyChains.forEach((chains) => {
      const result = transformChainIdsListToQuery(chains)
      expect(result).toBe('')
    })
  })
})

describe('queryMetadata', () => {
  afterEach(() => {
    jest.resetAllMocks()
  })

  it('should throw error when falsy queries are passed', async () => {
    const falsyQueries = [undefined, null]
    const loggerSpy = jest.spyOn(LoggerInstance, 'error')

    falsyQueries.forEach(async (query) => {
      await expect(queryMetadata(query)).rejects.toThrow()
    })
  })

  it('should return undefined when axios response is falsy or in error', async () => {
    jest
      .spyOn(axios, 'post')
      .mockResolvedValueOnce(undefined)
      .mockResolvedValueOnce(null)
      .mockResolvedValue({
        data: undefined,
        status: 400,
        statusText: '',
        headers: {},
        config: {}
      })

    for (let i = 0; i < 3; i++) {
      const response = await queryMetadata(queryPublishedAssets)
      expect(response).toBeUndefined()
    }
  })

  it('should return metadata when if able to query metadata from aquarius', async () => {
    const successfulResponse = {
      status: 200,
      data: {
        hits: {
          hits: [{ _source: { name: 'test asset' } }],
          total: { value: 1 }
        },
        aggregations: []
      }
    }
    const expectedResult = {
      results: [{ name: 'test asset' }],
      page: 1,
      totalPages: 0,
      totalResults: 1,
      aggregations: []
    }

    const mockAxios = axios.post as jest.MockedFunction<typeof axios.post>
    mockAxios.mockResolvedValueOnce(successfulResponse)

    const result = await queryMetadata(queryPublishedAssets)
    expect(axios.post).toHaveBeenCalledWith(
      expect.stringContaining('/api/aquarius/assets/query'),
      expect.objectContaining({
        from: 0,
        query: {
          bool: {
            must: [
              {
                query_string: {
                  query:
                    '((datatokens.address:0xbc18446d527f90e086ee6d3b19cfc8ebecaaa2f3) OR (datatokens.address:0x10b412719799113f5a4ba6a03d86a2194b1cff21) OR (datatokens.address:0xc94015b11ddf31d40b9ee96205a56b170429dc77) OR (datatokens.address:0xc94015b11ddf31d40b9ee96205a56b170429dc77)) AND (chainId:5)'
                }
              }
            ],
            must_not: [
              {
                wildcard: {
                  _index: `*${HISTORY_INDEX}`
                }
              }
            ]
          }
        },
        size: 500,
        sort: {
          'metadata.created': 'desc'
        }
      }),
      {}
    )

    expect(result).toEqual(expectedResult)
  })
})

describe('transformQueryResult', () => {
  it('should return undefined if falsy input is passed', () => {
    const falsyQueryResults = [undefined, null]
    falsyQueryResults.forEach((result) => {
      const response = transformQueryResult(result)
      expect(response).toBeUndefined()
    })

    const falsyFroms = [-0.01, -1, 1.1, 0.01]
    falsyFroms.forEach((from) => {
      const response = transformQueryResult(sampleQueryResult, from)
      expect(response).toBeUndefined()
    })

    const falsySizes = [-0.01, -1, 1.1, 0.01]
    falsySizes.forEach((size) => {
      const response = transformQueryResult(sampleQueryResult, 0, size)
      expect(response).toBeUndefined()
    })
  })

  it('should return result if correct query result is passed', () => {
    const response = transformQueryResult(sampleQueryResult)
    expect(response).toBeDefined()
    expect(response.results).toBeDefined()

    const responseProperties = JSON.stringify([
      'aggregations',
      'page',
      'results',
      'totalPages',
      'totalResults'
    ])
    const responseKeys = Object.keys(response).sort()
    expect(JSON.stringify(responseKeys)).toEqual(responseProperties)

    const resultsProperties = JSON.stringify([
      '@context',
      'chainId',
      'datatokens',
      'event',
      'id',
      'metadata',
      'nft',
      'nftAddress',
      'purgatory',
      'services',
      'stats',
      'version'
    ])
    const { results } = response
    results.forEach((result) => {
      const resultKeys = JSON.stringify(Object.keys(result).sort())
      expect(resultKeys).toEqual(resultsProperties)
    })
  })
})

describe('aquarius', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  it('should return a term filter with a single value if value is a string, number, or boolean', () => {
    const value =
      'did:op:58985c38c0541967bf802dc3435924dbdd60ef689c61601ead87760b55fc7b16'
    expect(getFilterTerm(didField, value)).toEqual({
      term: {
        [didField]: value
      }
    })
  })

  it('should return a terms filter with multiple values if value is an array', () => {
    expect(getFilterTerm(didField, mockDid)).toEqual({
      terms: {
        [didField]: mockDid
      }
    })
  })

  it('should return undefined when filter field is not provided', () => {
    expect(getFilterTerm(undefined, mockDid)).toBeUndefined()
  })

  it('should return a term filter with undefined value when the input value is empty/undefined', () => {
    expect(getFilterTerm(didField, undefined)).toEqual({
      term: {
        [didField]: undefined
      }
    })
  })

  it('should generate base query based on query parameters', () => {
    const baseQueryParams: BaseQueryParams = {
      chainIds: chainIdLists,
      filters: [getFilterTerm(didField, mockDid)],
      ignorePurgatory: true
    }
    expect(generateBaseQuery(baseQueryParams)).toEqual(sampleSearchQuery)
  })

  it('should return purgatory state false if ignore purgatory is false', () => {
    const baseQueryParams: BaseQueryParams = {
      esPaginationOptions: {
        from: 0,
        size: 1000
      },
      chainIds: chainIdLists,
      filters: [getFilterTerm(didField, mockDid)],
      ignorePurgatory: false
    }
    const expectedOutput = {
      ...sampleSearchQuery,
      query: {
        bool: {
          filter: [
            ...sampleSearchQuery.query.bool.filter,
            {
              term: {
                'purgatory.state': false
              }
            }
          ]
        }
      }
    }
    expect(generateBaseQuery(baseQueryParams)).toEqual(expectedOutput)
  })

  it('should return generated base query with sort options', () => {
    const baseQueryParams: BaseQueryParams = {
      chainIds: chainIdLists,
      filters: [getFilterTerm(didField, mockDid)],
      ignorePurgatory: true,
      sortOptions: {
        sortBy: SortTermOptions.Created
      }
    }
    const expectedOutput = {
      ...sampleSearchQuery,
      sort: {
        'metadata.created': 'desc'
      }
    }
    expect(generateBaseQuery(baseQueryParams)).toEqual(expectedOutput)
  })

  it('should return generated base query with parameters', () => {
    const baseQueryParams: BaseQueryParams = {
      chainIds: chainIdLists,
      filters: [getFilterTerm(didField, mockDid)],
      ignorePurgatory: true,
      aggs: {
        totalOrders: {
          sum: {
            field: SortTermOptions.Orders
          }
        }
      }
    }
    const expectedOutput = {
      ...sampleSearchQuery,
      aggs: {
        totalOrders: {
          sum: {
            field: 'stats.orders'
          }
        }
      }
    }
    expect(generateBaseQuery(baseQueryParams)).toEqual(expectedOutput)
  })

  it('should return undefined if didList is empty', async () => {
    const result = await getAssetsFromDidList(
      [],
      chainIdLists,
      {} as CancelToken
    )
    expect(result).toBeUndefined()
  })

  it('should log error and return undefined if queryMetadata throws error', async () => {
    ;(axios.post as jest.Mock).mockRejectedValue(
      new Error('Something went wrong')
    )
    const error = new Error('Something went wrong')
    const spyLog = jest.spyOn(LoggerInstance, 'error')
    const result = await getAssetsFromDidList(
      [
        'did:op:bf097bec4b15c60f7a92e8566706aca8785089a9c8a6b2d9f52f2ebd80a1b0d1',
        'did:op:25903c631a67dfcc2715004e17db882ab98ec064d31b42b21f4e33e4e6e4be09'
      ],
      chainIdLists,
      {} as CancelToken
    )
    expect(result).toBeUndefined()
    expect(spyLog).toHaveBeenCalledWith(error.message)
  })
})
