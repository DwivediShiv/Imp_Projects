export const feedback: { [key in number]: string } = {
  99: 'Decrypting file URL...',
  0: '1/3 Looking for Datatoken. Buying if none found...',
  1: '2/3 Transfering Datatoken.',
  2: '3/3 Payment confirmed. Requesting access...'
}

export const publishFeedback: { [key in number]: string } = {
  0: '1/5 Creating datatoken ...',
  2: '2/5 Encrypting files ...',
  4: '3/5 Storing ddo ...',
  6: '4/5 Minting tokens ...',
  8: '5/5 Asset published succesfully'
}

// TODO: do something with this object,
// consumeStep should probably return one of those strings
// instead of just a number
export const consumeFeedback: { [key in number]: string } = {
  ...feedback,
  3: '3/3 Access granted. Consuming file...'
}

// TODO: customize for compute
export const computeFeedback: { [key in number]: string } = {
  0: '1/3 Ordering asset...',
  1: '2/3 Transfering Datatoken.',
  2: '3/3 Access granted. Starting job...'
}

export function getCreatePricingExchangeFeedback(dtSymbol: string): {
  [key: number]: string
} {
  return {
    99: `Minting ${dtSymbol} ...`,
    0: 'Creating exchange ...',
    1: `Approving ${dtSymbol} ...`,
    2: 'Fixed exchange created.'
  }
}

export function getCreateFreePricingFeedback(dtSymbol: string): {
  [key: number]: string
} {
  return {
    99: `Creating ${dtSymbol} faucet...`,
    0: 'Setting faucet as minter ...',
    1: 'Approving minter...',
    2: 'Faucet created.'
  }
}

export function getBuyDTFeedback(
  dtSymbol: string,
  baseToken: string
): { [key: number]: string } {
  return {
    1: `1/3 Approving ${baseToken} ...`,
    2: `2/3 Buying ${dtSymbol} ...`,
    3: `3/3 ${dtSymbol} bought.`
  }
}

export function getSellDTFeedback(dtSymbol: string): { [key: number]: string } {
  return {
    1: '1/3 Approving OCEAN ...',
    2: `2/3 Selling ${dtSymbol} ...`,
    3: `3/3 ${dtSymbol} sold.`
  }
}

export function getDispenseFeedback(dtSymbol: string): {
  [key: number]: string
} {
  return {
    1: `1/2 Requesting ${dtSymbol}...`,
    2: `2/2 Received ${dtSymbol}.`
  }
}

export function getIsConsumableFeedback(
  accessType?: string,
  assetType?: string,
  isOwner?: boolean
): {
  [key: number]: string
} {
  return {
    0: 'All good',
    1: isOwner
      ? 'If you would like to have your asset purchasable, please select the option to resume sale of this asset in the advanced settings.'
      : 'Unfortunately, this asset is unavailable for purchase at the moment.\nPlease try again later.',
    2: `Unfortunately you do not have permission to purchase this ${assetType}. Please browse for other available assets.`,
    3: `Unfortunately you do not have permission to purchase this ${assetType}. Please browse for other available assets.`
  }
}

// TODO: can be better
export function getOrderFeedback(
  baseTokenSymbol: string,
  datatokenSymbol: string
): { [key in number]: string } {
  return {
    0: `Approving and buying one ${datatokenSymbol}`,
    1: `Ordering asset`,
    2: `Approving ${baseTokenSymbol} and ordering asset`,
    3: 'Generating signature to access download url'
  }
}

export function getCollectTokensFeedback(
  baseTokenSymbol: string,
  baseTokenBalance: string
) {
  return `Collecting ${baseTokenBalance} ${baseTokenSymbol} from asset `
}

export function getComputeFeedback(
  baseTokenSymbol?: string,
  datatokenSymbol?: string,
  assetType?: string
): { [key in number]: string } {
  return {
    0: `Setting price and fees for ${assetType}`,
    1: `Approving and buying one ${datatokenSymbol} `,
    2: `Ordering  ${assetType} and transfering datatoken ...`,
    3: `Approving ${baseTokenSymbol} and ordering ${assetType}`,
    4: 'Generating signature. Starting compute job ...'
  }
}
