import { ComputeOption } from '@components/Publish/_constants'

interface DockerMetadata {
  image: string
  tag: string
  checksum: string
  referenceUrl: string
}

export function mapDockerDetailsUrl(
  computeOptions: ComputeOption[],
  metadata: DockerMetadata,
  runtimeEnvironment: string
): string {
  const dockerImage = computeOptions.find(
    (option) => option.name === runtimeEnvironment
  )

  if (dockerImage?.value) {
    const { registry, imageName } = dockerImage.value
    if (registry && imageName) {
      return `${registry}${imageName}`
    }
  }

  if (metadata) {
    const { image, tag, checksum, referenceUrl } = metadata
    if (referenceUrl) {
      return referenceUrl
    }
    // Kris: Below kept for backward compatible with existing published asset (26/6/2024)
    if (image && tag && checksum) {
      return `https://hub.docker.com/layers/${image}/${tag}/images/${checksum}`
    }
  }

  return ''
}

export function getImageAndTagFromRegistryLink(inputString: string) {
  const lastIndex = inputString.lastIndexOf(':')
  let image = inputString
  let tag = ''

  if (lastIndex !== -1) {
    image = inputString.substring(0, lastIndex)
    tag = inputString.substring(lastIndex + 1)
  }

  return { image, tag }
}
