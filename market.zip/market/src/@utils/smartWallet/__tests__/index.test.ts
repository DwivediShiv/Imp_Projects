import { getTokenDetailsForChain, getPaymasterBalance } from '..'

jest.mock('@shared/fancy/atoms/Toast/FancyToast', () => ({
  __esModule: true,
  default: jest.fn()
}))

jest.mock('../tokenList.json', () => ({
  tokens: [
    {
      chainId: 80001,
      isUsed: false,
      symbol: 'USDC',
      address: '0x123451234',
      decimals: 18
    },
    {
      chainId: 80001,
      isUsed: true,
      symbol: 'MATIC',
      address: '0x123456789',
      decimals: 18
    },
    {
      chainId: 137,
      isUsed: true,
      symbol: 'USDC',
      address: '0x987654321',
      decimals: 18
    }
  ]
}))

describe('getTokenDetailsForChain', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  it('should return token details for a given chain without Symbol', () => {
    const tokenInfo = getTokenDetailsForChain(80001, true)
    expect(tokenInfo).toEqual({
      chainId: 80001,
      isUsed: true,
      symbol: 'MATIC',
      address: '0x123456789',
      decimals: 18
    })
  })

  it('should return token details for a given chain with Symbol', () => {
    const tokenInfo = getTokenDetailsForChain(80001, true, 'MATIC')
    expect(tokenInfo).toEqual({
      chainId: 80001,
      isUsed: true,
      symbol: 'MATIC',
      address: '0x123456789',
      decimals: 18
    })
  })

  it('should return null when token not found for the given criteria', () => {
    const tokenInfo = getTokenDetailsForChain(2, true, 'USDC')
    expect(tokenInfo).toBeNull()
  })
})

describe('getPaymasterBalance', () => {
  afterEach(() => {
    jest.clearAllMocks()
  })

  it('should return null in case of no signer', async () => {
    const balanceResult = await getPaymasterBalance(null)
    expect(balanceResult).toBeUndefined()
  })
})
