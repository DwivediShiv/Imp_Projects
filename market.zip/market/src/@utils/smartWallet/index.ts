import BiconomyTokens from './tokenList.json'
import { BalancesDto } from '@biconomy/node-client'
import { formatUnits } from 'ethers/lib/utils'
import { BiconomySmartAccountV2 } from '@biconomy/account'
import { Contract, ethers } from 'ethers'
import {
  ApiResponse,
  PaymasterBalanceForChain,
  SmartWalletBalanceForToken
} from '../../@types/SmartAccount'
import {
  editOrgProfileUrl,
  editPaymasterDetailsUrl,
  getPaymasterOwnerUrl
} from '@utils/api'
import axios, { AxiosResponse } from 'axios'
import { PAYMASTER_ABI } from '../biconomy/abiCollection'
import { getAccessToken } from '@utils/auth'

declare type ModuleVersion = 'V1_0_0' | 'V1_0_1'

export function getTokenDetailsForChain(
  chainId: number,
  isUsed: boolean,
  symbol?: string
) {
  const { tokens } = BiconomyTokens
  for (const tokenData of tokens) {
    if (
      tokenData.chainId === chainId &&
      tokenData.isUsed === isUsed &&
      (symbol ? tokenData.symbol === symbol : true)
    ) {
      return tokenData
    }
  }
  return null
}

export function normalizeChainId(chainId: string | number | bigint) {
  if (typeof chainId === 'string') {
    return Number.parseInt(
      chainId,
      chainId.trim().substring(0, 2) === '0x' ? 16 : 10
    )
  }
  if (typeof chainId === 'bigint') {
    return Number(chainId)
  }
  return chainId
}

export async function getSmartWalletBalance(
  chain: number,
  smartAccount: BiconomySmartAccountV2
) {
  const tokenInfo = getTokenDetailsForChain(chain, true)
  if (!tokenInfo) {
    return
  }
  const smartAccountAddress = await smartAccount?.getAccountAddress()
  const balanceParams: BalancesDto = {
    chainId: chain,
    eoaAddress: smartAccountAddress,
    tokenAddresses: [tokenInfo.address]
  }
  const key = tokenInfo.symbol.toUpperCase()
  const balFromSdk = await smartAccount.getAllTokenBalances(balanceParams)
  const tokenBalance = balFromSdk?.data[0]?.balance
  if (!tokenBalance) {
    return
  }
  const userBalance = formatUnits(
    balFromSdk?.data[0]?.balance,
    tokenInfo.decimals
  )
  const smartWalletBalance: SmartWalletBalanceForToken = {
    [key === 'SEP' ? 'ETH' : key]: userBalance
  }
  return smartWalletBalance
}

export async function getPaymasterBalance(
  signer: ethers.Signer
): Promise<PaymasterBalanceForChain> {
  if (!signer) return

  try {
    const chain = await signer.getChainId()
    const tokenInfo = getTokenDetailsForChain(chain, true)
    const { paymasterContractAddress } = tokenInfo
    const paymasterContract = new Contract(
      paymasterContractAddress,
      PAYMASTER_ABI,
      signer
    )
    const token = await getAccessToken()
    const payload = { authService: 'jwt' }
    const apiResponse: AxiosResponse = await axios.post<ApiResponse<any>>(
      getPaymasterOwnerUrl(),
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      }
    )
    const { data } = apiResponse
    const ownerEOA = data.ownerAddress

    const Balance = await paymasterContract.getBalance(ownerEOA)
    const intBalance = BigInt(Balance).toString()
    const paymasterBalance = formatUnits(intBalance, tokenInfo.decimals)

    const tokenSymbol = tokenInfo.symbol.toUpperCase()
    const paymasterBalanceFinal: PaymasterBalanceForChain = {}
    paymasterBalanceFinal[tokenSymbol] = paymasterBalance

    return paymasterBalanceFinal
  } catch (e) {
    console.error(`ERROR: Failed to get the Paymaster Balance: ${e.message}`)
    const defaultBalance: PaymasterBalanceForChain = {}
    defaultBalance.eth = '0'
    return defaultBalance
  }
}

export async function updateAbstractOrgDetails(
  orgId: string,
  data: Record<string, unknown>
): Promise<unknown> {
  try {
    const { data: response } = await axios.put(editOrgProfileUrl(orgId), data)
    return response.data
  } catch (error) {
    console.error('Error occured while updating Organization Data: ', error)
  }
}

export async function updatePaymasterDetails(
  orgId: string,
  data: Record<string, unknown>
): Promise<unknown> {
  try {
    const { data: response } = await axios.put(
      editPaymasterDetailsUrl(orgId),
      data
    )
    return response.data
  } catch (error) {
    console.error('Error occured while updating Organization Data: ', error)
  }
}

export function getSessionKeyManagerVersion(): ModuleVersion {
  return 'V1_0_1'
}

export function printSmartTxError(response: any, label = ''): void {
  if (response?.status === 200 || response?.status === 409) {
    return
  }
  console.error(`error ${label}: `, response)
}
