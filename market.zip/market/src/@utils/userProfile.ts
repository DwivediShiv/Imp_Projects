import { useState } from 'react'
import { UpdateUserRequest } from '../components/pages/Users/utils'
import axios, { AxiosResponse } from 'axios'
import {
  deleteUserRolesUrl,
  getAllRolesUrl,
  getOrgUserInfoUrl,
  getOrgUserRolesUrl,
  getProfileRoleUrl,
  getUserInfoUrl,
  getUserRolesUrl,
  postOrgUserRolesUrl,
  postUserRolesUrl,
  putOrgUserInfoUrl,
  putUserInfoUrl,
  roleToggleApI,
  updateActiveStateUrl
} from '@utils/api'
import { getAccessToken } from './auth'
import appConfig from 'app.config'
import jwt from 'jwt-decode' // import dependency
import {
  deleteAsync,
  getAsync,
  postAsync,
  printErrorStack,
  putAsync
} from './utils.api'
import FancyHelperMessage from '@components/@shared/fancy/atoms/FancyHelperMessage'
import {
  IUserAttributes,
  ManageWalletRole,
  UserInfo,
  UserProfileRoles
} from 'src/@types/User'
import { RoleInfo } from '@components/pages/Roles/utils'
import FancyToast from '@shared/fancy/atoms/Toast/FancyToast'
import { USER_MESSAGES, USER_UNAUTHORISED_ACTION } from './constants'
import { ApiResponse } from 'src/@types/Form'
import { ReactElement } from 'react-markdown'

export const IS_ACKNOWLEDGE_COMPANY_NAME_CHANGE =
  'IS_ACKNOWLEDGE_COMPANY_NAME_CHANGE'

const companyNameChangeDate = Date.parse(
  appConfig.customization?.companyNameChangeDate
)

let token: any = null

export async function getUserId() {
  if (!token) {
    const accessToken = await getAccessToken()
    token = jwt(accessToken)
  }
  return token?.sub
}

export async function editAttribute(data: UpdateUserRequest): Promise<any> {
  try {
    const userId = await getUserId()
    const response: AxiosResponse = await axios({
      method: 'PUT',
      url: putUserInfoUrl(userId),
      data
    })
    return response.data
  } catch (error) {
    console.log(error)
  }
}

export async function getUserInfo(): Promise<any> {
  try {
    const userId = await getUserId()
    const response: AxiosResponse = await axios({
      method: 'GET',
      url: getUserInfoUrl(userId)
    })
    return response.data
  } catch (error) {
    console.log(error)
  }
}
export async function getUserInfoWithId(userId: string): Promise<any> {
  try {
    const { data: response } = await axios.get<ApiResponse<UserInfo>>(
      getOrgUserInfoUrl(userId)
    )
    return response?.data
  } catch (error) {
    console.log('--------', error)
    throw error
  }
}

export function hasAcknowledgeCompanyNameChange(userInfo: any): boolean {
  return !!userInfo?.data?.attributes[IS_ACKNOWLEDGE_COMPANY_NAME_CHANGE]?.[0]
}

export function checkIsRegisterBeforeCompanyNameChange(userInfo: any): boolean {
  return userInfo?.data?.createdTimestamp < companyNameChangeDate
}

export async function deleteUserRoles(
  userId: string,
  data: RoleInfo[],
  email: string
): Promise<any> {
  try {
    const response: AxiosResponse = await deleteAsync(
      deleteUserRolesUrl(userId),
      data
    )
    FancyHelperMessage({
      isValid: true,
      message: `${email}: Admin Role Unassigned.`
    })

    return response?.data
  } catch (error) {
    printErrorStack(error)
  }
}

export const updateInactiveRole = async (
  profileId: string,
  responseMessage?: ReactElement
) => {
  try {
    const { data: response } = await axios.put<AxiosResponse>(
      updateActiveStateUrl(profileId)
    )
    FancyToast('success', responseMessage)
  } catch (error) {
    if (error.response?.data?.error.additionalData) {
      FancyToast('error', error.response?.data?.error.additionalData)
    } else if (
      error.response?.data?.code === USER_UNAUTHORISED_ACTION &&
      error.response?.data?.error
    ) {
      FancyToast('error', error.response?.data?.error)
    } else if (axios.isAxiosError(error)) {
      const { message = '', additionalData = {} } =
        error?.response?.data?.error ?? {}
      const additionalErrors = Object.values(additionalData)
      FancyToast(
        'error',
        additionalErrors?.length ? additionalErrors[0] : message
      )
    } else {
      FancyToast('error', USER_MESSAGES.ERROR_COMMON)
      printErrorStack(error)
    }
  }
}

export async function getRoles(): Promise<any> {
  try {
    const response: AxiosResponse = await getAsync(getAllRolesUrl())

    return response?.data?.data
  } catch (error) {
    printErrorStack(error)
  }
}

export async function getAllOrgRoles(): Promise<any> {
  try {
    const response: AxiosResponse = await getAsync(getAllRolesUrl())

    return response?.data?.data
  } catch (error) {
    printErrorStack(error)
  }
}

export async function getUserRoles(userId: string): Promise<any> {
  try {
    const response: AxiosResponse = await getAsync(getUserRolesUrl(userId))
    return response?.data?.data
  } catch (error) {
    printErrorStack(error)
  }
}

export async function getOrgUserRoles(userId: string): Promise<any> {
  try {
    const response: AxiosResponse = await getAsync(getOrgUserRolesUrl(userId))
    return response?.data?.roles
  } catch (error) {
    printErrorStack(error)
  }
}

export async function postUserRoles(
  userId: string,
  data: RoleInfo[],
  email: string
): Promise<any> {
  try {
    const response: AxiosResponse = await postAsync(
      postUserRolesUrl(userId),
      data
    )
    FancyHelperMessage({
      isValid: true,
      message: `${email}: Assigned Admin Role.`
    })
    return response?.data
  } catch (error) {
    printErrorStack(error)
  }
}

export async function postOrgUserRoles(
  userId: string,
  data: RoleInfo[],
  email: string
): Promise<any> {
  try {
    const response: AxiosResponse = await postAsync(
      postOrgUserRolesUrl(userId),
      data
    )
    FancyHelperMessage({
      isValid: true,
      message: `${email}: Assigned Admin Role.`
    })
    return response?.data
  } catch (error) {
    printErrorStack(error)
  }
}

export async function getProfileRole(
  userId: string
): Promise<UserProfileRoles> {
  try {
    const response: AxiosResponse = await getAsync(getProfileRoleUrl(userId))
    return response.data
  } catch (error) {
    console.log(error)
  }
}

export async function postManageWalletRole(
  id: string,
  data: ManageWalletRole[]
): Promise<any> {
  try {
    const response: AxiosResponse = await postAsync(getProfileRoleUrl(id), data)
    return response.data
  } catch (error) {
    console.log(error)
  }
}

export async function postManageOrgWalletRole(
  id: string,
  data: ManageWalletRole[]
): Promise<any> {
  try {
    const response: AxiosResponse = await postAsync(getProfileRoleUrl(id), data)
    return response?.data
  } catch (error) {
    console.log(error)
  }
}

export const updateUserRole = async (
  role: string,
  profileId: string,
  responseMessage?: ReactElement
) => {
  try {
    const { data: response } = await axios.put<AxiosResponse>(
      roleToggleApI(role, profileId)
    )
    FancyToast('success', responseMessage)
    return response
  } catch (error) {
    printErrorStack(error)
  }
}

/**
 * Method to update org user profile information
 * @param id profileId of user
 * @param data data containg name,value of attributes to be updated
 * @param successCallback after success function to execute
 * @param errorCallback after error fucntion to execute
 * @returns
 */
export async function updateUserProfileInformation(
  id: string,
  data: { attributes: IUserAttributes[] },
  successCallback: any,
  errorCallback: any
): Promise<any> {
  try {
    const response: AxiosResponse = await putAsync(
      putOrgUserInfoUrl(id),
      data,
      null,
      successCallback,
      errorCallback
    )
    return response.data
  } catch (error) {
    printErrorStack(error)
    return error
  }
}
