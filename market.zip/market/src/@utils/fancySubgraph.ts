import { gql } from 'urql'
// import {
//   AssetsOrders,
//   AssetsOrders_tokenOrders as AssetsOrdersTokenOrders
// } from 'src/@types/subgraph/AssetsOrders'
import { fetchData, getQueryContext } from './subgraph'

const AssetsOrdersQuery = gql`
  query AssetsOrders($datatokenId_in: [String!]) {
    orders(where: { datatoken_in: $datatokenId_in }) {
      datatoken {
        address
      }
      createdTimestamp
      tx
      payer {
        id
      }
    }
  }
`

export async function getDataTokensOrder(
  dids: string[],
  chainIds: number[]
): Promise<any[]> {
  // Promise<AssetsOrdersTokenOrders[]> {
  const loweredDids = dids?.reduce(function (result, d) {
    if (d) {
      result.push(d?.toLowerCase())
    }
    return result
  }, [])

  if (!loweredDids.length) {
    return
  }
  const query = {
    datatokenId_in: loweredDids
  }

  if (!chainIds || !chainIds.length) {
    return []
  }

  const subgraphRequests = []
  chainIds.forEach((chainId) => {
    const subgraphRequest = fetchData(
      AssetsOrdersQuery,
      query,
      getQueryContext(chainId)
    )
    subgraphRequests.push(subgraphRequest)
  })
  const results = await Promise.all(subgraphRequests)
  let tokenOrders: any = [] // AssetsOrdersTokenOrders[] = []
  results?.forEach((result) => {
    tokenOrders = Object.assign(tokenOrders, result?.data?.orders)
  })

  return tokenOrders
}

export async function getDataTokensOrderCountMapped(
  datatokens: string[],
  chainIds: number[]
): Promise<{ [did: string]: number }> {
  const tokenOrders = await getDataTokensOrder(datatokens, chainIds)
  if (!tokenOrders?.length) {
    return
  }

  const result: { [datatokenAddress: string]: number } = {}
  datatokens.forEach((datatoken) => {
    const tokenOrder = tokenOrders.filter((order) => {
      return order?.datatoken?.address === datatoken.toLowerCase()
    })
    result[datatoken] = tokenOrder?.length
  })
  return result
}
