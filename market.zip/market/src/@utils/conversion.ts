import { camelCase, mapKeys, toNumber } from 'lodash'
import { secondsToString } from './metadata'
import moment from 'moment'
import { isAddress } from 'ethers/lib/utils.js'
const TRUNC_ACC_START = 22
const TRUNC_ACC_END = 38

export function megaByteToByte(size: string): number {
  return parseInt(size) * 1024 * 1024
}

export function byteToMegaByte(size: string): string | number {
  if (!size) {
    return size
  }
  try {
    return parseInt(size) / 1024 / 1024
  } catch {
    return size
  }
}

export function megaByteIndication(size: string): string {
  const mbSize = byteToMegaByte(size)
  if (typeof mbSize !== 'number') {
    return size
  }
  return mbSize < 25 ? '<25' : mbSize.toFixed(2)
}

export function getMegaByte(size: string): string {
  const mbSize = byteToMegaByte(size)
  if (typeof mbSize !== 'number') {
    return size
  }
  return mbSize.toFixed(2)
}

export function durationToNowInTimestamp(date: string): number {
  const dataTimestamp = new Date(date).getTime()
  const timestamp = Math.round((new Date().getTime() - dataTimestamp) / 1000)
  return timestamp
}

export function convertDate(
  date: string,
  format?: string,
  inputFormat?: string,
  defaultText?: string
) {
  return date
    ? inputFormat
      ? moment(date, inputFormat).format(format || 'DD MMM YYYY, hh:mm A')
      : moment(new Date(date)).format(format || 'DD MMM YYYY, hh:mm A')
    : defaultText || '-'
}

export function durationToNow(date: string): string {
  return secondsToString(durationToNowInTimestamp(date))
}

export function getFileTypeWithoutCharset(mime: string): string {
  if (!mime) return
  const semiColoIndex = mime.indexOf(';')
  return mime.substr(0, semiColoIndex)
}

export function convertSnakeToCamel(data) {
  const camel = mapKeys(data, (value, key) => camelCase(key))
  return camel
}

export function convertObjectToType<T>(input: any): T {
  return Object.assign({}, input) as T
}

export function convertToThreeNonZeroDecimal(value: number): string {
  if (!value) {
    return '0'
  }
  return value.toFixed(20).match(/^-?\d*\.?0*\d{0,3}/)[0]
}

export function safeConvertToNumber(value: string): number {
  if (!value) {
    return 0
  }
  try {
    return toNumber(value)
  } catch {
    return 0
  }
}

export function truncateEnding(text: string, length: number): string {
  if (!length) return
  if (text?.length > length) {
    const truncated = text.substring(0, length).concat('...')
    return truncated
  } else {
    return text
  }
}

export function convertArrayToLowerCase(strings: string[]): string[] {
  const stringsInLowerCase = strings?.map((str: string) => {
    return str?.toLowerCase()
  })
  return stringsInLowerCase ?? []
}

export function accountTruncate(account: string): string {
  // example: 0x500DB43EE6966e6213BA...432e
  if (!account || account === '' || !isAddress(account)) return
  const middle = account.substring(TRUNC_ACC_START, TRUNC_ACC_END)
  const truncated = account.replace(middle, '…')
  return truncated
}

export function formatPriceUnit(
  value: number | string,
  decimals?: string
): string {
  const billion = 1e9
  const trillion = 1e12

  let result: string
  let suffix = ''

  value = typeof value === 'string' ? toNumber(value.replace(/,/g, '')) : value
  if (!value && value !== 0) return ''

  if (value < billion) {
    result = value.toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 6
    })
  } else if (value < trillion) {
    result = (value / billion).toFixed(6)
    suffix = ' billion'
  } else {
    result = (value / trillion).toFixed(6)
    suffix = ' trillion'
  }

  // Remove trailing zeros for values in billion or trillion
  if (value >= billion) {
    result = result.replace(/\.?0+$/, '')
  }

  return result + suffix
}

export function formatBytes(bytes: number) {
  if (bytes === 0) return '0 B'
  const kiloBytes = 1024
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
  const i = Math.floor(Math.log(bytes) / Math.log(kiloBytes))
  const size = bytes / Math.pow(kiloBytes, i)
  const formattedSize = parseFloat(size.toFixed(1)).toLocaleString('en-US', {
    maximumFractionDigits: 1
  })

  return `${formattedSize} ${sizes[i]}`
}

export function formatCurrency(value: number): string {
  const QUADRILLION_VALUE = 1_000_000_000_000_000
  const TRILLION_VALUE = 1_000_000_000_000
  const BILLION_VALUE = 1_000_000_000
  const MILLION_VALUE = 1_000_000
  const THOUSAND_VALUE = 1_000
  const ROUND_OFF_VALUE = 999.95

  if (
    value >= QUADRILLION_VALUE ||
    value >= ROUND_OFF_VALUE * QUADRILLION_VALUE
  ) {
    const formattedValue = (value / QUADRILLION_VALUE).toFixed(1)
    return formattedValue.endsWith('.0')
      ? formattedValue.slice(0, -2) + ' Quadrillion'
      : formattedValue + ' Quadrillion'
  } else if (
    value >= TRILLION_VALUE ||
    value >= ROUND_OFF_VALUE * BILLION_VALUE
  ) {
    const formattedValue = (value / TRILLION_VALUE).toFixed(1)
    return formattedValue.endsWith('.0')
      ? formattedValue.slice(0, -2) + ' Trillion'
      : formattedValue + ' Trillion'
  } else if (
    value >= BILLION_VALUE ||
    value >= ROUND_OFF_VALUE * BILLION_VALUE
  ) {
    const formattedValue = (value / BILLION_VALUE).toFixed(1)
    return formattedValue.endsWith('.0')
      ? formattedValue.slice(0, -2) + ' Billion'
      : formattedValue + ' Billion'
  } else if (
    value >= MILLION_VALUE ||
    value >= ROUND_OFF_VALUE * MILLION_VALUE
  ) {
    const formattedValue = value
      .toFixed(1)
      .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    return formattedValue.endsWith('.0')
      ? formattedValue.slice(0, -2)
      : formattedValue
  } else if (
    value >= THOUSAND_VALUE ||
    value >= ROUND_OFF_VALUE * THOUSAND_VALUE
  ) {
    const formattedValue = value
      .toFixed(1)
      .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    return formattedValue.endsWith('.0')
      ? formattedValue.slice(0, -2)
      : formattedValue
  } else {
    return value.toFixed(1).endsWith('.0')
      ? value
          .toFixed(1)
          .slice(0, -2)
          .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
      : value.toFixed(1).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  }
}
