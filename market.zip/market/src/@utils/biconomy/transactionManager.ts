import { ethers } from 'ethers'
import { BiconomySmartAccountV2 } from '@biconomy/account'
import { Transaction } from '@biconomy/core-types'
import { IProvider } from '@web3auth/base'
import { UserOpReceipt } from '@biconomy/bundler'
import {
  PaymasterMode,
  SponsorUserOperationDto,
  IHybridPaymaster,
  PaymasterAndDataResponse
} from '@biconomy/paymaster'

import {
  NFT_ABI,
  DATATOKEN_TEMPLATE2_ABI,
  FIXED_RATE_EXCHNGE_ABI,
  DISPENSER_ABI,
  ERC721_FACTORY_ABI
} from '@utils/biconomy/abiCollection'
import { getAccessToken } from '@utils/auth'
import { ApiResponse } from '../../@types/SmartAccount'
import axios, { AxiosResponse } from 'axios'
import { getSponsorTransactionUrl } from '@utils/api'
import { LoggerInstance } from '@oceanprotocol/lib'
import { ACCOUNT_ABSTRACTION_PROVIDERS } from '@utils/constants'

const GAS_SPONSOR_METHODS = [
  'createNftWithErc20WithDispenser',
  'createNftWithErc20WithFixedRate',
  'setMetaData',
  'setMetaDataAndTokenURI',
  'buyFromDispenserAndOrder',
  'buyFromFreAndOrder',
  'mint',
  'buyDT',
  'dispense',
  'startOrder',
  'approve',
  'setMetaDataState',
  'safeTransferNft',
  'setRate',
  'setPaymentCollector',
  'safeTransferFrom',
  'setMerkleRoot',
  'reuseOrder'
]

export class TransactionManager {
  private authProvider: IProvider | null = null
  private web3Provider: ethers.providers.Web3Provider | null = null
  private smartAccount: BiconomySmartAccountV2 | any | null = null
  private sendResult: UserOpReceipt | null = null
  private sessionValidationModule: string | null = null
  private accountAbstractionProvider: string | null
  private readonly erc721FactoryInterface: ethers.utils.Interface | null = null
  private readonly nftInterface: ethers.utils.Interface | null = null
  private readonly datatokenInterface: ethers.utils.Interface | null = null
  private readonly dispenserInterface: ethers.utils.Interface | null = null
  private readonly fixedRateExchangeInterface: ethers.utils.Interface | null =
    null

  constructor() {
    this.erc721FactoryInterface = new ethers.utils.Interface(ERC721_FACTORY_ABI)
    this.nftInterface = new ethers.utils.Interface(NFT_ABI)
    this.datatokenInterface = new ethers.utils.Interface(
      DATATOKEN_TEMPLATE2_ABI
    )
    this.dispenserInterface = new ethers.utils.Interface(DISPENSER_ABI)
    this.fixedRateExchangeInterface = new ethers.utils.Interface(
      FIXED_RATE_EXCHNGE_ABI
    )
  }

  getAuthProvider(): IProvider {
    return this.authProvider
  }

  getSmartAccount(): BiconomySmartAccountV2 {
    return this.smartAccount
  }

  setWeb3Provider(web3Provider: ethers.providers.Web3Provider) {
    this.web3Provider = web3Provider
  }

  setSessionValidationModule(validationContractAddress: string) {
    this.sessionValidationModule = validationContractAddress
  }

  setAccountAbstractionProvider(accountAbstractionProvider: string) {
    this.accountAbstractionProvider = accountAbstractionProvider
  }

  setAuthProvider(authProvider: IProvider | null) {
    this.authProvider = authProvider
  }

  setSmartAccount(smartAccount: BiconomySmartAccountV2 | null) {
    this.smartAccount = smartAccount
  }

  setTransactionResult(result: UserOpReceipt | null) {
    this.sendResult = result
  }

  getTransactionResult(): UserOpReceipt | null {
    return this.sendResult
  }

  clearTransactionResult() {
    this.sendResult = null
  }

  private parseTransaction(
    method: string,
    transaction: Transaction
  ): ethers.utils.TransactionDescription | undefined {
    let txnObj: ethers.utils.TransactionDescription | undefined
    const interfaceList = [
      {
        name: 'erc721FactoryInterface',
        value: this.erc721FactoryInterface
      },
      {
        name: 'nftInterface',
        value: this.nftInterface
      },
      {
        name: 'datatokenInterface',
        value: this.datatokenInterface
      },
      {
        name: 'dispenserInterface',
        value: this.dispenserInterface
      },
      {
        name: 'fixedRateExchangeInterface',
        value: this.fixedRateExchangeInterface
      }
    ]
    if (transaction?.data) {
      for (const iface of interfaceList) {
        try {
          const currentInterface = iface.value
          txnObj = currentInterface.parseTransaction({ data: transaction.data })
          break // Exit the loop if parsing is successful
        } catch (error) {
          // console.log(`error parsing txn with ${iface.name}, trying next...`)
        }
      }
    }
    return txnObj
  }

  sendTransaction = async (method: string, params: Transaction[] = []) => {
    const txnObj = this.parseTransaction(method, params[0])

    if (method === 'eth_estimateGas') {
      return 0
    }

    if (
      txnObj &&
      this.accountAbstractionProvider ===
        ACCOUNT_ABSTRACTION_PROVIDERS.ALCHEMY &&
      GAS_SPONSOR_METHODS.includes(txnObj?.name || '')
    ) {
      return await this.initiateAlchemyTransaction(method, params)
    } else if (
      this.accountAbstractionProvider ===
        ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY &&
      txnObj &&
      GAS_SPONSOR_METHODS.includes(txnObj?.name || '')
    ) {
      try {
        LoggerInstance.log('Method : ', txnObj?.name)
        return await this.initiateBiconomyTransaction(method, params)
      } catch (e) {
        console.error(
          '[transactionManager]: Error in executing eth_sendTransaction using biconomy: ',
          method,
          params,
          e
        )
        return ''
      }
    } else {
      try {
        return await this.initiateWeb3ProviderTransaction(method, params)
      } catch (e) {
        console.error(
          "[transactionManager]: Error in executing authProvider's request: ",
          method,
          params,
          e
        )
        return ''
      }
    }
  }

  async initiateAlchemyTransaction(
    method: string,
    params: Transaction[]
  ): Promise<string> {
    if (!this.smartAccount) {
      console.error(
        '[transactionManager]: Alchemy Smart account not configured: ',
        method,
        params
      )
      return ''
    }
    try {
      const isAccountSessionKey = await this.smartAccount.isAccountSessionKey({
        key: this.smartAccount.account.publicKey,
        account: this.smartAccount.account
      })

      if (isAccountSessionKey) {
        const signer = this.web3Provider?.getSigner()

        const sessionKeyUo = await this.smartAccount.executeWithSessionKey({
          args: [
            [
              {
                target: ethers.utils.getAddress(params[0]?.to),
                data: ethers.utils.hexlify(params[0]?.data),
                value: ethers.utils.hexlify(params[0]?.value || 0n)
              }
            ],
            await signer.getAddress()
          ]
        })

        const txHash = await this.smartAccount.waitForUserOperationTransaction({
          hash: sessionKeyUo.hash
        })

        return txHash
      } else {
        const uoHash = await this.smartAccount.sendUserOperation({
          uo: {
            target: ethers.utils.getAddress(params[0]?.to),
            data: ethers.utils.hexlify(params[0]?.data)
          }
        })

        const txHash = await this.smartAccount.waitForUserOperationTransaction(
          uoHash
        )

        return txHash

        // Kris: Keeping custom build User OPs as backup method in case of future client deprecation event
        // const token = await getAccessToken()
        // const signer = this.web3Provider?.getSigner()
        // const chain = await signer.getChainId()
        // const entryPointAddress =
        //   this.smartAccount.account.getEntryPoint().address
        // let uoStruct = await this.smartAccount.buildUserOperation({
        //   uo: {
        //     target: ethers.utils.getAddress(params[0]?.to),
        //     data: ethers.utils.hexlify(params[0]?.data) as any
        //   },
        //   account: undefined
        // })
        // console.log('[initiateAlchemyTx 1] uoStruct=', uoStruct)

        // // kris alchemy: Send `request` to payment management for PayMasterAndData
        // const payload = {
        //   authService: 'jwt',
        //   chainId: chain,
        //   entryPoint: entryPointAddress,
        //   dummySignature: await this.smartAccount.account.getDummySignature(),
        //   userOperation: {
        //     ...uoStruct,
        //     maxFeePerGas: ethers.utils.hexlify(uoStruct?.maxFeePerGas),
        //     maxPriorityFeePerGas: ethers.utils.hexlify(
        //       uoStruct?.maxPriorityFeePerGas
        //     ),
        //     nonce: ethers.utils.hexlify(uoStruct?.nonce)
        //   }
        // }
        // console.log('[initiateAlchemyTx 2 payment-m payload=', payload)
        // const apiResponse: AxiosResponse = await axios.post<ApiResponse<any>>(
        //   getSponsorTransactionUrl(),
        //   payload,
        //   {
        //     headers: {
        //       'Content-Type': 'application/json',
        //       Authorization: `Bearer ${token}`
        //     }
        //   }
        // )
        // if (apiResponse.status === 200) {
        //   const { result } = apiResponse.data.sponsorData
        //   console.log('[initiateAlchemyTx 3 api response.data=', result)
        //   uoStruct = {
        //     ...uoStruct,
        //     ...result
        //   }
        // } else {
        //   // Kris: To allow future flexibility of no gas sponsorship = use smart account address native token balance
        //   console.log(
        //     '[Payment Management] Sponsorship not available, sending user ops without sponsor...'
        //   )
        // }
        // console.log('[initiateAlchemyTx 4 new uoStruct=', uoStruct)

        // const request = await this.smartAccount.signUserOperation({
        //   uoStruct,
        //   account: this.smartAccount.account
        // })
        // console.log('[initiateAlchemyTx 5] Signed request=', request)
        // const opHash = await this.smartAccount.sendRawUserOperation(
        //   request,
        //   entryPointAddress
        // )

        // console.log('[initiateAlchemyTx 6] uoHash=', opHash)
        // const txHash = await this.smartAccount.waitForUserOperationTransaction({
        //   hash: opHash
        // })
        // console.log('[initiateAlchemyTx 7] confirmed txHash=', txHash)
        // return txHash
      }
    } catch (e) {
      console.error(
        '[transactionManager Alchemy]: failed to execute user operations: ',
        e
      )
      return ''
    }
  }

  async initiateBiconomyTransaction(
    method: string,
    params: Transaction[]
  ): Promise<string> {
    if (!this.smartAccount) {
      console.error(
        '[transactionManager]: Smart account not configured: ',
        method,
        params
      )
      return ''
    }
    try {
      const signer = this.web3Provider?.getSigner()
      const userOp = await this.smartAccount.buildUserOp(params || [], {
        params: {
          sessionSigner: signer,
          sessionValidationModule: this.sessionValidationModule
        }
      })
      const chain = await signer.getChainId()

      const token = await getAccessToken()
      const payload = {
        authService: 'jwt',
        userOpParam: userOp,
        chainId: chain
      }

      const apiResponse: AxiosResponse = await axios.post<ApiResponse<any>>(
        getSponsorTransactionUrl(),
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        }
      )
      const { data } = apiResponse
      const paymasterResult = data.sponsorData

      userOp.paymasterAndData = paymasterResult.paymasterAndData
      if (
        paymasterResult.callGasLimit &&
        paymasterResult.verificationGasLimit &&
        paymasterResult.preVerificationGas
      ) {
        // Returned gas limits must be replaced in your op as you update paymasterAndData.
        // Because these are the limits paymaster service signed on to generate paymasterAndData
        // If you receive AA34 error check here.
        userOp.callGasLimit = paymasterResult.callGasLimit
        userOp.verificationGasLimit = paymasterResult.verificationGasLimit
        userOp.preVerificationGas = paymasterResult.preVerificationGas
      }

      // send user op
      const userOpResponse = await this.smartAccount.sendUserOp(userOp, {
        sessionSigner: this.web3Provider?.getSigner(),
        sessionValidationModule: this.sessionValidationModule
      })
      const response = await userOpResponse.wait()
      this.sendResult = response

      // Must return transaction hash for ocean methods to work
      return this.sendResult?.receipt?.transactionHash
    } catch (e) {
      console.error(
        '[transactionManager]: failed to execute user operations: ',
        e
      )
      return ''
    }
  }

  private async initiateWeb3ProviderTransaction(
    method: string,
    params: Transaction[]
  ) {
    if (!this.authProvider) {
      console.error(
        '[transactionManager]: authProvider not configured: ',
        method,
        params
      )
      return ''
    }
    const request = { method, params }
    return await this.authProvider.request(request)
  }
}
