import dispenserJSON from '@oceanprotocol/contracts/artifacts/contracts/pools/dispenser/Dispenser.sol/Dispenser.json'
import ERC721FactoryJSON from '@oceanprotocol/contracts/artifacts/contracts/ERC721Factory.sol/ERC721Factory.json'

export const NFT_ABI = [
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'AddedManager',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'AddedTo725StoreList',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'AddedToCreateERC20List',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'AddedToMetadataList',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'approved',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'Approval',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'operator',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'bool',
        name: 'approved',
        type: 'bool'
      }
    ],
    name: 'ApprovalForAll',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'CleanedPermissions',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'contractAddress',
        type: 'address'
      }
    ],
    name: 'ContractCreated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'key',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'value',
        type: 'bytes'
      }
    ],
    name: 'DataChanged',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'uint256',
        name: '_operation',
        type: 'uint256'
      },
      {
        indexed: true,
        internalType: 'address',
        name: '_to',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: '_value',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: '_data',
        type: 'bytes'
      }
    ],
    name: 'Executed',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'createdBy',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'state',
        type: 'uint8'
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'decryptorUrl',
        type: 'string'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'flags',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'data',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'metaDataHash',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'MetadataCreated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'updatedBy',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'state',
        type: 'uint8'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'MetadataState',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'updatedBy',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'state',
        type: 'uint8'
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'decryptorUrl',
        type: 'string'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'flags',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'data',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'metaDataHash',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'MetadataUpdated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'validator',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'metaDataHash',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'v',
        type: 'uint8'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'r',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 's',
        type: 'bytes32'
      }
    ],
    name: 'MetadataValidated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'RemovedFrom725StoreList',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'RemovedFromCreateERC20List',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'RemovedFromMetadataList',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'RemovedManager',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'newTokenAddress',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'templateAddress',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'name',
        type: 'string'
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'symbol',
        type: 'string'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'cap',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'creator',
        type: 'address'
      }
    ],
    name: 'TokenCreated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'updatedBy',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'string',
        name: 'tokenURI',
        type: 'string'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'tokenID',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'TokenURIUpdate',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'from',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'Transfer',
    type: 'event'
  },
  {
    stateMutability: 'payable',
    type: 'fallback'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_managerAddress',
        type: 'address'
      }
    ],
    name: 'addManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address[]',
        name: 'addresses',
        type: 'address[]'
      },
      {
        internalType: 'enum ERC721RolesAddress.RolesType[]',
        name: 'roles',
        type: 'uint8[]'
      }
    ],
    name: 'addMultipleUsersToRoles',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address'
      }
    ],
    name: 'addTo725StoreList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address'
      }
    ],
    name: 'addToCreateERC20List',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address'
      }
    ],
    name: 'addToMetadataList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'approve',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    name: 'auth',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address'
      }
    ],
    name: 'balanceOf',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'baseURI',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'cleanPermissions',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '_templateIndex',
        type: 'uint256'
      },
      {
        internalType: 'string[]',
        name: 'strings',
        type: 'string[]'
      },
      {
        internalType: 'address[]',
        name: 'addresses',
        type: 'address[]'
      },
      {
        internalType: 'uint256[]',
        name: 'uints',
        type: 'uint256[]'
      },
      {
        internalType: 'bytes[]',
        name: 'bytess',
        type: 'bytes[]'
      }
    ],
    name: 'createERC20',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '_operation',
        type: 'uint256'
      },
      {
        internalType: 'address',
        name: '_to',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: '_value',
        type: 'uint256'
      },
      {
        internalType: 'bytes',
        name: '_data',
        type: 'bytes'
      }
    ],
    name: 'executeCall',
    outputs: [],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'getApproved',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_key',
        type: 'bytes32'
      }
    ],
    name: 'getData',
    outputs: [
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getId',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8'
      }
    ],
    stateMutability: 'pure',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getMetaData',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      },
      {
        internalType: 'string',
        name: '',
        type: 'string'
      },
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8'
      },
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'user',
        type: 'address'
      }
    ],
    name: 'getPermissions',
    outputs: [
      {
        components: [
          {
            internalType: 'bool',
            name: 'manager',
            type: 'bool'
          },
          {
            internalType: 'bool',
            name: 'deployERC20',
            type: 'bool'
          },
          {
            internalType: 'bool',
            name: 'updateMetadata',
            type: 'bool'
          },
          {
            internalType: 'bool',
            name: 'store',
            type: 'bool'
          }
        ],
        internalType: 'struct ERC721RolesAddress.Roles',
        name: '',
        type: 'tuple'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getTokensList',
    outputs: [
      {
        internalType: 'address[]',
        name: '',
        type: 'address[]'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'hasMetaData',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        internalType: 'string',
        name: 'name_',
        type: 'string'
      },
      {
        internalType: 'string',
        name: 'symbol_',
        type: 'string'
      },
      {
        internalType: 'address',
        name: 'tokenFactory',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'additionalERC20Deployer',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'additionalMetaDataUpdater',
        type: 'address'
      },
      {
        internalType: 'string',
        name: 'tokenURI',
        type: 'string'
      },
      {
        internalType: 'bool',
        name: 'transferable_',
        type: 'bool'
      }
    ],
    name: 'initialize',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'operator',
        type: 'address'
      }
    ],
    name: 'isApprovedForAll',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'datatoken',
        type: 'address'
      }
    ],
    name: 'isDeployed',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address'
      }
    ],
    name: 'isERC20Deployer',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'isInitialized',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'metaDataDecryptorAddress',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'metaDataDecryptorUrl',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'metaDataState',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'name',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'ownerOf',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address'
      }
    ],
    name: 'removeFrom725StoreList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address'
      }
    ],
    name: 'removeFromCreateERC20List',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_allowedAddress',
        type: 'address'
      }
    ],
    name: 'removeFromMetadataList',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_managerAddress',
        type: 'address'
      }
    ],
    name: 'removeManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'safeTransferFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'operator',
        type: 'address'
      },
      {
        internalType: 'bool',
        name: 'approved',
        type: 'bool'
      }
    ],
    name: 'setApprovalForAll',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'string',
        name: '_baseURI',
        type: 'string'
      }
    ],
    name: 'setBaseURI',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_key',
        type: 'bytes32'
      },
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes'
      }
    ],
    name: 'setDataERC20',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint8',
        name: '_metaDataState',
        type: 'uint8'
      },
      {
        internalType: 'string',
        name: '_metaDataDecryptorUrl',
        type: 'string'
      },
      {
        internalType: 'string',
        name: '_metaDataDecryptorAddress',
        type: 'string'
      },
      {
        internalType: 'bytes',
        name: 'flags',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: 'data',
        type: 'bytes'
      },
      {
        internalType: 'bytes32',
        name: '_metaDataHash',
        type: 'bytes32'
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'validatorAddress',
            type: 'address'
          },
          {
            internalType: 'uint8',
            name: 'v',
            type: 'uint8'
          },
          {
            internalType: 'bytes32',
            name: 'r',
            type: 'bytes32'
          },
          {
            internalType: 'bytes32',
            name: 's',
            type: 'bytes32'
          }
        ],
        internalType: 'struct ERC721Template.metaDataProof[]',
        name: '_metadataProofs',
        type: 'tuple[]'
      }
    ],
    name: 'setMetaData',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'uint8',
            name: 'metaDataState',
            type: 'uint8'
          },
          {
            internalType: 'string',
            name: 'metaDataDecryptorUrl',
            type: 'string'
          },
          {
            internalType: 'string',
            name: 'metaDataDecryptorAddress',
            type: 'string'
          },
          {
            internalType: 'bytes',
            name: 'flags',
            type: 'bytes'
          },
          {
            internalType: 'bytes',
            name: 'data',
            type: 'bytes'
          },
          {
            internalType: 'bytes32',
            name: 'metaDataHash',
            type: 'bytes32'
          },
          {
            internalType: 'uint256',
            name: 'tokenId',
            type: 'uint256'
          },
          {
            internalType: 'string',
            name: 'tokenURI',
            type: 'string'
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'validatorAddress',
                type: 'address'
              },
              {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8'
              },
              {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32'
              },
              {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32'
              }
            ],
            internalType: 'struct ERC721Template.metaDataProof[]',
            name: 'metadataProofs',
            type: 'tuple[]'
          }
        ],
        internalType: 'struct ERC721Template.metaDataAndTokenURI',
        name: '_metaDataAndTokenURI',
        type: 'tuple'
      }
    ],
    name: 'setMetaDataAndTokenURI',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint8',
        name: '_metaDataState',
        type: 'uint8'
      }
    ],
    name: 'setMetaDataState',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_key',
        type: 'bytes32'
      },
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes'
      }
    ],
    name: 'setNewData',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      },
      {
        internalType: 'string',
        name: 'tokenURI',
        type: 'string'
      }
    ],
    name: 'setTokenURI',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes4',
        name: 'interfaceId',
        type: 'bytes4'
      }
    ],
    name: 'supportsInterface',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'symbol',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'index',
        type: 'uint256'
      }
    ],
    name: 'tokenByIndex',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'index',
        type: 'uint256'
      }
    ],
    name: 'tokenOfOwnerByIndex',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'tokenURI',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'totalSupply',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256'
      }
    ],
    name: 'transferFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'transferable',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'withdrawETH',
    outputs: [],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    stateMutability: 'payable',
    type: 'receive'
  }
]

export const DATATOKEN_TEMPLATE2_ABI = [
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'AddedMinter',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'AddedPaymentManager',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'spender',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'value',
        type: 'uint256'
      }
    ],
    name: 'Approval',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'CleanedPermissions',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'consumeMarketFeeAddress',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'consumeMarketFeeToken',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'consumeMarketFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'ConsumeMarketFee',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'currentMinter',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'newMinter',
        type: 'address'
      }
    ],
    name: 'MinterApproved',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'currentMinter',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'newMinter',
        type: 'address'
      }
    ],
    name: 'MinterProposed',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'dispenserContract',
        type: 'address'
      }
    ],
    name: 'NewDispenser',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'exchangeContract',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'baseToken',
        type: 'address'
      }
    ],
    name: 'NewFixedRate',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'caller',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: '_newPaymentCollector',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'NewPaymentCollector',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'providerAddress',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'consumerAddress',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'providerData',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'providerSignature',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'consumerData',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'consumerSignature',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'OrderExecuted',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'caller',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'number',
        type: 'uint256'
      }
    ],
    name: 'OrderReused',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'consumer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'payer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'serviceIndex',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'publishMarketAddress',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'OrderStarted',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'providerFeeAddress',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'providerFeeToken',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'providerFeeAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'bytes',
        name: 'providerData',
        type: 'bytes'
      },
      {
        indexed: false,
        internalType: 'uint8',
        name: 'v',
        type: 'uint8'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 'r',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'bytes32',
        name: 's',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'validUntil',
        type: 'uint256'
      }
    ],
    name: 'ProviderFee',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'PublishMarketFeeAddress',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'PublishMarketFeeToken',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'PublishMarketFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'PublishMarketFee',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'caller',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'PublishMarketFeeAddress',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'PublishMarketFeeToken',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'PublishMarketFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'PublishMarketFeeChanged',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'RemovedMinter',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'user',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'signer',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'timestamp',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'blockNumber',
        type: 'uint256'
      }
    ],
    name: 'RemovedPaymentManager',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'from',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'value',
        type: 'uint256'
      }
    ],
    name: 'Transfer',
    type: 'event'
  },
  {
    stateMutability: 'payable',
    type: 'fallback'
  },
  {
    inputs: [],
    name: 'BASE',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'DOMAIN_SEPARATOR',
    outputs: [
      {
        internalType: 'bytes32',
        name: '',
        type: 'bytes32'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'PERMIT_TYPEHASH',
    outputs: [
      {
        internalType: 'bytes32',
        name: '',
        type: 'bytes32'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_minter',
        type: 'address'
      }
    ],
    name: 'addMinter',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_paymentManager',
        type: 'address'
      }
    ],
    name: 'addPaymentManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'spender',
        type: 'address'
      }
    ],
    name: 'allowance',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'spender',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'approve',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    name: 'authERC20',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address'
      }
    ],
    name: 'balanceOf',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'burn',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'burnFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'consumer',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'serviceIndex',
            type: 'uint256'
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'providerFeeAddress',
                type: 'address'
              },
              {
                internalType: 'address',
                name: 'providerFeeToken',
                type: 'address'
              },
              {
                internalType: 'uint256',
                name: 'providerFeeAmount',
                type: 'uint256'
              },
              {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8'
              },
              {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32'
              },
              {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32'
              },
              {
                internalType: 'uint256',
                name: 'validUntil',
                type: 'uint256'
              },
              {
                internalType: 'bytes',
                name: 'providerData',
                type: 'bytes'
              }
            ],
            internalType: 'struct ERC20TemplateEnterprise.providerFee',
            name: '_providerFee',
            type: 'tuple'
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'consumeMarketFeeAddress',
                type: 'address'
              },
              {
                internalType: 'address',
                name: 'consumeMarketFeeToken',
                type: 'address'
              },
              {
                internalType: 'uint256',
                name: 'consumeMarketFeeAmount',
                type: 'uint256'
              }
            ],
            internalType: 'struct ERC20TemplateEnterprise.consumeMarketFee',
            name: '_consumeMarketFee',
            type: 'tuple'
          }
        ],
        internalType: 'struct ERC20TemplateEnterprise.OrderParams',
        name: '_orderParams',
        type: 'tuple'
      },
      {
        internalType: 'address',
        name: 'dispenserContract',
        type: 'address'
      }
    ],
    name: 'buyFromDispenserAndOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'consumer',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'serviceIndex',
            type: 'uint256'
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'providerFeeAddress',
                type: 'address'
              },
              {
                internalType: 'address',
                name: 'providerFeeToken',
                type: 'address'
              },
              {
                internalType: 'uint256',
                name: 'providerFeeAmount',
                type: 'uint256'
              },
              {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8'
              },
              {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32'
              },
              {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32'
              },
              {
                internalType: 'uint256',
                name: 'validUntil',
                type: 'uint256'
              },
              {
                internalType: 'bytes',
                name: 'providerData',
                type: 'bytes'
              }
            ],
            internalType: 'struct ERC20TemplateEnterprise.providerFee',
            name: '_providerFee',
            type: 'tuple'
          },
          {
            components: [
              {
                internalType: 'address',
                name: 'consumeMarketFeeAddress',
                type: 'address'
              },
              {
                internalType: 'address',
                name: 'consumeMarketFeeToken',
                type: 'address'
              },
              {
                internalType: 'uint256',
                name: 'consumeMarketFeeAmount',
                type: 'uint256'
              }
            ],
            internalType: 'struct ERC20TemplateEnterprise.consumeMarketFee',
            name: '_consumeMarketFee',
            type: 'tuple'
          }
        ],
        internalType: 'struct ERC20TemplateEnterprise.OrderParams',
        name: '_orderParams',
        type: 'tuple'
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'exchangeContract',
            type: 'address'
          },
          {
            internalType: 'bytes32',
            name: 'exchangeId',
            type: 'bytes32'
          },
          {
            internalType: 'uint256',
            name: 'maxBaseTokenAmount',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'swapMarketFee',
            type: 'uint256'
          },
          {
            internalType: 'address',
            name: 'marketFeeAddress',
            type: 'address'
          }
        ],
        internalType: 'struct ERC20TemplateEnterprise.FreParams',
        name: '_freParams',
        type: 'tuple'
      }
    ],
    name: 'buyFromFreAndOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'cap',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'cleanFrom721',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'cleanPermissions',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_dispenser',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'maxTokens',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'maxBalance',
        type: 'uint256'
      },
      {
        internalType: 'bool',
        name: 'withMint',
        type: 'bool'
      },
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    name: 'createDispenser',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'fixedPriceAddress',
        type: 'address'
      },
      {
        internalType: 'address[]',
        name: 'addresses',
        type: 'address[]'
      },
      {
        internalType: 'uint256[]',
        name: 'uints',
        type: 'uint256[]'
      }
    ],
    name: 'createFixedRate',
    outputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'decimals',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8'
      }
    ],
    stateMutability: 'pure',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'spender',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'subtractedValue',
        type: 'uint256'
      }
    ],
    name: 'decreaseAllowance',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getDispensers',
    outputs: [
      {
        internalType: 'address[]',
        name: '',
        type: 'address[]'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getERC721Address',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getFixedRates',
    outputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'contractAddress',
            type: 'address'
          },
          {
            internalType: 'bytes32',
            name: 'id',
            type: 'bytes32'
          }
        ],
        internalType: 'struct ERC20TemplateEnterprise.fixedRate[]',
        name: '',
        type: 'tuple[]'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getId',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8'
      }
    ],
    stateMutability: 'pure',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getPaymentCollector',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'user',
        type: 'address'
      }
    ],
    name: 'getPermissions',
    outputs: [
      {
        components: [
          {
            internalType: 'bool',
            name: 'minter',
            type: 'bool'
          },
          {
            internalType: 'bool',
            name: 'paymentManager',
            type: 'bool'
          }
        ],
        internalType: 'struct ERC20Roles.RolesERC20',
        name: '',
        type: 'tuple'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getPublishingMarketFee',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      },
      {
        internalType: 'address',
        name: '',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'spender',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'addedValue',
        type: 'uint256'
      }
    ],
    name: 'increaseAllowance',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'string[]',
        name: 'strings_',
        type: 'string[]'
      },
      {
        internalType: 'address[]',
        name: 'addresses_',
        type: 'address[]'
      },
      {
        internalType: 'address[]',
        name: 'factoryAddresses_',
        type: 'address[]'
      },
      {
        internalType: 'uint256[]',
        name: 'uints_',
        type: 'uint256[]'
      },
      {
        internalType: 'bytes[]',
        name: 'bytes_',
        type: 'bytes[]'
      }
    ],
    name: 'initialize',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'user',
        type: 'address'
      }
    ],
    name: 'isERC20Deployer',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'isInitialized',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address'
      }
    ],
    name: 'isMinter',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'account',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'value',
        type: 'uint256'
      }
    ],
    name: 'mint',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'name',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    name: 'nonces',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32'
      },
      {
        internalType: 'bytes',
        name: 'providerData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: 'providerSignature',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: 'consumerData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: 'consumerSignature',
        type: 'bytes'
      },
      {
        internalType: 'address',
        name: 'consumerAddress',
        type: 'address'
      }
    ],
    name: 'orderExecuted',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    name: 'permissions',
    outputs: [
      {
        internalType: 'bool',
        name: 'minter',
        type: 'bool'
      },
      {
        internalType: 'bool',
        name: 'paymentManager',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'spender',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'value',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'deadline',
        type: 'uint256'
      },
      {
        internalType: 'uint8',
        name: 'v',
        type: 'uint8'
      },
      {
        internalType: 'bytes32',
        name: 'r',
        type: 'bytes32'
      },
      {
        internalType: 'bytes32',
        name: 's',
        type: 'bytes32'
      }
    ],
    name: 'permit',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_minter',
        type: 'address'
      }
    ],
    name: 'removeMinter',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_paymentManager',
        type: 'address'
      }
    ],
    name: 'removePaymentManager',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'orderTxId',
        type: 'bytes32'
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'providerFeeAddress',
            type: 'address'
          },
          {
            internalType: 'address',
            name: 'providerFeeToken',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'providerFeeAmount',
            type: 'uint256'
          },
          {
            internalType: 'uint8',
            name: 'v',
            type: 'uint8'
          },
          {
            internalType: 'bytes32',
            name: 'r',
            type: 'bytes32'
          },
          {
            internalType: 'bytes32',
            name: 's',
            type: 'bytes32'
          },
          {
            internalType: 'uint256',
            name: 'validUntil',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'providerData',
            type: 'bytes'
          }
        ],
        internalType: 'struct ERC20TemplateEnterprise.providerFee',
        name: '_providerFee',
        type: 'tuple'
      }
    ],
    name: 'reuseOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'router',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes',
        name: '_value',
        type: 'bytes'
      }
    ],
    name: 'setData',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_newPaymentCollector',
        type: 'address'
      }
    ],
    name: 'setPaymentCollector',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_publishMarketFeeAddress',
        type: 'address'
      },
      {
        internalType: 'address',
        name: '_publishMarketFeeToken',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: '_publishMarketFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'setPublishingMarketFee',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'consumer',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'serviceIndex',
        type: 'uint256'
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'providerFeeAddress',
            type: 'address'
          },
          {
            internalType: 'address',
            name: 'providerFeeToken',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'providerFeeAmount',
            type: 'uint256'
          },
          {
            internalType: 'uint8',
            name: 'v',
            type: 'uint8'
          },
          {
            internalType: 'bytes32',
            name: 'r',
            type: 'bytes32'
          },
          {
            internalType: 'bytes32',
            name: 's',
            type: 'bytes32'
          },
          {
            internalType: 'uint256',
            name: 'validUntil',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'providerData',
            type: 'bytes'
          }
        ],
        internalType: 'struct ERC20TemplateEnterprise.providerFee',
        name: '_providerFee',
        type: 'tuple'
      },
      {
        components: [
          {
            internalType: 'address',
            name: 'consumeMarketFeeAddress',
            type: 'address'
          },
          {
            internalType: 'address',
            name: 'consumeMarketFeeToken',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'consumeMarketFeeAmount',
            type: 'uint256'
          }
        ],
        internalType: 'struct ERC20TemplateEnterprise.consumeMarketFee',
        name: '_consumeMarketFee',
        type: 'tuple'
      }
    ],
    name: 'startOrder',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'symbol',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'totalSupply',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'transfer',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'transferFrom',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'withdrawETH',
    outputs: [],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    stateMutability: 'payable',
    type: 'receive'
  }
]

export const FIXED_RATE_EXCHNGE_ABI = [
  {
    inputs: [
      {
        internalType: 'address',
        name: '_router',
        type: 'address'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'constructor'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'token',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'ConsumeMarketFee',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'exchangeOwner',
        type: 'address'
      }
    ],
    name: 'ExchangeActivated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'allowedSwapper',
        type: 'address'
      }
    ],
    name: 'ExchangeAllowedSwapperChanged',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'baseToken',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'datatoken',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'exchangeOwner',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'fixedRate',
        type: 'uint256'
      }
    ],
    name: 'ExchangeCreated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'exchangeOwner',
        type: 'address'
      }
    ],
    name: 'ExchangeDeactivated',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'exchangeOwner',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'bool',
        name: 'withMint',
        type: 'bool'
      }
    ],
    name: 'ExchangeMintStateChanged',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'exchangeOwner',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'newRate',
        type: 'uint256'
      }
    ],
    name: 'ExchangeRateChanged',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'feeToken',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'feeAmount',
        type: 'uint256'
      }
    ],
    name: 'MarketFeeCollected',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'feeToken',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'feeAmount',
        type: 'uint256'
      }
    ],
    name: 'OceanFeeCollected',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'caller',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'newMarketCollector',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'swapFee',
        type: 'uint256'
      }
    ],
    name: 'PublishMarketFeeChanged',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'oceanFeeAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'marketFeeAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'consumeMarketFeeAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'tokenFeeAddress',
        type: 'address'
      }
    ],
    name: 'SWAP_FEES',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'by',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'baseTokenSwappedAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'datatokenSwappedAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'tokenOutAddress',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'marketFeeAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'oceanFeeAmount',
        type: 'uint256'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'consumeMarketFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'Swapped',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'to',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'token',
        type: 'address'
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'TokenCollected',
    type: 'event'
  },
  {
    inputs: [],
    name: 'MAX_FEE',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'MIN_FEE',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'MIN_RATE',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: 'datatokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'maxBaseTokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'address',
        name: 'consumeMarketAddress',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'consumeMarketSwapFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'buyDT',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: 'datatokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'consumeMarketSwapFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'calcBaseInGivenOutDT',
    outputs: [
      {
        internalType: 'uint256',
        name: 'baseTokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'oceanFeeAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'publishMarketFeeAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'consumeMarketFeeAmount',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: 'datatokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'consumeMarketSwapFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'calcBaseOutGivenInDT',
    outputs: [
      {
        internalType: 'uint256',
        name: 'baseTokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'oceanFeeAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'publishMarketFeeAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'consumeMarketFeeAmount',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'collectBT',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256'
      }
    ],
    name: 'collectDT',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'collectMarketFee',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'collectOceanFee',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'datatoken',
        type: 'address'
      },
      {
        internalType: 'address[]',
        name: 'addresses',
        type: 'address[]'
      },
      {
        internalType: 'uint256[]',
        name: 'uints',
        type: 'uint256[]'
      }
    ],
    name: 'createWithDecimals',
    outputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'baseToken',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'datatoken',
        type: 'address'
      }
    ],
    name: 'generateExchangeId',
    outputs: [
      {
        internalType: 'bytes32',
        name: '',
        type: 'bytes32'
      }
    ],
    stateMutability: 'pure',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'getAllowedSwapper',
    outputs: [
      {
        internalType: 'address',
        name: 'allowedSwapper',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'getBTSupply',
    outputs: [
      {
        internalType: 'uint256',
        name: 'supply',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'getDTSupply',
    outputs: [
      {
        internalType: 'uint256',
        name: 'supply',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'getExchange',
    outputs: [
      {
        internalType: 'address',
        name: 'exchangeOwner',
        type: 'address'
      },
      {
        internalType: 'address',
        name: 'datatoken',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'dtDecimals',
        type: 'uint256'
      },
      {
        internalType: 'address',
        name: 'baseToken',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'btDecimals',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'fixedRate',
        type: 'uint256'
      },
      {
        internalType: 'bool',
        name: 'active',
        type: 'bool'
      },
      {
        internalType: 'uint256',
        name: 'dtSupply',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'btSupply',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'dtBalance',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'btBalance',
        type: 'uint256'
      },
      {
        internalType: 'bool',
        name: 'withMint',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getExchanges',
    outputs: [
      {
        internalType: 'bytes32[]',
        name: '',
        type: 'bytes32[]'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'getFeesInfo',
    outputs: [
      {
        internalType: 'uint256',
        name: 'marketFee',
        type: 'uint256'
      },
      {
        internalType: 'address',
        name: 'marketFeeCollector',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'opcFee',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'marketFeeAvailable',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'oceanFeeAvailable',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getId',
    outputs: [
      {
        internalType: 'uint8',
        name: '',
        type: 'uint8'
      }
    ],
    stateMutability: 'pure',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'getMarketFee',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getNumberOfExchanges',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'baseTokenAddress',
        type: 'address'
      }
    ],
    name: 'getOPCFee',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'getRate',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'isActive',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'router',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: 'datatokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'uint256',
        name: 'minBaseTokenAmount',
        type: 'uint256'
      },
      {
        internalType: 'address',
        name: 'consumeMarketAddress',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: 'consumeMarketSwapFeeAmount',
        type: 'uint256'
      }
    ],
    name: 'sellDT',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'address',
        name: 'newAllowedSwapper',
        type: 'address'
      }
    ],
    name: 'setAllowedSwapper',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: 'newRate',
        type: 'uint256'
      }
    ],
    name: 'setRate',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      }
    ],
    name: 'toggleExchangeState',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'bool',
        name: 'withMint',
        type: 'bool'
      }
    ],
    name: 'toggleMintState',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'uint256',
        name: '_newMarketFee',
        type: 'uint256'
      }
    ],
    name: 'updateMarketFee',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'exchangeId',
        type: 'bytes32'
      },
      {
        internalType: 'address',
        name: '_newMarketCollector',
        type: 'address'
      }
    ],
    name: 'updateMarketFeeCollector',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  }
]

export const DISPENSER_ABI = dispenserJSON.abi

export const ERC721_FACTORY_ABI = ERC721FactoryJSON.abi

export const PAYMASTER_ABI = [
  {
    inputs: [
      { internalType: 'address', name: '_owner', type: 'address' },
      {
        internalType: 'contract IEntryPoint',
        name: '_entryPoint',
        type: 'address'
      },
      {
        internalType: 'address',
        name: '_verifyingSigner',
        type: 'address'
      }
    ],
    stateMutability: 'payable',
    type: 'constructor'
  },
  {
    inputs: [{ internalType: 'address', name: 'caller', type: 'address' }],
    name: 'CallerIsNotAnEntryPoint',
    type: 'error'
  },
  { inputs: [], name: 'CanNotWithdrawToZeroAddress', type: 'error' },
  { inputs: [], name: 'DepositCanNotBeZero', type: 'error' },
  { inputs: [], name: 'EntryPointCannotBeZero', type: 'error' },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'amountRequired',
        type: 'uint256'
      },
      { internalType: 'uint256', name: 'currentBalance', type: 'uint256' }
    ],
    name: 'InsufficientBalance',
    type: 'error'
  },
  {
    inputs: [{ internalType: 'uint256', name: 'sigLength', type: 'uint256' }],
    name: 'InvalidPaymasterSignatureLength',
    type: 'error'
  },
  { inputs: [], name: 'PaymasterIdCannotBeZero', type: 'error' },
  { inputs: [], name: 'VerifyingSignerCannotBeZero', type: 'error' },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'uint256',
        name: '_oldValue',
        type: 'uint256'
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: '_newValue',
        type: 'uint256'
      }
    ],
    name: 'EPGasOverheadChanged',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: '_paymasterId',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: '_charge',
        type: 'uint256'
      }
    ],
    name: 'GasBalanceDeducted',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: '_paymasterId',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: '_value',
        type: 'uint256'
      }
    ],
    name: 'GasDeposited',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: '_paymasterId',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: '_to',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: '_value',
        type: 'uint256'
      }
    ],
    name: 'GasWithdrawn',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'previousOwner',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'newOwner',
        type: 'address'
      }
    ],
    name: 'OwnershipTransferred',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: '_oldSigner',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: '_newSigner',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: '_actor',
        type: 'address'
      }
    ],
    name: 'VerifyingSignerChanged',
    type: 'event'
  },
  {
    inputs: [
      { internalType: 'uint32', name: 'unstakeDelaySec', type: 'uint32' }
    ],
    name: 'addStake',
    outputs: [],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'deposit',
    outputs: [],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'paymasterId', type: 'address' }],
    name: 'depositFor',
    outputs: [],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'entryPoint',
    outputs: [
      { internalType: 'contract IEntryPoint', name: '', type: 'address' }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'paymasterId', type: 'address' }],
    name: 'getBalance',
    outputs: [{ internalType: 'uint256', name: 'balance', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'getDeposit',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          { internalType: 'address', name: 'sender', type: 'address' },
          { internalType: 'uint256', name: 'nonce', type: 'uint256' },
          { internalType: 'bytes', name: 'initCode', type: 'bytes' },
          { internalType: 'bytes', name: 'callData', type: 'bytes' },
          {
            internalType: 'uint256',
            name: 'callGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'verificationGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'preVerificationGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxPriorityFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'paymasterAndData',
            type: 'bytes'
          },
          { internalType: 'bytes', name: 'signature', type: 'bytes' }
        ],
        internalType: 'struct UserOperation',
        name: 'userOp',
        type: 'tuple'
      },
      { internalType: 'address', name: 'paymasterId', type: 'address' },
      { internalType: 'uint48', name: 'validUntil', type: 'uint48' },
      { internalType: 'uint48', name: 'validAfter', type: 'uint48' }
    ],
    name: 'getHash',
    outputs: [{ internalType: 'bytes32', name: '', type: 'bytes32' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'owner',
    outputs: [{ internalType: 'address', name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: '', type: 'address' }],
    name: 'paymasterIdBalances',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'enum IPaymaster.PostOpMode',
        name: 'mode',
        type: 'uint8'
      },
      { internalType: 'bytes', name: 'context', type: 'bytes' },
      { internalType: 'uint256', name: 'actualGasCost', type: 'uint256' }
    ],
    name: 'postOp',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'renounceOwnership',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_newVerifyingSigner',
        type: 'address'
      }
    ],
    name: 'setSigner',
    outputs: [],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'uint256', name: 'value', type: 'uint256' }],
    name: 'setUnaccountedEPGasOverhead',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'newOwner', type: 'address' }],
    name: 'transferOwnership',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'unlockStake',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          { internalType: 'address', name: 'sender', type: 'address' },
          { internalType: 'uint256', name: 'nonce', type: 'uint256' },
          { internalType: 'bytes', name: 'initCode', type: 'bytes' },
          { internalType: 'bytes', name: 'callData', type: 'bytes' },
          {
            internalType: 'uint256',
            name: 'callGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'verificationGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'preVerificationGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxPriorityFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'paymasterAndData',
            type: 'bytes'
          },
          { internalType: 'bytes', name: 'signature', type: 'bytes' }
        ],
        internalType: 'struct UserOperation',
        name: 'userOp',
        type: 'tuple'
      },
      { internalType: 'bytes32', name: 'userOpHash', type: 'bytes32' },
      { internalType: 'uint256', name: 'maxCost', type: 'uint256' }
    ],
    name: 'validatePaymasterUserOp',
    outputs: [
      { internalType: 'bytes', name: 'context', type: 'bytes' },
      { internalType: 'uint256', name: 'validationData', type: 'uint256' }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'verifyingSigner',
    outputs: [{ internalType: 'address', name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address payable',
        name: 'withdrawAddress',
        type: 'address'
      }
    ],
    name: 'withdrawStake',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address payable',
        name: 'withdrawAddress',
        type: 'address'
      },
      { internalType: 'uint256', name: 'amount', type: 'uint256' }
    ],
    name: 'withdrawTo',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  }
]

export const ECDSA_ABI = [
  {
    inputs: [
      { internalType: 'address', name: 'smartAccount', type: 'address' }
    ],
    name: 'AlreadyInitedForSmartAccount',
    type: 'error'
  },
  {
    inputs: [
      { internalType: 'address', name: 'smartAccount', type: 'address' }
    ],
    name: 'NoOwnerRegisteredForSmartAccount',
    type: 'error'
  },
  {
    inputs: [{ internalType: 'address', name: 'account', type: 'address' }],
    name: 'NotEOA',
    type: 'error'
  },
  { inputs: [], name: 'WrongSignatureLength', type: 'error' },
  { inputs: [], name: 'ZeroAddressNotAllowedAsOwner', type: 'error' },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'smartAccount',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'oldOwner',
        type: 'address'
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'newOwner',
        type: 'address'
      }
    ],
    name: 'OwnershipTransferred',
    type: 'event'
  },
  {
    inputs: [],
    name: 'NAME',
    outputs: [{ internalType: 'string', name: '', type: 'string' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'VERSION',
    outputs: [{ internalType: 'string', name: '', type: 'string' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'address', name: 'smartAccount', type: 'address' }
    ],
    name: 'getOwner',
    outputs: [{ internalType: 'address', name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'eoaOwner', type: 'address' }],
    name: 'initForSmartAccount',
    outputs: [{ internalType: 'address', name: '', type: 'address' }],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'bytes32', name: 'dataHash', type: 'bytes32' },
      { internalType: 'bytes', name: 'moduleSignature', type: 'bytes' }
    ],
    name: 'isValidSignature',
    outputs: [{ internalType: 'bytes4', name: '', type: 'bytes4' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'bytes32', name: 'dataHash', type: 'bytes32' },
      { internalType: 'bytes', name: 'moduleSignature', type: 'bytes' },
      { internalType: 'address', name: 'smartAccount', type: 'address' }
    ],
    name: 'isValidSignatureForAddress',
    outputs: [{ internalType: 'bytes4', name: '', type: 'bytes4' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'renounceOwnership',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'owner', type: 'address' }],
    name: 'transferOwnership',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          { internalType: 'address', name: 'sender', type: 'address' },
          { internalType: 'uint256', name: 'nonce', type: 'uint256' },
          { internalType: 'bytes', name: 'initCode', type: 'bytes' },
          { internalType: 'bytes', name: 'callData', type: 'bytes' },
          { internalType: 'uint256', name: 'callGasLimit', type: 'uint256' },
          {
            internalType: 'uint256',
            name: 'verificationGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'preVerificationGas',
            type: 'uint256'
          },
          { internalType: 'uint256', name: 'maxFeePerGas', type: 'uint256' },
          {
            internalType: 'uint256',
            name: 'maxPriorityFeePerGas',
            type: 'uint256'
          },
          { internalType: 'bytes', name: 'paymasterAndData', type: 'bytes' },
          { internalType: 'bytes', name: 'signature', type: 'bytes' }
        ],
        internalType: 'struct UserOperation',
        name: 'userOp',
        type: 'tuple'
      },
      { internalType: 'bytes32', name: 'userOpHash', type: 'bytes32' }
    ],
    name: 'validateUserOp',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  }
]

export const SKM_ABI = [
  {
    inputs: [
      {
        internalType: 'address',
        name: 'smartAccount',
        type: 'address'
      }
    ],
    name: 'getSessionKeys',
    outputs: [
      {
        components: [
          {
            internalType: 'bytes32',
            name: 'merkleRoot',
            type: 'bytes32'
          }
        ],
        internalType: 'struct SessionStorage',
        name: '',
        type: 'tuple'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_dataHash',
        type: 'bytes32'
      },
      {
        internalType: 'bytes',
        name: '_signature',
        type: 'bytes'
      }
    ],
    name: 'isValidSignature',
    outputs: [
      {
        internalType: 'bytes4',
        name: '',
        type: 'bytes4'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: '_merkleRoot',
        type: 'bytes32'
      }
    ],
    name: 'setMerkleRoot',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'sender',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'nonce',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'initCode',
            type: 'bytes'
          },
          {
            internalType: 'bytes',
            name: 'callData',
            type: 'bytes'
          },
          {
            internalType: 'uint256',
            name: 'callGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'verificationGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'preVerificationGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxPriorityFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'paymasterAndData',
            type: 'bytes'
          },
          {
            internalType: 'bytes',
            name: 'signature',
            type: 'bytes'
          }
        ],
        internalType: 'struct UserOperation',
        name: 'userOp',
        type: 'tuple'
      },
      {
        internalType: 'bytes32',
        name: 'userOpHash',
        type: 'bytes32'
      }
    ],
    name: 'validateUserOp',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  }
]

export const BASE_CURRENCY_OCEAN = [
  {
    constant: true,
    inputs: [],
    name: 'name',
    outputs: [
      {
        name: '',
        type: 'string'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: 'spender',
        type: 'address'
      },
      {
        name: 'value',
        type: 'uint256'
      }
    ],
    name: 'approve',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'getAccountsLength',
    outputs: [
      {
        name: '',
        type: 'uint256'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'totalSupply',
    outputs: [
      {
        name: '',
        type: 'uint256'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: '_from',
        type: 'address'
      },
      {
        name: '_to',
        type: 'address'
      },
      {
        name: '_value',
        type: 'uint256'
      }
    ],
    name: 'transferFrom',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'decimals',
    outputs: [
      {
        name: '',
        type: 'uint8'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'cap',
    outputs: [
      {
        name: '',
        type: 'uint256'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: 'spender',
        type: 'address'
      },
      {
        name: 'addedValue',
        type: 'uint256'
      }
    ],
    name: 'increaseAllowance',
    outputs: [
      {
        name: 'success',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [],
    name: 'unpause',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: 'to',
        type: 'address'
      },
      {
        name: 'value',
        type: 'uint256'
      }
    ],
    name: 'mint',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [],
    name: 'kill',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: true,
    inputs: [
      {
        name: 'account',
        type: 'address'
      }
    ],
    name: 'isPauser',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'paused',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: false,
    inputs: [],
    name: 'renouncePauser',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: true,
    inputs: [
      {
        name: 'owner',
        type: 'address'
      }
    ],
    name: 'balanceOf',
    outputs: [
      {
        name: '',
        type: 'uint256'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: false,
    inputs: [],
    name: 'renounceOwnership',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: 'account',
        type: 'address'
      }
    ],
    name: 'addPauser',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [],
    name: 'pause',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'owner',
    outputs: [
      {
        name: '',
        type: 'address'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'isOwner',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'symbol',
    outputs: [
      {
        name: '',
        type: 'string'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: 'account',
        type: 'address'
      }
    ],
    name: 'addMinter',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [],
    name: 'renounceMinter',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: 'spender',
        type: 'address'
      },
      {
        name: 'subtractedValue',
        type: 'uint256'
      }
    ],
    name: 'decreaseAllowance',
    outputs: [
      {
        name: 'success',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: '_to',
        type: 'address'
      },
      {
        name: '_value',
        type: 'uint256'
      }
    ],
    name: 'transfer',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: true,
    inputs: [
      {
        name: 'account',
        type: 'address'
      }
    ],
    name: 'isMinter',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: true,
    inputs: [
      {
        name: 'owner',
        type: 'address'
      },
      {
        name: 'spender',
        type: 'address'
      }
    ],
    name: 'allowance',
    outputs: [
      {
        name: '',
        type: 'uint256'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: true,
    inputs: [
      {
        name: '_start',
        type: 'uint256'
      },
      {
        name: '_end',
        type: 'uint256'
      }
    ],
    name: 'getAccounts',
    outputs: [
      {
        name: '',
        type: 'address[]'
      },
      {
        name: '',
        type: 'uint256[]'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  },
  {
    constant: false,
    inputs: [
      {
        name: 'newOwner',
        type: 'address'
      }
    ],
    name: 'transferOwnership',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        name: 'contractOwner',
        type: 'address'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'constructor'
  },
  {
    payable: true,
    stateMutability: 'payable',
    type: 'fallback'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        name: 'account',
        type: 'address'
      }
    ],
    name: 'MinterAdded',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        name: 'account',
        type: 'address'
      }
    ],
    name: 'MinterRemoved',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        name: 'account',
        type: 'address'
      }
    ],
    name: 'Paused',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        name: 'account',
        type: 'address'
      }
    ],
    name: 'Unpaused',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        name: 'account',
        type: 'address'
      }
    ],
    name: 'PauserAdded',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        name: 'account',
        type: 'address'
      }
    ],
    name: 'PauserRemoved',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        name: 'from',
        type: 'address'
      },
      {
        indexed: true,
        name: 'to',
        type: 'address'
      },
      {
        indexed: false,
        name: 'value',
        type: 'uint256'
      }
    ],
    name: 'Transfer',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        name: 'owner',
        type: 'address'
      },
      {
        indexed: true,
        name: 'spender',
        type: 'address'
      },
      {
        indexed: false,
        name: 'value',
        type: 'uint256'
      }
    ],
    name: 'Approval',
    type: 'event'
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        name: 'previousOwner',
        type: 'address'
      },
      {
        indexed: true,
        name: 'newOwner',
        type: 'address'
      }
    ],
    name: 'OwnershipTransferred',
    type: 'event'
  }
]

export const USER_SVM_ABI = [
  {
    inputs: [],
    name: 'EXECUTE_OPTIMIZED_SELECTOR',
    outputs: [
      {
        internalType: 'bytes4',
        name: '',
        type: 'bytes4'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'EXECUTE_SELECTOR',
    outputs: [
      {
        internalType: 'bytes4',
        name: '',
        type: 'bytes4'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'baseCurrencyBytecodeHash',
        type: 'bytes32'
      }
    ],
    name: 'initForSmartAccount',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'destinationContract',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      },
      {
        internalType: 'bytes',
        name: '_funcCallData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: '_sessionKeyData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: '',
        type: 'bytes'
      }
    ],
    name: 'validateSessionParams',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'sender',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'nonce',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'initCode',
            type: 'bytes'
          },
          {
            internalType: 'bytes',
            name: 'callData',
            type: 'bytes'
          },
          {
            internalType: 'uint256',
            name: 'callGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'verificationGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'preVerificationGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxPriorityFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'paymasterAndData',
            type: 'bytes'
          },
          {
            internalType: 'bytes',
            name: 'signature',
            type: 'bytes'
          }
        ],
        internalType: 'struct UserOperation',
        name: '_op',
        type: 'tuple'
      },
      {
        internalType: 'bytes32',
        name: '_userOpHash',
        type: 'bytes32'
      },
      {
        internalType: 'bytes',
        name: '_sessionKeyData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: '_sessionKeySignature',
        type: 'bytes'
      }
    ],
    name: 'validateSessionUserOp',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  }
]

export const ADMIN_SVM_ABI = [
  {
    inputs: [],
    name: 'EXECUTE_OPTIMIZED_SELECTOR',
    outputs: [
      {
        internalType: 'bytes4',
        name: '',
        type: 'bytes4'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'EXECUTE_SELECTOR',
    outputs: [
      {
        internalType: 'bytes4',
        name: '',
        type: 'bytes4'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'bytes32',
        name: 'baseCurrencyBytecodeHash',
        type: 'bytes32'
      }
    ],
    name: 'initForSmartAccount',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'destinationContract',
        type: 'address'
      },
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256'
      },
      {
        internalType: 'bytes',
        name: '_funcCallData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: '_sessionKeyData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: '',
        type: 'bytes'
      }
    ],
    name: 'validateSessionParams',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      {
        components: [
          {
            internalType: 'address',
            name: 'sender',
            type: 'address'
          },
          {
            internalType: 'uint256',
            name: 'nonce',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'initCode',
            type: 'bytes'
          },
          {
            internalType: 'bytes',
            name: 'callData',
            type: 'bytes'
          },
          {
            internalType: 'uint256',
            name: 'callGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'verificationGasLimit',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'preVerificationGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'uint256',
            name: 'maxPriorityFeePerGas',
            type: 'uint256'
          },
          {
            internalType: 'bytes',
            name: 'paymasterAndData',
            type: 'bytes'
          },
          {
            internalType: 'bytes',
            name: 'signature',
            type: 'bytes'
          }
        ],
        internalType: 'struct UserOperation',
        name: '_op',
        type: 'tuple'
      },
      {
        internalType: 'bytes32',
        name: '_userOpHash',
        type: 'bytes32'
      },
      {
        internalType: 'bytes',
        name: '_sessionKeyData',
        type: 'bytes'
      },
      {
        internalType: 'bytes',
        name: '_sessionKeySignature',
        type: 'bytes'
      }
    ],
    name: 'validateSessionUserOp',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool'
      }
    ],
    stateMutability: 'view',
    type: 'function'
  }
]
