export function getPaymasterUrl(chainId: number, paymasterKey: string) {
  return `https://paymaster.biconomy.io/api/v1/${chainId}/${paymasterKey}`
}

export function getBundlerUrl(chainId: number, bundlerKey: string) {
  return `https://bundler.biconomy.io/api/v2/${chainId}/${bundlerKey}`
}
