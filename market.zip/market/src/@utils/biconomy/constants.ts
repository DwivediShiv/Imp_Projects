export const WHITELISTED_METHODS_NFT = [
  'addManager',
  'addMultipleUsersToRoles',
  'addTo725StoreList',
  'addToCreateERC20List',
  'addToMetadataList',
  'approve',
  'cleanPermissions',
  'createERC20',
  'executeCall',
  'initialize',
  'removeFrom725StoreList',
  'removeFromCreateERC20List',
  'removeFromMetadataList',
  'removeManager',
  'safeTransferFrom',
  'setApprovalForAll',
  'setBaseURI',
  'setDataERC20',
  'setMetaData',
  'setMetaDataAndTokenURI',
  'setMetaDataState',
  'setNewData',
  'setTokenURI',
  'transferFrom',
  'withdrawETH'
]

export const WHITELISTED_METHODS_DATATOKEN = [
  'addMinter',
  'addPaymentManager',
  'approve',
  'burn',
  'burnFrom',
  'buyFromDispenserAndOrder',
  'buyFromFreAndOrder',
  'cleanFrom721',
  'cleanPermissions',
  'createDispenser',
  'createFixedRate',
  'decreaseAllowance',
  'increaseAllowance',
  'initialize',
  'mint',
  'orderExecuted',
  'permit',
  'removeMinter',
  'removePaymentManager',
  'reuseOrder',
  'setData',
  'setPaymentCollector',
  'setPublishingMarketFee',
  'startOrder',
  'transfer',
  'transferFrom',
  'withdrawETH'
]

export const ERROR_MESSAGES = {
  CONTRACT_ALREADY_EXISTS: 'contract_exists',
  UNEXPECTED_ERROR: 'unexpected error'
}

export const WHITELISTED_METHODS_SKM = ['setMerkleRoot']

export const WHITELISTED_METHODS_BASE_CURRENCY_OCEAN = [
  'approve',
  'transferFrom',
  'increaseAllowance',
  'unpause',
  'mint',
  'kill',
  'renouncePauser',
  'renounceOwnership',
  'addPauser',
  'pause',
  'addMinter',
  'renounceMinter',
  'decreaseAllowance',
  'transfer',
  'transferOwnership'
]

export const WHITELISTED_METHODS_DISP_CONTRACT = [
  'activate',
  'create',
  'deactivate',
  'dispense',
  'ownerWithdraw',
  'setAllowedSwapper'
]

export const WHITELISTED_METHODS_FRE_CONTRACT = [
  'buyDT',
  'collectBT',
  'collectDT',
  'collectMarketFee',
  'collectOceanFee',
  'createWithDecimals',
  'sellDT',
  'setAllowedSwapper',
  'setRate',
  'toggleExchangeState',
  'toggleMintState',
  'updateMarketFee',
  'updateMarketFeeCollector'
]

export const WHITELISTED_METHODS_ERC721_FACTORY_CONTRACT = [
  'add721TokenTemplate',
  'addTokenTemplate',
  'createNftWithErc20',
  'createNftWithErc20WithDispenser',
  'createNftWithErc20WithFixedRate',
  'createNftWithErc20WithPool',
  'createNftWithMetaData',
  'createToken',
  'deployERC721Contract',
  'disable721TokenTemplate',
  'disableTokenTemplate',
  'reactivate721TokenTemplate',
  'reactivateTokenTemplate',
  'renounceOwnership',
  'reuseMultipleTokenOrder',
  'startMultipleTokenOrder',
  'transferOwnership'
]

export const WHITELISTED_METHODS_USER_SVM = ['initForSmartAccount']

export const WHITELISTED_METHODS_ADMIN_SVM = ['initForSmartAccount']

export const WHITELISTED_METHODS_ECDSA = [
  'initForSmartAccount',
  'renounceOwnership',
  'transferOwnership'
]
