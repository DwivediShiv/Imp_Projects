import { act, renderHook } from '@testing-library/react'
import {
  useAbstractWhitelisting,
  useBaseCurrencyAbstractWhitelisting,
  useDispAbstractWhitelisting,
  useErcFactoryAbstractWhitelisting,
  useFreAbstractWhitelisting,
  useSKMAbstractWhitelisting,
  useSvmWhitelisting
} from '../hooks/useAbstractWhitelisting'
import React from 'react'

describe('use abstract hook for whitelisting contracts', () => {
  it('Successful', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addERC721PolicyToPaymaster: jest.fn().mockReturnValue({}),
      addDatatokenPolicyToPaymaster: jest.fn().mockReturnValue({}),
      erc721PolicyError: '',
      datatokenPolicyError: ''
    }))

    const { result } = renderHook(() => useAbstractWhitelisting())

    await act(async () => {
      await result.current.handleAbstractWhitelistingFlow({
        nftAddress: '123',
        services: [{ datatokenAddress: '456' }]
      })
    })

    expect(result.current.errorInternal).toBe('')
  })

  it('Failure', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addERC721PolicyToPaymaster: jest.fn().mockReturnValue({}),
      addDatatokenPolicyToPaymaster: jest.fn().mockReturnValue({}),
      erc721PolicyError: 'unexpected error',
      datatokenPolicyError: 'unexpected error'
    }))

    const { result } = renderHook(() => useAbstractWhitelisting())

    await act(async () => {
      await result.current.handleAbstractWhitelistingFlow({
        nftAddress: '123',
        services: [{ datatokenAddress: '456' }]
      })
    })

    expect(result.current.errorInternal).toBe('')
  })
})

describe('use abstract hook for whitelisting SKM contracts', () => {
  it('Successful', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addSKMPolicyToPaymaster: jest.fn().mockReturnValue({}),
      skmPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest.spyOn(React, 'useState').mockReturnValue(['', mockSetError])

    const { result } = renderHook(() => useSKMAbstractWhitelisting())

    await act(async () => {
      await result.current.handleAbstractWhitelistingFlow(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternal).toBe('')
  })

  it('Failure', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addSKMPolicyToPaymaster: jest.fn().mockReturnValue({}),
      skmPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest
      .spyOn(React, 'useState')
      .mockReturnValue(['unexpected error', mockSetError])

    const { result } = renderHook(() => useSKMAbstractWhitelisting())

    await act(async () => {
      await result.current.handleAbstractWhitelistingFlow(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternal).toBe('unexpected error')
  })
})

describe('use abstract hook for whitelisting Base Currency contracts', () => {
  it('Successful', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addBaseCurrencyPolicyToPaymaster: jest.fn().mockReturnValue({}),
      baseCurrencyPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest.spyOn(React, 'useState').mockReturnValue(['', mockSetError])

    const { result } = renderHook(() => useBaseCurrencyAbstractWhitelisting())

    await act(async () => {
      await result.current.handleBaseCurrencyWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalBaseCurrency).toBe('')
  })

  it('Failure', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addBaseCurrencyPolicyToPaymaster: jest.fn().mockReturnValue({}),
      baseCurrencyPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest
      .spyOn(React, 'useState')
      .mockReturnValue(['unexpected error', mockSetError])

    const { result } = renderHook(() => useBaseCurrencyAbstractWhitelisting())

    await act(async () => {
      await result.current.handleBaseCurrencyWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalBaseCurrency).toBe('unexpected error')
  })
})

describe('use abstract hook for whitelisting FixedRateExchange contracts', () => {
  it('Successful', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addFrePolicyToPaymaster: jest.fn().mockReturnValue({}),
      frePolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest.spyOn(React, 'useState').mockReturnValue(['', mockSetError])

    const { result } = renderHook(() => useFreAbstractWhitelisting())

    await act(async () => {
      await result.current.handleFreWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalFre).toBe('')
  })

  it('Failure', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addFrePolicyToPaymaster: jest.fn().mockReturnValue({}),
      frePolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest
      .spyOn(React, 'useState')
      .mockReturnValue(['unexpected error', mockSetError])

    const { result } = renderHook(() => useFreAbstractWhitelisting())

    await act(async () => {
      await result.current.handleFreWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalFre).toBe('unexpected error')
  })
})

describe('use abstract hook for whitelisting Dispenser contracts', () => {
  it('Successful', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addDispPolicyToPaymaster: jest.fn().mockReturnValue({}),
      dispPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest.spyOn(React, 'useState').mockReturnValue(['', mockSetError])

    const { result } = renderHook(() => useDispAbstractWhitelisting())

    await act(async () => {
      await result.current.handleDispWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalDisp).toBe('')
  })

  it('Failure', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addDispPolicyToPaymaster: jest.fn().mockReturnValue({}),
      dispPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest
      .spyOn(React, 'useState')
      .mockReturnValue(['unexpected error', mockSetError])

    const { result } = renderHook(() => useDispAbstractWhitelisting())

    await act(async () => {
      await result.current.handleDispWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalDisp).toBe('unexpected error')
  })
})

describe('use abstract hook for whitelisting ERC721Factory contracts', () => {
  it('Successful', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addErcFactoryPolicyToPaymaster: jest.fn().mockReturnValue({}),
      ercFactoryPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest.spyOn(React, 'useState').mockReturnValue(['', mockSetError])

    const { result } = renderHook(() => useErcFactoryAbstractWhitelisting())

    await act(async () => {
      await result.current.handleErcFactoryWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalErcFactory).toBe('')
  })

  it('Failure', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addErcFactoryPolicyToPaymaster: jest.fn().mockReturnValue({}),
      ercFactoryPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest
      .spyOn(React, 'useState')
      .mockReturnValue(['unexpected error', mockSetError])

    const { result } = renderHook(() => useErcFactoryAbstractWhitelisting())

    await act(async () => {
      await result.current.handleErcFactoryWhitelisting(
        {
          policyAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.errorInternalErcFactory).toBe('unexpected error')
  })
})

describe('use abstract hook for whitelisting User SVM contract', () => {
  it('Successful', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addUserSvmPolicyToPaymaster: jest.fn().mockReturnValue({}),
      userSvmPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest.spyOn(React, 'useState').mockReturnValue(['', mockSetError])

    const { result } = renderHook(() => useSvmWhitelisting())

    await act(async () => {
      await result.current.handleSvmWhitelistingFlow(
        {
          userAddress: '0x0000000000000000000000000000000000000000'
        },
        {
          adminAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.svmErrorInternal).toBe('')
  })

  it('Failure', async () => {
    jest.mock('../hooks/useAddPolicyToMaster', () => ({
      addUserSvmPolicyToPaymaster: jest.fn().mockReturnValue({}),
      userSvmPolicyError: 'unexpected error'
    }))

    const mockSetError = jest.fn()

    jest
      .spyOn(React, 'useState')
      .mockReturnValue(['unexpected error', mockSetError])

    const { result } = renderHook(() => useSvmWhitelisting())

    await act(async () => {
      await result.current.handleSvmWhitelistingFlow(
        {
          userAddress: '0x0000000000000000000000000000000000000000'
        },
        {
          adminAddress: '0x0000000000000000000000000000000000000000'
        },
        { socialDetails: { authToken: 'abcd', paymasterKey: 'abcd' } }
      )
    })

    expect(result.current.svmErrorInternal).toBe('unexpected error')
  })
})
