import { TransactionManager } from '../transactionManager'
import { BiconomySmartAccountV2 } from '@biconomy/account'
import { IProvider } from '@web3auth/base'
import { UserOpReceipt } from '@biconomy/bundler'
import { IHybridPaymaster, SponsorUserOperationDto } from '@biconomy/paymaster'
import { Transaction } from '@biconomy/core-types'

jest.mock('ethers')
jest.mock('@biconomy/account')
jest.mock('@web3auth/base')

describe('TransactionManager', () => {
  let transactionManager: TransactionManager
  let mockAuthProvider: IProvider | null

  beforeEach(() => {
    transactionManager = new TransactionManager()
    mockAuthProvider = null
  })

  afterEach(() => {
    jest.clearAllMocks()
  })

  it('should initialize correctly', () => {
    expect(transactionManager.getTransactionResult()).toBeNull()
  })

  it('should set authProvider', () => {
    const mockProvider = {} as IProvider
    transactionManager.setAuthProvider(mockProvider)
    expect(transactionManager.getAuthProvider()).toBe(mockProvider)
  })

  it('should set smartAccount', () => {
    const mockAccount = {} as BiconomySmartAccountV2
    transactionManager.setSmartAccount(mockAccount)
    expect(transactionManager.getSmartAccount()).toBe(mockAccount)
  })

  it('should set and get transaction result', () => {
    const mockResult = {} as UserOpReceipt
    transactionManager.setTransactionResult(mockResult)
    expect(transactionManager.getTransactionResult()).toBe(mockResult)
  })

  it('should clear transaction result', () => {
    const mockResult = {} as UserOpReceipt
    transactionManager.setTransactionResult(mockResult)
    transactionManager.clearTransactionResult()
    expect(transactionManager.getTransactionResult()).toBeNull()
  })

  it('should send Biconomy transaction', async () => {
    const mockUserOpResponse = {
      wait: jest
        .fn()
        .mockResolvedValue({ receipt: { transactionHash: 'txhash123' } })
    }

    mockAuthProvider = {
      request: jest.fn().mockResolvedValue('txhash123')
    } as unknown as IProvider

    transactionManager.setSmartAccount({
      buildUserOp: jest.fn().mockResolvedValue({}),
      sendUserOp: jest.fn().mockResolvedValue(mockUserOpResponse),
      paymaster: {} as IHybridPaymaster<SponsorUserOperationDto>
    } as unknown as BiconomySmartAccountV2)

    transactionManager.setAuthProvider(mockAuthProvider)

    const result = await transactionManager.sendTransaction('testMethod', [])
    expect(result).toBe('txhash123')
  })

  it('should send Web3Provider transaction', async () => {
    const mockResponse = 'mockResponse'

    mockAuthProvider = {
      request: jest.fn().mockResolvedValue(mockResponse)
    } as unknown as IProvider

    transactionManager.setAuthProvider(mockAuthProvider)

    const result = await transactionManager.sendTransaction('testMethod', [])
    expect(result).toBe(mockResponse)
  })

  it('should handle Biconomy transaction failure', async () => {
    const errorMessage = 'Biconomy transaction failed'
    transactionManager.setSmartAccount({
      buildUserOp: jest.fn().mockRejectedValue(new Error(errorMessage))
    } as unknown as BiconomySmartAccountV2)

    const result = await transactionManager.sendTransaction('testMethod', [])
    expect(result).toBe('')
  })

  it('should handle Web3Provider transaction failure', async () => {
    const errorMessage = 'Web3Provider transaction failed'
    transactionManager.setAuthProvider({
      request: jest.fn().mockRejectedValue(new Error(errorMessage))
    } as unknown as IProvider)

    const result = await transactionManager.sendTransaction('testMethod', [])
    expect(result).toBe('')
  })

  it('should handle missing smart account', async () => {
    const sendTransactionResult = await transactionManager.sendTransaction(
      'testMethod',
      []
    )
    expect(sendTransactionResult).toBe('')
    const initBiconomyTransactionResult =
      await transactionManager.sendTransaction('testMethod', [])
    expect(initBiconomyTransactionResult).toBe('')
  })

  it('should handle missing auth provider', async () => {
    transactionManager.setSmartAccount({} as BiconomySmartAccountV2)

    const result = await transactionManager.sendTransaction('testMethod', [])
    expect(result).toBe('')
  })

  it.skip('should initiate biconomy transaction', async () => {
    const mockSmartAccount = {
      buildUserOp: jest.fn().mockResolvedValue({
        userOpHash: 'mocked-user-op'
      }),
      paymaster: {
        getPaymasterAndData: jest.fn().mockResolvedValue({
          paymasterAndData: 'mocked-paymaster-data',
          callGasLimit: 100000,
          verificationGasLimit: 20000,
          preVerificationGas: 5000
        })
      },
      sendUserOp: jest.fn().mockReturnValue({
        wait: jest.fn().mockResolvedValue({
          receipt: {
            transactionHash: 'mockTransactionHash'
          }
        })
      })
    } as unknown as BiconomySmartAccountV2

    transactionManager.setSmartAccount(mockSmartAccount)
    transactionManager.setSessionValidationModule('mockValidationModule')
    const method = 'mockMethod'
    const params = [] as unknown as Transaction[]
    const sessionValidationParams = {
      sessionSigner: undefined,
      sessionValidationModule: 'mockValidationModule'
    }
    const result = await transactionManager.initiateBiconomyTransaction(
      method,
      params
    )
    expect(mockSmartAccount.buildUserOp).toHaveBeenCalledWith(params, {
      params: sessionValidationParams
    })
    expect(mockSmartAccount.sendUserOp).toHaveBeenCalledWith(
      {
        userOpHash: 'mocked-user-op',
        paymasterAndData: 'mocked-paymaster-data',
        callGasLimit: 100000,
        verificationGasLimit: 20000,
        preVerificationGas: 5000
      },
      sessionValidationParams
    )
    expect(result).toBe('mockTransactionHash')
  })

  it.skip('should handle Biconomy transaction Initialization failure', async () => {
    const errorMessage = 'Web3Provider transaction failed'
    transactionManager.setSmartAccount({
      request: jest.fn().mockRejectedValue(new Error(errorMessage))
    } as unknown as BiconomySmartAccountV2)

    const result = await transactionManager.initiateBiconomyTransaction(
      'testMethod',
      []
    )
    expect(result).toBeFalsy()
  })
})
