import {
  useBaseCurrencyPolicyToPaymasterApi,
  useDispPolicyToPaymasterApi,
  useErcFactoryPolicyToPaymasterApi,
  useFrePolicyToPaymasterApi,
  usePolicyToPaymasterApi,
  useSKMPolicyToPaymasterApi,
  useSvmPolicyToPaymasterApi,
  useEcdsaPolicyToPaymasterApi
} from '../hooks/useAddPolicyToMaster'
import { act, renderHook } from '@testing-library/react'
import {
  addPolicyHandler,
  getAbstractOrgDataHandler
} from '../msw/addPolicyHandler'

describe.skip('usePolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const policyAddress = '0x123456789abcdef'

  it('should add ERC721 policy to paymaster', async () => {
    const { result } = renderHook(() => usePolicyToPaymasterApi())

    await act(async () => {
      await result.current.addERC721PolicyToPaymaster(policyAddress)
    })
    expect(result.current.erc721PolicyError).toBe('')
  })

  it('should add dataToken policy to paymaster', async () => {
    const { result } = renderHook(() => usePolicyToPaymasterApi())

    await act(async () => {
      await result.current.addDatatokenPolicyToPaymaster(policyAddress)
    })

    expect(result.current.datatokenPolicyError).toBe('')
  })

  it('should handle errors when adding ERC721 policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => usePolicyToPaymasterApi())

    await act(async () => {
      await result.current.addERC721PolicyToPaymaster(policyAddress)
    })

    expect(result.current.erc721PolicyError).toBe(
      'Request failed with status code 500'
    )
  })

  it('should handle errors when adding dataToken policy', async () => {
    addPolicyHandler({
      status: 500
    })

    const { result } = renderHook(() => usePolicyToPaymasterApi())

    await act(async () => {
      await result.current.addDatatokenPolicyToPaymaster(policyAddress)
    })

    expect(result.current.datatokenPolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})

describe('useSKMPolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const policyAddress = '0x123456789abcdef'
  const authToken = '01a9bbc8f-1234-4e00-9f20-1234b5678a90'
  const paymasterKey = '0sCPmg-ab.01c23ba4-e45a-47b2-90e2-f7bd41a671cd'

  it('should add SKM policy to paymaster', async () => {
    const { result } = renderHook(() => useSKMPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addSKMPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })
    expect(result.current.skmPolicyError).toBe('')
  })

  it('should handle errors when adding SKM policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => useSKMPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addSKMPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.skmPolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})

describe('useBaseCurrencyPolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const policyAddress = '0x123456789abcdef'
  const authToken = '01a9bbc8f-1234-4e00-9f20-1234b5678a90'
  const paymasterKey = '0sCPmg-ab.01c23ba4-e45a-47b2-90e2-f7bd41a671cd'

  it('should add Base Currency policy to paymaster', async () => {
    const { result } = renderHook(() => useBaseCurrencyPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addBaseCurrencyPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })
    expect(result.current.baseCurrencyPolicyError).toBe('')
  })

  it('should handle errors when adding Base Currency policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => useBaseCurrencyPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addBaseCurrencyPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.baseCurrencyPolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})

describe('useFrePolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const policyAddress = '0x123456789abcdef'
  const authToken = '01a9bbc8f-1234-4e00-9f20-1234b5678a90'
  const paymasterKey = '0sCPmg-ab.01c23ba4-e45a-47b2-90e2-f7bd41a671cd'

  it('should add Fixed Rate Exchange policy to paymaster', async () => {
    const { result } = renderHook(() => useFrePolicyToPaymasterApi())

    await act(async () => {
      await result.current.addFrePolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })
    expect(result.current.frePolicyError).toBe('')
  })

  it('should handle errors when adding Fixed Rate Exchange policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => useFrePolicyToPaymasterApi())

    await act(async () => {
      await result.current.addFrePolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.frePolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})

describe('useDispPolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const policyAddress = '0x123456789abcdef'
  const authToken = '01a9bbc8f-1234-4e00-9f20-1234b5678a90'
  const paymasterKey = '0sCPmg-ab.01c23ba4-e45a-47b2-90e2-f7bd41a671cd'

  it('should add Dispenser policy to paymaster', async () => {
    const { result } = renderHook(() => useDispPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addDispPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })
    expect(result.current.dispPolicyError).toBe('')
  })

  it('should handle errors when adding Dispenser policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => useDispPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addDispPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.dispPolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})

describe('useErcFactoryPolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const policyAddress = '0x123456789abcdef'
  const authToken = '01a9bbc8f-1234-4e00-9f20-1234b5678a90'
  const paymasterKey = '0sCPmg-ab.01c23ba4-e45a-47b2-90e2-f7bd41a671cd'

  it('should add ERC721 Factory policy to paymaster', async () => {
    const { result } = renderHook(() => useErcFactoryPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addErcFactoryPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })
    expect(result.current.ercFactoryPolicyError).toBe('')
  })

  it('should handle errors when adding ERC721 Factory policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => useErcFactoryPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addErcFactoryPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.ercFactoryPolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})

describe('useSvmPolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const userAddress = '0x123456789abcdef'
  const adminAddress = '0x123456789abcdef'
  const authToken = '01a9bbc8f-1234-4e00-9f20-1234b5678a90'
  const paymasterKey = '0sCPmg-ab.01c23ba4-e45a-47b2-90e2-f7bd41a671cd'

  it('should add user svm policy to paymaster', async () => {
    const { result } = renderHook(() => useSvmPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addUserSVMPolicyToPaymaster(userAddress, {
        authToken,
        paymasterKey
      })
    })
    expect(result.current.userSVMPolicyError).toBe('')
  })

  it('should add admin svm policy to paymaster', async () => {
    const { result } = renderHook(() => useSvmPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addAdminSVMPolicyToPaymaster(adminAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.adminSVMPolicyError).toBe('')
  })

  it('should handle errors when adding user svm policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => useSvmPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addUserSVMPolicyToPaymaster(userAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.userSVMPolicyError).toBe(
      'Request failed with status code 500'
    )
  })

  it('should handle errors when adding admin svm policy', async () => {
    addPolicyHandler({
      status: 500
    })

    const { result } = renderHook(() => useSvmPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addAdminSVMPolicyToPaymaster(adminAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.adminSVMPolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})

describe('useEcdsaPolicyToPaymasterApi', () => {
  beforeEach(() => {
    getAbstractOrgDataHandler()
    addPolicyHandler({})
  })

  const policyAddress = '0x123456789abcdef'
  const authToken = '01a9bbc8f-1234-4e00-9f20-1234b5678a90'
  const paymasterKey = '0sCPmg-ab.01c23ba4-e45a-47b2-90e2-f7bd41a671cd'

  it('should add ECDSA policy to paymaster', async () => {
    const { result } = renderHook(() => useEcdsaPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addEcdsaPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })
    expect(result.current.ecdsaPolicyError).toBe('')
  })

  it('should handle errors when adding ECDSA policy', async () => {
    addPolicyHandler({
      status: 500
    })
    const { result } = renderHook(() => useEcdsaPolicyToPaymasterApi())

    await act(async () => {
      await result.current.addEcdsaPolicyToPaymaster(policyAddress, {
        authToken,
        paymasterKey
      })
    })

    expect(result.current.ecdsaPolicyError).toBe(
      'Request failed with status code 500'
    )
  })
})
