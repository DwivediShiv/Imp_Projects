import { AbstractDetails } from '../../../@types/SmartAccount'

export const orgDetails: AbstractDetails = {
  orgId: 'OrgId',
  orgName: 'mockName',
  sessionKey: {
    merkleRoot: '',
    sessionKeys: [
      {
        validUntil: 0,
        validAfter: 0,
        sessionValidationModule: 'mockValidationModule',
        sessionKeyData: 'mocksessionKeyData',
        sessionPublicKey: '0x0000000000000000000000000000000000000001',
        sessionID: 'mockSessionKey',
        status: 'ACTIVE'
      }
    ]
  },
  accountAddress: 'orgSmartAccount',
  accountAbstractionProvider: ''
}
