import { rest } from 'msw'
import { server } from '@utils/msw'
import { ApiResponse, MswHandlerProps } from '../types/policyToPaymaster'
import { AbstractDetails } from '../../../@types/SmartAccount'
import { getAbstractOrgUrl } from '@utils/api'
import { orgDetails } from './data'

export function addPolicyHandler(props?: MswHandlerProps<any>) {
  const statusCode = props?.status ?? 200
  const handler = rest.post(
    'https://paymaster-dashboard-backend.prod.biconomy.io/api/v2/public/sdk/smart-contract',
    async (_, res, ctx) => {
      let json: ApiResponse<any>

      if (props?.response) {
        json = props.response
      } else {
        json = {}
      }
      return res(ctx.status(statusCode), ctx.json(json))
    }
  )
  server.use(handler)
}

export function getAbstractOrgDataHandler(
  props?: MswHandlerProps<AbstractDetails>
) {
  const statusCode = props?.status ?? 200
  const handler = rest.get(getAbstractOrgUrl(), async (_, res, ctx) => {
    let json: ApiResponse<AbstractDetails>
    const data = orgDetails

    if (props?.response) {
      json = props.response
    } else {
      json = {
        data
      }
    }
    return res(ctx.status(statusCode), ctx.json(json))
  })
  server.use(handler)
}
