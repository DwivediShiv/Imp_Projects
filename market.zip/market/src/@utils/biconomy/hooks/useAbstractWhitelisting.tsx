import { useCallback, useState } from 'react'
import {
  useBaseCurrencyPolicyToPaymasterApi,
  usePolicyToPaymasterApi,
  useSKMPolicyToPaymasterApi,
  useDispPolicyToPaymasterApi,
  useErcFactoryPolicyToPaymasterApi,
  useFrePolicyToPaymasterApi,
  useSvmPolicyToPaymasterApi,
  useEcdsaPolicyToPaymasterApi
} from './useAddPolicyToMaster'
export function useAbstractWhitelisting() {
  const [errorInternal, setErrorInternal] = useState('')
  const {
    addERC721PolicyToPaymaster,
    addDatatokenPolicyToPaymaster,
    erc721PolicyError,
    datatokenPolicyError
  } = usePolicyToPaymasterApi()

  const handleAbstractWhitelistingFlow = useCallback(
    async (asset) => {
      await addERC721PolicyToPaymaster(asset.nftAddress)
      await addDatatokenPolicyToPaymaster(asset.services[0].datatokenAddress)
      if (erc721PolicyError || datatokenPolicyError) {
        setErrorInternal(erc721PolicyError || datatokenPolicyError)
      }
    },
    [
      addERC721PolicyToPaymaster,
      addDatatokenPolicyToPaymaster,
      erc721PolicyError,
      datatokenPolicyError
    ]
  )

  return { handleAbstractWhitelistingFlow, errorInternal }
}

export function useSKMAbstractWhitelisting() {
  const [errorInternal, setErrorInternal] = useState('')
  const { addSKMPolicyToPaymaster, skmPolicyError } =
    useSKMPolicyToPaymasterApi()

  const handleAbstractWhitelistingFlow = useCallback(
    async (policyAddress, payMasterDetails) => {
      await addSKMPolicyToPaymaster(policyAddress, payMasterDetails)
      if (skmPolicyError) {
        setErrorInternal(skmPolicyError)
      }
    },
    [addSKMPolicyToPaymaster, skmPolicyError]
  )

  return { handleAbstractWhitelistingFlow, errorInternal }
}

export function useBaseCurrencyAbstractWhitelisting() {
  const [errorInternalBaseCurrency, setErrorInternalBaseCurrency] = useState('')
  const { addBaseCurrencyPolicyToPaymaster, baseCurrencyPolicyError } =
    useBaseCurrencyPolicyToPaymasterApi()

  const handleBaseCurrencyWhitelisting = useCallback(
    async (policyAddress, payMasterDetails) => {
      try {
        await addBaseCurrencyPolicyToPaymaster(policyAddress, payMasterDetails)
        if (baseCurrencyPolicyError) {
          setErrorInternalBaseCurrency(baseCurrencyPolicyError)
          return false // Whitelisting failed
        }
        return true // Whitelisting succeeded
      } catch (error) {
        console.error('Error handling BaseCurrency whitelisting:', error)
        return false // Whitelisting failed
      }
    },
    [addBaseCurrencyPolicyToPaymaster, baseCurrencyPolicyError]
  )

  return { handleBaseCurrencyWhitelisting, errorInternalBaseCurrency }
}

export function useFreAbstractWhitelisting() {
  const [errorInternalFre, setErrorInternalFre] = useState('')
  const { addFrePolicyToPaymaster, frePolicyError } =
    useFrePolicyToPaymasterApi()

  const handleFreWhitelisting = useCallback(
    async (policyAddress, payMasterDetails) => {
      try {
        await addFrePolicyToPaymaster(policyAddress, payMasterDetails)
        if (frePolicyError) {
          setErrorInternalFre(errorInternalFre)
          return false
        }
        return true
      } catch (error) {
        console.error('Error handling FRE Policy whitelisting:', error)
        return false
      }
    },
    [addFrePolicyToPaymaster, frePolicyError]
  )

  return { handleFreWhitelisting, errorInternalFre }
}

export function useDispAbstractWhitelisting() {
  const [errorInternalDisp, setErrorInternalDisp] = useState('')
  const { addDispPolicyToPaymaster, dispPolicyError } =
    useDispPolicyToPaymasterApi()

  const handleDispWhitelisting = useCallback(
    async (policyAddress, payMasterDetails) => {
      try {
        await addDispPolicyToPaymaster(policyAddress, payMasterDetails)
        if (dispPolicyError) {
          setErrorInternalDisp(dispPolicyError)
          return false
        }
        return true
      } catch (error) {
        console.error('Error handling Dispenser whitelisting:', error)
        return false
      }
    },
    [addDispPolicyToPaymaster, dispPolicyError]
  )

  return { handleDispWhitelisting, errorInternalDisp }
}

export function useErcFactoryAbstractWhitelisting() {
  const [errorInternalErcFactory, setErrorInternalErcFactory] = useState('')
  const { addErcFactoryPolicyToPaymaster, ercFactoryPolicyError } =
    useErcFactoryPolicyToPaymasterApi()

  const handleErcFactoryWhitelisting = useCallback(
    async (policyAddress, payMasterDetails) => {
      try {
        await addErcFactoryPolicyToPaymaster(policyAddress, payMasterDetails)
        if (ercFactoryPolicyError) {
          setErrorInternalErcFactory(ercFactoryPolicyError)
          return false
        }
        return true
      } catch (error) {
        console.error('Error handling ERC721 Factory whitelisting:', error)
        return false
      }
    },
    [addErcFactoryPolicyToPaymaster, ercFactoryPolicyError]
  )

  return { handleErcFactoryWhitelisting, errorInternalErcFactory }
}

export function useSvmWhitelisting() {
  const [svmErrorInternal, setSvmErrorInternal] = useState('')
  const {
    userSVMPolicyError,
    adminSVMPolicyError,
    addUserSVMPolicyToPaymaster,
    addAdminSVMPolicyToPaymaster
  } = useSvmPolicyToPaymasterApi()

  const handleSvmWhitelistingFlow = useCallback(
    async (userAddress, adminAddress, payMasterDetails) => {
      try {
        await addUserSVMPolicyToPaymaster(userAddress, payMasterDetails)
        await addAdminSVMPolicyToPaymaster(adminAddress, payMasterDetails)

        if (userSVMPolicyError || adminSVMPolicyError) {
          setSvmErrorInternal(userSVMPolicyError || adminSVMPolicyError)
          return false
        }

        return true
      } catch (error) {
        console.error('Error handling SVM whitelisting:', error)
        return false
      }
    },
    [
      addUserSVMPolicyToPaymaster,
      addAdminSVMPolicyToPaymaster,
      userSVMPolicyError,
      adminSVMPolicyError
    ]
  )

  return { handleSvmWhitelistingFlow, svmErrorInternal }
}

export function useEcdsaWhitelisting() {
  const [ecdsaErrorInternal, setEcdsaErrorInternal] = useState('')
  const { ecdsaPolicyError, addEcdsaPolicyToPaymaster } =
    useEcdsaPolicyToPaymasterApi()

  const handleEcdsaWhitelistingFlow = useCallback(
    async (ecdsaAddress, payMasterDetails) => {
      try {
        await addEcdsaPolicyToPaymaster(ecdsaAddress, payMasterDetails)

        if (ecdsaPolicyError) {
          setEcdsaErrorInternal(ecdsaPolicyError)
          return false
        }

        return true
      } catch (error) {
        console.error('Error handling ECDSA whitelisting:', error)
        return false
      }
    },
    [ecdsaPolicyError, addEcdsaPolicyToPaymaster]
  )

  return { handleEcdsaWhitelistingFlow, ecdsaErrorInternal }
}
