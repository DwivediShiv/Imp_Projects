import { useCallback, useState } from 'react'
import axios from 'axios'
import { ApiResponse } from '../types/policyToPaymaster'
import {
  NFT_ABI,
  DATATOKEN_TEMPLATE2_ABI,
  SKM_ABI,
  BASE_CURRENCY_OCEAN,
  FIXED_RATE_EXCHNGE_ABI,
  DISPENSER_ABI,
  ERC721_FACTORY_ABI,
  USER_SVM_ABI,
  ADMIN_SVM_ABI,
  ECDSA_ABI
} from '../abiCollection'
import {
  WHITELISTED_METHODS_NFT,
  WHITELISTED_METHODS_DATATOKEN,
  ERROR_MESSAGES,
  WHITELISTED_METHODS_SKM,
  WHITELISTED_METHODS_BASE_CURRENCY_OCEAN,
  WHITELISTED_METHODS_DISP_CONTRACT,
  WHITELISTED_METHODS_ERC721_FACTORY_CONTRACT,
  WHITELISTED_METHODS_FRE_CONTRACT,
  WHITELISTED_METHODS_USER_SVM,
  WHITELISTED_METHODS_ADMIN_SVM,
  WHITELISTED_METHODS_ECDSA
} from '../constants'
import appConfig from 'app.config'
import { getAccessToken } from '@utils/auth'
import { getPaymasterWhitelistingUrl } from '@utils/api'

export const addPolicyToPaymasterUrl = `https://paymaster-dashboard-backend.prod.biconomy.io/api/v2/public/sdk/smart-contract`

export function usePolicyToPaymasterApi() {
  const [erc721PolicyError, setERC721PolicyError] = useState<string | null>('')
  const [datatokenPolicyError, setDatatokenPolicyError] = useState<
    string | null
  >('')

  const addERC721PolicyToPaymaster = useCallback(
    async (policyAddress: string) => {
      try {
        setERC721PolicyError('')

        const payload = {
          authService: 'jwt',
          name: `NFT${policyAddress.slice(-6)}`,
          address: policyAddress,
          abi: JSON.stringify(NFT_ABI),
          whitelistedMethods: WHITELISTED_METHODS_NFT
        }

        const token = await getAccessToken()
        await axios.post<ApiResponse<any>>(
          getPaymasterWhitelistingUrl(),
          payload,
          {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`
            }
          }
        )
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setERC721PolicyError(error.message)
          }
        } else {
          setERC721PolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  const addDatatokenPolicyToPaymaster = useCallback(
    async (policyAddress: string) => {
      try {
        setDatatokenPolicyError('')

        const payload = {
          authService: 'jwt',
          name: `DT${policyAddress.slice(-6)}`,
          address: policyAddress,
          abi: JSON.stringify(DATATOKEN_TEMPLATE2_ABI),
          whitelistedMethods: WHITELISTED_METHODS_DATATOKEN
        }
        const token = await getAccessToken()
        await axios.post<ApiResponse<any>>(
          getPaymasterWhitelistingUrl(),
          payload,
          {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`
            }
          }
        )
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setDatatokenPolicyError(error.message)
          }
        } else {
          setDatatokenPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    erc721PolicyError,
    datatokenPolicyError,
    addERC721PolicyToPaymaster,
    addDatatokenPolicyToPaymaster
  }
}

export function useSKMPolicyToPaymasterApi() {
  const [skmPolicyError, setSKMPolicyError] = useState<string | null>('')

  const addSKMPolicyToPaymaster = useCallback(
    async (skmaddress: string, { authToken, paymasterKey }) => {
      try {
        setSKMPolicyError('')

        const payload = {
          name: `SessionKeyManager`,
          address: skmaddress,
          abi: JSON.stringify(SKM_ABI),
          whitelistedMethods: WHITELISTED_METHODS_SKM
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setSKMPolicyError(error.message)
          }
        } else {
          setSKMPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    skmPolicyError,
    addSKMPolicyToPaymaster
  }
}

export function useBaseCurrencyPolicyToPaymasterApi() {
  const [baseCurrencyPolicyError, setBaseCurrencyPolicyError] = useState<
    string | null
  >('')

  const addBaseCurrencyPolicyToPaymaster = useCallback(
    async (baseCurrencyaddress: string, { authToken, paymasterKey }) => {
      try {
        setBaseCurrencyPolicyError('')

        const payload = {
          name: `BaseCurrencyAddress`,
          address: baseCurrencyaddress,
          abi: JSON.stringify(BASE_CURRENCY_OCEAN),
          whitelistedMethods: WHITELISTED_METHODS_BASE_CURRENCY_OCEAN
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setBaseCurrencyPolicyError(error.message)
          }
        } else {
          setBaseCurrencyPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    baseCurrencyPolicyError,
    addBaseCurrencyPolicyToPaymaster
  }
}

export function useFrePolicyToPaymasterApi() {
  const [frePolicyError, setFrePolicyError] = useState<string | null>('')

  const addFrePolicyToPaymaster = useCallback(
    async (freAddress: string, { authToken, paymasterKey }) => {
      try {
        setFrePolicyError('')

        const payload = {
          name: `FixedRateExchange`,
          address: freAddress,
          abi: JSON.stringify(FIXED_RATE_EXCHNGE_ABI),
          whitelistedMethods: WHITELISTED_METHODS_FRE_CONTRACT
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setFrePolicyError(error.message)
          }
        } else {
          setFrePolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    frePolicyError,
    addFrePolicyToPaymaster
  }
}

export function useDispPolicyToPaymasterApi() {
  const [dispPolicyError, setDispPolicyError] = useState<string | null>('')

  const addDispPolicyToPaymaster = useCallback(
    async (dispAddress: string, { authToken, paymasterKey }) => {
      try {
        setDispPolicyError('')
        const payload = {
          name: `DispenserContract`,
          address: dispAddress,
          abi: JSON.stringify(DISPENSER_ABI),
          whitelistedMethods: WHITELISTED_METHODS_DISP_CONTRACT
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setDispPolicyError(error.message)
          }
        } else {
          setDispPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    dispPolicyError,
    addDispPolicyToPaymaster
  }
}

export function useErcFactoryPolicyToPaymasterApi() {
  const [ercFactoryPolicyError, setErcFactoryPolicyError] = useState<
    string | null
  >('')

  const addErcFactoryPolicyToPaymaster = useCallback(
    async (ercFactoryAddress: string, { authToken, paymasterKey }) => {
      try {
        setErcFactoryPolicyError('')

        const payload = {
          name: `Erc721Factory`,
          address: ercFactoryAddress,
          abi: JSON.stringify(ERC721_FACTORY_ABI),
          whitelistedMethods: WHITELISTED_METHODS_ERC721_FACTORY_CONTRACT
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setErcFactoryPolicyError(error.message)
          }
        } else {
          setErcFactoryPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    ercFactoryPolicyError,
    addErcFactoryPolicyToPaymaster
  }
}

export function useEcdsaPolicyToPaymasterApi() {
  const [ecdsaPolicyError, setEcdsaPolicyError] = useState<string | null>('')

  const addEcdsaPolicyToPaymaster = useCallback(
    async (ecdsaContractAddress: string, { authToken, paymasterKey }) => {
      try {
        setEcdsaPolicyError('')

        const payload = {
          name: `ECDSA`,
          address: ecdsaContractAddress,
          abi: JSON.stringify(ECDSA_ABI),
          whitelistedMethods: WHITELISTED_METHODS_ECDSA
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setEcdsaPolicyError(error.message)
          }
        } else {
          setEcdsaPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    ecdsaPolicyError,
    addEcdsaPolicyToPaymaster
  }
}

export function useSvmPolicyToPaymasterApi() {
  const [userSVMPolicyError, setUserSVMPolicyError] = useState<string | null>(
    ''
  )
  const [adminSVMPolicyError, setAdminSVMPolicyError] = useState<string | null>(
    ''
  )

  const addUserSVMPolicyToPaymaster = useCallback(
    async (userAddress: string, { authToken, paymasterKey }) => {
      try {
        setUserSVMPolicyError('')

        const payload = {
          name: `User SVM`,
          address: userAddress,
          abi: JSON.stringify(USER_SVM_ABI),
          whitelistedMethods: WHITELISTED_METHODS_USER_SVM
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setUserSVMPolicyError(error.message)
          }
        } else {
          setUserSVMPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  const addAdminSVMPolicyToPaymaster = useCallback(
    async (adminAddress: string, { authToken, paymasterKey }) => {
      try {
        setAdminSVMPolicyError('')

        const payload = {
          name: `Admin SVM`,
          address: adminAddress,
          abi: JSON.stringify(ADMIN_SVM_ABI),
          whitelistedMethods: WHITELISTED_METHODS_ADMIN_SVM
        }

        await axios.post<ApiResponse<any>>(addPolicyToPaymasterUrl, payload, {
          headers: {
            authToken,
            apiKey: paymasterKey
          }
        })
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.message !== ERROR_MESSAGES.CONTRACT_ALREADY_EXISTS) {
            setAdminSVMPolicyError(error.message)
          }
        } else {
          setAdminSVMPolicyError(ERROR_MESSAGES.UNEXPECTED_ERROR)
        }
      }
    },
    []
  )

  return {
    userSVMPolicyError,
    adminSVMPolicyError,
    addUserSVMPolicyToPaymaster,
    addAdminSVMPolicyToPaymaster
  }
}
