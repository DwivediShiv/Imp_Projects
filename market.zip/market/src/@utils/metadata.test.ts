import { checkIsExpired, getRemainingTimeout } from './metadata'
import BigNumber from 'bignumber.js'
import { falsyValues } from '../../.jest/__fixtures__/mockUtils'

const DATETIME_PURCHASED = new Date().getTime() / 1000
const ONE_HOUR = 60 * 60
const ONE_DAY = ONE_HOUR * 24

describe('metadata', () => {
  it('should return true when reaches the expiry date', () => {
    const oneDayAgo = DATETIME_PURCHASED - ONE_DAY
    expect(checkIsExpired(ONE_HOUR, oneDayAgo)).toBe(true)
  })

  it('should return false when the expiry date is not yet reached', () => {
    expect(checkIsExpired(ONE_DAY, DATETIME_PURCHASED)).toBe(false)

    const oneHourLater = DATETIME_PURCHASED + ONE_HOUR
    expect(checkIsExpired(ONE_HOUR, oneHourLater)).toBe(false)
  })

  it('should return false if timeout is not provided', () => {
    expect(checkIsExpired(undefined, DATETIME_PURCHASED)).toBe(false)
  })

  it('should return remaining timeout', () => {
    const BUFFER = 1
    expect(
      getRemainingTimeout(ONE_HOUR, DATETIME_PURCHASED) + BUFFER
    ).toBeGreaterThanOrEqual(ONE_HOUR)

    const remainingTime = new BigNumber(DATETIME_PURCHASED)
      .minus(500)
      .toNumber()
    expect(
      getRemainingTimeout(ONE_HOUR, remainingTime) + BUFFER
    ).toBeGreaterThanOrEqual(ONE_HOUR - 500)
  })

  it.each(falsyValues)('should return NaN if given %p', (input: any) => {
    expect(getRemainingTimeout(input, DATETIME_PURCHASED)).toBeNaN()
  })

  it('should return 9999999999 when timeout is 0', () => {
    expect(getRemainingTimeout(0, DATETIME_PURCHASED)).toEqual(9999999999)
  })
})
