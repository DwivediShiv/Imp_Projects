import { Signer, ethers } from 'ethers'
import { Transaction } from '@biconomy/core-types'
import {
  BiconomySmartAccountV2,
  BiconomySmartAccountV2Config,
  DEFAULT_ENTRYPOINT_ADDRESS
} from '@biconomy/account'
import {
  ApiResponse,
  BiconomySocialLoginImplOptions,
  ConnectorMetadataArgs,
  ISocialLoginProps,
  PaymasterBalanceForChain,
  SmartWalletBalanceForToken
} from '../../@types/SmartAccount'
import {
  getPaymasterBalance,
  getSessionKeyManagerVersion,
  getSmartWalletBalance,
  updateAbstractOrgDetails
} from '../smartWallet'
import { Bundler, IBundler } from '@biconomy/bundler'
import { TransactionManager } from '@utils/biconomy/transactionManager'
import { getPaymasterUrl, getBundlerUrl } from '@utils/biconomy/api'
import {
  CreateSessionDataParams,
  ECDSAOwnershipValidationModule,
  ModuleVersion,
  SessionKeyManagerModule
} from '@biconomy/modules'
import { OrgSessionDataStorage } from './OrgSessionDataStorage'
import { SessionLeafNode } from '@biconomy/modules/dist/src/interfaces/ISessionStorage'
import {
  ROLE_SUPERADMIN,
  ROLE_ADMIN,
  ROLE_USER
} from '@components/@shared/fancy/constants/RoleConstants'
import {
  clearInMemoryStorage,
  getAbstractDetails,
  getAccessToken,
  getPaymasterDetails,
  isLoggedIn
} from '@utils/auth'
import {
  CHAIN_NAMESPACES,
  ADAPTER_STATUS,
  IProvider,
  WALLET_ADAPTERS
} from '@web3auth/base'
import { Web3AuthNoModal } from '@web3auth/no-modal'
import {
  LANGUAGES,
  OPENLOGIN_NETWORK_TYPE,
  OpenloginAdapter
} from '@web3auth/openlogin-adapter'
import appConfig from 'app.config'
import {
  EthereumPrivateKeyProvider,
  EthereumPrivKeyProviderConfig
} from '@web3auth/ethereum-provider'
import { getBiconomyBundlerKey, getTechnicalNetworkName } from '@utils/network'
import { parseEther } from 'ethers/lib/utils.js'
import Router from 'next/router'
import { getSocialLoginParams } from '@utils/wallet'
import { fancyCheckIsTestnet } from '@hooks/useNetworkMetadata'
import { ACCOUNT_ABSTRACTION_PROVIDERS } from '@utils/constants'
import { AlchemySmartAccountClient } from '@alchemy/aa-alchemy'
import {
  accountLoupeActions,
  createMultiOwnerModularAccount,
  multiOwnerPluginActions,
  pluginManagerActions,
  sessionKeyPluginActions
} from '@alchemy/aa-accounts'
import { getPaymasterDetailsForUser } from '@utils/sdk'
import { Address, Hex, http } from 'viem'
import { createSmartAccountClient } from '@alchemy/aa-core'
import { getSponsorTransactionUrl } from '@utils/api'
import axios, { AxiosResponse } from 'axios'
import {
  getAlchemyCoreChainConfig,
  fancyGetAlchemyPaymasterAddress,
  getAlchemyRpcTransport
} from '@utils/alchemy/utils'
import { Web3AuthWalletClientSigner } from '@utils/alchemy/Web3AuthWalletClientSigner'
import { Web3AuthOptions } from '@web3auth/modal'

export class WagmiBiconomySocialLogin implements ISocialLoginProps {
  private readonly options: BiconomySocialLoginImplOptions
  private smartAccount: BiconomySmartAccountV2 | null = null
  private signer: Signer | null = null
  private skmModule: SessionKeyManagerModule | null = null
  private txnManager: TransactionManager | null = null
  private web3auth: Web3AuthNoModal | any
  private provider: IProvider
  private web3Provider: ethers.providers.Web3Provider
  private loginParams: ConnectorMetadataArgs
  private accountAbstractionProvider: string
  private alchemyClientSigner: any

  constructor(options: BiconomySocialLoginImplOptions) {
    this.options = options
  }

  private clearSessionCache() {
    localStorage.removeItem(`openlogin_store`)
    Object.keys(localStorage).forEach(function (key) {
      if (key.substring(0, 5) === 'wagmi') {
        localStorage.removeItem(key)
      }
    })
    this.web3auth.clearCache()
  }

  private async removePreviousSession(enableSession: boolean) {
    if (enableSession) return
    if (!enableSession && this.web3auth?.status === ADAPTER_STATUS.CONNECTED) {
      await this.logout()
      await this.initialize()
    }
    this.clearSessionCache()
  }

  async initialize(): Promise<void> {
    const { loginOptions } = this.options
    const infuraBaseUrl =
      appConfig?.infuraUrls[getTechnicalNetworkName(loginOptions.chainId)]?.url

    const chainConfig = {
      chainNamespace: CHAIN_NAMESPACES.EIP155,
      chainId: ethers.utils.hexValue(loginOptions.chainId),
      rpcTarget: `${infuraBaseUrl}${loginOptions.infuraProjectId}`
    }

    const privateKeyProvider = new EthereumPrivateKeyProvider({
      config: { chainConfig } as unknown as EthereumPrivKeyProviderConfig
    }) as any

    const openloginAdapter = new OpenloginAdapter({
      adapterSettings: {
        storageServerUrl: appConfig.socialLogin?.serverUrl,
        uxMode: 'popup'
      },
      loginSettings: {
        mfaLevel: 'none'
      },
      privateKeyProvider
    }) as any

    const web3AuthOptions: Web3AuthOptions = {
      clientId: loginOptions.clientId,
      chainConfig,
      web3AuthNetwork: loginOptions.network as OPENLOGIN_NETWORK_TYPE,
      // privateKeyProvider,
      uiConfig: {
        // uxMode: 'popup',
        appName: loginOptions.whiteLabelName,
        logoLight: loginOptions.whiteLabelLogo,
        logoDark: loginOptions.whiteLabelLogo,
        defaultLanguage: LANGUAGES.en,
        mode: 'dark'
      }
    }

    if (
      this.accountAbstractionProvider === ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY
    ) {
      const web3AuthCore = new Web3AuthNoModal(web3AuthOptions)
      web3AuthCore.configureAdapter(openloginAdapter)
      await web3AuthCore.init()
      this.web3auth = web3AuthCore
    } else {
      let web3AuthSigner = new Web3AuthWalletClientSigner(web3AuthOptions)
      web3AuthSigner.inner.configureAdapter(openloginAdapter)
      await web3AuthSigner.inner.init()
      // Handles reload page scenario:
      if (
        web3AuthSigner?.inner?.connected &&
        web3AuthSigner?.inner?.status === ADAPTER_STATUS.CONNECTED
      ) {
        web3AuthSigner = new Web3AuthWalletClientSigner({
          inner: web3AuthSigner.inner
        })
        await web3AuthSigner.authenticate({
          init: () => null,
          connect: () => null
        })
        await web3AuthSigner
          .getAuthDetails()
          .catch(() => console.error('Failed to reconnect on reload'))
      }

      this.alchemyClientSigner = web3AuthSigner
      this.web3auth = web3AuthSigner.inner
    }
  }

  async login(args: ConnectorMetadataArgs): Promise<void> {
    this.accountAbstractionProvider = args.accountAbstractionProvider
    this.loginParams = args
    if (
      this.smartAccount &&
      this.provider &&
      args.enableSession &&
      this.accountAbstractionProvider === ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY
    ) {
      await this.instantiateSessionKeyManagerModule(this.smartAccount)
      return
    } else {
      // kris: do alchemy session key manager module
    }

    await this.initialize()
    await this.removePreviousSession(args.enableSession)
    const web3Provider = await this.emailLogin(
      args.userMail,
      args.enableSession
    )
    if (web3Provider) {
      await this.setupSmartAccount(args)
    } else {
      console.error('Error occured while Social Login')
    }
  }

  async getMerkleTransactionData(
    sessionKeys: CreateSessionDataParams[]
  ): Promise<string> {
    const mockAddress = 'mock'
    const mockSkmModule = await SessionKeyManagerModule.create({
      smartAccountAddress: 'mock',
      entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
      version: getSessionKeyManagerVersion() as ModuleVersion
    })

    let transactionData: any
    if (sessionKeys.length !== 0) {
      mockSkmModule.merkleTree.resetTree()
      const { data } = await mockSkmModule.createSessionData(sessionKeys)
      transactionData = data
    }
    localStorage.removeItem(`${mockAddress}_sessions`)
    mockSkmModule.merkleTree.resetTree()
    return transactionData
  }

  async getBytecodeHash(contractAddr: string): Promise<string | null> {
    const bytecode = await this.web3Provider.getCode(contractAddr)
    const byteCodeHash = ethers.utils.keccak256(bytecode)
    return byteCodeHash
  }

  private async instantiateSessionKeyManagerModule(
    smartAccount: BiconomySmartAccountV2
  ) {
    const { svmDetails, orgId, userRole, paymasterSetupStatus } =
      this.loginParams
    const smartAccountAddress = await smartAccount?.getAccountAddress()
    const skmModule = await SessionKeyManagerModule.create({
      smartAccountAddress,
      entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
      version: getSessionKeyManagerVersion() as ModuleVersion
    })
    skmModule.merkleTree.resetTree()

    skmModule.sessionStorageClient = new OrgSessionDataStorage(orgId)

    const sessionKeys: SessionLeafNode[] =
      await skmModule.sessionStorageClient.getAllSessionData()

    let existingSessionKeys: CreateSessionDataParams[]
    if (sessionKeys.length !== 0) {
      existingSessionKeys = (
        skmModule.sessionStorageClient as OrgSessionDataStorage
      ).getCleanedSessionData(sessionKeys)
      await skmModule.createSessionData(existingSessionKeys)
    }

    this.skmModule = skmModule

    let isModuleEnabled: boolean = null
    try {
      isModuleEnabled = await smartAccount?.isModuleEnabled(
        skmModule.getAddress()
      )
    } catch {
      isModuleEnabled = false
    }

    if (!isModuleEnabled) {
      const enableModuleTrx = await smartAccount.getEnableModuleData(
        skmModule.getAddress()
      )
      await this.txnManager.initiateBiconomyTransaction('', [enableModuleTrx])
    }

    if (userRole !== ROLE_SUPERADMIN) {
      smartAccount?.setActiveValidationModule(skmModule)
    }

    /* When initiating Smart account by Super Admin - initForSmartAccount(userSVM) should get called */
    const chainId = await this.getSigner().getChainId()
    if (
      userRole === ROLE_SUPERADMIN &&
      (svmDetails === null ||
        Object.keys(svmDetails).length === 0 ||
        !svmDetails?.userSvmChains?.includes(chainId.toString())) &&
      paymasterSetupStatus
    ) {
      console.log('Initializing Svm for Smart Account')
      const userValidationAddress =
        appConfig.validationSmartContracts[getTechnicalNetworkName(chainId)]
          ?.orgUser
      const adminValidationAddress =
        appConfig.validationSmartContracts[getTechnicalNetworkName(chainId)]
          ?.orgAdmin

      try {
        // eslint-disable-next-line testing-library/no-await-sync-query
        const baseTokenBytecodeHash = await this.getBytecodeHash(
          appConfig?.stableCoin[getTechnicalNetworkName(chainId)]?.address
        )
        console.log('basetoken bytecodehash fetched:', baseTokenBytecodeHash)
        const moduleRegistryAbi =
          'function initForSmartAccount(bytes32 baseCurrencyBytecodeHash)'
        const initInterface = new ethers.utils.Interface([moduleRegistryAbi])
        const smartAccInitData = initInterface.encodeFunctionData(
          'initForSmartAccount',
          [baseTokenBytecodeHash]
        )

        const userTx: Transaction = {
          to: userValidationAddress,
          value: parseEther('0'),
          data: smartAccInitData
        }
        const adminTx: Transaction = {
          to: adminValidationAddress,
          value: parseEther('0'),
          data: smartAccInitData
        }
        const svmInitTransactions = [userTx, adminTx]
        console.log('svmInitTransactions:', svmInitTransactions)
        const transactionHash =
          await this.txnManager.initiateBiconomyTransaction(
            '',
            svmInitTransactions
          )
        console.log(
          'transaction hash after initForSmartAccount transaction done:',
          transactionHash
        )

        if (transactionHash) {
          let initChains: Array<string>
          if (!svmDetails?.userSvmChains) {
            initChains = [chainId.toString()]
          } else {
            initChains = [chainId.toString(), ...svmDetails.userSvmChains]
          }

          const svmDetailsData = {
            svmDetails: { userSvmChains: initChains }
          }
          await updateAbstractOrgDetails(orgId, svmDetailsData)
        }
      } catch (e) {
        console.error('[Init SmartAccout error: ]', e)
      }
    }
    this.smartAccount = smartAccount
    return smartAccount
  }

  private async setupSmartAccount(args: ConnectorMetadataArgs) {
    if (this.web3auth && this.web3auth.provider) {
      const txnManager = new TransactionManager()
      txnManager.setAuthProvider(this.provider)

      const provider = new ethers.providers.Web3Provider(
        txnManager.sendTransaction.bind(
          txnManager
        ) as ethers.providers.JsonRpcFetchFunc
      )
      this.web3Provider = provider
      const chain = await provider?.getSigner()?.getChainId()

      if (args.userRole === ROLE_ADMIN) {
        this.accountAbstractionProvider ===
          ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY &&
          txnManager.setSessionValidationModule(
            appConfig.validationSmartContracts[getTechnicalNetworkName(chain)]
              ?.orgAdmin
          )
        // kris alchemy: to add validate for admin?
      } else if (args.userRole === ROLE_USER) {
        this.accountAbstractionProvider ===
          ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY &&
          txnManager.setSessionValidationModule(
            appConfig.validationSmartContracts[getTechnicalNetworkName(chain)]
              ?.orgUser
          )
        // kris alchemy: to add validate for user?
      }

      const isTestnet = fancyCheckIsTestnet(chain)
      this.signer = provider.getSigner()

      try {
        const { chainId } = this.options.loginOptions
        if (
          this.accountAbstractionProvider ===
          ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY
        ) {
          const ecdsaModule = await ECDSAOwnershipValidationModule.create({
            signer: this.signer,
            entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
            //          moduleAddress: DEFAULT_ECDSA_OWNERSHIP_MODULE,
            version: 'V1_0_0'
          })

          const bundler: IBundler = new Bundler({
            bundlerUrl: getBundlerUrl(
              chainId,
              getBiconomyBundlerKey(isTestnet)
            ),
            chainId: Number(chainId),
            entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
            userOpReceiptIntervals: {
              [chainId]: 3000
            }
          })

          const smartAccountConfig: BiconomySmartAccountV2Config = {
            chainId: Number(chainId),
            defaultValidationModule: ecdsaModule,
            entryPointAddress: DEFAULT_ENTRYPOINT_ADDRESS,
            provider,
            bundler
          }

          if (args.orgSmartAccount) {
            smartAccountConfig.accountAddress = args.orgSmartAccount
          }
          const smartAccount = await BiconomySmartAccountV2.create(
            smartAccountConfig
          )
          await smartAccount.init()
          txnManager.setSmartAccount(smartAccount)
          txnManager.setWeb3Provider(provider)
          this.txnManager = txnManager
          const activeSmartAccount =
            await this.instantiateSessionKeyManagerModule(smartAccount)

          if (!args.orgSmartAccount && args.userRole === ROLE_SUPERADMIN) {
            const smartAccountData = {
              accountAddress: await activeSmartAccount?.getAccountAddress()
            }
            await updateAbstractOrgDetails(args.orgId, smartAccountData)
          }
          this.smartAccount = activeSmartAccount
          this.txnManager.setSmartAccount(activeSmartAccount)
          return activeSmartAccount
        } else {
          const getPaymaster = await getPaymasterDetailsForUser()
          let socialDetails
          if (getPaymaster) {
            socialDetails = (await getPaymasterDetails())?.socialDetails
          } else {
            await this.logout()
            clearInMemoryStorage()
            Router.push('/login')
            throw new Error('Unable to get paymaster social details!')
          }

          const rpcTransport = http(
            getAlchemyRpcTransport(chainId) + socialDetails?.apiKey
          )
          const client = createSmartAccountClient({
            opts: {
              txMaxRetries: 150,
              txRetryIntervalMs: 5000,
              txRetryMultiplier: 1
            },
            transport: rpcTransport,
            chain: getAlchemyCoreChainConfig(chainId),
            account: await createMultiOwnerModularAccount({
              transport: rpcTransport,
              chain: getAlchemyCoreChainConfig(chainId),
              signer: this.alchemyClientSigner,
              accountAddress:
                args.orgSmartAccount && args.userRole !== ROLE_SUPERADMIN
                  ? (args.orgSmartAccount as Address)
                  : undefined
            }),
            paymasterAndData: {
              dummyPaymasterAndData: () => {
                return `${fancyGetAlchemyPaymasterAddress(chainId)}0x` as Hex
              },
              paymasterAndData: async (userop, opts) => {
                try {
                  const [
                    initCode,
                    nonce,
                    callData,
                    maxFeePerGas,
                    maxPriorityFeePerGas
                  ] = await Promise.all([
                    (userop as any)?.initCode,
                    userop?.nonce,
                    userop?.callData,
                    userop?.maxFeePerGas,
                    userop?.maxPriorityFeePerGas
                  ])
                  const dummySignature =
                    await opts.client.account.getDummySignature()
                  const token = await getAccessToken()
                  const payload = {
                    authService: 'jwt',
                    chainId: chain,
                    entryPoint: opts.client.account.getEntryPoint().address,
                    dummySignature,
                    userOperation: {
                      ...userop,
                      initCode,
                      callData: ethers.utils.hexlify(callData),
                      maxFeePerGas: ethers.utils.hexlify(maxFeePerGas),
                      maxPriorityFeePerGas:
                        ethers.utils.hexlify(maxPriorityFeePerGas),
                      nonce: ethers.utils.hexlify(nonce)
                    }
                  }

                  const apiResponse: AxiosResponse = await axios.post<
                    ApiResponse<any>
                  >(getSponsorTransactionUrl(), payload, {
                    headers: {
                      'Content-Type': 'application/json',
                      Authorization: `Bearer ${token}`
                    }
                  })
                  if (apiResponse?.status === 200) {
                    const { result } = apiResponse.data.sponsorData

                    return {
                      ...userop,
                      ...result
                    }
                  }

                  return userop
                } catch (e) {
                  console.error('[paymasterAndData] Sponsorship Error=', e)
                  return userop
                }
              }
            }
          })
            .extend(sessionKeyPluginActions)
            .extend(pluginManagerActions)
            .extend(accountLoupeActions)
            .extend(multiOwnerPluginActions)

          const activeSmartAccount = client.account.address
          if (!args.orgSmartAccount && args.userRole === ROLE_SUPERADMIN) {
            const smartAccountData = {
              accountAddress: activeSmartAccount
            }
            await updateAbstractOrgDetails(args.orgId, smartAccountData)
          }

          txnManager.setSmartAccount(client as any)
          txnManager.setWeb3Provider(provider)
          txnManager.setAccountAbstractionProvider(
            this.accountAbstractionProvider
          )
          this.txnManager = txnManager
          this.smartAccount = client as any

          return client
        }
      } catch (e) {
        if (!isLoggedIn()) {
          await this.logout()
          clearInMemoryStorage()
        }
        console.error('error setting up smart account: ', e)
      }
    }
  }

  async emailLogin(
    email: string,
    enableExistingSession: boolean
  ): Promise<IProvider | null> {
    if (!this.web3auth) {
      console.error('web3auth not initialized yet')
      return null
    }
    try {
      if (
        this.web3auth.connected &&
        this.web3auth?.status === ADAPTER_STATUS.CONNECTED
      ) {
        // Logout user if Already existing user session found in case of new login
        if (!enableExistingSession) {
          await this.logout()
          clearInMemoryStorage()
          Router.push('/login')
          throw Error('Pervious Session found on new Login')
        }

        this.provider = this.web3auth.provider as IProvider
        return this.provider
      }

      // Logout user if Web3Auth session terminated abruptly
      if (enableExistingSession) {
        await this.logout()
        clearInMemoryStorage()
        Router.push('/login')
        throw Error('Web3Auth session terminated abruptly')
      }

      if (
        this.accountAbstractionProvider ===
        ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY
      ) {
        const web3authProvider = await this.web3auth.connectTo(
          WALLET_ADAPTERS.OPENLOGIN,
          {
            loginProvider: 'email_passwordless',
            login_hint: email
          }
        )

        if (!web3authProvider) {
          console.error('web3authProvider is not set')
          return null
        }
        this.provider = web3authProvider as IProvider
      } else {
        await this.alchemyClientSigner.authenticate({
          init: () => null,
          connect: async () => {
            const web3authProvider = await this.web3auth.connectTo(
              WALLET_ADAPTERS.OPENLOGIN,
              {
                loginProvider: 'email_passwordless',
                login_hint: email
              }
            )
            if (!web3authProvider) {
              console.error('web3authProvider is not set')
              return null
            }
            this.provider = web3authProvider as IProvider
          }
        })
        this.alchemyClientSigner.inner = this.web3auth
      }
      return this.provider
    } catch (error) {
      console.error(error)
      return null
    }
  }

  async logout(): Promise<void> {
    if (!this.web3auth) {
      console.error('web3auth not initialized yet')
      return
    }
    try {
      await this.web3auth.logout()
      this.web3auth.clearCache()
      this.provider = null
    } catch (e) {
      console.error('Error while Social Login logout: ', e)
    }
  }

  newInstance(getFreshInstance?: boolean): ISocialLoginProps {
    const params = {
      loginOptions: getSocialLoginParams()
    }
    const instance = new WagmiBiconomySocialLogin(this.options || params)
    if (getFreshInstance) {
      return instance
    }
    instance.web3auth = this.web3auth
    instance.provider = this.provider
    instance.smartAccount = this.smartAccount
    instance.signer = this.signer
    instance.skmModule = this.skmModule
    instance.txnManager = this.txnManager
    instance.web3Provider = this.web3Provider
    instance.accountAbstractionProvider = this.accountAbstractionProvider
    instance.getSmartAccountAddress = this.getSmartAccountAddress
    return instance
  }

  clearInstance(): ISocialLoginProps {
    const instance = new WagmiBiconomySocialLogin(this.options)
    return instance
  }

  getWeb3auth(): Web3AuthNoModal | null {
    return this.web3auth
  }

  getSmartAccount(): BiconomySmartAccountV2 | null {
    return this.smartAccount
  }

  getSmartAccountAddress(): string | null {
    if (
      this.accountAbstractionProvider === ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY
    ) {
      return this.smartAccount.accountAddress
    } else if (
      this.accountAbstractionProvider === ACCOUNT_ABSTRACTION_PROVIDERS.ALCHEMY
    ) {
      return (this.smartAccount as unknown as AlchemySmartAccountClient)
        ?.account?.address
    }

    return null
  }

  getTransactionManager(): TransactionManager | null {
    return this.txnManager
  }

  getSessionKeyManagerModule(): SessionKeyManagerModule | null {
    return this.skmModule
  }

  getSigner(): Signer | null {
    return this.signer
  }

  getAccountAbstractionProvider(): string | null {
    return this.accountAbstractionProvider
  }

  // kris alchemy: THIS FUNCTION SEEMS NOT CALLED ANYWHERE, marked as removable
  async getSmartAccountBalance(): Promise<SmartWalletBalanceForToken | null> {
    switch (this.accountAbstractionProvider) {
      case ACCOUNT_ABSTRACTION_PROVIDERS.BICONOMY: {
        if (this.smartAccount) {
          const { chainId } = this.options.loginOptions
          const balance = await getSmartWalletBalance(
            chainId,
            this.smartAccount
          )
          return balance
        }
        break
      }
      case ACCOUNT_ABSTRACTION_PROVIDERS.ALCHEMY: {
        return null
      }
    }
  }

  async getSdkPayMasterBalance(): Promise<PaymasterBalanceForChain | null> {
    if (
      this.smartAccount &&
      this.signer &&
      this.accountAbstractionProvider !== ACCOUNT_ABSTRACTION_PROVIDERS.ALCHEMY // Alchemy doesn't have balance so will hide when null
    ) {
      const balance = await getPaymasterBalance(this.signer)
      return balance
    }
  }

  async getPrivateKey(): Promise<string | null> {
    if (this.provider) {
      const privateKey: string = await this.provider.request({
        method: 'eth_private_key'
      })
      return privateKey
    }
    return null
  }
}
