import { PayMasterData } from 'src/@types/SmartAccount'
import { checkPayMasterKey } from '@utils/api'
import axios, { AxiosResponse } from 'axios'
import { ethers } from 'ethers'
import { SetStateAction } from 'react'
import { createModularAccountAlchemyClient } from '@alchemy/aa-alchemy'
import { LocalAccountSigner } from '@alchemy/aa-core'
import appConfig from 'app.config'
import { randomBytes } from 'crypto'
import { getAlchemyCoreChainConfig } from '@utils/alchemy/utils'

async function validateBiconomyPaymasterKey(
  authToken: string,
  paymasterApiKey?: string,
  ownerEOA?: string,
  setOrgProfileError?: (value: SetStateAction<string>) => void
): Promise<any> {
  try {
    setOrgProfileError && setOrgProfileError('')
    const response: AxiosResponse = await axios({
      method: 'GET',
      url: checkPayMasterKey(),
      headers: {
        authToken
      }
    })
    if (response.status !== 200) {
      setOrgProfileError && setOrgProfileError('Auth error')
      return false
    } else {
      const isMatching = response?.data?.data?.find(
        (obj) => paymasterApiKey === obj.apiKey
      )
      const isvalidEoa = ethers.utils.isAddress(ownerEOA)
      if (isMatching && isvalidEoa) {
        return true
      } else if (!isMatching) {
        setOrgProfileError && setOrgProfileError('key error')
        return false
      } else if (!isvalidEoa) {
        setOrgProfileError && setOrgProfileError('wallet error')
        return false
      }
    }
  } catch (error) {
    setOrgProfileError && setOrgProfileError('Auth Token error')
    console.error('Paymaster Api Validation error:', error)
  }
}

async function checkAlchemyCredentialValidity(
  apiKey: string,
  policyId: string
) {
  const dummySigner = LocalAccountSigner.privateKeyToAccountSigner(
    `0x${randomBytes(32).toString('hex')}`
  )
  const dummySignerAddress = await dummySigner.getAddress()
  const dummyAccountClient = await createModularAccountAlchemyClient({
    apiKey,
    chain: getAlchemyCoreChainConfig(appConfig.socialLogin.chainId),
    signer: dummySigner,
    gasManagerConfig: {
      policyId
    }
  })

  const isEligible = await dummyAccountClient.checkGasSponsorshipEligibility({
    uo: [
      {
        data: '0x',
        target: dummySignerAddress,
        value: 0n
      }
    ],
    account: dummyAccountClient.account
  })

  console.log(`Credential input is ${isEligible ? 'valid' : 'invalid'}.`)

  return isEligible
}

async function validateAlchemyCredentials(
  apiKey: string,
  policyId: string,
  setOrgProfileError?: (value: SetStateAction<string>) => void
) {
  try {
    setOrgProfileError && setOrgProfileError('')
    return await checkAlchemyCredentialValidity(apiKey, policyId)
  } catch (error) {
    setOrgProfileError && setOrgProfileError('Auth Token error')
    console.error('Alchemy Api Validation error:', error)
  }
}

export async function validateAccountAbstractionCredentials(
  socialDetails: PayMasterData,
  setOrgProfileError?: (value: SetStateAction<string>) => void
): Promise<any> {
  const apiKey = socialDetails?.apiKey
  const policyId = socialDetails?.policyId

  const authToken = socialDetails?.authToken
  const paymasterApiKey = socialDetails?.paymasterKey
  const ownerEOA = socialDetails?.ownerEOA

  if (authToken) {
    return await validateBiconomyPaymasterKey(
      authToken,
      paymasterApiKey,
      ownerEOA,
      setOrgProfileError
    )
  } else if (apiKey && policyId) {
    return await validateAlchemyCredentials(
      apiKey,
      policyId,
      setOrgProfileError
    )
  }
}
