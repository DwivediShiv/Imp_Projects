import { Address, Chain, Connector, ConnectorData } from 'wagmi'
import { IProvider } from '@web3auth/base'
import { getAddress } from 'ethers/lib/utils'
import { WagmiBiconomySocialLogin } from './WagmiBiconomySocialLogin'
import { ConnectArgs } from 'wagmi/dist/actions'
import { ConnectorMetadataArgs } from '../../@types/SmartAccount'
import { ethers } from 'ethers'
import { normalizeChainId } from '../smartWallet'
import { Web3AuthNoModal } from '@web3auth/no-modal'

export const CUSTOM_CONNECTOR_ID = 'wagmi-social-login'
export const CUSTOM_CONNECTOR_NAME = 'wagmi-social-login'

export interface Options {
  id?: string
  name?: string
  biconomySocialLogin: WagmiBiconomySocialLogin
}

export class WagmiBiconomyConnector extends Connector<
  IProvider,
  Options,
  ethers.Signer
> {
  ready = true
  readonly id: string
  readonly name: string

  protected provider: IProvider | null = null
  private biconomySocialLogin: WagmiBiconomySocialLogin
  private metadataArgs: ConnectorMetadataArgs | null = null

  constructor({ chains, options }: { chains?: Chain[]; options: Options }) {
    super({ chains, options })
    this.biconomySocialLogin = options.biconomySocialLogin
    this.id = options.id || CUSTOM_CONNECTOR_ID
    this.name = options.name || CUSTOM_CONNECTOR_NAME
  }

  setMetadata(args: ConnectorMetadataArgs) {
    this.metadataArgs = args
  }

  async connect(_args: ConnectArgs): Promise<Required<ConnectorData>> {
    try {
      if (this.biconomySocialLogin && this.metadataArgs) {
        await this.biconomySocialLogin.login(this.metadataArgs)
      }
      const [account, connectedChainId] = await Promise.all([
        this.getAccount(),
        this.getChainId()
      ])

      const provider = await this.getProvider()
      return {
        account,
        chain: {
          id: connectedChainId,
          unsupported: false
        },
        provider
      }
    } catch (error) {
      this.onDisconnect()
      console.error('Error occured while connection to Wagmi')
    }
  }

  async disconnect(): Promise<void> {
    try {
      if (this.biconomySocialLogin) {
        await this.biconomySocialLogin.logout()
        this.biconomySocialLogin =
          this.biconomySocialLogin.clearInstance() as WagmiBiconomySocialLogin
      }
    } catch (e) {
      console.error('Error occured while Disconnecting Abstract wallet: ', e)
    }
  }

  async getAccount(): Promise<Address> {
    const provider = await this.getProvider()
    if (provider) {
      const account = await this.biconomySocialLogin?.getSigner()?.getAddress()
      return getAddress(account)
    }
  }

  async getChainId(): Promise<number> {
    const provider = await this.getProvider()
    if (provider) {
      const chainId = await this.biconomySocialLogin?.getSigner()?.getChainId()
      if (chainId) {
        return normalizeChainId(chainId)
      }
    }
  }

  async getProvider(): Promise<IProvider> {
    if (this.provider) {
      return this.provider
    }
    this.provider = this.getWeb3AuthSdk()?.provider as IProvider
    return this.provider
  }

  async isAuthorized() {
    try {
      const account = await this.getAccount()
      return !!account
    } catch {
      return false
    }
  }

  private getWeb3AuthSdk(): Web3AuthNoModal | null {
    if (this.biconomySocialLogin) {
      return this.biconomySocialLogin.getWeb3auth()
    }
    return null
  }

  protected onAccountsChanged = (_accounts: string[]): void => {
    // To be Implemented
  }

  protected isChainUnsupported(chainId: number): boolean {
    // To be Implemented
    return true
  }

  protected onChainChanged = (chainId: string | number): void => {
    // To be Implemented
  }

  protected onDisconnect(): void {
    this.emit('disconnect')
  }

  public async getSigner(_config?: {
    chainId?: number
  }): Promise<ethers.Signer> {
    const signer = this.biconomySocialLogin?.getSigner()
    if (signer) {
      return Promise.resolve(signer)
    }
  }
}
