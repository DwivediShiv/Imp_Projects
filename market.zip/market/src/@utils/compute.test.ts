import { ordersDataWithDDOs } from '../../.jest/__fixtures__/compute'
import { getUserProfileDetailOfOrders } from './compute'

describe('getUserProfileDetailOfOrders', () => {
  it('should return unique wallet IDs', () => {
    const expectedWalletIDs: string[] = [
      '0xAe28AA182BF02021914F192EAbE3A036520C9273',
      '0x4b08d64D6e7E5F81F76E96203C2796Cf83006BB0'
    ]
    const returnedValue = getUserProfileDetailOfOrders(ordersDataWithDDOs)
    expect(returnedValue).toEqual(expectedWalletIDs)
  })

  it('should return empty array if no orders given', () => {
    const emptyWalletIDs: string[] = []
    const returnedValue = getUserProfileDetailOfOrders([])
    expect(returnedValue).toEqual(emptyWalletIDs)
  })
})
