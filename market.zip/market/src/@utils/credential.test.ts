import {
  mockedRawCredentialTable,
  mockedCountryList,
  mockedCredentialTableWithLabel
} from '../../.jest/__fixtures__/credential'
import { getCredentialLabel } from './credential'

describe('getCredentialLabel', () => {
  it('should return corresponding country name for country item in allow / deny list', () => {
    mockedRawCredentialTable.forEach((credential, index) => {
      credential.label = getCredentialLabel(
        credential.value,
        credential.type,
        mockedCountryList
      )
      expect(credential).toEqual(mockedCredentialTableWithLabel[index])
    })
  })

  it('should return original value as label if falsy country list is passed', () => {
    const falsyCountryList = [undefined, null, []]
    falsyCountryList.forEach((falsyCountry) => {
      mockedRawCredentialTable.forEach((credential) => {
        credential.label = getCredentialLabel(
          credential.value,
          credential.type,
          falsyCountry
        )
        expect(credential.label).toEqual(credential.value)
      })
    })
  })

  it('should return original value as label if credential type is null or undefined', () => {
    const value = 'test value'
    const falsyCredentialTypes = [undefined, null]

    falsyCredentialTypes.forEach((falsyType) => {
      const label = getCredentialLabel(value, falsyType, mockedCountryList)
      expect(label).toEqual(value)
    })
  })

  it('should return original value as label if value provided is invalid', () => {
    const falsyValues = [undefined, null, '']
    const type = 'country'

    falsyValues.forEach((falsyValue) => {
      const label = getCredentialLabel(falsyValue, type, mockedCountryList)
      expect(label).toBeUndefined()
    })
  })
})
