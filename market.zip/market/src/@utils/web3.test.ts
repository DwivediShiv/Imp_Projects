import { accountTruncate } from './wallet'
import { falsyValues } from '../../.jest/__fixtures__/mockUtils'

const mockedWallets = [
  ['0x9984…84e0', '0x99840df5cb42fabe0feb8811aaa4bc99ca6c84e0'],
  ['0x7B97…4A02', '0x7B97450975E89Ce1dB2EC1FEa1F82E234a5d4A02'],
  ['0xd1Cd…E8Ec', '0xd1CdD6182f86456712e49Eea0C03aF5A1375E8Ec']
]

describe.skip('accountTruncate', () => {
  it.each(mockedWallets)('should return %p if given %p', (expected, input) => {
    expect(accountTruncate(input)).toEqual(expected)
  })

  it('should return undefined if given falsy value', () => {
    falsyValues.forEach((value: any) => {
      expect(accountTruncate(value)).toBeUndefined()
    })
  })

  it('should return undefined if invalid wallet address is given', () => {
    expect(accountTruncate('0x123')).toBe('…0x123')
  })
})
