const bigDefaultImages =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMEAAAAgCAYAAACrWhy7AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAfBSURBVHgB7VxbWts4FD5HCfM6eR0SG88Kyg7KrABYAbAC6AoCK4CuoHQF0BUQVtCwgppc5uOt6dt8TSzNf2Q7OGnI1YYU9H9fEsuypKPLuUoOUwZBLdjRRm8TU4UKgiLVCDthgxwc1gQsX0EQVKK+uZKUMeZOMfWoAGhDFUW8aww1S3/wURiGhbTj4LAwvNrWlV/zT+mZUENbXnXrhhwc1gE1mEB+desbPTOECcT8IgeHF4ZSpHc0mS/0zGA2d9b/cHB4YSj7VZAPMAO9Ih1wB4d5ocjB4Y3DMYHDm0eZloRX9Q6ZOXgqX5XVJUKgITk4rDmW0gSe5+0xqfpT+Yb4XfRTX5CDw2+A5TSBFofWNFqd1umkbAm7sqI65YRa1b8wpC673bCZ3vM2wYjQRK1u69mZTUK7kdG7uEwce3Pb7rYv6Q1ALABIuV773/Y1vRLk6hNg5zmQTTc2+oDyBKJXisz56D0+V5F69omobfp1hJSvDNMPw+qzMIAmfjNRLiaGgONXFdpe2ieYiP9yr9GiA40jG3oigeXckSxE3G6ED48+hz33hD0PuR73R0QzlcsUpveEWWlAQXqGKU2D9lAP9KEm1ehMON8kz0V9faoG/Hfr4T58it5ptATVYJs2EB6OaFv2SYwxoWiRtEyazrZpaSNRwHF+aaPUGKkzCCq6rw8l5Dyr/DhNgRfsUYma2fpE2qON62WOtUh7oGVPaJl0TmwkH3TIOKD9Rrat4fhB46gNdV20b5mrJpBFKSZSLCHzhVH8ITKmLoPITIelSJ2leVY6G3MuC0BrokFfX9nJT6CMPoyiaCdND7AoIjL1bBrlP0V98wkNPTnxUR91MI8w3zhkAUldQovUpftmZGdcs94DI90MdLygxbeCufd1YPRekj7OHmGxtBr9CZ8DWycksZQfo2tPJwxArHbHy9u+kTm24wMTLlse7W5jvE6GYymmLGhalgHgC97IsrJtoV3/L/9kJB9tp7TKeMszRI/7RX7VPx/OJZN9XpicCsTcchsDi0EkqwYNmYBEiFR96QCVNtSZcKsdQGsKmdyJbrfDa6+6dRwNrFk0XIjx4T9I54j/Dh/a9l6t5lMysSfz1i99AmP9M22B22iYXYjTwHXFfBR22g1JYVIpMtY/amQqCjude0sbmAZJddBO057XA/Mcj1VaaXdbR8n1pbfpD7Wi3MhKfilvxsqjb5V2p7U/fGbT35UFKXNWLqsLjN83JE9l4dv5Y1pKiKGeOgTUx1Y3tH4atF4zUkYY7iLOhxAxfNfpxr4k2rxGme/JOc6USU5KmbnEuiNoZxmbUyoIc2sCMMCF2L/yAcliC5/FaWKoNytVywMK43xzTwXAMJ+BkJ2sFoAJJgzXyy5eFonK/I4WQziNAWIC5tpZF7Nq6MBDnTcoFhqUpW+khDY/hk2Y0q9tMDdHk3QbcRSkadE+3ubWlZzHYj0hajdWPotY4nMTmnIvubWjBjBTloAh2lashm2FcSCjkmrl2J94HBvLdMzD/g5is21kHqARmkZToT7IQhb8pAiISDJ0771cJ8RfxirVLLoIZ0KYLCqNLvhJwGBXzLR8jiqQtrQoNCYYklJMsg9PmQvJpFrGlDQmVo6PT2UeLOrvU/PN6PEShKC3KIrNtlj7mrrSbLVYMvYLReZEuAjzxFqIZwuDKYj0xKMwcf8R4NDjfTFiNcSaAH5bL+qPFpw1l3lgKZ9AOFtMIfmAwHwjQQsinjBu+tVgSAcm9T2+RlW6jhk1ud6lJSDOMiYljBLNlyJrs8q7EsgfmiNiXsAcadIKQPntVJrGv9CGOpaobKxGGAoGZr1w32y/GNLWqINfxm0RMH0BbcN5EBMa49VMBQYCDtf4eZ+OV23sFDGea+J5Sn0oeQ7r6xh+TqFRwGVjOb3EFBJOZXphwIY80iVzA3MAERIjEZfPne79ZZqPKMWFhDWtuQAprdmadEsBvsd+VKZzr+Z/x6zGk/vT2tCnQ1rKZNsSWxzD0yuVeZ9WABZCUxxs1BnC8QzgMH5oJ4teojjIq6fvZ6DvS/UN4/MRGue43b2fSSsYHe35Q0FQYvhSYCSJ4sEfu0DeN9AsUp/K0WPfhdmQfwsh8RXBgJ4ydEs8qiWhNffhGF/Zvg70tvUxOuElFQmJJMzzQg06Zibf9w79xEFOIRzu1aa/NDNvu4sgiFFZNn/BtirT6kvyV24rO5Yz2lupb9avGJvHZZGOzYz8StyubybRnedczUIBUf2Xw6x4cp7x5kTF92bk54pp9K/StyQqU5foGOWAp8bGLuqBdXKtiSShbTEvJ41V0XsDWbwqJniNsM7iz+Le94AWvwQDvMf+wcf2Q/ELT/YreGDD62Iqhth4zIXxVsFMJpAdTtnggR1Ik8wXOSwHGy7I5hmjt9bAVXgVEGcRPyv5FNPQ6rYO6ZmQSPzC+rIs5tYEWNNnE++TuUPe3diz98bwLTk4/AaYyQTJhsdKIT4Hh3WGe7PM4c3DMYHDm4eS8zDjW9nPhJdo08HhFyh7HoY493M+s4Bo066cNycHh3WAbLn7m35ur0POgmySyF8/koPDGsBGh0obvB8NSA7Eyd8xXiPE+YMKAKT/nwigyr9e06rnaRwc8sLIjpacU1HJK3iFQN60Ymp23F+zO6wR/gdioUTqPKqXjQAAAABJRU5ErkJggg=='
const smallDefaultImages =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAABmUExURQAAACAcIB4bHh4cHiAgIB0bHx0cHxwbHh4bHx0aHx0cHxwcHhwcIB4cHh0bHSAgIB0dHR0aHh4bHh0bHiAYIB4cHhwbHR0bHh0bHiAbIBwbHh0bIB4aHhwaHh0bHh4bIB0bHv///0EcAlcAAAAgdFJOUwBAcIAQv7+Q36+vgECQYCBQsJ+fIG+/36Awz2B/f49wDlG/TwAAAAFiS0dEIcRsDRYAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfnCxYOAjWrLDNjAAAAAW9yTlQBz6J3mgAAALVJREFUOMut090OgjAMBeBCN8BZNmUo/gLv/5QWMNGLtSTouRgX50sashUAIMsxnQymGFuU6b6sdoaBQxCztwBUgRKbAZYaqHNA1AC3/wb+/YdBAIdq6d1RAL5ZvlSoIGDUQbsGpBGnGM9djAEouiQY/ZRLA62v0+AzhSQQeIoKzDxCAasjfgJXHJd7uvERk+A7980PZgvI9WePQFYDHa+nfcj90/FhXNenl7e3hZkdCds/EJcvBxYKFKvuSOAAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjMtMTEtMjJUMTQ6MDI6NDArMDA6MDAJ9JAvAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIzLTExLTIyVDE0OjAyOjQwKzAwOjAweKkokwAAACh0RVh0ZGF0ZTp0aW1lc3RhbXAAMjAyMy0xMS0yMlQxNDowMjo1MyswMDowMNL+E08AAAAASUVORK5CYII='
function isToken(str) {
  // Define a regular expression pattern to match the token format
  const pattern = /^#\(.+\)#$/
  // Test if the string matches the pattern
  return pattern.test(str)
}

function convertToStringArray(inputString) {
  // Split the input string by comma and trim whitespace
  return inputString.split(',').map((item) => item.trim())
}

function validateEnvVariable(currentVal, defaultVal, type, emptyUseDefault) {
  if (isToken(currentVal) || (emptyUseDefault && currentVal === '')) {
    return defaultVal
  }

  switch (type) {
    case 'number':
      return Number(currentVal)
    case 'numberRound':
      return ~~currentVal
    case 'json':
      return JSON.parse(currentVal)
    case 'arrayjson':
      currentVal = convertToStringArray(currentVal)
      return currentVal
    default:
      return currentVal
  }
}

module.exports = {
  network:
    process.env.NEXT_PUBLIC_NETWORK || '#(NEXT_PUBLIC_NETWORK)#' || 'sepolia',
  conversationContext:
    process.env.NEXT_PUBLIC_ORBIS_CONTEXT ||
    '#(NEXT_PUBLIC_ORBIS_CONTEXT)#' ||
    'ocean_market',
  idleLogoutTime:
    process.env.NEXT_PUBLIC_IDLE_LOGOUT_TIME ||
    '#(NEXT_PUBLIC_IDLE_LOGOUT_TIME)#' ||
    '30',
  walletConnectProjectId:
    process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID ||
    '#(NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID)#',
  metadataCacheUri:
    process.env.NEXT_PUBLIC_NETWORK_METADATA_CACHE_URI ||
    '#(NEXT_PUBLIC_NETWORK_METADATA_CACHE_URI)#' ||
    'https://v1.aquarius.nagarro.acentrik.io',
  v3MetadataCacheUri:
    process.env.NEXT_PUBLIC_V3_METADATACACHE_URI ||
    '#(NEXT_PUBLIC_V3_METADATACACHE_URI)#' ||
    'https://v1.aquarius.nagarro.acentrik.io',
  v3MarketUri:
    process.env.NEXT_PUBLIC_V3_MARKET_URI || '#(NEXT_PUBLIC_V3_MARKET_URI)#',
  chainIds:
    (process.env.NEXT_PUBLIC_MARKET_DEFAULT_CHAINS &&
      JSON.parse(process.env.NEXT_PUBLIC_MARKET_DEFAULT_CHAINS)) ||
    validateEnvVariable(
      '#(NEXT_PUBLIC_MARKET_DEFAULT_CHAINS)#',
      [80001, 80002, 137],
      'json'
    ),
  chainIdsSupported:
    (process.env.NEXT_PUBLIC_MARKET_SUPPORTED_CHAINS &&
      JSON.parse(process.env.NEXT_PUBLIC_MARKET_SUPPORTED_CHAINS)) ||
    validateEnvVariable(
      '#(NEXT_PUBLIC_MARKET_SUPPORTED_CHAINS)#',
      [1, 137, 10, 5, 80001, 80002, 11155111, 137],
      'json'
    ),

  testNetSymbol: 'matic',
  socialLogin: {
    whitelistUrl:
      process.env.NEXT_PUBLIC_SOCIAL_LOGIN_WHITELIST_URL ||
      '#(NEXT_PUBLIC_SOCIAL_LOGIN_WHITELIST_URL)#',
    whiteLabelName: 'Marketplace',
    whiteLabelLogo: 'TO_BE_DECIDED',
    chainId:
      (process.env.NEXT_PUBLIC_ABSTRACT_CHAIN &&
        parseInt(process.env.NEXT_PUBLIC_ABSTRACT_CHAIN)) ||
      validateEnvVariable(
        '#(NEXT_PUBLIC_ABSTRACT_CHAIN)#',
        137,
        'number',
        true
      ),
    network:
      process.env.NEXT_PUBLIC_WEB3AUTH_NETWORK ||
      '#(NEXT_PUBLIC_WEB3AUTH_NETWORK)#',
    infuraProjectId:
      process.env.NEXT_PUBLIC_INFURA_PROJECT_ID ||
      validateEnvVariable(
        '#(NEXT_PUBLIC_INFURA_PROJECT_ID)#',
        'c6f6a2dc86564984af94c86b9d51e8e1',
        null,
        true
      ),
    clientId:
      process.env.NEXT_PUBLIC_WEB3AUTH_CLIENT_ID ||
      '#(NEXT_PUBLIC_WEB3AUTH_CLIENT_ID)#',
    serverUrl:
      process.env.NEXT_PUBLIC_WEB3AUTH_SERVER_URL ||
      validateEnvVariable(
        '#(NEXT_PUBLIC_WEB3AUTH_SERVER_URL)#',
        'https://session-sg.web3auth.io'
      )
  },
  validationSmartContracts: {
    sepolia: {
      orgAdmin:
        process.env.NEXT_PUBLIC_ADMIN_SESSION_VALIDATION_CONTRACT_SEPOLIA ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_ADMIN_SESSION_VALIDATION_CONTRACT_SEPOLIA)#',
          '0x6aB79ED61ec00A25ca875607A1C5D052eCe87eF8',
          null,
          true
        ),

      orgUser:
        process.env.NEXT_PUBLIC_USER_SESSION_VALIDATION_CONTRACT_SEPOLIA ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_USER_SESSION_VALIDATION_CONTRACT_SEPOLIA)#',
          '0x7220F978a1104706Cb82D03ff6Fa027456Ff69a2',
          null,
          true
        )
    },
    amoy: {
      orgAdmin:
        process.env.NEXT_PUBLIC_ADMIN_SESSION_VALIDATION_CONTRACT_AMOY ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_ADMIN_SESSION_VALIDATION_CONTRACT_AMOY)#',
          '0xcBa30bf6aF7e7384386A2df066497Eb5B41d9613',
          null,
          true
        ),

      orgUser:
        process.env.NEXT_PUBLIC_USER_SESSION_VALIDATION_CONTRACT_AMOY ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_USER_SESSION_VALIDATION_CONTRACT_AMOY)#',
          '0xB99aD06389e6c3180e1d3e8d9643080f81816b36',
          null,
          true
        )
    },
    polygon: {
      orgAdmin:
        process.env.NEXT_PUBLIC_ADMIN_SESSION_VALIDATION_CONTRACT_POLYGON ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_ADMIN_SESSION_VALIDATION_CONTRACT_POLYGON)#',
          '0x15469A10631f7A5CDdd63821BF57Ca0D22F0774c',
          null,
          true
        ),

      orgUser:
        process.env.NEXT_PUBLIC_USER_SESSION_VALIDATION_CONTRACT_POLYGON ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_USER_SESSION_VALIDATION_CONTRACT_POLYGON)#',
          '0x2dD33411E8871DF7c31B9f6c4F7D1C7B05Ec7c2c',
          null,
          true
        )
    }
  },
  infuraUrls: {
    amoy: {
      url: 'https://polygon-amoy.infura.io/v3/'
    },
    polygon: {
      url: 'https://polygon-mainnet.infura.io/v3/'
    },
    sepolia: {
      url: 'https://sepolia.infura.io/v3/'
    }
  },
  paymentManager: {
    url:
      process.env.NEXT_PUBLIC_PAYMENT_MANAGER_URL ||
      '#(NEXT_PUBLIC_PAYMENT_MANAGER_URL)#'
  },
  rbac: {
    url: process.env.NEXT_PUBLIC_RBAC_URL || '#(NEXT_PUBLIC_RBAC_URL)#',
    validateMechanism:
      process.env.NEXT_PUBLIC_RBAC_VALIDATE_MECHANISM ||
      '#(NEXT_PUBLIC_RBAC_VALIDATE_MECHANISM)#',
    authService:
      process.env.NEXT_PUBLIC_RBAC_AUTH_SERBICE ||
      '#(NEXT_PUBLIC_RBAC_AUTH_SERBICE)#'
  },
  infuraProjectId:
    process.env.NEXT_PUBLIC_INFURA_PROJECT_ID ||
    validateEnvVariable(
      '#(NEXT_PUBLIC_INFURA_PROJECT_ID)#',
      'c6f6a2dc86564984af94c86b9d51e8e1'
    ),
  infuraProjectKeys:
    (process.env.NEXT_PUBLIC_INFURA_KEYS &&
      convertToStringArray(process.env.NEXT_PUBLIC_INFURA_KEYS)) ||
    validateEnvVariable('#(NEXT_PUBLIC_INFURA_KEYS)#', [], 'arrayjson'),
  defaultDatatokenTemplateIndex: 2,
  marketFeeAddress:
    process.env.NEXT_PUBLIC_MARKET_FEE_ADDRESS ||
    '#(NEXT_PUBLIC_MARKET_FEE_ADDRESS)#',
  publisherMarketOrderFee:
    process.env.NEXT_PUBLIC_PUBLISHER_MARKET_ORDER_FEE ||
    '#(NEXT_PUBLIC_PUBLISHER_MARKET_ORDER_FEE)#',
  publisherMarketPoolSwapFee:
    process.env.NEXT_PUBLIC_PUBLISHER_MARKET_POOL_SWAP_FEE ||
    '#(NEXT_PUBLIC_PUBLISHER_MARKET_POOL_SWAP_FEE)#',
  publisherMarketFixedSwapFee:
    process.env.NEXT_PUBLIC_PUBLISHER_MARKET_FIXED_SWAP_FEE ||
    '#(NEXT_PUBLIC_PUBLISHER_MARKET_FIXED_SWAP_FEE)#',
  consumeMarketOrderFee:
    process.env.NEXT_PUBLIC_CONSUME_MARKET_ORDER_FEE ||
    '#(NEXT_PUBLIC_CONSUME_MARKET_ORDER_FEE)#',
  consumeMarketPoolSwapFee:
    process.env.NEXT_PUBLIC_CONSUME_MARKET_POOL_SWAP_FEE ||
    '#(NEXT_PUBLIC_CONSUME_MARKET_POOL_SWAP_FEE)#',
  consumeMarketFixedSwapFee:
    process.env.NEXT_PUBLIC_CONSUME_MARKET_FIXED_SWAP_FEE ||
    '#(NEXT_PUBLIC_CONSUME_MARKET_FIXED_SWAP_FEE)#',
  codeArtifactAuthToken:
    process.env.NEXT_PUBLIC_CODEARTIFACT_AUTH_TOKEN ||
    '#(NEXT_PUBLIC_CODEARTIFACT_AUTH_TOKEN)#',
  // paymaster url
  payMasterUrl: process.env.NEXT_PUBLIC_SMART_ACCOUNT_PAYMASTER_URL || '...',
  //bundler url
  bundlerUrl: process.env.NEXT_PUBLIC_SMART_ACCOUNT_BUNDLER_URL || '...',
  // url
  biconomyDashboardUrl: process.env.NEXT_PUBLIC_BICONOMY_DASHBOARD_URL || '...',
  biconomyTestnetBundlerKey:
    process.env.NEXT_PUBLIC_BICONOMY_TESTNET_BUNDLER_KEY ||
    'nJPK7B3ru.dd7f7861-190d-41bd-af80-6877f74b8f44',
  biconomyMainnetBundlerKey:
    process.env.NEXT_PUBLIC_BICONOMY_MAINNET_BUNDLER_KEY ||
    'dewj2189.wh1289hU-7E49-45ic-af80-ycUvCzsVB',
  // Used for conversion display, can be whatever coingecko API supports
  // see: https://api.coingecko.com/api/v3/simple/supported_vs_currencies
  currencies: [
    'EUR',
    'USD',
    'CAD',
    'GBP',
    'SGD',
    'HKD',
    'CNY',
    'JPY',
    'INR',
    'RUB',
    'ETH',
    'BTC',
    'LINK'
  ],
  postpayCurrencies: ['USD'],
  coingeckoTokenIds: [
    'ocean-protocol',
    'h2o',
    'ethereum',
    'matic-network',
    'usd-coin'
  ],
  stableCoin: {
    goerli: {
      address:
        process.env.NEXT_PUBLIC_STABLE_COIN_GOERLI_ADDRESS ||
        '#(NEXT_PUBLIC_STABLE_COIN_GOERLI_ADDRESS)#',
      ticker:
        process.env.NEXT_PUBLIC_STABLE_COIN_GOERLI_TICKER ||
        '#(NEXT_PUBLIC_STABLE_COIN_GOERLI_TICKER)#',
      decimals:
        parseInt(process.env.NEXT_PUBLIC_STABLE_COIN_GOERLI_DECIMALS) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_STABLE_COIN_GOERLI_DECIMALS)#',
          6,
          'number'
        )
    },
    sepolia: {
      address:
        process.env.NEXT_PUBLIC_STABLE_COIN_SEPOLIA_ADDRESS ||
        '#(NEXT_PUBLIC_STABLE_COIN_SEPOLIA_ADDRESS)#',
      ticker:
        process.env.NEXT_PUBLIC_STABLE_COIN_SEPOLIA_TICKER ||
        '#(NEXT_PUBLIC_STABLE_COIN_SEPOLIA_TICKER)#',
      decimals:
        parseInt(process.env.NEXT_PUBLIC_STABLE_COIN_SEPOLIA_DECIMALS) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_STABLE_COIN_SEPOLIA_DECIMALS)#',
          6,
          'number'
        )
    },
    polygon: {
      address:
        process.env.NEXT_PUBLIC_STABLE_COIN_POLYGON_ADDRESS ||
        '#(NEXT_PUBLIC_STABLE_COIN_POLYGON_ADDRESS)#',
      ticker:
        process.env.NEXT_PUBLIC_STABLE_COIN_POLYGON_TICKER ||
        '#(NEXT_PUBLIC_STABLE_COIN_POLYGON_TICKER)#',
      decimals:
        parseInt(process.env.NEXT_PUBLIC_STABLE_COIN_POLYGON_DECIMALS) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_STABLE_COIN_POLYGON_DECIMALS)#',
          6,
          'number'
        )
    },
    amoy: {
      address:
        process.env.NEXT_PUBLIC_STABLE_COIN_AMOY_ADDRESS ||
        '#(NEXT_PUBLIC_STABLE_COIN_AMOY_ADDRESS)#',
      ticker:
        process.env.NEXT_PUBLIC_STABLE_COIN_AMOY_TICKER ||
        '#(NEXT_PUBLIC_STABLE_COIN_AMOY_TICKER)#',
      decimals:
        parseInt(process.env.NEXT_PUBLIC_STABLE_COIN_AMOY_DECIMALS) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_STABLE_COIN_AMOY_DECIMALS)#',
          6,
          'number'
        )
    },
    supernetTestnet: {
      address:
        process.env.NEXT_PUBLIC_STABLE_COIN_SUPERNET_TESTNET_ADDRESS ||
        '#(NEXT_PUBLIC_STABLE_COIN_SUPERNET_TESTNET_ADDRESS)#',
      ticker:
        process.env.NEXT_PUBLIC_STABLE_COIN_SUPERNET_TESTNET_TICKER ||
        '#(NEXT_PUBLIC_STABLE_COIN_SUPERNET_TESTNET_TICKER)#',
      decimals:
        parseInt(
          process.env.NEXT_PUBLIC_STABLE_COIN_SUPERNET_TESTNET_DECIMALS
        ) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_STABLE_COIN_SUPERNET_TESTNET_DECIMALS)#',
          6,
          'number'
        )
    },
    'gen-x-testnet': {
      address:
        process.env.NEXT_PUBLIC_STABLE_COIN_GEN_X_TESTNET_ADDRESS ||
        '#(NEXT_PUBLIC_STABLE_COIN_GEN_X_TESTNET_ADDRESS)#',
      ticker:
        process.env.NEXT_PUBLIC_STABLE_COIN_GEN_X_TESTNET_TICKER ||
        '#(NEXT_PUBLIC_STABLE_COIN_GEN_X_TESTNET_TICKER)#',
      decimals:
        parseInt(process.env.NEXT_PUBLIC_STABLE_COIN_GEN_X_TESTNET_DECIMALS) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_STABLE_COIN_GEN_X_TESTNET_DECIMALS)#',
          6,
          'number'
        )
    },
    'acentrik-testnet': {
      address: '0xe538844D599236da444FFA4a121D105580883572',
      ticker: 'USDC',
      decimals: 6
    }
  },
  transaction: {
    goerli: {
      gasEstimateNftAddress:
        process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_GAS_ESTIMATE_NFT_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_GAS_ESTIMATE_NFT_ADDRESS)#',
          '0x96bC1643f5E953A89010D791BB238f9B2981a9BE'
        ),
      gasEstimateNftOwnerAddress:
        process.env
          .NEXT_PUBLIC_TRANSACTION_GOERLI_GAS_ESTIMATE_NFT_OWNER_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_GAS_ESTIMATE_NFT_OWNER_ADDRESS)#',
          '0x500DB43EE6966e6213BA58EAF152dA593EB7432e'
        ),
      transactionBlockTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_BLOCK_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_BLOCK_TIMEOUT)#',
          150,
          'number'
        ),

      transactionConfirmationBlocks:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_CONFIRMATION_BLOCKS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_CONFIRMATION_BLOCKS)#',
          5,
          'number'
        ),

      transactionPollingTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_POLLING_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_POLLING_TIMEOUT)#',
          1750,
          'number'
        ),

      gasFeeMultiplier:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_GAS_MULTIPLIER ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_GAS_MULTIPLIER)#',
          0,
          'numberRound'
        ),

      periodicCheckTransactionDuration:
        (process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_PERIODIC_CHECK_DURATION &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_PERIODIC_CHECK_DURATION
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_PERIODIC_CHECK_DURATION)#',
          180000,
          'number'
        ),

      periodicCheckTransactionCycle:
        (process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_PERIODIC_CHECK_CYCLE &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_GOERLI_PERIODIC_CHECK_CYCLE
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GOERLI_PERIODIC_CHECK_CYCLE)#',
          5,
          'number'
        )
    },
    sepolia: {
      gasEstimateNftAddress:
        process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_GAS_ESTIMATE_NFT_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_GAS_ESTIMATE_NFT_ADDRESS)#',
          '0xf4AB049DA35C6e749a7FE2Bf517C3f71aCAe6E25'
        ),

      gasEstimateNftOwnerAddress:
        process.env
          .NEXT_PUBLIC_TRANSACTION_SEPOLIA_GAS_ESTIMATE_NFT_OWNER_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_GAS_ESTIMATE_NFT_OWNER_ADDRESS)#',
          '0x500DB43EE6966e6213BA58EAF152dA593EB7432e'
        ),

      transactionBlockTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_BLOCK_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_BLOCK_TIMEOUT)#',
          375,
          'number'
        ),

      transactionConfirmationBlocks:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_CONFIRMATION_BLOCKS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_CONFIRMATION_BLOCKS)#',
          5,
          'number'
        ),

      transactionPollingTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_POLLING_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_POLLING_TIMEOUT)#',
          5500,
          'number'
        ),

      gasFeeMultiplier:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_GAS_MULTIPLIER ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_GAS_MULTIPLIER)#',
          0,
          'numberRound'
        ),

      periodicCheckTransactionDuration:
        (process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_PERIODIC_CHECK_DURATION &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_PERIODIC_CHECK_DURATION
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_PERIODIC_CHECK_DURATION)#',
          180000,
          'number'
        ),

      periodicCheckTransactionCycle:
        (process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_PERIODIC_CHECK_CYCLE &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_SEPOLIA_PERIODIC_CHECK_CYCLE
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SEPOLIA_PERIODIC_CHECK_CYCLE)#',
          5,
          'number'
        )
    },
    polygon: {
      gasEstimateNftAddress:
        process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_GAS_ESTIMATE_NFT_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_GAS_ESTIMATE_NFT_ADDRESS)#',
          '0xD6355C352e9539DA20bE78070DC92b9614cec18F'
        ),

      gasEstimateNftOwnerAddress:
        process.env
          .NEXT_PUBLIC_TRANSACTION_POLYGON_GAS_ESTIMATE_NFT_OWNER_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_GAS_ESTIMATE_NFT_OWNER_ADDRESS)#',
          '0x500DB43EE6966e6213BA58EAF152dA593EB7432e'
        ),

      transactionBlockTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_BLOCK_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_BLOCK_TIMEOUT)#',
          375,
          'number'
        ),

      transactionConfirmationBlocks:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_CONFIRMATION_BLOCKS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_CONFIRMATION_BLOCKS)#',
          5,
          'number'
        ),

      transactionPollingTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_POLLING_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_POLLING_TIMEOUT)#',
          5500,
          'number'
        ),

      gasFeeMultiplier:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_GAS_MULTIPLIER ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_GAS_MULTIPLIER)#',
          0,
          'numberRound'
        ),

      periodicCheckTransactionDuration:
        (process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_PERIODIC_CHECK_DURATION &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_PERIODIC_CHECK_DURATION
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_PERIODIC_CHECK_DURATION)#',
          180000,
          'number'
        ),

      periodicCheckTransactionCycle:
        (process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_PERIODIC_CHECK_CYCLE &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_POLYGON_PERIODIC_CHECK_CYCLE
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_POLYGON_PERIODIC_CHECK_CYCLE)#',
          5,
          'number'
        )
    },
    amoy: {
      gasEstimateNftAddress:
        process.env.NEXT_PUBLIC_TRANSACTION_AMOY_GAS_ESTIMATE_NFT_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_GAS_ESTIMATE_NFT_ADDRESS)#',
          '0xed9994904141Fde5B71D26507A3891B7EF3FDA72'
        ),

      gasEstimateNftOwnerAddress:
        process.env
          .NEXT_PUBLIC_TRANSACTION_AMOY_GAS_ESTIMATE_NFT_OWNER_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_GAS_ESTIMATE_NFT_OWNER_ADDRESS)#',
          '0x2E33C6014222A47585605F8379a1877eaaF0ec13'
        ),

      transactionBlockTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_AMOY_BLOCK_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_BLOCK_TIMEOUT)#',
          375,
          'number'
        ),

      transactionConfirmationBlocks:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_AMOY_CONFIRMATION_BLOCKS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_CONFIRMATION_BLOCKS)#',
          5,
          'number'
        ),
      transactionPollingTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_AMOY_POLLING_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_POLLING_TIMEOUT)#',
          5500,
          'number'
        ),

      gasFeeMultiplier:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_AMOY_GAS_MULTIPLIER ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_GAS_MULTIPLIER)#',
          0,
          'numberRound'
        ),

      periodicCheckTransactionDuration:
        (process.env.NEXT_PUBLIC_TRANSACTION_AMOY_PERIODIC_CHECK_DURATION &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_AMOY_PERIODIC_CHECK_DURATION
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_PERIODIC_CHECK_DURATION)#',
          180000,
          'number'
        ),

      periodicCheckTransactionCycle:
        (process.env.NEXT_PUBLIC_TRANSACTION_AMOY_PERIODIC_CHECK_CYCLE &&
          Number(
            process.env.NEXT_PUBLIC_TRANSACTION_AMOY_PERIODIC_CHECK_CYCLE
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_AMOY_PERIODIC_CHECK_CYCLE)#',
          5,
          'number'
        )
    },
    supernetTestnet: {
      transactionBlockTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_BLOCK_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_BLOCK_TIMEOUT)#',
          375,
          'number'
        ),

      transactionConfirmationBlocks:
        ~~process.env
          .NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_CONFIRMATION_BLOCKS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_CONFIRMATION_BLOCKS)#',
          5,
          'number'
        ),

      transactionPollingTimeout:
        ~~process.env
          .NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_POLLING_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_POLLING_TIMEOUT)#',
          5500,
          'number'
        ),

      gasFeeMultiplier:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_GAS_MULTIPLIER ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_GAS_MULTIPLIER)#',
          0,
          'numberRound'
        ),

      periodicCheckTransactionDuration:
        (process.env
          .NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_PERIODIC_CHECK_DURATION &&
          Number(
            process.env
              .NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_PERIODIC_CHECK_DURATION
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_PERIODIC_CHECK_DURATION)#',
          180000,
          'number'
        ),

      periodicCheckTransactionCycle:
        (process.env
          .NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_PERIODIC_CHECK_CYCLE &&
          Number(
            process.env
              .NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_PERIODIC_CHECK_CYCLE
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_SUPERNET_TESTNET_PERIODIC_CHECK_CYCLE)#',
          5,
          'number'
        )
    },
    'gen-x-testnet': {
      transactionBlockTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_BLOCK_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_BLOCK_TIMEOUT)#',
          375,
          'number'
        ),

      transactionConfirmationBlocks:
        ~~process.env
          .NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_CONFIRMATION_BLOCKS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_CONFIRMATION_BLOCKS)#',
          5,
          'number'
        ),

      transactionPollingTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_POLLING_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_POLLING_TIMEOUT)#',
          5500,
          'number'
        ),

      gasFeeMultiplier:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_GAS_MULTIPLIER ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_GAS_MULTIPLIER)#',
          0,
          'numberRound'
        ),

      periodicCheckTransactionDuration:
        (process.env
          .NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_PERIODIC_CHECK_DURATION &&
          Number(
            process.env
              .NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_PERIODIC_CHECK_DURATION
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_PERIODIC_CHECK_DURATION)#',
          180000,
          'number'
        ),

      periodicCheckTransactionCycle:
        (process.env
          .NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_PERIODIC_CHECK_CYCLE &&
          Number(
            process.env
              .NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_PERIODIC_CHECK_CYCLE
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_GEN_X_TESTNET_PERIODIC_CHECK_CYCLE)#',
          5,
          'number'
        )
    },
    'acentrik-testnet': {
      gasEstimateNftAddress:
        process.env
          .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_GAS_ESTIMATE_NFT_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_GAS_ESTIMATE_NFT_ADDRESS)#',
          '0x47AAF5A39eb6D896D8E8C58Ae709b99b49eBc1e8'
        ),
      gasEstimateNftOwnerAddress:
        process.env
          .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_GAS_ESTIMATE_NFT_OWNER_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_GAS_ESTIMATE_NFT_OWNER_ADDRESS)#',
          '0xAe28AA182BF02021914F192EAbE3A036520C9273'
        ),

      transactionBlockTimeout:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_BLOCK_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_BLOCK_TIMEOUT)#',
          375,
          'number'
        ),

      transactionConfirmationBlocks:
        ~~process.env
          .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_CONFIRMATION_BLOCKS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_CONFIRMATION_BLOCKS)#',
          5,
          'number'
        ),

      transactionPollingTimeout:
        ~~process.env
          .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_POLLING_TIMEOUT ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_POLLING_TIMEOUT)#',
          5500,
          'number'
        ),

      gasFeeMultiplier:
        ~~process.env.NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_GAS_MULTIPLIER ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_GAS_MULTIPLIER)#',
          1,
          'numberRound'
        ),

      periodicCheckTransactionDuration:
        (process.env
          .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_PERIODIC_CHECK_DURATION &&
          Number(
            process.env
              .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_PERIODIC_CHECK_DURATION
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_PERIODIC_CHECK_DURATION)#',
          180000,
          'number'
        ),

      periodicCheckTransactionCycle:
        (process.env
          .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_PERIODIC_CHECK_CYCLE &&
          Number(
            process.env
              .NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_PERIODIC_CHECK_CYCLE
          )) ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_TRANSACTION_ACENTRIK_TESTNET_PERIODIC_CHECK_CYCLE)#',
          5,
          'number'
        )
    },
    progressStepperAttentionCountdown: 3000,
    retry:
      (process.env.NEXT_PUBLIC_TRANSACTION_RETRY &&
        Number(process.env.NEXT_PUBLIC_TRANSACTION_RETRY)) ||
      validateEnvVariable('#(NEXT_PUBLIC_TRANSACTION_RETRY)#', 3, 'number')
  },
  darkModeConfig: {
    classNameDark: 'dark',
    classNameLight: 'light',
    storageKey: 'oceanDarkMode'
  },
  // Wallets
  portisId: process.env.NEXT_PUBLIC_PORTIS_ID || '#(NEXT_PUBLIC_PORTIS_ID)#',
  // Analytics
  analyticsId:
    process.env.NEXT_PUBLIC_ANALYTICS_ID || '#(NEXT_PUBLIC_ANALYTICS_ID)#',
  // Compute Output expiry
  computeOutputExpiry:
    process.env.NEXT_PUBLIC_COMPUTE_OUTPUT_EXPIRY ||
    '#(NEXT_PUBLIC_COMPUTE_OUTPUT_EXPIRY)#',
  source: process.env.NEXT_PUBLIC_SOURCE || '#(NEXT_PUBLIC_SOURCE)#',
  networkConfig: {
    multiChainEncryptionProviderUri:
      process.env.NEXT_PUBLIC_MULTI_NETWORK_ENCRYPTION_PROVIDER_URI ||
      '#(NEXT_PUBLIC_MULTI_NETWORK_ENCRYPTION_PROVIDER_URI)#',
    goerli: {
      providerUri:
        process.env.NEXT_PUBLIC_NETWORK_GOERLI_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_GOERLI_PROVIDER_URI)#',
      subgraphUri:
        process.env.NEXT_PUBLIC_NETWORK_GOERLI_SUBGRAPH_URI ||
        '#(NEXT_PUBLIC_NETWORK_GOERLI_SUBGRAPH_URI)#',
      marketFeeAddress:
        process.env.NEXT_PUBLIC_NETWORK_GOERLI_MARKET_FEE_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_GOERLI_MARKET_FEE_ADDRESS)#',
          '0xF730734e79cC6a32e520e86359f90cfA3b378A14',
          'number'
        ),
      encryptionProviderUri:
        process.env.NEXT_PUBLIC_NETWORK_GOERLI_ENCRYPTION_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_GOERLI_ENCRYPTION_PROVIDER_URI)#',
      rpc:
        process.env.NEXT_PUBLIC_GOERLI_RPC_URL ||
        validateEnvVariable('#(NEXT_PUBLIC_GOERLI_RPC_URL)#', undefined)
    },
    sepolia: {
      providerUri:
        process.env.NEXT_PUBLIC_NETWORK_SEPOLIA_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_SEPOLIA_PROVIDER_URI)#',
      subgraphUri:
        process.env.NEXT_PUBLIC_NETWORK_SEPOLIA_SUBGRAPH_URI ||
        '#(NEXT_PUBLIC_NETWORK_SEPOLIA_SUBGRAPH_URI)#',
      marketFeeAddress:
        process.env.NEXT_PUBLIC_NETWORK_SEPOLIA_MARKET_FEE_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_SEPOLIA_MARKET_FEE_ADDRESS)#',
          '0xD4ebBB5CCaF29d189B14fA95C6Fa73AA9910191a'
        ),
      encryptionProviderUri:
        process.env.NEXT_PUBLIC_NETWORK_SEPOLIA_ENCRYPTION_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_SEPOLIA_ENCRYPTION_PROVIDER_URI)#',
      rpc:
        process.env.NEXT_PUBLIC_SEPOLIA_RPC_URL ||
        validateEnvVariable('#(NEXT_PUBLIC_SEPOLIA_RPC_URL)#', undefined)
    },
    polygon: {
      providerUri:
        process.env.NEXT_PUBLIC_NETWORK_POLYGON_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_POLYGON_PROVIDER_URI)#',
      subgraphUri:
        process.env.NEXT_PUBLIC_NETWORK_POLYGON_SUBGRAPH_URI ||
        '#(NEXT_PUBLIC_NETWORK_POLYGON_SUBGRAPH_URI)#',
      marketFeeAddress:
        process.env.NEXT_PUBLIC_NETWORK_POLYGON_MARKET_FEE_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_POLYGON_MARKET_FEE_ADDRESS)#',
          '0xF14BFDac1e60E2Eb5b62083A7eB10F52063d6c30'
        ),
      encryptionProviderUri:
        process.env.NEXT_PUBLIC_NETWORK_POLYGON_ENCRYPTION_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_POLYGON_ENCRYPTION_PROVIDER_URI)#',
      rpc:
        process.env.NEXT_PUBLIC_MATIC_RPC_URL ||
        validateEnvVariable('#(NEXT_PUBLIC_MATIC_RPC_URL)#', undefined)
    },
    amoy: {
      providerUri:
        process.env.NEXT_PUBLIC_NETWORK_AMOY_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_AMOY_PROVIDER_URI)#',
      subgraphUri:
        process.env.NEXT_PUBLIC_NETWORK_AMOY_SUBGRAPH_URI ||
        '#(NEXT_PUBLIC_NETWORK_AMOY_SUBGRAPH_URI)#',
      marketFeeAddress:
        process.env.NEXT_PUBLIC_NETWORK_AMOY_MARKET_FEE_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_AMOY_MARKET_FEE_ADDRESS)#',
          '0xF14BFDac1e60E2Eb5b62083A7eB10F52063d6c30'
        ),
      encryptionProviderUri:
        process.env.NEXT_PUBLIC_NETWORK_AMOY_ENCRYPTION_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_AMOY_ENCRYPTION_PROVIDER_URI)#',
      rpc:
        process.env.NEXT_PUBLIC_AMOY_RPC_URL ||
        validateEnvVariable('#(NEXT_PUBLIC_AMOY_RPC_URL)#', undefined)
    },
    supernetTestnet: {
      providerUri:
        process.env.NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_PROVIDER_URI)#',
      subgraphUri:
        process.env.NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_SUBGRAPH_URI ||
        '#(NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_SUBGRAPH_URI)#',
      marketFeeAddress:
        process.env.NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_MARKET_FEE_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_MARKET_FEE_ADDRESS)#',
          '0xF14BFDac1e60E2Eb5b62083A7eB10F52063d6c30'
        ),
      encryptionProviderUri:
        process.env
          .NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_ENCRYPTION_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_ENCRYPTION_PROVIDER_URI)#',
      rpc:
        process.env.NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_RPC_URL ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_SUPERNET_TESTNET_RPC_URL)#',
          'https://rpc-edgenet.polygon.technology'
        )
    },
    'gen-x-testnet': {
      providerUri:
        process.env.NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_PROVIDER_URI)#',
      subgraphUri:
        process.env.NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_SUBGRAPH_URI ||
        '#(NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_SUBGRAPH_URI)#',
      marketFeeAddress:
        process.env.NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_MARKET_FEE_ADDRESS ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_MARKET_FEE_ADDRESS)#',
          '0x203C7AA993EED06932FA327a192de9A8370b5Ab4'
        ),

      encryptionProviderUri:
        process.env.NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_ENCRYPTION_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_ENCRYPTION_PROVIDER_URI)#',
      rpc:
        process.env.NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_RPC_URL ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_GEN_X_TESTNET_RPC_URL)#',
          'https://rpc.genx.minimal-gaia-x.eu'
        )
    },
    'acentrik-testnet': {
      providerUri:
        process.env.NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_PROVIDER_URI)#',
      subgraphUri:
        process.env.NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_SUBGRAPH_URI ||
        '#(NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_SUBGRAPH_URI)#',
      marketFeeAddress:
        process.env.NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_MARKET_FEE_ADDRESS ||
        '#(NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_MARKET_FEE_ADDRESS)#',
      encryptionProviderUri:
        process.env
          .NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_ENCRYPTION_PROVIDER_URI ||
        '#(NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_ENCRYPTION_PROVIDER_URI)#',
      rpc:
        process.env.NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_RPC_URL ||
        validateEnvVariable(
          '#(NEXT_PUBLIC_NETWORK_ACENTRIK_TESTNET_RPC_URL)#',
          'https://nd-857-945-998.p2pify.com/54fd318470db6bee4164a4059da710ba'
        )
    }
  },
  // IPFS related settings
  ipfs: {
    gatewayUri: process.env.NEXT_PUBLIC_IPFS_URI || '#(NEXT_PUBLIC_IPFS_URI)#',
    uploadLimit:
      process.env.NEXT_PUBLIC_IPFS_UPLOAD_LIMIT ||
      '#(NEXT_PUBLIC_IPFS_UPLOAD_LIMIT)#',
    eulaUploadLimit:
      process.env.NEXT_PUBLIC_IPFS_EULA_UPLOAD_LIMIT ||
      '#(NEXT_PUBLIC_IPFS_EULA_UPLOAD_LIMIT)#',
    imageUploadLimit:
      process.env.NEXT_PUBLIC_IPFS_UPLOAD_IMAGE_LIMIT ||
      '#(NEXT_PUBLIC_IPFS_UPLOAD_IMAGE_LIMIT)#'
  },

  // Default standard api domain
  api:
    process.env.NEXT_PUBLIC_API_URI ||
    validateEnvVariable(
      '#(NEXT_PUBLIC_API_URI)#',
      'https://api.devv3.acentrik.io'
    ),
  keycloakUrl:
    process.env.NEXT_PUBLIC_KEYCLOAK_URI || '#(NEXT_PUBLIC_KEYCLOAK_URI)#',
  otpDuration:
    process.env.NEXT_PUBLIC_AUTH_OTP_DURATION ||
    '#(NEXT_PUBLIC_AUTH_OTP_DURATION)#',
  // Org enabled flow
  isOrgEnabled: true,
  site: {
    baseUrl:
      process.env.NEXT_PUBLIC_SITE_BASE_URL || '#(NEXT_PUBLIC_SITE_BASE_URL)#',
    termsAndConditionsUrl:
      process.env.NEXT_PUBLIC_SITE_TERM_AND_CONDITION_URL ||
      '#(NEXT_PUBLIC_SITE_TERM_AND_CONDITION_URL)#',
    matomoBaseUrl:
      process.env.NEXT_PUBLIC_MATOMO_BASE_URL ||
      '#(NEXT_PUBLIC_MATOMO_BASE_URL)#',
    matomoSiteId:
      ~~process.env.NEXT_PUBLIC_MATOMO_SITE_ID ||
      validateEnvVariable('#(NEXT_PUBLIC_MATOMO_SITE_ID)#', 1, 'number'),

    isEnableMatomo:
      process.env.NEXT_PUBLIC_MATOMO_ENABLE || '#(NEXT_PUBLIC_MATOMO_ENABLE)#',
    cookieSecure:
      process.env.NEXT_PUBLIC_COOKIE_SECURE || '#(NEXT_PUBLIC_COOKIE_SECURE)#',
    webPortalUrl:
      process.env.NEXT_PUBLIC_SITE_WEB_PORTAL_URL ||
      validateEnvVariable(
        '#(NEXT_PUBLIC_SITE_WEB_PORTAL_URL)#',
        'https://docs.acentrik.io',
        null,
        true
      ),
    assetManagementTokenSymbolPrefix:
      process.env.NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_SYMBOL_PREFIX ||
      '#(NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_SYMBOL_PREFIX)#',
    assetManagementTokenName:
      process.env.NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_NAME ||
      '#(NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_NAME)#',
    assetManagementTokenImageUrl:
      process.env.NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_IMAGE_URL ||
      '#(NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_IMAGE_URL)#',
    assetManagementTokenImageBackground:
      process.env
        .NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_IMAGE_BACKGROUND ||
      '#(NEXT_PUBLIC_ACENTRIK_ASSET_MANAGEMENT_TOKEN_IMAGE_BACKGROUND)#'
  },
  themeImagesData: {
    headerLogoBase64: validateEnvVariable('#(headerLogo)#', bigDefaultImages),
    footerLogoBase64: validateEnvVariable('#(footerLogo)#', bigDefaultImages),
    tokenImageBase64: validateEnvVariable('#(tokenImage)#', smallDefaultImages),
    faviconBase64: validateEnvVariable('#(favicon)#', smallDefaultImages)
  },
  staticUrlsData: {
    termsAndConditions: validateEnvVariable('#(termsAndConditions)#', ''),
    privacyPolicy: validateEnvVariable('#(privacyPolicy)#', ''),
    cookiePolicy: validateEnvVariable('#(cookiePolicy)#', ''),
    licenses: validateEnvVariable('#(licenses)#', ''),
    copyrightText: validateEnvVariable('#(copyrightText)#', ''),
    knowledgeBase: validateEnvVariable('#(knowledgeBase)#', ''),
    faqs: validateEnvVariable('#(faqs)#', ''),
    contactUs: validateEnvVariable('#(contactUs)#', ''),
    websiteHeading: validateEnvVariable('#(websiteHeading)#', '')
  },
  // Used to show or hide the fixed, dynamic or free price options
  // tab to publishers during the price creation.
  allowFixedPricing:
    process.env.NEXT_PUBLIC_ALLOW_FIXED_PRICING ||
    '#(NEXT_PUBLIC_ALLOW_FIXED_PRICING)#',
  allowDynamicPricing:
    process.env.NEXT_PUBLIC_ALLOW_DYNAMIC_PRICING ||
    '#(NEXT_PUBLIC_ALLOW_DYNAMIC_PRICING)#',
  allowFreePricing:
    process.env.NEXT_PUBLIC_ALLOW_FREE_PRICING ||
    '#(NEXT_PUBLIC_ALLOW_FREE_PRICING)#',

  allowHttpAssetEndpoint:
    process.env.NEXT_PUBLIC_CUSTOMIZATION_ASSET_ALLOW_INSECURE_PROTOCOL ||
    '#(NEXT_PUBLIC_CUSTOMIZATION_ASSET_ALLOW_INSECURE_PROTOCOL)#',

  // Used to show or hide advanced settings button in asset details page
  allowAdvancedSettings:
    process.env.NEXT_PUBLIC_ALLOW_ADVANCED_SETTINGS ||
    '#(NEXT_PUBLIC_ALLOW_ADVANCED_SETTINGS)#',
  allowAdvancedPublishSettings:
    process.env.NEXT_PUBLIC_ALLOW_ADVANCED_PUBLISH_SETTINGS ||
    '#(NEXT_PUBLIC_ALLOW_ADVANCED_PUBLISH_SETTINGS)#',

  credentialType:
    process.env.NEXT_PUBLIC_CREDENTIAL_TYPE ||
    '#(NEXT_PUBLIC_CREDENTIAL_TYPE)#',

  // Set the default privacy policy to initially display
  // this should be the slug of your default policy markdown file
  defaultPrivacyPolicySlug: '/privacy/en',

  // This enables / disables the use of a GDPR compliant
  // privacy preference center to manage cookies on the market
  // If set to true a gdpr.json file inside the content directory
  // is used to create and show a privacy preference center / cookie banner
  // To learn more about how to configure and use this, please refer to the readme
  privacyPreferenceCenter:
    process.env.NEXT_PUBLIC_PRIVACY_PREFERENCE_CENTER ||
    '#(NEXT_PUBLIC_PRIVACY_PREFERENCE_CENTER)#',

  supportEmail:
    process.env.NEXT_PUBLIC_SUPPORT_EMAIL || '#(NEXT_PUBLIC_SUPPORT_EMAIL)#',

  requestTimeout:
    ~~process.env.NEXT_PUBLIC_REQUEST_TIMEOUT ||
    validateEnvVariable(
      '#(NEXT_PUBLIC_REQUEST_TIMEOUT)#',
      '0xF730734e79cC6a32e520e86359f90cfA3b378A14',
      'number'
    ),

  customization: {
    isDisableUnlimitedTimeout:
      process.env.NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_UNLIMITED_TIMEOUT ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_UNLIMITED_TIMEOUT)#',
    isDisableParameterizeAsset:
      process.env.NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_PARAMETERIZE_ASSET ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_PARAMETERIZE_ASSET)#',
    isDisableCustomDocker:
      process.env.NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_CUSTOM_DOCKER ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_CUSTOM_DOCKER)#',
    isDisableCustomDockerValidation:
      process.env
        .NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_CUSTOM_DOCKER_VALIDATION ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_CUSTOM_DOCKER_VALIDATION)#',
    isDisableRbacMultipleCredentialType:
      process.env
        .NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_RBAC_MULTIPLE_CREDENTIAL_TYPE ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_RBAC_MULTIPLE_CREDENTIAL_TYPE)#',
    isDisableDeveloperDetail:
      process.env.NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_DEVELOPER_DETAIL ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_DEVELOPER_DETAIL)#',
    isDisableCompanyNameChangeAcknowledgement:
      process.env
        .NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_COMPANY_NAME_CHANGE_ACKNOWLEDGEMENT ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_COMPANY_NAME_CHANGE_ACKNOWLEDGEMENT)#',
    //YYYY-MM-DDThh:mm
    companyNameChangeDate:
      process.env.NEXT_PUBLIC_CUSTOMIZATION_COMPANY_NAME_CHANGE_DATE ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_COMPANY_NAME_CHANGE_DATE)#',
    theme:
      process.env.NEXT_PUBLIC_CUSTOMIZATION_THEME ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_THEME)#',
    isDisableFilterByContract:
      process.env.NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_FILTER_BY_CONTRACT ||
      '#(NEXT_PUBLIC_CUSTOMIZATION_IS_DISABLE_FILTER_BY_CONTRACT)#',
    dateFormat: 'dd MMM yyyy',
    bucketName:
      process.env.NEXT_PUBLIC_AWS_S3_BUCKET_PUBLIC ||
      '#(NEXT_PUBLIC_AWS_S3_BUCKET_PUBLIC)#'
  },
  computeOptions: [
    {
      name: 'nodejs',
      value: {
        entrypoint: 'node $ALGO',
        registry:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_REGISTRY ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_REGISTRY)#',
        imageName:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_IMAGE_NAME ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_IMAGE_NAME)#',
        image:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_IMAGE ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_IMAGE)#',
        tag:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_TAG ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_TAG)#',
        checksum:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_HASH ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_NODEJS_HASH)#'
      }
    },
    {
      name: 'python3.7',
      value: {
        entrypoint: 'python $ALGO',
        registry:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_REGISTRY ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_REGISTRY)#',
        imageName:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_IMAGE_NAME ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_IMAGE_NAME)#',
        image:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_IMAGE ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_IMAGE)#',
        tag:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_TAG ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_TAG)#',
        checksum:
          process.env.NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_HASH ||
          '#(NEXT_PUBLIC_COMPUTE_OPTION_PYTHON_HASH)#'
      }
    }
  ]
}
