---
title: Privacy Policy
description: If you have Do Not Track activated or do not interact with our cookie banner, we don’t collect any information at all about your visit on our site. If you accept cookies, we make sure to only collect the bare minimum of information needed, as described in this Privacy Policy.
---

### **Privacy Policy**

<p class="subtitle2">Last updated: 14 April 2022 </p>

**1 INTRODUCTION**

1.1 Daimler South East Asia Pte Ltd (&quot;**DSEA**&quot;, &quot;**we**&quot;, &quot;**us**&quot; or &quot;**our**&quot;) operates https://acentrik.io, a decentralised data marketplace platform (the &quot;**Acentrik Platform**&quot;). This page informs you of our policies regarding the collection, use and disclosure of Personal Data we receive from users of the Acentrik Platform.

1.2 **Personal Data** means any data that allows the identification of a person directly or indirectly. For example, combining various data may enable identifying a person even when each data separately would not allow that. Personal data can include many types of data, such as a name, location data, an online identifier, IP address or the like. We regularly review our Privacy Policy and may change it from time to time.

1.3 In order to allow you to use or access the Acentrik Platform and all software and services offered through the Acentrik Platform (collectively referred to as the &quot;**Services**&quot;), it is necessary for DSEA to process your Personal Data in accordance with Clauses 2 to 4 of this Privacy Policy.

1.4 We are a private limited company registered under the laws of Singapore, which is located at Daimler South East Asia Pte. Ltd., Westgate Tower, 1 Gateway Drive #15-01, Singapore 608531. Our appointed data protection officer is contactable at joanne.chia@mercedes-benz.com..

1.5 If you have questions about the Privacy Policy or want to exercise any of your rights mentioned in Clause 8, let us know by emailing support-acentrik@mercedes-benz.com.

1.6 We process your Personal Data in accordance with the Personal Data Protection Act 2012 in Singapore (&quot;**PDPA**&quot;) and Article 6 of the General Data Protection Regulation (&quot;**GDPR**&quot;) to the extent that such processing is necessary for the provision of our Services to you, or where we are legally obliged to do so (e.g., storage for the fulfilment of commercial or tax-related retention obligations, release in accordance with official or judicial orders, e.g. to a law enforcement authority). Where any form of processing is not necessary for the provision of our Services to you and are for additional purposes (such as marketing or the sending of promotional emails), we will only conduct such processing with your specific and express consent.

1.7 We do not knowingly collect Personal Data from children under 18 without consent from a parent or guardian. If we learn a child has provided Personal Data, we have the right to delete the information containing such Personal Data and/or the User Account containing such Personal Data.

**2 WHAT INFORMATION IS COLLECTED**

2.1 When you sign up for an account on the Acentrik Platform, we will ask you for your company name, password and business email.

2.2 If you wish to subscribe to data sets provided by third parties (&quot;**Data Assets**&quot;) as publicised in listings (&quot;**Asset Listings**&quot;) on the Acentrik Platform (&quot;**Data Consumer**&quot;), such third party data providers (&quot;**Data Providers**&quot;) may ask you for additional Personal Data or request a confirmation of your identity. Any such information will be collected separately by these third parties and not by us, and we advise you to read and familiarize yourself with their privacy policies. However, if such third parties share your Personal Data with us, we will process the data in line with this Privacy Policy.

2.3 Whenever you visit the Acentrik Platform, we store certain information about the browser and operating system you are using; the date and time of your visit; the status of the interaction (e.g. whether you were able to access the Acentrik Platform or received an error message); the usage of features on the Acentrik Platform; any search phrases you entered; how often you visit the Acentrik Platform; the names of the files you access; the amount of data transferred; the Web page from which you accessed the Acentrik Platform; and the Web page you visited after visiting the Acentrik Platform, whether by clicking links on DSEA’s other websites or entering a domain directly into the input field of the same tab (or window) of the browser in which you have the Acentrik Platform open. In addition, we store your IP address and the name of your Internet service provider for seven days. This is for security reasons; in particular, to prevent and detect attacks on the Acentrik Platform or attempts at fraud. The legal basis for such processing is found under Article 6(1)(f) of the GDPR. You have the right to opt out of such processing.

2.4 **To the extent your Personal Data is processed as part of data streams provided in the Acentrik Platform due to the transfer of the Data, the controller of your Personal Data is the third party Data Provider and not us. In this case, we simply process the Personal Data on behalf of the Data Provider. Therefore, in these circumstances the third party Data Provider’s privacy policy governs the processing of your Personal Data, and not this privacy policy. We recommend that you familiarize yourself with the contents of the Data Provider’s privacy policy.**

**3 HOW INFORMATION IS COLLECTED**

3.1 Your Personal Data is collected when you sign up for an account on the Acentrik Platform. Your Personal Data may also be collected by analytics providers or other third party services used by the Acentrik Platform if you gave your specific and express consent. Other than Personal Data, third party analytics providers or other third party services used by the Acentrik Platform may also collect or be provided with anonymised information about your behaviour and interactions on the Acentrik Platform. DSEA shall have the right to unilaterally amend this Privacy Policy from time to time to reflect the information and data that is provided to such third parties insofar as such data does not constitute Personal Data. You have the right to opt out of such processing.

**4 WHAT WE DO WITH YOUR INFORMATION**

4.1 We process your Personal Data to provide our Services, including but not limited to the following:

(a) Provide you with a user account on the Acentrik Platform and allow you to access the Acentrik Platform and its API;
<br />
(b) Verify your identity, update our records and generally maintain your account with us and;
<br />
(c) Develop, operate, improve, deliver and maintain our Services.

**5 HOW IS THE PERSONAL DATA PROTECTED**

5.1 The security of your information is important to us. We have security measures in place to protect against the loss, misuse and alteration of information under our control. We also follow generally accepted industry standards to protect the information transmitted to us over the Internet, both during transmission and once we receive it.

5.2 However, no method of transmission over the Internet, or method of electronic storage, is 100% secure. Therefore, while we strive to use commercially acceptable means to protect your information, we cannot guarantee its absolute security. It is important that you protect against unauthorised access of your Account and information by choosing your password carefully, and keeping your password and Account secure (e.g. by signing out from the Acentrik Platform after using our Services).

**6 WHETHER WE SHARE OR TRANSFER YOUR PERSONAL DATA**

6.1 Except as otherwise provided in this Privacy Policy, we will not show, sell or rent your Personal Data to third parties, unless we are required to do so by law, a court order or similar judgement, or unless we obtain your prior consent.

**7 HOW LONG PERSONAL DATA WILL BE STORED FOR**

7.1 We will retain your Personal Data for as long as it is relevant for the purpose for which it was collected and will delete any personal data that is no longer relevant. This means that we will keep your Personal Data that is necessary to implement our agreement with you for as long as you maintain a user account on the Acentrik Platform.

7.2 We will also comply with any applicable laws or statutes which obligate us to retain your Personal Data for a specific time period, such as the mandatory retention periods under accounting laws and regulations. In regards to any Personal Data that we process based on your consent, we will retain such Personal Data for as long as it is relevant for the purpose for which the data was collected, unless you withdraw your consent before that.

7.3 You may request to close your account on the Acentrik Platform at any time. After we receive your request to close the account, we will do so as long as you have no outstanding obligations as either a Data Consumer or Data Provider and have no Content listed on the Acentrik Platform.

7.4 We will delete all your Personal Data when your account is closed within a reasonable time period, unless there are applicable laws or statutes which obligate or allow us to retain your Personal Data longer. If you have entered into a contract with a third party Data Provider, any such contract may contain further obligations as to for how long the personal information is kept.

**8 YOUR RIGHTS**

8.1 You have rights under the PDPA in relation to your Personal Data. To exercise any of your rights, please send us a written request in accordance with paragraph 1.5 of this Privacy Policy.

<ol type="a">
    <li>
     <strong>Right to access your Personal Data:</strong> You have the right to obtain confirmation from us whether your Personal Data is being processed. You also have the right to access your Personal Data and to obtain certain information, such as the purposes of processing your Personal Data, the types of Personal Data involved, the duration of the retention, the source of the Personal Data, safeguards relating to the transfer, and a copy of the Personal Data.
    </li>
    <br />
    <li><strong>Right to rectification</strong> : You have the right to request us to correct inaccurate Personal Data about you.</li>
    <br />
    <li><strong>Right to erasure</strong> : You have the right to request us to erase Personal Data about you in certain situations, such as if the Personal Data is no longer necessary for the purposes for which it was collected, if processing such Personal Data is unlawful or if the data was processed based on consent and you withdraw your consent.</li>
    <br />
    <li><strong>Right to restriction of processing your Personal Data:</strong> You have the right to restrict processing of your Personal Data in certain situations. If you exercise this right, we are generally only allowed to store the Personal Data in question. You might exercise this right, for example, if you believe that the Personal Data we hold about you is inaccurate, in which case your right to restriction of processing would apply for the time that it takes us to verify whether your belief is correct.</li>
    <br />
    <li><strong>Right to object to processing your Personal Data</strong> : <u>You may file an objection at any time to the processing of personal data pertaining to you that is collected under Article 6(1e) GDPR (data processing in the public interest) or Article 6 (1f) GDPR (data processing on the basis of a balance of interests). If you file an objection and the GDPR applies to you, we will continue to process your personal data only if we can document mandatory, legitimate reasons that outweigh your interests, rights and freedoms, or if processing is for the assertion, exercise or defense of legal claims. To the extent we use your personal data for direct marketing based on legitimate interests, your consent will be sought and you have the right to revoke your consent at any time without giving reasons.</u></li>
    <br />
    <li><strong>Right to data portability:</strong> You have the right to obtain your Personal Data in a structured, commonly used and machine-readable format and to transfer the Personal Data to another controller, if we process your Personal Data based on your consent or because of a contract that we have entered with you. For this right to be available to you, our processing of your Personal Data must take place by automated means.</li>
    <br />
    <li><strong>Right to withdraw your consent:</strong> To the extent we process your Personal Data based on your consent, you have the right to withdraw your consent at any time. You can do so by sending an email to <a href="mailto:support-acentrik@mercedes-benz.com">support-acentrik@mercedes-benz.com</a>. You can also manage your consent preferences by ticking the relevant boxes in the Privacy section of your user account settings on the Acentrik Platform. Withdrawing your consent does not affect the lawfulness of processing of your Personal Data based on consent before its withdrawal. 
</li>
    <br />
    <li><strong>Right to lodge complaint with supervisory authority:</strong> You have the right to lodge a complaint with the relevant data protection supervisory authority in your country, if you consider that the processing of your Personal Data infringes your rights under the laws applicable to you.
    </li>
</ol>
<br />

**9 AMENDMENTS TO THIS PRIVACY POLICY**

9.1 We will need to amend this Privacy Policy on a regular basis. Please check back regularly to view the latest version of this Privacy Policy online and we will keep you informed of important changes through information provided on the Acentrik Platform.
