---
title: Cookie Policy
description: FOR WEB USER
---

### **Cookie Policy**

<p class="subtitle2">Last updated: 22 July 2021 </p>

1 **USE OF COOKIES**

1.1 Daimler South East Asia Pte Ltd (&quot;**DSEA**&quot;, &quot;**we**&quot;, &quot;**us**&quot; or &quot;**our**&quot;) operates https://acentrik.io (the &quot;Site&quot;) and a decentralised data marketplace platform (the &quot;Acentrik Platform&quot;). The Site and the Acentrik Platform use cookies. Cookies make it possible for you to sign onto the Acentrik Platform and allows us to deliver a better and more personalized user experience for you.

1.2 A cookie is a small file that stores Internet settings. Almost every website uses cookie technology. It is downloaded by your web browser on the first visit to a website. The next time this website is opened with the same user device, the cookie and the information stored in it is either sent back to the website that created it (first-party cookie) or sent to another website it belongs to (third-party cookie). This enables the website to detect that you have opened it previously with this browser and in some cases to vary the displayed content.

1.3 When you first arrive on our Site, a cookie banner will be shown. By accepting the cookies, you help us to provide better content in the future. On our Site, we currently implement first-party cookies that are necessary for the use of the Site and the Acentrik Platform, such cookies are essential for a user to navigate the Site and the Acentrik Platform, use its features, and keep you logged in. First-party cookies are cookies that belong to DSEA.

The cookies currently being used on the Acentrik Platform and Site are as follows:

<div class="tableContainer">
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th>Name</th>
                <th>Provider</th>
                <th>Purpose</th>
                <th>Expiry</th>
                <th>Type</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td rowspan=9 valign="top">Necessary cookies are used to provide proper functioning of the Acentrik Platform and Site</td>
                <td>oceanDarkMode</td>
                <td>Application</td>
                <td>This cookie is used to identify user’s preferred application theme. Currently will be always set to dark mode</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>localStorage</td>
            </tr>
            <tr>
                <td>ocean-user-preferences</td>
                <td>User Input on Settings</td>
                <td>This cookie is used to identify user’s preferred setting such as currency (will disable this), bookmarks, blockchains network assets, etc. It also stores debug option for developer to check metadata value</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>localStorage</td>
            </tr>
            <tr>
                <td>providerServices</td>
                <td>Acentrik API</td>
                <td>This cookie is for list of edge node provider available for the user</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>localStorage</td>
            </tr>
            <tr>
                <td>ocean-publish-form </td>
                <td>User Input</td>
                <td>This cookie temporarily stores publish form value. User revisit could continue from the point of time stopped previously</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>localStorage</td>
            </tr>
            <tr>
                <td>networkId</td>
                <td>Web3 Plugin in Application Source from MetaMask</td>
                <td>This cookie is used to identify wallet chain network</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>localStorage</td>
            </tr>
            <tr>
                <td>jwt-latest-expiry</td>
                <td>User session expiry</td>
                <td>This cookie is used to retaining user session among multiple tabs</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>localStorage</td>
            </tr>
            <tr>
                <td>WEB3_CONNECT_CACHED_PROVIDER</td>
                <td>Web3 Plugin in Application</td>
                <td>This cookie is used for auto reconnect to wallet when user refreshes the page</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>localStorage</td>
            </tr>
        <tr>
                <td>@@scroll|/&lt;page&gt;|&lt;time&gt;</td>
                <td>Gatsby Plugin in Application</td>
                <td>This cookie is used for saving user scroll position</td>
                <td>No expiry but some action may replace or remove the cookie</td>
                <td>sessionStorage</td>
            </tr>
            <tr>
                <td>Refresh_token</td>
                <td>Acentrik Authentication</td>
                <td>This cookie is used for user authentication and authorization within Acentrik application</td>
                <td>5 minute or when the application/browser refreshed</td>
                <td>HTTP Cookie</td>
            </tr>
        </tbody>
    </table>
</div>
<br/>
We do not implement any other cookies at present, however we may introduce new cookies in future, including cookies relating to tracking user preferences, collation of user statistics, and marketing. This cookie policy will be updated to reflect the list of cookies being used on the Site and the Acentrik Platform when such new cookies are introduced. 
<br/>
<br/>
1.4 You have the option of disabling cookies in your browser setting, and deleting cookies from your computer’s hard disk at any time. However, turning off cookies may result in a loss of functionality when using our Site or the Acentrik Platform.
