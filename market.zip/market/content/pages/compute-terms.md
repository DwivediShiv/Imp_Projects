---
title: DATA SUBSCRIPTION (VIA COMPUTING ALGORITHM) TERMS AND CONDITIONS
description: FOR USER DATA PUBLISHERS AND USER DATA SUBSCRIBERS
---
## **DATA SUBSCRIPTION (VIA COMPUTING ALGORITHM) TERMS AND CONDITIONS FOR USER DATA PUBLISHERS AND USER DATA SUBSCRIBERS**

1 **DATA COMPUTING SERVICES**

1.1 These data subscription (computing) terms and conditions (&quot; **Computing Terms &amp; Conditions**&quot;) shall apply in addition to the General Terms and Conditions:

    (a) To a User Data Publisher who offers to other Users, through DDM, Data Computing Services in Content; and
    (b) To a User Data Subscriber who, through the Platform, engages DDM for Data Computing Services.

1.2 Once agreed, these Computing Terms &amp; Conditions are incorporated into the General Terms and Conditions and shall form part of the agreement between you and DDM for the use of the Platform. The definitions set out in the General Terms and Conditions are applicable to these Computing Terms and Conditions. By accepting these Computing Terms and Conditions, either by clicking to signify acceptance, or by using Data Computing Services, you agree to be bound by the provisions of this agreement.

1.3 **Data Computing Services** refer the service provided by the Platform where, in response to an offer made by a User Data Publisher in Content, a User Data Subscriber engages DDM to run algorithms (&quot; **Algorithms**&quot;) on the Data; the Algorithms that can be run on the Data are either offered by the User Data Publisher and listed on the Content, or whitelisted by the User Data Publisher upon provision of the Algorithm by the User Data Subscriber. DDM runs the Algorithms on the User Data Publisher&#39;s Data, either in the default Platform environment or the User Data Publishers&#39; own provider environment, and makes a copy of the outcome of the algorithmic computation (the &quot; **Output&quot;** ) available to download by the User Subscriber; The source Data on which the Algorithm was run is not made available to the User Data Subscriber as part of Data Computing Services.

2 **OBLIGATIONS OF USER DATA PUBLISHERS**

2.1 Where a User Data Publisher opts to offer Data Computing Services on the Data Publisher&#39;s Content, the Data Publisher agrees to grant a license to DDM to carry out the Data Computing Services on the Data to the extent of the Algorithms selected by the User Data Publisher. The User Data Publisher shall provide a compilable, error-free copy of the Algorithm to DDM for the purposes of carrying out the Data Computing Services. Where the User Data Publisher elects for the Algorithms to be run on the User Data Publisher&#39;s own environment, the User Data Publisher agrees to grant DDM all rights required to access the User Data Publisher&#39;s environment to run the Algorithms on the Data, and obtain and extract the Output.

2.2 In the event that a User Data Subscriber engages DDM for Data Computing Services, the User Data Publisher shall ensure that the Data that the Algorithms are to be run on is made available to DDM via the HTTP/HTTPS end-point listed on the Platform.

2.3 The User Data Publisher shall ensure that the Data provided to DDM for Data Computing Services through the HTTP/HTTPS end-point is complete and in conformity to what is described in the metadata on the Content, and that it is free from all viruses, malware, contamination, or destructive features, including but not limited to all viruses, malware, trojan horses, worms, adware, spyware, crimeware, online graffiti taggers, droppers, rootkits, keyloggers, bots, or other harmful software program or program elements. The User Data Publisher shall fully indemnify DDM from any and all loss or damage suffered by DDM arising from a breach of this provision.

2.4 The User Data Publisher shall ensure that any Algorithms offered on the Content shall be free from errors and all viruses, malware, contamination, or destructive features, including but not limited to all viruses, malware, trojan horses, worms, adware, spyware, crimeware, online graffiti taggers, droppers, rootkits, keyloggers, bots, or other harmful software program or program elements.

2.5 In the event of any Output that is either nil or inaccurate as a result of errors in the Algorithm, and losses are suffered by the User Data Subscriber as a result, the User Data Publisher agrees to be solely liable to the User Data Subscriber for any and all loss, and shall fully indemnify DDM in relation to any and all claims against DDM by any third parties (including but not limited to the User Data Subscriber) in relation to such losses.

3 **OBLIGATIONS OF DDM**

3.1  When engaged to carry out Data Computing Services by the User Data Subscriber, and on receipt of the Algorithms from either the User Data Publisher or the User Data Subscriber, DDM shall run the Algorithms on the Data made available to DDM by the User Data Publisher and make the Output available to the User Data Subscriber on the storage solution used by the Platform.

3.2 DDM does not provide any warranties about the quality, accuracy, completeness, or usability of the Output, including if for any reason the Output is nil (whether this is because of data corruption on the part of DDM, the User Data Publisher or otherwise). DDM shall not be responsible for the validation of the Data used for the Output, and shall produce the Output based solely on the Data and the Algorithms on an &quot;as is where is&quot; basis, as provided by the User Data Publisher, based on the User Data Subscriber&#39;s instructions.

3.3 Both the User Data Publisher and User Data Subscriber agree and acknowledge that to the fullest extent allowed by law DDM shall not be responsible for any errors or omissions in the Output or losses arising as a result thereof.

3.4 DDM does not warrant that the Output will be free from all viruses, malware, contamination, or destructive features, including but not limited to all viruses, malware, trojan horses, worms, adware, spyware, crimeware, online graffiti taggers, droppers, rootkits, keyloggers, bots, or other harmful software program or program elements.

3.5 For the avoidance of doubt, clauses 12, 13 and 14 of the User Terms and Conditions (amongst others) shall apply to any matter relating to Data Computing Services.

3.6 Each Output shall be made available by the Platform for User Data Subscribers to download though an end point one time for XX days from the date that the Output was first created, after which the download link shall expire and the User Data Subscriber will no longer be able to download the Output.

3.7 Once the Output is generated, the copy of the Data that the Algorithm is run on shall be purged by DDM, and DDM shall not retain the copy of the said Data.

4 **OBLIGATIONS OF USER DATA SUBSCRIBER**

4.1 In the event that the User Data Subscriber wishes to use an Algorithm of its own choice for the Data Computing Services, it shall be the obligation of the User Data Subscriber to obtain the consent of the User Data Publisher for the said Algorithm to be used on the User Data Publisher&#39;s Data. In doing so the User Data Subscriber shall not provide DDM with any Algorithm that has not been authorised by the User Data Publisher for the purposes of carrying out the Data Computing Services.

4.2 The User Data Subscriber agrees to make any and all payments (whether in the form of Tokens or otherwise) to DDM and the User Data Publisher as stipulated on the Platform by the User Data Publisher relating to the Output. The User Subscriber shall remain fully liable to make any and all such payments to DDM and the User Data Publisher even in the event that the Output is nil, or not what the User Data Subscriber had expected or anticipated.
