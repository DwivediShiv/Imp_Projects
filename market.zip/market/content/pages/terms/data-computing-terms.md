---
title: Data Computing Terms & Conditions
key: data-computing
description: Thanks for using our product and services.
---

<p class="subtitle2">Last updated: 02 November 2021 </p>

DATA SUBSCRIPTION (VIA COMPUTING ALGORITHM) TERMS AND CONDITIONS FOR DATA PROVIDERS AND DATA CONSUMERS

<br/>

1 **DATA COMPUTING SERVICES**

1.1 These data subscription (computing) terms and conditions (&quot;**Computing Terms & Conditions**&quot;) shall apply in addition to the General Terms and Conditions:
<br />

<ol type="a">
    <li>To a Data Provider who offers to other Users, through the Acentrik Platform, Data Computing Services in Content; and<br /></li>
    <li>To a Data Consumer who, through the Acentrik Platform, engages DSEA for Data Computing Services offered on the Acentrik Platform.</li>
</ol>
<br />

1.2 Once agreed, these Computing Terms & Conditions are incorporated into the General Terms and Conditions and shall form part of the agreement between you and DSEA for the use of the Platform. The definitions set out in the General Terms and Conditions are applicable to these Computing Terms and Conditions. By accepting these Computing Terms and Conditions, either by clicking to signify acceptance, or by using Data Computing Services, you agree to be bound by the provisions of this agreement.

1.3 **Data Computing Services** refer to the service provided by the Acentrik Platform where, in response to an offer made by a Data Provider in Content, a Data Consumer engages DSEA, through the Acentrik Platform, to run algorithms (&quot;**Algorithms**&quot;) on the Data; the Algorithms that can be run on the Data are either offered by the Data Provider and listed on the Content, or allowed by the Data Provider upon provision of the Algorithm by the Data Consumer. The Acentrik Platform runs the Algorithms on the Data Provider&#39;s Data, either in the default platform environment or the Data Providers&#39; own provider environment, and makes a copy of the outcome of the algorithmic computation (the &quot;**Output**&quot;) available to download by the Data Consumer; The source Data on which the Algorithm was run is not made available to the Data Consumer as part of Data Computing Services.

2 **OBLIGATIONS OF DATA PROVIDERS**

2.1 Where a Data Provider opts to offer Data Computing Services on the Data Provider&#39;s Content, the Data Provider agrees to grant a license to DSEA to carry out the Data Computing Services on the Data to the extent of the Algorithms selected by the Data Provider. The Data Provider shall provide a compilable, error-free copy of the Algorithm to DSEA for the purposes of carrying out the Data Computing Services. Where the Data Provider elects for the Algorithms to be run on the Data Provider&#39;s own environment, the Data Provider agrees to grant DSEA all rights required to access the Data Provider&#39;s environment to run the Algorithms on the Data, and obtain and extract the Output.

2.2 In the event that a Data Consumer engages DSEA for Data Computing Services, the Data Provider shall ensure that the Data and Algorithms are to be run on is made available to DSEA via the HTTP/HTTPS end-point listed on the Acentrik Platform.

2.3 The Data Provider shall ensure that the Data provided to DSEA for Data Computing Services through the HTTP/HTTPS end-point is complete and in conformity to what is described in the metadata on the Content, and that it is free from all viruses, malware, contamination, or destructive features, including but not limited to all viruses, malware, trojan horses, worms, adware, spyware, crimeware, online graffiti taggers, droppers, rootkits, keyloggers, bots, or other harmful software program or program elements. The Data Provider shall fully indemnify DSEA from any and all loss or damage suffered by DSEA arising from a breach of this provision.

2.4 The Data Provider shall ensure that any Algorithms offered on the Content shall be free from errors and all viruses, malware, contamination, or destructive features, including but not limited to all viruses, malware, trojan horses, worms, adware, spyware, crimeware, online graffiti taggers, droppers, rootkits, keyloggers, bots, or other harmful software program or program elements.

2.5 In the event of any Output that is either nil or inaccurate as a result of errors in the Algorithm, and losses are suffered by the Data Consumer as a result, the Data Provider agrees to be solely liable to the Data Consumer for any and all loss, and shall fully indemnify DSEA in relation to any and all claims against DSEA by any third parties (including but not limited to the Data Consumer) in relation to such losses.

3 **OBLIGATIONS OF DSEA**

3.1 When engaged to carry out Data Computing Services by the Data Consumer, and on receipt of the Algorithms from either the Data Provider or the Data Consumer, DSEA shall run the Algorithms on the Data made available to DSEA by the Data Provider and make the Output available to the Data Consumer on the storage solution used by the Acentrik Platform.

3.2 DSEA does not provide any warranties about the quality, accuracy, completeness, or usability of the Output, including if for any reason the Output is nil (whether this is because of data corruption on the part of DSEA, the Data Provider or otherwise). DSEA shall not be responsible for the validation of the Data used for the Output, and shall produce the Output based solely on the Data and the Algorithms on an &quot;as is where is&quot; basis, as provided by the Data Provider, based on the Data Consumer&#39;s instructions.

3.3 Both the Data Provider and Data Consumer agree and acknowledge that to the fullest extent allowed by law that DSEA shall not be responsible for any errors or omissions in the Output or losses arising as a result thereof.

3.4 DSEA does not warrant that the Output will be free from all viruses, malware, contamination, or destructive features, including but not limited to all viruses, malware, trojan horses, worms, adware, spyware, crimeware, online graffiti taggers, droppers, rootkits, keyloggers, bots, or other harmful software program or program elements.

3.5 Each Output shall be made available by the Acentrik Platform for Data Consumers to download though an end point one time for 60 days from the date that the Output was first created (&quot;**Output Download Link**&quot;), after which the Output Download Link shall expire and the Data Consumer will no longer be able to download the Output.

3.6 Once the Output is generated, the copy of the Data that the Algorithm is run on shall be purged by DSEA, and DSEA shall not retain the copy of the said Data.

3.7 Both the Data Provider and Data Consumer agree and acknowledge that once the Output Download Link is sent to the Data Consumer by the Acentrik Platform, DSEA has fulfilled its obligations in relation to providing the Output to the Data Consumer, DSEA no longer has control over the Output Download Link and the Output, and that to the fullest extent allowed by law, DSEA shall not be liable for any losses howsoever arising from any circulation of the Output Download Link, whether authorised or unauthorised by the Data Consumer or any third party, and any damage or losses arising out of or relating to the said circulation including but not limited to any download, theft or unauthorised use of the Output or the data contained in the Output by third parties.

3.8 For the avoidance of doubt, clauses 13, 14, 15 and 16 of the General Terms and Conditions (amongst others) shall apply to any matter relating to Data Computing Services.

4 **OBLIGATIONS OF DATA CONSUMER**

4.1 In the event that the Data Consumer wishes to use an Algorithm of its own choice for the Data Computing Services, it shall be the obligation of the Data Consumer to obtain the consent of the Data Provider for the said Algorithm to be used on the Data Provider&#39;s Data. In doing so the Data Consumer shall not provide DSEA with any Algorithm that has not been authorised by the Data Provider for the purposes of carrying out the Data Computing Services.

4.2 The Data Consumer agrees to make any and all payments (whether in the form of Tokens or otherwise) to DSEA and the Data Provider as stipulated on the Acentrik Platform by the Data Provider relating to the Output. The Data Consumer shall remain fully liable to make any and all such payments to DSEA and the Data Provider even in the event that the Output is nil, or not what the Data Consumer had expected or anticipated.

</div>
