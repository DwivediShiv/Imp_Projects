---
title: Storage Terms & Conditions
key: storage
description: For Decentralized Storage Service
---

<p class="subtitle2">Last updated: 08 December 2021 </p>

TERMS OF SERVICE FOR MARKETPLACE STORAGE OF DATA

<br/>

1 **GENERAL**

1.1 These Terms of Service for Marketplace Storage of Data (&quot;**Storage Terms**&quot;) are a legal agreement between you or the entity you represent (&quot;**you**&quot;, &quot;**your**&quot;, &quot;**User**&quot;) and Daimler South East Asia Pte Ltd (&quot;**DSEA**&quot;, &quot;**we**&quot;, &quot;**us**&quot;, &quot;**our**&quot;) governing the terms of your use of the Storage Services as defined herein. Once agreed, these Storage Terms are incorporated into the General Terms and Conditions and shall form part of the agreement between you and DSEA for the use of the Platform (&quot;**Acentrik Platform**&quot;). The definitions set out in the General Terms and Conditions and the Computing Terms and Conditions are equally applicable to these Storage Terms. By accepting these Storage Terms, either by clicking to signify acceptance, or by using the Storage Services, you agree to be bound by the provisions of this agreement.

2 **DEFINITIONS**

2.1 **Competent Authority**: This means any government, judicial or regulatory authority having jurisdiction over the subject matter of these Storage Terms, or over any of the parties hereto.

2.2 **Storage Services**: The Acentrik Storage Services utilises interplanetary file system (&quot;IPFS&quot;) distributed network of independent third-party storage nodes which you may access and use to store Storage Materials pursuant to the terms of your use of the Storage Services as set forth herein. The Storage Services employ technology provided by a third-party provider designed to encrypt and share Storage Materials locally on your device and then facilitate the distribution of encrypted data fragments to the network of storage nodes. The storage nodes are neither operated, controlled nor maintained by DSEA, and DSEA has no responsibility or liability for the storage nodes. You are solely responsible for your use of the Storage Services including for configurations that you select for maintaining access to your Storage Materials.

2.3 **Storage Materials**: This refers to any form of data (including but not limited to the Output as defined in the Computing Terms and Conditions, but excluding Data as defined in the General Terms and Conditions) stored by the User on the Storage Services.

3 **REGISTRATION ACCESS AND USAGE**

3.1 These Storage Terms shall be effective on the date the User first registers on the Acentrik Platform for access to the Storage Services (the &quot;**Effective Date**&quot;). DSEA may update the content, functionality, and user interface of the Storage Services from time to time in its sole discretion.

3.2 You acknowledge and recognise that IPFS is a maturing technology that is still in beta testing, and in using the Storage Services, you fully accept the risk that in IPFS errors or faults may arise that may cause either corruption or loss of data, and agree to bear all such risk and not hold DSEA liable for any loss or damage (whether direct, indirect, or otherwise) arising out of the use of the Storage Services.

3.3 **Restrictions on use**: User shall not:

(a) Reverse engineer, copy, modify, adapt, hack the Storage Services or otherwise attempt to gain unauthorized access to the Storage Services or its related systems or networks;
<br />
(b) Without authorization, access the Storage Services or its related systems or networks to build a competitive product or Storage Services;
<br />
(c) Access or use the Storage Services:

<ol type="i">
 <li>To store the Data as defined in the General Terms and Conditions;</li>
 <li>To store infringing, obscene, threatening, or otherwise unlawful material, including material which violate third-party privacy rights or are in violation of applicable laws; </li>
 <li>To store material knowingly or intentionally containing software viruses, worms, Trojan horses, or other harmful computer code, files, or scripts; </li>
 <li>In a manner that interferes with or disrupts the integrity or 	performance of the Storage Services (or the data contained therein);</li>
 <li>To store personal information which is sensitive and/or confidential in nature, including but not limited to: credit card information, credit card numbers and magnetic stripe information, social security numbers, driver&#39;s license numbers, passport numbers, government-issued identification numbers, health-related information, biometric data, financial account information, personally identifiable information collected from children under the age of 13 or from online services directed toward children, and real time geo-location data which can identify an individual, or information deemed &quot;sensitive&quot; under applicable laws; or</li>
 <li>To store information that is the subject of confidentiality obligations between yourself and third parties.</li>
</ol>
<br />

3.4 **Right to suspend**: DSEA may immediately, with or without notice, suspend or terminate the Account of any User who: (a) violates these Storage Terms (b) uses the Storage Services in a manner that DSEA reasonably believes may cause a security risk, a disruption to others&#39; use of the Storage Services or liability for DSEA. In the event that the acts of a User give rise to potential criminal liability, DSEA reserves the rights to provide login and other details of the User and the User&#39;s account to the relevant authorities for further investigation.

4 **OWNERSHIP OF INTELLECTUAL PROPERTY**

4.1 Except for software subject to open source licenses, DSEA and its licensors own and shall retain all right, title, and interest in and to all intellectual property rights comprised in the Storage Services (including any improvements, enhancements, customizations, and modifications thereto).

5 **FEES, BILLING AND PAYMENT**

5.1 For the use of Storage Services, you shall pay the fees set forth on the Acentrik Platform.

6 **STORAGE MATERIALS**

6.1 **License**: You grant DSEA and Acentrik a non-exclusive, royalty-free, worldwide, perpetual, irrevocable, transferable, and fully sublicensable right to reproduce, modify, distribute, and export the Storage Materials to the extent necessary to meet our obligations hereunder, to comply with your instructions to store such Storage Materials via the Storage Services, and to carry out the day to day running of the Storage Services in relation to supporting the Acentrik Platform.

6.2 **Backup**: DSEA does not recommend that you use the Storage Services as a form of data backup and you are advised to only store the sample files of any data in the Storage Services, rather than the actual data. While DSEA shall endeavour to ensure availability of the Storage Materials, but you recognise and acknowledge that software and hardware failures may occur for reasons beyond DSEA&#39;s control or otherwise, causing the irretrievable loss of the Storage Materials. In this regard, DSEA does not guarantee the maintenance and availability of any Storage Materials, and in using the Storage Services, you fully acknowledge and accept that DSEA is not responsible for any loss, misuse, or deletion of Storage Materials or any failure of any Storage Materials to be stored or encrypted, for any reason whatsoever. You are responsible for mitigating any and all risk of loss of any of the Storage Materials you store on the Storage Services by backing up and maintaining copies of the Storage Materials outside of the Storage Services, and DSEA shall not be responsible for any loss suffered by you for your failure to do so.

6.3 **Security**: You are responsible for properly configuring and using the Storage Services to store your Storage Materials and for maintaining appropriate security of your Storage Materials, which includes client-side encryption.

6.4 **Compliance with Laws**: You are solely responsible for ensuring that your use of the Storage Services is in compliance with all applicable laws. We make no representations or warranties regarding the suitability of the Storage Services for the storage of any particular types of data or for your specific usage. DSEA makes no representation or warranty that the using the Storage Services to store any Storage Materials that include personal data or sensitive data requiring heightened security protections complies with any specific regulations or laws. **You must provide all notices to, and obtain any necessary consents from, third parties as required by applicable laws in connection with the storage of Storage Materials via the Storage Services. We reserve the right at any time, without notice, to remove, reject or delete any Storage Materials that contain unencrypted and/or plain text data or otherwise violate these Storage Terms**.

7 **NO PERSONAL DATA CONTAINED IN STORAGE MATERIALS**

7.1 No Personal Data should be contained in any Storage Material at all times. If it is essential for the Storage Materials to contain some Personal Data, the User must ensure and hereby warrants that all Personal Data has been collected in accordance with the Personal Data Protection Act 2012 (&quot;**PDPA**&quot;), General Data Protection Regulation, Regulation (EU) 2016/679 (&quot;**GDPR**&quot;) and other applicable laws, and that any use of the Personal Data by DSEA or the User has been consented to by the individual whose Personal Data is being processed. DSEA will not be responsible for the loss of any Personal Data or any potential breaches regarding the Personal Data stored in the Storage Materials.

8 **USER SUPPORT**

8.1 DSEA may provide certain support services in connection with your use of the Storage Services as stated on the Acentrik Platform, which may be changed from time to time.

9 **TERMINATION**

9.1 We reserve the right to terminate or suspend your ability to use the Storage Services at any time, with or without notice, if we are of the view or suspicion that you may be using the Storage Services in breach of these terms, in contravention of any applicable laws, infringement of intellectual property rights, or as part of criminal activity. In such event we reserve the right to provide any Storage Materials to the relevant authorities without further notice to you. Upon expiration or termination of these Storage Terms for any reason, all use of the Storage Services and any other rights granted to User under these Storage Terms shall immediately terminate, and User shall immediately cease all use of the Storage Services.

9.2 User acknowledges and agrees that if the User&#39;s access to the Storage Services is suspended or terminated for any reason, User will no longer have access to the Storage Materials stored in the Storage Services and User&#39;s Storage Materials may not be recoverable.

9.3 In the event of termination, DSEA is under no obligation to return any Storage Materials to you.

Please note that the provision of such Storage Services is a test feature offered by DSEA and DSEA reserves the right to terminate such Storage Services in the future at its sole discretion. If DSEA chooses to terminate the provision of such Storage Services at its sole discretion, independently of any reason stated at Clause 9.1 above, DSEA will endeavour to provide all Users with 90-days&#39; advance notice of such termination.

10 **LIMITATION OF LIABILITY**

10.1 **TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT WILL DSEA, OR ITS AFFILIATES, OFFICERS, DIRECTORS, EMPLOYEES, AGENTS, PARTNERS, REPRESENTATIVES, OR LICENSORS BE LIABLE FOR ANY DAMAGES, INCLUDING WITHOUT LIMITATION DIRECT OR INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL EXPENSES OR DAMAGES; LOSSES OF PROFITS, SALES, BUSINESS OR REVENUE; BUSINESS INTERRUPTION; LOSS OF ANTICIPATED SERVICES; LOSS OF BUSINESS OPPORTUNITY, DATA, USE, GOODWILL OR REPUTATION, WHETHER INCURRED DIRECTLY OR INDIRECTLY, ARISING IN CONNECTION WITH:**
<br />
(a) **YOUR ACCESS TO OR USE OF OR INABILITY TO ACCESS OR USE THE STORAGE SERVICES**;
<br />
(b) **ANY PARTIAL OR COMPLETE LOSS OR CORRUPTION OF THE STORAGE MATERIALS ON THE STORAGE SERVICES, WHETHER ARISING OUT OF THE ACTS OR OMISSIONS (DELIBERATE OR OTHERWISE) BY DSEA OR OTHERWISE.**;
<br />
(c) **THE MANNER IN WHICH THE STORAGE MATERIALS ARE STORED THROUGH THE STORAGE SERVICES; OR**
<br />
(d) **UNAUTHORIZED ACCESS, USE, OR ALTERATION OF YOUR STORAGE MATERIALS DUE TO THE USE OF THE STORAGE SERVICES , EVEN IF DSEA OR OUR REPRESENTATIVES ARE ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, LOSSES, OR EXPENSES**.

10.2 **IF THERE ARE CLAIMS MADE AGAINST DSEA ARISING OUT OF ANY NON-COMPLIANCE WITH THE LAWS APPLICABLE TO THE PROCESSING OF PERSONAL DATA BY YOU, YOU SHALL ALSO INDEMNIFY DSEA FROM ANY REGULATORY FINES WHICH MAY BE IMPOSED ON DSEA BY ANY COMPETENT AUTHORITY**.

10.3 **DSEA DOES NOT PROVIDE ANY GUARANTEE THAT THE STORAGE MATERIALS WILL BE ACCESSIBLE OR AVAILABLE OR DEMAND OR RETRIEVABLE AT ANY TIME. YOU ARE RESPONSIBLE FOR MAINTAINING BACKUP COPIES OF ALL STORAGE MATERIALS AT ALL TIMES. DSEA IS NOT RESPONSIBLE FOR ANY LOSS OR DAMAGE TO STORAGE MATERIALS**.

11 **INDEMNIFICATION**

11.1 You agree to indemnify, defend, and hold harmless DSEA, its affiliates, officers, directors, employees, agents, partners, representatives, and licensors (the &quot;**Indemnified Parties**&quot; and each an &quot;**Indemnified Party**&quot;) from and against all losses, expenses, damages, and costs, including reasonable attorneys&#39; fees, due to, arising out of, or relating in any way to (i) any violation of these Storage Terms (including negligent or wrongful conduct) by you, (ii) your access to or use of the Storage Services, or (iii) information provided by you, including, without limitation, infringement by your Storage Materials of any third party intellectual property rights or infringement of any individual's privacy rights. You agree to fully cooperate at your expense as reasonably required by an Indemnified Party. Each Indemnified Party may, at its election, assume the defense and control of any matter for which it is indemnified hereunder. You shall not settle any matter involving an Indemnified Party without the consent of the applicable Indemnified Party.

</div>
