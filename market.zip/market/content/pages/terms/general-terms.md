---
title: General Terms & Conditions
key: general
description: Thanks for using our product and services.
---

<p class="subtitle2">Last updated: 14 April 2022 </p>

**1 GENERAL**

1.1 These Terms and Conditions (&quot;**Terms**&quot;) govern your use of the decentralised data marketplace Platform (the &quot;**Platform**&quot;) provided by Daimler South East Asia Pte Ltd (**&quot;DSEA&quot; &quot;we&quot;, &quot;us&quot;, &quot;our&quot;**).

1.2 We are a private limited company registered under the laws of Singapore, which is located at Daimler South East Asia Pte. Ltd., Westgate Tower, 1 Gateway Drive #15-01, Singapore 608531.

1.3 &quot;**Asset Listing**&quot; means listings published on the Platform which sets out relevant information on the Data Assets being sold or licensed on the Platform.

1.4 &quot;**Data Asset**&quot; means a set(s) of data that is being offered on the Platform.

1.5 &quot;**Services**&quot; shall be defined as the access to the Platform for reviewing Asset Listings.

1.6 Your use and access of the Services means that you are accepting the Terms. If you do not agree with the Terms, please discontinue your use of any Services.

**2 PERSONS ALLOWED TO USE THE SERVICE**

2.1 You are not allowed to use the Services if you are under the age of majority where you live. By accepting these Terms, you affirm that you are at least 18 years old (or the age of majority where you live), and are competent and authorized to agree to and abide by these Terms. If you are not 18 years of age or older, please stop using the Services.

**3 CHANGES TO THE TERMS**

3.1 DSEA has the right to change these Terms at any time by uploading the revised Terms onto the Platform and by notifying you of the change in the Platform. By continuing to access or use the Services after an amendment becomes effective, you agree to be bound by the amended Terms.

**4 ACCESS AND USE OF THE SERVICES**

4.1 You are authorized to use the Services only in accordance with these Terms.

4.2 You shall not duplicate, decompile, publish, modify, reverse engineer, create derivative works from, participate in the transfer of, post on the World Wide Web, attempt to extract the source code of that software, make any modification, adaptation, improvement, enhancement to or in any way distribute or exploit the Services or the Platform.

4.3 No rights or licenses in the Services or the Platform are granted or conveyed to you, except access rights as expressly set forth in this Section 4, whether expressly, by implication, estoppel, reliance or otherwise, all of which are specifically excluded and disclaimed.

4.4 **User Account**. When creating your User Account, you agree that you will provide to us true, accurate, current, and complete information and will update the information about yourself promptly. You are responsible for any activity that occurs in your User Account. Please keep it secure, protect it with a strong password, and do not share the password with anyone. If you think that someone has gained access to your User Account, please contact us immediately at: [support-acentrik@mercedes-benz.com](mailto:support-acentrik@mercedes-benz.com).

4.5 You acknowledge that until your account is verified and authorised to do so by your employer, you will only be able to view Asset Listings and will not be able to publish or consume a Data Asset.

**5 WARRANTY DISCLAIMER**

5.1 To the maximum extent permitted by the applicable law, you understand and agree that the Platform, information and materials in the Services, are provided to you on an “as is” and “as available” basis and disclaims all warranties and conditions, whether express or implied, of merchantability, fitness for a particular purpose, title, or noninfringement and warranties arising from course of dealing or course of performance.

5.2 DSEA makes no warranty whatsoever to you, express or implied, regarding the security of the Services, including with respect to the ability of unauthorized persons to intercept or access information transmitted by you or to you through the Services.

**6 INDEMNIFICATION**

6.1 You agree, to indemnify, defend, and hold harmless DSEA, its affiliates, officers, directors, employees, agents, partners, representatives, and licensors (the &quot;**Indemnified Parties**&quot; and each an &quot;**Indemnified Party**&quot;) from and against all losses, expenses, damages, and costs, including reasonable attorneys’ fees, due to, arising out of, or relating in any way to (i) any violation of these Terms (including negligent or wrongful conduct) by you, (ii) your access to or use of the Services. You agree to fully cooperate at your expense as reasonably required by an Indemnified Party. Each Indemnified Party may, at its election, assume the defense and control of any matter for which it is indemnified hereunder. You shall not settle any matter involving an Indemnified Party without the consent of the applicable Indemnified Party.

**7 DISCLOSURE OF USE**

7.1 DSEA reserves the right at all times to disclose any information that DSEA deems necessary to comply with any applicable law, regulation, legal process, or governmental request. DSEA may also disclose your information when DSEA determines that applicable law requires or permits such disclosure, including exchanging information with other companies and organizations for fraud protection purposes.

**8 GENERAL**

8.1 No agency, partnership, joint venture, employee-employer or franchiser-franchisee relationship is intended or created by these Terms.

8.2 If any provision of these Terms is held unenforceable, then such provision will be modified to reflect the parties' intention. All remaining provisions of these Terms shall remain in full force and effect.

8.3 Any failure by DSEA to exercise a right or require performance of an obligation in these Terms shall not affect DSEA’s ability to exercise such right or require such performance at any time thereafter nor shall the waiver of a breach of these Terms constitute a waiver of any subsequent breach.

8.4 You shall not assign any rights or delegate any obligations herein without our prior written consent and any attempted assignment or delegation in contravention of this provision shall be null and void and of no force or effect.

8.5 These Terms constitute the entire agreement between you and DSEA and supersedes all prior or contemporaneous understandings and/or agreements between you and DSEA.

**9 TERMINATION**

9.1 We reserve the right to terminate or suspend your ability to use the Services at any time, such as by deleting or suspending your User Account, if we are of the view or suspicion that you may be using the Services in breach of these Terms, in contravention of any applicable laws, infringement of intellectual property rights, or as part of criminal activity. In such event we reserve the right to provide any relevant information to the relevant authorities without further notice to you. Additionally, your rights to use the Services will terminate immediately if you breach any of these Terms. In the event that your User Account is suspended, to the maximum extent permitted by applicable laws, DSEA shall bear no liability for any expenses, losses, damages or any other costs incurred by you or any third party due to such suspension of your User Account.

**10 APPLICABLE LAWS AND JURISDICTION**

10.1 Your use of these Services shall be governed in all respects by the laws of Singapore. Any dispute arising out of or in connection with this contract, including any question regarding its existence, validity or termination, shall be referred to and finally resolved by arbitration administered by the Singapore International Arbitration Centre in accordance with the Arbitration Rules of the Singapore International Arbitration Centre for the time being in force, which rules are deemed to be incorporated by reference in this clause.
